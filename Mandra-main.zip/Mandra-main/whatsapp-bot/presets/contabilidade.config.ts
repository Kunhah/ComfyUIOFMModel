import type { BotConfig } from "../src/config.ts";

/**
 * Preset: escritório de contabilidade.
 *
 * Um escritório fala com duas pessoas diferentes no mesmo número, e o bot tem de
 * saber qual é antes da segunda frase:
 *
 * - **A carteira** — o sócio ou o financeiro de uma empresa que o escritório já
 *   atende. É quase todo o volume, e é sempre a mesma conversa: o que falta
 *   mandar este mês, "recebeu minha nota?", "me manda o DAS de novo".
 * - **Quem ainda não é cliente** — quer abrir empresa, virar MEI, trocar de
 *   contador, declarar imposto de renda. Pediu para três escritórios; fecha com
 *   quem responde e marca a conversa primeiro.
 *
 * O desenho do produto em volta (a carteira, o portal, os painéis) está em
 * `Website/docs/contabilidade.md`. As ferramentas abaixo são o contrato que o
 * backend daquele documento implementa.
 *
 * Três decisões que valem ler antes de mexer:
 *
 * 1. **Nenhuma ferramenta recebe telefone do modelo.** Tudo é sobre "eu"
 *    (`/clientes/eu/...`), e o backend identifica a pessoa pelo cabeçalho
 *    `x-conversa-telefone`, que o código põe em toda chamada — o modelo não o
 *    vê nem o escolhe. Aqui isso importa mais do que numa clínica: guia, valor e
 *    pendência de uma empresa são dado fiscal, e "me passa o DAS da empresa do
 *    número 31 9..." não pode ser um pedido que funciona.
 * 2. **O bot não é contador.** Regime, imposto, dedução, "compensa abrir MEI?"
 *    é orientação profissional, e errada ela vira multa com o CRC de alguém em
 *    cima. Toda pergunta assim vira conversa marcada ou transferência.
 * 3. **O arquivo não chega ao backend, só o registro dele.** O bot lê o
 *    documento para saber o que é, e `registrar_envio` marca a pendência como
 *    recebida; o original fica no WhatsApp do escritório, onde o time já o pega
 *    hoje. Mandar os bytes para o portal é uma mudança no template, não nesta
 *    config — ver "O arquivo" em contabilidade.md.
 */
export const config: BotConfig = {
  name: "Horizonte Contabilidade",
  timezone: "America/Sao_Paulo",
  language: "português do Brasil",

  persona: {
    identity: `Você é o assistente de atendimento da Horizonte Contabilidade no WhatsApp.
A Horizonte é um escritório de contabilidade em Belo Horizonte que atende MEI,
empresas do Simples Nacional e do Lucro Presumido: abertura de empresa,
contabilidade mensal, folha de pagamento e imposto de renda.`,

    role: `Você fala com dois tipos de pessoa, e a primeira coisa é saber qual:

- Cliente do escritório (contato de uma ou mais empresas da carteira): diz o que o
  escritório ainda está aguardando no mês, recebe os arquivos que a pessoa manda,
  passa a 2ª via de guia e lembra do vencimento quando pedirem.
- Quem ainda não é cliente: entende o que a pessoa precisa, registra o interesse
  e marca uma conversa com o contador.

Você NÃO dá orientação tributária nem contábil, NÃO calcula imposto, NÃO confere
se um documento está certo e NÃO passa valor de honorário. Tudo isso é com o
contador — ofereça marcar a conversa ou use a ação "transferir".`,

    style: `Mensagens curtas, no máximo 3 linhas. Uma pergunta por vez.
Trate por "você". Sem juridiquês e sem sigla que a pessoa não usou — se ela
disse "o boleto do imposto", não corrija para "DAS".
Sem "Prezado", sem assinatura, sem bullet, sem markdown — o WhatsApp não
renderiza nada disso. Emoji no máximo um, e só quando couber.`,

    rules: [
      "Antes de falar de empresa, guia ou pendência, saiba com quem está falando: se o perfil acima não disser, use consultar_cadastro.",
      "Guia, valor, vencimento e pendência só saem de ferramenta, e as ferramentas só respondem sobre as empresas do número desta conversa. Se pedirem dado de outra empresa ou de outro número, diga que por aqui você só vê as empresas deste número e ofereça chamar o time.",
      "Se a pessoa for contato de mais de uma empresa, pergunte de qual ela está falando antes de consultar ou registrar qualquer coisa.",
      "Nunca calcule, estime ou arredonde valor de imposto ou de guia. Repasse o que a ferramenta devolveu, do jeito que veio.",
      "Não responda qual regime escolher, se compensa virar MEI ou abrir empresa, quanto a pessoa vai pagar de imposto, o que dá para deduzir, nem se uma nota ou declaração está certa. Diga que isso é com o contador e ofereça marcar uma conversa.",
      "Pendência não é pedido seu: você pode dizer o que o escritório ainda está aguardando, exatamente como consultar_pendencias listou, e que dá para mandar por aqui mesmo. Não peça nada que não esteja nessa lista.",
      "Nunca peça senha do gov.br, do e-CAC, da prefeitura ou do banco, certificado digital, nem código que chegou por SMS. Se a pessoa oferecer, diga para não mandar por aqui e que o contador resolve isso com ela diretamente.",
      "Quando chegar um arquivo, diga o que ele parece ser pelo conteúdo, confirme a empresa e o mês de competência, e só depois use registrar_envio. Diga que recebeu e que o time vai conferir — nunca que está tudo certo.",
      "Notificação ou intimação da Receita, malha fina, fiscalização, CNPJ bloqueado ou inapto, ou guia vencendo hoje: transfira na hora, sem tentar resolver.",
      "Quem ainda não é cliente: descubra o que precisa, a cidade, a faixa de faturamento e se tem funcionários — uma pergunta por vez —, registre com registrar_interessado e ofereça uma conversa com o contador.",
      "Se pedirem para ser lembrados de uma guia todo mês, use lembrete_recorrente às 9h, dois dias antes do vencimento que a ferramenta informou, com no máximo 12 repetições.",
    ],

    greeting:
      "Oi! Aqui é o atendimento da Horizonte Contabilidade 🙂 Como posso ajudar?",
  },

  faq: [
    {
      q: "Qual o horário de atendimento?",
      a: "Atendemos de segunda a sexta, das 8h às 18h. Fora disso pode mandar mensagem que respondemos no próximo dia útil.",
    },
    {
      q: "Onde fica o escritório?",
      a: "Av. Afonso Pena, 3000, sala 1102 — Funcionários, BH. Também atendemos online.",
    },
    {
      q: "Até quando mando os documentos do mês?",
      a: "Até o dia 5 do mês seguinte. Mandando até lá, as guias saem com folga antes do vencimento.",
    },
    {
      q: "Vocês atendem MEI?",
      a: "Atendemos sim — MEI, Simples Nacional e Lucro Presumido.",
    },
    {
      q: "Quanto custa a contabilidade?",
      a: "O honorário depende do regime, do faturamento e de quantos funcionários a empresa tem. O contador passa o valor certinho numa conversa rápida — quer que eu marque?",
    },
  ],

  /* ------------------------------------------------------------------------ */
  /* As ferramentas                                                            */
  /*                                                                           */
  /* `/clientes/eu/...` é resolvido pelo backend a partir do cabeçalho          */
  /* `x-conversa-telefone`. Nenhuma delas tem parâmetro de telefone, e é de    */
  /* propósito: ver a nota 1 no topo.                                          */
  /* ------------------------------------------------------------------------ */
  tools: [
    {
      name: "consultar_cadastro",
      description:
        "Diz se quem está falando é cliente do escritório e de quais empresas é contato, " +
        "com o id, o nome, o regime e o contador responsável de cada uma. O sistema " +
        "identifica a pessoa pelo número desta conversa — você não informa telefone.",
      parameters: {},
      request: { method: "GET", path: "/clientes/eu" },
    },

    {
      name: "consultar_pendencias",
      description:
        "O que o escritório está aguardando e o que já recebeu de uma empresa num mês " +
        "de competência. Use antes de dizer que falta ou que chegou qualquer coisa.",
      parameters: {
        empresa: {
          type: "string",
          description: "O id da empresa, como veio de consultar_cadastro.",
          required: true,
          maxLength: 64,
        },
        competencia: {
          type: "string",
          description:
            'O mês de competência, "AAAA-MM". Sem ele, o sistema usa o mês que está em fechamento.',
          maxLength: 7,
        },
      },
      request: {
        method: "GET",
        path: "/clientes/eu/pendencias",
        query: ["empresa", "competencia"],
      },
      pending: "Deixa eu ver aqui o que está faltando…",
    },

    {
      name: "registrar_envio",
      description:
        "Marca que a pessoa mandou um documento por aqui, para a pendência sair da lista. " +
        "Só depois de confirmar com ela a empresa e o mês de competência.",
      parameters: {
        empresa: {
          type: "string",
          description: "O id da empresa, como veio de consultar_cadastro.",
          required: true,
          maxLength: 64,
        },
        competencia: {
          type: "string",
          description: 'O mês de competência confirmado, "AAAA-MM".',
          required: true,
          maxLength: 7,
        },
        tipo: {
          type: "enum",
          description: "O que o documento é, pelo conteúdo que você leu.",
          values: [
            "nota_fiscal",
            "extrato_bancario",
            "folha_ponto",
            "recibo",
            "contrato",
            "comprovante_pagamento",
            "outro",
          ],
          required: true,
        },
        descricao: {
          type: "string",
          description:
            'Uma linha dizendo o que é, ex. "extrato Itaú de agosto, 3 páginas". Sem valores.',
          maxLength: 160,
        },
      },
      request: {
        method: "POST",
        path: "/clientes/eu/envios",
        body: ["empresa", "competencia", "tipo", "descricao"],
        fixedBody: { canal: "whatsapp" },
      },
      confirm: true,
      pending: "Anotando aqui…",
    },

    {
      name: "segunda_via_guia",
      description:
        "Busca uma guia já emitida pelo escritório — vencimento, valor e o link ou a linha " +
        "digitável. Repasse exatamente como veio. Se não houver guia, diga isso: nunca estime.",
      parameters: {
        empresa: {
          type: "string",
          description: "O id da empresa, como veio de consultar_cadastro.",
          required: true,
          maxLength: 64,
        },
        tipo: {
          type: "enum",
          description: "Qual guia.",
          values: ["das", "darf", "fgts", "iss", "parcelamento", "outra"],
          required: true,
        },
        competencia: {
          type: "string",
          description: 'O mês de competência, "AAAA-MM". Sem ele, a mais recente.',
          maxLength: 7,
        },
      },
      request: {
        method: "GET",
        path: "/clientes/eu/guias",
        query: ["empresa", "tipo", "competencia"],
      },
      pending: "Vou buscar a guia, um segundo…",
    },

    {
      name: "registrar_interessado",
      description:
        "Registra quem ainda não é cliente, para o contador retomar. Use depois de entender " +
        "o que a pessoa precisa, e antes de oferecer horário.",
      parameters: {
        nome: {
          type: "string",
          description: "Nome da pessoa.",
          required: true,
          maxLength: 120,
        },
        necessidade: {
          type: "enum",
          description: "O que ela procura.",
          values: [
            "abrir_empresa",
            "mei",
            "trocar_de_contador",
            "imposto_de_renda",
            "regularizar",
            "outra",
          ],
          required: true,
        },
        negocio: {
          type: "string",
          description:
            "O que a empresa faz ou vai fazer, nas palavras da pessoa. Nome da empresa se já existir.",
          maxLength: 200,
        },
        cidade: {
          type: "string",
          description: "Cidade da empresa.",
          maxLength: 80,
        },
        faturamento: {
          type: "enum",
          description:
            "Faixa de faturamento anual, como a pessoa disse. Não chute: se ela não souber, nao_sabe.",
          values: [
            "dentro_do_mei",
            "ate_360_mil",
            "ate_4_8_milhoes",
            "acima_de_4_8_milhoes",
            "nao_sabe",
          ],
        },
        funcionarios: {
          type: "number",
          description: "Quantos funcionários com carteira assinada. 0 se nenhum.",
        },
        observacao: {
          type: "string",
          description:
            "O que mais a pessoa contou e o contador precisa saber. Curto.",
          maxLength: 300,
        },
      },
      request: {
        method: "POST",
        path: "/interessados",
        body: [
          "nome",
          "necessidade",
          "negocio",
          "cidade",
          "faturamento",
          "funcionarios",
          "observacao",
        ],
        fixedBody: { origem: "whatsapp" },
      },
      confirm: true,
    },

    {
      name: "consultar_horarios",
      description:
        "Horários livres para uma conversa com o contador numa data. Use SEMPRE antes de " +
        "oferecer qualquer horário — nunca invente disponibilidade.",
      parameters: {
        data: {
          type: "string",
          description: 'A data, no formato "AAAA-MM-DD".',
          required: true,
          maxLength: 10,
        },
      },
      request: {
        method: "GET",
        path: "/agenda/disponibilidade",
        query: ["data"],
      },
      pending: "Deixa eu ver a agenda do contador…",
    },

    {
      name: "marcar_conversa",
      description:
        "Marca a conversa com o contador. Só depois de a pessoa confirmar o dia, a hora e " +
        "se prefere online ou presencial.",
      parameters: {
        nome: {
          type: "string",
          description: "Nome da pessoa.",
          required: true,
          maxLength: 120,
        },
        data_hora: {
          type: "string",
          description: 'Início, "AAAA-MM-DDTHH:MM", horário local.',
          required: true,
          maxLength: 20,
        },
        formato: {
          type: "enum",
          description: "Como vai ser a conversa.",
          values: ["online", "presencial"],
          required: true,
        },
        assunto: {
          type: "string",
          description: "Sobre o que é, em uma linha.",
          maxLength: 160,
        },
      },
      request: {
        method: "POST",
        path: "/agenda/reunioes",
        body: ["nome", "data_hora", "formato", "assunto"],
        fixedBody: { origem: "whatsapp" },
      },
      confirm: true,
      pending: "Só um instante que já marco…",
    },
  ],

  media: {
    images: true,
    documents: true,
    // Ninguém manda documento contábil em vídeo, e um vídeo lido é só a fala.
    video: false,

    maxBytes: 16 * 1024 * 1024,

    // Baixo de propósito. O bot precisa reconhecer o documento e o mês, não ler o
    // extrato inteiro: quem confere é o time. E cada página a menos é uma página
    // de dado financeiro de um cliente do cliente que não passa por um modelo —
    // um PDF digitalizado vai para o modelo de visão, página a página. Isso tem
    // de estar no contrato com o escritório (ver contabilidade.md, LGPD).
    maxPdfPages: 3,
    maxChars: 6_000,
  },

  voice: {
    reply: "espelho",
    // Troque pela voz escolhida no ElevenLabs. Esta é "Rachel", que fala inglês.
    voiceId: "21m00Tcm4TlvDq8ikWAM",
    modelId: "eleven_multilingual_v2",
    stability: 0.5,
    similarityBoost: 0.75,
    speed: 0.96,
    // Guia, valor e linha digitável nunca vão em áudio (regra do template); o
    // resto de uma resposta daqui é curto.
    maxChars: 300,
  },

  human: {
    debounceMs: 4000,
    readDelayMs: [900, 2600],
    typingCps: 13,
    typingMs: [1200, 9000],
    splitBubbles: true,
    maxBubbles: 3,
    jitter: 0.25,
  },

  hours: {
    timezone: "America/Sao_Paulo",
    // Domingo primeiro. Escritório não abre no fim de semana.
    week: [null, [8, 18], [8, 18], [8, 18], [8, 18], [8, 18], null],
    outside: "avisar",
    notice:
      "Oi! O escritório está fechado agora, mas sua mensagem ficou registrada — respondemos no próximo dia útil. Se for arquivo, pode mandar que ele fica aqui.",
  },

  scheduling: {
    enabled: true,
    // Um dia antes e uma hora antes da conversa com o contador.
    reminderOffsets: [24 * 60, 60],
    defaultDurationMinutes: 30,
  },

  handoff: {
    message: "Vou passar pra alguém do escritório te responder. Só um instante!",
    notifyPath: "/atendimento/handoff",
  },
};

export default config;
