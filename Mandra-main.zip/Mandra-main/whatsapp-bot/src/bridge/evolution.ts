import { timingSafeEqual } from "node:crypto";
import { environment } from "../config.ts";

/**
 * The WhatsApp transport: Evolution API, self-hosted beside this bot.
 *
 * This is the ONLY file that knows what a JID is, what an endpoint is called, or
 * what a webhook body looks like. Everything else in the template deals in bare
 * phone numbers, strings and Buffers. That boundary is the point: Evolution is
 * an unofficial bridge, and the day a copy of this bot has to move to Meta's
 * Cloud API — a ban, a client who needs the official one, a volume that justifies
 * the cost — the agent, the scheduler and the audio pipeline must not know.
 * Don't let `@s.whatsapp.net` leak upward.
 *
 * The bridge runs as its own container and publishes no host port. It holds a
 * long-lived socket and a paired session on disk, which is exactly the state a
 * process you redeploy is the wrong place for — and an Evolution instance
 * reachable from the internet is a WhatsApp account anyone can send from.
 */

export class EvolutionError extends Error {
  // Not a constructor parameter property: Node's type stripping rejects those
  // outright while a bundler accepts them, so the shorthand would run in a build
  // and fail under `node --test`.
  readonly status?: number;

  constructor(message: string, status?: number) {
    super(message);
    this.status = status;
  }
}

/** Past any healthy send, short of the proxy timeouts around it. */
const TIMEOUT_MS = 20_000;
/** Media can be a two-minute voice note over a bad connection. */
const MEDIA_TIMEOUT_MS = 60_000;

function server(): { baseUrl: string; apiKey: string; instance: string } {
  const config = environment.evolution();
  if (!config) {
    throw new EvolutionError(
      "WhatsApp não está configurado (EVOLUTION_API_URL, EVOLUTION_API_KEY, EVOLUTION_INSTANCE).",
    );
  }
  return config;
}

export function whatsappConfigured(): boolean {
  return environment.evolution() !== null;
}

async function call<T>(
  path: string,
  init: RequestInit,
  timeout = TIMEOUT_MS,
): Promise<T> {
  const { baseUrl, apiKey } = server();
  const response = await fetch(`${baseUrl}${path}`, {
    ...init,
    headers: {
      "content-type": "application/json",
      apikey: apiKey,
      ...(init.headers ?? {}),
    },
    signal: AbortSignal.timeout(timeout),
  });

  if (!response.ok) {
    // The body carries Evolution's own reason ("instance not connected", a
    // number that is not on WhatsApp), which is the only useful half of the
    // failure — a bare status tells an operator nothing about which it was.
    // Capped, or an HTML error page from a proxy is stored whole.
    const detail = (await response.text().catch(() => "")).slice(0, 400);
    throw new EvolutionError(
      `Evolution respondeu ${response.status}${detail ? `: ${detail}` : ""}`,
      response.status,
    );
  }
  return (await response.json()) as T;
}

/* -------------------------------------------------------------------------- */
/* Identity                                                                    */
/* -------------------------------------------------------------------------- */

/**
 * A WhatsApp JID reduced to the bare digits everything else keys on.
 *
 * Null for anything that is not one person's number: groups (`@g.us`), status
 * broadcasts and newsletters. The bot must never answer a group — it would reply
 * to every message in it, in public, on behalf of the business.
 *
 * The `:12` in `5531999998888:12@s.whatsapp.net` is WhatsApp's multi-device
 * marker and is not part of the number; leaving it on produces a second
 * conversation row for the same person every time they change handset.
 */
export function jidToPhone(jid: string | null | undefined): string | null {
  if (!jid) return null;
  if (!jid.endsWith("@s.whatsapp.net") && !jid.endsWith("@c.us")) return null;
  const user = jid.split("@")[0]?.split(":")[0] ?? "";
  const digits = user.replace(/\D/g, "");
  return digits.length >= 8 ? digits : null;
}

/**
 * The shared secret the webhook is checked against.
 *
 * Separate from the API key on purpose: that one authenticates us *to* the
 * bridge, this authenticates the bridge *to us*. One value for both directions
 * means compromising the bridge also hands over the ability to post fabricated
 * customer messages into this bot.
 */
export function webhookTokenValid(presented: string | null): boolean {
  const expected = environment.webhookSecret();
  // No secret configured means no webhook is accepted. The opposite default
  // turns a forgotten variable into an open endpoint that makes the bot talk to
  // strangers on the client's number.
  if (!expected || !presented) return false;
  const a = Buffer.from(presented);
  const b = Buffer.from(expected);
  // Length is compared first and leaks, which is fine: the signal worth closing
  // is the per-byte one that lets a token be guessed a character at a time.
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

/* -------------------------------------------------------------------------- */
/* Sending                                                                     */
/* -------------------------------------------------------------------------- */

export type SendResult = {
  /** The provider's id, stored so the webhook recognises our own echo. */
  providerId: string | null;
};

/**
 * Shows "digitando…" or "gravando áudio…" on the other phone.
 *
 * Separate from the send, and that is what makes the pacing in `humanize.ts`
 * possible: the presence goes up, we wait however long a person would have
 * taken, and only then does the message go. Evolution's own `delay` field can
 * only ever produce one fixed pause per message.
 *
 * Best-effort by design — never throws. A bridge version that does not
 * implement presence must not cost the customer their answer.
 */
export async function sendPresence(
  phone: string,
  presence: "composing" | "recording" | "paused",
  durationMs: number,
): Promise<void> {
  const { instance } = server();
  try {
    await call(`/chat/sendPresence/${encodeURIComponent(instance)}`, {
      method: "POST",
      body: JSON.stringify({
        number: phone,
        // Evolution keeps the presence up for this long on its side, so it does
        // not blink out halfway through a pause we are timing here.
        delay: Math.min(Math.round(durationMs), 30_000),
        presence,
      }),
    });
  } catch {
    // Deliberately swallowed. See above.
  }
}

/**
 * Marks the customer's message as read — the two blue ticks.
 *
 * Also best-effort, and also part of looking human: a bot that answers without
 * ever having "read" anything leaves a thread where every incoming message
 * stays on one tick while replies keep arriving, which people do notice.
 */
export async function markAsRead(
  phone: string,
  providerId: string,
): Promise<void> {
  const { instance } = server();
  try {
    await call(`/chat/markMessageAsRead/${encodeURIComponent(instance)}`, {
      method: "POST",
      body: JSON.stringify({
        readMessages: [
          { remoteJid: `${phone}@s.whatsapp.net`, fromMe: false, id: providerId },
        ],
      }),
    });
  } catch {
    // See above.
  }
}

/** Sends a text message. Throws on anything but success. */
export async function sendText(input: {
  phone: string;
  text: string;
}): Promise<SendResult> {
  const { instance } = server();
  const body = await call<{ key?: { id?: string } }>(
    `/message/sendText/${encodeURIComponent(instance)}`,
    {
      method: "POST",
      body: JSON.stringify({ number: input.phone, text: input.text }),
    },
  );
  return { providerId: body.key?.id ?? null };
}

/**
 * Sends a voice note — the round one with a waveform, not a file attachment.
 *
 * The distinction is the whole feature. `sendWhatsAppAudio` produces a push-to-
 * talk message that plays inline; sending the same bytes through the document or
 * media endpoint produces an attachment the person has to download and open in a
 * player, which reads as a robot mailing them a file. It requires Opus in an Ogg
 * container, which is what `audio/tts.ts` converts to.
 */
export async function sendAudio(input: {
  phone: string;
  /** Ogg/Opus, as produced by `audio/tts.ts`. */
  audio: Buffer;
}): Promise<SendResult> {
  const { instance } = server();
  const body = await call<{ key?: { id?: string } }>(
    `/message/sendWhatsAppAudio/${encodeURIComponent(instance)}`,
    {
      method: "POST",
      body: JSON.stringify({
        number: input.phone,
        audio: input.audio.toString("base64"),
        // Already Opus. Letting the bridge re-encode costs a second and a
        // generation of quality for nothing.
        encoding: false,
      }),
    },
    MEDIA_TIMEOUT_MS,
  );
  return { providerId: body.key?.id ?? null };
}

/**
 * Pulls the bytes of a media message back out of the bridge.
 *
 * WhatsApp media is encrypted on Meta's CDN and the keys are in the message the
 * bridge already holds, so this cannot be a plain download of `url` — that
 * returns ciphertext. Evolution decrypts it and hands back base64, which is why
 * this endpoint exists at all and why the whole raw message has to be passed
 * back to it rather than just an id.
 */
export async function downloadMedia(rawMessage: unknown): Promise<Buffer> {
  const { instance } = server();
  const body = await call<{ base64?: string }>(
    `/chat/getBase64FromMediaMessage/${encodeURIComponent(instance)}`,
    {
      method: "POST",
      body: JSON.stringify({
        message: rawMessage,
        // We want the original Opus. Asking for mp4 makes the bridge shell out
        // to ffmpeg for a file we are about to send to a transcriber that reads
        // Opus perfectly well.
        convertToMp4: false,
      }),
    },
    MEDIA_TIMEOUT_MS,
  );

  if (!body.base64) {
    throw new EvolutionError("A ponte não devolveu o áudio da mensagem.");
  }
  return Buffer.from(body.base64, "base64");
}

/* -------------------------------------------------------------------------- */
/* Receiving                                                                   */
/* -------------------------------------------------------------------------- */

export type InboundMedia = {
  kind: "audio" | "image" | "video" | "document";
  mimetype: string | null;
  /** The sender's own filename, on a document. Decides how it is read. */
  filename: string | null;
  /** Seconds, on audio and video. */
  seconds: number | null;
  /**
   * The whole message object, because `downloadMedia` needs it to decrypt —
   * WhatsApp media on the CDN is ciphertext and the keys live in here.
   */
  raw: unknown;
};

export type InboundMessage = {
  phone: string;
  /** The contact's WhatsApp display name, when they have one set. */
  pushName: string | null;
  /**
   * The typed words. On a media message this is the caption, which is usually
   * the actual question — "esse aqui tá certo?" against a photograph of a form
   * is a message whose meaning is entirely in the caption.
   */
  text: string;
  kind: "text" | "audio" | "image" | "video" | "document" | "other";
  providerId: string | null;
  /** Present when a file came with the message. */
  media: InboundMedia | null;
};

/**
 * Pulls an inbound message out of a webhook body, or null.
 *
 * Null covers a great deal: delivery receipts, our own outbound echo (`fromMe`),
 * group traffic, reactions, and media we cannot do anything with. All of them
 * are ordinary events on a live number rather than errors, so the route answers
 * 200 to each and does nothing — the alternative is a bridge that retries
 * forever because we called a photo a failure.
 *
 * Deliberately defensive about shape. Evolution's payload has changed between
 * minor versions more than once, and a thrown TypeError inside a webhook is a
 * retry loop you find out about from the customer rather than from the logs.
 */
export function parseInbound(payload: unknown): InboundMessage | null {
  if (!payload || typeof payload !== "object") return null;
  const body = payload as Record<string, unknown>;

  const event = typeof body.event === "string" ? body.event : "";
  // Written dotted or underscored depending on the version and on whether
  // webhook-by-events is on.
  if (event.replace(/_/g, ".") !== "messages.upsert") return null;

  const data = body.data as Record<string, unknown> | undefined;
  if (!data || typeof data !== "object") return null;

  const key = data.key as Record<string, unknown> | undefined;
  if (!key) return null;
  if (key.fromMe === true) return null;

  const phone = jidToPhone(
    typeof key.remoteJid === "string" ? key.remoteJid : null,
  );
  if (!phone) return null;

  const message = data.message as Record<string, unknown> | undefined;
  const pushName =
    typeof data.pushName === "string" && data.pushName.trim()
      ? data.pushName.trim().slice(0, 120)
      : null;
  const providerId = typeof key.id === "string" ? key.id : null;

  // The caption is read either way: on a media message it is the question, and
  // on a plain one it is the whole message.
  const text = messageText(message) ?? "";

  const media = mediaOf(message);
  if (media) {
    return {
      phone,
      pushName,
      text,
      kind: media.kind,
      providerId,
      // The bridge decrypts from the whole `data` object, key included.
      media: { ...media, raw: data },
    };
  }

  if (!text) return null;
  return { phone, pushName, text, kind: "text", providerId, media: null };
}

/**
 * The file attached to a message, if there is one.
 *
 * Order matters. A `documentMessage` can carry an image mimetype — that is what
 * "send as file" produces, and it is how people send a scan they do not want
 * WhatsApp to recompress — so the document branch has to come first and pass the
 * mimetype along rather than the branch order deciding how the file is read.
 * `src/media/understand.ts` routes on mimetype and filename, which is the only
 * place that decision belongs.
 *
 * Stickers are deliberately excluded. They are reactions, not content, and
 * describing one with a vision model is a paid API call to be told somebody sent
 * a cartoon.
 */
function mediaOf(
  message: Record<string, unknown> | undefined,
):
  | {
      kind: "audio" | "image" | "video" | "document";
      mimetype: string | null;
      filename: string | null;
      seconds: number | null;
    }
  | null {
  if (!message) return null;

  const document = message.documentMessage as Record<string, unknown> | undefined;
  // `documentWithCaptionMessage` wraps a document that was sent with text; the
  // real document sits one level down.
  const wrapped = (
    (message.documentWithCaptionMessage as Record<string, unknown> | undefined)
      ?.message as Record<string, unknown> | undefined
  )?.documentMessage as Record<string, unknown> | undefined;

  const doc = document ?? wrapped;
  if (doc) {
    return {
      kind: "document",
      mimetype: str(doc.mimetype),
      filename: str(doc.fileName) ?? str(doc.title),
      seconds: null,
    };
  }

  const audio = message.audioMessage as Record<string, unknown> | undefined;
  if (audio) {
    return {
      kind: "audio",
      mimetype: str(audio.mimetype),
      filename: null,
      seconds: num(audio.seconds),
    };
  }

  const image = message.imageMessage as Record<string, unknown> | undefined;
  if (image) {
    return {
      kind: "image",
      mimetype: str(image.mimetype) ?? "image/jpeg",
      filename: null,
      seconds: null,
    };
  }

  const video = message.videoMessage as Record<string, unknown> | undefined;
  if (video) {
    return {
      kind: "video",
      mimetype: str(video.mimetype),
      filename: null,
      seconds: num(video.seconds),
    };
  }

  return null;
}

function str(value: unknown): string | null {
  return typeof value === "string" && value.trim() ? value.trim().slice(0, 300) : null;
}

function num(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value)
    ? Math.round(value)
    : null;
}

/**
 * The readable text of a message, across the shapes WhatsApp uses.
 *
 * A plain message is `conversation`; one with a link preview or a reply becomes
 * `extendedTextMessage`; a photo with a caption carries the words in
 * `imageMessage.caption`. Reading only the first makes the bot ignore every
 * message sent as a reply to another, which in practice is most of a real
 * conversation.
 */
function messageText(message: unknown): string | null {
  if (!message || typeof message !== "object") return null;
  const m = message as Record<string, unknown>;

  const candidates = [
    m.conversation,
    (m.extendedTextMessage as Record<string, unknown> | undefined)?.text,
    (m.imageMessage as Record<string, unknown> | undefined)?.caption,
    (m.videoMessage as Record<string, unknown> | undefined)?.caption,
    (m.documentMessage as Record<string, unknown> | undefined)?.caption,
    (m.buttonsResponseMessage as Record<string, unknown> | undefined)
      ?.selectedDisplayText,
    (m.listResponseMessage as Record<string, unknown> | undefined)?.title,
  ];

  for (const candidate of candidates) {
    if (typeof candidate === "string" && candidate.trim()) {
      // WhatsApp accepts 65.536 characters. Nothing downstream benefits from
      // more than a couple of thousand, and the prompt is billed by the token.
      return candidate.trim().slice(0, 4000);
    }
  }
  return null;
}

/* -------------------------------------------------------------------------- */
/* Pairing                                                                     */
/* -------------------------------------------------------------------------- */

export type PairingState = {
  /** Evolution's own word: "open" is paired and online. */
  state: "open" | "connecting" | "close" | "unknown";
  /** A data: URI for the QR code, while one is being offered. */
  qr: string | null;
  pairingCode: string | null;
};

/**
 * Creates the instance if it is not already there.
 *
 * Evolution answers 403 for a name that exists, which is not an error here: the
 * operator running pair again on a half-finished pairing means "carry on", not
 * "start over". Anything else is re-thrown — a bridge that is down must not read
 * as a successful create followed by a QR that never appears.
 */
export async function ensureInstance(): Promise<void> {
  const { instance } = server();
  try {
    await call("/instance/create", {
      method: "POST",
      body: JSON.stringify({
        instanceName: instance,
        qrcode: true,
        integration: "WHATSAPP-BAILEYS",
      }),
    });
  } catch (error) {
    const already =
      error instanceof EvolutionError &&
      (error.status === 403 ||
        /already in use|already exists/i.test(error.message));
    if (!already) throw error;
  }
}

/**
 * Points the instance at our webhook.
 *
 * Done on every pair rather than only on create, because the URL changes
 * whenever this bot moves host and a stale one is the invisible failure of the
 * whole feature: the number pairs, the screen says connected, and not one
 * message ever arrives.
 */
export async function setWebhook(url: string): Promise<void> {
  const { instance } = server();
  const secret = environment.webhookSecret();
  if (!secret) {
    // Refused rather than configured without one: the webhook rejects every
    // request when the secret is unset, so this would pair a number whose
    // messages can never be accepted.
    throw new EvolutionError(
      "EVOLUTION_WEBHOOK_SECRET não está definido — o webhook recusaria tudo.",
    );
  }
  await call(`/webhook/set/${encodeURIComponent(instance)}`, {
    method: "POST",
    body: JSON.stringify({
      webhook: {
        enabled: true,
        url,
        headers: { "x-webhook-token": secret },
        // Everything else is parsed and dropped by `parseInbound`, so
        // subscribing to it is bandwidth and log noise.
        events: ["MESSAGES_UPSERT"],
      },
    }),
  });
}

/** Asks for the QR code, or reports that the number is already paired. */
export async function connect(): Promise<PairingState> {
  const { instance } = server();
  const state = await connectionState();
  if (state === "open") return { state, qr: null, pairingCode: null };

  const body = await call<{
    base64?: string;
    code?: string;
    pairingCode?: string;
  }>(`/instance/connect/${encodeURIComponent(instance)}`, { method: "GET" });

  const raw = typeof body.base64 === "string" ? body.base64 : null;
  // Returned as bare base64 on some versions and as a data: URI on others. An
  // <img> with a bare base64 src renders as a broken image and reads as a
  // pairing failure to whoever is holding the phone.
  const qr = raw
    ? raw.startsWith("data:")
      ? raw
      : `data:image/png;base64,${raw}`
    : null;

  return {
    state: qr ? "connecting" : state,
    qr,
    pairingCode: typeof body.pairingCode === "string" ? body.pairingCode : null,
  };
}

export async function connectionState(): Promise<PairingState["state"]> {
  const { instance } = server();
  try {
    const body = await call<{ instance?: { state?: string } }>(
      `/instance/connectionState/${encodeURIComponent(instance)}`,
      { method: "GET" },
    );
    const state = body.instance?.state;
    return state === "open" || state === "connecting" || state === "close"
      ? state
      : "unknown";
  } catch {
    // An instance nobody has created answers 404, which is a normal state for a
    // fresh deployment rather than something to report as an error.
    return "unknown";
  }
}

/**
 * Unpairs and removes the instance.
 *
 * Logout first, then delete: deleting a connected instance leaves the session on
 * the phone's linked-devices list, so the owner sees a device they cannot remove
 * from our side. Both are best-effort.
 */
export async function disconnect(): Promise<void> {
  const { instance } = server();
  for (const path of [
    `/instance/logout/${encodeURIComponent(instance)}`,
    `/instance/delete/${encodeURIComponent(instance)}`,
  ]) {
    try {
      await call(path, { method: "DELETE" });
    } catch {
      // Deliberately swallowed. See above.
    }
  }
}
