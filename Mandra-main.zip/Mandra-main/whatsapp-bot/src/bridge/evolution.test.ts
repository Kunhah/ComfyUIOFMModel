import test from "node:test";
import assert from "node:assert/strict";

import { jidToPhone, parseInbound, webhookTokenValid } from "./evolution.ts";

/**
 * What the bridge sends us, and what must never get past this file.
 *
 * Every case here is an ordinary event on a live number. The point of the tests
 * is that they are all *silently* dropped: a group message that reached the
 * agent would be answered in public on behalf of the business, and our own echo
 * would have the bot reply to itself forever.
 */

function upsert(message: unknown, key: Record<string, unknown> = {}): unknown {
  return {
    event: "messages.upsert",
    instance: "clinica",
    data: {
      key: { remoteJid: "5531999998888@s.whatsapp.net", id: "M1", ...key },
      pushName: "Ana",
      message,
    },
  };
}

test("strips the multi-device suffix from a JID", () => {
  // Leaving `:12` on produces a second conversation row for the same person
  // every time they change handset.
  assert.equal(jidToPhone("5531999998888:12@s.whatsapp.net"), "5531999998888");
  assert.equal(jidToPhone("5531999998888@c.us"), "5531999998888");
});

test("refuses anything that is not one person's number", () => {
  // A group answered by the bot is a reply to every message in it, in public.
  assert.equal(jidToPhone("120363000000000000@g.us"), null);
  assert.equal(jidToPhone("status@broadcast"), null);
  assert.equal(jidToPhone(null), null);
});

test("reads a plain message", () => {
  const inbound = parseInbound(upsert({ conversation: "oi, tudo bem?" }));
  assert.equal(inbound?.text, "oi, tudo bem?");
  assert.equal(inbound?.kind, "text");
  assert.equal(inbound?.pushName, "Ana");
  assert.equal(inbound?.providerId, "M1");
});

test("reads a reply and a captioned photo, not only `conversation`", () => {
  // Reading only the first shape makes the bot ignore every message sent as a
  // reply to another, which in practice is most of a real conversation.
  assert.equal(
    parseInbound(upsert({ extendedTextMessage: { text: "pode ser quinta" } }))
      ?.text,
    "pode ser quinta",
  );
  assert.equal(
    parseInbound(upsert({ imageMessage: { caption: "é esse aqui" } }))?.text,
    "é esse aqui",
  );
});

test("reads a voice note as audio, with the caption empty and the raw kept", () => {
  const inbound = parseInbound(
    upsert({ audioMessage: { seconds: 12, mimetype: "audio/ogg; codecs=opus", ptt: true } }),
  );
  assert.equal(inbound?.kind, "audio");
  assert.equal(inbound?.text, "");
  assert.equal(inbound?.media?.seconds, 12);
  // The whole message object, because the bridge needs it to decrypt: WhatsApp
  // media on the CDN is ciphertext and the keys are in here.
  assert.ok(inbound?.media?.raw);
});

test("reads an image, keeping the caption as the question", () => {
  // "esse aqui tá certo?" against a photograph of a form is a message whose
  // entire meaning is in the caption.
  const inbound = parseInbound(
    upsert({
      imageMessage: { mimetype: "image/jpeg", caption: "esse aqui tá certo?" },
    }),
  );
  assert.equal(inbound?.kind, "image");
  assert.equal(inbound?.text, "esse aqui tá certo?");
  assert.equal(inbound?.media?.mimetype, "image/jpeg");
});

test("reads an image with no caption at all", () => {
  // Before media support this returned null and the photo was silently ignored.
  const inbound = parseInbound(upsert({ imageMessage: { mimetype: "image/jpeg" } }));
  assert.equal(inbound?.kind, "image");
  assert.equal(inbound?.text, "");
});

test("reads a document, keeping the filename", () => {
  const inbound = parseInbound(
    upsert({
      documentMessage: {
        mimetype: "application/pdf",
        fileName: "contrato assinado.pdf",
      },
    }),
  );
  assert.equal(inbound?.kind, "document");
  assert.equal(inbound?.media?.filename, "contrato assinado.pdf");
});

test("unwraps a document sent with a caption", () => {
  // `documentWithCaptionMessage` nests the real document one level down; missing
  // that makes every commented attachment invisible.
  const inbound = parseInbound(
    upsert({
      documentWithCaptionMessage: {
        message: {
          documentMessage: {
            mimetype: "application/pdf",
            fileName: "exame.pdf",
            caption: "chegou o resultado",
          },
        },
      },
    }),
  );
  assert.equal(inbound?.kind, "document");
  assert.equal(inbound?.media?.filename, "exame.pdf");
});

test("a document wins over its own image mimetype", () => {
  // "Send as file" produces a documentMessage carrying image/jpeg. The mimetype
  // is passed through so the router — not the branch order here — decides that
  // this one goes to the vision model.
  const inbound = parseInbound(
    upsert({
      documentMessage: { mimetype: "image/jpeg", fileName: "scan.jpg" },
    }),
  );
  assert.equal(inbound?.kind, "document");
  assert.equal(inbound?.media?.mimetype, "image/jpeg");
});

test("reads a video", () => {
  const inbound = parseInbound(
    upsert({ videoMessage: { mimetype: "video/mp4", seconds: 31 } }),
  );
  assert.equal(inbound?.kind, "video");
  assert.equal(inbound?.media?.seconds, 31);
});

test("ignores a sticker", () => {
  // A reaction, not content. Describing one with a vision model is a paid call
  // to be told somebody sent a cartoon.
  assert.equal(
    parseInbound(upsert({ stickerMessage: { mimetype: "image/webp" } })),
    null,
  );
});

test("drops our own echo", () => {
  // Without this the bot answers its own messages, forever.
  assert.equal(
    parseInbound(upsert({ conversation: "oi" }, { fromMe: true })),
    null,
  );
});

test("drops group traffic", () => {
  assert.equal(
    parseInbound(
      upsert({ conversation: "oi" }, { remoteJid: "1203630000@g.us" }),
    ),
    null,
  );
});

test("drops receipts, reactions and anything with neither words nor a file", () => {
  assert.equal(parseInbound({ event: "messages.update", data: {} }), null);
  assert.equal(parseInbound(upsert({ reactionMessage: { text: "👍" } })), null);
  assert.equal(parseInbound(upsert({})), null);
  assert.equal(parseInbound(null), null);
  assert.equal(parseInbound("nem json"), null);
});

test("accepts the event name written either way", () => {
  // Dotted or underscored depending on the version and on whether
  // webhook-by-events is on.
  const underscored = {
    event: "messages_upsert",
    instance: "clinica",
    data: {
      key: { remoteJid: "5531999998888@s.whatsapp.net", id: "M2" },
      message: { conversation: "oi" },
    },
  };
  assert.equal(parseInbound(underscored)?.text, "oi");
});

test("no configured secret means no webhook is accepted", () => {
  // The opposite default turns a forgotten variable into an open endpoint that
  // makes the bot talk to strangers on the client's number.
  delete process.env.EVOLUTION_WEBHOOK_SECRET;
  assert.equal(webhookTokenValid("qualquer-coisa"), false);
  assert.equal(webhookTokenValid(null), false);

  process.env.EVOLUTION_WEBHOOK_SECRET = "um-segredo-longo";
  assert.equal(webhookTokenValid("um-segredo-longo"), true);
  assert.equal(webhookTokenValid("um-segredo-curto"), false);
  assert.equal(webhookTokenValid("tamanho-diferente"), false);
  delete process.env.EVOLUTION_WEBHOOK_SECRET;
});
