import test from "node:test";
import assert from "node:assert/strict";

import {
  businessHours,
  readDelay,
  shouldSpeak,
  speakable,
  splitBubbles,
  typingDelay,
} from "./humanize.ts";
import type { HumanConfig, VoiceConfig } from "./config.ts";

/**
 * The pacing rules, pinned where getting them wrong is visible to a customer.
 *
 * The random parts are asserted as ranges rather than values — the jitter is the
 * feature, so a test that demanded an exact number would be testing that the
 * feature is absent.
 */

const human: HumanConfig = {
  debounceMs: 4000,
  readDelayMs: [900, 2600],
  typingCps: 13,
  typingMs: [1200, 9000],
  splitBubbles: true,
  maxBubbles: 3,
  jitter: 0.25,
};

const voice: VoiceConfig = {
  reply: "espelho",
  voiceId: "v1",
  maxChars: 420,
};

test("typing time scales with length but never goes instant", () => {
  // An instant reply is the tell. The floor matters more than the ceiling.
  for (let i = 0; i < 40; i += 1) {
    assert.ok(typingDelay("ok", human) >= 1200 * 0.75);
    assert.ok(typingDelay("x".repeat(10_000), human) <= 9000 * 1.25);
  }
  const short = typingDelay("oi", human);
  const long = typingDelay("x".repeat(400), human);
  assert.ok(long > short);
});

test("the read pause varies rather than repeating", () => {
  const samples = new Set(
    Array.from({ length: 30 }, () => readDelay(human)),
  );
  // Identical pauses every time are as machine-like as no pause at all.
  assert.ok(samples.size > 5);
});

test("leaves a short reply as one bubble", () => {
  assert.deepEqual(splitBubbles("Claro! Que horas?", human), [
    "Claro! Que horas?",
  ]);
});

test("splits a long reply at sentence ends, keeping the punctuation", () => {
  const text =
    "Oi, tudo bem? Temos horário na quinta de manhã. " +
    "Também tem vaga na sexta à tarde. Qual fica melhor para você?";
  const bubbles = splitBubbles(text, human);
  assert.ok(bubbles.length > 1);
  assert.ok(bubbles.length <= human.maxBubbles);
  // Nothing lost and nothing invented.
  assert.equal(bubbles.join(" "), text.trim());
  assert.match(bubbles.at(-1) ?? "", /\?$/);
});

test("never splits a reply carrying a link or a long number", () => {
  // Half an address in one bubble is worse than a slightly long message.
  const withLink =
    "Segue o link do formulário para você preencher antes da consulta, " +
    "leva dois minutos. https://exemplo.com/form";
  assert.equal(splitBubbles(withLink, human).length, 1);

  const withNumber =
    "Nosso telefone fixo é 3132251100 e funciona das oito às seis. " +
    "Pode ligar quando quiser, viu? Estamos por aqui.";
  assert.equal(splitBubbles(withNumber, human).length, 1);
});

test("mirror mode answers audio with audio and text with text", () => {
  const base = { voice, text: "Claro, pode ser quinta!", voiceReady: true };
  assert.equal(shouldSpeak({ ...base, inboundKind: "audio" }), true);
  assert.equal(shouldSpeak({ ...base, inboundKind: "text" }), false);
});

test("never speaks when the voice is not actually available", () => {
  assert.equal(
    shouldSpeak({
      voice: { ...voice, reply: "sempre" },
      inboundKind: "audio",
      text: "oi",
      voiceReady: false,
    }),
    false,
  );
});

test("refuses to speak anything the person has to read back", () => {
  // True even in `sempre`: a phone number in a voice note is a number they have
  // to write down while listening.
  const always: VoiceConfig = { ...voice, reply: "sempre" };
  for (const text of [
    "O link é https://exemplo.com/agenda",
    "Manda pro contato@clinica.com.br",
    "Nosso telefone é 3132251100",
  ]) {
    assert.equal(
      shouldSpeak({ voice: always, inboundKind: "audio", text, voiceReady: true }),
      false,
      text,
    );
  }
});

test("refuses to speak a reply that is too long to listen to", () => {
  assert.equal(
    shouldSpeak({
      voice,
      inboundKind: "audio",
      text: "a".repeat(500),
      voiceReady: true,
    }),
    false,
  );
});

test("strips what a voice would mangle", () => {
  const spoken = speakable(
    "Claro! 🙂 *Quinta* às 14h — segue https://exemplo.com/x",
  );
  assert.doesNotMatch(spoken, /🙂|\*|https?:\/\//);
  assert.match(spoken, /Quinta/);
  assert.match(spoken, /o link que te mandei/);
});

test("opening hours are read in the business's timezone, not the container's", () => {
  const hours = {
    timezone: "America/Sao_Paulo",
    // Sunday closed; weekdays 08-19; Saturday 08-12.
    week: [
      null,
      [8, 19],
      [8, 19],
      [8, 19],
      [8, 19],
      [8, 19],
      [8, 12],
    ] as Array<[number, number] | null>,
    outside: "avisar" as const,
    notice: "fechado",
  };

  // 2026-09-08 is a Tuesday. 11:00Z is 08:00 in São Paulo — open — while the
  // same instant read as UTC would be 11:00 and also open, so the telling case
  // is the one below.
  assert.equal(businessHours(hours, new Date("2026-09-08T11:00:00Z")).open, true);

  // 10:00Z is 07:00 local: closed. Read as UTC it would be 10:00 and "open",
  // which is the bug this exists to prevent — three hours of every working day.
  assert.equal(businessHours(hours, new Date("2026-09-08T10:00:00Z")).open, false);

  // Sunday, midday local.
  assert.equal(businessHours(hours, new Date("2026-09-06T15:00:00Z")).open, false);
});

test("no hours configured means always open", () => {
  assert.equal(businessHours(undefined).open, true);
});
