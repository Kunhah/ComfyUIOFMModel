import test from "node:test";
import assert from "node:assert/strict";
import { createServer, type Server } from "node:http";
import { spawn, type ChildProcess } from "node:child_process";
import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * The whole thing, end to end, against stand-ins for the three services it
 * talks to.
 *
 * This is the test that would have caught every integration bug the unit tests
 * cannot see: a webhook that authenticates but never routes, a tool result that
 * never reaches the second round, a reply that is composed and never sent. It
 * runs the real `src/server.ts` as a child process — no mocking of our own code
 * — with a fake Evolution, a fake OpenAI-shaped model and a fake backend.
 *
 * It is slow on purpose. Most of the wall time is the human pacing doing its
 * job: the debounce window, then the reading pause, then typing. A version of
 * this test that ran instantly would be a version with the pacing disabled,
 * which is the part most likely to break.
 */

const here = path.dirname(fileURLToPath(import.meta.url));

type Sent = { path: string; body: Record<string, unknown> };

/** Stands in for Evolution. Records what the bot tried to send. */
function fakeBridge(sent: Sent[]): Promise<{ server: Server; port: number }> {
  const server = createServer((request, response) => {
    const chunks: Buffer[] = [];
    request.on("data", (c: Buffer) => chunks.push(c));
    request.on("end", () => {
      const raw = Buffer.concat(chunks).toString("utf8");
      const body = raw ? (JSON.parse(raw) as Record<string, unknown>) : {};
      sent.push({ path: request.url ?? "", body });
      response.writeHead(200, { "content-type": "application/json" });
      response.end(JSON.stringify({ key: { id: `srv-${sent.length}` } }));
    });
  });
  return listen(server);
}

/**
 * Stands in for the model. Answers with a scripted queue of envelopes, so the
 * two-round tool flow can be exercised deterministically.
 */
function fakeModel(
  script: string[],
  seen: unknown[],
): Promise<{ server: Server; port: number }> {
  const server = createServer((request, response) => {
    const chunks: Buffer[] = [];
    request.on("data", (c: Buffer) => chunks.push(c));
    request.on("end", () => {
      seen.push(JSON.parse(Buffer.concat(chunks).toString("utf8")));
      const content = script.shift() ?? '{"mensagem":"ok","acoes":[]}';
      response.writeHead(200, { "content-type": "application/json" });
      response.end(
        JSON.stringify({ choices: [{ message: { content } }] }),
      );
    });
  });
  return listen(server);
}

/** Stands in for the customer's own backend. */
function fakeBackend(hits: string[]): Promise<{ server: Server; port: number }> {
  const server = createServer((request, response) => {
    hits.push(`${request.method} ${request.url}`);
    response.writeHead(200, { "content-type": "application/json" });
    response.end(JSON.stringify({ livres: ["09:00", "10:30"] }));
  });
  return listen(server);
}

async function listen(server: Server): Promise<{ server: Server; port: number }> {
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  return {
    server,
    port: typeof address === "object" && address ? address.port : 0,
  };
}

function close(server: Server): Promise<void> {
  return new Promise((resolve) => server.close(() => resolve()));
}

/** Polls /health until the bot answers, rather than sleeping and hoping. */
async function waitForBoot(port: number): Promise<void> {
  for (let i = 0; i < 100; i += 1) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/health`);
      if (response.ok) return;
    } catch {
      // Not up yet.
    }
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error("o bot não subiu");
}

function inboundText(text: string, id: string): unknown {
  return {
    event: "messages.upsert",
    instance: "teste",
    data: {
      key: { remoteJid: "5531988887777@s.whatsapp.net", id },
      pushName: "Ana",
      message: { conversation: text },
    },
  };
}

test("uma conversa inteira: webhook, ferramenta, resposta", { timeout: 90_000 }, async () => {
  const sent: Sent[] = [];
  const modelSaw: unknown[] = [];
  const backendHits: string[] = [];

  const bridge = await fakeBridge(sent);
  const backend = await fakeBackend(backendHits);
  const model = await fakeModel(
    [
      // Round 1: the model reaches for the tool and says nothing yet.
      JSON.stringify({
        mensagem: "",
        acoes: [
          {
            tipo: "ferramenta",
            nome: "consultar_horarios",
            argumentos: { data: "2026-09-10", especialidade: "fisioterapia" },
          },
        ],
      }),
      // Round 2: with the result in hand, it answers.
      JSON.stringify({
        mensagem: "Tenho 9h e 10h30 na quinta. Qual fica melhor?",
        acoes: [],
      }),
    ],
    modelSaw,
  );

  const port = 8199;
  const dataDir = mkdtempSync(path.join(tmpdir(), "bot-e2e-"));

  // Its own config, rather than whichever example is checked in. The pacing is
  // shortened — the arithmetic is pinned in humanize.test.ts, and what this test
  // is proving is that the pieces are wired together — and no opening hours are
  // set, so the run does not depend on what day it happens to be.
  const configFile = path.join(dataDir, "e2e.config.ts");
  writeFileSync(
    configFile,
    `export default ${JSON.stringify(
      {
        name: "Clínica de Teste",
        timezone: "America/Sao_Paulo",
        language: "português do Brasil",
        persona: {
          identity: "Você é o assistente da Clínica de Teste.",
          role: "Atende e marca horário.",
          style: "Curto.",
        },
        tools: [
          {
            name: "consultar_horarios",
            description: "Lista horários livres.",
            parameters: {
              data: { type: "string", description: "AAAA-MM-DD", required: true },
              especialidade: {
                type: "enum",
                description: "tipo",
                values: ["fisioterapia", "pilates"],
                required: true,
              },
            },
            request: {
              method: "GET",
              path: "/agenda/disponibilidade",
              query: ["data", "especialidade"],
            },
          },
        ],
        media: {
          images: true,
          documents: true,
          video: true,
          maxBytes: 16 * 1024 * 1024,
          maxPdfPages: 8,
          maxChars: 12000,
        },
        voice: { reply: "espelho", voiceId: "v1", maxChars: 420 },
        human: {
          debounceMs: 300,
          readDelayMs: [50, 150],
          typingCps: 200,
          typingMs: [100, 400],
          splitBubbles: true,
          maxBubbles: 3,
          jitter: 0.2,
        },
        scheduling: {
          enabled: true,
          reminderOffsets: [1440, 120],
          defaultDurationMinutes: 50,
        },
        handoff: { message: "Vou chamar alguém do time." },
      },
      null,
      2,
    )};\n`,
  );

  const child: ChildProcess = spawn(
    process.execPath,
    [path.join(here, "server.ts")],
    {
      env: {
        ...process.env,
        PORT: String(port),
        BOT_DB: path.join(dataDir, "e2e.db"),
        BOT_CONFIG: configFile,
        EVOLUTION_API_URL: `http://127.0.0.1:${bridge.port}`,
        EVOLUTION_API_KEY: "chave-da-ponte",
        EVOLUTION_INSTANCE: "teste",
        EVOLUTION_WEBHOOK_SECRET: "segredo-do-webhook",
        // The chain's first link points at the fake; the others must be absent
        // or a failure here would silently fall through to a real provider.
        GROQ_API_KEY: "fake",
        GROQ_BASE_URL: `http://127.0.0.1:${model.port}`,
        OPENROUTER_API_KEY: "",
        OPENAI_API_KEY: "",
        BACKEND_URL: `http://127.0.0.1:${backend.port}`,
        BACKEND_TOKEN: "token-do-backend",
        ELEVENLABS_API_KEY: "",
        ADMIN_TOKEN: "token-de-operador",
      },
      stdio: ["ignore", "pipe", "pipe"],
    },
  );

  let stderr = "";
  child.stderr?.on("data", (c: Buffer) => (stderr += String(c)));

  try {
    await waitForBoot(port);

    const response = await fetch(`http://127.0.0.1:${port}/webhook`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-webhook-token": "segredo-do-webhook",
      },
      body: JSON.stringify(
        inboundText("oi, tem horário na quinta pra fisio?", "MSG-1"),
      ),
    });

    assert.equal(response.status, 200);
    const verdict = (await response.json()) as {
      handled: boolean;
      replied: boolean;
      tools: string[];
    };

    assert.equal(verdict.handled, true, stderr);
    assert.equal(verdict.replied, true, stderr);
    assert.deepEqual(verdict.tools, ["consultar_horarios"]);

    // The backend was really called, with the path template filled in.
    assert.equal(backendHits.length, 1);
    assert.match(
      backendHits[0] ?? "",
      /^GET \/agenda\/disponibilidade\?data=2026-09-10/,
    );

    // The customer's message was marked read, and the reply went out as text.
    const texts = sent.filter((item) => item.path.includes("/message/sendText/"));
    assert.ok(
      sent.some((item) => item.path.includes("/chat/markMessageAsRead/")),
      "não marcou como lida",
    );
    assert.ok(texts.length >= 1, "nada foi enviado");
    assert.match(
      texts.map((item) => String(item.body.text)).join(" "),
      /9h e 10h30/,
    );

    // Presence went up before the message — that is what makes the pause read
    // as someone typing rather than as a laggy bot.
    assert.ok(
      sent.some((item) => item.path.includes("/chat/sendPresence/")),
      "não mostrou digitando",
    );

    // The second round really did see the tool result: without it the model
    // would be answering from nothing, which is the failure this loop exists
    // to prevent.
    const secondCall = modelSaw[1] as { messages: { content: string }[] };
    assert.ok(
      secondCall.messages.some((message) =>
        message.content.includes("10:30"),
      ),
      "o resultado da ferramenta não voltou para o modelo",
    );

    // A replay of the same provider id is not answered twice.
    const replay = await fetch(`http://127.0.0.1:${port}/webhook`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-webhook-token": "segredo-do-webhook",
      },
      body: JSON.stringify(inboundText("oi, tem horário?", "MSG-1")),
    });
    assert.deepEqual(await replay.json(), {
      ok: true,
      handled: false,
      duplicate: true,
    });

    // A wrong token is refused before anything is read.
    const unauthorised = await fetch(`http://127.0.0.1:${port}/webhook`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-webhook-token": "errado",
      },
      body: JSON.stringify(inboundText("oi", "MSG-2")),
    });
    assert.equal(unauthorised.status, 401);

    // The operator API is behind its own token, not the bridge's.
    const forbidden = await fetch(
      `http://127.0.0.1:${port}/admin/conversations`,
      { headers: { authorization: "Bearer segredo-do-webhook" } },
    );
    assert.equal(forbidden.status, 401);

    const allowed = await fetch(
      `http://127.0.0.1:${port}/admin/conversations`,
      { headers: { authorization: "Bearer token-de-operador" } },
    );
    assert.equal(allowed.status, 200);
    const listed = (await allowed.json()) as {
      conversations: { phone: string }[];
    };
    assert.equal(listed.conversations[0]?.phone, "5531988887777");
  } finally {
    child.kill("SIGKILL");
    await close(bridge.server);
    await close(model.server);
    await close(backend.server);
  }
});
