import { spawn } from "node:child_process";
import { environment } from "../config.ts";
import type { VoiceConfig } from "../config.ts";

/**
 * Words in, a WhatsApp voice note out.
 *
 * Two steps, and the second is the one people miss. ElevenLabs produces the
 * audio; ffmpeg then re-wraps it as mono Ogg/Opus, which is the only thing
 * WhatsApp will play as a *voice note* — the round bubble with a waveform that
 * plays when you tap it. Hand the bridge an mp3 and it goes out as a file
 * attachment the person has to download and open, which is unmistakably a
 * machine mailing them something.
 *
 * ffmpeg is therefore a real requirement for voice replies, and its absence is
 * reported rather than worked around: a voice note that arrives as a download
 * link is worse than a text reply, so `available()` is checked before the bot
 * ever offers to speak.
 */

export class VoiceError extends Error {}

const TIMEOUT_MS = 45_000;

export function ttsConfigured(): boolean {
  return environment.tts() !== null;
}

/**
 * Whether ffmpeg answers. Cached: this is checked before every voice reply and
 * spawning a process to ask each time would add a fork to the hot path.
 */
let ffmpegOk: boolean | null = null;

export async function ffmpegAvailable(): Promise<boolean> {
  if (ffmpegOk !== null) return ffmpegOk;
  ffmpegOk = await new Promise<boolean>((resolve) => {
    try {
      const child = spawn(environment.ffmpeg(), ["-version"], {
        stdio: "ignore",
      });
      child.on("error", () => resolve(false));
      child.on("close", (code) => resolve(code === 0));
    } catch {
      resolve(false);
    }
  });
  return ffmpegOk;
}

/** Whether this copy can send voice at all, and why not when it cannot. */
export async function voiceReadiness(): Promise<{
  ready: boolean;
  elevenlabs: boolean;
  ffmpeg: boolean;
}> {
  const elevenlabs = ttsConfigured();
  const ffmpeg = await ffmpegAvailable();
  return { ready: elevenlabs && ffmpeg, elevenlabs, ffmpeg };
}

export type Speech = {
  /** Ogg/Opus, ready for `sendAudio`. */
  audio: Buffer;
  /** Seconds, as ffmpeg measured it — used to time the "gravando áudio…" pause. */
  durationSeconds: number;
};

/**
 * Speaks one reply.
 *
 * The text is spoken as written, which is why `humanize.ts` strips it first: a
 * URL read aloud character by character is forty seconds of nonsense, and an
 * emoji is either read out as its name or silently dropped depending on the
 * model's mood.
 */
export async function speak(
  text: string,
  voice: VoiceConfig,
): Promise<Speech> {
  const config = environment.tts();
  if (!config) {
    throw new VoiceError("ELEVENLABS_API_KEY não está definida.");
  }
  if (!(await ffmpegAvailable())) {
    throw new VoiceError(
      "ffmpeg não está instalado — sem ele o áudio não vira nota de voz do WhatsApp.",
    );
  }

  const spoken = text.trim();
  if (!spoken) throw new VoiceError("Nada para falar.");

  let response: Response;
  try {
    response = await fetch(
      `${config.url}/${encodeURIComponent(voice.voiceId)}?output_format=mp3_44100_128`,
      {
        method: "POST",
        headers: {
          "xi-api-key": config.key,
          "content-type": "application/json",
          accept: "audio/mpeg",
        },
        body: JSON.stringify({
          text: spoken,
          model_id: voice.modelId ?? "eleven_multilingual_v2",
          voice_settings: {
            stability: voice.stability ?? 0.45,
            similarity_boost: voice.similarityBoost ?? 0.75,
            speed: voice.speed ?? 1,
          },
        }),
        signal: AbortSignal.timeout(TIMEOUT_MS),
      },
    );
  } catch (error) {
    throw new VoiceError(
      `Não foi possível falar com o ElevenLabs: ${
        error instanceof Error ? error.message : String(error)
      }`,
    );
  }

  if (!response.ok) {
    const detail = (await response.text().catch(() => "")).slice(0, 300);
    throw new VoiceError(
      `ElevenLabs respondeu ${response.status}${detail ? `: ${detail}` : ""}`,
    );
  }

  const mp3 = Buffer.from(await response.arrayBuffer());
  return toVoiceNote(mp3);
}

/**
 * Re-encodes to what WhatsApp plays inline.
 *
 * Mono, 48 kHz, Opus in an Ogg container, at a bitrate chosen for speech. The
 * `-application voip` flag is not decoration: it tells the encoder the signal is
 * a single voice, which at these bitrates is audibly cleaner than the default
 * music tuning.
 *
 * Piped through stdin and stdout rather than temp files. The audio is somebody's
 * message and writing it to /tmp means a directory of customer conversations
 * with no retention policy on a host where nothing else writes enough to make
 * that obvious.
 */
export function toVoiceNote(input: Buffer): Promise<Speech> {
  return new Promise((resolve, reject) => {
    const child = spawn(
      environment.ffmpeg(),
      [
        "-hide_banner",
        "-loglevel",
        "error",
        "-i",
        "pipe:0",
        "-ac",
        "1",
        "-ar",
        "48000",
        "-c:a",
        "libopus",
        "-b:a",
        "32k",
        "-application",
        "voip",
        "-f",
        "ogg",
        "pipe:1",
      ],
      { stdio: ["pipe", "pipe", "pipe"] },
    );

    const chunks: Buffer[] = [];
    let stderr = "";

    child.stdout.on("data", (chunk: Buffer) => chunks.push(chunk));
    child.stderr.on("data", (chunk: Buffer) => {
      stderr = (stderr + String(chunk)).slice(-2000);
    });

    child.on("error", (error) => {
      reject(
        new VoiceError(
          error.message.includes("ENOENT")
            ? "ffmpeg não está instalado ou não está no PATH."
            : `ffmpeg: ${error.message}`,
        ),
      );
    });

    child.on("close", (code) => {
      if (code !== 0) {
        reject(new VoiceError(`ffmpeg terminou com código ${code}. ${stderr.trim()}`));
        return;
      }
      const audio = Buffer.concat(chunks);
      if (audio.byteLength === 0) {
        reject(new VoiceError("ffmpeg devolveu um áudio vazio."));
        return;
      }
      resolve({ audio, durationSeconds: oggDuration(audio) });
    });

    // EPIPE when ffmpeg has already rejected the input; the close handler above
    // reports the real reason, and an unhandled error event here would take the
    // process down with it.
    child.stdin.on("error", () => {});
    child.stdin.end(input);
  });
}

/**
 * Length of an Ogg stream, from its last page's granule position.
 *
 * Opus counts granules at a fixed 48 kHz regardless of the input rate, so the
 * final page's position divided by 48000 is the duration in seconds. Read here
 * rather than by running ffprobe: it is a second process spawn per voice note
 * for a number that is sitting in the last few bytes of a buffer we already hold.
 *
 * Zero when the pattern is not found, which the caller treats as "estimate it" —
 * this only ever times a typing pause.
 */
function oggDuration(ogg: Buffer): number {
  // Ogg pages start with "OggS"; the last one carries the total sample count.
  const last = ogg.lastIndexOf("OggS", ogg.length - 1, "latin1");
  if (last < 0 || last + 14 > ogg.length) return 0;
  const granule = ogg.readBigUInt64LE(last + 6);
  // Opus prepends ~80ms of pre-skip that is not audible playback time. At this
  // resolution it does not matter for a typing pause, so it is left in.
  return Number(granule) / 48000;
}
