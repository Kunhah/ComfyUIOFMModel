import { environment } from "../config.ts";

/**
 * Voice note in, words out.
 *
 * Groq's hosted whisper-large-v3-turbo, over the API, and that is a deliberate
 * trade rather than the easy option. A voice note is answered inside the same
 * webhook that received it, so the transcription sits directly in front of the
 * customer waiting for a reply: the API returns a 30-second note in about a
 * second, whereas whisper.cpp on the kind of CPU this container usually gets
 * takes tens of seconds. That gap is the difference between a bot that answers
 * a voice note and one that appears to have ignored it.
 *
 * What you are buying with that speed is that the customer's audio leaves your
 * server. Say so in your privacy policy. If that is not acceptable for the
 * business this copy serves — a clinic, a lawyer, anything where the recording
 * is privileged — swap this file for a local whisper.cpp call and move the turn
 * off the webhook onto a queue. Nothing else in the template changes; that is
 * what this file being one function is for.
 */

export class TranscriptionError extends Error {}

/** Longer than any voice note worth transcribing, shorter than the bridge's patience. */
const TIMEOUT_MS = 45_000;

/**
 * WhatsApp caps a voice note well below this; the guard is for a forwarded audio
 * file, which arrives on the same message type and can be an album.
 */
const MAX_BYTES = 20 * 1024 * 1024;

export function sttConfigured(): boolean {
  return environment.stt().key !== null;
}

export type Transcription = {
  text: string;
  /** What the provider thought it heard the language as, when it says. */
  language: string | null;
};

/**
 * Transcribes one voice note.
 *
 * The language is declared rather than detected. Auto-detection on a note that
 * opens with "alô" has come back as Spanish before, and every word after that is
 * wrong in a way that reads as a bad model rather than as a wrong flag.
 */
export async function transcribe(audio: Buffer): Promise<Transcription> {
  const { key, url, model, language } = environment.stt();
  if (!key) {
    throw new TranscriptionError(
      "GROQ_API_KEY não está definida — o bot não consegue ouvir áudio.",
    );
  }
  if (audio.byteLength === 0) {
    throw new TranscriptionError("O áudio chegou vazio.");
  }
  if (audio.byteLength > MAX_BYTES) {
    throw new TranscriptionError(
      `O áudio tem ${Math.round(audio.byteLength / 1024 / 1024)} MB e o limite é ${MAX_BYTES / 1024 / 1024} MB.`,
    );
  }

  const form = new FormData();
  // The filename is what the API reads the container from, and WhatsApp voice
  // notes are Ogg/Opus. Sending it as `.mp3` makes the decode fail on a file
  // that is perfectly fine.
  form.append("file", new Blob([new Uint8Array(audio)]), "audio.ogg");
  form.append("model", model);
  form.append("language", language);
  // Just the words. `verbose_json` buys timestamps that nothing here uses and a
  // payload several times the size.
  form.append("response_format", "json");
  // Nudges the transcriber towards the vocabulary of this business. Names of
  // services and the company come out mangled without it, and a mangled name is
  // what the agent then repeats back to the customer.
  const hint = process.env.STT_PROMPT?.trim();
  if (hint) form.append("prompt", hint.slice(0, 800));

  let response: Response;
  try {
    response = await fetch(url, {
      method: "POST",
      headers: { authorization: `Bearer ${key}` },
      body: form,
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
  } catch (error) {
    throw new TranscriptionError(
      `Não foi possível falar com a transcrição: ${
        error instanceof Error ? error.message : String(error)
      }`,
    );
  }

  if (!response.ok) {
    const detail = (await response.text().catch(() => "")).slice(0, 300);
    throw new TranscriptionError(
      `A transcrição respondeu ${response.status}${detail ? `: ${detail}` : ""}`,
    );
  }

  const body = (await response.json()) as { text?: string; language?: string };
  const text = typeof body.text === "string" ? body.text.trim() : "";

  // An empty transcription is a real outcome, not a failure: someone recorded
  // three seconds of traffic noise, or pressed the button by accident. The
  // caller turns it into the bot saying it could not hear — which is what a
  // person would say — rather than into an error the customer never sees.
  return {
    text: text.slice(0, 4000),
    language: typeof body.language === "string" ? body.language : null,
  };
}
