import test from "node:test";
import assert from "node:assert/strict";
import { createServer, type Server } from "node:http";
import { spawn, type ChildProcess } from "node:child_process";
import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * Files, end to end: an image and a PDF, through the real server.
 *
 * What this proves that the unit tests cannot: that the bridge's base64 reaches
 * the right reader, that a vision description and an extracted PDF both arrive
 * as the customer's turn in the shape the prompt tells the agent to expect, and
 * that the vision call really goes to the vision model rather than to the chat
 * one — which is the failure that does not error, it just answers about nothing.
 */

const here = path.dirname(fileURLToPath(import.meta.url));

type Sent = { path: string; body: Record<string, unknown> };

async function listen(server: Server): Promise<number> {
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  return typeof address === "object" && address ? address.port : 0;
}

function close(server: Server): Promise<void> {
  return new Promise((resolve) => server.close(() => resolve()));
}

async function waitForBoot(port: number): Promise<void> {
  for (let i = 0; i < 100; i += 1) {
    try {
      if ((await fetch("http://127.0.0.1:" + port + "/health")).ok) return;
    } catch {
      // Not up yet.
    }
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error("o bot nao subiu");
}

/** A one-page PDF with a real text layer. */
function makePdf(text: string): Buffer {
  const content = "BT /F1 18 Tf 72 720 Td (" + text + ") Tj ET";
  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R " +
      "/Resources << /Font << /F1 5 0 R >> >> >>",
    "<< /Length " + content.length + " >>\nstream\n" + content + "\nendstream",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
  ];
  let pdf = "%PDF-1.4\n";
  const offsets: number[] = [];
  objects.forEach((body, index) => {
    offsets.push(pdf.length);
    pdf += index + 1 + " 0 obj\n" + body + "\nendobj\n";
  });
  const xref = pdf.length;
  pdf += "xref\n0 " + (objects.length + 1) + "\n0000000000 65535 f \n";
  for (const offset of offsets) {
    pdf += String(offset).padStart(10, "0") + " 00000 n \n";
  }
  pdf +=
    "trailer\n<< /Size " + (objects.length + 1) +
    " /Root 1 0 R >>\nstartxref\n" + xref + "\n%%EOF\n";
  return Buffer.from(pdf, "latin1");
}

/** A tiny but valid PNG, for the image case. */
const PNG = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
  "base64",
);

test("imagem e PDF chegam ao agente como texto", { timeout: 90_000 }, async () => {
  const sent: Sent[] = [];
  let payload: Buffer = PNG;

  const bridge = createServer((request, response) => {
    const chunks: Buffer[] = [];
    request.on("data", (c: Buffer) => chunks.push(c));
    request.on("end", () => {
      const raw = Buffer.concat(chunks).toString("utf8");
      sent.push({
        path: request.url ?? "",
        body: raw ? (JSON.parse(raw) as Record<string, unknown>) : {},
      });
      response.writeHead(200, { "content-type": "application/json" });
      if ((request.url ?? "").includes("getBase64FromMediaMessage")) {
        response.end(JSON.stringify({ base64: payload.toString("base64") }));
        return;
      }
      response.end(JSON.stringify({ key: { id: "srv-" + sent.length } }));
    });
  });

  type ModelCall = {
    model: string;
    messages: { role: string; content: unknown }[];
  };
  const modelSaw: ModelCall[] = [];

  const model = createServer((request, response) => {
    const chunks: Buffer[] = [];
    request.on("data", (c: Buffer) => chunks.push(c));
    request.on("end", () => {
      const call = JSON.parse(
        Buffer.concat(chunks).toString("utf8"),
      ) as ModelCall;
      modelSaw.push(call);

      // The vision call is the one carrying an image part; it answers with a
      // description. Everything else is the agent and answers with an envelope.
      const isVision = call.messages.some(
        (message) =>
          Array.isArray(message.content) &&
          (message.content as { type: string }[]).some(
            (part) => part.type === "image_url",
          ),
      );

      response.writeHead(200, { "content-type": "application/json" });
      response.end(
        JSON.stringify({
          choices: [
            {
              message: {
                content: isVision
                  ? "Print de tela de um erro. Texto legivel: PAGAMENTO RECUSADO codigo 51."
                  : JSON.stringify({ mensagem: "Entendi, ja te ajudo!", acoes: [] }),
              },
            },
          ],
        }),
      );
    });
  });

  const [bridgePort, modelPort] = await Promise.all([
    listen(bridge),
    listen(model),
  ]);

  const dataDir = mkdtempSync(path.join(tmpdir(), "bot-e2e-media-"));
  const configFile = path.join(dataDir, "media.config.ts");
  writeFileSync(
    configFile,
    "export default " +
      JSON.stringify({
        name: "Teste",
        timezone: "America/Sao_Paulo",
        language: "portugues do Brasil",
        persona: { identity: "Assistente.", role: "Atende.", style: "Curto." },
        tools: [],
        media: {
          images: true,
          documents: true,
          video: true,
          maxBytes: 16 * 1024 * 1024,
          maxPdfPages: 8,
          maxChars: 12000,
        },
        voice: { reply: "nunca", voiceId: "v1", maxChars: 420 },
        human: {
          debounceMs: 150,
          readDelayMs: [30, 60],
          typingCps: 400,
          typingMs: [50, 150],
          splitBubbles: false,
          maxBubbles: 1,
          jitter: 0.1,
        },
        scheduling: { enabled: false, reminderOffsets: [], defaultDurationMinutes: 30 },
        handoff: { message: "Vou chamar alguem." },
      }) +
      ";\n",
  );

  const port = 8197;
  const child: ChildProcess = spawn(
    process.execPath,
    [path.join(here, "server.ts")],
    {
      env: {
        ...process.env,
        PORT: String(port),
        BOT_DB: path.join(dataDir, "media.db"),
        BOT_CONFIG: configFile,
        EVOLUTION_API_URL: "http://127.0.0.1:" + bridgePort,
        EVOLUTION_API_KEY: "k",
        EVOLUTION_INSTANCE: "teste",
        EVOLUTION_WEBHOOK_SECRET: "segredo",
        GROQ_API_KEY: "fake",
        GROQ_BASE_URL: "http://127.0.0.1:" + modelPort,
        GROQ_MODEL: "modelo-de-texto",
        GROQ_VISION_MODEL: "modelo-de-visao",
        OPENROUTER_API_KEY: "",
        OPENAI_API_KEY: "",
        ELEVENLABS_API_KEY: "",
        BACKEND_URL: "",
        ADMIN_TOKEN: "operador",
      },
      stdio: ["ignore", "pipe", "pipe"],
    },
  );

  let stderr = "";
  child.stderr?.on("data", (c: Buffer) => (stderr += String(c)));

  const send = (message: unknown, id: string) =>
    fetch("http://127.0.0.1:" + port + "/webhook", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-webhook-token": "segredo",
      },
      body: JSON.stringify({
        event: "messages.upsert",
        instance: "teste",
        data: {
          key: { remoteJid: "5531966665555@s.whatsapp.net", id },
          pushName: "Carla",
          message,
        },
      }),
    });

  try {
    await waitForBoot(port);

    /* --- an image ------------------------------------------------------- */
    payload = PNG;
    const imageReply = await send(
      { imageMessage: { mimetype: "image/png", caption: "o que faço aqui?" } },
      "IMG-1",
    );
    assert.equal(imageReply.status, 200);
    assert.equal(
      ((await imageReply.json()) as { replied: boolean }).replied,
      true,
      stderr,
    );

    // The picture went to the vision model, not the chat model. This is the
    // failure that does not error: a text-only model handed an image part
    // answers confidently about nothing.
    const visionCall = modelSaw.find((call) =>
      call.messages.some(
        (message) =>
          Array.isArray(message.content) &&
          (message.content as { type: string }[]).some(
            (part) => part.type === "image_url",
          ),
      ),
    );
    assert.ok(visionCall, "nao chamou o modelo de visao");
    assert.equal(visionCall.model, "modelo-de-visao");

    // And the description reached the agent as the customer's turn, labelled so
    // the agent knows it did not see the image itself.
    const agentCall = modelSaw.find(
      (call) =>
        call.model === "modelo-de-texto" &&
        call.messages.some(
          (message) =>
            typeof message.content === "string" &&
            message.content.includes("PAGAMENTO RECUSADO"),
        ),
    );
    assert.ok(agentCall, "a descricao nao chegou ao agente");
    const userTurn = agentCall.messages.find((m) => m.role === "user");
    assert.match(String(userTurn?.content), /\[imagem — descrição automática\]/);
    // The caption survives: it is usually the actual question.
    assert.match(String(userTurn?.content), /o que faço aqui\?/);

    /* --- a PDF ---------------------------------------------------------- */
    payload = makePdf("ORCAMENTO 1200 REAIS validade 30 dias");
    const pdfReply = await send(
      {
        documentMessage: {
          mimetype: "application/pdf",
          fileName: "orcamento.pdf",
        },
      },
      "PDF-1",
    );
    assert.equal(pdfReply.status, 200);
    assert.equal(
      ((await pdfReply.json()) as { replied: boolean }).replied,
      true,
      stderr,
    );

    const pdfCall = modelSaw.find(
      (call) =>
        call.model === "modelo-de-texto" &&
        call.messages.some(
          (message) =>
            typeof message.content === "string" &&
            message.content.includes("ORCAMENTO 1200 REAIS"),
        ),
    );
    assert.ok(pdfCall, "o texto do PDF nao chegou ao agente. " + stderr);
    const pdfTurn = pdfCall.messages.filter((m) => m.role === "user").at(-1);
    // Named, and described as a PDF of one page — the agent is never left
    // guessing how much of the document it is looking at.
    assert.match(String(pdfTurn?.content), /orcamento\.pdf/);
    assert.match(String(pdfTurn?.content), /PDF de 1 página/);

    /* --- something it cannot read --------------------------------------- */
    payload = Buffer.from([0x00, 0x01, 0x02, 0x03, 0x04]);
    const binaryReply = await send(
      {
        documentMessage: {
          mimetype: "application/x-msdownload",
          fileName: "instalador.exe",
        },
      },
      "BIN-1",
    );
    const verdict = (await binaryReply.json()) as { read?: boolean };
    assert.equal(verdict.read, false);

    // It still answered — a file it cannot open is a reply, not silence.
    const texts = sent
      .filter((item) => item.path.includes("/message/sendText/"))
      .map((item) => String(item.body.text));
    assert.ok(
      texts.some((text) => /não consegui abrir/i.test(text)),
      "nao avisou que nao conseguiu abrir: " + texts.join(" | "),
    );
  } finally {
    child.kill("SIGKILL");
    await Promise.all([close(bridge), close(model)]);
  }
});
