import { complete, llmConfigured, type ChatMessage } from "../ai/providers.ts";
import { buildSystemPrompt } from "./prompt.ts";
import { parseAgentReply, type AgentAction, type AgentReply } from "./reply.ts";
import { MAX_TOOL_ROUNDS, runTool } from "./tools.ts";
import {
  cancelJobs,
  conversationById,
  recentMessages,
  setAutoReply,
  type Conversation,
  type MessageKind,
} from "../db.ts";
import {
  localTime,
  scheduleAppointment,
  scheduleRecurring,
  scheduleReminder,
} from "../scheduler/jobs.ts";
import { describeCron } from "../scheduler/cron.ts";
import { deliver } from "../sender.ts";
import { environment, type BotConfig } from "../config.ts";

/**
 * One turn: read the thread, ask the model, act, answer.
 *
 * The inbound message must already be recorded — the caller does that first, so
 * a crash in here still leaves the customer's words in the transcript and a
 * person can see what was asked.
 *
 * The conversational memory is the `messages` table, not a map in this process.
 * A deploy mid-conversation, a restart and a second copy of this container all
 * have to leave the thread intact, and someone who gets a reply that has
 * forgotten the last three messages notices immediately.
 */

/** How much of the thread the model is shown. */
const HISTORY_TURNS = 20;

export type AgentTurn = {
  /** What was sent, or null when nothing was. */
  sent: string | null;
  reply: AgentReply | null;
  /** A human-readable line per action carried out. */
  applied: string[];
  /** Which tools ran, for the log. */
  toolsUsed: string[];
  error: string | null;
};

export async function runTurn(input: {
  conversationId: string;
  config: BotConfig;
  /** What the customer's last message was, for `espelho` voice mode. */
  inboundKind?: MessageKind;
}): Promise<AgentTurn> {
  const empty: AgentTurn = {
    sent: null,
    reply: null,
    applied: [],
    toolsUsed: [],
    error: null,
  };

  const conversation = conversationById(input.conversationId);
  if (!conversation) return { ...empty, error: "Conversa não encontrada." };
  if (!llmConfigured()) return { ...empty, error: "IA não configurada." };

  const { config } = input;
  const timezone = conversation.timezone ?? config.timezone;

  const messages: ChatMessage[] = [
    { role: "system", content: buildSystemPrompt({ config, conversation }) },
    ...history(conversation.id),
  ];

  const parseContext = {
    timezone,
    tools: config.tools,
    schedulingEnabled: config.scheduling.enabled,
  };

  const toolsUsed: string[] = [];
  let reply: AgentReply | null = null;
  let corrected = false;

  /**
   * Ask, act on tools, ask again with what they said.
   *
   * The loop exists because a useful answer usually needs two round trips —
   * look at the diary, *then* offer a time — and the customer must not see the
   * middle of that. Bounded, because a model looping on a tool that keeps
   * failing has to give up while they are still in the conversation.
   */
  for (let round = 1; round <= MAX_TOOL_ROUNDS; round += 1) {
    let raw: string;
    try {
      ({ text: raw } = await complete(messages, { json: true }));
    } catch (error) {
      // No fallback message is sent. A generic "não entendi" trains the customer
      // to repeat themselves at a bot that is down; the thread is better left
      // silent while the handoff below puts it in front of a person.
      setAutoReply(conversation.id, false);
      return {
        ...empty,
        error: error instanceof Error ? error.message : String(error),
      };
    }

    reply = parseAgentReply(raw, parseContext);

    // The worst failure this feature has: the model writes "pronto, agendei!"
    // over an action that was refused, so the customer is told something that
    // did not happen and finds out when nobody calls. One corrective round-trip
    // — the model is shown exactly why it was refused and asked again — fixes
    // almost all of these, because the usual cause is a date it read wrong
    // rather than a request that was impossible.
    //
    // Only once per turn, and only when nothing survived: a second failure means
    // it is not going to get it, and the reply then goes without the promise,
    // which is a worse answer but a true one.
    if (!corrected && reply.rejected.length > 0 && reply.actions.length === 0) {
      corrected = true;
      messages.push({ role: "assistant", content: raw });
      messages.push({
        role: "system",
        content:
          `As ações que você mandou foram recusadas: ${reply.rejected.join(" ")} ` +
          "Responda de novo, no mesmo formato JSON. Corrija a ação se der, e se " +
          "não der, NÃO diga que fez — pergunte o que falta para acertar.",
      });
      continue;
    }

    const toolCalls = reply.actions.filter(
      (action) => action.type === "ferramenta",
    );
    if (toolCalls.length === 0) break;

    // A pending line, sent before the backend is touched. A three-second silence
    // in a chat that is otherwise instant reads as a hang, and this is the one
    // place the bot legitimately knows it is about to be slow.
    if (reply.message) {
      await deliver({
        conversationId: conversation.id,
        text: reply.message,
        origin: "agent",
        config,
        inboundKind: input.inboundKind,
      });
    } else {
      const pending = toolCalls
        .map((call) => (call.type === "ferramenta" ? call.tool.pending : null))
        .find((line): line is string => Boolean(line));
      if (pending) {
        await deliver({
          conversationId: conversation.id,
          text: pending,
          origin: "agent",
          config,
          inboundKind: input.inboundKind,
        });
      }
    }

    messages.push({ role: "assistant", content: raw });

    for (const call of toolCalls) {
      if (call.type !== "ferramenta") continue;

      // A tool that changes something may only be called in the first round —
      // that is, directly in response to something the person just said.
      //
      // This is a partial guard and worth being honest about: it does not prove
      // they agreed, it proves the model is not acting on its own tool output
      // without them having spoken. That is where an uninvited cancellation
      // actually comes from. The prompt rule and the audit trail in
      // `tool_calls` carry the rest.
      if (call.tool.confirm && round > 1) {
        messages.push({
          role: "system",
          content:
            `A ferramenta ${call.tool.name} não pode ser usada agora: ela muda algo, ` +
            "e você só pode usá-la logo depois da pessoa confirmar. Pergunte a ela primeiro.",
        });
        continue;
      }

      const outcome = await runTool({
        tool: call.tool,
        args: call.args,
        conversationId: conversation.id,
      });
      toolsUsed.push(call.tool.name);
      messages.push({ role: "system", content: outcome.summary });
    }

    // The next round answers with what the tools said. Falls out of the loop on
    // the last one with whatever it had — see the guard below.
    reply = null;
  }

  if (!reply) {
    // Ran out of rounds mid-chain. Rather than send whatever half-finished
    // thought was in flight, hand the thread over: a model still calling tools
    // after three rounds has not understood the request, and the person is
    // better served by someone who has.
    return handOff(conversation, config, "o assistente não concluiu a consulta");
  }

  const applied = await applyActions({ conversation, config, actions: reply.actions });

  let sent: string | null = null;
  if (reply.message) {
    const delivery = await deliver({
      conversationId: conversation.id,
      text: reply.message,
      origin: "agent",
      config,
      inboundKind: input.inboundKind,
    });
    if (delivery.ok) sent = reply.message;
    else return { sent: null, reply, applied, toolsUsed, error: delivery.error };
  }

  return { sent, reply, applied, toolsUsed, error: null };
}

/**
 * The transcript, as the model's own turns.
 *
 * Failed outbound messages are excluded: the customer never saw them, so a model
 * that reads them back believes it already said something it did not, and the
 * next reply refers to a message that does not exist on the other phone.
 *
 * Consecutive messages from the same side are merged. Someone who sent three
 * bubbles sent one thought, and the providers reject or mangle alternating-role
 * histories that repeat a role — merging is both more accurate and more portable.
 */
function history(conversationId: string): ChatMessage[] {
  const rows = recentMessages(conversationId, HISTORY_TURNS).filter(
    (message) => message.status === "ok",
  );

  const merged: ChatMessage[] = [];
  for (const row of rows) {
    const role = row.direction === "in" ? ("user" as const) : ("assistant" as const);
    // A voice note is marked as one, so the model knows it is reading a
    // transcription and that a voice note back is welcome.
    const body =
      row.direction === "in" && row.kind === "audio"
        ? `[áudio transcrito] ${row.body}`
        : row.body;

    const last = merged.at(-1);
    if (last?.role === role) last.content = `${last.content}\n${body}`;
    else merged.push({ role, content: body });
  }
  return merged;
}

/**
 * Carries out what the model asked for, in the order it asked.
 *
 * Everything here has already been validated by `parseAgentReply`; this decides
 * nothing about whether an action is reasonable, only how to perform it.
 */
async function applyActions(input: {
  conversation: Conversation;
  config: BotConfig;
  actions: AgentAction[];
}): Promise<string[]> {
  const applied: string[] = [];

  for (const action of input.actions) {
    switch (action.type) {
      // Already run inside the loop above; listed so a new action type cannot be
      // added without this switch failing to compile.
      case "ferramenta":
        break;

      case "agendar": {
        const { reminders } = scheduleAppointment({
          conversationId: input.conversation.id,
          action,
          config: input.config,
        });
        applied.push(
          `${action.title} marcado para ${localTime(action.startsAt, action.timezone)}` +
            (reminders.length
              ? ` (${reminders.length} lembrete${reminders.length > 1 ? "s" : ""})`
              : ""),
        );
        break;
      }

      case "lembrete": {
        const job = scheduleReminder({
          conversationId: input.conversation.id,
          action,
        });
        applied.push(
          `Lembrete para ${localTime(job.nextRunAt!, job.timezone)}: "${job.body}"`,
        );
        break;
      }

      case "lembrete_recorrente": {
        const job = scheduleRecurring({
          conversationId: input.conversation.id,
          action,
        });
        if (job) {
          applied.push(
            `Lembrete ${describeCron(job.cron!)} (${job.maxRuns}x): "${job.body}"`,
          );
        }
        break;
      }

      case "transferir": {
        // The switch that stops the bot answering. Everything else it does is
        // additive; this one hands the thread to a person, which is why
        // `auto_reply` is a column rather than a setting.
        setAutoReply(input.conversation.id, false);
        await notifyHandoff(input.conversation, input.config, action.reason);
        applied.push(
          `Transferido para atendimento humano${action.reason ? ` — ${action.reason}` : ""}`,
        );
        break;
      }

      case "cancelar_lembretes": {
        const closed = cancelJobs(input.conversation.id, "cancelado");
        applied.push(
          `${closed} lembrete(s) cancelado(s)${action.reason ? ` — ${action.reason}` : ""}`,
        );
        break;
      }
    }
  }

  return applied;
}

/** Stops answering and says so, for the cases the bot cannot finish. */
async function handOff(
  conversation: Conversation,
  config: BotConfig,
  reason: string,
): Promise<AgentTurn> {
  setAutoReply(conversation.id, false);
  await notifyHandoff(conversation, config, reason);
  const delivery = await deliver({
    conversationId: conversation.id,
    text: config.handoff.message,
    origin: "agent",
    config,
  });
  return {
    sent: delivery.ok ? config.handoff.message : null,
    reply: null,
    applied: [`Transferido para atendimento humano — ${reason}`],
    toolsUsed: [],
    error: delivery.ok ? null : delivery.error,
  };
}

/**
 * Tells your backend a person is needed.
 *
 * Best-effort and deliberately so: the handoff itself already happened — the bot
 * has stopped answering and said so — and failing the turn because a
 * notification endpoint is down would leave the customer with silence instead of
 * the one message that explains it.
 */
async function notifyHandoff(
  conversation: Conversation,
  config: BotConfig,
  reason: string | null,
): Promise<void> {
  const backend = environment.backend();
  if (!backend || !config.handoff.notifyPath) return;

  try {
    await fetch(`${backend.url}${config.handoff.notifyPath}`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        ...(backend.token
          ? {
              [backend.headerName]: /^\S+\s/.test(backend.token)
                ? backend.token
                : `Bearer ${backend.token}`,
            }
          : {}),
      },
      body: JSON.stringify({
        phone: conversation.phone,
        name: conversation.contactName,
        conversationId: conversation.id,
        reason,
      }),
      signal: AbortSignal.timeout(8000),
    });
  } catch (error) {
    console.error(
      JSON.stringify({
        service: "bot",
        event: "handoff.notify.failed",
        conversation: conversation.id,
        message: error instanceof Error ? error.message : String(error),
      }),
    );
  }
}
