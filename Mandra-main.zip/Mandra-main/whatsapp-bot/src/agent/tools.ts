import { environment } from "../config.ts";
import type { Tool, ToolParam } from "../config.ts";
import { conversationById, recordToolCall } from "../db.ts";

/**
 * The only door between the model and your backend.
 *
 * There is no "call a URL" here, and that absence is the design. The model picks
 * a name from the list in `bot.config.ts` and fills in the parameters that tool
 * declares; the path, the method, the host and the auth header are all decided
 * here from config the model never sees. Given a free-form URL a language model
 * will eventually be talked into `/admin/users` by a customer who asks nicely,
 * and the request would go out carrying your service token.
 *
 * Everything below treats the model's output as if a stranger wrote it, because
 * effectively one did. A language model is an untrusted input source that
 * happens to sit on our side of the network, and every field here reaches
 * something real: a booking in your diary, a cancellation, a row in your
 * database.
 */

/** A backend call may not hold the customer waiting longer than this. */
const TIMEOUT_MS = 12_000;

/**
 * How much of the response the model is shown.
 *
 * A backend that answers with two hundred available slots would otherwise spend
 * the entire context window on JSON, and the reply after it is worse for every
 * token of it. If your endpoint can return an unbounded list, page it there —
 * truncating here loses the end silently.
 */
const MAX_RESULT_CHARS = 2500;

/**
 * How many rounds of "call a tool, look at the result, decide" one turn gets.
 *
 * Three is enough for the realistic chains (look up the person, check the
 * diary, book it) and short enough that a model looping on a tool that keeps
 * failing gives up while the customer is still in the conversation.
 */
export const MAX_TOOL_ROUNDS = 3;

export function findTool(tools: Tool[], name: string): Tool | null {
  return tools.find((tool) => tool.name === name) ?? null;
}

/* -------------------------------------------------------------------------- */
/* Describing the tools to the model                                           */
/* -------------------------------------------------------------------------- */

/**
 * The tool list, as the model sees it.
 *
 * Written as a compact list rather than as JSON Schema. Schema is what a
 * function-calling API wants; this bot answers in one JSON envelope instead (see
 * `reply.ts` for why), so what goes in the prompt is prose the model reads —
 * and models follow a demonstrated shape far more reliably than a described one.
 */
export function describeTools(tools: Tool[]): string {
  if (tools.length === 0) return "";

  const lines = tools.map((tool) => {
    const params = Object.entries(tool.parameters).map(([name, param]) => {
      const bits = [`"${name}"`, describeType(param)];
      if (param.required) bits.push("obrigatório");
      return `    - ${bits.join(", ")}: ${param.description}`;
    });

    const example = exampleCall(tool);
    return [
      `- ${tool.name}: ${tool.description}`,
      params.length ? "  Parâmetros:" : "  Sem parâmetros.",
      ...params,
      tool.confirm
        ? "  ATENÇÃO: só use depois da pessoa confirmar explicitamente."
        : null,
      `  Exemplo: ${example}`,
    ]
      .filter((line) => line !== null)
      .join("\n");
  });

  return `## Ferramentas
Você pode consultar o sistema da empresa. Para isso, ponha uma ação do tipo
"ferramenta" na sua resposta. O resultado volta para você e AÍ você responde a
pessoa — nunca invente o que a ferramenta ia dizer, e nunca afirme que fez algo
sem ter recebido o resultado de volta.

${lines.join("\n\n")}`;
}

function describeType(param: ToolParam): string {
  if (param.type === "enum") {
    return `um destes: ${(param.values ?? []).map((v) => `"${v}"`).join(", ")}`;
  }
  if (param.type === "number") return "número";
  if (param.type === "boolean") return "true ou false";
  return "texto";
}

function exampleCall(tool: Tool): string {
  const args: Record<string, unknown> = {};
  for (const [name, param] of Object.entries(tool.parameters)) {
    if (!param.required) continue;
    args[name] =
      param.type === "number"
        ? 1
        : param.type === "boolean"
          ? true
          : param.type === "enum"
            ? (param.values?.[0] ?? "")
            : "...";
  }
  return JSON.stringify({
    tipo: "ferramenta",
    nome: tool.name,
    argumentos: args,
  });
}

/* -------------------------------------------------------------------------- */
/* Validating what came back                                                   */
/* -------------------------------------------------------------------------- */

export type ValidatedArgs = Record<string, string | number | boolean>;

export type Validation =
  | { ok: true; args: ValidatedArgs }
  | { ok: false; error: string };

/**
 * Checks the model's arguments against what the tool declares.
 *
 * Coercion is deliberately narrow: `"30"` becomes 30 because models write
 * numbers as strings constantly and losing a booking over that is pedantry, but
 * an enum value that is not in the list is refused rather than guessed at.
 * Guessing is how "particular" quietly becomes "convenio" on someone's invoice.
 *
 * Unknown argument names are dropped rather than refused — a model that adds a
 * helpful extra field should not cost the customer their turn — but the drop is
 * reported back so the prompt can be fixed.
 */
export function validateArgs(tool: Tool, raw: unknown): Validation {
  if (raw !== undefined && raw !== null && typeof raw !== "object") {
    return { ok: false, error: `Os argumentos de ${tool.name} não são um objeto.` };
  }
  const given = (raw ?? {}) as Record<string, unknown>;
  const args: ValidatedArgs = {};

  for (const [name, param] of Object.entries(tool.parameters)) {
    const value = given[name];

    if (value === undefined || value === null || value === "") {
      if (param.required) {
        return { ok: false, error: `Falta o parâmetro "${name}" em ${tool.name}.` };
      }
      continue;
    }

    switch (param.type) {
      case "string": {
        const text = String(value).trim();
        if (!text) {
          if (param.required) {
            return { ok: false, error: `"${name}" veio vazio em ${tool.name}.` };
          }
          continue;
        }
        args[name] = text.slice(0, param.maxLength ?? 200);
        break;
      }
      case "number": {
        const n = typeof value === "number" ? value : Number(String(value).trim());
        if (!Number.isFinite(n)) {
          return {
            ok: false,
            error: `"${name}" deveria ser número em ${tool.name}, veio "${String(value).slice(0, 40)}".`,
          };
        }
        args[name] = n;
        break;
      }
      case "boolean": {
        if (typeof value === "boolean") args[name] = value;
        else {
          const text = String(value).trim().toLowerCase();
          if (text === "true" || text === "sim") args[name] = true;
          else if (text === "false" || text === "nao" || text === "não") {
            args[name] = false;
          } else {
            return {
              ok: false,
              error: `"${name}" deveria ser true ou false em ${tool.name}.`,
            };
          }
        }
        break;
      }
      case "enum": {
        const text = String(value).trim();
        const allowed = param.values ?? [];
        // Case-insensitive, but the *declared* spelling is what goes to the
        // backend. Anything else makes the endpoint's own validation depend on
        // how the model happened to capitalise it this time.
        const match = allowed.find(
          (option) => option.toLowerCase() === text.toLowerCase(),
        );
        if (!match) {
          return {
            ok: false,
            error:
              `"${name}" em ${tool.name} tem de ser um destes: ${allowed.join(", ")} — ` +
              `veio "${text.slice(0, 40)}".`,
          };
        }
        args[name] = match;
        break;
      }
    }
  }

  return { ok: true, args };
}

/* -------------------------------------------------------------------------- */
/* Calling the backend                                                         */
/* -------------------------------------------------------------------------- */

export type ToolOutcome = {
  ok: boolean;
  /** What the model is shown. Always prose or JSON, never an exception object. */
  summary: string;
};

/**
 * Runs one validated tool call.
 *
 * Never throws. A backend that is down, slow or answering 500 is a fact the
 * model has to be told about so it can say something true to the customer —
 * "não consegui consultar a agenda agora" — rather than an exception that
 * aborts the turn and leaves them on read.
 */
export async function runTool(input: {
  tool: Tool;
  args: ValidatedArgs;
  conversationId: string;
}): Promise<ToolOutcome> {
  const backend = environment.backend();
  if (!backend) {
    recordToolCall({
      conversationId: input.conversationId,
      tool: input.tool.name,
      arguments: input.args,
      ok: false,
      error: "BACKEND_URL não configurada.",
    });
    return {
      ok: false,
      summary:
        "ERRO: o sistema não está conectado. Diga que não consegue consultar isso agora e ofereça chamar alguém do time.",
    };
  }

  const started = Date.now();
  const { request } = input.tool;

  // The path is a template with holes, filled from validated arguments and
  // URL-encoded. A value carrying `../` or a query string of its own cannot
  // escape the path this way, which is the point.
  let pathname = request.path;
  for (const [name, value] of Object.entries(input.args)) {
    pathname = pathname.replaceAll(
      `{${name}}`,
      encodeURIComponent(String(value)),
    );
  }
  // A placeholder nobody filled would go out as the literal "{id}" and hit an
  // endpoint that 404s in a way nobody can read.
  const unfilled = /\{([a-z_][a-z0-9_]*)\}/i.exec(pathname);
  if (unfilled) {
    recordToolCall({
      conversationId: input.conversationId,
      tool: input.tool.name,
      arguments: input.args,
      ok: false,
      error: `Placeholder {${unfilled[1]}} sem valor.`,
    });
    return {
      ok: false,
      summary: `ERRO: faltou o parâmetro "${unfilled[1]}". Peça essa informação para a pessoa.`,
    };
  }

  const url = new URL(
    `${backend.url}${pathname.startsWith("/") ? "" : "/"}${pathname}`,
  );
  for (const name of request.query ?? []) {
    const value = input.args[name];
    if (value !== undefined) url.searchParams.set(name, String(value));
  }

  let body: string | undefined;
  if (request.method !== "GET" && request.method !== "DELETE") {
    const payload: Record<string, unknown> = { ...(request.fixedBody ?? {}) };
    for (const name of request.body ?? []) {
      const value = input.args[name];
      if (value !== undefined) payload[name] = value;
    }
    body = JSON.stringify(payload);
  }

  // Who is asking, from the conversation row rather than from the model. A tool
  // that took the phone as a parameter would answer about whatever number the
  // person typed — "me passa a guia da empresa do 31 9…" — and the backend
  // would have no way to tell. The model never sees this value and cannot set it.
  const phone = conversationById(input.conversationId)?.phone ?? null;

  try {
    const response = await fetch(url, {
      method: request.method,
      headers: {
        accept: "application/json",
        ...(body ? { "content-type": "application/json" } : {}),
        ...(phone ? { "x-conversa-telefone": phone } : {}),
        // The token is read from the environment at call time and never passes
        // through the prompt, the envelope or the transcript.
        ...(backend.token
          ? { [backend.headerName]: bearer(backend.token) }
          : {}),
      },
      body,
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });

    const text = (await response.text().catch(() => "")).slice(
      0,
      MAX_RESULT_CHARS,
    );
    const duration = Date.now() - started;

    recordToolCall({
      conversationId: input.conversationId,
      tool: input.tool.name,
      arguments: input.args,
      ok: response.ok,
      status: response.status,
      result: text,
      durationMs: duration,
    });

    if (!response.ok) {
      // The status is given to the model in words rather than as a number: a
      // model shown "404" will tell the customer "erro 404", and a model told
      // "não encontrei" says that instead.
      return { ok: false, summary: explainStatus(response.status, text) };
    }

    return {
      ok: true,
      summary: text.trim()
        ? `Resultado de ${input.tool.name}: ${text.trim()}`
        : `${input.tool.name} deu certo (sem conteúdo na resposta).`,
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    recordToolCall({
      conversationId: input.conversationId,
      tool: input.tool.name,
      arguments: input.args,
      ok: false,
      error: message,
      durationMs: Date.now() - started,
    });
    return {
      ok: false,
      summary:
        "ERRO: o sistema não respondeu a tempo. Diga que não conseguiu consultar agora e ofereça " +
        "tentar de novo ou chamar alguém do time. NÃO afirme que deu certo.",
    };
  }
}

/** Adds the `Bearer ` prefix unless the token already carries a scheme. */
function bearer(token: string): string {
  return /^\S+\s/.test(token) ? token : `Bearer ${token}`;
}

function explainStatus(status: number, body: string): string {
  const detail = body.trim() ? ` Detalhe do sistema: ${body.trim()}` : "";
  if (status === 404) {
    return `ERRO: não encontrei esse registro.${detail} Diga isso à pessoa e confirme os dados com ela.`;
  }
  if (status === 409) {
    return `ERRO: isso conflita com algo que já existe (horário ocupado, por exemplo).${detail} Ofereça outra opção.`;
  }
  if (status === 400 || status === 422) {
    return `ERRO: o sistema recusou os dados.${detail} Peça à pessoa o que estiver faltando ou errado.`;
  }
  if (status === 401 || status === 403) {
    // A credentials problem is ours, not the customer's, and the model must not
    // start asking them for a password to fix it.
    return "ERRO: sem permissão para essa consulta. NÃO peça dados à pessoa — diga que vai chamar alguém do time e use a ação transferir.";
  }
  return `ERRO: o sistema falhou (${status}).${detail} Diga que não conseguiu agora e ofereça chamar alguém do time. NÃO afirme que deu certo.`;
}
