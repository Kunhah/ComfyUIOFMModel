import { describeTools } from "./tools.ts";
import { describeCron } from "../scheduler/cron.ts";
import { jobsFor, type Conversation } from "../db.ts";
import type { BotConfig } from "../config.ts";

/**
 * What the bot is, what it is talking to, and what it may say back.
 *
 * Assembled per turn rather than kept as a constant, because two thirds of it is
 * about *this* conversation: who the person is, what is already scheduled for
 * them, what time it is where they are. A static prompt plus a "context" message
 * was tried in the CRM this is ported from and it drifts — the model treats the
 * static half as instructions and the appended half as conversation.
 */

/**
 * The rules a client's brief cannot drop.
 *
 * `bot.config.ts` is written by whoever runs the bot, and the four below are
 * exactly the ones that go missing when a persona is written by someone thinking
 * about sales rather than about liability. They are concatenated after the
 * config's own rules so they are the last thing the model reads.
 *
 * "Nunca diga que é humano" is not negotiable and not a style choice. The pacing
 * in `humanize.ts` makes the bot feel like a person; being asked directly and
 * lying about it is a different act, and in several places a regulated one.
 */
const NON_NEGOTIABLE = [
  "Nunca invente preço, prazo, desconto ou condição de pagamento. Se perguntarem e você não tiver o dado de uma ferramenta, diga que quem passa isso é o time e ofereça chamar alguém.",
  "Nunca invente informação que deveria vir de uma ferramenta. Se a consulta falhou, diga que não conseguiu ver agora — nunca chute.",
  "Nunca peça senha, dado bancário, número de cartão ou documento.",
  "Nunca diga que é humano. Se perguntarem se é um robô ou uma pessoa, responda que é o assistente virtual e ofereça chamar alguém do time.",
  "Nunca prometa que fez algo que você não fez. Só diga que agendou, marcou ou cancelou depois de receber o resultado da ferramenta.",
];

export function buildSystemPrompt(input: {
  config: BotConfig;
  conversation: Conversation;
  now?: Date;
}): string {
  const { config, conversation } = input;
  const timezone = conversation.timezone ?? config.timezone;
  const now = new Intl.DateTimeFormat("pt-BR", {
    timeZone: timezone,
    dateStyle: "full",
    timeStyle: "short",
  }).format(input.now ?? new Date());

  const sections = [
    persona(config),
    who(conversation, config),
    faq(config),
    mediaGuide(config),
    describeTools(config.tools),
    envelopeContract(config, now, timezone),
  ];

  return sections.filter((section) => section.trim()).join("\n\n");
}

function persona(config: BotConfig): string {
  const rules = [...(config.persona.rules ?? []), ...NON_NEGOTIABLE];
  return `${config.persona.identity}

## Seu papel
${config.persona.role}

## Regras que não se quebram
${rules.map((rule) => `- ${rule}`).join("\n")}

## Como escrever
${config.persona.style}
Escreva em ${config.language}.`;
}

/**
 * What the bot knows about the person on the other side.
 *
 * Everything here is already ours — a name WhatsApp gave us, a profile your own
 * backend wrote, jobs this bot itself created. Nothing is inferred, and there is
 * no place for the model to put a guess: an assistant that opens with a half-
 * remembered detail about the wrong person is worse than one that opens cold.
 */
function who(conversation: Conversation, config: BotConfig): string {
  const lines: string[] = [];

  if (conversation.contactName) {
    lines.push(`Nome no WhatsApp: ${conversation.contactName}`);
  }
  lines.push(`Telefone: ${conversation.phone}`);

  if (conversation.profile) {
    for (const [key, value] of Object.entries(conversation.profile)) {
      if (value === null || value === undefined || value === "") continue;
      lines.push(`${key}: ${String(value).slice(0, 300)}`);
    }
  }

  // What is already scheduled, so the bot does not book a second appointment
  // over the first or promise a reminder that already exists.
  const live = jobsFor(conversation.id).filter((job) => job.active);
  if (live.length > 0) {
    lines.push(
      `Já programado para esta pessoa: ${live
        .map((job) =>
          job.kind === "cron" && job.cron
            ? `${describeCron(job.cron)} — "${job.body.slice(0, 60)}"`
            : `${job.nextRunAt ?? "sem data"} — "${job.body.slice(0, 60)}"`,
        )
        .join("; ")}`,
    );
  }

  if (lines.length <= 1 && config.persona.greeting) {
    lines.push(
      `Esta pessoa nunca escreveu antes. Abra com algo próximo de: "${config.persona.greeting}"`,
    );
  }

  return `## Quem está do outro lado\n${lines.join("\n")}`;
}

/**
 * Canned answers, given as answers rather than as facts.
 *
 * A model handed "endereço: Rua X, 1200" paraphrases it, and the paraphrase is
 * where the sala number goes missing. Handed the finished sentence and told to
 * use it as written, it does.
 */
function faq(config: BotConfig): string {
  if (!config.faq?.length) return "";
  return `## Respostas prontas
Quando a pergunta for uma destas, responda com o texto abaixo, praticamente como
está escrito. Não parafraseie endereço, valor, horário nem nome próprio.

${config.faq.map((item) => `P: ${item.q}\nR: ${item.a}`).join("\n\n")}`;
}

/**
 * The contract. Written as an instruction *and* as an example, because models
 * follow a demonstrated shape far more reliably than a described one.
 *
 * The keys are in the prompt's own language for the same reason the rest of it
 * is: asking a model to reason in one language and emit keys in another costs
 * accuracy on exactly the fields that matter.
 */
function envelopeContract(
  config: BotConfig,
  now: string,
  timezone: string,
): string {
  const scheduling = config.scheduling.enabled
    ? `
Ações de agenda (só depois da pessoa concordar — nunca agende por conta própria):

{"tipo":"agendar","titulo":"Consulta de fisioterapia","quando":"2026-09-10T14:00","duracao_min":${config.scheduling.defaultDurationMinutes},"observacao":"primeira sessão"}

{"tipo":"lembrete","quando":"2026-09-09T09:00","texto":"Oi! Passando pra lembrar da sua consulta amanhã às 14h 🙂","motivo":"pediu para lembrar"}

{"tipo":"lembrete_recorrente","cron":"0 9 * * 1","texto":"Bom dia! Como está a recuperação essa semana?","repeticoes":4,"motivo":"acompanhamento semanal combinado"}

Limites: no mínimo 6 horas entre repetições, no máximo 12 repetições, e nada a
mais de 365 dias. O "texto" de um lembrete é a mensagem inteira que a pessoa vai
receber sozinha, dias depois — escreva ela completa, sem depender desta conversa.
`
    : "";

  return `## Formato da resposta (obrigatório)
Responda SEMPRE com um único objeto JSON, sem texto fora dele e sem blocos de
código:

{"mensagem": "o que enviar para a pessoa", "acoes": []}

"mensagem" é o texto que a pessoa vai ler no WhatsApp. "acoes" é uma lista, quase
sempre vazia.

Agora são ${now} (fuso ${timezone}). Use SEMPRE horário local no formato
"AAAA-MM-DDTHH:MM". Nunca escreva fuso, "Z" nem offset.

Para usar uma ferramenta, deixe "mensagem" vazia ou com uma frase curta de espera
e ponha a ação. O resultado volta para você antes de a pessoa ver qualquer coisa:

{"mensagem": "", "acoes": [{"tipo":"ferramenta","nome":"nome_da_ferramenta","argumentos":{}}]}
${scheduling}
Passar para uma pessoa do time:
{"tipo":"transferir","motivo":"cliente pediu falar com humano"}

Parar de mandar lembretes:
{"tipo":"cancelar_lembretes","motivo":"pediu para não chamar mais"}`;
}

/**
 * How to read the turns that came from a file.
 *
 * Included whenever the bot can open anything, because the agent otherwise has
 * no way to tell a transcription from something typed — and the difference
 * matters twice. A transcription carries mishearings, so an odd word is a
 * question to ask rather than a fact to act on; and it is also the cue that a
 * voice note back is welcome.
 *
 * The video line is the one that earns its place. Only the audio is heard, and
 * an agent that does not know that will answer "vi seu vídeo" about a picture
 * nobody looked at — a claim the customer has no way to check and every reason
 * to believe.
 */
export function mediaGuide(config: BotConfig): string {
  if (!config.media.images && !config.media.documents && !config.media.video) {
    return "";
  }

  return `## Arquivos que a pessoa manda
Às vezes a mensagem da pessoa chega já convertida em texto por outro sistema,
entre colchetes. Trate o conteúdo como se ela tivesse dito, mas sabendo de onde
veio:

- "[áudio transcrito]" — é transcrição de voz e pode ter erro. Se uma palavra não
  fizer sentido, pergunte em vez de adivinhar. Responder em áudio é bem-vindo.
- "[imagem — descrição automática]" — você NÃO viu a imagem; leu a descrição que
  outro sistema fez dela. Não invente nada que não esteja ali, e se precisar de
  um detalhe que a descrição não traz, peça.
- "[vídeo — só consegui ouvir o áudio]" — você NÃO viu as imagens. Nunca diga que
  viu o vídeo. Se a pergunta depender do que aparece na tela, diga que só ouviu.
- "[arquivo ...]" — é o texto extraído de um documento. Quando disser que leu só
  parte, é porque leu só parte: diga isso à pessoa em vez de responder como se
  tivesse lido tudo.
- "[a pessoa mandou ... e eu não consegui ler]" — não finja que leu. Diga que não
  conseguiu abrir e ofereça outro caminho.

Nunca repita de volta número de documento, cartão ou senha que apareça num
arquivo, mesmo que a pessoa tenha mandado.`;
}
