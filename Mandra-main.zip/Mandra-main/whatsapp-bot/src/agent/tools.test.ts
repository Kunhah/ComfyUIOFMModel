import test from "node:test";
import assert from "node:assert/strict";
import { createServer, type Server } from "node:http";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import type { Tool } from "../config.ts";

// The database is opened lazily on first use, so this has to be set before the
// modules under test are imported.
process.env.BOT_DB = path.join(
  mkdtempSync(path.join(tmpdir(), "bot-tools-")),
  "test.db",
);

// Imported dynamically, after BOT_DB is set above. The type is a static import
// because types are erased and never open a database.
const { runTool, describeTools, validateArgs } = await import("./tools.ts");
const { openConversation } = await import("../db.ts");

/**
 * What reaches the backend, and what must not.
 *
 * The interesting cases are all about the boundary: a path built from a
 * template, a token that never appears in anything the model sees, and an error
 * turned into words the bot can safely repeat to a customer.
 */

type Received = {
  method: string;
  url: string;
  authorization: string | undefined;
  telefone: string | undefined;
  body: string;
};

async function withBackend(
  handler: (received: Received) => { status: number; body: string },
  run: (base: string) => Promise<void>,
): Promise<Received[]> {
  const seen: Received[] = [];
  const server: Server = createServer((request, response) => {
    const chunks: Buffer[] = [];
    request.on("data", (chunk: Buffer) => chunks.push(chunk));
    request.on("end", () => {
      const received: Received = {
        method: request.method ?? "",
        url: request.url ?? "",
        authorization: request.headers.authorization,
        telefone: request.headers["x-conversa-telefone"] as string | undefined,
        body: Buffer.concat(chunks).toString("utf8"),
      };
      seen.push(received);
      const answer = handler(received);
      response.writeHead(answer.status, { "content-type": "application/json" });
      response.end(answer.body);
    });
  });

  await new Promise<void>((resolve) => server.listen(0, resolve));
  const address = server.address();
  const port = typeof address === "object" && address ? address.port : 0;
  try {
    await run(`http://127.0.0.1:${port}`);
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
  return seen;
}

const conversation = openConversation({ phone: "5531999990000" });

const lookup: Tool = {
  name: "consultar",
  description: "consulta",
  parameters: {
    id: { type: "string", description: "o id", required: true },
    nota: { type: "string", description: "nota" },
  },
  request: { method: "GET", path: "/registros/{id}", query: ["nota"] },
};

test("fills the path template and URL-encodes the value", async () => {
  const seen = await withBackend(
    () => ({ status: 200, body: '{"livre":true}' }),
    async (base) => {
      process.env.BACKEND_URL = base;
      process.env.BACKEND_TOKEN = "s3cr3t";
      const outcome = await runTool({
        tool: lookup,
        args: { id: "abc 123", nota: "oi" },
        conversationId: conversation.id,
      });
      assert.equal(outcome.ok, true);
      assert.match(outcome.summary, /livre/);
    },
  );

  assert.equal(seen[0]?.method, "GET");
  assert.equal(seen[0]?.url, "/registros/abc%20123?nota=oi");
  // The token is read from the environment at call time; it is never in the
  // prompt, the envelope or the transcript.
  assert.equal(seen[0]?.authorization, "Bearer s3cr3t");
  // Who is asking comes from the conversation row, not from an argument — the
  // backend can scope by it and the model has no way to name another number.
  assert.equal(seen[0]?.telefone, "5531999990000");
});

test("a value cannot break out of the path it was given", async () => {
  const seen = await withBackend(
    () => ({ status: 200, body: "{}" }),
    async (base) => {
      process.env.BACKEND_URL = base;
      await runTool({
        tool: lookup,
        // The shape of the thing a model gets talked into by a customer.
        args: { id: "../../admin/users" },
        conversationId: conversation.id,
      });
    },
  );
  assert.equal(seen[0]?.url, "/registros/..%2F..%2Fadmin%2Fusers");
});

test("refuses to call out when a placeholder was never filled", async () => {
  process.env.BACKEND_URL = "http://127.0.0.1:1";
  const outcome = await runTool({
    tool: lookup,
    args: { nota: "sem id" },
    conversationId: conversation.id,
  });
  assert.equal(outcome.ok, false);
  assert.match(outcome.summary, /faltou o parâmetro "id"/);
});

test("merges fixedBody and only the declared body fields", async () => {
  const booking: Tool = {
    name: "marcar",
    description: "marca",
    parameters: {
      nome: { type: "string", description: "nome", required: true },
      quando: { type: "string", description: "quando", required: true },
    },
    request: {
      method: "POST",
      path: "/consultas",
      body: ["nome", "quando"],
      fixedBody: { origem: "whatsapp" },
    },
    confirm: true,
  };

  const seen = await withBackend(
    () => ({ status: 201, body: '{"id":"c1"}' }),
    async (base) => {
      process.env.BACKEND_URL = base;
      await runTool({
        tool: booking,
        args: { nome: "Ana", quando: "2026-09-10T14:00" },
        conversationId: conversation.id,
      });
    },
  );

  assert.deepEqual(JSON.parse(seen[0]?.body ?? "{}"), {
    // The channel is not the model's to choose.
    origem: "whatsapp",
    nome: "Ana",
    quando: "2026-09-10T14:00",
  });
});

test("turns a status into words the bot can safely repeat", async () => {
  const cases: Array<[number, RegExp]> = [
    [404, /não encontrei/],
    [409, /conflita/],
    [422, /recusou os dados/],
    // A credentials problem is ours, not the customer's, and the model must not
    // start asking them for a password to fix it.
    [401, /NÃO peça dados à pessoa/],
    [500, /NÃO afirme que deu certo/],
  ];

  for (const [status, expected] of cases) {
    await withBackend(
      () => ({ status, body: "" }),
      async (base) => {
        process.env.BACKEND_URL = base;
        const outcome = await runTool({
          tool: lookup,
          args: { id: "x" },
          conversationId: conversation.id,
        });
        assert.equal(outcome.ok, false, `status ${status}`);
        assert.match(outcome.summary, expected, `status ${status}`);
      },
    );
  }
});

test("a backend that is down is reported as words, never thrown", async () => {
  // Nothing is listening on this port.
  process.env.BACKEND_URL = "http://127.0.0.1:1";
  const outcome = await runTool({
    tool: lookup,
    args: { id: "x" },
    conversationId: conversation.id,
  });
  assert.equal(outcome.ok, false);
  assert.match(outcome.summary, /NÃO afirme que deu certo/);
});

test("the prompt description lists every tool and its required arguments", () => {
  const described = describeTools([lookup]);
  assert.match(described, /consultar/);
  assert.match(described, /"id".*obrigatório/);
  // An example call, because models follow a demonstrated shape far more
  // reliably than a described one.
  assert.match(described, /"tipo":"ferramenta"/);
});

test("unknown arguments are dropped rather than costing the turn", () => {
  const result = validateArgs(lookup, { id: "x", inventado: "y" });
  assert.equal(result.ok, true);
  if (!result.ok) return;
  assert.deepEqual(result.args, { id: "x" });
});
