import { extractJson } from "../ai/envelope.ts";
import { isValidCron, nextRunOf, wallToInstant } from "../scheduler/cron.ts";
import { findTool, validateArgs, type ValidatedArgs } from "./tools.ts";
import type { Tool } from "../config.ts";

/**
 * The JSON the model is allowed to send, and everything that stops it being
 * believed.
 *
 * The bot does not use a function-calling API — it answers with one object
 * containing what to say and, optionally, what to *do*. One envelope because the
 * providers behind it expose tool calling differently and not every model on
 * every one of them supports it, while `response_format: json_object` works on
 * all three. The cost is this file: a schema written out by hand and validated
 * as if it came from a stranger.
 *
 * Which it did. Every field here reaches something real — a message sent to a
 * customer's phone, a booking in a diary, a job that keeps messaging them for
 * weeks. The rules below are not defensive programming, they are the product: a
 * bot that can be talked into scheduling a message every minute for a year is a
 * worse feature than no bot.
 */

export type ToolAction = {
  type: "ferramenta";
  tool: Tool;
  args: ValidatedArgs;
};

export type ScheduleAction = {
  type: "agendar";
  title: string;
  /** ISO-8601 UTC, resolved from the local wall time the model wrote. */
  startsAt: string;
  timezone: string;
  durationMinutes: number;
  notes: string | null;
};

export type ReminderAction = {
  type: "lembrete";
  runAt: string;
  timezone: string;
  body: string;
  reason: string | null;
};

export type RecurringAction = {
  type: "lembrete_recorrente";
  cron: string;
  timezone: string;
  body: string;
  maxRuns: number;
  reason: string | null;
};

export type HandoffAction = { type: "transferir"; reason: string | null };
export type CancelAction = { type: "cancelar_lembretes"; reason: string | null };

export type AgentAction =
  | ToolAction
  | ScheduleAction
  | ReminderAction
  | RecurringAction
  | HandoffAction
  | CancelAction;

export type AgentReply = {
  /** What to send. May be empty when the turn is only a tool call. */
  message: string;
  actions: AgentAction[];
  /**
   * Actions that were refused, with the reason.
   *
   * Kept rather than dropped, because they are fed back to the model so it can
   * correct itself. The worst failure this whole feature has is the model
   * writing "pronto, agendei!" over an action that was refused: the customer is
   * told something that did not happen and finds out when nobody calls.
   */
  rejected: string[];
};

/**
 * How far ahead anything may be scheduled.
 *
 * A model that misreads "ano que vem" or fumbles a year in an ISO string
 * produces a job sitting in the queue until 2034. Nothing this bot does is
 * legitimately more than a year out, and the ceiling turns a silent absurdity
 * into a rejection the model is told about.
 */
const MAX_HORIZON_DAYS = 365;

/**
 * The floor on how often a recurrence may fire, and the most important number in
 * this file.
 *
 * `* * * * *` is perfectly valid cron that messages a customer every minute
 * forever, and it is exactly what a confused model emits for "lembrar sempre".
 * Six hours allows every real reminder — daily, weekly, twice a week — and
 * excludes every shape that gets the number banned.
 */
const MIN_INTERVAL_MINUTES = 6 * 60;

/**
 * A recurrence with no end is a subscription the customer never agreed to, and
 * nothing in a chat thread cancels it — they block the number instead. Twelve is
 * three months of weekly follow-ups.
 */
const MAX_RUNS = 12;
const DEFAULT_MAX_RUNS = 4;

const MAX_MESSAGE_LENGTH = 1200;
const MAX_BODY_LENGTH = 800;
const MAX_DURATION_MINUTES = 8 * 60;

/** Guard against a model that decides to do twenty things in one turn. */
const MAX_ACTIONS = 4;

export type ParseContext = {
  timezone: string;
  tools: Tool[];
  /** Whether `bot.config.ts` allows booking at all. */
  schedulingEnabled: boolean;
  /** Injected in tests; the moment "the past" is measured against. */
  now?: Date;
};

/**
 * Turns the model's raw completion into a reply we are willing to act on.
 *
 * Never throws. Every failure — unparseable JSON, a missing message, an action
 * that breaks a rule — degrades to something sendable, because the alternative
 * on a live WhatsApp thread is a customer left on read.
 */
export function parseAgentReply(
  raw: string,
  context: ParseContext,
): AgentReply {
  const parsed = extractJson(raw);

  // A model that ignored the envelope entirely still wrote a sentence. Sending
  // it beats sending nothing: the words are usually a perfectly good reply and
  // only the structure is missing, so the turn loses its actions rather than its
  // answer.
  if (!parsed) {
    return { message: clamp(raw, MAX_MESSAGE_LENGTH), actions: [], rejected: [] };
  }

  const message = clamp(
    typeof parsed.mensagem === "string" ? parsed.mensagem : "",
    MAX_MESSAGE_LENGTH,
  );

  const rejected: string[] = [];
  const actions: AgentAction[] = [];

  const list = Array.isArray(parsed.acoes) ? parsed.acoes : [];
  for (const entry of list.slice(0, MAX_ACTIONS)) {
    const result = parseAction(entry, context);
    if ("error" in result) rejected.push(result.error);
    else actions.push(result.action);
  }
  if (list.length > MAX_ACTIONS) {
    rejected.push(
      `Só as ${MAX_ACTIONS} primeiras ações foram consideradas (vieram ${list.length}).`,
    );
  }

  return { message, actions, rejected };
}

type ActionResult = { action: AgentAction } | { error: string };

function parseAction(entry: unknown, context: ParseContext): ActionResult {
  if (!entry || typeof entry !== "object") {
    return { error: "Ação ignorada: não era um objeto." };
  }
  const a = entry as Record<string, unknown>;
  const type = typeof a.tipo === "string" ? a.tipo.trim().toLowerCase() : "";

  switch (type) {
    case "ferramenta":
      return parseToolCall(a, context);
    case "agendar":
      return context.schedulingEnabled
        ? parseSchedule(a, context)
        : { error: "Agendamento não está habilitado neste bot." };
    case "lembrete":
      return context.schedulingEnabled
        ? parseReminder(a, context)
        : { error: "Lembrete não está habilitado neste bot." };
    case "lembrete_recorrente":
      return context.schedulingEnabled
        ? parseRecurring(a, context)
        : { error: "Lembrete recorrente não está habilitado neste bot." };
    case "transferir":
      return { action: { type: "transferir", reason: text(a.motivo, 300) } };
    case "cancelar_lembretes":
      return {
        action: { type: "cancelar_lembretes", reason: text(a.motivo, 300) },
      };
    default:
      return { error: `Ação desconhecida: "${type || "(sem tipo)"}".` };
  }
}

/**
 * A tool call, checked against the list this bot actually declares.
 *
 * A name that is not in the list is refused with the list attached, which is the
 * single most useful correction there is: the usual cause is the model inventing
 * a plausible neighbour of a real tool ("verificar_agenda" for
 * "consultar_horarios"), and shown the real names it picks the right one.
 */
function parseToolCall(
  a: Record<string, unknown>,
  context: ParseContext,
): ActionResult {
  const name = typeof a.nome === "string" ? a.nome.trim() : "";
  if (!name) return { error: "Ferramenta sem nome." };

  const tool = findTool(context.tools, name);
  if (!tool) {
    const available = context.tools.map((t) => t.name).join(", ");
    return {
      error: `A ferramenta "${name}" não existe. As que existem são: ${available || "nenhuma"}.`,
    };
  }

  const validated = validateArgs(tool, a.argumentos);
  if (!validated.ok) return { error: validated.error };

  return { action: { type: "ferramenta", tool, args: validated.args } };
}

function parseSchedule(
  a: Record<string, unknown>,
  context: ParseContext,
): ActionResult {
  const timezone = zone(a.fuso, context.timezone);
  if (!timezone) return { error: `Fuso horário inválido: ${String(a.fuso)}.` };

  const when = resolveWhen(a.quando, timezone, context.now);
  if ("error" in when) return { error: `Agendamento recusado — ${when.error}` };

  return {
    action: {
      type: "agendar",
      title: text(a.titulo, 160) ?? "Compromisso",
      startsAt: when.instant.toISOString(),
      timezone,
      durationMinutes: Math.min(
        Math.max(Math.round(number(a.duracao_min) ?? 30), 5),
        MAX_DURATION_MINUTES,
      ),
      notes: text(a.observacao, 500),
    },
  };
}

function parseReminder(
  a: Record<string, unknown>,
  context: ParseContext,
): ActionResult {
  const timezone = zone(a.fuso, context.timezone);
  if (!timezone) return { error: `Fuso horário inválido: ${String(a.fuso)}.` };

  const when = resolveWhen(a.quando, timezone, context.now);
  if ("error" in when) return { error: `Lembrete recusado — ${when.error}` };

  const body = text(a.texto, MAX_BODY_LENGTH);
  // The body is the whole point of the job: a reminder with nothing to say
  // fires on time and sends an empty WhatsApp message.
  if (!body) return { error: "Lembrete recusado — sem texto para enviar." };

  return {
    action: {
      type: "lembrete",
      runAt: when.instant.toISOString(),
      timezone,
      body,
      reason: text(a.motivo, 300),
    },
  };
}

function parseRecurring(
  a: Record<string, unknown>,
  context: ParseContext,
): ActionResult {
  const timezone = zone(a.fuso, context.timezone);
  if (!timezone) return { error: `Fuso horário inválido: ${String(a.fuso)}.` };

  const expression = typeof a.cron === "string" ? a.cron.trim() : "";
  if (!expression || !isValidCron(expression)) {
    return {
      error: `Recorrência recusada — expressão cron inválida: "${expression}".`,
    };
  }

  const body = text(a.texto, MAX_BODY_LENGTH);
  if (!body) return { error: "Recorrência recusada — sem texto para enviar." };

  const now = context.now ?? new Date();
  const first = nextRunOf(expression, now, timezone);
  if (!first) {
    return { error: `Recorrência recusada — "${expression}" nunca acontece.` };
  }

  const spacing = minimumInterval(expression, first, timezone);
  if (spacing !== null && spacing < MIN_INTERVAL_MINUTES) {
    return {
      error:
        `Recorrência recusada — "${expression}" dispara a cada ${spacing} min, ` +
        `e o mínimo é ${MIN_INTERVAL_MINUTES / 60}h.`,
    };
  }

  return {
    action: {
      type: "lembrete_recorrente",
      cron: expression,
      timezone,
      body,
      maxRuns: Math.min(
        Math.max(Math.round(number(a.repeticoes) ?? DEFAULT_MAX_RUNS), 1),
        MAX_RUNS,
      ),
      reason: text(a.motivo, 300),
    },
  };
}

/**
 * The shortest gap between consecutive fires, sampled over the next few runs.
 *
 * Sampled rather than inferred from the fields: `0 9,10 * * *` fires twice, an
 * hour apart, once a day, and reading the expression calls that a daily
 * reminder. Computing four consecutive runs and taking the smallest gap is the
 * only cheap way to know.
 */
function minimumInterval(
  expression: string,
  first: Date,
  timezone: string,
): number | null {
  let previous = first;
  let smallest: number | null = null;

  for (let i = 0; i < 4; i += 1) {
    const next = nextRunOf(expression, previous, timezone);
    if (!next) break;
    const gap = Math.round((next.getTime() - previous.getTime()) / 60000);
    smallest = smallest === null ? gap : Math.min(smallest, gap);
    previous = next;
  }
  return smallest;
}

type WhenResult = { instant: Date } | { error: string };

/**
 * Resolves the moment the model wrote into a real instant.
 *
 * Accepts a bare local wall time (`2026-09-05T14:00`) and reads it in the
 * conversation's timezone, which is what the model is told to send: asking a
 * language model for a UTC offset is asking it to do arithmetic it is bad at,
 * and a wrong offset books the appointment three hours out with nothing to show
 * for it. A string carrying its own offset or a `Z` is honoured as written.
 */
function resolveWhen(value: unknown, timezone: string, now?: Date): WhenResult {
  if (typeof value !== "string" || !value.trim()) {
    return { error: "sem data e hora." };
  }
  const raw = value.trim();

  const local = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::\d{2})?$/.exec(raw);
  let instant: Date;

  if (local) {
    instant = new Date(
      wallToInstant(
        {
          year: Number(local[1]),
          month: Number(local[2]),
          day: Number(local[3]),
          hour: Number(local[4]),
          minute: Number(local[5]),
        },
        timezone,
      ),
    );
  } else {
    const parsed = Date.parse(raw);
    if (Number.isNaN(parsed)) return { error: `data inválida: "${raw}".` };
    instant = new Date(parsed);
  }

  const reference = now ?? new Date();
  // A minute of slack: the model reads "daqui a pouco" as the current minute
  // often enough, and rejecting that is pedantry the customer experiences as the
  // bot refusing to book them in.
  if (instant.getTime() < reference.getTime() - 60_000) {
    return { error: `a data ${raw} já passou.` };
  }
  if (instant.getTime() > reference.getTime() + MAX_HORIZON_DAYS * 86_400_000) {
    return { error: `a data ${raw} está a mais de ${MAX_HORIZON_DAYS} dias.` };
  }

  return { instant };
}

function text(value: unknown, max: number): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  return trimmed ? clamp(trimmed, max) : null;
}

function clamp(value: string, max: number): string {
  const trimmed = value.trim();
  return trimmed.length > max ? `${trimmed.slice(0, max - 1)}…` : trimmed;
}

function number(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  // Models write "30" as often as 30, and a schema violation this trivial is
  // not worth losing a booking over.
  if (typeof value === "string" && value.trim()) {
    const n = Number(value.trim());
    if (Number.isFinite(n)) return n;
  }
  return null;
}

/** A valid IANA zone name, or the conversation's, or null if even that is bad. */
function zone(value: unknown, fallback: string): string | null {
  const candidate =
    typeof value === "string" && value.trim() ? value.trim() : fallback;
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: candidate });
    return candidate;
  } catch {
    return null;
  }
}
