import test from "node:test";
import assert from "node:assert/strict";

import { parseAgentReply, type ParseContext } from "./reply.ts";
import type { Tool } from "../config.ts";

/**
 * These are the guardrails, not the happy path.
 *
 * Everything asserted here is something a model actually does: fenced JSON, a
 * cron that fires every minute, a booking in the past, a tool that does not
 * exist. The happy path is covered incidentally; the value is in the refusals.
 */

const TOOL: Tool = {
  name: "consultar_horarios",
  description: "Lista horários livres.",
  parameters: {
    data: { type: "string", description: "AAAA-MM-DD", required: true },
    tipo: {
      type: "enum",
      description: "o tipo",
      values: ["fisioterapia", "pilates"],
      required: true,
    },
    pessoas: { type: "number", description: "quantas" },
  },
  request: { method: "GET", path: "/agenda", query: ["data"] },
};

const NOW = new Date("2026-09-05T12:00:00Z");

const context: ParseContext = {
  timezone: "America/Sao_Paulo",
  tools: [TOOL],
  schedulingEnabled: true,
  now: NOW,
};

test("reads the envelope out of a fenced block", () => {
  const reply = parseAgentReply(
    'Claro!\n```json\n{"mensagem":"Oi!","acoes":[]}\n```',
    context,
  );
  assert.equal(reply.message, "Oi!");
  assert.deepEqual(reply.actions, []);
});

test("sends the prose when the model ignored the envelope entirely", () => {
  // The words are usually a perfectly good reply and only the structure is
  // missing. Losing the turn's actions beats leaving the customer on read.
  const reply = parseAgentReply("Bom dia! Como posso ajudar?", context);
  assert.equal(reply.message, "Bom dia! Como posso ajudar?");
  assert.deepEqual(reply.actions, []);
});

test("does not stop at a brace inside the message text", () => {
  const reply = parseAgentReply(
    '{"mensagem":"use as chaves {} assim","acoes":[]}',
    context,
  );
  assert.equal(reply.message, "use as chaves {} assim");
});

test("refuses a recurrence that would message every minute forever", () => {
  const reply = parseAgentReply(
    JSON.stringify({
      mensagem: "Vou te lembrar sempre!",
      acoes: [
        { tipo: "lembrete_recorrente", cron: "* * * * *", texto: "Oi!" },
      ],
    }),
    context,
  );
  assert.deepEqual(reply.actions, []);
  assert.match(reply.rejected[0] ?? "", /mínimo é 6h/);
});

test("refuses a recurrence that fires twice within the floor", () => {
  // `0 9,10 * * *` reads as a daily reminder if you look at the fields; it is
  // two fires an hour apart. Only sampling catches it.
  const reply = parseAgentReply(
    JSON.stringify({
      mensagem: "ok",
      acoes: [{ tipo: "lembrete_recorrente", cron: "0 9,10 * * *", texto: "Oi" }],
    }),
    context,
  );
  assert.deepEqual(reply.actions, []);
  assert.match(reply.rejected[0] ?? "", /dispara a cada 60 min/);
});

test("caps repetitions and defaults them when absent", () => {
  const many = parseAgentReply(
    JSON.stringify({
      mensagem: "ok",
      acoes: [
        { tipo: "lembrete_recorrente", cron: "0 9 * * 1", texto: "Oi", repeticoes: 500 },
      ],
    }),
    context,
  );
  const action = many.actions[0];
  assert.equal(action?.type, "lembrete_recorrente");
  assert.equal(action.type === "lembrete_recorrente" && action.maxRuns, 12);

  const none = parseAgentReply(
    JSON.stringify({
      mensagem: "ok",
      acoes: [{ tipo: "lembrete_recorrente", cron: "0 9 * * 1", texto: "Oi" }],
    }),
    context,
  );
  const fallback = none.actions[0];
  assert.equal(
    fallback?.type === "lembrete_recorrente" && fallback.maxRuns,
    4,
  );
});

test("refuses a booking in the past and one past the horizon", () => {
  const past = parseAgentReply(
    JSON.stringify({
      mensagem: "Marquei!",
      acoes: [{ tipo: "agendar", titulo: "Consulta", quando: "2020-01-01T10:00" }],
    }),
    context,
  );
  assert.deepEqual(past.actions, []);
  assert.match(past.rejected[0] ?? "", /já passou/);

  const far = parseAgentReply(
    JSON.stringify({
      mensagem: "Marquei!",
      acoes: [{ tipo: "agendar", titulo: "Consulta", quando: "2034-01-01T10:00" }],
    }),
    context,
  );
  assert.deepEqual(far.actions, []);
  assert.match(far.rejected[0] ?? "", /mais de 365 dias/);
});

test("reads a bare wall time in the conversation's timezone", () => {
  const reply = parseAgentReply(
    JSON.stringify({
      mensagem: "Marquei!",
      acoes: [{ tipo: "agendar", titulo: "Consulta", quando: "2026-09-10T14:00" }],
    }),
    context,
  );
  const action = reply.actions[0];
  assert.equal(action?.type, "agendar");
  // 14:00 in São Paulo (UTC-3) is 17:00Z. Not 14:00Z, which is what treating
  // the string as UTC would give and what would put the appointment three
  // hours out.
  assert.equal(
    action.type === "agendar" && action.startsAt,
    "2026-09-10T17:00:00.000Z",
  );
});

test("refuses scheduling entirely when the config turns it off", () => {
  const reply = parseAgentReply(
    JSON.stringify({
      mensagem: "Marquei!",
      acoes: [{ tipo: "agendar", titulo: "x", quando: "2026-09-10T14:00" }],
    }),
    { ...context, schedulingEnabled: false },
  );
  assert.deepEqual(reply.actions, []);
  assert.match(reply.rejected[0] ?? "", /não está habilitado/);
});

test("refuses a tool that does not exist, and names the ones that do", () => {
  const reply = parseAgentReply(
    JSON.stringify({
      mensagem: "",
      acoes: [{ tipo: "ferramenta", nome: "verificar_agenda", argumentos: {} }],
    }),
    context,
  );
  assert.deepEqual(reply.actions, []);
  // Naming the real tools is the correction that works: the usual cause is the
  // model inventing a plausible neighbour of one that exists.
  assert.match(reply.rejected[0] ?? "", /consultar_horarios/);
});

test("refuses a tool call missing a required argument", () => {
  const reply = parseAgentReply(
    JSON.stringify({
      mensagem: "",
      acoes: [
        {
          tipo: "ferramenta",
          nome: "consultar_horarios",
          argumentos: { data: "2026-09-10" },
        },
      ],
    }),
    context,
  );
  assert.deepEqual(reply.actions, []);
  assert.match(reply.rejected[0] ?? "", /Falta o parâmetro "tipo"/);
});

test("accepts a tool call and coerces a number written as a string", () => {
  const reply = parseAgentReply(
    JSON.stringify({
      mensagem: "",
      acoes: [
        {
          tipo: "ferramenta",
          nome: "consultar_horarios",
          argumentos: { data: "2026-09-10", tipo: "PILATES", pessoas: "2" },
        },
      ],
    }),
    context,
  );
  const action = reply.actions[0];
  assert.equal(action?.type, "ferramenta");
  if (action.type !== "ferramenta") return;
  assert.equal(action.args.pessoas, 2);
  // The declared spelling, not the model's. Otherwise the backend's own
  // validation depends on how it happened to capitalise it this time.
  assert.equal(action.args.tipo, "pilates");
});

test("refuses an enum value outside the list rather than guessing", () => {
  const reply = parseAgentReply(
    JSON.stringify({
      mensagem: "",
      acoes: [
        {
          tipo: "ferramenta",
          nome: "consultar_horarios",
          argumentos: { data: "2026-09-10", tipo: "quiropraxia" },
        },
      ],
    }),
    context,
  );
  assert.deepEqual(reply.actions, []);
  assert.match(reply.rejected[0] ?? "", /fisioterapia, pilates/);
});

test("caps how many actions one turn may carry", () => {
  const reply = parseAgentReply(
    JSON.stringify({
      mensagem: "ok",
      acoes: Array.from({ length: 9 }, () => ({
        tipo: "transferir",
        motivo: "x",
      })),
    }),
    context,
  );
  assert.equal(reply.actions.length, 4);
  assert.match(reply.rejected.at(-1) ?? "", /4 primeiras/);
});
