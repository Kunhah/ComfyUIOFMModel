import { environment } from "../config.ts";

/**
 * The providers, and what happens when one is down.
 *
 * A provider interface, one configuration per host, and a chain that tries them
 * in order. A chat that answers customers cannot be one provider's outage away
 * from silence, and Groq in particular rate-limits hard enough that a busy
 * afternoon will hit it — a 429 from Groq is not a 429 from OpenRouter.
 *
 * All three speak the OpenAI chat-completions shape, so this is one client with
 * three configurations rather than three clients. Order is fastest first: the
 * person is watching the "digitando…" while this runs.
 */

/**
 * A piece of a multimodal message.
 *
 * Only text and images, because those are the two the OpenAI chat-completions
 * shape agrees on across every provider in the chain. PDFs and documents are
 * turned into text *before* they get here (see `src/media/`) rather than sent as
 * a native file part: the providers disagree about that one, and a template
 * whose document support works on one of three keys is a template that breaks
 * on failover.
 */
export type ContentPart =
  | { type: "text"; text: string }
  | { type: "image_url"; image_url: { url: string } };

export type ChatMessage = {
  role: "system" | "user" | "assistant";
  content: string | ContentPart[];
};

export type Completion = {
  text: string;
  /** Which one actually answered. A changed env var is otherwise
   *  indistinguishable from a model that got worse. */
  model: string;
  provider: string;
  usage: { inputTokens: number; outputTokens: number } | null;
};

export class LlmError extends Error {}

/** Wall-clock budget for one completion. */
const TIMEOUT_MS = 30_000;

type Endpoint = {
  name: string;
  url: string;
  key: string;
  model: string;
  /** The vision-capable model on this provider, used when `vision` is asked for. */
  visionModel: string;
};

/** The chain, in the order it is tried. Absent keys are simply absent links. */
function endpoints(): Endpoint[] {
  const config = environment.llm();
  const chain: Endpoint[] = [];

  if (config.groqKey) {
    chain.push({
      name: "groq",
      url: `${config.groqUrl}/chat/completions`,
      key: config.groqKey,
      model: config.groqModel,
      visionModel: config.groqVisionModel,
    });
  }
  if (config.openrouterKey) {
    chain.push({
      name: "openrouter",
      url: `${config.openrouterUrl}/chat/completions`,
      key: config.openrouterKey,
      model: config.openrouterModel,
      visionModel: config.openrouterVisionModel,
    });
  }
  if (config.openaiKey) {
    chain.push({
      name: "openai",
      url: `${config.openaiUrl}/chat/completions`,
      key: config.openaiKey,
      model: config.openaiModel,
      visionModel: config.openaiVisionModel,
    });
  }
  return chain;
}

export function llmConfigured(): boolean {
  return endpoints().length > 0;
}

export type CompleteOptions = {
  /**
   * Ask the provider to guarantee syntactically valid JSON.
   *
   * The whole contract is a JSON envelope, and without this a model happily
   * wraps it in fences. `extractJson` survives that — it has to, because not
   * every model honours the flag — but a provider that enforces it turns a
   * recurring annoyance into a non-event.
   */
  json?: boolean;
  temperature?: number;
  maxTokens?: number;
  /**
   * Use each provider's vision model instead of its chat model.
   *
   * Asked for explicitly rather than inferred from the message content, because
   * the failure is silent in the worst way: a text-only model handed an image
   * part does not error, it answers confidently about nothing.
   */
  vision?: boolean;
};

/**
 * One completion, through the first provider that answers.
 *
 * Every failure is collected and only the last is thrown, with all of them in
 * the message: "Groq respondeu 429" alone sends someone to check a rate limit
 * when the real problem is that the OpenRouter key behind it expired too.
 */
export async function complete(
  messages: ChatMessage[],
  options: CompleteOptions = {},
): Promise<Completion> {
  const chain = endpoints();
  if (chain.length === 0) {
    throw new LlmError(
      "Nenhum modelo configurado (GROQ_API_KEY, OPENROUTER_API_KEY ou OPENAI_API_KEY).",
    );
  }

  const failures: string[] = [];

  for (const endpoint of chain) {
    try {
      return await callEndpoint(endpoint, messages, options);
    } catch (error) {
      failures.push(
        `${endpoint.name}: ${error instanceof Error ? error.message : String(error)}`,
      );
    }
  }

  throw new LlmError(`Nenhum provedor respondeu. ${failures.join(" | ")}`);
}

async function callEndpoint(
  endpoint: Endpoint,
  messages: ChatMessage[],
  options: CompleteOptions,
): Promise<Completion> {
  const response = await fetch(endpoint.url, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${endpoint.key}`,
    },
    body: JSON.stringify({
      model: options.vision ? endpoint.visionModel : endpoint.model,
      messages,
      temperature: options.temperature ?? 0.6,
      max_tokens: options.maxTokens ?? 900,
      ...(options.json ? { response_format: { type: "json_object" } } : {}),
    }),
    signal: AbortSignal.timeout(TIMEOUT_MS),
  });

  if (!response.ok) {
    const detail = (await response.text().catch(() => "")).slice(0, 300);
    throw new LlmError(`respondeu ${response.status}${detail ? ` — ${detail}` : ""}`);
  }

  const body = (await response.json()) as {
    choices?: { message?: { content?: string } }[];
    usage?: { prompt_tokens?: number; completion_tokens?: number };
  };

  const text = body.choices?.[0]?.message?.content;
  if (typeof text !== "string" || !text.trim()) {
    // A 200 with an empty choice is a real thing — a content filter, a model
    // that produced only a refusal token. Treated as a failure so the chain
    // moves on rather than returning an empty reply to a customer.
    throw new LlmError("respondeu sem conteúdo.");
  }

  return {
    text,
    model: endpoint.model,
    provider: endpoint.name,
    usage: body.usage
      ? {
          inputTokens: body.usage.prompt_tokens ?? 0,
          outputTokens: body.usage.completion_tokens ?? 0,
        }
      : null,
  };
}
