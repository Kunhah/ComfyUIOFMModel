/**
 * Getting a JSON object out of whatever the model actually sent.
 *
 * Models wrap the envelope in ```json fences, write a sentence before it, or
 * append "Espero ter ajudado!" after the closing brace — all three happen even
 * with `response_format: json_object` on, because not every model behind every
 * provider honours the flag. One implementation of "extract the object from
 * inside the noise" rather than one per caller: two would be two sets of edge
 * cases to discover separately, in production, months apart.
 */
export function extractJson(raw: string): Record<string, unknown> | null {
  const text = raw.trim();
  if (!text) return null;

  // The common case: it did what it was told.
  const direct = parse(text);
  if (direct) return direct;

  // A fenced block, with or without a language tag.
  const fenced = /```(?:json)?\s*([\s\S]*?)```/i.exec(text);
  if (fenced?.[1]) {
    const inside = parse(fenced[1].trim());
    if (inside) return inside;
  }

  // Last resort: the outermost brace pair. Scanned with a depth counter and not
  // by a regex, because the envelope's own nested objects — an action carrying
  // arguments — make a lazy `\{.*\}` stop at the first inner closing brace and a
  // greedy one swallow a trailing sentence.
  const start = text.indexOf("{");
  if (start < 0) return null;

  let depth = 0;
  let inString = false;
  let escaped = false;

  for (let i = start; i < text.length; i += 1) {
    const char = text[i]!;

    if (escaped) {
      escaped = false;
      continue;
    }
    if (char === "\\") {
      escaped = true;
      continue;
    }
    if (char === '"') {
      inString = !inString;
      continue;
    }
    // Braces inside a string are text — a message that says "{}" would otherwise
    // close the object early and lose everything after it.
    if (inString) continue;

    if (char === "{") depth += 1;
    else if (char === "}") {
      depth -= 1;
      if (depth === 0) return parse(text.slice(start, i + 1));
    }
  }

  return null;
}

function parse(candidate: string): Record<string, unknown> | null {
  try {
    const value = JSON.parse(candidate) as unknown;
    // An array or a bare string is not an envelope. Returning one would make
    // every field read as undefined, which downstream looks like a model that
    // answered nothing rather than one that answered in the wrong shape.
    return value && typeof value === "object" && !Array.isArray(value)
      ? (value as Record<string, unknown>)
      : null;
  } catch {
    return null;
  }
}
