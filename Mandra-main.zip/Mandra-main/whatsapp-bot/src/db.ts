import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { environment } from "./config.ts";

/**
 * Everything the bot remembers, in one SQLite file.
 *
 * `node:sqlite` is a Node builtin, so this costs no dependency and no service.
 * That matters more than it sounds: the thing being stored is the transcript of
 * conversations with real people plus a queue of messages that will be sent to
 * them next week, and both have to survive a restart. An in-process Map is
 * lost on every deploy, and a reminder that evaporates on restart is worse than
 * one that never existed — the person was told it was coming.
 *
 * The transcript is also the agent's memory. There is no conversation state in
 * the process, so two copies of this server answer identically and a deploy
 * mid-conversation leaves the thread intact.
 */

let database: DatabaseSync | null = null;

export function db(): DatabaseSync {
  if (database) return database;

  const file = environment.dbPath();
  mkdirSync(path.dirname(path.resolve(file)), { recursive: true });

  database = new DatabaseSync(file);
  // WAL: the webhook writes while the scheduler tick reads, and the default
  // rollback journal turns that into "database is locked" under any real load.
  database.exec("PRAGMA journal_mode = WAL");
  database.exec("PRAGMA foreign_keys = ON");
  database.exec("PRAGMA busy_timeout = 5000");
  database.exec(SCHEMA);
  addMissingColumns(database);
  widenMessageKinds(database);
  database.exec(INDEXES);
  return database;
}

/**
 * The transcript table.
 *
 * A function for the same reason `conversationsDdl` is: `widenMessageKinds()`
 * has to build this very table under a scratch name, and writing the DDL twice
 * is how a rebuilt table ends up a column behind the one fresh databases get —
 * on the machines nobody tests.
 */
const messagesDdl = (table: string) => `
  CREATE TABLE IF NOT EXISTS ${table} (
    id              INTEGER PRIMARY KEY,
    conversation_id TEXT NOT NULL
                    REFERENCES conversations (id) ON DELETE CASCADE,
    direction       TEXT NOT NULL CHECK (direction IN ('in','out')),
    origin          TEXT NOT NULL DEFAULT 'client'
                    CHECK (origin IN ('agent','job','operator','client')),
    -- What the body actually is. Anything but 'text' means we *derived* it from
    -- a file — a transcription, a description, an extraction — rather than the
    -- person having typed it. The agent is told which, because answering a voice
    -- note as if it were typed loses the cue that a voice note back is welcome,
    -- and answering a video as if it had been watched is worse than saying only
    -- the audio was heard.
    kind            TEXT NOT NULL DEFAULT 'text'
                    CHECK (kind IN ('text','audio','image','video','document','other')),
    body            TEXT NOT NULL,
    -- The provider's own message id. UNIQUE, and it is the entire idempotency
    -- story: the bridge retries a webhook it reads as failed, and without this
    -- the same message is answered twice.
    provider_id     TEXT UNIQUE,
    -- Seconds, on audio and video. Shown to the agent, because "mandou um áudio
    -- de dois minutos" and "de três segundos" are different turns.
    duration_s      INTEGER,
    status          TEXT NOT NULL DEFAULT 'ok' CHECK (status IN ('ok','failed')),
    error           TEXT,
    job_id          TEXT REFERENCES jobs (id) ON DELETE SET NULL,
    created_at      TEXT NOT NULL
                    DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
  );
`;

const SCHEMA = `
  -- One row per number we have ever talked to.
  CREATE TABLE IF NOT EXISTS conversations (
    id            TEXT PRIMARY KEY,
    -- Bare E.164 digits. UNIQUE: a second thread for one number is not a second
    -- conversation, it is a split history that guarantees the agent answers with
    -- half its context missing.
    phone         TEXT NOT NULL UNIQUE,
    contact_name  TEXT,
    -- The handoff switch. An operator who takes over turns this off and the bot
    -- stops answering. A column rather than a setting because a human and a
    -- model both answering is the most embarrassing thing this can do in front
    -- of a customer.
    auto_reply    INTEGER NOT NULL DEFAULT 1,
    timezone      TEXT,
    -- Whatever your backend told us about this person, as JSON. Injected into
    -- the prompt so the bot opens knowing who it is talking to.
    profile       TEXT,
    last_inbound_at  TEXT,
    last_outbound_at TEXT,
    created_at    TEXT NOT NULL
                  DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
  );

  -- The transcript, and the agent's memory.
${messagesDdl("messages")}

  -- The scheduler's queue. 'once' is a moment; 'cron' is a recurrence kept as
  -- the expression rather than as expanded rows.
  CREATE TABLE IF NOT EXISTS jobs (
    id              TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL
                    REFERENCES conversations (id) ON DELETE CASCADE,
    kind            TEXT NOT NULL CHECK (kind IN ('once','cron')),
    cron            TEXT,
    -- IANA name, never an offset: an offset is wrong twice a year in half the
    -- world, and a reminder is a wall-clock promise.
    timezone        TEXT NOT NULL,
    -- Rendered when the job is created, not at send time, so what is on the
    -- schedule screen is exactly what the person will receive.
    body            TEXT NOT NULL,
    reason          TEXT,
    created_by      TEXT NOT NULL DEFAULT 'agent',
    next_run_at     TEXT,
    runs            INTEGER NOT NULL DEFAULT 0,
    -- Mandatory on a recurrence. A repeat with no end is a subscription nobody
    -- agreed to, and nothing in a chat cancels it — they block the number.
    max_runs        INTEGER,
    active          INTEGER NOT NULL DEFAULT 1,
    closed_reason   TEXT,
    last_error      TEXT,
    created_at      TEXT NOT NULL
                    DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
  );

  CREATE TABLE IF NOT EXISTS appointments (
    id              TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL
                    REFERENCES conversations (id) ON DELETE CASCADE,
    title           TEXT NOT NULL,
    starts_at       TEXT NOT NULL,
    timezone        TEXT NOT NULL,
    duration_min    INTEGER NOT NULL,
    notes           TEXT,
    created_by      TEXT NOT NULL DEFAULT 'agent',
    created_at      TEXT NOT NULL
                    DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
  );

  -- Every backend call the model asked for, whether or not it was allowed.
  -- The refusals are the valuable half: they are how you find out the model is
  -- reaching for a tool that does not fit, which reads as a broken bot long
  -- before anything appears in your backend's own logs.
  CREATE TABLE IF NOT EXISTS tool_calls (
    id              INTEGER PRIMARY KEY,
    conversation_id TEXT NOT NULL
                    REFERENCES conversations (id) ON DELETE CASCADE,
    tool            TEXT NOT NULL,
    arguments       TEXT,
    ok              INTEGER NOT NULL,
    status          INTEGER,
    result          TEXT,
    error           TEXT,
    duration_ms     INTEGER,
    created_at      TEXT NOT NULL
                    DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
  );
`;

/**
 * Additive migrations only, applied before the indexes.
 *
 * The table DDL above is `CREATE TABLE IF NOT EXISTS`, so it does nothing to a
 * database that already exists — a new column has to arrive here or it never
 * reaches a running deployment. Additive only, because people are told they can
 * keep the file.
 */
function addMissingColumns(handle: DatabaseSync): void {
  const columns = (table: string): Set<string> =>
    new Set(
      handle
        .prepare(`PRAGMA table_info(${table})`)
        .all()
        .map((row) => String((row as { name: unknown }).name)),
    );

  const wanted: Record<string, Record<string, string>> = {
    conversations: { profile: "TEXT" },
    messages: { kind: "TEXT NOT NULL DEFAULT 'text'", duration_s: "INTEGER" },
  };

  for (const [table, cols] of Object.entries(wanted)) {
    const present = columns(table);
    for (const [name, type] of Object.entries(cols)) {
      if (!present.has(name)) {
        handle.exec(`ALTER TABLE ${table} ADD COLUMN ${name} ${type}`);
      }
    }
  }
}

/**
 * Widens `messages.kind` on a database built before video and documents existed.
 *
 * A CHECK constraint cannot be ALTERed and the table DDL is `CREATE TABLE IF NOT
 * EXISTS`, so neither of the ordinary migration paths reaches an existing file —
 * and the failure is not cosmetic: the old constraint rejects a row with
 * kind='document', which means the first PDF anyone sends is lost with a
 * constraint error where an answer should have been.
 *
 * So this is a real rebuild, in SQLite's documented order: build under a scratch
 * name, copy, drop, rename into place. Two details that are load-bearing:
 *
 * - Nothing has a foreign key *into* `messages`, so the rename cannot repoint a
 *   child at the scratch table — which is the trap that makes rebuilding
 *   `conversations` a much longer story.
 * - `PRAGMA foreign_keys` cannot change inside a transaction, so it is toggled
 *   around the BEGIN rather than within it. `messages` points *at* two parents,
 *   and leaving enforcement on during the drop would take the copy with it.
 *
 * A no-op on a fresh database and on one already migrated, which is what makes
 * it safe to run on every boot.
 */
function widenMessageKinds(handle: DatabaseSync): void {
  const row = handle
    .prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='messages'")
    .get() as { sql: string | null } | undefined;

  const ddl = row?.sql ?? "";
  // Absent means the table is about to be created by SCHEMA with the current
  // definition; present-and-widened means somebody already ran this.
  if (!ddl || ddl.includes("'document'")) return;

  const wasOn = (
    handle.prepare("PRAGMA foreign_keys").get() as
      | { foreign_keys: number }
      | undefined
  )?.foreign_keys;

  handle.exec("PRAGMA foreign_keys = OFF");
  try {
    handle.exec("BEGIN IMMEDIATE");
    handle.exec(messagesDdl("messages_rebuilt"));
    // Columns named explicitly. `INSERT INTO ... SELECT *` binds by position,
    // so it silently shifts every value one column left the day the two
    // definitions differ — which is the day you are running this.
    handle.exec(`
      INSERT INTO messages_rebuilt
        (id, conversation_id, direction, origin, kind, body, provider_id,
         duration_s, status, error, job_id, created_at)
      SELECT
         id, conversation_id, direction, origin, kind, body, provider_id,
         duration_s, status, error, job_id, created_at
        FROM messages
    `);
    handle.exec("DROP TABLE messages");
    handle.exec("ALTER TABLE messages_rebuilt RENAME TO messages");
    handle.exec("COMMIT");
  } catch (error) {
    handle.exec("ROLLBACK");
    throw error;
  } finally {
    handle.exec(`PRAGMA foreign_keys = ${wasOn === 0 ? "OFF" : "ON"}`);
  }
}

/**
 * Applied after `addMissingColumns`, never with the table.
 *
 * `CREATE INDEX` on a column an older database lacks throws, and that aborts the
 * whole schema statement before the column can be added — the table then stays a
 * migration behind and every write fails on a column that does not exist.
 */
const INDEXES = `
  CREATE INDEX IF NOT EXISTS idx_messages_conversation
    ON messages (conversation_id, id DESC);
  CREATE INDEX IF NOT EXISTS idx_jobs_due
    ON jobs (active, next_run_at);
  CREATE INDEX IF NOT EXISTS idx_tool_calls_conversation
    ON tool_calls (conversation_id, id DESC);
`;

/* -------------------------------------------------------------------------- */
/* Conversations                                                               */
/* -------------------------------------------------------------------------- */

export type Conversation = {
  id: string;
  phone: string;
  contactName: string | null;
  autoReply: boolean;
  timezone: string | null;
  profile: Record<string, unknown> | null;
  lastInboundAt: string | null;
  lastOutboundAt: string | null;
  createdAt: string;
};

type ConversationRow = {
  id: string;
  phone: string;
  contact_name: string | null;
  auto_reply: number;
  timezone: string | null;
  profile: string | null;
  last_inbound_at: string | null;
  last_outbound_at: string | null;
  created_at: string;
};

function toConversation(row: ConversationRow): Conversation {
  let profile: Record<string, unknown> | null = null;
  if (row.profile) {
    // A malformed blob is not worth failing a customer's message over; the
    // prompt simply carries less context that turn.
    try {
      profile = JSON.parse(row.profile) as Record<string, unknown>;
    } catch {
      profile = null;
    }
  }
  return {
    id: row.id,
    phone: row.phone,
    contactName: row.contact_name,
    autoReply: row.auto_reply === 1,
    timezone: row.timezone,
    profile,
    lastInboundAt: row.last_inbound_at,
    lastOutboundAt: row.last_outbound_at,
    createdAt: row.created_at,
  };
}

export function conversationById(id: string): Conversation | null {
  const row = db()
    .prepare("SELECT * FROM conversations WHERE id = ?")
    .get(id) as ConversationRow | undefined;
  return row ? toConversation(row) : null;
}

export function findConversation(phone: string): Conversation | null {
  const row = db()
    .prepare("SELECT * FROM conversations WHERE phone = ?")
    .get(phone) as ConversationRow | undefined;
  return row ? toConversation(row) : null;
}

/** Finds the thread for a number, or starts one. */
export function openConversation(input: {
  phone: string;
  contactName?: string | null;
  timezone?: string | null;
}): Conversation {
  const existing = findConversation(input.phone);
  if (existing) {
    // A display name can appear or change after the first message, and the
    // greeting reads wrong for months if the first blank one is kept forever.
    if (input.contactName && input.contactName !== existing.contactName) {
      db()
        .prepare("UPDATE conversations SET contact_name = ? WHERE id = ?")
        .run(input.contactName, existing.id);
      return { ...existing, contactName: input.contactName };
    }
    return existing;
  }

  const id = randomUUID();
  db()
    .prepare(
      `INSERT INTO conversations (id, phone, contact_name, timezone)
       VALUES (?, ?, ?, ?)`,
    )
    .run(id, input.phone, input.contactName ?? null, input.timezone ?? null);
  return conversationById(id)!;
}

export function setAutoReply(id: string, on: boolean): void {
  db()
    .prepare("UPDATE conversations SET auto_reply = ? WHERE id = ?")
    .run(on ? 1 : 0, id);
}

export function setProfile(
  id: string,
  profile: Record<string, unknown> | null,
): void {
  db()
    .prepare("UPDATE conversations SET profile = ? WHERE id = ?")
    .run(profile ? JSON.stringify(profile) : null, id);
}

export function listConversations(limit = 100): Conversation[] {
  return (
    db()
      .prepare(
        `SELECT * FROM conversations
          ORDER BY COALESCE(last_inbound_at, created_at) DESC LIMIT ?`,
      )
      .all(limit) as ConversationRow[]
  ).map(toConversation);
}

/* -------------------------------------------------------------------------- */
/* Messages                                                                    */
/* -------------------------------------------------------------------------- */

export type MessageOrigin = "agent" | "job" | "operator" | "client";
export type MessageKind =
  | "text"
  | "audio"
  | "image"
  | "video"
  | "document"
  | "other";

export type Message = {
  id: number;
  conversationId: string;
  direction: "in" | "out";
  origin: MessageOrigin;
  kind: MessageKind;
  body: string;
  durationSeconds: number | null;
  status: "ok" | "failed";
  error: string | null;
  createdAt: string;
};

type MessageRow = {
  id: number;
  conversation_id: string;
  direction: "in" | "out";
  origin: MessageOrigin;
  kind: MessageKind;
  body: string;
  duration_s: number | null;
  status: "ok" | "failed";
  error: string | null;
  created_at: string;
};

function toMessage(row: MessageRow): Message {
  return {
    id: row.id,
    conversationId: row.conversation_id,
    direction: row.direction,
    origin: row.origin,
    kind: row.kind ?? "text",
    body: row.body,
    durationSeconds: row.duration_s,
    status: row.status,
    error: row.error,
    createdAt: row.created_at,
  };
}

/**
 * Writes a message to the transcript, or returns null when it is a replay.
 *
 * Null on a duplicate `provider_id` is the point, and callers must check it
 * rather than assume a write happened: the bridge retries a webhook it reads as
 * failed, and answering the retry sends the customer a second reply to a
 * message they sent once.
 */
export function recordMessage(input: {
  conversationId: string;
  direction: "in" | "out";
  origin: MessageOrigin;
  body: string;
  kind?: MessageKind;
  providerId?: string | null;
  durationSeconds?: number | null;
  status?: "ok" | "failed";
  error?: string | null;
  jobId?: string | null;
}): Message | null {
  try {
    const result = db()
      .prepare(
        `INSERT INTO messages
           (conversation_id, direction, origin, kind, body, provider_id,
            duration_s, status, error, job_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        input.conversationId,
        input.direction,
        input.origin,
        input.kind ?? "text",
        input.body,
        input.providerId ?? null,
        input.durationSeconds ?? null,
        input.status ?? "ok",
        input.error ?? null,
        input.jobId ?? null,
      );

    const column =
      input.direction === "in" ? "last_inbound_at" : "last_outbound_at";
    db()
      .prepare(
        `UPDATE conversations
            SET ${column} = strftime('%Y-%m-%dT%H:%M:%fZ','now')
          WHERE id = ?`,
      )
      .run(input.conversationId);

    const row = db()
      .prepare("SELECT * FROM messages WHERE id = ?")
      .get(result.lastInsertRowid as number) as MessageRow;
    return toMessage(row);
  } catch (error) {
    // The UNIQUE on provider_id firing means we have seen this message. Any
    // other failure is a real one and must not be swallowed as a replay.
    if (String(error).includes("UNIQUE") && input.providerId) return null;
    throw error;
  }
}

/** The last `limit` messages, oldest first. */
export function recentMessages(
  conversationId: string,
  limit: number,
): Message[] {
  const rows = db()
    .prepare(
      `SELECT * FROM messages WHERE conversation_id = ?
        ORDER BY id DESC LIMIT ?`,
    )
    .all(conversationId, limit) as MessageRow[];
  return rows.reverse().map(toMessage);
}

/** The newest inbound message's id, for the debounce check in `humanize.ts`. */
export function lastInboundId(conversationId: string): number | null {
  const row = db()
    .prepare(
      `SELECT id FROM messages
        WHERE conversation_id = ? AND direction = 'in'
        ORDER BY id DESC LIMIT 1`,
    )
    .get(conversationId) as { id: number } | undefined;
  return row?.id ?? null;
}

export function recordToolCall(input: {
  conversationId: string;
  tool: string;
  arguments: unknown;
  ok: boolean;
  status?: number | null;
  result?: string | null;
  error?: string | null;
  durationMs?: number | null;
}): void {
  db()
    .prepare(
      `INSERT INTO tool_calls
         (conversation_id, tool, arguments, ok, status, result, error, duration_ms)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      input.conversationId,
      input.tool,
      JSON.stringify(input.arguments ?? null),
      input.ok ? 1 : 0,
      input.status ?? null,
      input.result?.slice(0, 4000) ?? null,
      input.error?.slice(0, 1000) ?? null,
      input.durationMs ?? null,
    );
}

/* -------------------------------------------------------------------------- */
/* Jobs                                                                        */
/* -------------------------------------------------------------------------- */

export type JobKind = "once" | "cron";

export type Job = {
  id: string;
  conversationId: string;
  kind: JobKind;
  cron: string | null;
  timezone: string;
  body: string;
  reason: string | null;
  createdBy: string;
  nextRunAt: string | null;
  runs: number;
  maxRuns: number | null;
  active: boolean;
  closedReason: string | null;
  lastError: string | null;
};

type JobRow = {
  id: string;
  conversation_id: string;
  kind: JobKind;
  cron: string | null;
  timezone: string;
  body: string;
  reason: string | null;
  created_by: string;
  next_run_at: string | null;
  runs: number;
  max_runs: number | null;
  active: number;
  closed_reason: string | null;
  last_error: string | null;
};

function toJob(row: JobRow): Job {
  return {
    id: row.id,
    conversationId: row.conversation_id,
    kind: row.kind,
    cron: row.cron,
    timezone: row.timezone,
    body: row.body,
    reason: row.reason,
    createdBy: row.created_by,
    nextRunAt: row.next_run_at,
    runs: row.runs,
    maxRuns: row.max_runs,
    active: row.active === 1,
    closedReason: row.closed_reason,
    lastError: row.last_error,
  };
}

export function createJob(input: {
  conversationId: string;
  kind: JobKind;
  cron?: string | null;
  timezone: string;
  body: string;
  reason?: string | null;
  createdBy?: string;
  nextRunAt: string | null;
  maxRuns?: number | null;
}): Job {
  const id = randomUUID();
  db()
    .prepare(
      `INSERT INTO jobs
         (id, conversation_id, kind, cron, timezone, body, reason, created_by,
          next_run_at, max_runs)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      id,
      input.conversationId,
      input.kind,
      input.cron ?? null,
      input.timezone,
      input.body,
      input.reason ?? null,
      input.createdBy ?? "agent",
      input.nextRunAt,
      input.maxRuns ?? null,
    );
  return jobById(id)!;
}

export function jobById(id: string): Job | null {
  const row = db().prepare("SELECT * FROM jobs WHERE id = ?").get(id) as
    | JobRow
    | undefined;
  return row ? toJob(row) : null;
}

export function jobsFor(conversationId: string): Job[] {
  return (
    db()
      .prepare(
        "SELECT * FROM jobs WHERE conversation_id = ? ORDER BY next_run_at",
      )
      .all(conversationId) as JobRow[]
  ).map(toJob);
}

/** Everything due now. `active` and a past `next_run_at`; ordered oldest first. */
export function dueJobs(now: Date, limit = 50): Job[] {
  return (
    db()
      .prepare(
        `SELECT * FROM jobs
          WHERE active = 1 AND next_run_at IS NOT NULL AND next_run_at <= ?
          ORDER BY next_run_at LIMIT ?`,
      )
      .all(now.toISOString(), limit) as JobRow[]
  ).map(toJob);
}

export function advanceJob(
  id: string,
  next: { nextRunAt: string | null; runs: number; error?: string | null },
): void {
  db()
    .prepare(
      `UPDATE jobs SET next_run_at = ?, runs = ?, last_error = ? WHERE id = ?`,
    )
    .run(next.nextRunAt, next.runs, next.error ?? null, id);
}

export function closeJob(id: string, reason: string): void {
  db()
    .prepare(
      `UPDATE jobs SET active = 0, next_run_at = NULL, closed_reason = ?
        WHERE id = ?`,
    )
    .run(reason, id);
}

/** Closes every live job on a thread. Returns how many. */
export function cancelJobs(conversationId: string, reason: string): number {
  const result = db()
    .prepare(
      `UPDATE jobs SET active = 0, next_run_at = NULL, closed_reason = ?
        WHERE conversation_id = ? AND active = 1`,
    )
    .run(reason, conversationId);
  return Number(result.changes);
}

export function createAppointment(input: {
  conversationId: string;
  title: string;
  startsAt: string;
  timezone: string;
  durationMinutes: number;
  notes?: string | null;
  createdBy?: string;
}): { id: string } {
  const id = randomUUID();
  db()
    .prepare(
      `INSERT INTO appointments
         (id, conversation_id, title, starts_at, timezone, duration_min, notes, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      id,
      input.conversationId,
      input.title,
      input.startsAt,
      input.timezone,
      input.durationMinutes,
      input.notes ?? null,
      input.createdBy ?? "agent",
    );
  return { id };
}
