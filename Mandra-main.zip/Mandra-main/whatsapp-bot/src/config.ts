/**
 * The shape of `bot.config.ts`, and the environment around it.
 *
 * The split is deliberate and it is the whole idea of this template: the config
 * file is *what this bot is* — who it says it is, what it may do, which backend
 * it calls — and the environment is *where this copy runs* — keys, URLs, the
 * paired number. One is committed and reviewed, the other is a secret per host.
 * Putting a persona in an env var is how a client's assistant ends up
 * undocumented in a dashboard nobody reads; putting an API key in the config is
 * how it ends up in git.
 */

/* -------------------------------------------------------------------------- */
/* Tools: what the bot can do to your backend                                  */
/* -------------------------------------------------------------------------- */

/**
 * One parameter of a tool.
 *
 * Deliberately tiny — not JSON Schema. Everything here has to be explained to a
 * model in a prompt *and* validated against what it sends back, and a schema
 * language rich enough to express `oneOf` is a schema language whose validator
 * has bugs the model will find. Four types cover every backend call this thing
 * has any business making.
 */
export type ToolParam = {
  type: "string" | "number" | "boolean" | "enum";
  /** Written *for the model*. It is the only thing it knows about this field. */
  description: string;
  required?: boolean;
  /** For `enum`. Anything outside the list is refused, never coerced. */
  values?: string[];
  /** For `string`. Defaults to 200; the value reaches your backend. */
  maxLength?: number;
};

export type ToolRequest = {
  method: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
  /**
   * Path under `BACKEND_URL`. `{nome}` is replaced with the argument of that
   * name, URL-encoded.
   *
   * A path is a template with holes, never a string the model writes: given the
   * whole path it will eventually write `/admin/users` because a customer asked
   * it nicely, and the request would carry your service token.
   */
  path: string;
  /** Argument names to send as a query string. */
  query?: string[];
  /** Argument names to send as a JSON body. Ignored on GET. */
  body?: string[];
  /**
   * Constants merged into the body. For the fields your backend needs and the
   * model must not choose — `source: "whatsapp"`, an account id, a channel.
   */
  fixedBody?: Record<string, unknown>;
};

export type Tool = {
  /** Snake case, in the prompt's language. The model writes this string back. */
  name: string;
  /**
   * What it does and *when to use it*, for the model. The second half is the
   * part people leave out and it is the half that decides whether the tool is
   * called at the right moment or every turn.
   */
  description: string;
  parameters: Record<string, ToolParam>;
  request: ToolRequest;
  /**
   * Whether the person must have agreed before this runs.
   *
   * The line is whether the call changes something on their side. Reading an
   * order status is free; cancelling it is not, and a model that is asked "posso
   * cancelar?" reads a question as permission often enough that this cannot be
   * left to the prompt. Refused actions come back to the model as a rejection.
   */
  confirm?: boolean;
  /**
   * What the person sees while this runs, if anything. A backend call that takes
   * three seconds inside a chat that is otherwise instant reads as a hang.
   */
  pending?: string;
};

/* -------------------------------------------------------------------------- */
/* Media                                                                       */
/* -------------------------------------------------------------------------- */

/**
 * What the bot is allowed to open when someone sends a file.
 *
 * Every one of these is off-by-choice rather than off-by-default-because-it-is-
 * hard: reading a customer's documents is a capability, and a business that
 * receives medical exams or ID scans may well want the bot to say "manda pro
 * time" instead of describing them to a vision model. Turn on what the business
 * actually needs.
 */
export type MediaConfig = {
  /** Read images with a vision model. Off means the bot says it cannot see. */
  images: boolean;
  /** Read PDFs, spreadsheets, documents and plain-text files. */
  documents: boolean;
  /**
   * Transcribe the speech in a video.
   *
   * Only the speech. Nothing here looks at the picture, and the bot is told so —
   * a video answered as if it had been watched is worse than one that was not.
   */
  video: boolean;
  /**
   * Biggest file to even download, in bytes.
   *
   * WhatsApp itself caps documents at 100 MB. This is smaller on purpose: the
   * bytes cross the network twice and a 90 MB PDF is not a question, it is an
   * archive.
   */
  maxBytes: number;
  /** Pages of a PDF actually read. The rest is reported, never silently dropped. */
  maxPdfPages: number;
  /**
   * Characters of extracted text that reach the prompt.
   *
   * A 40-page contract would otherwise spend the whole context window, and the
   * answer after it is worse for every token of it.
   */
  maxChars: number;
  /** What to say about a file this bot will not open. */
  unsupported?: string;
};

/* -------------------------------------------------------------------------- */
/* Voice                                                                       */
/* -------------------------------------------------------------------------- */

export type VoiceConfig = {
  /**
   * When to answer with a voice note.
   *
   * `espelho` (the default) answers audio with audio and text with text, which
   * is what a person does. `sempre` is almost always wrong: a voice note with a
   * phone number or a link in it is a voice note the person has to transcribe by
   * hand, so even in `sempre` anything matching `textOnly` below goes as text.
   */
  reply: "nunca" | "espelho" | "sempre";
  /** ElevenLabs voice id. */
  voiceId: string;
  modelId?: string;
  /** 0-1. Higher is steadier and flatter; lower is more expressive and less predictable. */
  stability?: number;
  similarityBoost?: number;
  /** ElevenLabs' own pacing hint, -1 to 1. Slightly slow reads as calm on WhatsApp. */
  speed?: number;
  /**
   * Replies longer than this go as text however they were asked.
   *
   * A ninety-second voice note is not an answer, it is a chore. The number is
   * characters because that is what we have before the audio exists.
   */
  maxChars?: number;
};

/* -------------------------------------------------------------------------- */
/* Behaviour                                                                   */
/* -------------------------------------------------------------------------- */

export type HumanConfig = {
  /**
   * How long to wait for the person to stop typing before answering.
   *
   * People send three short messages, not one long one. Answering the first
   * while the second is being typed is the single clearest tell that there is a
   * machine on the other end — and it also answers a question that was still
   * being asked. See `humanize.ts`.
   */
  debounceMs: number;
  /** Reading takes a moment. The pause before "digitando…" starts. */
  readDelayMs: [number, number];
  /** Characters per second while "typing". A fast human types ~12. */
  typingCps: number;
  /** Floor and ceiling on the typing pause, whatever the length says. */
  typingMs: [number, number];
  /**
   * Split replies into separate bubbles at sentence ends.
   *
   * One paragraph is an email. Two or three short bubbles with a pause between
   * them is how the medium is actually used.
   */
  splitBubbles: boolean;
  maxBubbles: number;
  /** Random ±fraction applied to every delay, so the rhythm is not identical. */
  jitter: number;
};

export type HoursConfig = {
  /** IANA zone the hours below are read in. */
  timezone: string;
  /** `[open, close]` in 24h local time, per weekday (0 = Sunday). Null is closed. */
  week: Array<[number, number] | null>;
  /**
   * What happens to a message that arrives out of hours.
   *
   * `responder` answers anyway (right for a bot that only answers questions);
   * `avisar` sends the note below and holds the rest for opening time;
   * `silencio` stores it and says nothing, which is the honest option for a bot
   * whose every useful answer needs a person.
   */
  outside: "responder" | "avisar" | "silencio";
  notice?: string;
};

export type BotConfig = {
  /** Used in logs and in the default handoff note. */
  name: string;
  /** IANA zone the bot schedules in. Never the container's — that is UTC. */
  timezone: string;
  /** Language of the prompt and the replies, as a name the model understands. */
  language: string;

  persona: {
    /** Who it is. First person, one paragraph. */
    identity: string;
    /** What it is for, and what it must refuse. Bullets. */
    role: string;
    /** Tone, length, punctuation. The part people under-specify. */
    style: string;
    /**
     * Extra rules on top of the non-negotiable ones in `prompt.ts`.
     *
     * Those cannot be dropped from here — never invent a price, never ask for a
     * password, never claim to be human — because a brief written by a client is
     * exactly where they would go missing.
     */
    rules?: string[];
    /** The opening line for a number that has never written before. */
    greeting?: string;
  };

  /** Answers the bot may give verbatim. Cheaper and steadier than a prompt line. */
  faq?: Array<{ q: string; a: string }>;

  tools: Tool[];
  media: MediaConfig;
  voice: VoiceConfig;
  human: HumanConfig;
  hours?: HoursConfig;

  scheduling: {
    /** Whether the bot may book appointments and set reminders at all. */
    enabled: boolean;
    /** Minutes before an appointment to send a reminder. */
    reminderOffsets: number[];
    defaultDurationMinutes: number;
  };

  handoff: {
    /** Sent when the bot hands the thread to a person. */
    message: string;
    /** Optional webhook told that a human is needed. */
    notifyPath?: string;
  };
};

/* -------------------------------------------------------------------------- */
/* Environment                                                                 */
/* -------------------------------------------------------------------------- */

function env(name: string): string | null {
  const value = process.env[name]?.trim();
  return value ? value : null;
}

function required(name: string): string {
  const value = env(name);
  if (!value) throw new Error(`Falta a variável de ambiente ${name}.`);
  return value;
}

export const environment = {
  port: Number(env("PORT") ?? 28528),
  /** Public URL of *this* server, used to build the webhook Evolution calls. */
  publicUrl: () => env("PUBLIC_URL"),
  dbPath: () => env("BOT_DB") ?? "data/bot.db",

  evolution: () => {
    const baseUrl = env("EVOLUTION_API_URL")?.replace(/\/+$/, "");
    const apiKey = env("EVOLUTION_API_KEY");
    const instance = env("EVOLUTION_INSTANCE");
    if (!baseUrl || !apiKey || !instance) return null;
    return { baseUrl, apiKey, instance };
  },
  /**
   * Authenticates the bridge *to us*. Deliberately a different value from the
   * API key, which authenticates us to the bridge: one value for both directions
   * means leaking the bridge also hands over the ability to post fabricated
   * customer messages into this bot.
   */
  webhookSecret: () => env("EVOLUTION_WEBHOOK_SECRET"),

  /**
   * The model chain. Each `*_BASE_URL` exists so a copy can be pointed at a
   * gateway, a proxy or a self-hosted endpoint that speaks the same shape —
   * and so the end-to-end test can point at a stand-in rather than spending
   * real tokens to prove the loop is wired up.
   */
  llm: () => ({
    groqKey: env("GROQ_API_KEY"),
    groqUrl: env("GROQ_BASE_URL") ?? "https://api.groq.com/openai/v1",
    groqModel: env("GROQ_MODEL") ?? "llama-3.3-70b-versatile",
    // A separate model id, because the chat model is usually text-only and a
    // text-only model handed an image does not fail — it answers about nothing.
    groqVisionModel:
      env("GROQ_VISION_MODEL") ?? "meta-llama/llama-4-scout-17b-16e-instruct",
    openrouterKey: env("OPENROUTER_API_KEY"),
    openrouterUrl: env("OPENROUTER_BASE_URL") ?? "https://openrouter.ai/api/v1",
    openrouterModel: env("OPENROUTER_MODEL") ?? "anthropic/claude-sonnet-4.5",
    openrouterVisionModel:
      env("OPENROUTER_VISION_MODEL") ?? "anthropic/claude-sonnet-4.5",
    openaiKey: env("OPENAI_API_KEY"),
    openaiUrl: env("OPENAI_BASE_URL") ?? "https://api.openai.com/v1",
    openaiModel: env("OPENAI_MODEL") ?? "gpt-4o-mini",
    openaiVisionModel: env("OPENAI_VISION_MODEL") ?? "gpt-4o-mini",
  }),

  stt: () => ({
    key: env("GROQ_API_KEY"),
    url:
      env("STT_BASE_URL") ?? "https://api.groq.com/openai/v1/audio/transcriptions",
    model: env("STT_MODEL") ?? "whisper-large-v3-turbo",
    language: env("STT_LANGUAGE") ?? "pt",
  }),

  tts: () => {
    const key = env("ELEVENLABS_API_KEY");
    if (!key) return null;
    return {
      key,
      url: env("ELEVENLABS_BASE_URL") ?? "https://api.elevenlabs.io/v1/text-to-speech",
    };
  },

  backend: () => {
    const url = env("BACKEND_URL")?.replace(/\/+$/, "");
    if (!url) return null;
    return {
      url,
      /** Sent as `Authorization`. Never reaches the model. */
      token: env("BACKEND_TOKEN"),
      headerName: env("BACKEND_AUTH_HEADER") ?? "authorization",
    };
  },

  ffmpeg: () => env("FFMPEG_BIN") ?? "ffmpeg",
  /** poppler-utils. Absent means PDFs with a text layer cannot be read locally. */
  pdftotext: () => env("PDFTOTEXT_BIN") ?? "pdftotext",
  /** Renders a PDF page to an image, for the scanned ones that have no text. */
  pdftoppm: () => env("PDFTOPPM_BIN") ?? "pdftoppm",
  /** Page counts. Same poppler package as the two above. */
  pdfinfo: () => env("PDFINFO_BIN") ?? "pdfinfo",
  required,
};
