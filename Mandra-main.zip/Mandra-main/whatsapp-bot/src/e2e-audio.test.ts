import test from "node:test";
import assert from "node:assert/strict";
import { createServer, type Server } from "node:http";
import { spawn, type ChildProcess } from "node:child_process";
import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * The audio path, end to end: a voice note arrives and a voice note goes back.
 *
 * Four stand-ins — the bridge, the transcriber, the model and the voice — around
 * the real server. What it is actually proving is the chain that no unit test
 * can see: that the bridge's base64 reaches the transcriber, that the
 * transcription reaches the model as the customer's turn, that `espelho` mode
 * notices the inbound was audio, and that what reaches the bridge on the way out
 * is Ogg/Opus on the voice-note endpoint rather than an mp3 on the file one.
 *
 * The last of those is the whole difference between a voice note and the bot
 * mailing somebody an attachment.
 */

const here = path.dirname(fileURLToPath(import.meta.url));

type Sent = { path: string; body: Record<string, unknown> };

async function listen(server: Server): Promise<number> {
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  return typeof address === "object" && address ? address.port : 0;
}

function close(server: Server): Promise<void> {
  return new Promise((resolve) => server.close(() => resolve()));
}

/** A real, tiny mp3, so the encoder in `tts.ts` has something to actually chew. */
function makeMp3(): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const child = spawn("ffmpeg", [
      "-hide_banner",
      "-loglevel",
      "error",
      "-f",
      "lavfi",
      "-i",
      "sine=frequency=440:duration=2",
      "-f",
      "mp3",
      "pipe:1",
    ]);
    const chunks: Buffer[] = [];
    child.stdout.on("data", (c: Buffer) => chunks.push(c));
    child.on("error", reject);
    child.on("close", (code) =>
      code === 0 ? resolve(Buffer.concat(chunks)) : reject(new Error(`ffmpeg ${code}`)),
    );
  });
}

async function waitForBoot(port: number): Promise<void> {
  for (let i = 0; i < 100; i += 1) {
    try {
      if ((await fetch(`http://127.0.0.1:${port}/health`)).ok) return;
    } catch {
      // Not up yet.
    }
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error("o bot não subiu");
}

test("áudio entra, áudio sai", { timeout: 90_000 }, async () => {
  const mp3 = await makeMp3();
  const sent: Sent[] = [];
  let transcriberSawBytes = 0;
  let spokenText = "";

  // The bridge: answers the media download with base64, records the sends.
  const bridge = createServer((request, response) => {
    const chunks: Buffer[] = [];
    request.on("data", (c: Buffer) => chunks.push(c));
    request.on("end", () => {
      const raw = Buffer.concat(chunks).toString("utf8");
      sent.push({
        path: request.url ?? "",
        body: raw ? (JSON.parse(raw) as Record<string, unknown>) : {},
      });
      response.writeHead(200, { "content-type": "application/json" });
      if ((request.url ?? "").includes("getBase64FromMediaMessage")) {
        // Stands in for the customer's voice note. Any bytes will do — the
        // transcriber here is a stand-in too.
        response.end(JSON.stringify({ base64: mp3.toString("base64") }));
        return;
      }
      response.end(JSON.stringify({ key: { id: `srv-${sent.length}` } }));
    });
  });

  const transcriber = createServer((request, response) => {
    const chunks: Buffer[] = [];
    request.on("data", (c: Buffer) => chunks.push(c));
    request.on("end", () => {
      transcriberSawBytes = Buffer.concat(chunks).length;
      response.writeHead(200, { "content-type": "application/json" });
      response.end(JSON.stringify({ text: "oi, queria marcar pra quinta" }));
    });
  });

  const modelSaw: { messages: { role: string; content: string }[] }[] = [];
  const model = createServer((request, response) => {
    const chunks: Buffer[] = [];
    request.on("data", (c: Buffer) => chunks.push(c));
    request.on("end", () => {
      modelSaw.push(
        JSON.parse(Buffer.concat(chunks).toString("utf8")) as (typeof modelSaw)[0],
      );
      response.writeHead(200, { "content-type": "application/json" });
      response.end(
        JSON.stringify({
          choices: [
            {
              message: {
                content: JSON.stringify({
                  mensagem: "Claro! Quinta de manhã ou de tarde?",
                  acoes: [],
                }),
              },
            },
          ],
        }),
      );
    });
  });

  const voice = createServer((request, response) => {
    const chunks: Buffer[] = [];
    request.on("data", (c: Buffer) => chunks.push(c));
    request.on("end", () => {
      const body = JSON.parse(Buffer.concat(chunks).toString("utf8")) as {
        text: string;
      };
      spokenText = body.text;
      response.writeHead(200, { "content-type": "audio/mpeg" });
      response.end(mp3);
    });
  });

  const [bridgePort, transcriberPort, modelPort, voicePort] = await Promise.all([
    listen(bridge),
    listen(transcriber),
    listen(model),
    listen(voice),
  ]);

  const dataDir = mkdtempSync(path.join(tmpdir(), "bot-e2e-audio-"));
  const configFile = path.join(dataDir, "audio.config.ts");
  writeFileSync(
    configFile,
    `export default ${JSON.stringify({
      name: "Clínica de Teste",
      timezone: "America/Sao_Paulo",
      language: "português do Brasil",
      persona: {
        identity: "Você é o assistente da Clínica de Teste.",
        role: "Atende.",
        style: "Curto.",
      },
      tools: [],
      media: {
        images: true,
        documents: true,
        video: true,
        maxBytes: 16 * 1024 * 1024,
        maxPdfPages: 8,
        maxChars: 12000,
      },
      // Mirror mode: they sent audio, so the answer goes back as audio.
      voice: { reply: "espelho", voiceId: "voz-de-teste", maxChars: 420 },
      human: {
        debounceMs: 200,
        readDelayMs: [50, 100],
        typingCps: 200,
        typingMs: [100, 300],
        splitBubbles: false,
        maxBubbles: 1,
        jitter: 0.1,
      },
      scheduling: { enabled: false, reminderOffsets: [], defaultDurationMinutes: 30 },
      handoff: { message: "Vou chamar alguém." },
    })};\n`,
  );

  const port = 8198;
  const child: ChildProcess = spawn(
    process.execPath,
    [path.join(here, "server.ts")],
    {
      env: {
        ...process.env,
        PORT: String(port),
        BOT_DB: path.join(dataDir, "audio.db"),
        BOT_CONFIG: configFile,
        EVOLUTION_API_URL: `http://127.0.0.1:${bridgePort}`,
        EVOLUTION_API_KEY: "k",
        EVOLUTION_INSTANCE: "teste",
        EVOLUTION_WEBHOOK_SECRET: "segredo-do-webhook",
        GROQ_API_KEY: "fake",
        GROQ_BASE_URL: `http://127.0.0.1:${modelPort}`,
        STT_BASE_URL: `http://127.0.0.1:${transcriberPort}/transcricoes`,
        OPENROUTER_API_KEY: "",
        OPENAI_API_KEY: "",
        ELEVENLABS_API_KEY: "fake",
        ELEVENLABS_BASE_URL: `http://127.0.0.1:${voicePort}/tts`,
        BACKEND_URL: "",
        ADMIN_TOKEN: "operador",
      },
      stdio: ["ignore", "pipe", "pipe"],
    },
  );

  let stderr = "";
  child.stderr?.on("data", (c: Buffer) => (stderr += String(c)));

  try {
    await waitForBoot(port);

    const response = await fetch(`http://127.0.0.1:${port}/webhook`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-webhook-token": "segredo-do-webhook",
      },
      body: JSON.stringify({
        event: "messages.upsert",
        instance: "teste",
        data: {
          key: { remoteJid: "5531977776666@s.whatsapp.net", id: "AUDIO-1" },
          pushName: "Bruno",
          message: {
            audioMessage: {
              seconds: 7,
              mimetype: "audio/ogg; codecs=opus",
              ptt: true,
            },
          },
        },
      }),
    });

    assert.equal(response.status, 200);
    const verdict = (await response.json()) as { replied: boolean };
    assert.equal(verdict.replied, true, stderr);

    // The bridge was asked to decrypt the media, and the bytes reached the
    // transcriber.
    assert.ok(
      sent.some((item) => item.path.includes("getBase64FromMediaMessage")),
      "não baixou a mídia",
    );
    assert.ok(transcriberSawBytes > 1000, "a transcrição não recebeu o áudio");

    // The transcription reached the model as the customer's turn, marked as a
    // transcription so it knows an odd word may be a mishearing.
    const firstCall = modelSaw[0];
    const asUser = firstCall?.messages.find((m) => m.role === "user");
    assert.match(asUser?.content ?? "", /marcar pra quinta/);
    assert.match(asUser?.content ?? "", /áudio transcrito/);

    // It went back as a voice note, on the voice-note endpoint — not as a file.
    const audioSends = sent.filter((item) =>
      item.path.includes("/message/sendWhatsAppAudio/"),
    );
    assert.equal(audioSends.length, 1, `esperava um áudio enviado. ${stderr}`);
    assert.equal(
      sent.filter((item) => item.path.includes("/message/sendText/")).length,
      0,
      "mandou texto quando devia mandar áudio",
    );

    // And what was sent is really Ogg/Opus, which is the only thing WhatsApp
    // plays inline.
    const payload = Buffer.from(String(audioSends[0]?.body.audio), "base64");
    assert.equal(payload.subarray(0, 4).toString(), "OggS");
    assert.equal(payload.subarray(28, 36).toString(), "OpusHead");

    // "gravando áudio…", not "digitando…".
    assert.ok(
      sent.some(
        (item) =>
          item.path.includes("/chat/sendPresence/") &&
          item.body.presence === "recording",
      ),
      "não mostrou gravando áudio",
    );

    // The emoji and the markdown never reached the voice.
    assert.equal(spokenText, "Claro! Quinta de manhã ou de tarde?");
  } finally {
    child.kill("SIGKILL");
    await Promise.all([
      close(bridge),
      close(transcriber),
      close(model),
      close(voice),
    ]);
  }
});
