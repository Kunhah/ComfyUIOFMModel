# Decisões deste template, e o motivo de cada uma

O leitor aqui é alguém — ou algum agente — decidindo o que mudar. Uma regra sem
motivo é uma regra que se "melhora" na primeira refatoração, então cada uma vem
com o que aconteceu quando não era assim.

Muito disto foi portado do agente de WhatsApp do CRM da Atlas
(`Website/src/lib/whatsapp/`). Onde a regra veio de lá, ela custou um bug real lá.

## A forma do template

- **`bot.config.ts` é o que muda por cliente; o ambiente é o que muda por
  máquina.** Persona, ferramentas e ritmo são commitados e revisados; chave,
  URL e número pareado são segredo por host. Persona em variável de ambiente é
  como o assistente de um cliente acaba indocumentado num painel que ninguém lê;
  chave na config é como ela acaba no git.
- **`BOT_CONFIG` aponta para outro arquivo, e é isso que faz uma imagem servir
  vários clientes.** Config diferente + `EVOLUTION_INSTANCE` diferente = outro
  bot. Sem isso, cada cliente vira um fork, e um fork é uma correção que não
  chega nos outros.
- **Zero dependências de runtime, de propósito.** O bot fala com quatro serviços
  por HTTP e o Node já traz `fetch`; a fila é `node:sqlite` e o servidor é
  `node:http`. Um template que instala trinta pacotes é um template que alguém
  tem de auditar antes de pôr o WhatsApp de um cliente atrás dele. Node 24+ é o
  preço disso — antes disso nada aqui roda sem flag experimental, e uma flag
  esquecida falha no boot em produção.
- **Sem parameter properties de construtor.** O type stripping do Node as recusa
  enquanto um bundler as aceita, então o atalho compila na build e quebra só sob
  `node --test`.

## A ponte

- **`src/bridge/evolution.ts` é o único arquivo que sabe o que é um JID.** Todo o
  resto lida com telefone, string e Buffer. É o que faz trocar a Evolution pela
  API oficial da Meta mexer em um arquivo só. Não deixe `@s.whatsapp.net` vazar
  para cima.
- **A ponte é outro container e não publica porta no host.** Ela segura um socket
  vivo e uma sessão pareada em disco — o estado que um processo que você
  redeploy é o lugar errado para guardar. Uma Evolution acessível pela internet é
  uma conta de WhatsApp da qual qualquer um envia.
- **Sem `EVOLUTION_WEBHOOK_SECRET`, nenhum webhook é aceito.** O padrão contrário
  — aceitar tudo quando não está definido — transforma uma variável esquecida num
  endpoint aberto que faz o bot falar com estranhos no número do cliente. E ele é
  deliberadamente diferente da `EVOLUTION_API_KEY`: aquela nos autentica *para* a
  ponte, esta autentica a ponte *para nós*; um valor só nos dois sentidos
  significa que vazar a ponte entrega junto a chave de injetar mensagem falsa.
- **`provider_id` é UNIQUE e é toda a história de idempotência.** A ponte repete
  um webhook que ela leu como falho; sem a constraint a mesma mensagem é
  respondida duas vezes. `recordMessage` devolve `null` numa repetição, então
  quem chama tem de checar o retorno em vez de assumir que escreveu.
- **O sufixo `:12` do multi-device não é parte do número.** Deixá-lo produz uma
  segunda conversa para a mesma pessoa toda vez que ela troca de aparelho.
- **Grupo nunca é respondido.** Seria responder a toda mensagem dele, em público,
  em nome da empresa. `jidToPhone` devolve null para `@g.us` e é ali que isso
  para.
- **O webhook responde 200 para quase tudo.** A ponte repete o que ela lê como
  falha, então um não-2xx numa mensagem que a gente só não trata — uma foto, um
  grupo, o eco do nosso próprio envio — compra um laço de retry para uma decisão
  que não vai mudar.
- **O webhook fica aberto durante toda a pausa humana, e é a idempotência que
  segura isso.** A janela de silêncio, a pausa de leitura, a digitação e a
  chamada ao modelo somam facilmente quinze ou vinte segundos antes de o 200
  sair, o que passa do timeout de webhook de algumas versões da ponte. Ela então
  repete — e a repetição bate no UNIQUE de `provider_id`, é reconhecida como
  duplicata e responde na hora, sem responder o cliente duas vezes. Se você
  aumentar `debounceMs` ou o teto de digitação, é essa a rede que está segurando;
  não a remova, e se um dia responder cedo for necessário, a saída é uma fila e
  não um `void` numa promise.
- **O webhook é apontado a cada `npm run pair`, não só na criação.** A URL vem de
  `PUBLIC_URL`, então muda quando o bot troca de host, e uma URL velha é a falha
  invisível de tudo isto: o número pareia, o terminal diz conectado, e não chega
  uma mensagem.

## Áudio

- **A transcrição é uma API e isso é uma escolha, não a opção fácil.** O áudio é
  respondido dentro do mesmo webhook que o recebeu, então a transcrição está na
  frente do cliente esperando: a Groq devolve 30s de áudio em ~1s, o whisper.cpp
  na CPU deste container leva dezenas de segundos. Essa diferença é entre um bot
  que responde áudio e um que parece ter ignorado. **O preço é que o áudio do
  cliente sai do seu servidor** — está na política de privacidade dele? Se não
  puder sair, troque `src/audio/stt.ts` por whisper.cpp local e mova o turno para
  uma fila; nada mais muda, e é para isso que aquele arquivo é uma função só.
- **Nota de voz precisa ser Ogg/Opus mono, e é o ffmpeg que garante isso.** O
  endpoint é `sendWhatsAppAudio`, não o de mídia: a bolinha com onda toca no
  chat, o arquivo o cliente tem de baixar e abrir num player — que é
  inconfundivelmente uma máquina mandando um anexo. Um teste ponta a ponta checa
  os bytes `OggS`/`OpusHead` justamente porque essa troca é silenciosa.
- **A mídia do WhatsApp é cifrada no CDN da Meta.** Baixar a `url` do payload
  devolve texto cifrado; as chaves estão na mensagem que a ponte já tem, e por
  isso `downloadMedia` manda o objeto inteiro de volta para ela em vez de um id.
- **Transcrição vazia é resultado, não erro.** Alguém gravou três segundos de
  barulho de rua ou apertou o botão sem querer. Vira o bot dizendo que não
  conseguiu ouvir — que é o que uma pessoa diria — e não um erro que o cliente
  nunca vê.
- **O idioma é declarado, não detectado.** Um áudio que começa com "alô" já foi
  detectado como espanhol, e aí toda palavra depois está errada de um jeito que
  parece modelo ruim em vez de flag errada.
- **O transcrito é guardado, o áudio não.** Tudo depois lê o texto: a memória do
  modelo, o operador lendo a thread. Guardar o arquivo compra re-escutar e nada
  mais, ao custo de uma pasta de conversas de cliente sem política de retenção.
- **O texto falado não é o texto escrito.** Emoji são lidos em voz alta pelo nome
  por algumas vozes, asterisco vira "asterisco", e uma URL ditada é quarenta
  segundos de absurdo. `speakable()` limpa isso — não peça duas versões ao
  modelo, é mais uma coisa para ele errar no turno em que ele também tinha de
  marcar alguma coisa.
- **Link, e-mail e número longo nunca vão em áudio, nem no modo `sempre`.** Uma
  nota de voz com um telefone dentro é um telefone que a pessoa tem de anotar
  enquanto escuta.

## Arquivos (imagem, PDF, documento, vídeo)

- **Tudo vira texto em `media/understand.ts`, e é essa uniformidade que é o
  projeto.** O agente, o prompt, o histórico e o laço de ferramentas não sabem o
  que é um PDF: eles leem um turno que diz o que o arquivo continha. Um caminho
  de código responde uma foto, um contrato e um áudio. Ler um tipo novo é uma
  entrada no `route()`, não um ramo novo no webhook.
- **Nunca fazer menos do que foi pedido em silêncio.** Quatro páginas de um PDF
  de quarenta é aceitável; quatro páginas apresentadas como o documento inteiro
  não é. Todo limite se anuncia no próprio turno (`note`), e o aviso chega ao
  modelo — que é instruído a repassá-lo. Um bot que responde sobre um contrato
  tendo lido um quinto dele, sem dizer, está errado de um jeito que o cliente não
  tem como perceber.
- **Falhar é uma resposta.** Arquivo ilegível vira uma frase, nunca uma exceção:
  a pessoa mandou e está esperando. E a frase é por tipo, porque a metade útil é
  dizer o que fazer em vez — áudio se repete, documento se descreve em palavras.
- **A recusa também é gravada na transcrição.** Uma thread onde o anexo do
  cliente simplesmente não está lê como se nada tivesse sido mandado, e o
  operador que pega a conversa depois não tem como saber que havia um arquivo.
- **Local primeiro, e aqui isso pesa mais que no áudio.** Os documentos que
  chegam num WhatsApp de empresa são exame, nota fiscal, contrato e foto de RG.
  PDF com camada de texto é `pdftotext` em milissegundos e não sai da máquina; só
  o digitalizado — o que abriu limpo e genuinamente não tem texto — cai no modelo
  de visão. `empty` é esse sinal, e é por isso que ele é resultado e não erro.
- **O modelo de visão é declarado à parte do modelo de conversa.** Um modelo
  só-texto que recebe uma parte `image_url` **não dá erro**: ele responde com
  confiança sobre nada. Por isso `vision: true` é pedido explicitamente em vez de
  inferido do conteúdo da mensagem, e por isso o teste ponta a ponta confere qual
  modelo foi chamado.
- **A imagem vai inline como data: URI, nunca como link.** Uma URL teria de ser
  publicamente alcançável, o que significa publicar a foto de um cliente na
  internet para um modelo poder olhar.
- **O prompt da visão manda transcrever antes de descrever.** O anexo mais comum
  que uma empresa recebe é a fotografia de um documento — recibo, receita, print
  de erro, cardápio. Uma descrição que diz "uma foto de um recibo" jogou fora a
  mensagem inteira.
- **Vídeo é só a fala, e o turno diz isso.** Nada aqui olha a imagem. Sem essa
  linha o agente responde "vi seu vídeo" sobre algo que ninguém assistiu — uma
  afirmação que o cliente não tem como conferir e toda razão para acreditar.
- **`documentMessage` vem antes de `imageMessage` no `mediaOf`, e o mimetype é
  repassado.** "Enviar como arquivo" produz um `documentMessage` com
  `image/jpeg` dentro, que é como se manda um scan sem deixar o WhatsApp
  recomprimir. Quem decide como ler é o `route()`, pelo mimetype e pelo nome do
  arquivo — nunca a ordem dos ramos.
- **`documentWithCaptionMessage` embrulha o documento um nível abaixo.** Perder
  isso torna invisível todo anexo que veio com um comentário, que é a maioria.
- **Sticker é ignorado de propósito.** É reação, não conteúdo, e descrever um com
  modelo de visão é uma chamada paga para descobrir que mandaram um desenho.
- **`route()` olha mimetype e depois extensão, porque os dois mentem em direções
  opostas.** Documento encaminhado de desktop chega como
  `application/octet-stream`; imagem mandada como arquivo mantém `image/jpeg`
  sendo um `documentMessage`. O que sobra sem nenhum dos dois é recusado em vez
  de adivinhado — adivinhar é como um binário vira uma tela de ruído no prompt.
- **O ZIP é lido pelo diretório central, não varrendo cabeçalhos locais.** É o
  que o formato manda e a única forma de estar certo sobre um arquivo que foi
  appendado ou que usa data descriptor. ZIP64, criptografia e métodos de
  compressão exóticos são recusados *pelo nome*: um Office não é nenhum dos três,
  então esbarrar num deles significa que o arquivo não é o que dizia ser.
- **`readOffice` quebra parágrafo antes de tirar as tags.** Sem isso o documento
  inteiro chega como uma linha corrida, e o modelo resume aquilo como se fosse
  uma frase só.
- **Slide é ordenado numericamente.** `slide10` vem antes de `slide2` em ordem
  alfabética, e um deck embaralhado lê como documento mal escrito, não como bug.
- **Planilha volta só o texto das células e o `note` diz isso.** Dá para
  responder "o que tem neste arquivo" e não "o que tem em B7". Dizer o limite é
  melhor do que deixar implícito que não existe.
- **`&amp;` é decodificado por último.** Antes dos outros, uma entidade escapada
  na origem é decodificada duas vezes e o documento passa a dizer outra coisa.
- **O `messages.kind` foi alargado com um rebuild de verdade, não com um
  ALTER.** CHECK não se altera e a DDL é `CREATE TABLE IF NOT EXISTS`, então
  nenhum dos caminhos normais chega num banco existente — e a falha não é
  cosmética: o primeiro PDF que alguém mandar é perdido com erro de constraint
  onde deveria haver resposta. `widenMessageKinds()` faz na ordem documentada do
  SQLite, e é no-op num banco novo ou já migrado.
- **As colunas são nomeadas no INSERT do rebuild.** `INSERT INTO ... SELECT *`
  liga por posição, então ele desloca todos os valores uma coluna no dia em que
  as duas definições diferirem — que é exatamente o dia em que isso roda.
- **`load-config.ts` confere as seções no boot.** Uma config sem `media` não
  falha onde se espera: ela estoura dentro do handler, o bot sobe dizendo que
  está ouvindo, e aí responde 500 para todo cliente — erro que só a ponte vê.
  Foi assim que dois testes ponta a ponta quebraram quando `media` passou a ser
  obrigatório, e a checagem existe por causa disso.

## Parecer gente

- **Nada disto muda o que o bot diz, e nada disto mente.** Ele continua dizendo
  que é um assistente quando perguntam — a regra está em `prompt.ts` e a config
  do cliente não a remove. Ritmar a conversa como gente é educação; afirmar ser
  gente é outra coisa, e em vários lugares é ilegal.
- **`waitForSilence` é o ajuste que mais muda a sensação.** Pessoas mandam "oi" /
  "queria marcar" / "pra quinta" em três mensagens. Responder a primeira é o
  tell mais claro que existe, e ainda responde uma pergunta que estava sendo
  feita — o bot acaba respondendo duas vezes, fora de ordem, a quem perguntou uma.
- **A checagem da janela é no banco, nunca num timer em memória.** A mensagem
  mais nova chega por *outro* request, possivelmente noutra cópia do processo, e
  o único lugar que os dois enxergam é a transcrição.
- **A presença sobe antes da pausa, não depois.** "Digitando…" aparecendo no
  instante anterior à mensagem chegar é pior do que não aparecer.
- **Resposta com link ou número longo nunca é quebrada em bolhas.** Metade de um
  endereço numa bolha é pior que uma mensagem um pouco comprida.
- **A API de operador manda `instant: true`.** O ritmo existe para o *bot* ler
  como pessoa; aplicá-lo a uma pessoa de verdade é só latência.

## O modelo e o envelope

- **Um envelope JSON, não function calling.** Os provedores expõem tool calling
  de formas diferentes e nem todo modelo em cada um suporta, enquanto
  `response_format: json_object` funciona nos três. O preço é `reply.ts`: um
  schema escrito à mão e validado como se um estranho tivesse mandado.
- **Que é o que aconteceu.** Um modelo é uma fonte não confiável que por acaso
  está do nosso lado da rede, e todo campo ali chega em algo real: uma mensagem
  no telefone de um cliente, uma marcação na agenda, um job que vai continuar
  mandando mensagem por semanas.
- **`MIN_INTERVAL_MINUTES` é o número mais importante do arquivo.** `* * * * *`
  é cron perfeitamente válido que manda mensagem para um cliente todo minuto,
  para sempre, e é exatamente o que um modelo confuso emite para "lembrar
  sempre".
- **O intervalo é amostrado, nunca inferido dos campos.** `0 9,10 * * *` dispara
  duas vezes com uma hora de diferença; ler a expressão chama isso de lembrete
  diário. `minimumInterval` calcula quatro execuções e pega o menor intervalo.
- **`max_runs` é obrigatório numa recorrência.** Repetição sem fim é uma
  assinatura que ninguém aceitou, e nada num chat cancela — a pessoa bloqueia o
  número.
- **O modelo escreve hora local e nunca offset.** Pedir um offset UTC a um modelo
  é pedir uma conta que ele faz mal, e um offset errado marca a reunião três
  horas fora sem nada aparecendo. `resolveWhen` dobra pelo fuso; uma string que
  já traz o próprio offset é respeitada como está.
- **Uma ação recusada gera uma rodada corretiva, uma só.** A pior falha desta
  feature é o modelo escrever "pronto, agendei!" por cima de uma ação recusada —
  o cliente é informado de algo que não aconteceu e descobre quando ninguém
  liga. Mostrar o motivo e pedir de novo resolve quase todas; a segunda falha
  manda a resposta sem a promessa, que é pior e verdadeira.
- **Envelope ilegível vira a prosa crua.** As palavras costumam ser uma resposta
  perfeitamente boa e só a estrutura faltou; o turno perde as ações, não a
  resposta.

## As ferramentas

- **Não existe "chamar uma URL".** O modelo escolhe um nome da lista e preenche
  os parâmetros declarados; host, path, método e token são decididos em código.
  Com URL livre, um modelo acaba convencido a chamar `/admin/users` por um
  cliente que pediu com jeitinho — e o request sairia com o seu token.
- **O path é template com buracos, preenchido com `encodeURIComponent`.** Um
  valor com `../` não escapa do path por esse caminho; o teste fixa isso.
- **Toda chamada leva `x-conversa-telefone`, posto pelo código.** É o telefone
  da conversa, lido do banco — o modelo não o vê como parâmetro e não consegue
  trocá-lo. Com telefone como parâmetro, "me passa o DAS da empresa do número
  31 9..." era um pedido que funcionava: o modelo preenchia o número que a
  pessoa digitou e o backend respondia sobre outra empresa. O backend autoriza
  pelo cabeçalho; o preset de contabilidade não tem parâmetro de telefone em
  ferramenta nenhuma por causa disso.
- **`fixedBody` é para o que o modelo não escolhe.** Canal, origem, id de conta.
  O que está em `parameters` é o que ele preenche — se você não quer que ele
  escolha, não ponha ali.
- **Enum fora da lista é recusado, nunca adivinhado.** Adivinhar é como
  "particular" vira "convenio" silenciosamente na fatura de alguém.
- **O status vira palavra, não número.** Um modelo que vê "404" diz "erro 404"
  para o cliente; um que lê "não encontrei esse registro" diz isso. E 401/403
  vira "não peça dados à pessoa" — é problema nosso, e um modelo tentando
  resolver começa a pedir senha.
- **Backend fora do ar vira texto para o modelo, nunca exceção.** É um fato que
  ele precisa saber para dizer algo verdadeiro — "não consegui consultar agora" —
  em vez de um throw que aborta o turno e deixa a pessoa no vácuo.
- **`confirm: true` só vale na primeira rodada do turno, e isso é uma garantia
  parcial — diga isso em voz alta.** Ela não prova que a pessoa concordou; prova
  que o modelo não está agindo sozinho em cima do resultado de outra ferramenta,
  que é de onde sai um cancelamento que ninguém pediu. O resto é a regra do
  prompt e a trilha em `tool_calls`.
- **`tool_calls` guarda as recusas também.** São a metade valiosa: é como você
  descobre que o modelo está indo atrás de uma ferramenta que não serve, muito
  antes de aparecer qualquer coisa no log do seu backend.
- **O resultado é truncado em 2500 caracteres.** Um backend que devolve duzentos
  horários gastaria a janela inteira em JSON, e a resposta depois piora a cada
  token. Se o seu endpoint pode devolver lista sem limite, pagine lá — truncar
  aqui perde o fim em silêncio.

## A fila

- **SQLite, não `setTimeout`.** Timer se perde em todo deploy, e um lembrete que
  evapora no restart é pior que um que nunca existiu, porque a pessoa foi avisada
  de que ele vinha. O tick só pergunta "tem alguma coisa vencida?", então perder
  *ele* custa o atraso e nada mais.
- **Cron é avaliado num fuso nomeado, nunca no do container.** Todo deploy roda
  UTC, e um lembrete é uma promessa em hora de parede: "segunda às 9" é 9 da
  manhã em São Paulo.
- **`MAX_LATENESS_MS` existe para não ser cruel.** Um container fora do ar num
  fim de semana volta segurando os lembretes de sexta. "Lembrando da nossa
  conversa de amanhã", chegando segunda sobre um sábado que passou, estraga a
  relação que ele deveria manter.
- **Envio que falha ainda avança o job.** Deixar `next_run_at` no passado faz o
  tick tentar de novo a cada trinta segundos para sempre — contra uma ponte
  desconectada, um log com um erro só; contra um número bloqueado, uma fila que
  nunca esvazia.
- **O tick se protege de rodar sobre si mesmo.** Ele espera uma chamada de rede
  por job — e, com voz ligada, um render de TTS — então uma ponte lenta passa do
  intervalo, e a segunda passada manda o mesmo lembrete duas vezes: exatamente a
  falha que a fila durável deveria ter removido.
- **Marcar compromisso agenda os próprios lembretes.** A experiência de
  "agendado" *é* o lembrete; deixar para o modelo faz disso um cara ou coroa por
  conversa. Offsets que já passaram são pulados, ou marcar algo para hoje à tarde
  dispara o lembrete de "amanhã" na hora.
- **O texto do lembrete é escrito na criação, não no envio.** O que está na fila
  é exatamente o que a pessoa vai receber; um template expandido três dias depois
  é uma mensagem que ninguém leu antes de chegar num cliente.

## O banco

- **A transcrição é a memória do modelo.** Não há estado de conversa no processo,
  então duas cópias respondem igual e um deploy no meio da conversa não a
  quebra. Quem recebe uma resposta que esqueceu as últimas três mensagens percebe
  na hora.
- **Mensagem de saída que falhou é guardada e excluída do prompt.** Guardada
  porque o operador tem de ver o que o cliente *não* recebeu — um buraco sem
  linha lê como o bot não tendo dito nada. Excluída porque um modelo que a lê de
  volta acha que já disse algo que o outro telefone nunca mostrou.
- **`auto_reply` é coluna, não configuração.** É a chave que desliga o bot naquela
  thread. Um humano e um modelo respondendo juntos é a coisa mais constrangedora
  que isto pode fazer na frente de um cliente, e a rota de envio desliga do lado
  do servidor — assumir a conversa não é algo que dê para esquecer.
- **Índices são aplicados depois de `addMissingColumns()`, nunca junto da
  tabela.** `CREATE INDEX` numa coluna que o banco antigo não tem lança, e isso
  aborta o schema inteiro antes de a coluna ser adicionada — a tabela fica uma
  migração atrás e todo write falha numa coluna que não existe.
- **Mudança de coluna precisa de entrada em `addMissingColumns()`, e só aditiva.**
  A DDL é `CREATE TABLE IF NOT EXISTS`, então ela não faz nada num banco que já
  existe. As pessoas são avisadas de que podem manter o arquivo.
- **Cuidado com crase dentro dos comentários SQL em `db.ts`.** Uma crase num
  comentário dentro do template literal termina a string, e o erro de parse
  aponta para o SQL, não para a aspa. O mesmo vale para `*` seguido de `/` num
  comentário de bloco nos arquivos de cron.

## Os testes

- **Nenhum gasta token.** Uma checagem que custa dinheiro por execução é uma
  checagem que alguém acaba desligando. Os dois testes ponta a ponta sobem o
  servidor de verdade contra dublês da ponte, do modelo, do transcritor e da voz.
- **Eles são a única coisa que enxerga a fiação.** Um webhook que autentica e não
  roteia, um resultado de ferramenta que não volta para a segunda rodada, uma
  resposta composta e nunca enviada: nada disso aparece em teste de unidade.
- **O e2e de áudio checa os bytes `OggS`/`OpusHead`.** Mandar mp3 no endpoint
  errado falha em silêncio — chega como anexo, e só uma pessoa olhando o celular
  perceberia.
- **O e2e usa a própria config, via `BOT_CONFIG`.** Depender do exemplo commitado
  fez o teste falhar num sábado à tarde, porque o horário de funcionamento do
  exemplo estava certo e o teste é que estava errado.
