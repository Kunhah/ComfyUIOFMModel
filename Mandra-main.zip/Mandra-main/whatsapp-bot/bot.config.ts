import type { BotConfig } from "./src/config.ts";

/**
 * ESTE É O ARQUIVO QUE VOCÊ EDITA.
 *
 * Tudo abaixo é exemplo de uma clínica fictícia e serve para o bot subir e
 * funcionar antes de você trocar uma linha. Troque a persona, troque as
 * ferramentas pelos endpoints do seu backend, e o resto do template não muda.
 *
 * Três coisas que valem ler antes de mexer:
 *
 * 1. `tools` é a única superfície entre o modelo e o seu backend. Não existe
 *    "chamar uma URL qualquer": o modelo escolhe um nome desta lista e preenche
 *    os parâmetros declarados, e é só isso que sai daqui. Ver `agent/tools.ts`.
 * 2. `persona` não pode desligar as regras não-negociáveis (nunca inventar
 *    preço, nunca pedir senha, nunca dizer que é humano). Elas estão em
 *    `agent/prompt.ts` e entram em todo prompt.
 * 3. `human` é o que faz a conversa não parecer um robô. Os números padrão são
 *    conservadores de propósito — mexa neles depois de ler uma conversa real.
 */
export const config: BotConfig = {
  name: "Clínica Vitalis",
  timezone: "America/Sao_Paulo",
  language: "português do Brasil",

  persona: {
    identity: `Você é o assistente de atendimento da Clínica Vitalis no WhatsApp.
A Vitalis é uma clínica de fisioterapia e reabilitação em Belo Horizonte, com
seis fisioterapeutas e atendimento de segunda a sábado.`,

    role: `Você atende quem chama no WhatsApp: tira dúvidas sobre os serviços,
consulta e marca horários, e lembra a pessoa da consulta que ela marcou.
Você NÃO dá diagnóstico, NÃO orienta tratamento, NÃO opina sobre exame ou
receita, e NÃO negocia valor. Qualquer uma dessas coisas é conversa com um
profissional — use a ação "transferir".`,

    style: `Mensagens curtas, no máximo 3 linhas. Uma pergunta por vez.
Sem "Prezado", sem assinatura, sem bullet, sem markdown — o WhatsApp não
renderiza nada disso. Emoji no máximo um, e só quando couber.`,

    rules: [
      "Nunca diga que um horário está livre sem consultar a agenda pela ferramenta.",
      "Antes de marcar, repita dia, hora e profissional e espere a pessoa confirmar.",
      "Se a pessoa descrever dor forte, falta de ar ou algo urgente, transfira imediatamente e diga para procurar atendimento presencial.",
    ],

    greeting:
      "Oi! Aqui é o atendimento da Clínica Vitalis 🙂 Como posso ajudar?",
  },

  // Respostas prontas. O modelo vê estas perguntas e respostas e é instruído a
  // usar a resposta como está. Sai mais barato e — o que importa mais — sai
  // igual toda vez, que é o que você quer para endereço e horário.
  faq: [
    {
      q: "Onde fica a clínica?",
      a: "Ficamos na Rua dos Timbiras, 1200, sala 405 — Funcionários, BH. Tem estacionamento no prédio.",
    },
    {
      q: "Quais convênios vocês atendem?",
      a: "Atendemos Unimed, Bradesco Saúde e SulAmérica. Também temos valor particular — o time passa por aqui.",
    },
    {
      q: "Precisa de pedido médico?",
      a: "Para convênio sim, precisa do pedido do médico. Particular não precisa.",
    },
  ],

  /* ------------------------------------------------------------------------ */
  /* As ferramentas: o que o bot pode pedir ao seu backend                     */
  /* ------------------------------------------------------------------------ */
  tools: [
    {
      name: "consultar_horarios",
      description:
        "Lista os horários livres de um profissional numa data. Use SEMPRE antes de " +
        "oferecer qualquer horário — nunca invente disponibilidade.",
      parameters: {
        data: {
          type: "string",
          description: 'A data, no formato "AAAA-MM-DD".',
          required: true,
          maxLength: 10,
        },
        especialidade: {
          type: "enum",
          description: "O tipo de atendimento que a pessoa quer.",
          values: ["fisioterapia", "pilates", "rpg", "acupuntura"],
          required: true,
        },
      },
      request: {
        method: "GET",
        path: "/agenda/disponibilidade",
        query: ["data", "especialidade"],
      },
      pending: "Deixa eu ver a agenda aqui, um segundo…",
    },

    {
      name: "marcar_consulta",
      description:
        "Marca a consulta. Só depois da pessoa confirmar explicitamente o dia, a " +
        "hora e o profissional que você ofereceu.",
      parameters: {
        nome: {
          type: "string",
          description: "Nome completo da pessoa.",
          required: true,
          maxLength: 120,
        },
        data_hora: {
          type: "string",
          description: 'Início da consulta, "AAAA-MM-DDTHH:MM", horário local.',
          required: true,
          maxLength: 20,
        },
        especialidade: {
          type: "enum",
          description: "O tipo de atendimento.",
          values: ["fisioterapia", "pilates", "rpg", "acupuntura"],
          required: true,
        },
        convenio: {
          type: "string",
          description: 'Convênio, ou "particular".',
          maxLength: 60,
        },
      },
      request: {
        method: "POST",
        path: "/agenda/consultas",
        body: ["nome", "data_hora", "especialidade", "convenio"],
        // O canal não é escolha do modelo. Campos assim vão aqui, não nos
        // parâmetros — o que está em `parameters` é o que o modelo preenche.
        fixedBody: { origem: "whatsapp" },
      },
      confirm: true,
      pending: "Só um instante que já marco pra você…",
    },

    {
      name: "consultar_consulta",
      description:
        "Busca a próxima consulta marcada para um telefone. Use quando a pessoa " +
        'perguntar "que dia é mesmo a minha consulta?" ou quiser remarcar.',
      parameters: {
        telefone: {
          type: "string",
          description:
            "O telefone da pessoa, só dígitos com DDD. Use o número desta conversa.",
          required: true,
          maxLength: 20,
        },
      },
      request: {
        method: "GET",
        path: "/agenda/consultas/{telefone}",
      },
    },

    {
      name: "cancelar_consulta",
      description:
        "Cancela uma consulta marcada. Só com o pedido explícito da pessoa.",
      parameters: {
        id: {
          type: "string",
          description: "O id da consulta, como veio de consultar_consulta.",
          required: true,
          maxLength: 64,
        },
        motivo: {
          type: "string",
          description: "O que a pessoa disse. Curto.",
          maxLength: 200,
        },
      },
      request: {
        method: "DELETE",
        path: "/agenda/consultas/{id}",
        query: ["motivo"],
      },
      confirm: true,
    },
  ],

  /* ------------------------------------------------------------------------ */
  /* O que o bot abre quando mandam um arquivo                                 */
  /* ------------------------------------------------------------------------ */
  media: {
    // Imagem passa por um modelo de visão, que transcreve o que estiver escrito
    // nela. É como um print de erro ou uma foto de pedido médico viram texto.
    images: true,
    // PDF, docx, xlsx, pptx, csv, txt, json. PDF com texto é lido localmente
    // pelo pdftotext; PDF digitalizado cai no modelo de visão, página a página.
    documents: true,
    // Vídeo: só a fala. Ninguém olha a imagem, e o agente é avisado disso.
    video: true,

    // O arquivo trafega duas vezes pela rede. 16 MB cobre com folga foto,
    // contrato e planilha; acima disso é acervo, não pergunta.
    maxBytes: 16 * 1024 * 1024,

    // Páginas de PDF realmente lidas. O que passar disso é *avisado*, nunca
    // descartado em silêncio — responder sobre um contrato de 40 páginas tendo
    // lido 8 sem dizer é pior que dizer que leu 8.
    maxPdfPages: 8,

    // Caracteres extraídos que entram no prompt.
    maxChars: 12_000,

    // O que dizer quando não dá para ler. Vazio usa uma frase por tipo de
    // arquivo, que é melhor: um áudio pode ser repetido, um documento pode ser
    // descrito em palavras, e a frase genérica não ajuda em nenhum dos dois.
    // unsupported: "Recebi seu arquivo! Vou pedir para alguém do time olhar.",
  },

  voice: {
    // Áudio responde áudio, texto responde texto. É o que uma pessoa faz.
    reply: "espelho",
    // Troque pela voz que você escolheu no ElevenLabs. Esta é "Rachel", que fala
    // inglês — ouça uma em português antes de subir isto para um cliente.
    voiceId: "21m00Tcm4TlvDq8ikWAM",
    modelId: "eleven_multilingual_v2",
    stability: 0.45,
    similarityBoost: 0.75,
    speed: 0.96,
    // Acima disto vai como texto mesmo que tenham mandado áudio. Um áudio de
    // noventa segundos não é resposta, é tarefa.
    maxChars: 420,
  },

  human: {
    // Espera a pessoa terminar de escrever. Ver `humanize.ts` — é o ajuste que
    // mais muda a sensação da conversa.
    debounceMs: 4000,
    readDelayMs: [900, 2600],
    typingCps: 13,
    typingMs: [1200, 9000],
    splitBubbles: true,
    maxBubbles: 3,
    jitter: 0.25,
  },

  hours: {
    timezone: "America/Sao_Paulo",
    // [abre, fecha] em hora local. Domingo primeiro.
    week: [null, [8, 19], [8, 19], [8, 19], [8, 19], [8, 19], [8, 12]],
    outside: "avisar",
    notice:
      "Oi! A clínica está fechada agora, mas já anotei sua mensagem — respondo assim que abrirmos 🙂",
  },

  scheduling: {
    enabled: true,
    // Um dia antes e duas horas antes.
    reminderOffsets: [24 * 60, 120],
    defaultDurationMinutes: 50,
  },

  handoff: {
    message:
      "Vou chamar alguém do time aqui pra te ajudar melhor. Só um momento!",
    // Opcional: o backend é avisado de que a conversa precisa de gente.
    notifyPath: "/atendimento/handoff",
  },
};

export default config;
