# Template de bot de WhatsApp

Um bot que atende no WhatsApp, entende áudio, responde em áudio, chama o seu
backend para consultar e marcar coisas, e agenda lembretes que sobrevivem a
deploy. Feito para ser copiado por cliente: o que muda é `bot.config.ts`.

Extraído do agente de WhatsApp do CRM da Atlas (`Website/src/lib/whatsapp/`),
sem o acoplamento com o CRM. O motor de cron, o validador de envelope e as
regras da ponte vieram de lá inteiros, porque cada caso-limite deles custou um
bug real para ser encontrado.

## O que ele faz

| | |
| --- | --- |
| **Conversa** | Um envelope JSON por turno, com a transcrição da conversa como memória. Sem estado no processo — dois containers respondem igual. |
| **Ouve áudio** | Baixa a nota de voz pela ponte, transcreve (Groq whisper-large-v3-turbo, ~1s) e trata como um turno normal, marcado como transcrição. |
| **Lê arquivos** | Imagem por modelo de visão (com o texto dela transcrito), PDF pelo `pdftotext` local — e por visão, página a página, quando é digitalizado. Também docx, pptx, xlsx, csv, txt, json, e a fala de um vídeo. |
| **Fala** | ElevenLabs + ffmpeg → Ogg/Opus, enviado como **nota de voz** (a bolinha com onda), não como arquivo. Por padrão só responde em áudio quem mandou áudio. |
| **Chama o seu backend** | Ferramentas declaradas em `bot.config.ts`. O modelo escolhe o nome e preenche os parâmetros; o host, o path, o método e o token são decididos no código. |
| **Agenda** | Fila em SQLite: lembretes, recorrências em cron com fuso, e lembretes automáticos de compromisso. Sobrevive a restart. |
| **Parece gente** | Espera você terminar de escrever, marca como lida, pausa para "ler", digita no tempo do tamanho da mensagem, e quebra resposta longa em bolhas. |
| **Sai de cena** | Ação `transferir` desliga o bot naquela conversa. Um humano e um modelo respondendo juntos é a pior coisa que isto pode fazer na frente de um cliente. |

Ele **não** finge ser humano. Se perguntarem, ele diz que é um assistente
virtual — essa regra está em `src/agent/prompt.ts` e a config do cliente não
consegue removê-la.

## Subindo

Precisa de **Node 24+** (por `node:sqlite` e pelo type stripping nativo — é o
que permite este template não ter nenhuma dependência de runtime), de **ffmpeg**
para responder em áudio e ler vídeo, e de **poppler-utils** para ler PDF. O
`docker-compose.yml` já traz os dois; numa máquina sua, `apt install ffmpeg
poppler-utils`. Sem eles o bot sobe e diz no log o que não vai conseguir fazer.

```bash
cp .env.example .env      # preencha as chaves
npm install               # só typescript e @types/node, para o typecheck
npm run pair              # lê o QR, pareia o número
npm start                 # http://localhost:28528
```

Ou tudo junto, com a ponte:

```bash
docker compose up -d
docker compose exec bot node src/pair.ts
```

Nada é obrigatório. Sem chave de modelo ele guarda as mensagens e não responde;
sem ElevenLabs ele responde em texto; sem `BACKEND_URL` ele conversa mas não
consulta nada. O que falta é dito no log no boot — o que ele não faz é subir
meio configurado em silêncio.

```bash
curl localhost:28528/health   # o que está ligado, sem revelar chave nenhuma
```

## Fazendo dele o seu

Tudo em [`bot.config.ts`](bot.config.ts).

Ou comece de um preset em [`presets/`](presets/), já escrito para um ramo:

| Preset | Para quem |
| --- | --- |
| [`contabilidade.config.ts`](presets/contabilidade.config.ts) | Escritório de contabilidade: a carteira (pendências do mês, recebimento de documento, 2ª via de guia) e a captação (abrir empresa, MEI, trocar de contador) no mesmo número. O desenho do produto está em `Website/docs/contabilidade.md`. |
| [`advocacia.config.ts`](presets/advocacia.config.ts) | Escritório de advocacia: o cliente com processo (andamento no texto que o escritório liberou, audiências, documentos) e a triagem de quem ainda não é cliente (área, outra parte para checar conflito, consulta marcada). Não dá orientação jurídica nem capta. O desenho está em `Website/docs/advocacia.md`. |

`BOT_CONFIG=presets/contabilidade.config.ts npm start` sobe com ele. Um teste
(`src/presets.test.ts`) sobe cada preset pelo loader de verdade e confere que
todo parâmetro de toda ferramenta chega ao backend.

**1. A persona.** Quem é, o que faz, o que recusa, como escreve. As regras
não-negociáveis (nunca inventar preço, nunca pedir senha, nunca dizer que é
humano, nunca afirmar que fez algo que não fez) são acrescentadas por cima e não
saem.

**2. As ferramentas.** Cada uma é um endpoint seu:

```ts
{
  name: "consultar_horarios",
  description: "Lista os horários livres. Use SEMPRE antes de oferecer horário.",
  parameters: {
    data: { type: "string", description: 'A data, "AAAA-MM-DD".', required: true },
  },
  request: { method: "GET", path: "/agenda/disponibilidade", query: ["data"] },
  pending: "Deixa eu ver a agenda, um segundo…",
}
```

O modelo nunca escreve uma URL. Ele escreve `{"tipo":"ferramenta","nome":"consultar_horarios","argumentos":{"data":"2026-09-10"}}`,
e `src/agent/tools.ts` valida cada argumento contra o que a ferramenta declarou,
preenche o path, junta o token do ambiente e chama. O resultado volta para o
modelo, que aí responde a pessoa — até três rodadas por turno.

`confirm: true` marca uma ferramenta que muda alguma coisa. Ela só pode ser
chamada na primeira rodada de um turno, isto é, logo depois de a pessoa ter
falado — nunca encadeada no resultado de outra ferramenta.

**3. Os arquivos.** `media` liga cada tipo separadamente, porque ler os
documentos de um cliente é uma capacidade e não uma conveniência — um negócio
que recebe exame médico ou foto de RG pode muito bem preferir que o bot diga
"manda pro time". Todo limite se **anuncia**: quatro páginas de um PDF de
quarenta viram "li as 4 primeiras", nunca uma resposta que finge ter lido tudo.
Vídeo é só a fala, e o agente é avisado disso — dizer "vi seu vídeo" sobre uma
imagem que ninguém olhou é uma afirmação que o cliente não tem como conferir.

**4. A voz.** `reply: "espelho"` responde áudio com áudio, que é o que uma
pessoa faz. Link, e-mail e número longo nunca vão em áudio, em nenhum modo:
uma nota de voz é um péssimo lugar para uma coisa que precisa ser lida de volta.

**5. O ritmo.** `human` controla a espera, a leitura, a digitação e as bolhas.
Os padrões são conservadores; mexa neles depois de ler uma conversa de verdade.

**6. O horário.** `hours` decide o que acontece fora do expediente: responder
mesmo assim, avisar uma vez e segurar, ou ficar quieto.

## A API de operador

Atrás de `ADMIN_TOKEN` (sem ele, desligada — não aberta).

```bash
GET  /admin/conversations              # as conversas
GET  /admin/messages?conversation=ID   # a transcrição
POST /admin/send                       # {conversation, text} — e desliga o bot na thread
POST /admin/auto-reply                 # {conversation, on} — devolve a thread ao bot
POST /admin/profile                    # {phone, profile} — o que o seu sistema sabe da pessoa
```

`/admin/profile` é como o bot passa a abrir sabendo com quem está falando: mande
o que o seu backend souber quando o cliente comprar, se cadastrar ou mudar de
plano, e aquilo entra no prompt.

## Vários clientes na mesma imagem

`BOT_CONFIG=/configs/clinica.ts` mais uma `EVOLUTION_INSTANCE` diferente é outro
bot: outra persona, outras ferramentas, outro número. Um container por cliente,
uma imagem só.

## Testes

```bash
npm test        # 86 testes, nenhum gasta token
npm run typecheck
```

Três deles sobem o servidor de verdade contra dublês da ponte, do modelo, do
transcritor e da voz — e é o que prova que a coisa está ligada ponta a ponta:
que o que sai como áudio é Ogg/Opus no endpoint de nota de voz e não um mp3 no de
arquivo, e que a imagem vai para o modelo de *visão* e não para o de texto, que é
a falha que não dá erro nenhum.

## O que ler antes de mexer

[`AGENTS.md`](AGENTS.md) tem as decisões que não são óbvias no código, com o
motivo junto. Vale principalmente se você for pedir para um agente mexer aqui.
