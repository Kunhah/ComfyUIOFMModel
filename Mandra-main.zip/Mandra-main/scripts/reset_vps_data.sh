#!/usr/bin/env bash
#
# Limpa os dados do VPS, mantendo os logins.
#
#   ./scripts/reset_vps_data.sh                 simulação: conta o que apagaria
#   ./scripts/reset_vps_data.sh --yes           apaga (pergunta antes)
#   ./scripts/reset_vps_data.sh --yes <nome>    nomeia o container
#
# Roda NO VPS, onde o docker está. Ele acha o container, copia
# scripts/reset_data.mjs para dentro e roda lá — a imagem carrega só o
# bootstrap.mjs, então isto não depende de rebuild nem de redeploy.
#
# O que sobrevive: `users`, `accounts`, `intake_sites` e `meta`, nos três bancos
# do volume (prospector.db, b2b.db, analytics.db). Todo o resto — leads, ligações,
# buscas, auditoria, listas, templates, conversas de WhatsApp, runs de IA,
# analytics das landing pages — é apagado. A lista exata de exceções está no
# KEEP de scripts/reset_data.mjs, que é onde ela deve ser mudada.
#
# O container NÃO precisa reiniciar depois: nada em lib/ guarda essas leituras em
# memória, então a primeira página já carrega vazia.
set -euo pipefail

cd "$(dirname "$0")/.."

SCRIPT_SRC=scripts/reset_data.mjs
SCRIPT_DEST=/tmp/atlas-reset.mjs

APPLY=""
CONTAINER=""
for arg in "$@"; do
  case "$arg" in
    --yes) APPLY=1 ;;
    -*) printf 'Argumento desconhecido: %s\n' "$arg" >&2; exit 1 ;;
    *) CONTAINER="$arg" ;;
  esac
done

die() { printf '%s\n' "$*" >&2; exit 1; }

[ -f "$SCRIPT_SRC" ] || die "Não achei $SCRIPT_SRC. Rode a partir do repositório."
command -v docker >/dev/null || die "docker não encontrado. Este script roda no VPS."

# Mesma resolução do seed_prospector_volume.sh: o Dokploy prefixa o nome com o
# nome do projeto dele, então o container quase nunca se chama 'atlas-web-1'.
if [ -z "$CONTAINER" ]; then
  CONTAINER="$(docker ps --filter "ancestor=kunhah/atlas-digital" --format '{{.Names}}' | head -1)"
  [ -n "$CONTAINER" ] || CONTAINER="$(docker ps --filter "publish=28527" --format '{{.Names}}' | head -1)"
  [ -n "$CONTAINER" ] || die "Não achei o container. Rode 'docker ps' e passe o nome:
  ./scripts/reset_vps_data.sh --yes <nome>"
fi

printf 'Container: %s\n' "$CONTAINER"

# Vai como root:644 e o processo roda como nextjs, que só precisa ler.
docker cp "$SCRIPT_SRC" "$CONTAINER:$SCRIPT_DEST" >/dev/null
cleanup() { docker exec "$CONTAINER" rm -f "$SCRIPT_DEST" >/dev/null 2>&1 || true; }
trap cleanup EXIT

# A simulação roda sempre, inclusive antes de apagar: é ela que mostra, com os
# números reais deste servidor, o que a confirmação está autorizando.
docker exec "$CONTAINER" node "$SCRIPT_DEST"

if [ -z "$APPLY" ]; then
  printf '\nIsto foi só a simulação. Para apagar de verdade:\n'
  printf '  ./scripts/reset_vps_data.sh --yes %s\n' "$CONTAINER"
  exit 0
fi

# Só pergunta quando há um terminal: num cron ou num pipe o --yes já é a resposta.
if [ -t 0 ]; then
  printf '\nApagar essas linhas no container %s? [digite SIM] ' "$CONTAINER"
  read -r answer
  [ "$answer" = "SIM" ] || die "Cancelado, nada foi apagado."
fi

printf '\n'
# O backup (VACUUM INTO) é feito pelo script lá dentro, antes de apagar.
output="$(docker exec "$CONTAINER" node "$SCRIPT_DEST" --yes)"
printf '%s\n' "$output"

# O backup nasce dentro do volume, que é justamente o que se perde junto se o
# volume for embora. Uma cópia no host custa segundos e é a única que sobrevive
# a um `docker volume rm`.
#
# Fora do repositório de propósito: o Dokploy re-clona o repo a cada deploy, então
# um backup guardado aqui dentro é um backup com data de validade. HOST_BACKUPS
# muda o destino.
backup_dir="$(printf '%s\n' "$output" | sed -n 's/^Backup em \(.*\) (dentro do volume).*$/\1/p' | head -1)"
if [ -n "$backup_dir" ]; then
  dest_root="${HOST_BACKUPS:-$HOME/atlas-backups}"
  local_dir="$dest_root/$(basename "$backup_dir")"
  mkdir -p "$dest_root"
  if docker cp "$CONTAINER:$backup_dir" "$local_dir" >/dev/null 2>&1; then
    printf 'Backup também copiado para %s\n' "$local_dir"
  else
    printf 'Aviso: não consegui copiar o backup para fora. Ele está em %s, dentro do volume.\n' "$backup_dir"
  fi
fi
