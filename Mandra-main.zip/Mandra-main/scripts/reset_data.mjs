#!/usr/bin/env node
//
// Empty the data tables of the SQLite databases, keeping the logins.
//
//   node scripts/reset_data.mjs            dry run: counts every row it would delete
//   node scripts/reset_data.mjs --yes      actually deletes, after a backup
//
// Meant to run INSIDE the production container, where `node:sqlite` is already
// there (Node 26) and no `sqlite3` CLI is — see scripts/reset_vps_data.sh, which
// copies this file in and runs it. Run by hand with:
//
//   docker exec <container> node /tmp/atlas-reset.mjs --yes
//
// What survives is a keep-list, not a delete-list, and that direction is the
// point: a table added next month is data until someone says otherwise, so it is
// cleaned automatically instead of being silently missed by a list that went
// stale. Adding a new table that must survive means adding it to KEEP here.
import { DatabaseSync } from "node:sqlite";
import { existsSync, mkdirSync } from "node:fs";
import path from "node:path";

// Setup, not activity. `users` is the point of the exercise; `accounts` and
// `intake_sites` come with it because dropping them breaks things that outlive
// the data: a 'cliente' login whose account_id points at nothing fails the
// account check in requireClient(), and an intake site is the key an embedded
// form posts under — recreating it means a new key and a dead form until the
// client's page is redeployed. `meta` is migration bookkeeping (niche and
// sector fingerprints, one-shot dedup markers), never user data.
const KEEP = new Set(["users", "accounts", "intake_sites", "meta"]);

// The three files the volume holds. prospector.db carries the CRM *and*, as
// separate tables, the WhatsApp threads, the AI runs and the meeting reviews.
const FILES = ["prospector.db", "b2b.db", "analytics.db"];

const args = new Set(process.argv.slice(2));
const apply = args.has("--yes");
const skipBackup = args.has("--no-backup");

// WORKDIR is /app/Website and the app resolves data/ from process.cwd(), so this
// is the same directory the running server has open.
const DATA_DIR = process.env.ATLAS_DATA_DIR ?? "/app/Website/data";

function die(message) {
  console.error(message);
  process.exit(1);
}

// The guard against running this on a laptop. Inside the container /.dockerenv
// exists; anywhere else the directory has to be named explicitly, so wiping a
// development checkout is a deliberate act rather than a wrong `cd`.
if (!existsSync("/.dockerenv") && !process.env.ATLAS_DATA_DIR) {
  die(`Este script é para rodar dentro do container, no VPS.

  ./scripts/reset_vps_data.sh          (faz tudo: acha o container e roda isto)

Fora dele, aponte ATLAS_DATA_DIR para o diretório de bancos de propósito.`);
}

if (!existsSync(DATA_DIR)) die(`Diretório não encontrado: ${DATA_DIR}`);

const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
// Resolved once, before anything is deleted. VACUUM INTO refuses to overwrite,
// and discovering that on the second file — with the first already emptied — is
// the one way this leaves a half-cleaned database behind.
let backupDir = path.join(DATA_DIR, "backups", `reset-${stamp}`);
for (let n = 2; existsSync(backupDir); n += 1) {
  backupDir = path.join(DATA_DIR, "backups", `reset-${stamp}-${n}`);
}

/** Every real table in the file, in the order SQLite lists them. */
function tablesOf(db) {
  return db
    .prepare(
      `SELECT name FROM sqlite_master
        WHERE type = 'table' AND name NOT LIKE 'sqlite_%'
        ORDER BY name`,
    )
    .all()
    .map((row) => row.name);
}

function countOf(db, table) {
  // The name comes from sqlite_master, never from input, so interpolating it is
  // the only option — a table name cannot be a bound parameter.
  return db.prepare(`SELECT count(*) AS n FROM "${table}"`).get().n;
}

let totalToDelete = 0;
let anyFile = false;

for (const file of FILES) {
  const full = path.join(DATA_DIR, file);
  if (!existsSync(full)) {
    console.log(`\n${file} — não existe ainda, pulando.`);
    continue;
  }
  anyFile = true;

  // Foreign keys off: the tables reference each other (call_list_items → leads,
  // wa_messages → wa_conversations, …) and emptying them in alphabetical order
  // would trip a constraint that is meaningless here, since every child and
  // every parent among them is being emptied in the same transaction.
  const db = new DatabaseSync(full, { enableForeignKeyConstraints: false });

  try {
    const tables = tablesOf(db);
    const toClear = tables.filter((t) => !KEEP.has(t));
    const kept = tables.filter((t) => KEEP.has(t));

    console.log(`\n${file}`);
    for (const table of kept) {
      console.log(`  mantém   ${table.padEnd(26)} ${countOf(db, table)} linhas`);
    }
    let fileRows = 0;
    for (const table of toClear) {
      const n = countOf(db, table);
      fileRows += n;
      console.log(`  limpa    ${table.padEnd(26)} ${n} linhas`);
    }
    totalToDelete += fileRows;

    if (!apply || fileRows === 0) {
      if (apply) console.log("  (já está vazio)");
      continue;
    }

    // VACUUM INTO, not a file copy: it is the supported way to back up a
    // database that another process has open, and it folds the -wal in rather
    // than leaving a copy that is missing the last writes.
    if (!skipBackup) {
      mkdirSync(backupDir, { recursive: true });
      const target = path.join(backupDir, file);
      db.exec(`VACUUM INTO '${target.replace(/'/g, "''")}'`);
      console.log(`  backup   ${target}`);
    }

    db.exec("BEGIN");
    try {
      for (const table of toClear) db.exec(`DELETE FROM "${table}"`);

      // Denormalised counters on a table we keep. Left alone they would claim
      // leads that no longer exist, and the intake list reads them rather than
      // counting — see lib/crm/sites.ts.
      if (tables.includes("intake_sites")) {
        db.exec("UPDATE intake_sites SET lead_count = 0, last_lead_at = NULL");
      }

      // Only exists when some table was declared AUTOINCREMENT. Resetting it
      // makes the next id 1 again instead of continuing from the deleted rows.
      if (
        db
          .prepare(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='sqlite_sequence'",
          )
          .get()
      ) {
        const names = toClear.map((t) => `'${t}'`).join(",");
        if (names) db.exec(`DELETE FROM sqlite_sequence WHERE name IN (${names})`);
      }

      db.exec("COMMIT");
    } catch (err) {
      db.exec("ROLLBACK");
      throw err;
    }
    console.log(`  ${fileRows} linhas apagadas.`);

    // Reclaims the pages the deletes freed. Best effort on purpose: VACUUM needs
    // the whole file to itself, so it can lose to the running server holding a
    // read — which costs disk space, not correctness, and the next one gets it.
    try {
      db.exec("VACUUM");
    } catch (err) {
      console.log(`  (VACUUM não rodou: ${err.message} — sem problema)`);
    }
  } finally {
    db.close();
  }
}

if (!anyFile) die(`\nNenhum banco encontrado em ${DATA_DIR}.`);

if (!apply) {
  console.log(`\n--- SIMULAÇÃO --- ${totalToDelete} linhas seriam apagadas.`);
  console.log("Rode de novo com --yes para apagar de verdade.");
} else {
  console.log(`\nPronto. ${totalToDelete} linhas apagadas.`);
  if (!skipBackup && totalToDelete > 0) {
    console.log(`Backup em ${backupDir} (dentro do volume).`);
  }
  // No restart needed: nothing in lib/ caches these reads in memory, so the
  // next page load already sees the empty tables.
}
