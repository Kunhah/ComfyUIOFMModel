#!/usr/bin/env bash
#
# Build the Atlas Digital image and push it to Docker Hub.
#
#   ./scripts/publish_images.sh                  build + push :latest and :<git-sha>
#   ./scripts/publish_images.sh v1.2.0           ...and :v1.2.0 as well
#   ./scripts/publish_images.sh --no-push        build only, load into the local daemon
#   ./scripts/publish_images.sh --platform linux/amd64,linux/arm64
#
# Every default is overridable by environment variable, so CI can set them
# without touching the flags:
#
#   DOCKER_HUB_USER   Docker Hub namespace          (default: kunhah)
#   IMAGE_NAME        repository within it          (default: atlas-digital)
#   PLATFORMS         target platforms              (default: linux/amd64)
#
# The image is tagged with the commit SHA as well as `latest` because `latest`
# alone gives a deployed container no way to say which build it is running, and
# no way to roll back to a specific one.

set -euo pipefail

DOCKER_HUB_USER="${DOCKER_HUB_USER:-kunhah}"
IMAGE_NAME="${IMAGE_NAME:-atlas-digital}"
PLATFORMS="${PLATFORMS:-linux/amd64}"

PUSH=1
TAG_LATEST=1
EXTRA_TAGS=()

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

die() {
  printf '\033[31merror\033[0m %s\n' "$*" >&2
  exit 1
}
say() { printf '\033[36m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[33mwarning\033[0m %s\n' "$*" >&2; }

usage() {
  sed -n '3,20p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
  exit "${1:-0}"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --no-push)      PUSH=0; shift ;;
    --no-latest)    TAG_LATEST=0; shift ;;
    --platform)     PLATFORMS="${2:?--platform needs a value}"; shift 2 ;;
    --platform=*)   PLATFORMS="${1#*=}"; shift ;;
    --image)        IMAGE_NAME="${2:?--image needs a value}"; shift 2 ;;
    --image=*)      IMAGE_NAME="${1#*=}"; shift ;;
    --user)         DOCKER_HUB_USER="${2:?--user needs a value}"; shift 2 ;;
    --user=*)       DOCKER_HUB_USER="${1#*=}"; shift ;;
    -h|--help)      usage 0 ;;
    -*)             die "unknown option: $1 (try --help)" ;;
    *)              EXTRA_TAGS+=("$1"); shift ;;
  esac
done

# --- preflight -------------------------------------------------------------
# All of it up front: a build takes minutes, and finding out afterwards that the
# push has nowhere to go wastes every one of them.

command -v docker >/dev/null 2>&1 || die "docker is not installed."

docker version >/dev/null 2>&1 ||
  die "the Docker daemon isn't reachable. Start it with: sudo systemctl start docker"

docker buildx version >/dev/null 2>&1 ||
  die "docker buildx is missing — install the docker-buildx plugin."

REPO="${DOCKER_HUB_USER}/${IMAGE_NAME}"

# Multi-platform manifests can't be loaded into the local daemon; there is no
# single image to load. Building them without pushing produces nothing usable.
if [[ $PUSH -eq 0 && "$PLATFORMS" == *,* ]]; then
  die "--no-push can't build multiple platforms ($PLATFORMS) — the local daemon takes one image at a time."
fi

if [[ $PUSH -eq 1 ]] && ! grep -q 'index.docker.io' "${DOCKER_CONFIG:-$HOME/.docker}/config.json" 2>/dev/null; then
  say "Not logged in to Docker Hub — running docker login."
  # No --username: pushing to an organisation namespace means logging in as a
  # member account, which is not the namespace itself.
  docker login || die "docker login failed; nothing was built."
fi

# --- tags ------------------------------------------------------------------

if git -C "$repo_root" rev-parse --git-dir >/dev/null 2>&1; then
  sha="$(git -C "$repo_root" rev-parse --short HEAD)"
  # A dirty tree means the SHA tag names a commit the image doesn't match — the
  # one case where "roll back to that tag" quietly gives you the wrong build.
  if [[ -n "$(git -C "$repo_root" status --porcelain)" ]]; then
    warn "working tree has uncommitted changes; :${sha} won't match commit ${sha}."
  fi
else
  sha=""
  warn "not a git repository — skipping the commit-SHA tag."
fi

tags=()
[[ $TAG_LATEST -eq 1 ]] && tags+=("latest")
[[ -n "$sha" ]] && tags+=("$sha")
tags+=("${EXTRA_TAGS[@]+"${EXTRA_TAGS[@]}"}")

[[ ${#tags[@]} -gt 0 ]] || die "no tags to publish (--no-latest outside a git repo?)."

tag_args=()
for t in "${tags[@]}"; do
  tag_args+=(--tag "${REPO}:${t}")
done

# --- build -----------------------------------------------------------------

say "Repository : ${REPO}"
say "Tags       : ${tags[*]}"
say "Platforms  : ${PLATFORMS}"
say "Context    : ${repo_root}"

# buildx needs a container driver for multi-platform builds; the default
# "docker" driver can only build for the host.
if [[ "$PLATFORMS" == *,* ]] && [[ "$(docker buildx inspect --bootstrap 2>/dev/null | awk '/^Driver:/{print $2}')" == "docker" ]]; then
  say "Selecting a container-driver buildx builder for multi-platform output."
  # Reuse the builder if a previous run left one behind; creating it twice is an
  # error, and set -e would turn that into a failed publish.
  docker buildx use atlas-builder 2>/dev/null ||
    docker buildx create --name atlas-builder --driver docker-container --use >/dev/null
fi

output_arg=(--load)
[[ $PUSH -eq 1 ]] && output_arg=(--push)

docker buildx build \
  --platform "$PLATFORMS" \
  "${tag_args[@]}" \
  "${output_arg[@]}" \
  --file "${repo_root}/Dockerfile" \
  "$repo_root"

# --- done ------------------------------------------------------------------

if [[ $PUSH -eq 1 ]]; then
  say "Pushed:"
  for t in "${tags[@]}"; do echo "    ${REPO}:${t}"; done
  echo
  say "Deploy: set ATLAS_TAG to the commit-SHA tag in Dokploy, then hit Redeploy."
  say "Dokploy pulls a new SHA once and reuses it on later redeploys."
  if [[ -n "$sha" ]]; then
    say "To pin this exact build instead, set ATLAS_TAG=${sha} in Dokploy's"
    say "Environment tab — that is what the commit-SHA tag is for."
  fi
  echo
  say "Anywhere else:"
  echo "    docker compose pull && docker compose up -d"
else
  say "Built locally (not pushed): ${REPO}:${tags[0]}"
  echo "    docker run --rm -p 28527:28527 -v atlas-data:/app/Website/data ${REPO}:${tags[0]}"
fi
