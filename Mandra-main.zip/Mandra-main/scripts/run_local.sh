#!/usr/bin/env bash
# Start Atlas Digital locally from any directory.
#
#   ./scripts/run_local.sh                 # marketing site at http://localhost:3000
#   ./scripts/run_local.sh --prospector    # validates prospector data first
#   PORT=3001 ./scripts/run_local.sh       # choose a different port
#
# Extra arguments are forwarded to Next.js, e.g.:
#   ./scripts/run_local.sh -- --hostname 0.0.0.0
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_root"

# Next runs from the Website workspace, so it only discovers Website/.env by
# itself. Keep the repo-level .env useful for the local launcher as well,
# without copying credentials into the workspace or committing a second file.
if [[ -f .env ]]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  printf 'Node.js and npm are required. Install a current Node.js LTS release, then try again.\n' >&2
  exit 1
fi

if [[ ! -d node_modules ]]; then
  printf 'Installing project dependencies…\n'
  npm ci
fi

mode="dev"
if [[ "${1:-}" == "--prospector" ]]; then
  mode="prospector"
  shift
fi

if [[ "${1:-}" == "--" ]]; then
  shift
fi

port="${PORT:-3000}"
if [[ "$mode" == "prospector" ]]; then
  printf 'Starting Atlas Digital with Prospector checks at http://localhost:%s\n' "$port"
  exec npm run up --workspace Website -- --port "$port" "$@"
fi

printf 'Starting Atlas Digital at http://localhost:%s\n' "$port"
exec npm run dev --workspace Website -- --port "$port" "$@"
