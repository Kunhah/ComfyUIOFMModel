#!/usr/bin/env bash
#
# Copy the Overture extract into the running container's data volume.
#
#   ./scripts/seed_prospector_volume.sh                 find the container itself
#   ./scripts/seed_prospector_volume.sh atlas-web-1     name it explicitly
#   EXTRACT=/path/to/places.parquet ./scripts/seed_prospector_volume.sh
#
# Why this exists: the volume starts empty by design — the 122MB extract is
# runtime state, not build output, so it is neither in the image nor in git. Until
# it is seeded the prospector falls back to querying S3 at 90s–230s per search,
# which looks like the tool being broken rather than unconfigured.
#
# Run it from the machine holding places.parquet. If that is not the VPS, copy
# the file over first (scp) and point EXTRACT at it.
set -euo pipefail

cd "$(dirname "$0")/.."

# The current name, falling back to the Brazil-only one earlier syncs wrote.
EXTRACT="${EXTRACT:-}"
if [ -z "$EXTRACT" ]; then
  for candidate in Website/data/places.parquet Website/data/br-leads.parquet; do
    [ -f "$candidate" ] && EXTRACT="$candidate" && break
  done
  EXTRACT="${EXTRACT:-Website/data/places.parquet}"
fi
CONTAINER="${1:-}"
DEST=/app/Website/data

die() { printf '%s\n' "$*" >&2; exit 1; }

[ -f "$EXTRACT" ] || die "Não encontrei $EXTRACT.
Rode 'npm run sync' (de Website/) para construir o extrato, ou aponte EXTRACT
para o arquivo."

# The column the search prunes on. Parquet keeps its schema field names as plain
# UTF-8 in the footer, so grep finds it without needing DuckDB or Node installed
# on whatever box is doing the seeding — which is the point, since this often runs
# on a bare VPS.
if ! grep -qa city_norm "$EXTRACT"; then
  die "O extrato não tem a coluna city_norm.
Rode 'npm run upgrade-extract' (de Website/) — leva segundos e não baixa nada.
Sem ela cada busca lê ~9x mais do arquivo."
fi

# Resolve the container from the compose project rather than assuming a name:
# Dokploy prefixes it with its own project name, so it is rarely 'atlas-web-1'.
if [ -z "$CONTAINER" ]; then
  CONTAINER="$(docker ps --filter "ancestor=kunhah/atlas-digital" --format '{{.Names}}' | head -1)"
  [ -n "$CONTAINER" ] || CONTAINER="$(docker ps --filter "publish=28527" --format '{{.Names}}' | head -1)"
  [ -n "$CONTAINER" ] || die "Não achei o container. Rode 'docker ps' e passe o nome:
  ./scripts/seed_prospector_volume.sh <nome>"
fi

size=$(du -h "$EXTRACT" | cut -f1)
printf 'Copiando %s (%s) para %s:%s\n' "$EXTRACT" "$size" "$CONTAINER" "$DEST"

# Always lands under the current name, whatever the source file is called: the
# app prefers it, and a container holding both would keep reading the old one.
docker cp "$EXTRACT" "$CONTAINER:$DEST/places.parquet"

# The connection is created once per process and the source is chosen per query,
# but the file has to exist before the first search to be picked up as `local`.
# Restarting is the simple way to be sure, and costs a few seconds.
docker restart "$CONTAINER" >/dev/null
printf 'Container reiniciado.\n\n'

printf 'Confira com:\n'
printf "  curl -s localhost:28527/api/prospector/search | head -c 200\n"
printf 'localExtract:true significa que o extrato foi encontrado.\n'
