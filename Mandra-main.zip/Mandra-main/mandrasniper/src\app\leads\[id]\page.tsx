"use client";

import React, { useEffect, useState, use } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  Sparkles,
  ShieldCheck,
  Target,
  Globe,
  MessageCircle,
  Phone,
  MapPin,
  Star,
  CheckCircle2,
  AlertTriangle,
  Send,
  ExternalLink,
  Copy,
  Check,
  Clock,
  Building2,
} from "lucide-react";
import type { Lead } from "@/types";
import { OutreachPanel } from "@/components/outreach-panel";
import { StatusPicker } from "@/components/status-picker";
import { outreachMessage, whatsappUrl } from "@/lib/score";

export default function LeadDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const resolvedParams = use(params);
  const leadId = resolvedParams.id;

  const [lead, setLead] = useState<Lead | null>(null);
  const [loading, setLoading] = useState(true);
  const [outreachOpen, setOutreachOpen] = useState(false);

  useEffect(() => {
    async function loadLead() {
      try {
        const res = await fetch(`/api/leads/${leadId}`);
        const data = await res.json();
        if (data.lead) {
          setLead(data.lead);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    loadLead();
  }, [leadId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20 text-xs text-[#FF9E1B] font-bold">
        Carregando inteligência do lead...
      </div>
    );
  }

  if (!lead) {
    return (
      <div className="space-y-4 max-w-xl text-center py-16">
        <h2 className="text-xl font-bold text-[#1E2026]">Lead não encontrado</h2>
        <Link href="/leads" className="text-xs font-bold text-[#FF9E1B] hover:underline">
          ← Voltar para a lista de leads
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-6xl">
      {/* Back Link */}
      <Link href="/leads" className="inline-flex items-center gap-2 text-xs font-bold text-[#6E7381] hover:text-[#1E2026]">
        <ArrowLeft className="size-4" />
        <span>Voltar para Lista de Leads</span>
      </Link>

      {/* Hero Section */}
      <div className="rounded-2xl border border-[#ECE8E0] bg-white p-6 shadow-md space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between border-b border-[#ECE8E0] pb-6">
          <div className="flex items-center gap-4">
            <div className="flex size-14 items-center justify-center rounded-2xl bg-[#181A20] text-xl font-black text-[#FF9E1B] shadow-sm">
              {lead.sniperScore}
            </div>
            <div>
              <div className="flex items-center gap-3">
                <h1 className="text-2xl font-black text-[#1E2026]">{lead.name}</h1>
                <span className="rounded-lg bg-[#FF9E1B]/15 px-2.5 py-0.5 text-xs font-black text-[#FF9E1B] uppercase border border-[#FF9E1B]/30">
                  SNIPER {lead.sniperScore}/100
                </span>
                <span className="rounded-md bg-emerald-500/15 text-emerald-700 px-2 py-0.5 text-[10px] font-extrabold uppercase border border-emerald-500/30">
                  Data Confidence: {lead.confidenceLevel}
                </span>
              </div>
              <p className="text-xs text-[#6E7381] mt-1">
                {lead.category} · {lead.city}, {lead.state} · {lead.address}
              </p>
            </div>
          </div>

          {/* SDR Action Buttons */}
          <div className="flex items-center gap-3">
            <StatusPicker id={lead.id} status={lead.crmStatus} />
            <button
              onClick={() => setOutreachOpen(true)}
              className="flex items-center gap-2 rounded-xl bg-[#1C1F26] px-5 py-3 text-xs font-bold text-white hover:bg-[#2A2E38] transition shadow-md"
            >
              <Sparkles className="size-4 text-[#FF9E1B]" />
              <span>GERAR ABORDAGEM IA</span>
            </button>
          </div>
        </div>

        {/* Fact Summary Line */}
        <div className="rounded-xl border border-[#E2DDD3] bg-[#FAF9F6] p-4 text-xs font-medium text-[#1E2026] leading-relaxed">
          <strong>Resumo Executivo:</strong> {lead.insights?.summary || `${lead.name} possui ${lead.reviewsCount} avaliações com nota ${lead.rating} no Google, porém não tem website oficial próprio.`}
        </div>

        {/* Facts Badges Row */}
        <div className="flex flex-wrap gap-2 text-xs">
          <span className="rounded-xl border border-[#E2DDD3] bg-[#FAF8F4] px-3 py-1.5 font-bold text-[#1E2026] flex items-center gap-1.5">
            <Star className="size-3.5 text-amber-500 fill-amber-500" />
            {lead.rating.toFixed(1)} ({lead.reviewsCount} avaliações)
          </span>

          <span className="rounded-xl border border-[#E2DDD3] bg-[#FAF8F4] px-3 py-1.5 font-bold text-[#FF9E1B] flex items-center gap-1.5">
            <Globe className="size-3.5" />
            {lead.websiteStatus === "NO_WEBSITE" ? "Sem Website Oficial" : lead.websiteStatus}
          </span>

          {lead.phone && (
            <span className="rounded-xl border border-[#E2DDD3] bg-[#FAF8F4] px-3 py-1.5 font-bold text-emerald-700 flex items-center gap-1.5">
              <MessageCircle className="size-3.5 text-[#25D366]" />
              {lead.phone}
            </span>
          )}
        </div>
      </div>

      {/* Grid Section: WHY THIS LEAD? & PAIN DETECTOR */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* WHY THIS LEAD? (Score Breakdown) */}
        <div className="rounded-2xl border border-[#ECE8E0] bg-white p-6 shadow-2xs space-y-4">
          <div className="flex items-center gap-2.5 border-b border-[#ECE8E0] pb-3">
            <Target className="size-5 text-[#FF9E1B]" />
            <h3 className="font-extrabold text-base text-[#1E2026]">WHY THIS LEAD? (SCORE BREAKDOWN)</h3>
          </div>

          <div className="space-y-2.5 text-xs">
            {lead.scoreBreakdown.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between rounded-xl bg-[#FAF8F4] p-3 border border-[#ECE8E0]">
                <span className="font-semibold text-[#1E2026]">{item.reason}</span>
                <span className="font-black text-[#FF9E1B] tnum">+{item.points} pts</span>
              </div>
            ))}
          </div>
        </div>

        {/* PAIN DETECTOR */}
        <div className="rounded-2xl border border-[#ECE8E0] bg-white p-6 shadow-2xs space-y-4">
          <div className="flex items-center gap-2.5 border-b border-[#ECE8E0] pb-3">
            <AlertTriangle className="size-5 text-amber-500" />
            <h3 className="font-extrabold text-base text-[#1E2026]">PAIN DETECTOR (DORES DETECTADAS)</h3>
          </div>

          <div className="space-y-3 text-xs">
            {lead.insights?.painPoints && lead.insights.painPoints.length > 0 ? (
              lead.insights.painPoints.map((pain, idx) => (
                <div key={idx} className="rounded-xl border border-amber-200 bg-amber-50/50 p-3.5 space-y-1">
                  <div className="font-bold text-amber-900">{pain.problem}</div>
                  <div className="text-[11px] text-amber-800 leading-snug">Evidência: {pain.evidence}</div>
                </div>
              ))
            ) : (
              <div className="rounded-xl border border-[#ECE8E0] bg-[#FAF8F4] p-4 text-gray-500">
                Sem site próprio mapeado · Prejuízo de captação orgânica no Google
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Section: FACT VS INFERENCE VS UNKNOWN */}
      <div className="rounded-2xl border border-[#ECE8E0] bg-white p-6 shadow-2xs space-y-4">
        <div className="flex items-center gap-2.5 border-b border-[#ECE8E0] pb-3">
          <ShieldCheck className="size-5 text-[#FF9E1B]" />
          <h3 className="font-extrabold text-base text-[#1E2026]">FACT VS INFERENCE VS UNKNOWN (ZERO HALLUCINATION)</h3>
        </div>

        <div className="grid gap-4 sm:grid-cols-3 text-xs">
          {/* FACTS */}
          <div className="rounded-xl border border-emerald-200 bg-emerald-50/50 p-4 space-y-2">
            <div className="font-extrabold text-emerald-900 flex items-center gap-1.5 uppercase">
              <CheckCircle2 className="size-4 text-emerald-600" />
              <span>FATOS CONFIRMADOSS</span>
            </div>
            <ul className="space-y-1 text-emerald-800 text-[11px]">
              <li>• Nome: {lead.facts.name.value}</li>
              <li>• Avaliações: {lead.facts.reviewsCount.value} (Nota {lead.facts.rating.value})</li>
              <li>• Website: {lead.facts.website.value || "Confirmado ausente (NULL)"}</li>
            </ul>
          </div>

          {/* INFERENCES */}
          <div className="rounded-xl border border-blue-200 bg-blue-50/50 p-4 space-y-2">
            <div className="font-extrabold text-blue-900 flex items-center gap-1.5 uppercase">
              <Sparkles className="size-4 text-blue-600" />
              <span>INFERÊNCIAS COMERCIAIS</span>
            </div>
            <ul className="space-y-1 text-blue-800 text-[11px]">
              <li>• Alta probabilidade de perder clientes sem landing page</li>
              <li>• Perfil propício para fechamento em 48h no WhatsApp</li>
            </ul>
          </div>

          {/* UNKNOWN */}
          <div className="rounded-xl border border-gray-200 bg-gray-50 p-4 space-y-2">
            <div className="font-extrabold text-gray-700 flex items-center gap-1.5 uppercase">
              <Clock className="size-4 text-gray-500" />
              <span>DESCONHECIDOS (UNKNOWN)</span>
            </div>
            <ul className="space-y-1 text-gray-600 text-[11px]">
              <li>• Nome do Proprietário: UNKNOWN</li>
              <li>• Faturamento Estimado: UNKNOWN</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Outreach Drawer */}
      <OutreachPanel
        lead={lead}
        open={outreachOpen}
        onClose={() => setOutreachOpen(false)}
      />
    </div>
  );
}
