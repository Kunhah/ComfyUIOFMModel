"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import {
  Kanban,
  Plus,
  MessageCircle,
  Sparkles,
  DollarSign,
  ChevronRight,
  MoreVertical,
  ShieldCheck,
} from "lucide-react";
import type { CrmDeal, LeadCrmStatus } from "@/types";
import { outreachMessage, whatsappUrl } from "@/lib/score";

const STAGES: { id: LeadCrmStatus; label: string; color: string }[] = [
  { id: "NOVO", label: "Novo Lead", color: "border-gray-300 text-gray-700 bg-gray-100" },
  { id: "QUALIFICADO", label: "Qualificado", color: "border-blue-300 text-blue-700 bg-blue-50" },
  { id: "ABORDAGEM", label: "Abordagem", color: "border-[#FF9E1B]/50 text-[#FF9E1B] bg-[#FFF5E6]" },
  { id: "CONTATADO", label: "Contatado", color: "border-amber-300 text-amber-700 bg-amber-50" },
  { id: "RESPONDEU", label: "Respondeu", color: "border-purple-300 text-purple-700 bg-purple-50" },
  { id: "REUNIÃO", label: "Reunião Agendada", color: "border-indigo-300 text-indigo-700 bg-indigo-50" },
  { id: "PROPOSTA", label: "Proposta Enviada", color: "border-cyan-300 text-cyan-700 bg-cyan-50" },
  { id: "GANHO", label: "Venda Ganha", color: "border-emerald-400 text-emerald-800 bg-emerald-50" },
  { id: "PERDIDO", label: "Perdido", color: "border-red-300 text-red-700 bg-red-50" },
];

export default function CrmPage() {
  const [deals, setDeals] = useState<CrmDeal[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchDeals = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/crm");
      const data = await res.json();
      if (data.deals) {
        setDeals(data.deals);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDeals();
  }, []);

  const moveStage = async (leadId: string, newStage: LeadCrmStatus) => {
    // Optimistic UI update
    setDeals((prev) =>
      prev.map((d) => (d.leadId === leadId ? { ...d, status: newStage, stageId: newStage } : d))
    );

    try {
      await fetch("/api/crm", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ leadId, stageId: newStage }),
      });
    } catch (e) {
      console.error(e);
      fetchDeals(); // Revert on failure
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20 text-xs font-bold text-[#FF9E1B]">
        Carregando Kanban do CRM...
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-[1600px]">
      {/* Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between border-b border-[#ECE8E0] pb-4">
        <div>
          <h1 className="text-2xl font-black text-[#1E2026] uppercase flex items-center gap-2">
            <Kanban className="size-6 text-[#FF9E1B]" />
            <span>CRM & Pipeline de Vendas</span>
          </h1>
          <p className="text-xs text-[#6E7381]">
            Gestão de oportunidades comerciais com movimentação de estágios e persistência real.
          </p>
        </div>

        <Link
          href="/prospecting"
          className="inline-flex items-center gap-2 rounded-xl bg-[#1C1F26] px-4 py-2.5 text-xs font-bold text-white hover:bg-[#2A2E38] transition shadow-xs"
        >
          <Plus className="size-4 text-[#FF9E1B]" />
          <span>Prospectar Novos Leads</span>
        </Link>
      </div>

      {/* Kanban Board Container */}
      <div className="flex gap-4 overflow-x-auto pb-6">
        {STAGES.map((stage) => {
          const stageDeals = deals.filter((d) => d.status === stage.id);
          const stageTotalValue = stageDeals.reduce((sum, d) => sum + (d.dealValue || 0), 0);

          return (
            <div
              key={stage.id}
              className="w-[280px] shrink-0 rounded-2xl border border-[#ECE8E0] bg-[#FAF8F4] p-3 flex flex-col justify-between"
            >
              <div>
                {/* Stage Header */}
                <div className="flex items-center justify-between border-b border-[#ECE8E0] pb-2.5 mb-3 px-1">
                  <div className="flex items-center gap-2">
                    <span className={`rounded-md border px-2 py-0.5 text-[11px] font-extrabold uppercase ${stage.color}`}>
                      {stage.label}
                    </span>
                    <span className="text-xs font-bold text-[#6E7381] tnum">
                      {stageDeals.length}
                    </span>
                  </div>
                </div>

                {/* Deal Cards */}
                <div className="space-y-3">
                  {stageDeals.map((deal) => (
                    <div
                      key={deal.id}
                      className="rounded-xl border border-[#ECE8E0] bg-white p-4 shadow-2xs hover:border-[#FF9E1B] transition space-y-3"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="rounded bg-[#FF9E1B]/15 px-1.5 py-0.5 text-[9px] font-black text-[#FF9E1B] uppercase">
                            SNIPER {deal.lead.sniperScore}
                          </span>
                          <h4 className="font-extrabold text-[#1E2026] text-xs mt-1">
                            <Link href={`/leads/${deal.lead.id}`} className="hover:underline">
                              {deal.lead.name}
                            </Link>
                          </h4>
                          <p className="text-[11px] text-[#6E7381]">
                            {deal.lead.category} · {deal.lead.city}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-[#6E7381] border-t border-[#ECE8E0] pt-2">
                        <span className="font-bold text-[#1E2026]">
                          R$ {deal.dealValue.toLocaleString("pt-BR")}
                        </span>

                        {deal.lead.phone && (
                          <a
                            href={whatsappUrl(deal.lead.phone, outreachMessage(deal.lead)) ?? "#"}
                            target="_blank"
                            rel="noreferrer"
                            className="text-[#25D366] hover:underline flex items-center gap-1 font-bold"
                          >
                            <MessageCircle className="size-3" />
                            <span>WhatsApp</span>
                          </a>
                        )}
                      </div>

                      {/* Move Stage Selector */}
                      <select
                        value={deal.status}
                        onChange={(e) => moveStage(deal.leadId, e.target.value as LeadCrmStatus)}
                        className="w-full rounded-lg border border-[#E2DDD3] bg-[#FAF9F6] px-2 py-1 text-[10px] font-bold text-[#1E2026] outline-none"
                      >
                        {STAGES.map((s) => (
                          <option key={s.id} value={s.id}>
                            Mover para: {s.label}
                          </option>
                        ))}
                      </select>
                    </div>
                  ))}

                  {stageDeals.length === 0 && (
                    <div className="rounded-xl border border-dashed border-[#E2DDD3] p-4 text-center text-[11px] text-gray-400 font-medium">
                      Nenhum lead nesta etapa
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
