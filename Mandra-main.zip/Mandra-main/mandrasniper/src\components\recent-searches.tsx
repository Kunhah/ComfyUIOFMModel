"use client";

import React from "react";
import { History, ArrowRight, Sparkles } from "lucide-react";

export interface RecentSearchItem {
  id: string;
  niche: string;
  location: string;
  count: number;
}

export function RecentSearches({
  searches,
  onSelect,
}: {
  searches: RecentSearchItem[];
  onSelect: (item: RecentSearchItem) => void;
}) {
  if (!searches || searches.length === 0) return null;

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 text-xs font-black text-[#8E94A2] uppercase tracking-wider">
        <History className="size-3.5 text-[#FF9E1B]" />
        <span>BUSCAS RECENTES</span>
      </div>

      <div className="grid gap-3 sm:grid-cols-3 text-xs">
        {searches.slice(0, 3).map((item) => (
          <div
            key={item.id}
            onClick={() => onSelect(item)}
            className="rounded-2xl border border-[#2B2E3C] bg-[#14161C] p-4 cursor-pointer hover:border-[#FF9E1B] transition space-y-2 group"
          >
            <div className="flex items-center justify-between">
              <div className="font-extrabold text-white text-sm">{item.niche}</div>
              <span className="rounded bg-[#FF9E1B]/15 px-2 py-0.5 text-[10px] font-extrabold text-[#FF9E1B]">
                {item.count} leads
              </span>
            </div>
            <div className="text-[11px] text-gray-400 font-medium">{item.location}</div>
            <div className="text-[10px] font-bold text-[#FF9E1B] flex items-center gap-1 pt-1">
              <span>Buscar novamente</span>
              <ArrowRight className="size-3 group-hover:translate-x-1 transition" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
