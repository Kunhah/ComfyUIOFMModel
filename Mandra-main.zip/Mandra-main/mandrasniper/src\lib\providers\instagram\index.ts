import type { InstagramProfileRecord, InstagramProvider, ProviderResult } from "../types";

export class InstagramProviderImpl implements InstagramProvider {
  private apiKey: string | null = null;

  constructor() {
    const key = process.env.INSTAGRAM_PROVIDER_API_KEY;
    if (key && key.trim().length > 0) {
      this.apiKey = key.trim();
    }
  }

  public async getProfile(urlOrUsername: string): Promise<ProviderResult<InstagramProfileRecord>> {
    if (!urlOrUsername || urlOrUsername.trim().length === 0) {
      return {
        status: "NOT_CONFIGURED",
        data: null,
        message: "Nenhum link ou usuário de Instagram fornecido.",
      };
    }

    const cleanUsername = urlOrUsername
      .replace(/https?:\/\/(www\.)?instagram\.com\//, "")
      .replace(/\/.*$/, "")
      .replace("@", "")
      .trim();

    if (!this.apiKey) {
      // Compliance-safe Mock Provider in DEMO MODE (without illegal scraping or login bypass)
      return {
        status: "DEMO_MODE",
        isDemo: true,
        data: {
          username: cleanUsername || "perfil.demo",
          url: `https://instagram.com/${cleanUsername || "perfil.demo"}`,
          followersCount: 4850,
          isActive: true,
          lastPostAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
          bioText: "Atendimento especializado | Agendamentos via WhatsApp",
        },
        message: "Instagram Provider em Modo Demonstração (API Oficial não conectada).",
      };
    }

    try {
      // Connect to authorized official provider when API key is provided
      const res = await fetch(`https://api.instagram.com/v1/users/self?access_token=${this.apiKey}`);
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }
      const json = await res.json();
      return {
        status: "CONFIGURED",
        isDemo: false,
        data: {
          username: json.data?.username || cleanUsername,
          url: `https://instagram.com/${json.data?.username || cleanUsername}`,
          followersCount: json.data?.counts?.followed_by || 0,
          isActive: true,
          lastPostAt: new Date().toISOString(),
          bioText: json.data?.bio || "",
        },
      };
    } catch (err) {
      return {
        status: "ERROR",
        data: null,
        message: `Falha ao consultar API do Instagram: ${err instanceof Error ? err.message : String(err)}`,
      };
    }
  }
}
