"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { BookmarkCheck, Play, Sparkles, SlidersHorizontal } from "lucide-react";

export default function SearchesPage() {
  const [searches, setSearches] = useState<any[]>([]);

  useEffect(() => {
    fetch("/api/searches")
      .then((r) => r.json())
      .then((d) => {
        if (d.searches) setSearches(d.searches);
      });
  }, []);

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="border-b border-[#ECE8E0] pb-4">
        <h1 className="text-2xl font-black text-[#1E2026] uppercase flex items-center gap-2">
          <BookmarkCheck className="size-6 text-[#FF9E1B]" />
          <span>Pesquisas Salvas</span>
        </h1>
        <p className="text-xs text-[#6E7381]">
          Execute novamente buscas automatizadas para capturar novos leads na região.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {searches.map((s) => (
          <div key={s.id} className="rounded-2xl border border-[#ECE8E0] bg-white p-5 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-extrabold text-sm text-[#1E2026]">{s.title}</span>
              <span className="rounded-md bg-[#FF9E1B]/15 px-2 py-0.5 text-[10px] font-bold text-[#FF9E1B] uppercase">
                SALVA
              </span>
            </div>

            <p className="text-xs text-[#6E7381] font-mono leading-relaxed bg-[#FAF8F4] p-3 rounded-xl border border-[#ECE8E0]">
              "{s.queryText}"
            </p>

            <div className="flex items-center justify-between pt-2">
              <span className="text-[11px] text-[#8E94A2]">
                Salva em {new Date(s.createdAt).toLocaleDateString("pt-BR")}
              </span>

              <Link
                href={`/prospecting`}
                className="inline-flex items-center gap-1.5 rounded-xl bg-[#1C1F26] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#2A2E38] transition"
              >
                <Play className="size-3.5 text-[#FF9E1B]" />
                <span>Executar Busca</span>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
