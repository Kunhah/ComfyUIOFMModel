"use client";

import React from "react";
import { ArrowRight, Sparkles, SlidersHorizontal, MapPin, Check } from "lucide-react";
import { NicheCombobox } from "./niche-combobox";
import { LocationAutocomplete } from "./location-autocomplete";

export function SniperSearchBar({
  niche,
  location,
  scope = "CITY_ONLY",
  onNicheChange,
  onLocationChange,
  onScopeChange,
  onSearch,
  loading,
  onOpenAdvanced,
}: {
  niche: string;
  location: string;
  scope?: "CITY_ONLY" | "REGIONAL";
  onNicheChange: (n: string) => void;
  onLocationChange: (l: string) => void;
  onScopeChange?: (s: "CITY_ONLY" | "REGIONAL") => void;
  onSearch: () => void;
  loading: boolean;
  onOpenAdvanced?: () => void;
}) {
  const popularChips = [
    "Barbearias",
    "Clínicas de estética",
    "Dentistas",
    "Restaurantes",
    "Academias",
    "Oficinas mecânicas",
  ];

  const cityOnlyName = location.split(",")[0].trim() || "Cidade";

  return (
    <div className="space-y-4">
      {/* Structured Main Search Card */}
      <div className="rounded-3xl border border-[#2B2E3C] bg-[#14161C] p-6 shadow-2xl space-y-6">
        <div className="grid gap-4 md:grid-cols-12 items-end">
          {/* Niche Combobox */}
          <div className="md:col-span-5">
            <NicheCombobox value={niche} onChange={onNicheChange} />
          </div>

          {/* Location Autocomplete */}
          <div className="md:col-span-4">
            <LocationAutocomplete value={location} onChange={onLocationChange} />
          </div>

          {/* CTA Button */}
          <div className="md:col-span-3">
            <button
              onClick={onSearch}
              disabled={loading || !niche || !location}
              className="w-full h-[46px] flex items-center justify-center gap-2 rounded-xl bg-[#FF9E1B] px-6 text-xs font-black text-[#101216] transition hover:bg-[#F08E0B] active:scale-[0.98] shadow-lg disabled:opacity-50"
            >
              <span>{loading ? "BUSCANDO..." : "ENCONTRAR LEADS"}</span>
              <ArrowRight className="size-4" />
            </button>
          </div>
        </div>

        {/* Scope Selector: Somente Cidade vs Cidade + Região */}
        {onScopeChange && (
          <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-[#222530] text-xs">
            <div className="flex items-center gap-4">
              <span className="text-[#8E94A2] font-semibold text-[11px] flex items-center gap-1">
                <MapPin className="size-3.5 text-[#FF9E1B]" />
                Área da busca:
              </span>
              <button
                onClick={() => onScopeChange("CITY_ONLY")}
                className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-[11px] font-bold transition border ${
                  scope === "CITY_ONLY"
                    ? "border-[#FF9E1B] bg-[#FF9E1B]/15 text-[#FF9E1B]"
                    : "border-[#262936] bg-[#1A1C24] text-gray-400 hover:text-white"
                }`}
              >
                {scope === "CITY_ONLY" && <Check className="size-3" />}
                <span>● Somente {cityOnlyName} (100% Precisão)</span>
              </button>

              <button
                onClick={() => onScopeChange("REGIONAL")}
                className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-[11px] font-bold transition border ${
                  scope === "REGIONAL"
                    ? "border-[#FF9E1B] bg-[#FF9E1B]/15 text-[#FF9E1B]"
                    : "border-[#262936] bg-[#1A1C24] text-gray-400 hover:text-white"
                }`}
              >
                {scope === "REGIONAL" && <Check className="size-3" />}
                <span>○ {cityOnlyName} + Região Próxima</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[#8E94A2] font-semibold text-[11px]">Populares:</span>
              <div className="flex flex-wrap gap-1.5">
                {popularChips.slice(0, 3).map((chip) => (
                  <button
                    key={chip}
                    onClick={() => onNicheChange(chip)}
                    className={`rounded-lg border px-2 py-0.5 text-[10px] font-semibold transition ${
                      niche === chip
                        ? "border-[#FF9E1B] bg-[#FF9E1B]/15 text-[#FF9E1B]"
                        : "border-[#262936] bg-[#1A1C24] text-gray-300 hover:border-[#FF9E1B] hover:text-white"
                    }`}
                  >
                    {chip}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
