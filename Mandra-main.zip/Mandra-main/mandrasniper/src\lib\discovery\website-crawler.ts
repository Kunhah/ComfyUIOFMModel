export interface ExtractedWebsiteContacts {
  whatsappUrl: string | null;
  whatsappPhone: string | null;
  instagramUrl: string | null;
  facebookUrl: string | null;
  email: string | null;
  phone: string | null;
}

export class WebsiteDiscoveryEngine {
  /**
   * Performs controlled crawling of homepage HTML to extract public business contact info.
   */
  public async crawlWebsite(websiteUrl?: string | null): Promise<ExtractedWebsiteContacts> {
    const result: ExtractedWebsiteContacts = {
      whatsappUrl: null,
      whatsappPhone: null,
      instagramUrl: null,
      facebookUrl: null,
      email: null,
      phone: null,
    };

    if (!websiteUrl) return result;

    try {
      const url = websiteUrl.startsWith("http") ? websiteUrl : `https://${websiteUrl}`;
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 3500);

      const res = await fetch(url, {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        },
        signal: controller.signal,
      });

      clearTimeout(timeout);

      if (!res.ok) return result;

      const html = await res.text();

      // 1. Extract WhatsApp Links & Digits
      const waMatch = html.match(/(?:wa\.me|api\.whatsapp\.com\/send\?phone=)(\d+)/i);
      if (waMatch) {
        result.whatsappPhone = waMatch[1];
        result.whatsappUrl = `https://wa.me/${waMatch[1]}`;
      }

      // 2. Extract Instagram Profile URL
      const instaMatch = html.match(/https?:\/\/(?:www\.)?instagram\.com\/([a-zA-Z0-9_\.]+)\/?/i);
      if (instaMatch && !instaMatch[1].includes("p/") && !instaMatch[1].includes("reel/")) {
        result.instagramUrl = `https://instagram.com/${instaMatch[1]}`;
      }

      // 3. Extract Facebook Profile URL
      const fbMatch = html.match(/https?:\/\/(?:www\.)?facebook\.com\/([a-zA-Z0-9_\.]+)\/?/i);
      if (fbMatch) {
        result.facebookUrl = `https://facebook.com/${fbMatch[1]}`;
      }

      // 4. Extract Commercial Email Address
      const emailMatch = html.match(/([a-zA-Z0-9._%+-]+@(?!example\.com|wixpress\.com)[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/i);
      if (emailMatch) {
        result.email = emailMatch[1].toLowerCase();
      }

      // 5. Extract Phone Number
      const phoneMatch = html.match(/\(?[1-9]{2}\)?\s?9?[0-9]{4}[-\s]?[0-9]{4}/);
      if (phoneMatch) {
        result.phone = phoneMatch[0];
      }

      return result;
    } catch (e) {
      console.warn("WebsiteDiscoveryEngine timeout or parse fallback:", e);
      return result;
    }
  }
}
