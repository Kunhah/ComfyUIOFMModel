import { resolveCity } from "./cities";
import { persistLeads } from "./db";
import { findNiche } from "./niches";
import { hasLocalExtract, queryOverture } from "./overture";
import { scoreAndSort } from "./score";
import type { SearchRequest, SearchResponse } from "./types";

/**
 * One implementation of "run a search", shared by the POST route (interactive
 * searches from the form) and by the page (a URL-driven search, rendered on the
 * server so a shared link shows its results immediately).
 *
 * Keeping it here rather than in the route handler is what stops the two paths
 * from drifting — the scoring, the stats and the persistence side effects have to
 * be identical or a deep link would disagree with the same search run by hand.
 */

export type SearchOutcome =
  | { ok: true; response: SearchResponse }
  | { ok: false; status: number; error: string };

export async function performSearch(
  input: SearchRequest,
): Promise<SearchOutcome> {
  const niche = findNiche(String(input.niche ?? ""));
  if (!niche) {
    return { ok: false, status: 400, error: "Nicho desconhecido." };
  }

  const city = resolveCity(String(input.city ?? ""), String(input.uf ?? ""));
  if (!city) {
    return {
      ok: false,
      status: 400,
      error: `Cidade não encontrada: ${input.city}/${input.uf}`,
    };
  }

  const onlyWithoutWebsite = input.onlyWithoutWebsite !== false;
  const minConfidence = clamp(input.minConfidence ?? 0.5, 0, 1);
  const limit = Math.trunc(clamp(input.limit ?? 500, 1, 5000));

  const warnings: string[] = [];
  if (!hasLocalExtract()) {
    warnings.push(
      "Consultando o Overture direto no S3 — isso pode levar vários minutos. " +
        "Rode `npm run sync` uma vez para baixar o extrato do Brasil e deixar as buscas instantâneas.",
    );
  }

  let result;
  try {
    result = await queryOverture({
      city,
      categories: niche.categories,
      onlyWithoutWebsite,
      minConfidence,
      limit,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return { ok: false, status: 502, error: `Falha na consulta: ${message}` };
  }

  const leads = scoreAndSort(result.leads);

  // Straight from the query's own aggregates, which cover every match. Counting
  // `leads` instead would report `limit` back as the size of the pool.
  const stats = {
    total: result.totals.matched,
    withoutWebsite: result.totals.withoutWebsite,
    withPhone: result.totals.withPhone,
    withWhatsapp: result.totals.withWhatsapp,
    returned: leads.length,
    elapsedMs: result.elapsedMs,
  };

  if (leads.length < result.totals.matched) {
    warnings.push(
      `Mostrando ${leads.length.toLocaleString("pt-BR")} de ` +
        `${result.totals.matched.toLocaleString("pt-BR")} negócios encontrados. ` +
        `Refine a busca para ver o resto.`,
    );
  }

  // History is always on: it's a local file, so there is no account to set up and
  // no reason to make it opt-in.
  const { result: persisted, warning } = persistLeads(leads, {
    niche: niche.slug,
    city: city.name,
    uf: city.uf,
  });
  if (warning) warnings.push(warning);

  // Marked after persisting, since "new" means "was not in the database before
  // this search". The board reads it to flag rows worth looking at first.
  const isNew = new Set(persisted?.newIds ?? []);
  const marked = persisted
    ? leads.map((l) => ({ ...l, isNew: isNew.has(l.id) }))
    : leads;

  return {
    ok: true,
    response: {
      leads: marked,
      stats,
      persisted: persisted && {
        inserted: persisted.inserted,
        alreadyKnown: persisted.alreadyKnown,
      },
      warnings,
    },
  };
}

function clamp(n: number, lo: number, hi: number): number {
  const v = Number(n);
  if (!Number.isFinite(v)) return lo;
  return Math.min(hi, Math.max(lo, v));
}
