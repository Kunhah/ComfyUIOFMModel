import type { GooglePlaceRecord, GooglePlacesProvider, ProviderResult } from "../types";
import { parseAddressComponents } from "@/lib/discovery/city-validation";

export class GooglePlacesProviderImpl implements GooglePlacesProvider {
  private apiKey: string | null = null;

  constructor() {
    const key = process.env.GOOGLE_PLACES_API_KEY;
    if (key && key.trim().length > 0) {
      this.apiKey = key.trim();
    }
  }

  public async searchPlaces(
    niche: string,
    location: string,
    radiusKm: number,
    limit: number
  ): Promise<ProviderResult<GooglePlaceRecord[]>> {
    if (!this.apiKey) {
      return this.getDemoPlaces(niche, location, limit);
    }

    try {
      const query = `${niche} em ${location} Brasil`;
      const url = `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${encodeURIComponent(
        query
      )}&key=${this.apiKey}`;

      const res = await fetch(url);
      const json = await res.json();

      if (json.status !== "OK" || !json.results) {
        console.warn("Google Places API non-OK status:", json.status);
        return this.getDemoPlaces(niche, location, limit);
      }

      const records: GooglePlaceRecord[] = json.results.slice(0, limit).map((p: any) => {
        const addressStr = p.formatted_address || location;
        const parsed = parseAddressComponents(addressStr);
        const city = parsed.city || location.split(",")[0].trim();
        const state = parsed.uf || location.split(",")[1]?.trim() || "SP";

        return {
          placeId: p.place_id,
          name: p.name,
          category: niche,
          address: addressStr,
          city,
          state,
          phone: p.formatted_phone_number || null,
          website: p.website || null,
          rating: p.rating || 4.5,
          reviewsCount: p.user_ratings_total || 45,
          mapsUrl: `https://maps.google.com/?q=place_id:${p.place_id}`,
          coordinates: {
            lat: p.geometry?.location?.lat || -23.186,
            lon: p.geometry?.location?.lng || -46.884,
          },
        };
      });

      return {
        status: "CONFIGURED",
        data: records,
        isDemo: false,
      };
    } catch (err) {
      console.warn("Google Places API error, falling back to Demo Mode:", err);
      return this.getDemoPlaces(niche, location, limit);
    }
  }

  private getDemoPlaces(
    niche: string,
    location: string,
    limit: number
  ): ProviderResult<GooglePlaceRecord[]> {
    const city = location.split(",")[0].trim() || "Jundiaí";
    const state = location.split(",")[1]?.trim() || "SP";

    const demoTemplates: Array<{
      name: string;
      category: string;
      reviews: number;
      rating: number;
      noSite: boolean;
      phone: string;
      website: string | null;
    }> = [
      { name: `Clínica Estética & Dra. Juliana`, category: "Estética", reviews: 184, rating: 4.9, noSite: true, phone: "+5511998124433", website: null },
      { name: `Studio Bella Estética Avançada`, category: "Estética", reviews: 92, rating: 4.8, noSite: true, phone: "+5511987654321", website: null },
      { name: `Dra. Camila Santos Odontologia`, category: "Dentista", reviews: 215, rating: 4.9, noSite: false, phone: "+5511999887766", website: "https://instagram.com/dracamilasantos" },
      { name: `Barbearia Dom Pedro Vintage`, category: "Barbearia", reviews: 142, rating: 4.7, noSite: true, phone: "+5511991234567", website: null },
      { name: `Academia X-Fit Cross`, category: "Academia", reviews: 310, rating: 4.8, noSite: true, phone: "+5511993456789", website: null },
      { name: `Espaço Harmonia do Corpo`, category: "Estética", reviews: 54, rating: 4.6, noSite: true, phone: "+5511988776655", website: null },
      { name: `Centro Odontológico Sorriso Real`, category: "Dentista", reviews: 128, rating: 4.8, noSite: true, phone: "+5511997654321", website: null },
      { name: `Pet Shop & Veterinária Patas`, category: "Pet Shop", reviews: 165, rating: 4.9, noSite: true, phone: "+5511996543210", website: null },
      { name: `Auto Center & Mecânica Jundiaí`, category: "Oficina Mecânica", reviews: 88, rating: 4.7, noSite: true, phone: "+5511995432109", website: null },
      { name: `Pizzaria Tradizione Italiana`, category: "Restaurante", reviews: 290, rating: 4.8, noSite: false, phone: "+5511988776611", website: "https://facebook.com/pizzariatradizione" },
    ];

    const records: GooglePlaceRecord[] = [];
    const count = Math.min(limit, 30);

    for (let i = 0; i < count; i++) {
      const template = demoTemplates[i % demoTemplates.length];
      const idStr = `demo-place-${i + 1}`;

      records.push({
        placeId: idStr,
        name: `${template.name} ${i > demoTemplates.length - 1 ? `#${i + 1}` : ""}`.trim(),
        category: niche.charAt(0).toUpperCase() + niche.slice(1),
        address: `Av. Nove de Julho, ${100 + i * 25}, Bairro Anhangabaú, ${city} - ${state}`,
        city,
        state,
        phone: template.phone,
        website: template.noSite ? null : template.website,
        rating: template.rating,
        reviewsCount: template.reviews,
        mapsUrl: `https://maps.google.com/?q=${encodeURIComponent(template.name)}+${city}`,
        coordinates: {
          lat: -23.1863 + (i * 0.002),
          lon: -46.8845 + (i * 0.002),
        },
      });
    }

    return {
      status: "CONFIGURED",
      data: records,
      isDemo: true,
    };
  }
}
