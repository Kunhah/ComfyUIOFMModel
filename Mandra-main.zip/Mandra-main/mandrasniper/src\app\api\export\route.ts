import { csvResponse } from "@/lib/csv";
import type { ScoredLead } from "@/lib/types";

export const runtime = "nodejs";

/**
 * CSV export of whatever is currently on screen.
 *
 * The client posts the rows back rather than the server re-running the search:
 * the export must match exactly what the user is looking at, including any
 * filtering they did in the browser.
 *
 * For exporting more than the visible page, use the history export
 * (`/api/history/export`), which reads from SQLite and isn't capped.
 *
 * The column definitions live in lib/csv.ts, shared with that route so the two
 * files can't drift apart.
 */
export async function POST(request: Request): Promise<Response> {
  let body: { leads?: ScoredLead[]; filename?: string };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const leads = Array.isArray(body.leads) ? body.leads : [];
  return csvResponse(leads, body.filename ?? "leads");
}
