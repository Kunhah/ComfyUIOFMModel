import React from "react";
import { Settings, ShieldCheck, Key, Server, CheckCircle2, AlertTriangle } from "lucide-react";
import { MandraRepository } from "@/lib/db/repository";

export const dynamic = "force-dynamic";
const repo = new MandraRepository();

export default async function SettingsPage() {
  const health = await repo.getProviderHealth();

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="border-b border-[#ECE8E0] pb-4">
        <h1 className="text-2xl font-black text-[#1E2026] uppercase flex items-center gap-2">
          <Settings className="size-6 text-[#FF9E1B]" />
          <span>Configurações do Sistema & Providers</span>
        </h1>
        <p className="text-xs text-[#6E7381]">
          Status das integrações de API externa, inteligência geográfica e credenciais do Supabase.
        </p>
      </div>

      {/* Provider Health Section */}
      <div className="rounded-2xl border border-[#ECE8E0] bg-white p-6 shadow-2xs space-y-4">
        <h3 className="font-extrabold text-sm text-[#1E2026] uppercase flex items-center gap-2">
          <Server className="size-4 text-[#FF9E1B]" />
          <span>Status dos Providers de Inteligência</span>
        </h3>

        <div className="grid gap-3 sm:grid-cols-2">
          {health.map((h) => {
            const isConfigured = h.status === "CONFIGURED";
            return (
              <div
                key={h.name}
                className="flex items-center justify-between rounded-xl border border-[#ECE8E0] bg-[#FAF8F4] p-4"
              >
                <div>
                  <div className="font-bold text-xs text-[#1E2026]">{h.name}</div>
                  <div className="text-[11px] text-[#6E7381] mt-0.5">{h.message}</div>
                </div>

                <span
                  className={`rounded-md px-2 py-0.5 text-[10px] font-extrabold uppercase ${
                    isConfigured
                      ? "bg-emerald-500/15 text-emerald-700 border border-emerald-500/30"
                      : "bg-amber-500/15 text-amber-700 border border-amber-500/30"
                  }`}
                >
                  {h.status}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
