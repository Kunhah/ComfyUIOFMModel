import { existsSync } from "node:fs";
import path from "node:path";
import { DuckDBInstance, type DuckDBConnection } from "@duckdb/node-api";
import type { City } from "./cities";
import { normalise } from "./cities";
import type { Lead } from "./types";

/**
 * Overture Maps places, queried with DuckDB.
 *
 * Why this source: it is free, needs no API key, and its licence (CDLA
 * Permissive 2.0) lets us store and export results — which the Google Maps
 * Platform terms do not. Coverage of Brazilian SMBs is also far better than
 * OpenStreetMap: for hair/beauty in Belo Horizonte, Overture returns ~4.4k
 * businesses against OSM's 68.
 *
 * There are two modes, and the difference is not small:
 *
 *   local  — queries data/br-leads.parquet, the Brazil extract built by
 *            `npm run sync`. Sub-second.
 *   remote — queries the public S3 bucket directly. Works with no setup, but
 *            measured 90s–230s per search and is highly variable, because the
 *            places dataset has no geographic partitioning: pruning relies
 *            entirely on Parquet row-group statistics and the whole planet's
 *            metadata still has to be fetched.
 *
 * Local is the intended mode. Remote exists so a fresh clone works before the
 * sync has run, and the UI surfaces a warning telling you to run it.
 */

/** Pin the release so results are reproducible; bump deliberately. */
export const overtureRelease = process.env.OVERTURE_RELEASE ?? "2026-07-22.0";

const REMOTE_PLACES = `s3://overturemaps-us-west-2/release/${overtureRelease}/theme=places/type=place/*`;

/** Where `npm run sync` writes the Brazil extract. */
export function localExtractPath(): string {
  return path.join(process.cwd(), "data", "br-leads.parquet");
}

export function hasLocalExtract(): boolean {
  return existsSync(localExtractPath());
}

let connectionPromise: Promise<DuckDBConnection> | null = null;
let remoteReady = false;

/**
 * One connection for the process. Extension load and S3 config are per-connection
 * and cost a round trip, so re-creating it per request would add seconds to every
 * search.
 */
async function getConnection(): Promise<DuckDBConnection> {
  if (!connectionPromise) {
    connectionPromise = (async () => {
      const instance = await DuckDBInstance.create(":memory:");
      return instance.connect();
    })().catch((err) => {
      // Don't cache a failed init — the next request should be able to retry.
      connectionPromise = null;
      throw err;
    });
  }
  return connectionPromise;
}

/**
 * httpfs is only needed for the remote fallback, and INSTALL reaches out to the
 * extension repository, so it stays out of the local path entirely.
 */
async function ensureRemote(connection: DuckDBConnection): Promise<void> {
  if (remoteReady) return;
  await connection.run("INSTALL httpfs");
  await connection.run("LOAD httpfs");
  await connection.run("SET s3_region='us-west-2'");
  // The bucket is public; without blanking these DuckDB tries to sign requests
  // with whatever AWS credentials happen to be in the environment, and 403s.
  await connection.run("SET s3_access_key_id=''");
  await connection.run("SET s3_secret_access_key=''");
  remoteReady = true;
}

/**
 * Categories come from our own registry in niches.ts, never from user input, but
 * they are interpolated into SQL rather than bound (DuckDB list binding through
 * the node bindings is fiddlier than it's worth). This assertion is the guard
 * that keeps that safe if the registry is ever edited carelessly.
 */
function quoteCategories(categories: string[]): string {
  for (const c of categories) {
    if (!/^[a-z0-9_]+$/.test(c)) {
      throw new Error(`Invalid Overture category: ${JSON.stringify(c)}`);
    }
  }
  return categories.map((c) => `'${c}'`).join(", ");
}

/**
 * The SQL half of `normalise()` in cities.ts — case, accents and punctuation all
 * folded away. These two have to produce the same string for the same input: the
 * picker resolves a city with the JS version and the query matches rows with this
 * one, so any disagreement shows up as a city that autocompletes fine and then
 * returns nothing.
 */
function nrm(expr: string): string {
  return `trim(regexp_replace(lower(strip_accents(${expr})), '[^a-z0-9]+', ' ', 'g'))`;
}

export type OvertureQuery = {
  city: City;
  categories: string[];
  onlyWithoutWebsite: boolean;
  minConfidence: number;
  limit: number;
};

export type OvertureResult = {
  leads: Lead[];
  /**
   * Counted over every match, not over the returned page. `leads` is capped by
   * `limit`, so deriving these from it would report the limit back as if it were
   * the size of the pool.
   */
  totals: {
    /** Before the no-website filter, so the UI can show "x of y". */
    matched: number;
    withoutWebsite: number;
    /** Scoped to the rows being shown, i.e. respects the no-website filter. */
    withPhone: number;
    withWhatsapp: number;
  };
  elapsedMs: number;
  mode: "local" | "remote";
};

export async function queryOverture(q: OvertureQuery): Promise<OvertureResult> {
  const connection = await getConnection();
  const local = hasLocalExtract();

  let source: string;
  if (local) {
    // Escape single quotes so a path with an apostrophe can't break out.
    source = `read_parquet('${localExtractPath().replace(/'/g, "''")}')`;
  } else {
    await ensureRemote(connection);
    source = `read_parquet('${REMOTE_PLACES}', hive_partitioning = 1)`;
  }

  // The local extract is already flattened by the sync script; the remote
  // dataset still has the nested Overture shape, so the projections differ.
  const cols = local
    ? `id, name, category, address, city, uf, phone, website, social, email, lon, lat, confidence`
    : `id,
       names.primary            AS name,
       categories.primary       AS category,
       addresses[1].freeform    AS address,
       addresses[1].locality    AS city,
       addresses[1].region      AS uf,
       phones[1]                AS phone,
       websites[1]              AS website,
       socials[1]               AS social,
       emails[1]                AS email,
       ((bbox.xmin + bbox.xmax) / 2) AS lon,
       ((bbox.ymin + bbox.ymax) / 2) AS lat,
       confidence`;

  const cityExpr = local ? "city" : "addresses[1].locality";
  const categoryExpr = local ? "category" : "categories.primary";
  // Brazil reuses city names heavily ("Bom Jesus" exists in a dozen states), so
  // matching on locality alone would merge them. The bbox narrows it and the
  // state code settles it.
  //
  // The sync normalises this column to a bare two-letter code; the raw dataset
  // does not, and arrives as "MG" or "BR-MG" depending on the record.
  const ufExpr = local
    ? "uf"
    : `nullif(upper(replace(coalesce(addresses[1].region, ''), 'BR-', '')), '')`;

  // The bbox is what makes the remote scan tractable, but it is a rectangle and
  // spills into neighbouring municipalities (a Belo Horizonte box also catches
  // Ibirité). The locality equality is what makes the result the city asked for.
  const bboxFilter = local
    ? `lon BETWEEN $xmin AND $xmax AND lat BETWEEN $ymin AND $ymax`
    : `bbox.xmin BETWEEN $xmin AND $xmax AND bbox.ymin BETWEEN $ymin AND $ymax`;

  // Same rule as isWhatsappCapable() in score.ts, expressed in SQL. It has to be
  // duplicated here rather than derived in JS because the totals below are
  // computed over every match, not just the page we return — reporting
  // "613 with WhatsApp" when that was only counted across the first 1,000 rows
  // would understate the pool and quietly mislead.
  const digits = `regexp_replace(coalesce(phone, ''), '[^0-9]', '', 'g')`;
  const e164 = `(CASE WHEN starts_with(${digits}, '55') THEN ${digits} ELSE '55' || ${digits} END)`;
  const waExpr = `(len(${e164}) = 13 AND substr(${e164}, 5, 1) = '9')`;

  // Restricts the reachability counts to the rows the table will actually show.
  const scopeToShown = q.onlyWithoutWebsite ? "AND no_site" : "";

  // The counts are window aggregates rather than a second query or a CROSS JOIN
  // against an aggregate CTE, both of which would scan the source twice. One
  // scan matters: remotely a scan is minutes.
  const sql = `
    WITH matched AS (
      SELECT ${cols} FROM ${source}
      WHERE ${bboxFilter}
        AND ${categoryExpr} IN (${quoteCategories(q.categories)})
        AND ${nrm(cityExpr)} = $city
        -- A missing state is not a reason to drop a lead. 15.203 Brazilian
        -- records give a city with no region at all, and by this point the bbox
        -- and the locality name have already pinned the municipality, so the
        -- state code has nothing left to disambiguate. The city index only folds
        -- state-less rows into names that occur in exactly one state, which is
        -- what keeps this from crediting them to the wrong "Santa Luzia".
        AND (${ufExpr} = $uf OR ${ufExpr} IS NULL)
        AND confidence >= $minConf
    ),
    flagged AS (
      SELECT *,
             (website IS NULL OR website = '') AS no_site,
             (phone IS NOT NULL AND phone <> '') AS has_phone,
             ${waExpr} AS wa
      FROM matched
    ),
    counted AS (
      SELECT *,
             count(*) OVER ()                                   AS total_matched,
             sum(CASE WHEN no_site THEN 1 ELSE 0 END) OVER ()   AS total_no_site,
             -- Reachability is counted over the rows the user is actually being
             -- shown. Counting it over every match instead produced nonsense
             -- like "sem site: 458 / com WhatsApp: 538" — more contactable leads
             -- than there were leads.
             sum(CASE WHEN has_phone ${scopeToShown} THEN 1 ELSE 0 END) OVER () AS total_phone,
             sum(CASE WHEN wa        ${scopeToShown} THEN 1 ELSE 0 END) OVER () AS total_wa
      FROM flagged
    )
    SELECT * FROM counted
    ${q.onlyWithoutWebsite ? "WHERE no_site" : ""}
    -- Confidence, not name, is the tiebreak: scores bunch at the top (a
    -- no-site business with a mobile scores 100 outright), and ordering those
    -- ties alphabetically buries the best records under every shop whose name
    -- starts with A.
    ORDER BY no_site DESC, confidence DESC
    LIMIT ${Math.max(1, Math.min(5000, Math.trunc(q.limit)))}
  `;

  const params = {
    xmin: q.city.bbox.xmin,
    xmax: q.city.bbox.xmax,
    ymin: q.city.bbox.ymin,
    ymax: q.city.bbox.ymax,
    city: normalise(q.city.name),
    uf: q.city.uf,
    minConf: q.minConfidence,
  };

  const started = Date.now();
  const reader = await connection.runAndReadAll(sql, params);
  const rows = reader.getRowObjectsJS() as Record<string, unknown>[];
  const elapsedMs = Date.now() - started;

  const str = (v: unknown): string | null => {
    if (v === null || v === undefined) return null;
    const s = String(v).trim();
    return s.length > 0 ? s : null;
  };
  const num = (v: unknown): number | null =>
    v === null || v === undefined ? null : Number(v);

  const leads: Lead[] = rows.map((r) => ({
    id: String(r.id),
    name: str(r.name) ?? "(sem nome)",
    category: str(r.category),
    address: str(r.address),
    city: str(r.city),
    uf: str(r.uf),
    phone: str(r.phone),
    website: str(r.website),
    social: str(r.social),
    email: str(r.email),
    lat: num(r.lat),
    lon: num(r.lon),
    confidence: num(r.confidence) ?? 0,
  }));

  // The window aggregates are repeated on every row; with no rows there is
  // nothing to read them from, and zero is the correct answer anyway.
  const first = rows[0];
  const agg = (key: string): number =>
    first === undefined ? 0 : (num(first[key]) ?? 0);

  return {
    leads,
    totals: {
      matched: agg("total_matched"),
      withoutWebsite: agg("total_no_site"),
      withPhone: agg("total_phone"),
      withWhatsapp: agg("total_wa"),
    },
    elapsedMs,
    mode: local ? "local" : "remote",
  };
}
