# Atlas Prospector

Internal prospecting tool for Atlas Digital. Pick a niche and a Brazilian city,
get back local businesses ranked by how badly they need what we sell — starting
with the ones that have no website at all but do have a WhatsApp number.

Not customer-facing and not deployed. It runs on your machine.

## Getting started

This lives in `Prospector/` inside a repo that holds one folder per project,
wired together as an **npm workspace**. Install from the repo root:

```bash
cd ..                  # repo root
npm run prospector     # http://localhost:3001
```

That's the whole thing, first run included. `npm run prospector` is a launcher
(`scripts/start.mjs`): it checks what's actually missing, runs only that, and then
starts the dev server. On a fresh clone it installs dependencies, downloads the
extract and builds the city index; on every run after, it finds nothing to do and
boots straight away.

It is checking for specific failures rather than just whether files exist:

| Situation                                    | What it does                                                                                            |
| -------------------------------------------- | ------------------------------------------------------------------------------------------------------- |
| dependencies not installed                   | `npm install`                                                                                           |
| extract missing                              | `npm run sync`                                                                                          |
| extract truncated or empty                   | `npm run sync` — a killed download leaves a file that opens and then fails mid-query                    |
| city index missing or corrupt                | `npm run cities`                                                                                        |
| city index older than the extract            | `npm run cities` — syncing without rebuilding leaves the picker describing data that is no longer there |
| extract from a different Overture release    | warns, so the header can't claim one release while querying another                                     |
| port already in use                          | says it's already running and stops, instead of failing on `EADDRINUSE`                                 |
| leftover `.partial` from an interrupted sync | deletes it                                                                                              |

```bash
npm run prospector:check    # report what's missing, change nothing (exit 1 if any)
npm run prospector:dev      # skip all checks, plain next dev
node scripts/start.mjs --port 3999
node scripts/start.mjs --force-sync
```

Or step through it by hand:

```bash
npm install
npm run sync --workspace Prospector     # one-time, ~2 min — see below
npm run cities --workspace Prospector   # rebuilds the city index from it
npm run prospector:dev                  # http://localhost:3001
```

| Script                                  | What it does                                                             |
| --------------------------------------- | ------------------------------------------------------------------------ |
| `npm run dev`                           | Dev server on port 3001 (Turbopack)                                      |
| `npm run build`                         | Production build                                                         |
| `npm start`                             | Serve the production build on 3001                                       |
| `npm run up`                            | **Check what's missing, fix it, then start.** The one you want.          |
| `npm run check`                         | Report what's missing and exit                                           |
| `npm run sync`                          | **Download the Brazil business extract.** Run once per Overture release. |
| `npm run cities`                        | Rebuild the searchable city index. **Run after every sync.**             |
| `npm run lint` / `typecheck` / `format` | ESLint / `tsc --noEmit` / Prettier                                       |

`sync` then `cities`, in that order — the city index and its counts are derived
from the extract, so running the sync alone leaves the picker describing the old
data.

Port 3001 is deliberate: the marketing site in `Website/` owns 3000, so both can
run at once.

## Why the data source is Overture and not Google

The obvious source is the Google Places API, and it is the wrong one here.

Google's Maps Platform terms only let you store `place_id` indefinitely and
coordinates for 30 days. **Business names, phone numbers and ratings must be
fetched live and cannot be warehoused.** A prospecting tool is a warehouse of
names and phone numbers by definition, so the entire product would sit outside
the licence — including the CSV export.

[Overture Maps](https://overturemaps.org) is open data under CDLA Permissive 2.0.
Free, no API key, no quota, and explicitly storable and redistributable. It is
also _better_ for this job than the free alternative — measured on hair and
beauty businesses in Belo Horizonte:

| Source                   | Businesses found |
| ------------------------ | ---------------- |
| OpenStreetMap (Overpass) | 68               |
| Overture Maps            | 4,612            |

OSM simply does not have Brazilian SMBs. Overture merges Meta and Microsoft
place data and does.

What comes back per business: name, category, street address, city, state,
phone, website, social profile, sometimes email, coordinates, and a 0–1
confidence score. Roughly 88% have a phone number.

## The local extract (`npm run sync`)

**This is the one setup step, and skipping it makes the tool unusable rather than
just slow.**

The Overture places dataset is a single unpartitioned set of Parquet files
covering the planet. Nothing about it is organised geographically, so a query
can only be pruned via Parquet row-group statistics — which still means fetching
metadata for the whole world. Measured, querying S3 per search:

| Mode                            | Time per search             |
| ------------------------------- | --------------------------- |
| Remote (S3, no extract)         | 90s – 230s, highly variable |
| Local (`data/br-leads.parquet`) | **0.2s – 0.6s**             |

So `npm run sync` pulls Brazil once, filtered to the categories in
`src/lib/niches.ts`, and writes `data/br-leads.parquet`:

```
1,768,794 businesses · 1,098,965 with no website · 122 MB
```

then `npm run cities` turns that into the searchable index:

```
6,215 cities · 1,765,436 of 1,768,794 businesses reachable (99.8%)
```

The parquet is gitignored — it is derived data, and 122MB does not belong in git.
The app falls back to querying S3 directly when it is missing, so a fresh clone
works, but the UI shows a warning telling you to run the sync.

**Re-run both** when Overture publishes a new release (roughly monthly, bump
`OVERTURE_RELEASE`) or **whenever you add a niche** — new categories are not in
the existing extract and would silently return zero results, which looks like
"no businesses here" rather than "not synced".

The sync filters on `addresses[1].country = 'BR'`, which is not the same thing as
the bounding box. The box has to cover Brazil's extremes and so also covers
Paraguay, Uruguay, Bolivia and parts of Argentina, Chile, Peru and Colombia;
without the country test the extract carried **284k foreign businesses** and the
city picker offered Asunción, Santiago, Córdoba and Santa Cruz de la Sierra.

## Searches are URLs

A search is fully expressed in the query string, and the server renders the
results before sending the page — so a link arrives with its table already
populated, and works with JS disabled:

```
/?niche=barbearias-saloes&city=Belo%20Horizonte&uf=MG
/?niche=pet&city=Manaus&uf=AM&conf=0.7
/?niche=restaurantes&city=S%C3%A3o%20Paulo&uf=SP&all=1
```

| Param         | Meaning                                                              |
| ------------- | -------------------------------------------------------------------- |
| `niche`       | slug from `src/lib/niches.ts`                                        |
| `city` / `uf` | must match the municipality index; `uf` disambiguates repeated names |
| `conf`        | confidence floor, 0–1 (default 0.5)                                  |
| `all=1`       | include businesses that already have a website                       |

Handy for sending someone a specific list, and it's the quickest way to confirm
the data layer is alive without touching the form.

## How a search works

```
niche  ──▶ src/lib/niches.ts     ──▶ Overture category list
city   ──▶ src/data/br-cities.json ──▶ bounding box + state code
                    │
                    ▼
         data/br-leads.parquet  (DuckDB, one scan)
                    │
                    ▼
         src/lib/score.ts       ──▶ 0-100 score + pt-BR reasons
                    │
                    ▼
              board  ·  CSV  ·  wa.me link
```

Three things in that pipeline are load-bearing and easy to break:

**The city bounding box is not an optimisation, it is correctness.** Brazil
reuses city names heavily — "Bom Jesus" exists in a dozen states. The query
filters on bbox _and_ normalised locality name _and_ state code. Drop any one and
you merge unrelated municipalities. The bbox also can't be used alone: it is a
rectangle, so a Belo Horizonte box catches Ibirité too.

**The city index is built from the extract, not from Overture's boundaries.** The
boundaries say what a municipality is _called_; the business records say what
their addresses actually _say_. Where those disagree, a boundary-derived index
makes the city unsearchable — and they disagree more than you'd expect. Brasília
was the worst case: Overture models the Federal District as 35 administrative
regions (Plano Piloto, Ceilândia, Taguatinga…) with no locality named "Brasília"
at all, while the businesses there give exactly that. **7,283 businesses, 2,390 of
them with no website, returned nothing.** Deriving the index from the places side
makes that class of bug structurally impossible: a name is in the index because
businesses use it. Boundaries are still read, but only for typeset display names.

**The category strings in `niches.ts` are copied from the live vocabulary**, kept
in `src/data/overture-categories.csv` (every category with ≥20 businesses in São
Paulo). An invented category name matches nothing and fails silently. Add
categories from that file, then re-run `npm run sync`.

**Stats are computed in SQL over every match, not over the returned page.** The
page is capped by `limit`, so counting the returned rows would report the limit
back as if it were the size of the pool ("2,875 without a website" would read as
"1,000"). The reachability counts are additionally scoped to the rows actually
shown, otherwise a filtered search reports more contactable leads than leads.

## Matching a city the way people type it

`normalise()` in `src/lib/cities.ts` folds away case, accents **and punctuation**,
and `overture.ts` repeats the same folding in SQL. The two have to agree exactly —
if they drift, a city resolves in the picker and then returns zero rows.

Punctuation is not cosmetic here. Overture's boundary names are typeset
("São João del-Rei", "Itapecuru-Mirim") while the records write them plainly
("Sao Joao del Rei"), and an accent-only normaliser stranded real municipalities.
On top of that:

- A trailing state code is split off the query, so `belo horizonte mg` works.
- The same split happens at sync time on the data side, because plenty of records
  put the state inside the city field — `"Belo Horizonte, MG"`, `"São Paulo SP"`.
  Left alone each becomes a near-duplicate city holding a handful of businesses.
  It is only applied when the record's own state agrees, so a row claiming
  `"Curitiba - Pr"` in Pará is left exactly as it is rather than quietly rewritten.
- **A missing state is not a reason to drop a lead.** 15,182 records give a city
  and no region. Once bbox and locality match, the state code has nothing left to
  disambiguate, so the query accepts `uf IS NULL`. The index only folds those rows
  into names that occur in exactly one state, which is what stops them being
  credited to the wrong "Santa Luzia".
- The picker ranks by business count, not bounding-box area. Area was a bad proxy:
  sprawling Amazonian municipalities have enormous boxes and almost no businesses,
  so they outranked the capitals people were actually typing.

Alternate spellings live in a hand-written `ALIASES` list in
`scripts/build-city-index.mjs`. That started as fuzzy matching — pair each unused
boundary name with its nearest unreachable locality above a Jaro-Winkler cutoff —
and it had to be thrown away: 13 of the 19 pairs it produced joined genuinely
different municipalities ("Capão Bonito do Sul" to "Capão Bonito", "Alagoinha do
Piauí" to "Alagoinha"). A wrong alias is worse than a missing one, because the
search succeeds and returns another town's businesses. Add pairs only when you
have confirmed they are one municipality.

## Niches

33 niches over 55 Overture categories, grouped into 8 families so the dropdown stays
navigable. **A category belongs to exactly one niche**, and `niches.ts` throws at
import if that is ever violated.

That rule is not theoretical. `nail_salon` was in both "barbearias-saloes" and
"estetica" — 17.624 businesses under two niches at once. Worse, a lead's stored
niche was whichever search had touched it last, so of the 133 nail salons already
saved, 61 sat under one and 72 under the other, purely by search order. Every
per-niche count was fiction.

Two changes fix it for good:

- **A lead's niche is derived from its own Overture category**, never from the
  search that found it. Same lead, same niche, whatever you searched for.
- **Overlap is caught at import.** The reverse map is also what the sync script
  reads, so the extract and the niche list cannot disagree.

The niches were also split much finer than the original 12. "Restaurantes" bundled
16 categories and matched 32.895 businesses in São Paulo — against the 1.000-row cap
you could never see past the first 3%. Pizzarias, padarias, bares, cafeterias and
hamburguerias are separate now, which is also how the pitch differs.

Verified against the extract: the 33 niches sum to **1.768.794**, exactly the row
count, with nothing double-counted and nothing unmapped.

**Regrouping categories needs no re-sync** as long as they're already in the extract
— every saved lead's niche is rebuilt from its category on next start (`reniche()` in
`db.ts`, keyed on a fingerprint of the vocabulary). Adding a category that isn't in
the extract does need `npm run sync`.

Old slugs stop resolving, so a bookmarked deep link using one returns "Nicho
desconhecido." instead of quietly searching something else.

## Scoring

Deterministic rules in `src/lib/score.ts`, not an LLM: it is instant, free, and
you can read a row and see exactly why it scored what it did. Every score comes
with pt-BR reason chips in the UI.

| Signal                        | Points    | Why                                                                                            |
| ----------------------------- | --------- | ---------------------------------------------------------------------------------------------- |
| No website                    | +45       | The thing we actually sell. Dominates by design.                                               |
| Social profile but no website | +15       | Strongest warm signal there is — they already want to be findable, they just never got a site. |
| Has a phone                   | +15       | Can start a conversation today.                                                                |
| …and it's a mobile            | +10       | WhatsApp resolves; a landline `wa.me` link is dead.                                            |
| Confidence ≥ 0.8              | +10       | Record is real and current.                                                                    |
| Has a street address          | +5        |                                                                                                |
| _Already has a website_       | _+5 only_ | Still a possible redesign lead, so not zero, but it sorts below everything sellable.           |

Ties break on confidence, not name. Scores bunch at the ceiling — any no-site
business with a mobile and a clean record hits 100 — and breaking ties
alphabetically buried the best records under every shop starting with "A".

WhatsApp capability is derived, not assumed: Brazilian mobiles are `+55` + 2-digit
DDD + 9 digits starting with `9`; landlines are 8 digits starting 2–5. The
WhatsApp button only renders for real mobiles.

## Looking at what you've gathered (`/historico`)

`/` only ever shows the search you just ran. `/historico` is everything the tool
has ever found, read back out of SQLite — the search page writes, this page reads.

| What      | How                                                                        |
| --------- | -------------------------------------------------------------------------- |
| Filter    | free text (name or address), niche, city, situação, no-site, has-WhatsApp  |
| Per niche | breakdown: leads, sem site, WhatsApp and how many you've worked, per niche |
| Sort      | score, most recently found, first found, name                              |
| Export    | **every matching row**, not just the page you're looking at                |
| Pipeline  | per-row dropdown: novo → contatado → respondeu → cliente → descartado      |

Filters live entirely in the query string, so a view is a shareable URL and works
with JavaScript off — the whole filter bar is a plain GET form. Only the situação
dropdown needs JS, and it updates optimistically rather than making you wait a
round trip per lead.

```
/historico?nosite=1&wa=1          # the sellable, reachable pool
/historico?niche=pet&city=Manaus  # one niche in one city
/historico?status=contatado       # who you've already messaged
/historico?q=estudio              # accent-insensitive: finds "Estúdio"
```

Free text matches a folded copy of name + address written on save (`search_norm`),
because SQLite has no `strip_accents` — so "estudio" finds "Estúdio" and
"sao joao" finds "São João".

The CSV here carries four extra columns the board's export can't know: `status`,
`primeiro_visto`, `ultimo_visto` and `nicho_busca`. Both exports share one writer
in `src/lib/csv.ts`, so the common columns can't drift apart.

Score and reason chips are recomputed from `score.ts` on read rather than taken
from the stored value, so a row is shown under today's scoring rules. The stored
score is what SQL sorts and filters on, since that's what's indexed.

## Lead history (SQLite)

The search itself needs no database — Overture plus the local extract is the whole
engine. The history adds the one thing a search can't tell you: **whether you have
seen a business before.** Without it, running the same city twice looks identical
both times and there's no way to spot what appeared since. Rows the database
hasn't seen before get a `novo` badge, and the header counts what you've built up.

There is nothing to set up. `data/prospector.db` is created on the first search.

```bash
sqlite3 data/prospector.db 'SELECT name, phone, score FROM leads ORDER BY score DESC LIMIT 20'
rm data/prospector.db      # reset — searches keep working, everything looks new again
```

Deleting it while the dev server is running won't take effect: the process keeps a
handle on the unlinked file and carries on writing to it, so the row counts stay
stubbornly high. **Stop the server, delete, restart.**

`node:sqlite` ships with Node, so there is no dependency, no native build step and
nothing to keep out of the bundler. Its API is synchronous, which for a single-user
tool on localhost is a feature: a search writes ~1,000 rows in one transaction in
single-digit milliseconds, with no connection pool, no network hop and no service
to be down. WAL mode is on, so an unclean shutdown can't corrupt the file.

The schema is created on open rather than through migration tooling — this is a
local single-user database that can be deleted and rebuilt by re-running a search,
so versioned migrations would be ceremony with nothing to protect.

New _columns_ are still picked up on an existing file, because they have to be:
`CREATE TABLE IF NOT EXISTS` does nothing to a table that already exists, so adding
`search_norm` to the schema left older files without it — and since the column is in
the INSERT list, **every search failed** with "no such column" rather than degrading.
`addMissingColumns()` adds what's missing on open and backfills it. Renames, type
changes and constraint changes are out of scope; for those, delete the file.

`first_seen_at` is never overwritten; that is the point of keeping history.
Everything else refreshes on re-upsert, so a business that has since published a
website updates rather than lingering at whatever it looked like the first time.

`status`, `notes` and `contacted_at` exist and nothing writes them yet — they are
there so adding a pipeline view later needs no schema change.

The file is gitignored, along with its `-wal`/`-shm` companions. It is local state
rather than source, and who you have already pulled and contacted has no business
in a shared repo.

## Known state

- **No preview-site generator.** That is ViziHub's actual conversion weapon and
  the obvious next step.
- **Pipeline is one dropdown, not a workflow.** `/historico` writes `status` and
  `contacted_at`; `notes` exists in the schema and nothing writes it. There are no
  reminders, no follow-up dates and no per-lead history of changes.
- **33 niches** in `src/lib/niches.ts` across 8 families, mapping 55 Overture
  categories.
- **Confidence floor defaults to 0.5.** Below that the records get noticeably
  stale and duplicated. The slider goes to 0 if you want to see them.
- **Result limit is 1,000 per search** from the UI. São Paulo restaurants match
  32,895, so wide searches are truncated — the UI says so explicitly rather than
  quietly capping.
- **3,358 businesses (0.2%) remain unreachable**: they give no state and their city
  name occurs in more than one, so there is no honest way to attribute them.
- **720 municipalities have a boundary but no businesses** in our 55 categories
  and are left out of the picker. An entry that always autocompletes to zero
  results is a trap; adding a niche can bring them back.
- **`data/br-leads.parquet` is a point-in-time snapshot.** A business that built
  a website last week still shows as "sem site" until the next sync.
- No auth on the app itself. It binds to localhost; don't expose it.

## Environment

| Variable           | Required | Purpose                                                                                             |
| ------------------ | -------- | --------------------------------------------------------------------------------------------------- |
| `OVERTURE_RELEASE` | no       | Pin a different Overture release. Defaults to `2026-07-22.0`. Must match what `npm run sync` built. |
| `PROSPECTOR_DB`    | no       | Move the history file. Defaults to `data/prospector.db`, created on first search.                   |

Nothing here is required — the tool works with an empty environment.

## Attribution

Place data © [Overture Maps Foundation](https://overturemaps.org), licensed
CDLA Permissive 2.0. Keep the attribution if any of this output becomes
customer-facing.
