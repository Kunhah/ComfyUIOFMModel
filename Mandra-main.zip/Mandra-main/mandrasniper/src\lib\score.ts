import type { Lead, ScoredLead } from "./types";

/**
 * Digits only, normalised to include the 55 country code.
 * Returns null if it doesn't look like a Brazilian number at all.
 */
export function normalisePhone(phone: string | null): string | null {
  if (!phone) return null;
  let d = phone.replace(/\D/g, "");
  // Locally-formatted numbers arrive without the country code.
  if (!d.startsWith("55")) d = `55${d}`;
  // 55 + 2-digit DDD + 8 (landline) or 9 (mobile) subscriber digits.
  if (d.length < 12 || d.length > 13) return null;
  return d;
}

/**
 * True for Brazilian mobiles, which are the only numbers WhatsApp resolves.
 * Mobiles are 9 subscriber digits beginning with 9; landlines are 8 beginning 2–5.
 * Sending a wa.me link to a landline produces a dead link, so this gates the button.
 */
export function isWhatsappCapable(phone: string | null): boolean {
  const d = normalisePhone(phone);
  return d !== null && d.length === 13 && d[4] === "9";
}

export function whatsappUrl(
  phone: string | null,
  message: string,
): string | null {
  const d = normalisePhone(phone);
  if (!d || !isWhatsappCapable(phone)) return null;
  return `https://wa.me/${d}?text=${encodeURIComponent(message)}`;
}

/** The opening line for a cold WhatsApp approach, in pt-BR. */
export function outreachMessage(lead: { name: string }): string {
  const name = lead.name.trim();
  return (
    `Olá! Tudo bem? Sou da Mandra Digital. ` +
    `Estava vendo que a ${name} não tem site próprio ainda — ` +
    `só o contato no Google/redes. ` +
    `Posso te mostrar sem compromisso como ficaria um site da ${name}?`
  );
}

/**
 * 0–100 qualification score, highest = best prospect for a web agency.
 *
 * The weighting is opinionated on purpose: "no website" is the thing Atlas
 * actually sells against, so it dominates. Everything else is either evidence
 * the business is real and active (confidence, address) or evidence we can
 * actually start a conversation today (phone, WhatsApp). A business with a
 * website can still be a redesign lead, so it scores low rather than zero.
 */
export function scoreLead(lead: Lead): ScoredLead {
  const reasons: string[] = [];
  let score = 0;

  const hasWebsite = Boolean(lead.website);
  const hasSocial = Boolean(lead.social);
  const whatsapp = isWhatsappCapable(lead.phone);

  if (!hasWebsite) {
    score += 45;
    reasons.push("sem site");
  } else {
    score += 5;
    reasons.push("já tem site");
  }

  // Presence on social with no site is the strongest warm signal there is: the
  // owner already believes in being findable, they just never got a site built.
  if (!hasWebsite && hasSocial) {
    score += 15;
    reasons.push("só redes sociais");
  }

  if (lead.phone) {
    score += 15;
    if (whatsapp) {
      score += 10;
      reasons.push("WhatsApp");
    } else {
      reasons.push("telefone fixo");
    }
  } else {
    reasons.push("sem telefone");
  }

  if (lead.confidence >= 0.8) {
    score += 10;
    reasons.push("cadastro confiável");
  } else if (lead.confidence >= 0.6) {
    score += 6;
  } else if (lead.confidence >= 0.4) {
    score += 2;
  } else {
    reasons.push("cadastro duvidoso");
  }

  if (lead.address) score += 5;

  return { ...lead, score: Math.min(100, score), reasons, whatsapp };
}

export function scoreAndSort(leads: Lead[]): ScoredLead[] {
  return leads.map(scoreLead).sort(
    (a, b) =>
      b.score - a.score ||
      // Scores bunch hard at the ceiling — any no-site business with a mobile
      // and a good record scores 100 — so the tiebreak carries real weight.
      // Confidence surfaces the most trustworthy of those; sorting by name
      // would just front-load the alphabet.
      b.confidence - a.confidence ||
      a.name.localeCompare(b.name, "pt-BR"),
  );
}
