"use client";

import { useState, useTransition } from "react";

const STAGES = [
  { id: "NOVO", label: "Novo" },
  { id: "QUALIFICADO", label: "Qualificado" },
  { id: "ABORDAGEM", label: "Abordagem" },
  { id: "CONTATADO", label: "Contatado" },
  { id: "RESPONDEU", label: "Respondeu" },
  { id: "REUNIÃO", label: "Reunião" },
  { id: "PROPOSTA", label: "Proposta" },
  { id: "GANHO", label: "Ganho" },
  { id: "PERDIDO", label: "Perdido" },
];

export function StatusPicker({
  id,
  status,
}: {
  id: string;
  status: string;
}) {
  const normalizedStatus = (status || "NOVO").toUpperCase();
  const [value, setValue] = useState<string>(normalizedStatus);
  const [failed, setFailed] = useState(false);
  const [pending, startTransition] = useTransition();

  function change(next: string) {
    const previous = value;
    setValue(next);
    setFailed(false);

    startTransition(async () => {
      try {
        const res = await fetch(`/api/leads/${id}`, {
          method: "PATCH",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ crmStatus: next }),
        });
        if (!res.ok) throw new Error(String(res.status));
      } catch {
        setValue(previous);
        setFailed(true);
      }
    });
  }

  return (
    <span className="inline-flex items-center gap-1.5">
      <select
        value={value}
        disabled={pending}
        onChange={(e) => change(e.target.value)}
        className="rounded-lg border border-[#E2DDD3] bg-[#FAF9F6] px-2 py-1 text-[11px] font-bold text-[#1E2026] outline-none"
      >
        {STAGES.map((s) => (
          <option key={s.id} value={s.id}>
            {s.label}
          </option>
        ))}
      </select>
      {failed && (
        <span className="text-red-500 text-xs font-bold" title="Não foi possível salvar">
          !
        </span>
      )}
    </span>
  );
}
