"use client";

import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Home,
  Search,
  Target,
  Users,
  MapPin,
  Kanban,
  BookmarkCheck,
  Bot,
  BarChart3,
  UserCheck,
  Settings,
  Sparkles,
  ShieldCheck,
  BookOpen,
  User,
} from "lucide-react";
import { MandraLogo } from "@/components/mandra-logo";

const SIDEBAR_ITEMS = [
  { label: "Seller Home", href: "/seller", icon: User, highlight: true },
  { label: "Overview", href: "/", icon: Home },
  { label: "Prospectar", href: "/prospecting", icon: Search },
  { label: "Leads", href: "/leads", icon: Users },
  { label: "Sniper Leads", href: "/leads?minScore=90", icon: Target, badge: "90+" },
  { label: "Mapa", href: "/map", icon: MapPin },
  { label: "CRM", href: "/crm", icon: Kanban },
  { label: "Pesquisas", href: "/searches", icon: BookmarkCheck },
  { label: "AI SDR", href: "/ai-sdr", icon: Bot },
  { label: "Analytics", href: "/analytics", icon: BarChart3 },
  { label: "Equipe", href: "/team", icon: UserCheck },
  { label: "Onboarding Tour", href: "/welcome", icon: BookOpen },
  { label: "Configurações", href: "/settings", icon: Settings },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="fixed top-0 bottom-0 left-0 z-40 flex w-[260px] flex-col justify-between border-r border-[#22252F] bg-[#101216] text-[#9AA0AC]">
      <div>
        {/* Brand Header */}
        <div className="flex h-16 items-center px-6 border-b border-[#1D2028]">
          <Link href="/">
            <MandraLogo dark />
          </Link>
        </div>

        {/* Navigation Items */}
        <nav className="mt-4 px-3 space-y-1">
          {SIDEBAR_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive =
              item.href === "/"
                ? pathname === "/"
                : item.href.includes("?")
                ? pathname + (typeof window !== "undefined" ? window.location.search : "") === item.href
                : pathname.startsWith(item.href);

            return (
              <Link
                key={item.label}
                href={item.href}
                className={`group flex items-center justify-between rounded-xl px-3.5 py-2.5 text-xs font-medium transition ${
                  isActive
                    ? "bg-[#1E212A] text-white font-bold shadow-xs border-l-2 border-[#FF9E1B]"
                    : "text-[#9AA0AC] hover:bg-[#181A22] hover:text-white"
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`size-4.5 transition ${
                      isActive
                        ? "text-[#FF9E1B]"
                        : item.highlight
                        ? "text-[#FF9E1B] group-hover:text-white"
                        : "text-[#6E7381] group-hover:text-white"
                    }`}
                  />
                  <span>{item.label}</span>
                </div>

                {item.badge && (
                  <span className="rounded-md bg-[#FF9E1B]/15 px-2 py-0.5 text-[10px] font-extrabold text-[#FF9E1B] border border-[#FF9E1B]/30">
                    {item.badge}
                  </span>
                )}
              </Link>
            );
          })}
        </nav>
      </div>

      {/* Bottom Compliance & System Health Badge */}
      <div className="p-4">
        <div className="rounded-xl border border-[#262A36] bg-[#161820] p-3.5 text-xs text-white">
          <div className="flex items-center gap-2 mb-1.5">
            <ShieldCheck className="size-4 text-[#FF9E1B]" />
            <span className="font-bold text-white text-xs">MANDRA SNIPER AI</span>
          </div>
          <p className="text-[11px] text-[#8E94A2] leading-tight">
            Sales Intelligence & Engine SDR em conformidade B2B.
          </p>
        </div>
      </div>
    </aside>
  );
}
