export interface WebSearchResultItem {
  id: string;
  title: string;
  url: string;
  snippet: string;
  discoveredDomain: string | null;
  discoveredPhone: string | null;
  discoveredInstagram: string | null;
}

export class WebSearchProvider {
  /**
   * Queries public web search endpoints for candidates matching niche and location.
   */
  public async searchWeb(queryStr: string, limit: number = 20): Promise<WebSearchResultItem[]> {
    try {
      const searchUrl = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(queryStr)}`;
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 4000);

      const res = await fetch(searchUrl, {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        },
        signal: controller.signal,
      });

      clearTimeout(timeout);

      if (!res.ok) {
        return [];
      }

      const html = await res.text();
      const results: WebSearchResultItem[] = [];

      // Extract result links & snippets using regex
      const linkRegex = /<a class="result__url" href="([^"]+)">(.*?)<\/a>/gi;
      const snippetRegex = /<a class="result__snippet"[^>]*>(.*?)<\/a>/gi;

      let match;
      let count = 0;
      while ((match = linkRegex.exec(html)) !== null && count < limit) {
        const rawUrl = match[1];
        let url = rawUrl;
        if (rawUrl.includes("uddg=")) {
          try {
            const urlObj = new URL(`https://duckduckgo.com${rawUrl}`);
            url = decodeURIComponent(urlObj.searchParams.get("uddg") || rawUrl);
          } catch {}
        }

        const title = match[2].replace(/<[^>]+>/g, "").trim();
        const snippetMatch = snippetRegex.exec(html);
        const snippet = snippetMatch ? snippetMatch[1].replace(/<[^>]+>/g, "").trim() : "";

        // Extract phone number from snippet
        const phoneMatch = snippet.match(/\(?[1-9]{2}\)?\s?9?[0-9]{4}[-\s]?[0-9]{4}/);
        const discoveredPhone = phoneMatch ? phoneMatch[0] : null;

        // Extract Instagram handle
        const instaMatch = url.match(/instagram\.com\/([a-zA-Z0-9_\.]+)/);
        const discoveredInstagram = instaMatch ? `@${instaMatch[1]}` : null;

        // Extract Domain
        let discoveredDomain = null;
        try {
          discoveredDomain = new URL(url).hostname.replace(/^www\./, "");
        } catch {}

        results.push({
          id: `web-${count}-${Date.now()}`,
          title,
          url,
          snippet,
          discoveredDomain,
          discoveredPhone,
          discoveredInstagram,
        });

        count++;
      }

      return results;
    } catch (e) {
      console.warn("WebSearchProvider query exception fallback:", e);
      return [];
    }
  }
}
