"use client";

import React, { useState } from "react";
import { UserPlus, Sparkles, Target, MapPin, ShieldCheck, X, ArrowRight, Copy } from "lucide-react";
import type { SellerProfile, SellerRole } from "@/types";

export function AddSellerModal({
  open,
  onClose,
  onAddSeller,
  existingSellers,
}: {
  open: boolean;
  onClose: () => void;
  onAddSeller: (seller: SellerProfile) => void;
  existingSellers: SellerProfile[];
}) {
  const [step, setStep] = useState(1);

  // Form Fields
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [role, setRole] = useState<SellerRole>("SDR");
  const [mainOffer, setMainOffer] = useState("Landing Page de Agendamento");
  const [region, setRegion] = useState("Campinas, SP");
  const [dailyGoal, setDailyGoal] = useState(20);

  if (!open) return null;

  const applyTemplate = (templateName: string) => {
    if (templateName === "SDR_LANDING_PAGE") {
      setRole("SDR");
      setMainOffer("Landing Page de Agendamento");
      setRegion("Campinas, SP");
      setDailyGoal(20);
    } else if (templateName === "SDR_GOOGLE") {
      setRole("SDR");
      setMainOffer("Otimização Google Meu Negócio");
      setRegion("Sorocaba, SP");
      setDailyGoal(25);
    } else if (templateName === "CLOSER_CRM") {
      setRole("CLOSER");
      setMainOffer("Automação CRM & WhatsApp");
      setRegion("São Paulo, SP");
      setDailyGoal(15);
    }
  };

  const handleDuplicate = (existingId: string) => {
    const existing = existingSellers.find((s) => s.id === existingId);
    if (existing) {
      setRole(existing.role);
      setMainOffer(existing.mainOffer);
      setRegion(existing.region);
      setDailyGoal(existing.dailyContactGoal);
    }
  };

  const handleCreate = () => {
    if (!name || !email) return;

    const newSeller: SellerProfile = {
      id: `seller-${Date.now()}`,
      name,
      email,
      phone,
      role,
      region,
      mainOffer,
      dailyContactGoal: dailyGoal,
      onboardingStatus: "NÃO_INICIADO",
      onboardingCompleted: false,
      assignedLeadsCount: 0,
      completedContactsToday: 0,
      dealsClosedCount: 0,
      createdAt: new Date().toISOString(),
    };

    onAddSeller(newSeller);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4">
      <div className="w-full max-w-xl rounded-3xl border border-[#ECE8E0] bg-white p-7 text-[#1E2026] shadow-2xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#ECE8E0] pb-4">
          <div className="flex items-center gap-3">
            <div className="flex size-10 items-center justify-center rounded-2xl bg-[#1C1F26] text-[#FF9E1B]">
              <UserPlus className="size-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-[#1E2026]">ADICIONAR NOVO VENDEDOR</h2>
              <p className="text-xs text-[#6E7381]">
                Etapa {step} de 4 — Configuração e perfil de acesso do vendedor
              </p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-gray-400 hover:bg-gray-100">
            <X className="size-5" />
          </button>
        </div>

        {/* TEMPLATES PRESETS BAR */}
        <div className="space-y-1.5">
          <span className="text-[11px] font-extrabold uppercase text-[#6E7381]">Usar Template Pronto:</span>
          <div className="flex flex-wrap gap-2 text-xs">
            <button
              onClick={() => applyTemplate("SDR_LANDING_PAGE")}
              className="rounded-lg border border-[#ECE8E0] bg-[#FAF8F4] px-2.5 py-1 text-[11px] font-bold text-[#1E2026] hover:border-[#FF9E1B]"
            >
              ⚡ SDR Landing Page
            </button>
            <button
              onClick={() => applyTemplate("SDR_GOOGLE")}
              className="rounded-lg border border-[#ECE8E0] bg-[#FAF8F4] px-2.5 py-1 text-[11px] font-bold text-[#1E2026] hover:border-[#FF9E1B]"
            >
              ⭐ SDR Google Meu Negócio
            </button>
            <button
              onClick={() => applyTemplate("CLOSER_CRM")}
              className="rounded-lg border border-[#ECE8E0] bg-[#FAF8F4] px-2.5 py-1 text-[11px] font-bold text-[#1E2026] hover:border-[#FF9E1B]"
            >
              🎯 Closer CRM
            </button>
          </div>
        </div>

        {/* STEP 1: DADOS BÁSICOS & CARGO */}
        {step === 1 && (
          <div className="space-y-4">
            <h3 className="font-extrabold text-sm text-[#1E2026]">Passo 1: Dados Básicos e Cargo</h3>
            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-[#1E2026] mb-1">Nome Completo</label>
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ex: Lucas Silva"
                  className="w-full rounded-xl border border-[#E2DDD3] bg-[#FAF9F6] p-3 font-semibold text-[#1E2026] outline-none focus:border-[#FF9E1B]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#1E2026] mb-1">E-mail Comercial</label>
                <input
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="exemplo@empresa.com"
                  className="w-full rounded-xl border border-[#E2DDD3] bg-[#FAF9F6] p-3 font-semibold text-[#1E2026] outline-none focus:border-[#FF9E1B]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#1E2026] mb-1">Cargo Inicial</label>
                <div className="grid grid-cols-3 gap-2">
                  {(["SDR", "CLOSER", "MANAGER", "ADMIN", "VIEWER"] as SellerRole[]).map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setRole(r)}
                      className={`rounded-xl border p-2.5 text-center font-bold transition ${
                        role === r
                          ? "border-[#FF9E1B] bg-[#FFF5E6] text-[#FF9E1B]"
                          : "border-[#ECE8E0] bg-[#FAF9F6] text-[#1E2026]"
                      }`}
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: O QUE ESSA PESSOA VAI VENDER? */}
        {step === 2 && (
          <div className="space-y-4">
            <h3 className="font-extrabold text-sm text-[#1E2026]">Passo 2: Oferta Principal</h3>
            <div className="grid grid-cols-2 gap-2 text-xs font-bold">
              {[
                "Landing Page de Agendamento",
                "Website Institucional",
                "Otimização Google Meu Negócio",
                "Automação CRM & WhatsApp",
                "Gestão de Social Media",
              ].map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setMainOffer(item)}
                  className={`rounded-2xl border p-3.5 text-left transition ${
                    mainOffer === item
                      ? "border-[#FF9E1B] bg-[#FFF5E6] text-[#FF9E1B]"
                      : "border-[#ECE8E0] bg-[#FAF9F6] text-[#1E2026]"
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* STEP 3: ONDE VAI ATUAR? */}
        {step === 3 && (
          <div className="space-y-4">
            <h3 className="font-extrabold text-sm text-[#1E2026]">Passo 3: Região / Cidade de Atuação</h3>
            <div className="space-y-3 text-xs">
              <input
                value={region}
                onChange={(e) => setRegion(e.target.value)}
                placeholder="Ex: Campinas, SP ou Jundiaí, SP"
                className="w-full rounded-xl border border-[#E2DDD3] bg-[#FAF9F6] p-3.5 font-bold text-[#1E2026] outline-none focus:border-[#FF9E1B]"
              />

              <div className="flex flex-wrap gap-2 pt-1">
                {["Campinas, SP", "Sorocaba, SP", "Jundiaí, SP", "São Paulo, SP", "Curitiba, PR"].map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setRegion(c)}
                    className="rounded-lg border border-[#ECE8E0] bg-[#FAF8F4] px-2.5 py-1 text-xs font-semibold text-[#1E2026]"
                  >
                    + {c}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* STEP 4: META DIÁRIA & CONCURSO */}
        {step === 4 && (
          <div className="space-y-4">
            <h3 className="font-extrabold text-sm text-[#1E2026]">Passo 4: Meta Diária de Contatos</h3>
            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-[#1E2026] mb-1">
                  Meta Diária de Contatos Comercial: <strong>{dailyGoal} contatos / dia</strong>
                </label>
                <input
                  type="range"
                  min={5}
                  max={50}
                  value={dailyGoal}
                  onChange={(e) => setDailyGoal(Number(e.target.value))}
                  className="w-full accent-[#FF9E1B]"
                />
              </div>

              <div className="rounded-2xl border border-[#ECE8E0] bg-[#FAF8F4] p-4 space-y-1">
                <div className="font-extrabold text-[#1E2026]">Resumo do Vendedor:</div>
                <div className="text-[#6E7381]">Nome: <strong>{name}</strong></div>
                <div className="text-[#6E7381]">Role: <strong>{role}</strong></div>
                <div className="text-[#6E7381]">Oferta: <strong>{mainOffer}</strong></div>
                <div className="text-[#6E7381]">Região: <strong>{region}</strong></div>
                <div className="text-[#FF9E1B] font-bold pt-1">
                  ✨ Ao criar, o onboarding guiado em 11 passos será ativado no primeiro login!
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="flex items-center justify-between border-t border-[#ECE8E0] pt-4">
          {step > 1 ? (
            <button
              onClick={() => setStep((s) => s - 1)}
              className="rounded-xl border border-[#E2DDD3] bg-white px-4 py-2.5 text-xs font-bold text-[#1E2026] hover:bg-[#FAF8F4]"
            >
              Voltar
            </button>
          ) : (
            <div />
          )}

          {step < 4 ? (
            <button
              onClick={() => setStep((s) => s + 1)}
              className="flex items-center gap-2 rounded-2xl bg-[#1C1F26] px-6 py-3 text-xs font-bold text-white hover:bg-[#2A2E38] transition"
            >
              <span>Próximo Passo</span>
              <ArrowRight className="size-4" />
            </button>
          ) : (
            <button
              onClick={handleCreate}
              disabled={!name || !email}
              className="flex items-center gap-2 rounded-2xl bg-[#FF9E1B] px-7 py-3.5 text-xs font-black text-[#101216] hover:bg-[#F08E0B] transition shadow-md disabled:opacity-50"
            >
              <Sparkles className="size-4" />
              <span>CRIAR VENDEDOR & ATIVAR ONBOARDING</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
