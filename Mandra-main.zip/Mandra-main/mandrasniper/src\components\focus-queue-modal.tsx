"use client";

import React, { useState } from "react";
import { Sparkles, MessageCircle, ArrowRight, Check, X, ChevronRight, Copy, ExternalLink, ShieldCheck } from "lucide-react";
import type { Lead } from "@/types";
import { outreachMessage, whatsappUrl } from "@/lib/score";

export function FocusQueueModal({
  leads,
  open,
  onClose,
}: {
  leads: Lead[];
  open: boolean;
  onClose: () => void;
}) {
  const [currentIndex, setCurrentIndex] = useState(0);

  if (!open || leads.length === 0) return null;

  const currentLead = leads[currentIndex] || leads[0];
  const message = outreachMessage(currentLead);
  const waUrl = whatsappUrl(currentLead.phone, message);

  const handleNext = () => {
    if (currentIndex < leads.length - 1) {
      setCurrentIndex((i) => i + 1);
    } else {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4">
      <div className="w-full max-w-2xl rounded-3xl border border-[#ECE8E0] bg-white p-7 text-[#1E2026] shadow-2xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#ECE8E0] pb-4">
          <div className="flex items-center gap-3">
            <span className="rounded-xl bg-[#FF9E1B]/15 px-3 py-1 text-xs font-extrabold text-[#FF9E1B] border border-[#FF9E1B]/30">
              MODO FOCO DO SDR
            </span>
            <span className="text-xs font-bold text-[#6E7381]">
              Lead {currentIndex + 1} de {leads.length}
            </span>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-gray-400 hover:bg-gray-100">
            <X className="size-5" />
          </button>
        </div>

        {/* Lead Hero Card */}
        <div className="rounded-2xl border border-[#ECE8E0] bg-[#FAF8F4] p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="rounded bg-[#FF9E1B]/15 px-2 py-0.5 text-[10px] font-black text-[#FF9E1B] uppercase">
                SNIPER {currentLead.sniperScore}/100
              </span>
              <h2 className="text-xl font-extrabold text-[#1E2026] mt-1">{currentLead.name}</h2>
              <p className="text-xs text-[#6E7381]">
                {currentLead.category} · {currentLead.city}, {currentLead.state} · ⭐ {currentLead.rating} ({currentLead.reviewsCount} avaliações)
              </p>
            </div>
          </div>

          <div className="rounded-xl bg-white p-3.5 border border-[#ECE8E0] text-xs space-y-1">
            <div className="font-extrabold text-[#1E2026]">Por que abordar agora:</div>
            <div className="text-[#6E7381]">
              "{currentLead.insights?.summary || `${currentLead.name} possui excelente reputação no Google, mas não tem página própria para retenção de clientes.`}"
            </div>
          </div>
        </div>

        {/* Message Script */}
        <div className="space-y-2">
          <span className="text-xs font-extrabold uppercase tracking-wider text-[#6E7381]">
            Mensagem Pronta de WhatsApp:
          </span>
          <div className="rounded-2xl border border-[#ECE8E0] bg-[#FAF9F6] p-4 text-xs font-mono leading-relaxed text-[#1E2026]">
            {message}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between border-t border-[#ECE8E0] pt-4">
          <button
            onClick={() => {
              navigator.clipboard.writeText(message);
            }}
            className="rounded-xl border border-[#E2DDD3] bg-white px-4 py-2.5 text-xs font-bold text-[#1E2026] hover:bg-[#FAF8F4]"
          >
            Copiar Texto
          </button>

          <div className="flex items-center gap-3">
            {waUrl && (
              <a
                href={waUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 rounded-2xl bg-[#25D366] px-5 py-3 text-xs font-bold text-white hover:bg-[#20bd5a] shadow-sm"
              >
                <MessageCircle className="size-4" />
                <span>Abrir WhatsApp</span>
              </a>
            )}

            <button
              onClick={handleNext}
              className="flex items-center gap-2 rounded-2xl bg-[#1C1F26] px-6 py-3 text-xs font-bold text-white hover:bg-[#2A2E38] transition"
            >
              <span>Próximo Lead</span>
              <ChevronRight className="size-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
