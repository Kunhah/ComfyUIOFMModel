"use client";

import React, { useState } from "react";
import { Bot, Sparkles, MessageSquare, PhoneCall, HelpCircle, X, Check, Copy } from "lucide-react";
import type { Lead } from "@/types";

export function AiSalesCoachModal({
  lead,
  open,
  onClose,
}: {
  lead: Lead | null;
  open: boolean;
  onClose: () => void;
}) {
  const [activeTab, setActiveTab] = useState<"OBJECTIONS" | "SCRIPT" | "COACH">("OBJECTIONS");
  const [selectedObjection, setSelectedObjection] = useState<string | null>(null);

  if (!open || !lead) return null;

  const objections = [
    {
      q: "Já temos Instagram, pra que precisamos de site?",
      a: `No Instagram você depende do algoritmo e disputa atenção com concorrentes. No Google, ${lead.reviewsCount} pessoas já procuram ativamente por ${lead.category} em ${lead.city} com intenção de compra. Uma landing page direciona esse cliente de busca direto para o seu WhatsApp.`,
    },
    {
      q: "Já temos um site antigo e ninguém entra.",
      a: "Sites antigos geralmente não são otimizados para celular nem possuem botão direto de agendamento no WhatsApp. Nosso foco é criar uma página de alta conversão feita especificamente para transformar visitantes do Google em contatos em 1 clique.",
    },
    {
      q: "Quanto custa essa landing page?",
      a: "Trabalhamos com modelos acessíveis focados em retorno rápido. Com 2 ou 3 novos clientes captados pelo agendamento no WhatsApp a estrutura já se paga no primeiro mês. Posso enviar um exemplo de 2 minutos?",
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
      <div className="w-full max-w-2xl rounded-3xl border border-[#ECE8E0] bg-white p-6 text-[#1E2026] shadow-2xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#ECE8E0] pb-4">
          <div className="flex items-center gap-3">
            <div className="flex size-10 items-center justify-center rounded-2xl bg-[#FFF5E6] text-[#FF9E1B]">
              <Bot className="size-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-[#1E2026]">
                AI SALES COACH — INSTRUTOR DE VENDAS
              </h3>
              <p className="text-xs text-[#6E7381]">
                Treinador comercial para {lead.name} ({lead.category} · {lead.city})
              </p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-gray-400 hover:bg-gray-100">
            <X className="size-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-2 border-b border-[#ECE8E0] pb-2 text-xs font-bold">
          <button
            onClick={() => setActiveTab("OBJECTIONS")}
            className={`px-3 py-1.5 rounded-xl transition ${
              activeTab === "OBJECTIONS" ? "bg-[#1C1F26] text-white" : "text-[#6E7381] hover:bg-[#FAF8F4]"
            }`}
          >
            Contornar Objeções
          </button>
          <button
            onClick={() => setActiveTab("SCRIPT")}
            className={`px-3 py-1.5 rounded-xl transition ${
              activeTab === "SCRIPT" ? "bg-[#1C1F26] text-white" : "text-[#6E7381] hover:bg-[#FAF8F4]"
            }`}
          >
            Script de Ligação Rápida
          </button>
        </div>

        {/* Tab 1: Objections */}
        {activeTab === "OBJECTIONS" && (
          <div className="space-y-3">
            <span className="text-xs font-extrabold uppercase text-[#6E7381]">
              Clique na objeção para ver a resposta recomendada pela IA:
            </span>
            <div className="space-y-2">
              {objections.map((obj, idx) => (
                <div
                  key={idx}
                  onClick={() => setSelectedObjection(selectedObjection === obj.q ? null : obj.q)}
                  className="rounded-2xl border border-[#ECE8E0] bg-[#FAF8F4] p-4 cursor-pointer hover:border-[#FF9E1B] transition space-y-2"
                >
                  <div className="font-extrabold text-xs text-[#1E2026] flex items-center justify-between">
                    <span>💬 "{obj.q}"</span>
                    <span className="text-[10px] font-bold text-[#FF9E1B]">Ver Resposta</span>
                  </div>
                  {selectedObjection === obj.q && (
                    <div className="text-xs text-[#6E7381] font-medium leading-relaxed pt-2 border-t border-[#ECE8E0] bg-white p-3 rounded-xl">
                      <strong>Resposta Recomendada:</strong> {obj.a}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 2: Call Script */}
        {activeTab === "SCRIPT" && (
          <div className="space-y-3 text-xs leading-relaxed">
            <div className="rounded-2xl border border-[#ECE8E0] bg-[#FAF9F6] p-4 space-y-2">
              <div className="font-bold text-[#1E2026]">1. ABERTURA:</div>
              <div className="text-[#6E7381]">"Olá, falo com o responsável comercial da {lead.name}?"</div>

              <div className="font-bold text-[#1E2026] pt-1">2. GANHO DE RESPEITO (FATO REAL):</div>
              <div className="text-[#6E7381]">
                "Vi que vocês têm {lead.reviewsCount} avaliações excelentes no Google com nota {lead.rating} em {lead.city}. Parabéns pelo trabalho!"
              </div>

              <div className="font-bold text-[#1E2026] pt-1">3. IDENTIFICAÇÃO DA DOR:</div>
              <div className="text-[#6E7381]">
                "Porém notei que quem busca por {lead.category} na região hoje não encontra uma página própria de agendamento de vocês."
              </div>

              <div className="font-bold text-[#1E2026] pt-1">4. PROPOSTA DE VALOR & CTA:</div>
              <div className="text-[#6E7381]">
                "Desenvolvemos uma estrutura de alta conversão para enviar esses clientes direto para o seu WhatsApp. Posso enviar um exemplo de 2 minutos no WhatsApp de vocês?"
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
