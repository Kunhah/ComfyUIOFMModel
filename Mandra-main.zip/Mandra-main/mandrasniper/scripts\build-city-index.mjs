#!/usr/bin/env node
/**
 * Regenerate src/data/br-cities.json — every place name you can actually search,
 * with its bounding box and how many prospectable businesses sit behind it.
 *
 * Run: npm run cities        (from Prospector/, after npm run sync)
 *
 * This is committed output. Re-run it after every `npm run sync`, since the
 * counts and the set of searchable names both come from the extract.
 *
 * Why the extract is the source of truth rather than Overture's division
 * boundaries: the boundaries say what a municipality is *called*, the business
 * records say what their addresses actually *say*, and where those disagree the
 * boundary name is unsearchable. Measured on the previous divisions-only index,
 * 784 localities holding 10.753 businesses could not be reached from the UI at
 * all. Brasília was 9.094 of them — Overture models the Federal District as 35
 * administrative regions (Plano Piloto, Ceilândia, Taguatinga…) and has no
 * locality named "Brasília", while the businesses there say exactly that.
 *
 * Building from the places side makes that whole class of bug impossible: a name
 * is in the index because businesses use it. Divisions are still read, but only
 * to supply nicely typeset display names and to register their spelling as an
 * alias when it differs from what the records say.
 */
import { writeFileSync, existsSync, statSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { DuckDBInstance } from "@duckdb/node-api";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..");
const out = path.join(root, "src", "data", "br-cities.json");
const extract = path.join(root, "data", "br-leads.parquet");

const RELEASE = process.env.OVERTURE_RELEASE ?? "2026-07-22.0";
const DIVISIONS = `s3://overturemaps-us-west-2/release/${RELEASE}/theme=divisions/type=division_area/*`;

/**
 * Alternate spellings, written by hand.
 *
 * This was generated automatically at first, pairing each unused boundary name
 * with its closest unreachable locality (Jaro-Winkler ≥ 0.90, restricted to names
 * that had nothing to lose on either side). It looked principled and was not:
 * of 19 pairs produced, 13 joined genuinely different municipalities —
 * "Capão Bonito do Sul" to "Capão Bonito", "Alagoinha do Piauí" to "Alagoinha",
 * "Santa Rita" to "Santa Luzia". A wrong alias is worse than a missing one,
 * because the search succeeds and quietly returns another town's businesses.
 * Tightening the threshold didn't rescue it either — the case that prompted the
 * whole idea, "Assu" for records spelling it "Açu", scores below every cutoff
 * that excludes the false pairs.
 *
 * So: [alias typed by the user, name in the records, state]. Add only pairs you
 * have actually confirmed are one municipality.
 */
const ALIASES = [
  // IBGE writes it "Assu"; the business records say "Açu".
  ["Assu", "Açu", "RN"],
];

if (!existsSync(extract)) {
  console.error(
    `Missing ${path.relative(root, extract)} — run npm run sync first.`,
  );
  process.exit(1);
}

const q = (s) => s.replace(/'/g, "''");
const br = (v) => Number(v).toLocaleString("pt-BR");

console.log(`Overture release : ${RELEASE}`);
console.log(`Extract          : ${path.relative(root, extract)}`);
console.log(`Output           : ${path.relative(root, out)}`);
console.log("");

const instance = await DuckDBInstance.create(":memory:");
const db = await instance.connect();
const rows = async (sql) => (await db.runAndReadAll(sql)).getRowObjectsJS();

// Must fold exactly like normalise() in src/lib/cities.ts: accents and
// punctuation both go, so "São João del-Rei" and "Sao Joao del Rei" agree.
await db.run(`CREATE MACRO nrm(s) AS
  trim(regexp_replace(regexp_replace(lower(strip_accents(s)), '[^a-z0-9]+', ' ', 'g'), '\\s+', ' ', 'g'))`);

// Snap outwards, never inwards. round() can push a bound past the business that
// defined it, and the query filters on `lon BETWEEN xmin AND xmax` — a bound
// rounded the wrong way silently drops the very lead that set it.
await db.run(`CREATE MACRO lo(v) AS floor(v * 10000) / 10000`);
await db.run(`CREATE MACRO hi(v) AS ceil(v * 10000) / 10000`);

const NOSITE = `count(*) FILTER (WHERE website IS NULL OR website = '')`;

await db.run(`CREATE TABLE ext AS
  SELECT nrm(city) AS n, uf, city AS raw, website, lon, lat
  FROM read_parquet('${q(extract)}')
  WHERE city IS NOT NULL AND lon IS NOT NULL AND lat IS NOT NULL`);

// Localities that name a state. These are the queryable units.
await db.run(`CREATE TABLE grp AS
  SELECT n, uf,
         mode(raw) AS display,          -- most common spelling, so accents survive
         count(*) AS biz, ${NOSITE} AS nosite,
         lo(min(lon)) AS xmin, hi(max(lon)) AS xmax,
         lo(min(lat)) AS ymin, hi(max(lat)) AS ymax
  FROM ext WHERE uf IS NOT NULL GROUP BY n, uf`);

// Rows whose address gave a city but no state. The query reaches them with
// `uf IS NULL` once bbox and locality already match, so fold their counts and
// extent into the city they belong to — but only when the name occurs in exactly
// one state, otherwise "Santa Luzia" would be credited to all of them.
await db.run(`CREATE TABLE nouf AS
  SELECT n, count(*) AS biz, ${NOSITE} AS nosite,
         lo(min(lon)) AS xmin, hi(max(lon)) AS xmax,
         lo(min(lat)) AS ymin, hi(max(lat)) AS ymax
  FROM ext WHERE uf IS NULL GROUP BY n`);
await db.run(`CREATE TABLE unique_names AS
  SELECT n FROM grp GROUP BY n HAVING count(*) = 1`);

// Narrowed to unambiguous names up front: DuckDB can't take a subquery in a
// LEFT JOIN condition, and folding the filter into the join would silently
// become an inner join if written carelessly.
await db.run(`CREATE TABLE nouf_unique AS
  SELECT u.* FROM nouf u WHERE u.n IN (SELECT n FROM unique_names)`);

await db.run(`CREATE TABLE merged AS
  SELECT g.n, g.uf, g.display,
         g.biz + coalesce(u.biz, 0) AS biz,
         g.nosite + coalesce(u.nosite, 0) AS nosite,
         least(g.xmin, coalesce(u.xmin, g.xmin)) AS xmin,
         greatest(g.xmax, coalesce(u.xmax, g.xmax)) AS xmax,
         least(g.ymin, coalesce(u.ymin, g.ymin)) AS ymin,
         greatest(g.ymax, coalesce(u.ymax, g.ymax)) AS ymax
  FROM grp g
  LEFT JOIN nouf_unique u ON u.n = g.n`);

// --- divisions: display names, authoritative extents, alias spellings ---------
await db.run("INSTALL httpfs");
await db.run("LOAD httpfs");
await db.run("SET s3_region='us-west-2'");
// Public bucket: blank the credentials or DuckDB signs with ambient AWS env vars and 403s.
await db.run("SET s3_access_key_id=''");
await db.run("SET s3_secret_access_key=''");

console.log("Reading division boundaries for canonical spellings...");
await db.run(`CREATE TABLE div AS
  SELECT names.primary AS display, nrm(names.primary) AS n,
         replace(region, 'BR-', '') AS uf,
         lo(bbox.xmin) AS xmin, hi(bbox.xmax) AS xmax,
         lo(bbox.ymin) AS ymin, hi(bbox.ymax) AS ymax
  FROM read_parquet('${DIVISIONS}', hive_partitioning = 1)
  WHERE country = 'BR' AND subtype = 'locality' AND names.primary IS NOT NULL
  -- A locality can appear more than once; keep the largest polygon, which is the
  -- municipality proper rather than a district inside it.
  QUALIFY row_number() OVER (
    PARTITION BY nrm(names.primary), region
    ORDER BY (bbox.xmax - bbox.xmin) * (bbox.ymax - bbox.ymin) DESC
  ) = 1`);

const aliasValues = ALIASES.map(
  ([alias, target, uf]) => `('${q(alias)}', nrm('${q(target)}'), '${q(uf)}')`,
).join(", ");

await db.run(`CREATE TABLE alias AS
  SELECT * FROM (VALUES ${aliasValues}) AS t(alias, target_n, target_uf)`);

// A curated pair that no longer matches anything is a silent no-op, so surface it
// rather than letting the list rot as the data shifts under it.
const staleAliases = await rows(
  `SELECT a.alias, a.target_uf AS uf FROM alias a
   WHERE NOT EXISTS (SELECT 1 FROM merged m WHERE m.n = a.target_n AND m.uf = a.target_uf)`,
);

const aliasPairs = await rows(
  `SELECT a.alias, m.display AS target, a.target_uf AS uf, m.biz
   FROM alias a JOIN merged m ON m.n = a.target_n AND m.uf = a.target_uf
   ORDER BY m.biz DESC`,
);

// Final rows. Division extent is unioned in, never substituted: it is the legal
// boundary, while a business can sit just outside it, and losing that business
// would be worse than a slightly loose box.
const final = await rows(`
  WITH agg AS (
    SELECT target_n AS n, target_uf AS uf, list(alias) AS aliases
    FROM alias GROUP BY 1, 2
  )
  SELECT coalesce(d.display, m.display) AS name, m.uf,
         least(m.xmin, coalesce(d.xmin, m.xmin)) AS xmin,
         greatest(m.xmax, coalesce(d.xmax, m.xmax)) AS xmax,
         least(m.ymin, coalesce(d.ymin, m.ymin)) AS ymin,
         greatest(m.ymax, coalesce(d.ymax, m.ymax)) AS ymax,
         m.biz, m.nosite, coalesce(a.aliases, []) AS aliases
  FROM merged m
  LEFT JOIN div d ON d.n = m.n AND d.uf = m.uf
  LEFT JOIN agg a ON a.n = m.n AND a.uf = m.uf
  ORDER BY m.biz DESC
`);

const tuples = final.map((r) => {
  const t = [
    r.name,
    r.uf,
    Number(r.xmin),
    Number(r.xmax),
    Number(r.ymin),
    Number(r.ymax),
    Number(r.biz),
    Number(r.nosite),
  ];
  const aliases = (r.aliases ?? []).filter((a) => a);
  if (aliases.length > 0) t.push(aliases);
  return t;
});

writeFileSync(out, JSON.stringify(tuples));

// --- report -------------------------------------------------------------------
const [stat] = await rows(`SELECT
  (SELECT count(*) FROM merged) AS cities,
  (SELECT sum(biz) FROM merged) AS biz,
  (SELECT sum(nosite) FROM merged) AS nosite,
  (SELECT count(*) FROM ext) AS ext_rows,
  (SELECT coalesce(sum(biz), 0) FROM nouf WHERE n NOT IN (SELECT n FROM unique_names)) AS orphan_nouf,
  (SELECT count(*) FROM div d WHERE NOT EXISTS (
     SELECT 1 FROM merged m WHERE m.n = d.n AND m.uf = d.uf)) AS empty_divisions`);

const kb = (statSync(out).size / 1024).toFixed(0);
const reachable = Number(stat.biz);
const extRows = Number(stat.ext_rows);

console.log("");
console.log(`Wrote ${br(stat.cities)} searchable places (${kb} KB).`);
console.log(
  `  businesses reachable : ${br(reachable)} of ${br(extRows)} in the extract`,
);
console.log(`  without a website    : ${br(stat.nosite)}`);
console.log(
  `  unreachable          : ${br(extRows - reachable)} (ambiguous city name, no state)`,
);
console.log(
  `  state-less folded in : ${br(Number(stat.orphan_nouf))} left out as ambiguous`,
);
console.log(
  `  divisions with no businesses: ${br(stat.empty_divisions)} (left out — they would autocomplete to zero results)`,
);

if (aliasPairs.length > 0) {
  console.log("");
  console.log(`Alias spellings (${aliasPairs.length}):`);
  for (const a of aliasPairs) {
    console.log(
      `  ${a.alias} -> ${a.target}/${a.uf}  (${br(a.biz)} businesses)`,
    );
  }
}

if (staleAliases.length > 0) {
  console.log("");
  console.log("Stale aliases in ALIASES — target no longer in the data:");
  for (const a of staleAliases) console.log(`  ${a.alias}/${a.uf}`);
}
