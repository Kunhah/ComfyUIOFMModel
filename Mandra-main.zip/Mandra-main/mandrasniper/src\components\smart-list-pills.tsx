"use client";

import React from "react";
import { Sparkles, Target, Globe, AlertTriangle, Share2, MessageCircle, Star, Clock, Filter } from "lucide-react";

export interface SmartListFilter {
  id: string;
  label: string;
  icon: any;
  filterFn: (params: any) => void;
}

export function SmartListPills({
  activeList,
  onSelectList,
}: {
  activeList: string;
  onSelectList: (id: string) => void;
}) {
  const lists = [
    { id: "ALL", label: "Todos os Leads", icon: Filter },
    { id: "SNIPER_LEADS", label: "SNIPER LEADS (90+)", icon: Target, highlight: true },
    { id: "HOT_LEADS", label: "HOT LEADS", icon: Sparkles },
    { id: "SEM_SITE", label: "SEM SITE", icon: Globe },
    { id: "SITE_RUIM", label: "SITE RUIM", icon: AlertTriangle },
    { id: "INSTAGRAM_FORTE", label: "INSTAGRAM FORTE", icon: Share2 },
    { id: "WHATSAPP_DISPONIVEL", label: "WHATSAPP DISPONÍVEL", icon: MessageCircle },
    { id: "ALTA_REPUTACAO", label: "ALTA REPUTAÇÃO (4.8+)", icon: Star },
    { id: "ABORDAR_HOJE", label: "ABORDAR HOJE", icon: Clock },
  ];

  return (
    <div className="flex flex-wrap items-center gap-2 py-2 overflow-x-auto">
      {lists.map((item) => {
        const Icon = item.icon;
        const isSelected = activeList === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onSelectList(item.id)}
            className={`flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-xs font-bold transition shadow-2xs ${
              isSelected
                ? "border-[#FF9E1B] bg-[#FFF5E6] text-[#FF9E1B]"
                : item.highlight
                ? "border-[#FF9E1B]/40 bg-[#1C1F26] text-white hover:border-[#FF9E1B]"
                : "border-[#E2DDD3] bg-white text-[#6E7381] hover:bg-[#FAF8F4] hover:text-[#1E2026]"
            }`}
          >
            <Icon className={`size-3.5 ${item.highlight && !isSelected ? "text-[#FF9E1B]" : ""}`} />
            <span>{item.label}</span>
          </button>
        );
      })}
    </div>
  );
}
