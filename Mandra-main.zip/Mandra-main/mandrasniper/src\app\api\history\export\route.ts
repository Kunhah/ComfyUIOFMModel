import { csvResponse, safeFilename } from "@/lib/csv";
import { allMatching, parseFilters } from "@/lib/history";

// node:sqlite is a Node builtin, so this can't run on the edge runtime.
export const runtime = "nodejs";

/**
 * CSV of the whole filtered history — every matching row, not the page you happen
 * to be looking at. The board's export takes rows posted from the browser because
 * it has to match what's on screen; this one reads from SQLite, so it has no
 * reason to be capped.
 *
 * A GET with the page's own query string, so the download link is just the
 * current view with a different path.
 */
export async function GET(request: Request): Promise<Response> {
  const params = Object.fromEntries(new URL(request.url).searchParams);
  const filters = parseFilters(params);
  const leads = allMatching(filters);

  const parts = [
    "historico",
    filters.niche,
    filters.city,
    filters.status,
    filters.onlyNoSite ? "sem-site" : null,
    filters.onlyWhatsapp ? "whatsapp" : null,
  ].filter(Boolean);

  return csvResponse(leads, safeFilename(parts.join("-")), {
    includeHistory: true,
  });
}
