import { normalise } from "@/lib/cities";
import type { NicheDefinition } from "./niche-taxonomy";

export type NicheMatchTier = "EXACT" | "STRONG" | "POSSIBLE" | "REJECT";

export interface NicheValidationResult {
  score: number;
  tier: NicheMatchTier;
  isValidMatch: boolean;
  matchedSignals: string[];
}

export class NicheValidator {
  /**
   * Validates whether a candidate business actually matches the target niche.
   */
  public validateCandidateNiche(
    candidateName: string,
    candidateCategory?: string | null,
    targetNiche?: NicheDefinition
  ): NicheValidationResult {
    if (!targetNiche) {
      return { score: 90, tier: "EXACT", isValidMatch: true, matchedSignals: ["Default Match"] };
    }

    const normName = normalise(candidateName);
    const normCategory = normalise(candidateCategory || "");
    const matchedSignals: string[] = [];

    let score = 50; // Baseline score

    // 1. Direct Name Match with Niche Aliases
    for (const alias of targetNiche.aliases) {
      const normAlias = normalise(alias);
      if (normName.includes(normAlias)) {
        score += 35;
        matchedSignals.push(`Nome contém '${alias}'`);
        break;
      }
    }

    // 2. Direct Category Match
    for (const alias of targetNiche.aliases) {
      const normAlias = normalise(alias);
      if (normCategory.includes(normAlias)) {
        score += 25;
        matchedSignals.push(`Categoria '${candidateCategory}' compatível`);
        break;
      }
    }

    // Cap score at 100
    score = Math.min(100, score);

    let tier: NicheMatchTier = "POSSIBLE";
    if (score >= 90) tier = "EXACT";
    else if (score >= 70) tier = "STRONG";
    else if (score >= 50) tier = "POSSIBLE";
    else tier = "REJECT";

    const isValidMatch = score >= 50;

    return {
      score,
      tier,
      isValidMatch,
      matchedSignals,
    };
  }
}
