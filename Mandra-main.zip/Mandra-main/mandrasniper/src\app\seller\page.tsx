"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import {
  Sparkles,
  Target,
  MessageCircle,
  TrendingUp,
  ArrowRight,
  Zap,
  CheckCircle2,
  BookOpen,
  Play,
  Flame,
  Award,
  Layers,
} from "lucide-react";
import type { Lead } from "@/types";
import { FocusQueueModal } from "@/components/focus-queue-modal";

export default function SellerHomePage() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [showFocusQueue, setShowFocusQueue] = useState(false);

  useEffect(() => {
    fetch("/api/leads")
      .then((r) => r.json())
      .then((d) => {
        if (d.leads) setLeads(d.leads);
        setLoading(false);
      });
  }, []);

  const sniperLeads = leads.filter((l) => l.sniperScore >= 90);
  const hotLeads = leads.filter((l) => l.sniperScore >= 75);

  return (
    <div className="space-y-8 max-w-6xl">
      {/* SELLER HEADER BANNER */}
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between border-b border-[#ECE8E0] pb-6">
        <div>
          <div className="inline-flex items-center gap-2 rounded-lg bg-[#FF9E1B]/15 px-3 py-1 text-xs font-extrabold text-[#FF9E1B] border border-[#FF9E1B]/30 mb-2">
            <Sparkles className="size-3.5" />
            <span>MANDRA SELLER HOME · PAINEL DO VENDEDOR</span>
          </div>
          <h1 className="text-3xl font-black tracking-tight text-[#1E2026] uppercase">
            O QUE VOCÊ QUER FAZER AGORA?
          </h1>
          <p className="mt-1 text-sm text-[#6E7381]">
            Seu centro de comando para prospecção B2B de alta conversão.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/welcome"
            className="inline-flex items-center gap-2 rounded-2xl border border-[#E2DDD3] bg-white px-4 py-2.5 text-xs font-bold text-[#1E2026] hover:bg-[#FAF8F4] transition shadow-xs"
          >
            <BookOpen className="size-4 text-[#FF9E1B]" />
            <span>Refazer Tour / Onboarding</span>
          </Link>
        </div>
      </div>

      {/* BIG ACTION CARDS */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Card 1 */}
        <Link
          href="/prospecting"
          className="group rounded-2xl border border-[#ECE8E0] bg-white p-5 shadow-2xs hover:border-[#FF9E1B] transition space-y-3"
        >
          <div className="flex size-10 items-center justify-center rounded-xl bg-[#FFF5E6] text-[#FF9E1B]">
            <Sparkles className="size-5" />
          </div>
          <div>
            <div className="font-extrabold text-sm text-[#1E2026]">GERAR NOVOS LEADS</div>
            <div className="text-xs text-[#6E7381] mt-0.5">Buscar empresas em 3 cliques</div>
          </div>
          <div className="text-xs font-bold text-[#FF9E1B] flex items-center gap-1">
            <span>Iniciar Busca</span>
            <ArrowRight className="size-3.5 group-hover:translate-x-1 transition" />
          </div>
        </Link>

        {/* Card 2 */}
        <button
          onClick={() => setShowFocusQueue(true)}
          className="group text-left rounded-2xl border border-[#ECE8E0] bg-white p-5 shadow-2xs hover:border-[#FF9E1B] transition space-y-3"
        >
          <div className="flex size-10 items-center justify-center rounded-xl bg-[#FFF5E6] text-[#FF9E1B]">
            <Target className="size-5" />
          </div>
          <div>
            <div className="font-extrabold text-sm text-[#1E2026]">COMEÇAR PROSPECÇÃO</div>
            <div className="text-xs text-[#6E7381] mt-0.5">Prospectar Foco (1 lead por vez)</div>
          </div>
          <div className="text-xs font-bold text-[#FF9E1B] flex items-center gap-1">
            <span>Abrir Fila</span>
            <ArrowRight className="size-3.5 group-hover:translate-x-1 transition" />
          </div>
        </button>

        {/* Card 3 */}
        <Link
          href="/crm"
          className="group rounded-2xl border border-[#ECE8E0] bg-white p-5 shadow-2xs hover:border-[#FF9E1B] transition space-y-3"
        >
          <div className="flex size-10 items-center justify-center rounded-xl bg-[#EAFBF1] text-[#25D366]">
            <MessageCircle className="size-5" />
          </div>
          <div>
            <div className="font-extrabold text-sm text-[#1E2026]">FAZER FOLLOW-UPS</div>
            <div className="text-xs text-[#6E7381] mt-0.5">Gerenciar negociações e lembretes</div>
          </div>
          <div className="text-xs font-bold text-emerald-600 flex items-center gap-1">
            <span>Ver Pipeline</span>
            <ArrowRight className="size-3.5 group-hover:translate-x-1 transition" />
          </div>
        </Link>

        {/* Card 4 */}
        <Link
          href="/analytics"
          className="group rounded-2xl border border-[#ECE8E0] bg-white p-5 shadow-2xs hover:border-[#FF9E1B] transition space-y-3"
        >
          <div className="flex size-10 items-center justify-center rounded-xl bg-blue-50 text-blue-600">
            <TrendingUp className="size-5" />
          </div>
          <div>
            <div className="font-extrabold text-sm text-[#1E2026]">VER MEU DESEMPENHO</div>
            <div className="text-xs text-[#6E7381] mt-0.5">Metas e taxa de conversão</div>
          </div>
          <div className="text-xs font-bold text-blue-600 flex items-center gap-1">
            <span>Ver Métricas</span>
            <ArrowRight className="size-3.5 group-hover:translate-x-1 transition" />
          </div>
        </Link>
      </div>

      {/* PRÓXIMA MELHOR AÇÃO & CHECKLIST PRIMEIRO DIA */}
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 rounded-2xl border border-[#FF9E1B]/30 bg-[#FFF9F0] p-6 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 text-xs font-black text-[#FF9E1B] uppercase tracking-wider">
            <Zap className="size-4 fill-[#FF9E1B]" />
            <span>SUA PRÓXIMA MELHOR AÇÃO</span>
          </div>

          <h2 className="text-xl font-black text-[#1E2026]">
            Você tem {sniperLeads.length} Sniper Leads quentes aguardando contato.
          </h2>

          <p className="text-xs text-[#6E7381] leading-relaxed">
            Essas empresas possuem nota alta no Google e reputação ativa, mas não têm site próprio. Inicie a prospecção foco para abordar 1 por vez.
          </p>

          <div className="pt-2">
            <button
              onClick={() => setShowFocusQueue(true)}
              className="flex items-center gap-2 rounded-xl bg-[#1C1F26] px-6 py-3 text-xs font-bold text-white hover:bg-[#2A2E38] transition shadow-xs"
            >
              <Play className="size-4 text-[#FF9E1B]" />
              <span>INICIAR FILA DE PROSPECÇÃO</span>
            </button>
          </div>
        </div>

        {/* CHECKLIST DO PRIMEIRO DIA */}
        <div className="rounded-2xl border border-[#ECE8E0] bg-white p-6 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-[#ECE8E0] pb-3">
            <h3 className="font-black text-sm text-[#1E2026] uppercase">CHECKLIST DO 1º DIA</h3>
          </div>

          <div className="space-y-2.5 text-xs font-bold">
            <div className="flex items-center gap-2 text-emerald-700">
              <CheckCircle2 className="size-4 text-emerald-600" />
              <span>1. Completar onboarding</span>
            </div>
            <div className="flex items-center gap-2 text-emerald-700">
              <CheckCircle2 className="size-4 text-emerald-600" />
              <span>2. Gerar primeira lista</span>
            </div>
            <div className="flex items-center gap-2 text-[#1E2026]">
              <CheckCircle2 className="size-4 text-gray-300" />
              <span>3. Fazer primeiro contato</span>
            </div>
            <div className="flex items-center gap-2 text-[#1E2026]">
              <CheckCircle2 className="size-4 text-gray-300" />
              <span>4. Agendar primeiro follow-up</span>
            </div>
          </div>
        </div>
      </div>

      <FocusQueueModal leads={sniperLeads} open={showFocusQueue} onClose={() => setShowFocusQueue(false)} />
    </div>
  );
}
