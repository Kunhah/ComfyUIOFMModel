import raw from "@/data/br-cities.json";

/**
 * Every place name you can actually search, with its bounding box and how many
 * prospectable businesses sit behind it.
 *
 * Why this file exists rather than a lookup at query time: the Overture places
 * dataset is one flat set of Parquet files with no geographic partitioning, so
 * the only thing that keeps a query from scanning the whole planet is a bbox
 * predicate that Parquet row-group statistics can prune on. We need the bbox
 * *before* we can query places, and pulling it from the divisions theme would
 * double the round trips. So it's resolved once, offline, by
 * `npm run cities` — see scripts/build-city-index.mjs.
 *
 * The index is built from the extract itself, not from Overture's division
 * boundaries. That inversion matters: the boundaries say what a municipality is
 * *called*, the business records say what the addresses actually *say*, and when
 * those disagree the boundary name is unsearchable. Brasília was the worst case —
 * Overture models the Federal District as 35 administrative regions (Plano
 * Piloto, Ceilândia, Taguatinga…) and has no locality named "Brasília" at all,
 * while 9.094 businesses give their city as exactly that. Deriving the index
 * from the places side makes that class of bug impossible.
 */
type Row = [
  name: string,
  uf: string,
  xmin: number,
  xmax: number,
  ymin: number,
  ymax: number,
  businesses: number,
  noSite: number,
  // Alternate spellings that should resolve here — Overture's boundary name when
  // it disagrees with the business records ("Assu" for records saying "Açu").
  aliases?: string[],
];

export type City = {
  name: string;
  uf: string;
  bbox: { xmin: number; xmax: number; ymin: number; ymax: number };
  /** Businesses in the local extract, across every niche. */
  businesses: number;
  /** …of which have no website. The size of the sellable pool. */
  noSite: number;
};

const ROWS = raw as unknown as Row[];

const UFS = new Set([
  "AC",
  "AL",
  "AM",
  "AP",
  "BA",
  "CE",
  "DF",
  "ES",
  "GO",
  "MA",
  "MG",
  "MS",
  "MT",
  "PA",
  "PB",
  "PE",
  "PI",
  "PR",
  "RJ",
  "RN",
  "RO",
  "RR",
  "RS",
  "SC",
  "SE",
  "SP",
  "TO",
]);

/**
 * Fold away everything users get wrong: case, accents, and punctuation.
 *
 * The punctuation step is not cosmetic. Overture's boundary names are typeset
 * ("São João del-Rei", "Itapecuru-Mirim") while the business records write them
 * plainly ("Sao Joao del Rei"), so an accent-only normaliser left real
 * municipalities stranded — 1.187 businesses in São João del-Rei alone matched
 * nothing.
 *
 * `overture.ts` applies the same folding in SQL. The two must agree or a city
 * resolves in the picker and then returns zero rows.
 */
export function normalise(s: string): string {
  return s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function toCity(r: Row): City {
  return {
    name: r[0],
    uf: r[1],
    bbox: { xmin: r[2], xmax: r[3], ymin: r[4], ymax: r[5] },
    businesses: r[6],
    noSite: r[7],
  };
}

/** Every string that should resolve to this row. */
function keysOf(r: Row): string[] {
  const keys = [normalise(r[0])];
  for (const a of r[8] ?? []) keys.push(normalise(a));
  return keys;
}

/**
 * Splits a trailing state code off the query, so "belo horizonte mg" and
 * "Ibirité - MG" work. People paste city and state together constantly, and
 * without this the whole query is treated as a city name and finds nothing.
 */
function splitUf(query: string): { text: string; uf: string | null } {
  const m = /^(.*?)[\s,/-]+([a-z]{2})$/i.exec(query.trim());
  if (m) {
    const uf = m[2].toUpperCase();
    if (UFS.has(uf) && normalise(m[1]).length >= 2) {
      return { text: m[1], uf };
    }
  }
  return { text: query, uf: null };
}

/**
 * Prefix-first search for the city autocomplete.
 *
 * Ranked by business count rather than bbox area. Area was a bad proxy: sprawling
 * Amazonian municipalities have enormous boxes and almost no businesses, so they
 * outranked the capitals people were actually typing. Business count is the thing
 * the user cares about anyway — it is what the search will return.
 */
export function searchCities(query: string, limit = 12): City[] {
  const { text, uf } = splitUf(query);
  const q = normalise(text);
  if (q.length < 2) return [];

  const scored: { row: Row; rank: number }[] = [];
  for (const row of ROWS) {
    if (uf && row[1] !== uf) continue;

    let rank = Infinity;
    for (const key of keysOf(row)) {
      if (key === q) rank = Math.min(rank, 0);
      else if (key.startsWith(q)) rank = Math.min(rank, 1);
      // Word-boundary hit beats a mid-word one: typing "horizonte" should find
      // "Belo Horizonte" ahead of anything that merely contains the letters.
      else if (key.includes(` ${q}`)) rank = Math.min(rank, 2);
      else if (key.includes(q)) rank = Math.min(rank, 3);
    }
    if (rank === Infinity) continue;
    scored.push({ row, rank });
  }

  scored.sort((a, b) => a.rank - b.rank || b.row[6] - a.row[6]);
  return scored.slice(0, limit).map((s) => toCity(s.row));
}

/** Exact resolve for a search request. `uf` disambiguates repeated names. */
export function resolveCity(name: string, uf: string): City | undefined {
  const n = normalise(name);
  const u = uf.toUpperCase().replace("BR-", "");
  const matches = ROWS.filter(
    (r) => r[1] === u && keysOf(r).some((k) => k === n),
  );
  if (matches.length === 0) return undefined;
  // Same name twice in one state: take the one with more businesses, which is
  // the municipality rather than the district inside it.
  matches.sort((a, b) => b[6] - a[6]);
  return toCity(matches[0]);
}

/** Totals for the landing page, so the tool states its own reach up front. */
export function indexSummary(): {
  cities: number;
  businesses: number;
  noSite: number;
} {
  let businesses = 0;
  let noSite = 0;
  for (const r of ROWS) {
    businesses += r[6];
    noSite += r[7];
  }
  return { cities: ROWS.length, businesses, noSite };
}
