import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // DuckDB ships a native binding (.node). Bundling it breaks `require`, so it
  // has to stay external and be loaded by Node itself. Neither package is on
  // Next's built-in opt-out list, so both must be named here.
  serverExternalPackages: ["@duckdb/node-api", "@duckdb/node-bindings"],
};

export default nextConfig;
