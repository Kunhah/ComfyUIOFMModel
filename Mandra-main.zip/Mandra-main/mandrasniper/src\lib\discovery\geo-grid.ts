export interface BoundingBox {
  xmin: number;
  xmax: number;
  ymin: number;
  ymax: number;
}

export interface GridCell {
  id: string;
  index: number;
  bbox: BoundingBox;
  center: { lat: number; lon: number };
  radiusKm: number;
}

/**
 * Splits a target BoundingBox or center coordinate into an N x N spatial grid.
 */
export function generateGeoGrid(
  bbox: BoundingBox,
  gridSize: 1 | 3 | 5 = 3
): GridCell[] {
  if (gridSize === 1) {
    return [
      {
        id: "grid-cell-1",
        index: 0,
        bbox,
        center: {
          lat: (bbox.ymin + bbox.ymax) / 2,
          lon: (bbox.xmin + bbox.xmax) / 2,
        },
        radiusKm: 10,
      },
    ];
  }

  const cells: GridCell[] = [];
  const lonStep = (bbox.xmax - bbox.xmin) / gridSize;
  const latStep = (bbox.ymax - bbox.ymin) / gridSize;

  let count = 0;
  for (let row = 0; row < gridSize; row++) {
    for (let col = 0; col < gridSize; col++) {
      const cellXmin = bbox.xmin + col * lonStep;
      const cellXmax = cellXmin + lonStep;
      const cellYmin = bbox.ymin + row * latStep;
      const cellYmax = cellYmin + latStep;

      count++;
      cells.push({
        id: `grid-cell-${count}`,
        index: count - 1,
        bbox: {
          xmin: cellXmin,
          xmax: cellXmax,
          ymin: cellYmin,
          ymax: cellYmax,
        },
        center: {
          lat: (cellYmin + cellYmax) / 2,
          lon: (cellXmin + cellXmax) / 2,
        },
        radiusKm: Math.max(3, Math.round(15 / gridSize)),
      });
    }
  }

  return cells;
}
