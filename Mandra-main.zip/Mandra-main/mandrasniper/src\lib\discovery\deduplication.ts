import type { Lead } from "@/types";

export interface DeduplicationResult {
  uniqueLeads: Lead[];
  duplicatesRemoved: number;
  duplicateLog: Array<{ candidate: string; matchedWith: string; reason: string }>;
}

function normalizeStr(s?: string | null): string {
  if (!s) return "";
  return s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "")
    .trim();
}

function extractDomain(url?: string | null): string | null {
  if (!url) return null;
  try {
    const cleanUrl = url.startsWith("http") ? url : `https://${url}`;
    const parsed = new URL(cleanUrl);
    return parsed.hostname.replace(/^www\./, "").toLowerCase();
  } catch {
    return null;
  }
}

/** Calculates string similarity ratio between 0 and 1 */
function stringSimilarity(a: string, b: string): number {
  if (a === b) return 1.0;
  if (!a || !b) return 0;
  
  const setA = new Set(a.split(""));
  const setB = new Set(b.split(""));
  const intersection = new Set([...setA].filter((x) => setB.has(x)));
  return (2 * intersection.size) / (setA.size + setB.size);
}

/**
 * Deduplicates raw candidate leads across multiple attributes while respecting
 * distinct branch locations.
 */
export function deduplicateLeads(candidates: Lead[]): DeduplicationResult {
  const uniqueLeads: Lead[] = [];
  const duplicateLog: Array<{ candidate: string; matchedWith: string; reason: string }> = [];

  for (const candidate of candidates) {
    const candNameNorm = normalizeStr(candidate.name);
    const candCityNorm = normalizeStr(candidate.city);
    const candPhoneDigits = candidate.phone ? candidate.phone.replace(/\D/g, "") : "";
    const candDomain = extractDomain(candidate.website);
    const candPlaceId = candidate.googlePlaceId;

    let isDuplicate = false;

    for (const existing of uniqueLeads) {
      const existNameNorm = normalizeStr(existing.name);
      const existCityNorm = normalizeStr(existing.city);
      const existPhoneDigits = existing.phone ? existing.phone.replace(/\D/g, "") : "";
      const existDomain = extractDomain(existing.website);
      const existPlaceId = existing.googlePlaceId;

      // 1. Google Place ID Match
      if (candPlaceId && existPlaceId && candPlaceId === existPlaceId) {
        isDuplicate = true;
        duplicateLog.push({
          candidate: candidate.name,
          matchedWith: existing.name,
          reason: `Place ID idêntico (${candPlaceId})`,
        });
        break;
      }

      // 2. Exact Phone Match (min 10 digits) in same city
      if (
        candPhoneDigits.length >= 10 &&
        existPhoneDigits.length >= 10 &&
        candPhoneDigits === existPhoneDigits
      ) {
        isDuplicate = true;
        duplicateLog.push({
          candidate: candidate.name,
          matchedWith: existing.name,
          reason: `Telefone comercial idêntico (${candPhoneDigits})`,
        });
        break;
      }

      // 3. Domain Match (excluding generic social domains)
      if (
        candDomain &&
        existDomain &&
        candDomain === existDomain &&
        !candDomain.includes("instagram.com") &&
        !candDomain.includes("facebook.com") &&
        !candDomain.includes("linktr.ee")
      ) {
        isDuplicate = true;
        duplicateLog.push({
          candidate: candidate.name,
          matchedWith: existing.name,
          reason: `Domínio de website idêntico (${candDomain})`,
        });
        break;
      }

      // 4. Name & City Similarity Match (only if same address/neighborhood)
      const isSameCity = candCityNorm === existCityNorm;
      const nameSim = stringSimilarity(candNameNorm, existNameNorm);
      const sameAddress = normalizeStr(candidate.address) === normalizeStr(existing.address);

      if (isSameCity && nameSim > 0.88 && sameAddress) {
        isDuplicate = true;
        duplicateLog.push({
          candidate: candidate.name,
          matchedWith: existing.name,
          reason: `Nome (${Math.round(nameSim * 100)}% similar) e endereço idênticos`,
        });
        break;
      }
    }

    if (!isDuplicate) {
      uniqueLeads.push(candidate);
    }
  }

  return {
    uniqueLeads,
    duplicatesRemoved: candidates.length - uniqueLeads.length,
    duplicateLog,
  };
}
