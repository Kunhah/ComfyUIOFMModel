"use client";

import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  Search,
  Download,
  Filter,
  SlidersHorizontal,
  ChevronLeft,
  ChevronRight,
  MessageCircle,
  Sparkles,
  Globe,
  Star,
  ShieldCheck,
  Target,
} from "lucide-react";
import type { Lead, LeadCrmStatus } from "@/types";
import { SmartListPills } from "@/components/smart-list-pills";
import { StatusPicker } from "@/components/status-picker";
import { OutreachPanel } from "@/components/outreach-panel";
import { outreachMessage, whatsappUrl } from "@/lib/score";

export default function LeadsPage() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters & State
  const [searchQuery, setSearchQuery] = useState("");
  const [activeSmartList, setActiveSmartList] = useState("ALL");
  const [cityFilter, setCityFilter] = useState("");
  const [nicheFilter, setNicheFilter] = useState("");
  const [minScoreFilter, setMinScoreFilter] = useState<number>(0);
  const [websiteFilter, setWebsiteFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Outreach drawer
  const [selectedLeadForOutreach, setSelectedLeadForOutreach] = useState<Lead | null>(null);

  const fetchLeads = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/leads");
      const data = await res.json();
      if (data.leads) {
        setLeads(data.leads);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLeads();
  }, []);

  // Filtered Leads Calculation
  const filteredLeads = useMemo(() => {
    let result = [...leads];

    // Smart list filtering
    if (activeSmartList === "SNIPER_LEADS") {
      result = result.filter((l) => l.sniperScore >= 90);
    } else if (activeSmartList === "HOT_LEADS") {
      result = result.filter((l) => l.sniperScore >= 75);
    } else if (activeSmartList === "SEM_SITE") {
      result = result.filter((l) => l.websiteStatus === "NO_WEBSITE" || !l.website);
    } else if (activeSmartList === "SITE_RUIM") {
      result = result.filter((l) => l.websiteStatus === "POOR_WEBSITE" || l.websiteStatus === "BROKEN_WEBSITE");
    } else if (activeSmartList === "INSTAGRAM_FORTE") {
      result = result.filter((l) => l.socialProfiles && l.socialProfiles.length > 0);
    } else if (activeSmartList === "WHATSAPP_DISPONIVEL") {
      result = result.filter((l) => l.phone && l.phone.length > 8);
    } else if (activeSmartList === "ALTA_REPUTACAO") {
      result = result.filter((l) => l.rating >= 4.8);
    } else if (activeSmartList === "ABORDAR_HOJE") {
      result = result.filter((l) => l.sniperScore >= 80 && l.crmStatus === "NOVO");
    }

    // Direct search input
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        (l) =>
          l.name.toLowerCase().includes(q) ||
          l.city.toLowerCase().includes(q) ||
          l.category.toLowerCase().includes(q)
      );
    }

    if (cityFilter) {
      result = result.filter((l) => l.city.toLowerCase().includes(cityFilter.toLowerCase()));
    }
    if (nicheFilter) {
      result = result.filter((l) => l.category.toLowerCase().includes(nicheFilter.toLowerCase()));
    }
    if (minScoreFilter > 0) {
      result = result.filter((l) => l.sniperScore >= minScoreFilter);
    }
    if (websiteFilter) {
      result = result.filter((l) => l.websiteStatus === websiteFilter);
    }
    if (statusFilter) {
      result = result.filter((l) => l.crmStatus === statusFilter);
    }

    return result.sort((a, b) => b.sniperScore - a.sniperScore);
  }, [
    leads,
    activeSmartList,
    searchQuery,
    cityFilter,
    nicheFilter,
    minScoreFilter,
    websiteFilter,
    statusFilter,
  ]);

  // Paginated leads
  const totalPages = Math.ceil(filteredLeads.length / pageSize) || 1;
  const paginatedLeads = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredLeads.slice(start, start + pageSize);
  }, [filteredLeads, currentPage, pageSize]);

  return (
    <div className="space-y-6 max-w-7xl">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-[#ECE8E0] pb-5">
        <div>
          <h1 className="text-2xl font-black text-[#1E2026] uppercase">
            Gestão & Inteligência de Leads
          </h1>
          <p className="mt-1 text-sm text-[#6E7381]">
            Base unificada com cálculo do Sniper Score, auditoria de website e origem de dados.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              const headers = "ID,Nome,Nicho,Cidade,UF,Score,Confianca,WebsiteStatus,WhatsApp,Rating,Reviews\n";
              const rows = filteredLeads.map(l => `"${l.id}","${l.name}","${l.category}","${l.city}","${l.state}",${l.sniperScore},"${l.confidenceLevel}","${l.websiteStatus}","${l.phone || ""}","${l.rating}","${l.reviewsCount}"`).join("\n");
              const blob = new Blob([headers + rows], { type: "text/csv" });
              const url = URL.createObjectURL(blob);
              const a = document.createElement("a");
              a.href = url;
              a.download = "mandra-sniper-leads.csv";
              a.click();
            }}
            className="flex items-center gap-2 rounded-xl border border-[#E2DDD3] bg-white px-4 py-2.5 text-xs font-bold text-[#1E2026] hover:bg-[#FAF8F4] transition shadow-2xs"
          >
            <Download className="size-4 text-[#6E7381]" />
            <span>Exportar CSV</span>
          </button>
        </div>
      </div>

      {/* Smart List Pills Bar */}
      <SmartListPills
        activeList={activeSmartList}
        onSelectList={(id) => {
          setActiveSmartList(id);
          setCurrentPage(1);
        }}
      />

      {/* Filter Toolbar */}
      <div className="rounded-2xl border border-[#ECE8E0] bg-white p-4 shadow-2xs space-y-3">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5 items-center">
          {/* Search Input */}
          <div className="relative lg:col-span-2">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-[#8E94A2]" />
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar por nome, cidade ou segmento..."
              className="w-full rounded-xl border border-[#E2DDD3] bg-[#FAF9F6] pl-9 pr-3 py-2 text-xs text-[#1E2026] outline-none focus:border-[#FF9E1B] focus:bg-white"
            />
          </div>

          {/* Website Status Filter */}
          <div>
            <select
              value={websiteFilter}
              onChange={(e) => setWebsiteFilter(e.target.value)}
              className="w-full rounded-xl border border-[#E2DDD3] bg-[#FAF9F6] px-3 py-2 text-xs text-[#1E2026] outline-none focus:border-[#FF9E1B] focus:bg-white"
            >
              <option value="">Todos os Websites</option>
              <option value="NO_WEBSITE">Sem Website</option>
              <option value="SOCIAL_ONLY">Apenas Rede Social</option>
              <option value="POOR_WEBSITE">Website Ruim</option>
              <option value="GOOD_WEBSITE">Website Bom</option>
            </select>
          </div>

          {/* CRM Status Filter */}
          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full rounded-xl border border-[#E2DDD3] bg-[#FAF9F6] px-3 py-2 text-xs text-[#1E2026] outline-none focus:border-[#FF9E1B] focus:bg-white"
            >
              <option value="">Todos os Status CRM</option>
              <option value="NOVO">Novo</option>
              <option value="QUALIFICADO">Qualificado</option>
              <option value="CONTATADO">Contatado</option>
              <option value="RESPONDEU">Respondeu</option>
              <option value="GANHO">Ganho</option>
            </select>
          </div>

          {/* Clear Filters */}
          <div className="flex justify-end">
            <button
              onClick={() => {
                setSearchQuery("");
                setCityFilter("");
                setNicheFilter("");
                setMinScoreFilter(0);
                setWebsiteFilter("");
                setStatusFilter("");
                setActiveSmartList("ALL");
              }}
              className="text-xs font-bold text-[#FF9E1B] hover:underline"
            >
              Limpar Filtros
            </button>
          </div>
        </div>
      </div>

      {/* Main Table */}
      <div className="rounded-2xl border border-[#ECE8E0] bg-white shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#ECE8E0] bg-[#FAF8F4] text-[#6E7381] font-extrabold uppercase tracking-wider">
                <th className="px-4 py-3.5">Sniper Score</th>
                <th className="px-4 py-3.5">Confidence</th>
                <th className="px-4 py-3.5">Empresa</th>
                <th className="px-4 py-3.5">Cidade</th>
                <th className="px-4 py-3.5">Website</th>
                <th className="px-4 py-3.5">WhatsApp / Fone</th>
                <th className="px-4 py-3.5">Google Rating</th>
                <th className="px-4 py-3.5">CRM Status</th>
                <th className="px-4 py-3.5 text-right">Ação SDR</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#ECE8E0]">
              {paginatedLeads.map((lead) => (
                <tr key={lead.id} className="hover:bg-[#FAF8F4] transition">
                  {/* Score */}
                  <td className="px-4 py-3.5">
                    <span className="inline-block rounded-lg bg-[#FF9E1B]/15 px-2.5 py-1 text-xs font-black text-[#FF9E1B] border border-[#FF9E1B]/30 tnum">
                      {lead.sniperScore}
                    </span>
                  </td>

                  {/* Data Confidence */}
                  <td className="px-4 py-3.5">
                    <span
                      className={`inline-block rounded-md px-2 py-0.5 text-[10px] font-extrabold uppercase ${
                        lead.confidenceLevel === "HIGH"
                          ? "bg-emerald-500/15 text-emerald-700 border border-emerald-500/30"
                          : lead.confidenceLevel === "MEDIUM"
                          ? "bg-amber-500/15 text-amber-700 border border-amber-500/30"
                          : "bg-gray-500/15 text-gray-700 border border-gray-500/30"
                      }`}
                    >
                      {lead.confidenceLevel}
                    </span>
                  </td>

                  {/* Empresa */}
                  <td className="px-4 py-3.5">
                    <Link href={`/leads/${lead.id}`} className="font-extrabold text-[#1E2026] text-sm hover:underline">
                      {lead.name}
                    </Link>
                    <div className="text-[11px] text-[#6E7381]">{lead.category}</div>
                  </td>

                  {/* Cidade */}
                  <td className="px-4 py-3.5 text-[#1E2026] font-medium">
                    {lead.city}, {lead.state}
                  </td>

                  {/* Website */}
                  <td className="px-4 py-3.5">
                    {lead.websiteStatus === "NO_WEBSITE" || !lead.website ? (
                      <span className="font-bold text-[#FF9E1B]">Sem Website</span>
                    ) : (
                      <a href={lead.website} target="_blank" rel="noreferrer" className="text-blue-600 font-semibold hover:underline">
                        {lead.websiteStatus}
                      </a>
                    )}
                  </td>

                  {/* WhatsApp */}
                  <td className="px-4 py-3.5">
                    {lead.phone ? (
                      <a
                        href={whatsappUrl(lead.phone, outreachMessage(lead)) ?? `tel:${lead.phone}`}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 font-semibold text-emerald-700 hover:underline"
                      >
                        <MessageCircle className="size-3.5 text-[#25D366]" />
                        <span>{lead.phone}</span>
                      </a>
                    ) : (
                      <span className="text-gray-400">Sem telefone</span>
                    )}
                  </td>

                  {/* Google Rating */}
                  <td className="px-4 py-3.5 text-[#1E2026] font-bold">
                    ⭐ {lead.rating.toFixed(1)} ({lead.reviewsCount})
                  </td>

                  {/* CRM Status Picker */}
                  <td className="px-4 py-3.5">
                    <StatusPicker id={lead.id} status={lead.crmStatus} />
                  </td>

                  {/* Action */}
                  <td className="px-4 py-3.5 text-right">
                    <button
                      onClick={() => setSelectedLeadForOutreach(lead)}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-[#1C1F26] px-3 py-1.5 text-xs font-bold text-white hover:bg-[#2A2E38] transition"
                    >
                      <Sparkles className="size-3 text-[#FF9E1B]" />
                      <span>Abordar</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Table Pagination */}
        <div className="flex flex-wrap items-center justify-between gap-4 px-5 py-4 border-t border-[#ECE8E0] bg-[#FAF8F4] text-xs text-[#6E7381]">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="flex size-7 items-center justify-center rounded-lg border border-[#E2DDD3] bg-white text-gray-600 disabled:opacity-40"
            >
              <ChevronLeft className="size-4" />
            </button>
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => i + 1).map((p) => (
              <button
                key={p}
                onClick={() => setCurrentPage(p)}
                className={`flex size-7 items-center justify-center rounded-lg font-bold transition ${
                  currentPage === p ? "bg-[#1C1F26] text-white" : "border border-[#E2DDD3] bg-white text-gray-700"
                }`}
              >
                {p}
              </button>
            ))}
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="flex size-7 items-center justify-center rounded-lg border border-[#E2DDD3] bg-white text-gray-600 disabled:opacity-40"
            >
              <ChevronRight className="size-4" />
            </button>
          </div>

          <div>
            Mostrando {filteredLeads.length === 0 ? 0 : (currentPage - 1) * pageSize + 1} a{" "}
            {Math.min(currentPage * pageSize, filteredLeads.length)} de {filteredLeads.length} leads
          </div>
        </div>
      </div>

      {/* Outreach Drawer */}
      <OutreachPanel
        lead={selectedLeadForOutreach}
        open={Boolean(selectedLeadForOutreach)}
        onClose={() => setSelectedLeadForOutreach(null)}
      />
    </div>
  );
}
