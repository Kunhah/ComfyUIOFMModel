# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all
differ from your training data. Read the relevant guide in
`node_modules/next/dist/docs/` before writing any code. Heed deprecation notices.

# Prospector specifics

- **DuckDB is a native module.** Route handlers that touch it must declare
  `export const runtime = "nodejs"`, and both `@duckdb/node-api` and
  `@duckdb/node-bindings` must stay in `serverExternalPackages` (next.config.ts).
  Bundling them breaks `require` of the `.node` binary.
- **The platform binding is an optionalDependency.** If `@duckdb/node-api` throws
  `MODULE_NOT_FOUND` on `duckdb.node`, npm skipped the per-platform package —
  check `optionalDependencies` in package.json covers your platform.
- **Never invent an Overture category string.** They come from
  `src/data/overture-categories.csv`. An unknown category matches nothing and
  fails silently, which reads as "no businesses in this city".
- **After changing `src/lib/niches.ts`, re-run `npm run sync` then `npm run cities`.**
  New categories are not in the existing extract, and the city index and its
  counts are derived from the extract.
- **Aggregate stats belong in SQL, not in JS over the returned rows.** The result
  set is capped by `limit`; counting it reports the limit back as the pool size.
- **`normalise()` in `src/lib/cities.ts` and `nrm()` in `src/lib/overture.ts` must
  fold identically** (case, accents, punctuation), and `build-city-index.mjs` has
  a third copy as a SQL macro. If they drift, a city resolves in the picker and
  then returns zero rows — which reads as "no businesses here".
- **The city index is derived from the extract, never from Overture's division
  boundaries.** Boundary names that no business uses are unsearchable by
  definition; that is how Brasília's 7,283 businesses were invisible. Divisions
  supply display spelling only.
- **Don't fuzzy-match city names.** It was tried and reverted: 13 of 19 generated
  pairs joined different municipalities. `ALIASES` in `build-city-index.mjs` is
  hand-written on purpose.
- **`country = 'BR'` in the sync is required, not redundant** with the bounding
  box — the box covers seven neighbouring countries.
- **History is SQLite via `node:sqlite`** (`src/lib/db.ts`), a Node builtin — no
  dependency and nothing for `serverExternalPackages`. Don't add `better-sqlite3`
  or an ORM. The API is synchronous by design; `persistLeads` is not async.
- **Watch backticks inside the SQL template literals in `db.ts`.** A backtick in a
  comment inside the schema string terminates the literal and the parse error
  points at the SQL, not at the quote.
- **Only _additive_ schema changes reach an existing `data/prospector.db`**, and
  only via `addMissingColumns()`. The table DDL itself is
  `CREATE TABLE IF NOT EXISTS`, so renames, type changes and constraint changes
  need the file deleted.
- **`/` writes the history, `/historico` reads it.** Search results are persisted
  by `performSearch`, so any new discovery path must go through it or its leads
  never reach the history.
- **Indexes are applied after `addMissingColumns()` in `db.ts`, not with the table.**
  `CREATE INDEX` on a column an older database lacks throws, which aborts the whole
  schema statement before the column can be added — the table then stays a
  migration behind and every search fails with "no such column".
- **Column changes need an entry in `addMissingColumns()`**, additive only. People
  are told they can keep the `.db` file, so a new column must not break it.
- **CSV columns live in `src/lib/csv.ts`**, shared by the board export and the
  history export. Don't add columns to a route handler.
- **`scripts/start.mjs` is the entry point people actually use** (`npm run up`,
  `npm run prospector`). Any new setup step belongs in its checks, or a fresh clone
  silently starts half-configured.
- **It launches Next by resolving `next/dist/bin/next`, not via `npm run dev`** —
  the dev script hardcodes `--port 3001`, so going through npm produced a duplicated
  `--port` the moment one was passed.
- **A lead's niche comes from `nicheForCategory(category)`, never from the search.**
  Storing the search's niche made the value depend on which search ran last, and
  every re-search overwrote it.
- **`niches.ts` throws at import if a category is in two niches.** That is
  deliberate — `nail_salon` sat in two for a while and silently corrupted every
  per-niche count. Don't catch it; fix the registry.
- **Regrouping existing categories needs no re-sync**; `reniche()` in `db.ts`
  rebuilds stored niches from category when `nicheFingerprint()` changes. Adding a
  category that isn't in the extract does need `npm run sync`.
