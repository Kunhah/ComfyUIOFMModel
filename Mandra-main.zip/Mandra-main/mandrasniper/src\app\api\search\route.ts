import { hasLocalExtract } from "@/lib/overture";
import { performSearch } from "@/lib/search";
import { historyCount } from "@/lib/db";
import type { SearchRequest } from "@/lib/types";

// DuckDB is a native module, so this can't run on the edge runtime.
export const runtime = "nodejs";
// A search against the local extract is well under a second, but the S3 fallback
// can take minutes on first use; don't let the platform kill it mid-scan.
export const maxDuration = 300;

export async function POST(request: Request): Promise<Response> {
  let body: SearchRequest;
  try {
    body = (await request.json()) as SearchRequest;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const outcome = await performSearch(body);
  if (!outcome.ok) {
    return Response.json({ error: outcome.error }, { status: outcome.status });
  }
  return Response.json(outcome.response);
}

/** Lets the UI show whether the fast path is available and how much history exists. */
export async function GET(): Promise<Response> {
  return Response.json({
    localExtract: hasLocalExtract(),
    history: historyCount(),
  });
}
