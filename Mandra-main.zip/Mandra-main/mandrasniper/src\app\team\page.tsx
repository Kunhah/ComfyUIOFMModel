"use client";

import React, { useState } from "react";
import { UserPlus, Sparkles, RefreshCw, Copy, ShieldCheck, Mail, Phone, MapPin, Award } from "lucide-react";
import type { SellerProfile } from "@/types";
import { AddSellerModal } from "@/components/add-seller-modal";

const INITIAL_SELLERS: SellerProfile[] = [
  {
    id: "seller-1",
    name: "Guilherme Santos",
    email: "guilherme@mandra.ai",
    phone: "(19) 99881-2233",
    role: "SDR",
    region: "Campinas, SP",
    mainOffer: "Landing Page de Agendamento",
    dailyContactGoal: 20,
    onboardingStatus: "COMPLETO",
    onboardingCompleted: true,
    assignedLeadsCount: 45,
    completedContactsToday: 14,
    dealsClosedCount: 3,
    createdAt: "2026-08-01T10:00:00Z",
  },
  {
    id: "seller-2",
    name: "Lucas Oliveira",
    email: "lucas@mandra.ai",
    phone: "(15) 99712-4455",
    role: "SDR",
    region: "Sorocaba, SP",
    mainOffer: "Otimização Google Meu Negócio",
    dailyContactGoal: 25,
    onboardingStatus: "EM_ANDAMENTO",
    onboardingCompleted: false,
    assignedLeadsCount: 30,
    completedContactsToday: 8,
    dealsClosedCount: 1,
    createdAt: "2026-08-10T14:00:00Z",
  },
  {
    id: "seller-3",
    name: "Ana Beatriz",
    email: "ana@mandra.ai",
    phone: "(11) 98822-1100",
    role: "CLOSER",
    region: "São Paulo, SP",
    mainOffer: "Automação CRM & WhatsApp",
    dailyContactGoal: 15,
    onboardingStatus: "COMPLETO",
    onboardingCompleted: true,
    assignedLeadsCount: 60,
    completedContactsToday: 12,
    dealsClosedCount: 5,
    createdAt: "2026-07-15T09:00:00Z",
  },
];

export default function TeamPage() {
  const [sellers, setSellers] = useState<SellerProfile[]>(INITIAL_SELLERS);
  const [showAddModal, setShowAddModal] = useState(false);

  const handleAddSeller = (newSeller: SellerProfile) => {
    setSellers((prev) => [newSeller, ...prev]);
  };

  const handleResetOnboarding = (id: string) => {
    setSellers((prev) =>
      prev.map((s) => (s.id === id ? { ...s, onboardingStatus: "NÃO_INICIADO", onboardingCompleted: false } : s))
    );
  };

  return (
    <div className="space-y-8 max-w-6xl">
      {/* Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between border-b border-[#ECE8E0] pb-4">
        <div>
          <div className="inline-flex items-center gap-2 rounded-lg bg-[#FF9E1B]/15 px-3 py-1 text-xs font-extrabold text-[#FF9E1B] border border-[#FF9E1B]/30 mb-2">
            <Sparkles className="size-3.5" />
            <span>MANDRA TEAM & SELLER ONBOARDING</span>
          </div>
          <h1 className="text-3xl font-black text-[#1E2026] uppercase">
            EQUIPE DE VENDAS & ONBOARDING
          </h1>
          <p className="mt-1 text-sm text-[#6E7381]">
            Gerencie vendedores, ofertas atribuídas, metas diárias e acompanhe o status de onboarding guiado.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 rounded-2xl bg-[#1C1F26] px-5 py-3.5 text-xs font-bold text-white hover:bg-[#2A2E38] transition shadow-md"
        >
          <UserPlus className="size-4 text-[#FF9E1B]" />
          <span>ADICIONAR NOVO VENDEDOR</span>
        </button>
      </div>

      {/* Seller Team Table */}
      <div className="rounded-2xl border border-[#ECE8E0] bg-white shadow-2xs overflow-hidden space-y-4 p-5">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-extrabold text-[#1E2026]">Vendedores Cadastrados ({sellers.length})</h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#ECE8E0] bg-[#FAF8F4] text-[#6E7381] font-bold uppercase">
                <th className="px-4 py-3">Vendedor</th>
                <th className="px-4 py-3">Cargo / Role</th>
                <th className="px-4 py-3">Oferta & Região</th>
                <th className="px-4 py-3">Meta Diária</th>
                <th className="px-4 py-3">Onboarding Status</th>
                <th className="px-4 py-3 text-right">Ações Admin</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#ECE8E0]">
              {sellers.map((s) => (
                <tr key={s.id} className="hover:bg-[#FAF8F4] transition">
                  <td className="px-4 py-3.5">
                    <div className="font-extrabold text-[#1E2026] text-sm">{s.name}</div>
                    <div className="text-[11px] text-[#6E7381]">{s.email}</div>
                  </td>
                  <td className="px-4 py-3.5">
                    <span className="rounded-md bg-[#1C1F26] text-white px-2 py-1 text-[10px] font-black uppercase">
                      {s.role}
                    </span>
                  </td>
                  <td className="px-4 py-3.5">
                    <div className="font-bold text-[#1E2026]">{s.mainOffer}</div>
                    <div className="text-[11px] text-[#6E7381]">{s.region}</div>
                  </td>
                  <td className="px-4 py-3.5 text-[#1E2026] font-bold tnum">
                    {s.completedContactsToday} / {s.dailyContactGoal} contatos
                  </td>
                  <td className="px-4 py-3.5">
                    {s.onboardingStatus === "COMPLETO" ? (
                      <span className="rounded-md bg-emerald-500/15 text-emerald-700 px-2 py-0.5 text-[10px] font-black uppercase">
                        COMPLETO
                      </span>
                    ) : s.onboardingStatus === "EM_ANDAMENTO" ? (
                      <span className="rounded-md bg-amber-500/15 text-amber-800 px-2 py-0.5 text-[10px] font-black uppercase">
                        EM ANDAMENTO
                      </span>
                    ) : (
                      <span className="rounded-md bg-gray-200 text-gray-700 px-2 py-0.5 text-[10px] font-black uppercase">
                        NÃO INICIADO
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3.5 text-right space-x-2">
                    <button
                      onClick={() => handleResetOnboarding(s.id)}
                      className="inline-flex items-center gap-1 rounded-xl border border-[#E2DDD3] bg-white px-3 py-1.5 text-xs font-bold text-[#1E2026] hover:bg-[#FAF8F4]"
                    >
                      <RefreshCw className="size-3 text-[#FF9E1B]" />
                      <span>Resetar Onboarding</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Seller Modal */}
      <AddSellerModal
        open={showAddModal}
        onClose={() => setShowAddModal(false)}
        onAddSeller={handleAddSeller}
        existingSellers={sellers}
      />
    </div>
  );
}
