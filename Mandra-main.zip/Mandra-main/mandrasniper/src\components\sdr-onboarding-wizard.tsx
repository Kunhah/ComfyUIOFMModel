"use client";

import React, { useState } from "react";
import { Sparkles, Target, MapPin, Globe, ArrowRight, Check, X, Building2, Flame, ShieldCheck } from "lucide-react";
import { useRouter } from "next/navigation";

export function SdrOnboardingWizard({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const router = useRouter();
  const [step, setStep] = useState(1);

  // Wizard Selections
  const [offer, setOffer] = useState("Landing Page de Agendamento");
  const [niche, setNiche] = useState("Estética");
  const [city, setCity] = useState("Campinas, SP");
  const [opportunity, setOpportunity] = useState("Sem site próprio");

  if (!open) return null;

  const handleFinish = () => {
    onClose();
    const queryStr = `${niche} em ${city} com prioridade ${opportunity} para oferecer ${offer}`;
    router.push(`/prospecting?prompt=${encodeURIComponent(queryStr)}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4">
      <div className="w-full max-w-xl rounded-3xl border border-[#ECE8E0] bg-white p-7 text-[#1E2026] shadow-2xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#ECE8E0] pb-4">
          <div className="flex items-center gap-3">
            <div className="flex size-10 items-center justify-center rounded-2xl bg-[#1C1F26] text-[#FF9E1B]">
              <Sparkles className="size-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-[#1E2026]">
                BEM-VINDO AO MANDRA SNIPER AI
              </h2>
              <p className="text-xs text-[#6E7381]">
                Passo {step} de 5 — Configure sua primeira prospecção guiada
              </p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-gray-400 hover:bg-gray-100">
            <X className="size-5" />
          </button>
        </div>

        {/* STEP 1: O QUE VOCÊ QUER VENDER? */}
        {step === 1 && (
          <div className="space-y-4">
            <h3 className="font-extrabold text-base text-[#1E2026]">1. O que você quer vender?</h3>
            <div className="grid grid-cols-2 gap-2.5 text-xs font-bold">
              {[
                "Landing Page de Agendamento",
                "Website Institucional",
                "Otimização Google Meu Negócio",
                "Automação CRM & WhatsApp",
                "Gestão de Social Media",
              ].map((item) => (
                <button
                  key={item}
                  onClick={() => setOffer(item)}
                  className={`rounded-2xl border p-3.5 text-left transition ${
                    offer === item
                      ? "border-[#FF9E1B] bg-[#FFF5E6] text-[#FF9E1B]"
                      : "border-[#ECE8E0] bg-[#FAF9F6] text-[#1E2026] hover:bg-white"
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* STEP 2: PARA QUEM VOCÊ QUER VENDER? */}
        {step === 2 && (
          <div className="space-y-4">
            <h3 className="font-extrabold text-base text-[#1E2026]">2. Para quem você quer vender?</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-bold">
              {[
                "Estética",
                "Dentistas",
                "Barbearias",
                "Restaurantes",
                "Academias",
                "Imobiliárias",
                "Oficinas",
                "Pet Shops",
              ].map((item) => (
                <button
                  key={item}
                  onClick={() => setNiche(item)}
                  className={`rounded-2xl border p-3 text-center transition ${
                    niche === item
                      ? "border-[#FF9E1B] bg-[#FFF5E6] text-[#FF9E1B]"
                      : "border-[#ECE8E0] bg-[#FAF9F6] text-[#1E2026] hover:bg-white"
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* STEP 3: ONDE VOCÊ QUER PROSPECTAR? */}
        {step === 3 && (
          <div className="space-y-4">
            <h3 className="font-extrabold text-base text-[#1E2026]">3. Onde você quer prospectar?</h3>
            <input
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="Digite a cidade e estado (ex: Campinas, SP)"
              className="w-full rounded-2xl border border-[#E2DDD3] bg-[#FAF9F6] p-4 text-sm font-bold text-[#1E2026] outline-none focus:border-[#FF9E1B]"
            />
          </div>
        )}

        {/* STEP 4: TIPO DE OPORTUNIDADE */}
        {step === 4 && (
          <div className="space-y-4">
            <h3 className="font-extrabold text-base text-[#1E2026]">4. Qual tipo de oportunidade você procura?</h3>
            <div className="grid gap-2 text-xs font-bold">
              {[
                "🔥 Sem site próprio (Maior Oportunidade)",
                "💀 Website antigo / ruim",
                "📱 Instagram forte com site fraco",
                "⭐ Muitas avaliações no Google",
                "📞 WhatsApp disponível para contato",
              ].map((item) => (
                <button
                  key={item}
                  onClick={() => setOpportunity(item)}
                  className={`rounded-2xl border p-3.5 text-left transition ${
                    opportunity === item
                      ? "border-[#FF9E1B] bg-[#FFF5E6] text-[#FF9E1B]"
                      : "border-[#ECE8E0] bg-[#FAF9F6] text-[#1E2026] hover:bg-white"
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* STEP 5: RESUMO E AÇÃO */}
        {step === 5 && (
          <div className="space-y-4">
            <h3 className="font-extrabold text-base text-[#1E2026]">5. Resumo da sua prospecção guiada:</h3>
            <div className="rounded-2xl border border-[#ECE8E0] bg-[#FAF8F4] p-4 text-xs space-y-2">
              <div><strong>Serviço:</strong> {offer}</div>
              <div><strong>Nicho:</strong> {niche}</div>
              <div><strong>Cidade:</strong> {city}</div>
              <div><strong>Prioridade:</strong> {opportunity}</div>
            </div>
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="flex items-center justify-between border-t border-[#ECE8E0] pt-4">
          {step > 1 ? (
            <button
              onClick={() => setStep((s) => s - 1)}
              className="rounded-xl border border-[#E2DDD3] bg-white px-4 py-2.5 text-xs font-bold text-[#1E2026] hover:bg-[#FAF8F4]"
            >
              Voltar
            </button>
          ) : (
            <div />
          )}

          {step < 5 ? (
            <button
              onClick={() => setStep((s) => s + 1)}
              className="flex items-center gap-2 rounded-2xl bg-[#1C1F26] px-6 py-3 text-xs font-bold text-white hover:bg-[#2A2E38] transition"
            >
              <span>Próximo Passo</span>
              <ArrowRight className="size-4" />
            </button>
          ) : (
            <button
              onClick={handleFinish}
              className="flex items-center gap-2 rounded-2xl bg-[#FF9E1B] px-7 py-3.5 text-xs font-black text-[#101216] hover:bg-[#F08E0B] transition shadow-md"
            >
              <Sparkles className="size-4" />
              <span>ENCONTRAR MEUS PRIMEIROS LEADS</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
