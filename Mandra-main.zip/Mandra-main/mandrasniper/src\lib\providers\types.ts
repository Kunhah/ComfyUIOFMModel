import type { Lead, ProviderStatus, WebsiteStatus } from "@/types";

export interface ProviderResult<T> {
  status: ProviderStatus;
  data: T | null;
  message?: string;
  isDemo?: boolean;
}

export interface GooglePlaceRecord {
  placeId: string;
  name: string;
  category: string;
  address: string;
  city: string;
  state: string;
  phone: string | null;
  website: string | null;
  rating: number;
  reviewsCount: number;
  mapsUrl: string;
  coordinates: { lat: number; lon: number };
}

export interface InstagramProfileRecord {
  username: string;
  url: string;
  followersCount: number;
  isActive: boolean;
  lastPostAt?: string;
  bioText?: string;
}

export interface WebsiteAuditRecord {
  url: string;
  statusCode: number;
  hasHttps: boolean;
  isResponsive: boolean;
  title: string | null;
  metaDescription: string | null;
  hasCta: boolean;
  hasWhatsapp: boolean;
  hasForm: boolean;
  hasSocialLinks: boolean;
  performanceScore: number;
  seoScore: number;
  websiteScore: number;
  status: WebsiteStatus;
}

export interface GooglePlacesProvider {
  searchPlaces(
    niche: string,
    location: string,
    radiusKm: number,
    limit: number
  ): Promise<ProviderResult<GooglePlaceRecord[]>>;
}

export interface InstagramProvider {
  getProfile(urlOrUsername: string): Promise<ProviderResult<InstagramProfileRecord>>;
}

export interface WebsiteAnalyzerProvider {
  analyzeWebsite(url: string | null): Promise<ProviderResult<WebsiteAuditRecord>>;
}

export interface EnrichmentEngine {
  enrichLead(rawRecord: GooglePlaceRecord): Promise<Lead>;
}
