import { normalisePhone, outreachMessage, whatsappUrl } from "./score";
import type { ScoredLead, StoredLead } from "./types";

/**
 * Either kind of row. The board exports plain scored leads; the history export
 * adds the stored bookkeeping columns, so the getters have to tolerate both.
 */
type ExportLead = ScoredLead & Partial<Omit<StoredLead, keyof ScoredLead>>;

/**
 * One CSV writer, shared by the board export (rows posted back from the browser)
 * and the history export (rows read straight out of SQLite). They produced the
 * same file by coincidence when the column list lived inside the route handler;
 * this is what makes that a guarantee.
 */

/**
 * Columns are typed so numbers stay numbers. The formula-injection guard below
 * prefixes a value with an apostrophe, which is right for free text but turns a
 * coordinate or a score into a text cell you then can't sort or chart.
 */
type Column = {
  header: string;
  kind: "text" | "number";
  get: (lead: ExportLead) => string;
};

const COLUMNS: Column[] = [
  { header: "nome", kind: "text", get: (l) => l.name },
  { header: "categoria", kind: "text", get: (l) => l.category ?? "" },
  { header: "endereco", kind: "text", get: (l) => l.address ?? "" },
  { header: "cidade", kind: "text", get: (l) => l.city ?? "" },
  { header: "uf", kind: "text", get: (l) => l.uf ?? "" },
  // E.164 digits with no leading "+". The plus makes Excel read the cell as a
  // formula, and the usual apostrophe fix leaves a visible quote in every other
  // tool. Digits are unambiguous, sort cleanly, and paste straight into a dialer.
  {
    header: "telefone",
    kind: "text",
    get: (l) => normalisePhone(l.phone) ?? "",
  },
  {
    header: "whatsapp",
    kind: "text",
    get: (l) => (l.whatsapp ? "sim" : "nao"),
  },
  // The actually useful artefact: click it and the conversation is open with the
  // pt-BR opener already typed.
  {
    header: "whatsapp_link",
    kind: "text",
    get: (l) => whatsappUrl(l.phone, outreachMessage(l)) ?? "",
  },
  { header: "site", kind: "text", get: (l) => l.website ?? "" },
  { header: "rede_social", kind: "text", get: (l) => l.social ?? "" },
  { header: "email", kind: "text", get: (l) => l.email ?? "" },
  { header: "score", kind: "number", get: (l) => String(l.score) },
  { header: "sinais", kind: "text", get: (l) => (l.reasons ?? []).join("; ") },
  {
    header: "confianca",
    kind: "number",
    get: (l) =>
      typeof l.confidence === "number" ? l.confidence.toFixed(3) : "",
  },
  {
    header: "latitude",
    kind: "number",
    get: (l) => (l.lat === null ? "" : String(l.lat)),
  },
  {
    header: "longitude",
    kind: "number",
    get: (l) => (l.lon === null ? "" : String(l.lon)),
  },
  { header: "overture_id", kind: "text", get: (l) => l.id },
];

/**
 * Extra columns for the history export — the outreach state, which only exists
 * for rows that came out of the database.
 */
const HISTORY_COLUMNS: Column[] = [
  { header: "status", kind: "text", get: (l) => l.status ?? "" },
  { header: "primeiro_visto", kind: "text", get: (l) => l.firstSeenAt ?? "" },
  { header: "ultimo_visto", kind: "text", get: (l) => l.lastSeenAt ?? "" },
  { header: "nicho_busca", kind: "text", get: (l) => l.niche ?? "" },
];

export function buildCsv(
  leads: ExportLead[],
  options: { includeHistory?: boolean } = {},
): string {
  const columns = options.includeHistory
    ? [...COLUMNS, ...HISTORY_COLUMNS]
    : COLUMNS;

  const lines = [
    columns.map((c) => quote(c.header)).join(","),
    ...leads.map((lead) =>
      columns
        .map((c) => {
          const value = c.get(lead) ?? "";
          // Numbers are ours, never user text — emit bare so spreadsheets type them.
          return c.kind === "number" ? value : quote(guard(value));
        })
        .join(","),
    ),
  ];

  // Excel in a pt-BR locale won't detect UTF-8 without a BOM and mangles every
  // accented business name. The BOM is what makes the export usable there.
  return "\ufeff" + lines.join("\r\n");
}

export function csvResponse(
  leads: ExportLead[],
  filename: string,
  options: { includeHistory?: boolean } = {},
): Response {
  return new Response(buildCsv(leads, options), {
    headers: {
      "content-type": "text/csv; charset=utf-8",
      "content-disposition": `attachment; filename="${safeFilename(filename)}.csv"`,
    },
  });
}

export function safeFilename(name: string): string {
  return (
    name
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-zA-Z0-9._-]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 80) || "leads"
  );
}

/**
 * A leading =, +, - or @ makes Excel and Sheets evaluate the cell as a formula.
 * A business genuinely named "+55 Barbearia" would otherwise execute rather than
 * display. Only applied to text columns.
 */
function guard(value: string): string {
  return /^[=+\-@\t\r]/.test(value) ? `'${value}` : value;
}

function quote(value: string): string {
  return `"${value.replace(/"/g, '""')}"`;
}
