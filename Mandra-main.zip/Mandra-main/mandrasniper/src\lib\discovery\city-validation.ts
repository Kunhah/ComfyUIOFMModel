import { normalise } from "@/lib/cities";
import type { BoundingBox } from "./geo-grid";

export type CityMatchStatus =
  | "EXACT_CITY_MATCH"
  | "NEARBY_CITY"
  | "OUTSIDE_TARGET_CITY"
  | "INVALID_LOCATION";

export interface CityValidationResult {
  status: CityMatchStatus;
  detectedCity: string;
  detectedState: string;
  isExactMatch: boolean;
  confidence: "HIGH" | "MEDIUM" | "LOW";
  rejectionReason?: "OUTSIDE_TARGET_CITY" | "CITY_MISMATCH" | "LOCATION_UNVERIFIED";
}

/**
 * Parses address components from raw formatted address string.
 */
export function parseAddressComponents(addressStr?: string | null): {
  city: string | null;
  uf: string | null;
  neighborhood: string | null;
} {
  if (!addressStr || addressStr.trim().length === 0) {
    return { city: null, uf: null, neighborhood: null };
  }

  // Example: "Av. Jundiaí, 1000 - Anhangabaú, Jundiaí - SP, 13208-051"
  const parts = addressStr.split(/[-–,]+/);
  let detectedUf: string | null = null;
  let detectedCity: string | null = null;

  for (let i = parts.length - 1; i >= 0; i--) {
    const part = parts[i].trim();
    const ufMatch = part.match(/\b([A-Z]{2})\b/);
    if (ufMatch && !detectedUf) {
      detectedUf = ufMatch[1];
    }
  }

  // Look for city segment before UF
  for (let i = 0; i < parts.length; i++) {
    const part = parts[i].trim();
    if (part.length > 2 && !part.match(/^\d+$/) && !part.includes("Brasil")) {
      if (!detectedCity && i >= 1) {
        detectedCity = part;
      }
    }
  }

  return {
    city: detectedCity,
    uf: detectedUf,
    neighborhood: parts[1]?.trim() || null,
  };
}

export class CityValidationEngine {
  /**
   * Validates whether a candidate business belongs EXACTLY to the target municipality.
   */
  public validateCandidateLocation(
    candidateAddress?: string | null,
    candidateCity?: string | null,
    candidateState?: string | null,
    candidateLat?: number | null,
    candidateLon?: number | null,
    targetCity: string = "Jundiaí",
    targetState: string = "SP",
    targetBbox?: BoundingBox
  ): CityValidationResult {
    const targetNorm = normalise(targetCity);
    const targetStateNorm = targetState.toLowerCase().trim();

    const fullAddr = `${candidateAddress || ""} ${candidateCity || ""}`.toLowerCase();
    const normAddr = normalise(fullAddr);

    // 1. Check if coordinates sit inside municipal bounding box
    let insideBbox = false;
    if (candidateLat && candidateLon && targetBbox) {
      insideBbox =
        candidateLat >= targetBbox.ymin &&
        candidateLat <= targetBbox.ymax &&
        candidateLon >= targetBbox.xmin &&
        candidateLon <= targetBbox.xmax;
    }

    // 2. Extract city from candidate city or address string
    const parsed = parseAddressComponents(candidateAddress);
    const candidateCityNorm = normalise(candidateCity || parsed.city || "");

    // Detect if candidate is explicitly from a distant major city like São Paulo capital
    const isSaoPauloCapital =
      normAddr.includes("sao paulo sp") ||
      normAddr.includes("sao paulo, sp") ||
      candidateCityNorm === "sao paulo";

    const isTargetSaoPaulo = targetNorm === "sao paulo";

    // 3. Strict Discard: If target is Jundiaí and candidate is in São Paulo capital
    if (!isTargetSaoPaulo && isSaoPauloCapital) {
      return {
        status: "OUTSIDE_TARGET_CITY",
        detectedCity: "São Paulo",
        detectedState: "SP",
        isExactMatch: false,
        confidence: "HIGH",
        rejectionReason: "OUTSIDE_TARGET_CITY",
      };
    }

    // 4. Exact City Name Match
    if (
      candidateCityNorm === targetNorm ||
      normAddr.includes(` ${targetNorm}`) ||
      normAddr.includes(`${targetNorm} `) ||
      normAddr.includes(targetNorm)
    ) {
      return {
        status: "EXACT_CITY_MATCH",
        detectedCity: targetCity,
        detectedState: targetState,
        isExactMatch: true,
        confidence: insideBbox ? "HIGH" : "MEDIUM",
      };
    }

    // 5. BoundingBox Match
    if (insideBbox) {
      return {
        status: "EXACT_CITY_MATCH",
        detectedCity: targetCity,
        detectedState: targetState,
        isExactMatch: true,
        confidence: "HIGH",
      };
    }

    // 6. Neighboring City Match (e.g. Várzea Paulista, Itupeva when target is Jundiaí)
    return {
      status: "NEARBY_CITY",
      detectedCity: candidateCity || parsed.city || "Região Próxima",
      detectedState: targetState,
      isExactMatch: false,
      confidence: "LOW",
      rejectionReason: "CITY_MISMATCH",
    };
  }
}
