import { DuckDBInstance } from "@duckdb/node-api";

async function run() {
  const db = await DuckDBInstance.create();
  const conn = await db.connect();
  const sql = `
    SELECT name, city, website, phone
    FROM read_parquet('data/br-leads.parquet')
    WHERE bbox.ymin >= -23.50 AND bbox.ymax <= -23.10
      AND bbox.xmin >= -47.30 AND bbox.xmax <= -46.85
    LIMIT 20;
  `;
  const reader = await conn.run(sql);
  const rows = await reader.getRows();
  console.log("DUCKDB LEADS IN CABREUVA REGION:", rows.length);
  for (const r of rows) {
    console.log(" -", r[0], "| City:", r[1], "| Phone:", r[3]);
  }
}

run().catch(console.error);
