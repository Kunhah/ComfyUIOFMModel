import { NextResponse } from "next/server";
import { MandraRepository } from "@/lib/db/repository";

export const runtime = "nodejs";
const repo = new MandraRepository();

export async function GET() {
  try {
    const searches = await repo.getSavedSearches();
    return NextResponse.json({ searches });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Erro ao carregar pesquisas salvas" },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { title, queryText, params } = body;

    const saved = await repo.saveSearch(title, queryText, params);
    return NextResponse.json({ success: true, search: saved });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Erro ao salvar pesquisa" },
      { status: 500 }
    );
  }
}
