import { NextResponse } from "next/server";
import { MandraRepository } from "@/lib/db/repository";
import type { LeadCrmStatus } from "@/types";

export const runtime = "nodejs";
const repo = new MandraRepository();

export async function GET() {
  try {
    const deals = await repo.getCrmDeals();
    return NextResponse.json({ deals });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Erro ao carregar CRM" },
      { status: 500 }
    );
  }
}

export async function PATCH(req: Request) {
  try {
    const body = await req.json();
    const { leadId, stageId } = body;

    if (!leadId || !stageId) {
      return NextResponse.json(
        { error: "leadId e stageId são obrigatórios." },
        { status: 400 }
      );
    }

    const updated = await repo.updateLeadCrmStatus(leadId, stageId as LeadCrmStatus);
    return NextResponse.json({ success: true, lead: updated });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Erro ao atualizar estágio do CRM" },
      { status: 500 }
    );
  }
}
