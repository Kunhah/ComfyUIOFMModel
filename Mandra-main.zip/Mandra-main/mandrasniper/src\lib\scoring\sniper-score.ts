import type { ConfidenceLevel, Lead, ScoreReason, ScoreTier, WebsiteStatus } from "@/types";

export interface SniperScoreResult {
  score: number;
  tier: ScoreTier;
  confidence: ConfidenceLevel;
  breakdown: ScoreReason[];
}

export function calculateSniperScore(params: {
  websiteStatus: WebsiteStatus;
  hasInstagram: boolean;
  hasWhatsapp: boolean;
  reviewsCount: number;
  rating: number;
  phone: string | null;
  hasAddress: boolean;
}): SniperScoreResult {
  const breakdown: ScoreReason[] = [];
  let score = 0;

  // 1. Website Status Scoring
  if (params.websiteStatus === "NO_WEBSITE") {
    score += 25;
    breakdown.push({ reason: "Sem site próprio", points: 25 });
  } else if (
    params.websiteStatus === "POOR_WEBSITE" ||
    params.websiteStatus === "BROKEN_WEBSITE" ||
    params.websiteStatus === "SOCIAL_ONLY"
  ) {
    score += 18;
    breakdown.push({
      reason:
        params.websiteStatus === "SOCIAL_ONLY"
          ? "Apenas perfil em rede social"
          : params.websiteStatus === "BROKEN_WEBSITE"
          ? "Website fora do ar ou quebrado"
          : "Website antigo / ruim",
      points: 18,
    });
  }

  // 2. Instagram Presence Scoring
  if (params.hasInstagram) {
    score += 12;
    breakdown.push({ reason: "Instagram ativo na região", points: 12 });
  }

  // 3. WhatsApp Available Scoring
  if (params.hasWhatsapp) {
    score += 10;
    breakdown.push({ reason: "WhatsApp comercial disponível", points: 10 });
  }

  // 4. Google Reviews Volume Scoring
  if (params.reviewsCount >= 100) {
    score += 10;
    breakdown.push({ reason: `${params.reviewsCount}+ avaliações no Google`, points: 10 });
  } else if (params.reviewsCount >= 30) {
    score += 6;
    breakdown.push({ reason: `${params.reviewsCount} avaliações no Google`, points: 6 });
  }

  // 5. Google Rating Scoring
  if (params.rating >= 4.5) {
    score += 8;
    breakdown.push({ reason: `Alta reputação (Nota ${params.rating.toFixed(1)})`, points: 8 });
  } else if (params.rating >= 4.0) {
    score += 4;
    breakdown.push({ reason: `Boa reputação (Nota ${params.rating.toFixed(1)})`, points: 4 });
  }

  // 6. Recent Digital Activity Signaling
  if (params.reviewsCount >= 15 || params.hasInstagram) {
    score += 7;
    breakdown.push({ reason: "Atividade digital recente", points: 7 });
  }

  // 7. Commercial Contact Identified
  if (params.phone) {
    score += 5;
    breakdown.push({ reason: "Contato comercial identificado", points: 5 });
  }

  // 8. Strong Commercial Signal
  if (params.reviewsCount >= 50 && params.websiteStatus === "NO_WEBSITE") {
    score += 5;
    breakdown.push({ reason: "Sinal comercial forte (demanda sem captação)", points: 5 });
  }

  const finalScore = Math.min(100, Math.max(0, score));

  // Determine Score Tier
  let tier: ScoreTier = "FRIO";
  if (finalScore >= 90) tier = "SNIPER";
  else if (finalScore >= 75) tier = "QUENTE";
  else if (finalScore >= 60) tier = "BOM";
  else if (finalScore >= 40) tier = "POSSÍVEL";

  // Determine Data Confidence (HIGH, MEDIUM, LOW)
  let confidence: ConfidenceLevel = "LOW";
  let factsCount = 0;
  if (params.phone) factsCount++;
  if (params.hasAddress) factsCount++;
  if (params.reviewsCount > 0) factsCount++;
  if (params.websiteStatus !== "UNKNOWN") factsCount++;

  if (factsCount >= 3) confidence = "HIGH";
  else if (factsCount >= 2) confidence = "MEDIUM";

  return {
    score: finalScore,
    tier,
    confidence,
    breakdown,
  };
}
