"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { Bot, Sparkles, MessageCircle, Send, ShieldCheck, ArrowRight } from "lucide-react";
import type { Lead } from "@/types";
import { OutreachPanel } from "@/components/outreach-panel";

export default function AiSdrPage() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);

  useEffect(() => {
    fetch("/api/leads")
      .then((r) => r.json())
      .then((d) => {
        if (d.leads) setLeads(d.leads);
      });
  }, []);

  return (
    <div className="space-y-6 max-w-6xl">
      <div className="border-b border-[#ECE8E0] pb-4">
        <h1 className="text-2xl font-black text-[#1E2026] uppercase flex items-center gap-2">
          <Bot className="size-6 text-[#FF9E1B]" />
          <span>AI SDR Copilot — Automação de Abordagens</span>
        </h1>
        <p className="text-xs text-[#6E7381]">
          Geração de copys de abordagem não-genéricas baseadas estritamente em fatos reais confirmados.
        </p>
      </div>

      <div className="rounded-2xl border border-[#ECE8E0] bg-white p-6 shadow-2xs space-y-4">
        <h3 className="font-extrabold text-[#1E2026] text-sm uppercase">Leads Prontos para Abordagem Comercial</h3>
        
        <div className="space-y-3">
          {leads.map((lead) => (
            <div key={lead.id} className="flex items-center justify-between rounded-xl bg-[#FAF8F4] p-4 border border-[#ECE8E0]">
              <div>
                <div className="font-extrabold text-sm text-[#1E2026]">{lead.name}</div>
                <div className="text-xs text-[#6E7381]">
                  {lead.category} · {lead.city} · Score <strong className="text-[#FF9E1B]">{lead.sniperScore}</strong>
                </div>
              </div>

              <button
                onClick={() => setSelectedLead(lead)}
                className="flex items-center gap-2 rounded-xl bg-[#1C1F26] px-4 py-2 text-xs font-bold text-white hover:bg-[#2A2E38] transition"
              >
                <Sparkles className="size-3.5 text-[#FF9E1B]" />
                <span>Gerar Abordagem com IA</span>
              </button>
            </div>
          ))}
        </div>
      </div>

      <OutreachPanel
        lead={selectedLead}
        open={Boolean(selectedLead)}
        onClose={() => setSelectedLead(null)}
      />
    </div>
  );
}
