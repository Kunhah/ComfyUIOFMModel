"use client";

import React from "react";
import { CheckCircle2, XCircle, Target, Sparkles, ShieldCheck, X, Zap } from "lucide-react";
import type { Lead } from "@/types";

export function WhyThisLeadModal({
  lead,
  open,
  onClose,
}: {
  lead: Lead | null;
  open: boolean;
  onClose: () => void;
}) {
  if (!open || !lead) return null;

  const match = lead.criteriaMatch || {
    categoryMatch: true,
    locationMatch: true,
    noWebsiteFound: lead.websiteStatus === "NO_WEBSITE" || lead.websiteStatus === "SOCIAL_ONLY",
    instagramFound: Boolean(lead.socialUrl),
    whatsappFound: Boolean(lead.phone),
    ratingScore: lead.rating,
    reviewsCount: lead.reviewsCount,
  };

  const fits = lead.offerFitScores || {
    landingPage: lead.websiteStatus === "NO_WEBSITE" ? 96 : 45,
    website: lead.websiteStatus === "POOR_WEBSITE" ? 92 : 30,
    googleProfile: lead.reviewsCount < 30 ? 88 : 50,
    crm: lead.phone ? 85 : 40,
    automation: lead.phone && lead.socialUrl ? 90 : 55,
    socialPresence: !lead.socialUrl ? 80 : 35,
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
      <div className="w-full max-w-xl rounded-2xl border border-[#ECE8E0] bg-white p-6 text-[#1E2026] shadow-2xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#ECE8E0] pb-4">
          <div className="flex items-center gap-3">
            <div className="flex size-10 items-center justify-center rounded-xl bg-[#FFF5E6] text-[#FF9E1B]">
              <Target className="size-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-[#1E2026]">
                POR QUE ESTE LEAD APARECEU?
              </h3>
              <p className="text-xs text-[#6E7381]">
                {lead.name} ({lead.city}) · Sniper Score <strong className="text-[#FF9E1B]">{lead.sniperScore}/100</strong>
              </p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-gray-400 hover:bg-gray-100">
            <X className="size-5" />
          </button>
        </div>

        {/* Criteria Match Checklist */}
        <div className="space-y-2">
          <span className="text-xs font-extrabold uppercase tracking-wider text-[#6E7381]">
            Critérios Confirmados de Oportunidade:
          </span>
          <div className="grid gap-2 text-xs">
            <div className="flex items-center justify-between rounded-xl bg-[#FAF8F4] p-3 border border-[#ECE8E0]">
              <span className="font-semibold text-[#1E2026]">Nicho / Categoria:</span>
              <span className="font-bold text-emerald-700 flex items-center gap-1">
                <CheckCircle2 className="size-3.5" />
                {lead.category}
              </span>
            </div>

            <div className="flex items-center justify-between rounded-xl bg-[#FAF8F4] p-3 border border-[#ECE8E0]">
              <span className="font-semibold text-[#1E2026]">Localização Mapeada:</span>
              <span className="font-bold text-emerald-700 flex items-center gap-1">
                <CheckCircle2 className="size-3.5" />
                {lead.city}, {lead.state}
              </span>
            </div>

            <div className="flex items-center justify-between rounded-xl bg-[#FAF8F4] p-3 border border-[#ECE8E0]">
              <span className="font-semibold text-[#1E2026]">Website Próprio:</span>
              {match.noWebsiteFound ? (
                <span className="font-bold text-[#FF9E1B] flex items-center gap-1">
                  <CheckCircle2 className="size-3.5 text-[#FF9E1B]" />
                  Ausente (Oportunidade Forte)
                </span>
              ) : (
                <span className="font-bold text-blue-600 flex items-center gap-1">
                  <CheckCircle2 className="size-3.5" />
                  Página Existente
                </span>
              )}
            </div>

            <div className="flex items-center justify-between rounded-xl bg-[#FAF8F4] p-3 border border-[#ECE8E0]">
              <span className="font-semibold text-[#1E2026]">Presença no Instagram:</span>
              {match.instagramFound ? (
                <span className="font-bold text-emerald-700 flex items-center gap-1">
                  <CheckCircle2 className="size-3.5" />
                  Ativo na Região
                </span>
              ) : (
                <span className="font-bold text-gray-500 flex items-center gap-1">
                  <XCircle className="size-3.5" />
                  Não Mapeado
                </span>
              )}
            </div>

            <div className="flex items-center justify-between rounded-xl bg-[#FAF8F4] p-3 border border-[#ECE8E0]">
              <span className="font-semibold text-[#1E2026]">WhatsApp / Contato:</span>
              {match.whatsappFound ? (
                <span className="font-bold text-emerald-700 flex items-center gap-1">
                  <CheckCircle2 className="size-3.5" />
                  Disponível para Abordagem
                </span>
              ) : (
                <span className="font-bold text-gray-500">Apenas Telefone Fixo</span>
              )}
            </div>
          </div>
        </div>

        {/* Offer Fit Radar Scores */}
        <div className="space-y-2">
          <span className="text-xs font-extrabold uppercase tracking-wider text-[#6E7381]">
            O que Vender para este Lead (Offer Fit Score):
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
            <div className="rounded-xl border border-[#ECE8E0] bg-[#FAF9F6] p-3 text-center">
              <div className="text-[10px] text-[#6E7381] font-semibold">Landing Page</div>
              <div className="text-lg font-black text-[#FF9E1B] mt-0.5 tnum">{fits.landingPage}%</div>
            </div>
            <div className="rounded-xl border border-[#ECE8E0] bg-[#FAF9F6] p-3 text-center">
              <div className="text-[10px] text-[#6E7381] font-semibold">Website Novo</div>
              <div className="text-lg font-black text-emerald-600 mt-0.5 tnum">{fits.website}%</div>
            </div>
            <div className="rounded-xl border border-[#ECE8E0] bg-[#FAF9F6] p-3 text-center">
              <div className="text-[10px] text-[#6E7381] font-semibold">Automação CRM</div>
              <div className="text-lg font-black text-blue-600 mt-0.5 tnum">{fits.crm}%</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
