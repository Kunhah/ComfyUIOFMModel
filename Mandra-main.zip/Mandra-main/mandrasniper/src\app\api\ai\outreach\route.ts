import { NextResponse } from "next/server";
import { OpenAIProvider } from "@/lib/ai/openai";
import { MandraRepository } from "@/lib/db/repository";

export const runtime = "nodejs";
const aiProvider = new OpenAIProvider();
const repo = new MandraRepository();

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { leadId, channel = "WHATSAPP", tone = "CONSULTATIVE", objective = "LANDING_PAGE" } = body;

    if (!leadId) {
      return NextResponse.json({ error: "ID do lead é obrigatório." }, { status: 400 });
    }

    const lead = await repo.getLeadById(leadId);
    if (!lead) {
      return NextResponse.json({ error: "Lead não encontrado." }, { status: 404 });
    }

    const script = await aiProvider.generateOutreachScript(lead, channel, tone, objective);

    return NextResponse.json({ success: true, script });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Erro ao gerar mensagem com IA" },
      { status: 500 }
    );
  }
}
