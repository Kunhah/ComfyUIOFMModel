import { NextResponse } from "next/server";
import { MandraRepository } from "@/lib/db/repository";
import type { LeadCrmStatus } from "@/types";

export const runtime = "nodejs";
const repo = new MandraRepository();

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const lead = await repo.getLeadById(id);

  if (!lead) {
    return NextResponse.json({ error: "Lead não encontrado" }, { status: 404 });
  }

  return NextResponse.json({ lead });
}

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await req.json();
  const { crmStatus } = body;

  if (!crmStatus) {
    return NextResponse.json({ error: "Status é obrigatório" }, { status: 400 });
  }

  const updated = await repo.updateLeadCrmStatus(id, crmStatus as LeadCrmStatus);
  if (!updated) {
    return NextResponse.json({ error: "Lead não encontrado" }, { status: 404 });
  }

  return NextResponse.json({ success: true, lead: updated });
}
