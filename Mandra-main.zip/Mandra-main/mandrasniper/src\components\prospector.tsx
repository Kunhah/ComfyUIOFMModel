"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Download,
  Globe,
  Loader2,
  MessageCircle,
  Phone,
  Search,
  SlidersHorizontal,
  X,
  ChevronLeft,
  ChevronRight,
  MoreVertical,
  Send,
  Calendar,
  LayoutGrid,
  MapPin,
  CheckCircle2,
  Sparkles,
  Copy,
  Check,
  Building2,
  ShieldCheck,
} from "lucide-react";
import type { Niche } from "@/lib/niches";
import { outreachMessage, whatsappUrl } from "@/lib/score";
import type { ScoredLead, SearchResponse } from "@/lib/types";
import { cn } from "@/lib/cn";
import { StatusPicker } from "@/components/status-picker";

type CityOption = {
  name: string;
  uf: string;
  businesses?: number;
  noSite?: number;
};

export type InitialSearch = {
  niche: string;
  city: string;
  uf: string;
  onlyWithoutWebsite: boolean;
  minConfidence: number;
};

const POPULAR_CITIES: CityOption[] = [
  { name: "São Paulo", uf: "SP" },
  { name: "Rio de Janeiro", uf: "RJ" },
  { name: "Belo Horizonte", uf: "MG" },
  { name: "Curitiba", uf: "PR" },
  { name: "Campinas", uf: "SP" },
  { name: "Indaiatuba", uf: "SP" },
  { name: "Salvador", uf: "BA" },
  { name: "Brasília", uf: "DF" },
];

function parseCityQuery(q: string): CityOption | null {
  const trimmed = q.trim();
  if (!trimmed) return null;
  const parts = trimmed.split(/[-—,]/);
  if (parts.length >= 2) {
    const name = parts[0].trim();
    const uf = parts[1].trim().toUpperCase().slice(0, 2);
    if (name && uf.length === 2) return { name, uf };
  }
  if (parts.length === 1 && trimmed.length >= 3) {
    return { name: trimmed, uf: "SP" };
  }
  return null;
}

export function Prospector({
  niches,
  initialSearch,
  initialResult,
  initialError,
}: {
  niches: Niche[];
  initialSearch: InitialSearch | null;
  initialResult: SearchResponse | null;
  initialError: string | null;
}) {
  const [niche, setNiche] = useState(
    initialSearch?.niche ?? niches[0]?.slug ?? "beleza",
  );
  const [cityQuery, setCityQuery] = useState(
    initialSearch ? `${initialSearch.city} - ${initialSearch.uf}` : "",
  );
  const [city, setCity] = useState<CityOption | null>(
    initialSearch
      ? { name: initialSearch.city, uf: initialSearch.uf }
      : null,
  );
  const [radius, setRadius] = useState("10 km");
  const [onlyFilter, setOnlyFilter] = useState("Site");
  const [options, setOptions] = useState<CityOption[]>([]);
  const [showOptions, setShowOptions] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);

  const [onlyWithoutWebsite, setOnlyWithoutWebsite] = useState(
    initialSearch?.onlyWithoutWebsite ?? true,
  );
  const [minConfidence, setMinConfidence] = useState(
    initialSearch?.minConfidence ?? 0.5,
  );

  // Search & Scanning state
  const [loading, setLoading] = useState(false);
  const [scanStep, setScanStep] = useState(0);
  const [scanProgress, setScanProgress] = useState(0);
  const [error, setError] = useState<string | null>(initialError);
  const [result, setResult] = useState<SearchResponse | null>(initialResult);
  const [filter, setFilter] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Outreach message script modal state
  const [selectedLeadForScript, setSelectedLeadForScript] = useState<ScoredLead | null>(null);
  const [copied, setCopied] = useState(false);

  // Debounced city autocomplete
  useEffect(() => {
    if (cityQuery.trim().length < 2) return;
    const controller = new AbortController();
    const timer = setTimeout(() => {
      fetch(`/api/cities?q=${encodeURIComponent(cityQuery)}`, {
        signal: controller.signal,
      })
        .then((r) => r.json())
        .then((d) => setOptions(d.cities ?? []))
        .catch(() => {});
    }, 150);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [cityQuery]);

  // Simulated Scanning Animation Progress for high precision feel
  useEffect(() => {
    if (!loading) {
      setScanStep(0);
      setScanProgress(0);
      return;
    }

    setScanStep(1);
    setScanProgress(15);

    const t1 = setTimeout(() => {
      setScanStep(2);
      setScanProgress(45);
    }, 600);

    const t2 = setTimeout(() => {
      setScanStep(3);
      setScanProgress(78);
    }, 1200);

    const t3 = setTimeout(() => {
      setScanStep(4);
      setScanProgress(96);
    }, 1800);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, [loading]);

  const runSearch = useCallback(
    async (args: {
      niche: string;
      city: string;
      uf: string;
      onlyWithoutWebsite: boolean;
      minConfidence: number;
    }) => {
      setLoading(true);
      setError(null);
      try {
        const startTime = Date.now();
        const res = await fetch("/api/search", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ ...args, limit: 1000 }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error ?? `Erro ${res.status}`);

        // Ensure minimum 1.5s scanning effect for user feedback
        const elapsed = Date.now() - startTime;
        if (elapsed < 1500) {
          await new Promise((r) => setTimeout(r, 1500 - elapsed));
        }

        setResult(data as SearchResponse);
        setFilter("");
        setCurrentPage(1);

        const qs = new URLSearchParams({
          niche: args.niche,
          city: args.city,
          uf: args.uf,
          conf: String(args.minConfidence),
        });
        if (!args.onlyWithoutWebsite) qs.set("all", "1");
        window.history.replaceState(null, "", `?${qs}`);
      } catch (err) {
        setError(err instanceof Error ? err.message : String(err));
        setResult(null);
      } finally {
        setLoading(false);
      }
    },
    [],
  );

  const search = useCallback(
    (explicitCity?: CityOption) => {
      let targetCity = explicitCity ?? city;
      if (!targetCity) {
        targetCity = parseCityQuery(cityQuery);
      }

      if (!targetCity) {
        setError("Por favor, selecione ou digite uma cidade e estado (ex: São Paulo - SP).");
        return;
      }

      setCity(targetCity);
      setCityQuery(`${targetCity.name} - ${targetCity.uf}`);

      return runSearch({
        niche,
        city: targetCity.name,
        uf: targetCity.uf,
        onlyWithoutWebsite,
        minConfidence,
      });
    },
    [city, cityQuery, niche, onlyWithoutWebsite, minConfidence, runSearch],
  );

  const visibleOptions = cityQuery.trim().length >= 2 ? options : [];

  const rawLeads = useMemo(() => {
    return result?.leads ?? [];
  }, [result]);

  const visible = useMemo(() => {
    const q = filter.trim().toLowerCase();
    if (!q) return rawLeads;
    return rawLeads.filter(
      (l) =>
        l.name.toLowerCase().includes(q) ||
        (l.address ?? "").toLowerCase().includes(q) ||
        (l.category ?? "").toLowerCase().includes(q),
    );
  }, [rawLeads, filter]);

  // Pagination
  const totalPages = Math.ceil(visible.length / pageSize) || 1;
  const paginatedLeads = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return visible.slice(start, start + pageSize);
  }, [visible, currentPage, pageSize]);

  const exportCsv = useCallback(async () => {
    if (visible.length === 0) return;
    const nicheLabel = niches.find((n) => n.slug === niche)?.label ?? niche;
    const res = await fetch("/api/export", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        leads: visible,
        filename: `${nicheLabel}-${city?.name ?? ""}-${city?.uf ?? ""}`,
      }),
    });
    if (!res.ok) return;
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "leads.csv";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }, [visible, niche, niches, city]);

  const totalCount = result ? result.stats.total : 0;
  const withoutSiteCount = result ? result.stats.withoutWebsite : 0;
  const whatsappCount = result ? result.stats.withWhatsapp : 0;
  const phoneCount = result ? result.stats.withPhone : 0;

  return (
    <div className="space-y-6">
      {/* 1. FILTER CARD CONTAINER */}
      <form
        className="rounded-2xl border border-[#ECE8E0] bg-white p-5 shadow-xs transition"
        onSubmit={(e) => {
          e.preventDefault();
          void search();
        }}
      >
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5 items-end">
          {/* Segmento */}
          <div>
            <label className="block text-xs font-semibold text-[#6E7381] mb-1.5">
              Segmento
            </label>
            <select
              value={niche}
              onChange={(e) => setNiche(e.target.value)}
              className="w-full rounded-xl border border-[#E2DDD3] bg-[#FAF9F6] px-3.5 py-2.5 text-sm text-[#1E2026] outline-none transition focus:border-[#FF9E1B] focus:bg-white"
            >
              {groupNiches(niches).map((g) => (
                <optgroup key={g.group} label={g.group}>
                  {g.niches.map((n) => (
                    <option key={n.slug} value={n.slug}>
                      {n.label}
                    </option>
                  ))}
                </optgroup>
              ))}
            </select>
          </div>

          {/* Localização Input */}
          <div className="relative">
            <label className="block text-xs font-semibold text-[#6E7381] mb-1.5">
              Localização
            </label>
            <div className="relative">
              <input
                value={cityQuery}
                onChange={(e) => {
                  setCityQuery(e.target.value);
                  setCity(null);
                  setShowOptions(true);
                }}
                onBlur={() => setTimeout(() => setShowOptions(false), 150)}
                placeholder="Ex: São Paulo - SP, Curitiba - PR..."
                className="w-full rounded-xl border border-[#E2DDD3] bg-[#FAF9F6] px-3.5 py-2.5 text-sm text-[#1E2026] outline-none transition focus:border-[#FF9E1B] focus:bg-white pr-8 placeholder:text-gray-400"
              />
              {cityQuery && (
                <button
                  type="button"
                  onClick={() => {
                    setCityQuery("");
                    setCity(null);
                  }}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  <X className="size-4" />
                </button>
              )}
            </div>

            {/* City Autocomplete List */}
            {showOptions && visibleOptions.length > 0 && (
              <ul className="absolute z-30 mt-1 max-h-56 w-full overflow-auto rounded-xl border border-[#ECE8E0] bg-white p-1 shadow-xl">
                {visibleOptions.map((c) => (
                  <li key={`${c.name}-${c.uf}`}>
                    <button
                      type="button"
                      onMouseDown={(e) => e.preventDefault()}
                      onClick={() => {
                        setCity(c);
                        setCityQuery(`${c.name} - ${c.uf}`);
                        setShowOptions(false);
                      }}
                      className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm text-[#1E2026] hover:bg-[#FAF8F4]"
                    >
                      <span className="font-medium">
                        {c.name}{" "}
                        <span className="text-xs text-[#6E7381]">- {c.uf}</span>
                      </span>
                      {c.noSite !== undefined && (
                        <span className="text-xs text-[#6E7381]">
                          {c.noSite.toLocaleString("pt-BR")} sem site
                        </span>
                      )}
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Raio */}
          <div>
            <label className="block text-xs font-semibold text-[#6E7381] mb-1.5">
              Raio
            </label>
            <select
              value={radius}
              onChange={(e) => setRadius(e.target.value)}
              className="w-full rounded-xl border border-[#E2DDD3] bg-[#FAF9F6] px-3.5 py-2.5 text-sm text-[#1E2026] outline-none transition focus:border-[#FF9E1B] focus:bg-white"
            >
              <option value="5 km">5 km</option>
              <option value="10 km">10 km</option>
              <option value="25 km">25 km</option>
              <option value="50 km">50 km</option>
            </select>
          </div>

          {/* Não possuem */}
          <div>
            <label className="block text-xs font-semibold text-[#6E7381] mb-1.5">
              Não possuem
            </label>
            <select
              value={onlyFilter}
              onChange={(e) => {
                setOnlyFilter(e.target.value);
                setOnlyWithoutWebsite(e.target.value === "Site");
              }}
              className="w-full rounded-xl border border-[#E2DDD3] bg-[#FAF9F6] px-3.5 py-2.5 text-sm text-[#1E2026] outline-none transition focus:border-[#FF9E1B] focus:bg-white"
            >
              <option value="Site">Site</option>
              <option value="Telefone">Telefone</option>
              <option value="WhatsApp">WhatsApp</option>
              <option value="Todos">Todos os Registros</option>
            </select>
          </div>

          {/* Buttons */}
          <div className="flex items-center gap-2 sm:col-span-2 lg:col-span-1">
            <button
              type="button"
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="flex items-center gap-1.5 rounded-xl border border-[#E2DDD3] bg-[#FAF9F6] px-3 py-2.5 text-xs font-semibold text-[#1E2026] hover:bg-white transition"
            >
              <SlidersHorizontal className="size-3.5 text-[#6E7381]" />
              Mais filtros
            </button>

            <button
              type="submit"
              disabled={loading}
              className={cn(
                "flex-1 inline-flex items-center justify-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold transition shadow-sm",
                "bg-[#1C1F26] text-white hover:bg-[#2A2E38] active:scale-[0.98]",
                "disabled:cursor-not-allowed disabled:opacity-50",
              )}
            >
              {loading ? (
                <Loader2 className="size-4 animate-spin text-[#FF9E1B]" />
              ) : (
                <Search className="size-4 text-[#FF9E1B]" />
              )}
              <span>Buscar Leads</span>
            </button>
          </div>
        </div>

        {/* Advanced Drawer */}
        {showAdvanced && (
          <div className="mt-4 pt-4 border-t border-[#ECE8E0] grid gap-4 sm:grid-cols-2">
            <label className="flex items-center gap-3 text-xs font-medium text-[#1E2026]">
              <input
                type="checkbox"
                checked={onlyWithoutWebsite}
                onChange={(e) => setOnlyWithoutWebsite(e.target.checked)}
                className="size-4 accent-[#FF9E1B] rounded"
              />
              <span>Somente empresas sem website oficial</span>
            </label>

            <div className="flex items-center gap-3">
              <span className="text-xs text-[#6E7381]">
                Confiança Mínima:{" "}
                <span className="font-bold text-[#1E2026]">
                  {minConfidence.toFixed(2)}
                </span>
              </span>
              <input
                type="range"
                min={0}
                max={0.95}
                step={0.05}
                value={minConfidence}
                onChange={(e) => setMinConfidence(Number(e.target.value))}
                className="w-32 accent-[#FF9E1B]"
              />
            </div>
          </div>
        )}
      </form>

      {error && (
        <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-xs text-red-600">
          {error}
        </div>
      )}

      {/* 2. SCANNING ANIMATED HUD (Shown when searching) */}
      {loading && (
        <div className="rounded-2xl border border-[#2B2F3E] bg-[#14161F] p-6 text-white shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex size-10 items-center justify-center rounded-xl bg-[#232634] text-[#FF9E1B]">
                <Sparkles className="size-5 animate-pulse" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-white">
                  Mandra Intelligence Engine — Varrendo Banco de Dados
                </h3>
                <p className="text-xs text-[#8A909E]">
                  Procurando leads de alta assertividade em{" "}
                  <span className="text-[#FF9E1B] font-semibold">
                    {cityQuery || "cidade selecionada"}
                  </span>
                </p>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-[#FF9E1B]">
              {scanProgress}%
            </span>
          </div>

          {/* Progress Bar */}
          <div className="h-2 w-full rounded-full bg-[#242836] overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#FF9E1B] to-amber-300 transition-all duration-300 ease-out"
              style={{ width: `${scanProgress}%` }}
            />
          </div>

          {/* Scanner Steps */}
          <div className="grid gap-2 text-xs text-[#9DA3B0] sm:grid-cols-2 pt-2">
            <div className={cn("flex items-center gap-2", scanStep >= 1 && "text-white font-medium")}>
              {scanStep >= 1 ? (
                <CheckCircle2 className="size-3.5 text-[#FF9E1B]" />
              ) : (
                <div className="size-3.5 rounded-full border border-gray-600" />
              )}
              <span>1. Conectando ao extrato Overture Maps Brasil...</span>
            </div>
            <div className={cn("flex items-center gap-2", scanStep >= 2 && "text-white font-medium")}>
              {scanStep >= 2 ? (
                <CheckCircle2 className="size-3.5 text-[#FF9E1B]" />
              ) : (
                <div className="size-3.5 rounded-full border border-gray-600" />
              )}
              <span>2. Mapeando segmento de negócios e coordenadas...</span>
            </div>
            <div className={cn("flex items-center gap-2", scanStep >= 3 && "text-white font-medium")}>
              {scanStep >= 3 ? (
                <CheckCircle2 className="size-3.5 text-[#FF9E1B]" />
              ) : (
                <div className="size-3.5 rounded-full border border-gray-600" />
              )}
              <span>3. Filtrando presença web e domínios ausentes...</span>
            </div>
            <div className={cn("flex items-center gap-2", scanStep >= 4 && "text-white font-medium")}>
              {scanStep >= 4 ? (
                <CheckCircle2 className="size-3.5 text-[#FF9E1B]" />
              ) : (
                <div className="size-3.5 rounded-full border border-gray-600" />
              )}
              <span>4. Calculando pontuação de oportunidade e contatos...</span>
            </div>
          </div>
        </div>
      )}

      {/* 3. KPI STAT CARDS */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="flex items-center gap-4 rounded-2xl border border-[#ECE8E0] bg-white p-4 shadow-xs">
          <div className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-[#FFF5E6] text-[#FF9E1B]">
            <LayoutGrid className="size-5" />
          </div>
          <div>
            <div className="text-xs font-semibold text-[#6E7381]">
              Leads Encontrados
            </div>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-2xl font-bold text-[#1E2026] tnum">
                {totalCount}
              </span>
              {result && (
                <span className="text-[11px] font-semibold text-[#6E7381]">
                  no filtro
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4 rounded-2xl border border-[#ECE8E0] bg-white p-4 shadow-xs">
          <div className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-[#FFF5E6] text-[#FF9E1B]">
            <Send className="size-5" />
          </div>
          <div>
            <div className="text-xs font-semibold text-[#6E7381]">
              Com WhatsApp
            </div>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-2xl font-bold text-[#1E2026] tnum">
                {whatsappCount}
              </span>
              {result && (
                <span className="text-[11px] font-semibold text-[#25D366]">
                  contato ativo
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4 rounded-2xl border border-[#ECE8E0] bg-white p-4 shadow-xs">
          <div className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-[#FFF5E6] text-[#FF9E1B]">
            <MessageCircle className="size-5" />
          </div>
          <div>
            <div className="text-xs font-semibold text-[#6E7381]">
              Com Telefone
            </div>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-2xl font-bold text-[#1E2026] tnum">
                {phoneCount}
              </span>
              {result && (
                <span className="text-[11px] font-semibold text-[#6E7381]">
                  verificados
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4 rounded-2xl border border-[#ECE8E0] bg-white p-4 shadow-xs">
          <div className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-[#FFF5E6] text-[#FF9E1B]">
            <Calendar className="size-5" />
          </div>
          <div>
            <div className="text-xs font-semibold text-[#6E7381]">
              Sem Website
            </div>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-2xl font-bold text-[#1E2026] tnum">
                {withoutSiteCount}
              </span>
              {result && (
                <span className="text-[11px] font-semibold text-[#FF9E1B]">
                  potencial alto
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* 4. EMPTY INITIAL STATE CARD (When no search has been run yet) */}
      {!result && !loading && (
        <div className="rounded-2xl border border-[#ECE8E0] bg-white p-8 text-center shadow-xs space-y-4">
          <div className="mx-auto flex size-14 items-center justify-center rounded-2xl bg-[#FFF5E6] text-[#FF9E1B]">
            <Building2 className="size-7" />
          </div>
          <div className="max-w-md mx-auto">
            <h3 className="text-base font-bold text-[#1E2026]">
              Pronto para prospectar novas oportunidades?
            </h3>
            <p className="mt-1 text-xs text-[#6E7381] leading-relaxed">
              Digite uma cidade e selecione o segmento acima para varrer a base de empresas sem site na região.
            </p>
          </div>

          {/* Quick Click Popular Cities Badges */}
          <div className="pt-2">
            <span className="block text-[11px] font-semibold uppercase tracking-wider text-[#8B919E] mb-2.5">
              Ou escolha uma cidade para buscar agora:
            </span>
            <div className="flex flex-wrap items-center justify-center gap-2">
              {POPULAR_CITIES.map((c) => (
                <button
                  key={`${c.name}-${c.uf}`}
                  type="button"
                  onClick={() => search(c)}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-[#E2DDD3] bg-[#FAF9F6] px-3.5 py-1.5 text-xs font-semibold text-[#1E2026] hover:border-[#FF9E1B] hover:bg-[#FFF5E6] hover:text-[#FF9E1B] transition shadow-xs"
                >
                  <MapPin className="size-3 text-[#FF9E1B]" />
                  <span>
                    {c.name} - {c.uf}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 5. LEADS TABLE (Rendered when search results are available) */}
      {result && (
        <div className="rounded-2xl border border-[#ECE8E0] bg-white shadow-xs overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-4 p-5 border-b border-[#ECE8E0]">
            <div className="flex items-center gap-3">
              <h2 className="text-lg font-bold text-[#1E2026]">
                Leads Encontrados
              </h2>
              <span className="rounded-lg bg-[#FAF8F4] border border-[#ECE8E0] px-2.5 py-0.5 text-xs font-semibold text-[#6E7381]">
                {visible.length} registros
              </span>
            </div>

            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-[#858B98]" />
                <input
                  value={filter}
                  onChange={(e) => setFilter(e.target.value)}
                  placeholder="Buscar empresa ou endereço..."
                  className="w-64 rounded-xl border border-[#E2DDD3] bg-[#FAF9F6] pl-9 pr-3 py-2 text-xs text-[#1E2026] outline-none transition focus:border-[#FF9E1B] focus:bg-white"
                />
              </div>

              <button
                onClick={() => void exportCsv()}
                disabled={visible.length === 0}
                className="flex items-center gap-2 rounded-xl border border-[#E2DDD3] bg-white px-3.5 py-2 text-xs font-semibold text-[#1E2026] hover:bg-[#FAF8F4] transition disabled:opacity-40"
              >
                <Download className="size-4 text-[#6E7381]" />
                Exportar CSV
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-[#ECE8E0] bg-[#FAF8F4] text-[#6E7381] font-semibold tracking-wider">
                  <th className="px-5 py-3">Score</th>
                  <th className="px-5 py-3">Empresa</th>
                  <th className="px-4 py-3">Segmento</th>
                  <th className="px-4 py-3">Localização</th>
                  <th className="px-4 py-3">Contato</th>
                  <th className="px-4 py-3">Fonte</th>
                  <th className="px-4 py-3">Site</th>
                  <th className="px-4 py-3 text-right">Ações & Pipeline</th>
                </tr>
              </thead>

              <tbody className="divide-y divide-[#ECE8E0]">
                {paginatedLeads.map((l) => (
                  <tr
                    key={l.id}
                    className="hover:bg-[#FAF8F5] transition duration-150"
                  >
                    {/* Score Badge */}
                    <td className="px-5 py-3.5">
                      <span className="inline-block rounded-lg bg-[#FF9E1B]/15 px-2 py-1 text-xs font-bold text-[#FF9E1B] border border-[#FF9E1B]/30 tnum">
                        {l.score}
                      </span>
                    </td>

                    {/* Empresa */}
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <div className="flex size-9 shrink-0 items-center justify-center rounded-full bg-[#181A20] text-xs font-bold text-[#FF9E1B] shadow-xs">
                          {l.name.slice(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <div className="font-bold text-[#1E2026] text-sm flex items-center gap-1.5">
                            {l.name}
                            {l.isNew && (
                              <span className="rounded bg-[#FF9E1B]/15 px-1.5 py-0.5 text-[9px] font-bold text-[#FF9E1B] uppercase tracking-wide">
                                Novo
                              </span>
                            )}
                          </div>
                          {l.address && (
                            <div className="text-[11px] text-[#858B98] truncate max-w-xs">
                              {l.address}
                            </div>
                          )}
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-3.5 font-medium text-[#1E2026]">
                      {l.category ?? "—"}
                    </td>

                    <td className="px-4 py-3.5 text-[#1E2026]">
                      {l.city} - {l.uf}
                    </td>

                    <td className="px-4 py-3.5">
                      {l.phone ? (
                        <a
                          href={whatsappUrl(l.phone, outreachMessage(l)) ?? `tel:${l.phone}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 font-medium text-[#25D366] hover:underline"
                        >
                          <MessageCircle className="size-4 fill-[#25D366]/20 text-[#25D366]" />
                          <span>{formatPhone(l.phone)}</span>
                        </a>
                      ) : (
                        <span className="text-[#989EA9]">Sem telefone</span>
                      )}
                    </td>

                    <td className="px-4 py-3.5 text-[#6E7381]">
                      Google Maps
                    </td>

                    <td className="px-4 py-3.5">
                      {l.website ? (
                        <a
                          href={l.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="font-medium text-[#1E2026] hover:underline flex items-center gap-1"
                        >
                          <Globe className="size-3.5 text-blue-500" />
                          Ver site
                        </a>
                      ) : (
                        <span className="font-semibold text-[#FF9E1B]">
                          Não possui
                        </span>
                      )}
                    </td>

                    {/* Ações & Pipeline Status */}
                    <td className="px-4 py-3.5 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <StatusPicker id={l.id} status="novo" />
                        <button
                          onClick={() => setSelectedLeadForScript(l)}
                          className="flex size-8 items-center justify-center rounded-lg bg-[#1C1F26] text-white hover:bg-[#2A2E38] transition shadow-xs"
                          title="Ver Script de Prospecção"
                        >
                          <MessageCircle className="size-4 text-[#FF9E1B]" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Table Pagination Footer */}
          <div className="flex flex-wrap items-center justify-between gap-4 px-5 py-4 border-t border-[#ECE8E0] bg-[#FAF8F4] text-xs text-[#6E7381]">
            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="flex size-7 items-center justify-center rounded-lg border border-[#E2DDD3] bg-white text-gray-600 disabled:opacity-40 hover:bg-[#F5F2EB]"
              >
                <ChevronLeft className="size-4" />
              </button>
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => i + 1).map(
                (p) => (
                  <button
                    key={p}
                    onClick={() => setCurrentPage(p)}
                    className={`flex size-7 items-center justify-center rounded-lg font-semibold transition ${
                      currentPage === p
                        ? "bg-[#1C1F26] text-white"
                        : "border border-[#E2DDD3] bg-white text-gray-700 hover:bg-[#F5F2EB]"
                    }`}
                  >
                    {p}
                  </button>
                ),
              )}
              {totalPages > 5 && <span className="px-1 text-gray-400">...</span>}
              <button
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="flex size-7 items-center justify-center rounded-lg border border-[#E2DDD3] bg-white text-gray-600 disabled:opacity-40 hover:bg-[#F5F2EB]"
              >
                <ChevronRight className="size-4" />
              </button>
            </div>

            <div>
              Mostrando {visible.length === 0 ? 0 : (currentPage - 1) * pageSize + 1}{" "}
              a {Math.min(currentPage * pageSize, visible.length)} de {visible.length}{" "}
              leads
            </div>

            <div className="flex items-center gap-2">
              <select
                value={pageSize}
                onChange={(e) => {
                  setPageSize(Number(e.target.value));
                  setCurrentPage(1);
                }}
                className="rounded-lg border border-[#E2DDD3] bg-white px-2 py-1 text-xs text-[#1E2026] outline-none"
              >
                <option value={10}>10 por página</option>
                <option value={25}>25 por página</option>
                <option value={50}>50 por página</option>
              </select>
            </div>
          </div>
        </div>
      )}

      {/* OUTREACH SCRIPT MODAL */}
      {selectedLeadForScript && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#ECE8E0] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="flex size-8 items-center justify-center rounded-lg bg-[#FFF5E6] text-[#FF9E1B]">
                  <Sparkles className="size-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-[#1E2026]">
                    Script Comercial WhatsApp
                  </h3>
                  <p className="text-xs text-[#6E7381]">
                    Para {selectedLeadForScript.name} ({selectedLeadForScript.city})
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedLeadForScript(null)}
                className="rounded-lg p-1 text-gray-400 hover:bg-gray-100"
              >
                <X className="size-5" />
              </button>
            </div>

            <div className="rounded-xl border border-[#E2DDD3] bg-[#FAF9F6] p-4 text-xs font-mono leading-relaxed text-[#1E2026]">
              {outreachMessage(selectedLeadForScript)}
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(outreachMessage(selectedLeadForScript));
                  setCopied(true);
                  setTimeout(() => setCopied(false), 2000);
                }}
                className="flex items-center gap-1.5 rounded-xl border border-[#E2DDD3] bg-white px-4 py-2 text-xs font-semibold text-[#1E2026] hover:bg-[#FAF8F4]"
              >
                {copied ? <Check className="size-4 text-emerald-600" /> : <Copy className="size-4" />}
                <span>{copied ? "Copiado!" : "Copiar Texto"}</span>
              </button>

              {selectedLeadForScript.phone && (
                <a
                  href={whatsappUrl(selectedLeadForScript.phone, outreachMessage(selectedLeadForScript)) ?? "#"}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 rounded-xl bg-[#25D366] px-5 py-2 text-xs font-bold text-white hover:bg-[#20bd5a] shadow-sm"
                >
                  <MessageCircle className="size-4" />
                  <span>Abrir no WhatsApp</span>
                </a>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function formatPhone(phone: string): string {
  const digits = phone.replace(/\D/g, "");
  if (digits.length === 13 && digits.startsWith("55")) {
    const ddd = digits.slice(2, 4);
    const num1 = digits.slice(4, 9);
    const num2 = digits.slice(9);
    return `(${ddd}) ${num1}-${num2}`;
  }
  return phone;
}

function groupNiches(niches: Niche[]): { group: string; niches: Niche[] }[] {
  const groups: { group: string; niches: Niche[] }[] = [];
  for (const niche of niches) {
    const last = groups[groups.length - 1];
    if (last && last.group === niche.group) last.niches.push(niche);
    else groups.push({ group: niche.group, niches: [niche] });
  }
  return groups;
}
