import type { WebsiteAuditRecord, WebsiteAnalyzerProvider, ProviderResult } from "../types";
import type { WebsiteStatus } from "@/types";

export class ServerWebsiteAnalyzer implements WebsiteAnalyzerProvider {
  public async analyzeWebsite(url: string | null): Promise<ProviderResult<WebsiteAuditRecord>> {
    if (!url || url.trim().length === 0) {
      return {
        status: "CONFIGURED",
        data: {
          url: "",
          statusCode: 0,
          hasHttps: false,
          isResponsive: false,
          title: null,
          metaDescription: null,
          hasCta: false,
          hasWhatsapp: false,
          hasForm: false,
          hasSocialLinks: false,
          performanceScore: 0,
          seoScore: 0,
          websiteScore: 0,
          status: "NO_WEBSITE",
        },
      };
    }

    const trimmedUrl = url.trim().toLowerCase();

    // Check for social landing profiles
    if (
      trimmedUrl.includes("instagram.com") ||
      trimmedUrl.includes("facebook.com") ||
      trimmedUrl.includes("linktr.ee") ||
      trimmedUrl.includes("wa.me") ||
      trimmedUrl.includes("whatsapp.com")
    ) {
      return {
        status: "CONFIGURED",
        data: {
          url: trimmedUrl,
          statusCode: 200,
          hasHttps: true,
          isResponsive: true,
          title: "Perfil Social",
          metaDescription: "Página em rede social",
          hasCta: true,
          hasWhatsapp: trimmedUrl.includes("wa.me") || trimmedUrl.includes("whatsapp"),
          hasForm: false,
          hasSocialLinks: true,
          performanceScore: 40,
          seoScore: 20,
          websiteScore: 25,
          status: "SOCIAL_ONLY",
        },
      };
    }

    // Normalized protocol URL
    const targetUrl = trimmedUrl.startsWith("http") ? trimmedUrl : `https://${trimmedUrl}`;

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);

      const res = await fetch(targetUrl, {
        method: "GET",
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) MandraBot/1.0",
        },
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!res.ok) {
        return {
          status: "CONFIGURED",
          data: {
            url: targetUrl,
            statusCode: res.status,
            hasHttps: targetUrl.startsWith("https"),
            isResponsive: false,
            title: null,
            metaDescription: null,
            hasCta: false,
            hasWhatsapp: false,
            hasForm: false,
            hasSocialLinks: false,
            performanceScore: 10,
            seoScore: 10,
            websiteScore: 15,
            status: "BROKEN_WEBSITE",
          },
        };
      }

      const html = await res.text();
      const lowerHtml = html.toLowerCase();

      const hasHttps = targetUrl.startsWith("https");
      const isResponsive = lowerHtml.includes('name="viewport"') || lowerHtml.includes("width=device-width");
      const hasCta = lowerHtml.includes("agendar") || lowerHtml.includes("contato") || lowerHtml.includes("solicitar") || lowerHtml.includes("btn");
      const hasWhatsapp = lowerHtml.includes("wa.me") || lowerHtml.includes("whatsapp") || lowerHtml.includes("api.whatsapp.com");
      const hasForm = lowerHtml.includes("<form") || lowerHtml.includes('type="submit"');
      const hasSocialLinks = lowerHtml.includes("instagram.com") || lowerHtml.includes("facebook.com");

      // Extract Title & Meta Description
      const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
      const title = titleMatch ? titleMatch[1].trim() : null;

      const metaMatch = html.match(/<meta[^>]*name=["']description["'][^>]*content=["']([^"']+)["']/i);
      const metaDescription = metaMatch ? metaMatch[1].trim() : null;

      let score = 20;
      if (hasHttps) score += 15;
      if (isResponsive) score += 20;
      if (hasCta) score += 15;
      if (hasWhatsapp) score += 15;
      if (hasForm) score += 10;
      if (title && title.length > 5) score += 5;

      const websiteScore = Math.min(100, Math.max(0, score));
      const status: WebsiteStatus = websiteScore < 50 ? "POOR_WEBSITE" : "GOOD_WEBSITE";

      return {
        status: "CONFIGURED",
        data: {
          url: targetUrl,
          statusCode: res.status,
          hasHttps,
          isResponsive,
          title,
          metaDescription,
          hasCta,
          hasWhatsapp,
          hasForm,
          hasSocialLinks,
          performanceScore: isResponsive ? 75 : 35,
          seoScore: title ? 70 : 30,
          websiteScore,
          status,
        },
      };
    } catch (err) {
      return {
        status: "CONFIGURED",
        data: {
          url: targetUrl,
          statusCode: 0,
          hasHttps: targetUrl.startsWith("https"),
          isResponsive: false,
          title: null,
          metaDescription: null,
          hasCta: false,
          hasWhatsapp: false,
          hasForm: false,
          hasSocialLinks: false,
          performanceScore: 0,
          seoScore: 0,
          websiteScore: 15,
          status: "BROKEN_WEBSITE",
        },
      };
    }
  }
}
