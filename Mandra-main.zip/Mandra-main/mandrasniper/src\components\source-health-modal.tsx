"use client";

import React, { useEffect, useState } from "react";
import { Server, Activity, ShieldCheck, AlertCircle, CheckCircle2, X } from "lucide-react";

export function SourceHealthModal({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const [sources, setSources] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (open) {
      fetch("/api/sources")
        .then((r) => r.json())
        .then((d) => {
          if (d.sources) setSources(d.sources);
          setLoading(false);
        });
    }
  }, [open]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4">
      <div className="w-full max-w-3xl rounded-3xl border border-[#2B2E3C] bg-[#14161C] p-7 text-white shadow-2xl space-y-6">
        <div className="flex items-center justify-between border-b border-[#222530] pb-4">
          <div className="flex items-center gap-3">
            <div className="flex size-10 items-center justify-center rounded-2xl bg-[#FF9E1B]/15 text-[#FF9E1B]">
              <Server className="size-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-white">
                GLOBAL DISCOVERY DATA SOURCES & HEALTH
              </h3>
              <p className="text-xs text-gray-400">
                Telemetry and status of active multi-source discovery providers
              </p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-gray-400 hover:text-white">
            <X className="size-5" />
          </button>
        </div>

        {loading ? (
          <div className="py-8 text-center text-xs text-[#FF9E1B] font-bold">Consultando Provedores...</div>
        ) : (
          <div className="space-y-3">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-[#222530] text-gray-400 font-bold uppercase">
                    <th className="px-3 py-2.5">Provedor / Fonte</th>
                    <th className="px-3 py-2.5">Tipo</th>
                    <th className="px-3 py-2.5">Status</th>
                    <th className="px-3 py-2.5">Tempo Resp.</th>
                    <th className="px-3 py-2.5">Yield Estimado</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#222530]">
                  {sources.map((s, idx) => (
                    <tr key={idx} className="hover:bg-[#1A1C24]">
                      <td className="px-3 py-3 font-bold text-white">
                        {s.name}
                        <div className="text-[10px] text-gray-400 font-normal">{s.message}</div>
                      </td>
                      <td className="px-3 py-3 text-gray-300 font-mono text-[11px]">{s.type}</td>
                      <td className="px-3 py-3">
                        {s.status === "CONNECTED" ? (
                          <span className="rounded-md bg-emerald-500/15 text-emerald-400 px-2 py-0.5 text-[10px] font-black uppercase border border-emerald-500/30 flex items-center gap-1 w-fit">
                            <CheckCircle2 className="size-3" />
                            CONNECTED (REAL)
                          </span>
                        ) : (
                          <span className="rounded-md bg-amber-500/15 text-amber-400 px-2 py-0.5 text-[10px] font-black uppercase border border-amber-500/30 flex items-center gap-1 w-fit">
                            <AlertCircle className="size-3" />
                            {s.status}
                          </span>
                        )}
                      </td>
                      <td className="px-3 py-3 font-mono text-gray-300 tnum">{s.averageLatencyMs}ms</td>
                      <td className="px-3 py-3 font-mono font-bold text-[#FF9E1B] tnum">
                        {s.yieldCount.toLocaleString("pt-BR")} leads
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
