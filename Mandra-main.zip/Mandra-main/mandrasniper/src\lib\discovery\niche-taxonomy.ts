export interface NicheDefinition {
  id: string;
  label: string;
  aliases: string[];
  googleKeywords: string[];
  osmTags: Record<string, string>[];
  webQueries: string[];
}

export const NICHE_TAXONOMY: Record<string, NicheDefinition> = {
  barber: {
    id: "barber",
    label: "Barbearias",
    aliases: ["barbearia", "barber shop", "barber", "cabeleireiro masculino", "corte masculino", "barba e cabelo"],
    googleKeywords: ["barbearia", "barber shop", "corte masculino"],
    osmTags: [{ shop: "hairdresser" }],
    webQueries: ["barbearia", "barber shop", "corte masculino"],
  },
  dentist: {
    id: "dentist",
    label: "Dentistas",
    aliases: ["dentista", "clínica odontológica", "odontologia", "ortodontia", "implantodontia", "consultório odontológico"],
    googleKeywords: ["dentista", "clínica odontológica", "odontologia"],
    osmTags: [{ amenity: "dentist" }, { healthcare: "dentist" }],
    webQueries: ["dentista", "clínica odontológica", "ortodontia"],
  },
  beauty: {
    id: "beauty",
    label: "Clínicas de estética",
    aliases: ["clínica de estética", "estética facial", "estética corporal", "harmonização facial", "spa urbano", "depilação a laser"],
    googleKeywords: ["estética", "clínica de estética", "harmonização facial"],
    osmTags: [{ shop: "beauty" }],
    webQueries: ["estética", "clínica de estética", "harmonização"],
  },
  restaurant: {
    id: "restaurant",
    label: "Restaurantes & Bares",
    aliases: ["restaurante", "bar", "bistrô", "churrascaria", "comida caseira", "gastronomia"],
    googleKeywords: ["restaurante", "bar", "bistrô"],
    osmTags: [{ amenity: "restaurant" }, { amenity: "bar" }],
    webQueries: ["restaurante", "bar", "bistrô"],
  },
  gym: {
    id: "gym",
    label: "Academias & Fitness",
    aliases: ["academia", "fitness", "crossfit", "pilates", "personal trainer", "treinamento funcional"],
    googleKeywords: ["academia", "fitness", "crossfit"],
    osmTags: [{ leisure: "fitness_centre" }, { leisure: "sports_centre" }],
    webQueries: ["academia", "fitness", "crossfit"],
  },
  pet: {
    id: "pet",
    label: "Pet Shops & Veterinárias",
    aliases: ["pet shop", "clínica veterinária", "veterinário", "banho e tosa", "casa de ração"],
    googleKeywords: ["pet shop", "clínica veterinária", "banho e tosa"],
    osmTags: [{ shop: "pet" }, { amenity: "veterinary" }],
    webQueries: ["pet shop", "clínica veterinária", "banho e tosa"],
  },
  mechanic: {
    id: "mechanic",
    label: "Oficinas mecânicas",
    aliases: ["oficina mecânica", "auto center", "centro automotivo", "funilaria e pintura", "troca de óleo", "auto elétrica"],
    googleKeywords: ["oficina mecânica", "auto center", "mecanica automotiva"],
    osmTags: [{ shop: "car_repair" }],
    webQueries: ["oficina mecânica", "auto center", "mecânica"],
  },
  realestate: {
    id: "realestate",
    label: "Imobiliárias",
    aliases: ["imobiliária", "corretor de imóveis", "venda de imóveis", "aluguel de imóveis", "consultoria imobiliária"],
    googleKeywords: ["imobiliária", "corretor de imóveis", "venda de imóveis"],
    osmTags: [{ office: "estate_agent" }],
    webQueries: ["imobiliária", "corretor de imóveis", "venda imóveis"],
  },
  lawyer: {
    id: "lawyer",
    label: "Advogados & Advocacia",
    aliases: ["advogado", "escritório de advocacia", "advocacia", "consultoria jurídica", "direito trabalhista"],
    googleKeywords: ["advogado", "escritório de advocacia", "advocacia"],
    osmTags: [{ office: "lawyer" }],
    webQueries: ["advogado", "escritório de advocacia", "advocacia"],
  },
  accountant: {
    id: "accountant",
    label: "Contabilidade",
    aliases: ["escritório de contabilidade", "contabilidade", "contador", "consultoria contábil", "abertura de empresa"],
    googleKeywords: ["contabilidade", "escritório de contabilidade", "contador"],
    osmTags: [{ office: "accountant" }],
    webQueries: ["contabilidade", "escritório contabilidade", "contador"],
  },
};

export class NicheResolver {
  /**
   * Resolves any input niche string into a structured NicheDefinition.
   */
  public resolveNiche(input: string): NicheDefinition {
    const norm = input.toLowerCase().trim();

    for (const def of Object.values(NICHE_TAXONOMY)) {
      if (
        def.id === norm ||
        def.label.toLowerCase().includes(norm) ||
        def.aliases.some((alias) => alias.toLowerCase().includes(norm) || norm.includes(alias.toLowerCase()))
      ) {
        return def;
      }
    }

    // Custom Write-in Niche Fallback
    return {
      id: `custom-${norm.replace(/\s+/g, "_")}`,
      label: input,
      aliases: [input, norm],
      googleKeywords: [input, norm],
      osmTags: [{ shop: "yes" }],
      webQueries: [input, norm],
    };
  }
}
