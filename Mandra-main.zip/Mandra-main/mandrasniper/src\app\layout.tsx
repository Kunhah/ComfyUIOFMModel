import type { Metadata } from "next";
import "./globals.css";
import { Sidebar } from "@/components/sidebar";
import { Header } from "@/components/header";

export const metadata: Metadata = {
  title: "MANDRA SNIPER AI — Sales Intelligence & AI SDR Platform",
  description: "Plataforma de Sales Intelligence e AI SDR para prospecção automatizada B2B.",
  robots: { index: false, follow: false },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR">
      <body className="min-h-screen bg-[#FAF8F4] text-[#1E2026] antialiased selection:bg-[#FF9E1B]/30 flex font-sans">
        <Sidebar />
        <div className="flex flex-1 flex-col pl-[260px] min-w-0">
          <Header />
          <main className="flex-1 p-8 overflow-y-auto">{children}</main>
        </div>
      </body>
    </html>
  );
}
