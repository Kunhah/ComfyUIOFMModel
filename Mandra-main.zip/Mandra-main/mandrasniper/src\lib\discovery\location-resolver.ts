import { resolveCity, searchCities, normalise, type City } from "@/lib/cities";
import type { BoundingBox } from "./geo-grid";

export interface ResolvedLocation {
  city: string;
  state: string;
  uf: string;
  country: string;
  formatted: string;
  lat: number;
  lon: number;
  bbox: BoundingBox;
  confidence: "HIGH" | "MEDIUM" | "LOW";
  source: "city_index" | "geocoding_api" | "fallback";
}

const RESOLVED_CACHE = new Map<string, ResolvedLocation>();

/**
 * Splits query string into city name and state code.
 */
function parseCityAndUf(input: string): { name: string; uf: string } {
  const parts = input.split(/[,/-]+/);
  const name = parts[0].trim();
  const rawUf = parts[1]?.trim().toUpperCase() || "";
  const uf = rawUf.length === 2 ? rawUf : "SP";
  return { name, uf };
}

export class LocationResolver {
  /**
   * Resolves any Brazilian city/location input into exact Lat, Lon, and geospatial BoundingBox.
   */
  public async resolveLocation(query: string): Promise<ResolvedLocation> {
    const normKey = normalise(query);
    if (RESOLVED_CACHE.has(normKey)) {
      return RESOLVED_CACHE.get(normKey)!;
    }

    const { name, uf } = parseCityAndUf(query);

    // 1. Check built-in br-cities.json index
    const staticCity = resolveCity(name, uf) || searchCities(name, 1)[0];
    if (staticCity) {
      const resolved: ResolvedLocation = {
        city: staticCity.name,
        state: staticCity.uf,
        uf: staticCity.uf,
        country: "Brasil",
        formatted: `${staticCity.name}, ${staticCity.uf}, Brasil`,
        lat: (staticCity.bbox.ymin + staticCity.bbox.ymax) / 2,
        lon: (staticCity.bbox.xmin + staticCity.bbox.xmax) / 2,
        bbox: staticCity.bbox,
        confidence: "HIGH",
        source: "city_index",
      };
      RESOLVED_CACHE.set(normKey, resolved);
      return resolved;
    }

    // 2. Geocoding API Fallback for cities not in static index (e.g. Cabreúva, SP)
    try {
      const geocodeUrl = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(
        `${name} ${uf} Brasil`
      )}`;

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 3500);

      const res = await fetch(geocodeUrl, {
        headers: { "User-Agent": "MandraSniper/1.0" },
        signal: controller.signal,
      });

      clearTimeout(timeout);

      if (res.ok) {
        const data = await res.json();
        if (data && data.length > 0) {
          const first = data[0];
          const lat = parseFloat(first.lat);
          const lon = parseFloat(first.lon);
          const bb = first.boundingbox; // [ymin, ymax, xmin, xmax]

          const bbox: BoundingBox = {
            ymin: parseFloat(bb[0]),
            ymax: parseFloat(bb[1]),
            xmin: parseFloat(bb[2]),
            xmax: parseFloat(bb[3]),
          };

          const resolved: ResolvedLocation = {
            city: first.name || name,
            state: uf,
            uf,
            country: "Brasil",
            formatted: `${first.name || name}, ${uf}, Brasil`,
            lat,
            lon,
            bbox,
            confidence: "HIGH",
            source: "geocoding_api",
          };

          RESOLVED_CACHE.set(normKey, resolved);
          return resolved;
        }
      }
    } catch (e) {
      console.warn("Geocoding API fallback error:", e);
    }

    // 3. Fallback BoundingBox around center if geocoding times out
    const defaultResolved: ResolvedLocation = {
      city: name,
      state: uf,
      uf,
      country: "Brasil",
      formatted: `${name}, ${uf}, Brasil`,
      lat: -23.3076,
      lon: -47.1324,
      bbox: { xmin: -47.19, xmax: -46.95, ymin: -23.40, ymax: -23.22 },
      confidence: "MEDIUM",
      source: "fallback",
    };

    RESOLVED_CACHE.set(normKey, defaultResolved);
    return defaultResolved;
  }
}
