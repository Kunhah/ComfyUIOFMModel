"use client";

import React, { useState, useRef, useEffect } from "react";
import { ChevronDown, Search, Check, Sparkles } from "lucide-react";

export const POPULAR_NICHES = [
  "Barbearias",
  "Clínicas de estética",
  "Dentistas",
  "Academias & Fitness",
  "Restaurantes & Bares",
  "Imobiliárias",
  "Oficinas mecânicas",
  "Pet Shops & Veterinárias",
  "Advogados & Advocacia",
  "Contabilidade",
  "Clínicas médicas",
  "Salões de beleza",
  "Pizzarias & Hamburguerias",
  "Estética automotiva",
  "Energia solar",
  "Instalação de ar-condicionado",
  "Arquitetura & Design",
  "Lojas de móveis",
];

export function NicheCombobox({
  value,
  onChange,
}: {
  value: string;
  onChange: (niche: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const filtered = POPULAR_NICHES.filter((n) =>
    n.toLowerCase().includes(search.toLowerCase())
  );

  const handleSelect = (niche: string) => {
    onChange(niche);
    setSearch("");
    setOpen(false);
  };

  return (
    <div ref={containerRef} className="relative w-full">
      <label className="block text-[11px] font-extrabold uppercase text-[#8E94A2] tracking-wider mb-1">
        O que você quer prospectar?
      </label>
      
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between rounded-xl border border-[#2B2E3C] bg-[#14161C] px-4 py-3 text-left text-sm font-bold text-white transition hover:border-[#FF9E1B] focus:border-[#FF9E1B]"
      >
        <span className="truncate">{value || "Selecione ou pesquise um nicho..."}</span>
        <ChevronDown className="size-4 text-[#8E94A2]" />
      </button>

      {open && (
        <div className="absolute top-full left-0 right-0 z-50 mt-2 rounded-2xl border border-[#2B2E3C] bg-[#14161C] p-3 shadow-2xl text-white space-y-2">
          <div className="relative">
            <Search className="absolute left-3 top-3 size-4 text-[#8E94A2]" />
            <input
              autoFocus
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Digite qualquer nicho (ex: Distribuidora de bebidas)..."
              className="w-full rounded-xl border border-[#222530] bg-[#1A1C24] py-2.5 pl-9 pr-3 text-xs font-semibold text-white outline-none focus:border-[#FF9E1B]"
            />
          </div>

          <div className="max-h-56 overflow-y-auto space-y-1 text-xs pr-1">
            {search && !filtered.includes(search) && (
              <button
                onClick={() => handleSelect(search)}
                className="w-full flex items-center justify-between rounded-xl px-3 py-2 text-left font-bold text-[#FF9E1B] bg-[#FF9E1B]/10 hover:bg-[#FF9E1B]/20"
              >
                <span>Usar personalizado: "{search}"</span>
                <Sparkles className="size-3.5" />
              </button>
            )}

            {filtered.map((niche) => (
              <button
                key={niche}
                onClick={() => handleSelect(niche)}
                className={`w-full flex items-center justify-between rounded-xl px-3 py-2 text-left font-medium transition ${
                  value === niche
                    ? "bg-[#1E212A] text-[#FF9E1B] font-bold"
                    : "text-gray-300 hover:bg-[#1A1C24] hover:text-white"
                }`}
              >
                <span>{niche}</span>
                {value === niche && <Check className="size-4 text-[#FF9E1B]" />}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
