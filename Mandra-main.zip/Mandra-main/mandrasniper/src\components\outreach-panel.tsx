"use client";

import React, { useState } from "react";
import {
  MessageCircle,
  Share2,
  Mail,
  PhoneCall,
  Sparkles,
  Copy,
  Check,
  X,
  Send,
  Loader2,
  ExternalLink,
} from "lucide-react";
import type { Lead } from "@/types";

export function OutreachPanel({
  lead,
  open,
  onClose,
}: {
  lead: Lead | null;
  open: boolean;
  onClose: () => void;
}) {
  const [channel, setChannel] = useState<"WHATSAPP" | "INSTAGRAM" | "EMAIL" | "CALL_SCRIPT">("WHATSAPP");
  const [tone, setTone] = useState<"DIRECT" | "CONSULTATIVE" | "CASUAL" | "EXECUTIVE">("CONSULTATIVE");
  const [objective, setObjective] = useState("LANDING_PAGE");
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [generatedScript, setGeneratedScript] = useState<string | null>(null);

  if (!open || !lead) return null;

  const generateScript = async () => {
    setLoading(true);
    setGeneratedScript(null);
    try {
      const res = await fetch("/api/ai/outreach", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          leadId: lead.id,
          channel,
          tone,
          objective,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setGeneratedScript(data.script.content);
      }
    } catch (e) {
      console.error("Outreach generation error:", e);
    } finally {
      setLoading(false);
    }
  };

  const whatsappPhone = lead.phone ? lead.phone.replace(/\D/g, "") : null;
  const whatsappUrl = whatsappPhone && generatedScript
    ? `https://wa.me/${whatsappPhone.startsWith("55") ? whatsappPhone : `55${whatsappPhone}`}?text=${encodeURIComponent(generatedScript)}`
    : null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs">
      <div className="w-full max-w-lg bg-white h-full shadow-2xl flex flex-col justify-between p-6 overflow-y-auto">
        <div className="space-y-5">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-[#ECE8E0] pb-4">
            <div className="flex items-center gap-3">
              <div className="flex size-9 items-center justify-center rounded-xl bg-[#FFF5E6] text-[#FF9E1B]">
                <Sparkles className="size-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-[#1E2026]">
                  Gerar Abordagem Personalizada
                </h3>
                <p className="text-xs text-[#6E7381]">
                  Para {lead.name} ({lead.city})
                </p>
              </div>
            </div>
            <button onClick={onClose} className="rounded-lg p-1 text-gray-400 hover:bg-gray-100">
              <X className="size-5" />
            </button>
          </div>

          {/* Facts Summary */}
          <div className="rounded-xl border border-[#E2DDD3] bg-[#FAF9F6] p-3.5 text-xs space-y-1">
            <div className="font-bold text-[#1E2026]">Fatos Confirmados do Lead:</div>
            <div className="text-[#6E7381]">
              - Avaliações: <strong>{lead.reviewsCount}</strong> (Nota {lead.rating})
              <br />
              - Website Status: <strong className="text-[#FF9E1B]">{lead.websiteStatus}</strong>
              <br />
              - Telefone: <strong>{lead.phone || "Desconhecido"}</strong>
            </div>
          </div>

          {/* 1. Channel Selector */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-[#1E2026] uppercase tracking-wider">
              Canal de Comunicação
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { id: "WHATSAPP", label: "WhatsApp", icon: MessageCircle },
                { id: "INSTAGRAM", label: "Instagram", icon: Share2 },
                { id: "EMAIL", label: "E-mail", icon: Mail },
                { id: "CALL_SCRIPT", label: "Ligação", icon: PhoneCall },
              ].map((item) => {
                const Icon = item.icon;
                const isSelected = channel === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setChannel(item.id as any)}
                    className={`flex flex-col items-center gap-1.5 rounded-xl border p-2.5 text-xs font-semibold transition ${
                      isSelected
                        ? "border-[#FF9E1B] bg-[#FFF5E6] text-[#FF9E1B]"
                        : "border-[#E2DDD3] bg-white text-[#6E7381] hover:bg-[#FAF8F4]"
                    }`}
                  >
                    <Icon className="size-4" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Tone Selector */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-[#1E2026] uppercase tracking-wider">
              Tom da Abordagem
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: "CONSULTATIVE", label: "Consultivo (Recomendado)" },
                { id: "DIRECT", label: "Direto ao Ponto" },
                { id: "CASUAL", label: "Casual / Relacionamento" },
                { id: "EXECUTIVE", label: "Executivo / Formal" },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setTone(item.id as any)}
                  className={`rounded-xl border px-3 py-2 text-xs font-semibold transition text-left ${
                    tone === item.id
                      ? "border-[#FF9E1B] bg-[#FFF5E6] text-[#FF9E1B]"
                      : "border-[#E2DDD3] bg-white text-[#6E7381] hover:bg-[#FAF8F4]"
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Generate Button */}
          <button
            onClick={generateScript}
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 rounded-xl bg-[#1C1F26] px-5 py-3 text-xs font-bold text-white hover:bg-[#2A2E38] transition shadow-sm disabled:opacity-50"
          >
            {loading ? <Loader2 className="size-4 animate-spin text-[#FF9E1B]" /> : <Sparkles className="size-4 text-[#FF9E1B]" />}
            <span>{loading ? "Gerando Mensagem Personalizada..." : "Gerar Mensagem com IA SDR"}</span>
          </button>

          {/* Generated Content Box */}
          {generatedScript && (
            <div className="space-y-3 pt-2">
              <div className="rounded-xl border border-[#E2DDD3] bg-[#FAF9F6] p-4 text-xs font-mono leading-relaxed text-[#1E2026] whitespace-pre-wrap">
                {generatedScript}
              </div>
            </div>
          )}
        </div>

        {/* Footer Action Buttons */}
        {generatedScript && (
          <div className="flex items-center justify-between border-t border-[#ECE8E0] pt-4 mt-6">
            <button
              onClick={() => {
                navigator.clipboard.writeText(generatedScript);
                setCopied(true);
                setTimeout(() => setCopied(false), 2000);
              }}
              className="flex items-center gap-1.5 rounded-xl border border-[#E2DDD3] bg-white px-4 py-2.5 text-xs font-bold text-[#1E2026] hover:bg-[#FAF8F4]"
            >
              {copied ? <Check className="size-4 text-emerald-600" /> : <Copy className="size-4" />}
              <span>{copied ? "Copiado!" : "Copiar Texto"}</span>
            </button>

            {channel === "WHATSAPP" && whatsappUrl && (
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 rounded-xl bg-[#25D366] px-5 py-2.5 text-xs font-bold text-white hover:bg-[#20bd5a] shadow-sm"
              >
                <MessageCircle className="size-4" />
                <span>Abrir WhatsApp</span>
                <ExternalLink className="size-3.5" />
              </a>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
