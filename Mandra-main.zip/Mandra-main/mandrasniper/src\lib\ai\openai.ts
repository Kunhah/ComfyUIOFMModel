import OpenAI from "openai";
import type { Lead, LeadInsight, OutreachScriptAI } from "@/types";
import type { AIProvider } from "./provider";
import { SYSTEM_PROMPTS } from "./prompts";
import {
  SearchPromptResultSchema,
  LeadInsightSchema,
  OutreachScriptSchema,
  type SearchPromptResult,
} from "./schemas";

export class OpenAIProvider implements AIProvider {
  private client: OpenAI | null = null;

  constructor() {
    const apiKey = process.env.OPENAI_API_KEY;
    if (apiKey && apiKey.trim().length > 0) {
      this.client = new OpenAI({ apiKey: apiKey.trim() });
    }
  }

  public isConfigured(): boolean {
    return this.client !== null;
  }

  public async interpretSearchPrompt(promptText: string): Promise<SearchPromptResult> {
    if (!this.client) {
      return this.fallbackInterpretSearchPrompt(promptText);
    }

    try {
      const response = await this.client.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: SYSTEM_PROMPTS.SEARCH_INTERPRETER },
          { role: "user", content: promptText },
        ],
        response_format: { type: "json_object" },
        temperature: 0.2,
      });

      const rawJson = response.choices[0]?.message?.content ?? "{}";
      const parsed = JSON.parse(rawJson);
      return SearchPromptResultSchema.parse(parsed);
    } catch (err) {
      console.warn("OpenAI prompt interpretation fallback:", err);
      return this.fallbackInterpretSearchPrompt(promptText);
    }
  }

  public async qualifyLead(lead: Lead): Promise<LeadInsight> {
    if (!this.client) {
      return this.fallbackQualifyLead(lead);
    }

    try {
      const promptPayload = {
        name: lead.name,
        category: lead.category,
        city: lead.city,
        state: lead.state,
        rating: lead.rating,
        reviewsCount: lead.reviewsCount,
        website: lead.website,
        websiteStatus: lead.websiteStatus,
        phone: lead.phone,
        socialUrl: lead.socialUrl,
        sniperScore: lead.sniperScore,
      };

      const response = await this.client.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: SYSTEM_PROMPTS.QUALIFIER_ENGINE },
          {
            role: "user",
            content: `Qualifique esta empresa usando estritamente seus fatos:\n${JSON.stringify(promptPayload, null, 2)}`,
          },
        ],
        response_format: { type: "json_object" },
        temperature: 0.3,
      });

      const rawJson = response.choices[0]?.message?.content ?? "{}";
      const parsed = JSON.parse(rawJson);
      return LeadInsightSchema.parse(parsed);
    } catch (err) {
      console.warn("OpenAI lead qualification fallback:", err);
      return this.fallbackQualifyLead(lead);
    }
  }

  public async generateOutreachScript(
    lead: Lead,
    channel: "WHATSAPP" | "INSTAGRAM" | "EMAIL" | "CALL_SCRIPT",
    tone: "DIRECT" | "CONSULTATIVE" | "CASUAL" | "EXECUTIVE",
    objective: string
  ): Promise<OutreachScriptAI> {
    if (!this.client) {
      return this.fallbackGenerateOutreachScript(lead, channel, tone, objective);
    }

    try {
      const promptPayload = {
        lead: {
          name: lead.name,
          category: lead.category,
          city: lead.city,
          rating: lead.rating,
          reviewsCount: lead.reviewsCount,
          websiteStatus: lead.websiteStatus,
          website: lead.website,
        },
        channel,
        tone,
        objective,
      };

      const response = await this.client.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: SYSTEM_PROMPTS.SDR_COPILOT },
          {
            role: "user",
            content: `Gere uma abordagem comercial personalizada:\n${JSON.stringify(promptPayload, null, 2)}`,
          },
        ],
        response_format: { type: "json_object" },
        temperature: 0.4,
      });

      const rawJson = response.choices[0]?.message?.content ?? "{}";
      const parsed = JSON.parse(rawJson);
      return OutreachScriptSchema.parse(parsed);
    } catch (err) {
      console.warn("OpenAI SDR script fallback:", err);
      return this.fallbackGenerateOutreachScript(lead, channel, tone, objective);
    }
  }

  public async queryCommandBar(
    queryText: string,
    contextLeads: Lead[]
  ): Promise<{ answer: string; matchingLeadIds: string[]; actionMessage?: string }> {
    const q = queryText.toLowerCase().trim();

    if (q.includes("sem site") || q.includes("sem website")) {
      const matching = contextLeads.filter(
        (l) => l.websiteStatus === "NO_WEBSITE" || !l.website
      );
      return {
        answer: `Encontrei ${matching.length} empresas sem website oficial registradas no sistema.`,
        matchingLeadIds: matching.map((l) => l.id),
        actionMessage: "Filtrado por: Sem Website",
      };
    }

    if (q.includes("score maior") || q.includes("score > 90") || q.includes("sniper")) {
      const matching = contextLeads.filter((l) => l.sniperScore >= 90);
      return {
        answer: `Encontrei ${matching.length} empresas com Sniper Score de elite (>= 90).`,
        matchingLeadIds: matching.map((l) => l.id),
        actionMessage: "Filtrado por: Sniper Score >= 90",
      };
    }

    if (q.includes("abordar primeiro") || q.includes("quem abordar")) {
      const matching = contextLeads
        .filter((l) => l.sniperScore >= 75)
        .slice(0, 5);
      return {
        answer: `Recomendo abordar prioritariamente os 5 leads mais quentes com pontuação Sniper elevada.`,
        matchingLeadIds: matching.map((l) => l.id),
        actionMessage: "Top 5 Abordagem Prioritária",
      };
    }

    // Default matching by city or category
    const matching = contextLeads.filter(
      (l) =>
        l.city.toLowerCase().includes(q) ||
        l.category.toLowerCase().includes(q) ||
        l.name.toLowerCase().includes(q)
    );

    return {
      answer:
        matching.length > 0
          ? `Encontrei ${matching.length} empresas correspondentes à busca "${queryText}".`
          : `Não encontrei nenhuma empresa com os termos "${queryText}". Tente buscar por cidade, nicho ou "empresas sem site".`,
      matchingLeadIds: matching.map((l) => l.id),
    };
  }

  // --- FALLBACK DETERMINISTIC PARSERS (DEMO MODE & SAFE FALLBACK) ---
  private fallbackInterpretSearchPrompt(promptText: string): SearchPromptResult {
    const text = promptText.toLowerCase();

    // Extract niche
    let niche = "estética";
    if (text.includes("academia") || text.includes("fitness")) niche = "academia";
    else if (text.includes("barbearia") || text.includes("barbeiro")) niche = "barbearia";
    else if (text.includes("dentista") || text.includes("odontologia") || text.includes("clínica odontológica")) niche = "dentista";
    else if (text.includes("estética") || text.includes("clínica de estética")) niche = "estética";
    else if (text.includes("restaurante") || text.includes("pizzaria")) niche = "restaurante";
    else if (text.includes("pet") || text.includes("pet shop") || text.includes("veterinária")) niche = "pet shop";
    else if (text.includes("auto") || text.includes("oficina")) niche = "oficina mecânica";

    // Extract location
    let location = "Campinas, SP";
    if (text.includes("sorocaba")) location = "Sorocaba, SP";
    else if (text.includes("jundiaí") || text.includes("jundiai")) location = "Jundiaí, SP";
    else if (text.includes("são paulo") || text.includes("sao paulo") || text.includes("sp")) location = "São Paulo, SP";
    else if (text.includes("curitiba")) location = "Curitiba, PR";
    else if (text.includes("belo horizonte")) location = "Belo Horizonte, MG";
    else if (text.includes("campinas")) location = "Campinas, SP";

    // Extract limit
    let limit = 50;
    const limitMatch = text.match(/(\d+)\s*(empresas|leads|clínicas|academias|dentistas|barbearias)?/);
    if (limitMatch && limitMatch[1]) {
      const parsedLimit = parseInt(limitMatch[1], 10);
      if (parsedLimit > 0 && parsedLimit <= 200) limit = parsedLimit;
    }

    // Extract reviews
    let minReviews = 0;
    const reviewsMatch = text.match(/(\d+)\s*(avaliações|reviews|ratings)/);
    if (reviewsMatch && reviewsMatch[1]) {
      minReviews = parseInt(reviewsMatch[1], 10);
    }

    // Extract conditions
    const requireInstagram = text.includes("instagram");
    const requireWhatsapp = text.includes("whatsapp");

    let websiteCondition: "missing" | "poor" | "broken" | "social" | "any" = "missing";
    if (text.includes("site ruim") || text.includes("antigo")) websiteCondition = "poor";
    else if (text.includes("sem site") || text.includes("sem website")) websiteCondition = "missing";
    else if (text.includes("só redes")) websiteCondition = "social";

    return {
      niche,
      location,
      radiusKm: 25,
      limit,
      minReviews,
      requireInstagram,
      requireWhatsapp,
      websiteCondition,
    };
  }

  private fallbackQualifyLead(lead: Lead): LeadInsight {
    const hasReviews = lead.reviewsCount >= 30;
    const noSite = lead.websiteStatus === "NO_WEBSITE" || !lead.website;

    const painPoints = [];
    if (noSite) {
      painPoints.push({
        problem: "Ausência total de website comercial próprio",
        evidence: `Empresa mapeada sem domínio registrado, dependente apenas de fichas públicas ou redes sociais`,
        confidence: 95,
      });
    }

    if (hasReviews && noSite) {
      painPoints.push({
        problem: "Demanda orgânica no Google desperdiçada sem página de captura",
        evidence: `${lead.reviewsCount} avaliações no Google com nota ${lead.rating}, porém sem link de agendamento próprio`,
        confidence: 90,
      });
    }

    return {
      summary: `${lead.name} possui excelente reputação local (${lead.reviewsCount} avaliações, nota ${lead.rating}), porém não tem landing page própria para retenção de clientes.`,
      painPoints,
      opportunities: [
        "Desenvolvimento de Landing Page de Alta Conversão focada em agendamentos pelo WhatsApp",
        "Configuração de rastreamento de conversão e Botão Flutuante de atendimento",
      ],
      recommendedOffer: "Landing Page de Alta Conversão com Agendamento WhatsApp",
      recommendedAngle: "Destacar a alta reputação no Google e o prejuízo de perder clientes por falta de página de agendamento.",
      icebreaker: `Vi que a ${lead.name} já tem ${lead.reviewsCount} avaliações excelentes no Google com nota ${lead.rating}, mas ainda não possui um site próprio para agendamentos.`,
      priority: lead.sniperScore >= 75 ? "HIGH" : "MEDIUM",
      confidenceScore: 90,
    };
  }

  private fallbackGenerateOutreachScript(
    lead: Lead,
    channel: "WHATSAPP" | "INSTAGRAM" | "EMAIL" | "CALL_SCRIPT",
    tone: "DIRECT" | "CONSULTATIVE" | "CASUAL" | "EXECUTIVE",
    objective: string
  ): OutreachScriptAI {
    const name = lead.name;
    const city = lead.city;
    const rating = lead.rating;
    const reviews = lead.reviewsCount;

    let content = "";

    if (channel === "WHATSAPP") {
      content = `Olá! Tudo bem? Sou da Mandra Sniper AI.\n\nEstava analisando a presença digital da ${name} em ${city} e vi que vocês construíram uma reputação incrível no Google com ${reviews} avaliações e nota ${rating}.\n\nPorém, notei que quem busca por ${lead.category} na região hoje não encontra uma página própria de agendamento da ${name}.\n\nDesenvolvemos uma estrutura simples e de alta conversão para transformar essas pesquisas no Google em clientes diretos no seu WhatsApp. Posso te mostrar sem compromisso em 2 minutos?`;
    } else if (channel === "INSTAGRAM") {
      content = `Olá equipe da ${name}! Acompanho o trabalho de vocês em ${city}. Vi que vocês têm ${reviews} avaliações nota ${rating} no Google, mas ainda estão sem site próprio de agendamento.\n\nMontei um modelo visual de página focada no público da região. Posso enviar o link por aqui para vocês darem uma olhada?`;
    } else if (channel === "EMAIL") {
      content = `Assunto: Oportunidade de captação digital para a ${name} em ${city}\n\nOlá,\n\nAnalisamos recentemente os principais estabelecimentos do segmento de ${lead.category} em ${city} e a ${name} se destaca com ${reviews} avaliações e nota ${rating} no Google.\n\nContudo, identificamos que a empresa ainda não possui um website oficial otimizado para conversão direta.\n\nCriamos um projeto sob medida para posicionar a ${name} no topo da região e dobrar o fluxo de contatos pelo WhatsApp.\n\nQuando seria um bom momento para conversarmos rapidamente esta semana?`;
    } else {
      content = `Script de Ligação para ${name}:\n1. Apresentação: "Olá, falo com o responsável comercial da ${name}?"\n2. Gancho de Fato: "Estava vendo a reputação de vocês no Google em ${city}, com ${reviews} avaliações nota ${rating}. Parabéns pelo trabalho!"\n3. Pergunta de Dor: "Percebi que vocês ainda não possuem um site próprio de agendamento. Como vocês captam hoje os clientes que pesquisam no Google?"\n4. Proposta: "Desenvolvemos páginas de agendamento em 48h. Posso enviar um exemplo de 2 minutos no WhatsApp de vocês?"`;
    }

    return {
      channel,
      tone,
      objective,
      content,
    };
  }
}
