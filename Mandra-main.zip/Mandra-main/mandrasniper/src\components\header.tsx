"use client";

import React, { useState } from "react";
import { Bell, Command, Search, Sparkles, User, ChevronDown } from "lucide-react";
import { AiCommandBar } from "./ai-command-bar";

export function Header() {
  const [commandBarOpen, setCommandBarOpen] = useState(false);

  return (
    <>
      <header className="flex h-16 items-center justify-between border-b border-[#ECE8E0] bg-[#FAF8F4] px-8 sticky top-0 z-30">
        {/* Left: AI Command Bar Launcher Button */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => setCommandBarOpen(true)}
            className="flex items-center gap-3 rounded-xl border border-[#E2DDD3] bg-white px-4 py-2 text-xs text-[#6E7381] hover:border-[#FF9E1B] hover:text-[#1E2026] transition shadow-2xs"
          >
            <Sparkles className="size-4 text-[#FF9E1B]" />
            <span className="font-medium">Perguntar à IA ou buscar...</span>
            <span className="rounded-md bg-[#FAF8F4] border border-[#E2DDD3] px-1.5 py-0.5 font-mono text-[10px] font-bold text-[#1E2026]">
              Ctrl + K
            </span>
          </button>
        </div>

        {/* Right: Notifications, User Profile & Organization */}
        <div className="flex items-center gap-4">
          {/* Notifications */}
          <button className="relative rounded-full p-2 text-[#6E7381] hover:bg-[#EFECE6] hover:text-[#1E2026] transition">
            <Bell className="size-4.5" />
            <span className="absolute top-1.5 right-1.5 size-2 rounded-full bg-[#FF9E1B]" />
          </button>

          {/* User Profile */}
          <div className="flex items-center gap-3 border-l border-[#ECE8E0] pl-4">
            <div className="flex size-8 items-center justify-center rounded-full bg-[#181A20] text-xs font-bold text-[#FF9E1B] shadow-xs">
              M
            </div>
            <div className="hidden text-left sm:block">
              <div className="text-xs font-bold text-[#1E2026]">
                Guilherme Silva
              </div>
              <div className="text-[10px] font-semibold text-[#FF9E1B] uppercase tracking-wider">
                SaaS Owner
              </div>
            </div>
            <ChevronDown className="size-3.5 text-[#858B98]" />
          </div>
        </div>
      </header>

      {/* AI Command Bar Modal */}
      <AiCommandBar open={commandBarOpen} onOpenChange={setCommandBarOpen} />
    </>
  );
}
