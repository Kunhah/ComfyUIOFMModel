#!/usr/bin/env node
/**
 * Build the local Brazil places extract that the app queries.
 *
 * Run: npm run sync        (from Prospector/)
 *
 * Why this exists: the Overture places dataset is a single unpartitioned set of
 * Parquet files covering the planet. Querying it over S3 per search measured
 * 90s–230s and was wildly variable, because row-group pruning still requires
 * fetching metadata for everything. Pulling Brazil once, filtered to the
 * categories we actually prospect, turns every subsequent search into a local
 * sub-second scan.
 *
 * Re-run it when Overture publishes a new release (roughly monthly) or when you
 * add a niche to src/lib/niches.ts — new categories are not in the existing
 * extract and would silently return nothing.
 */
import {
  mkdirSync,
  existsSync,
  renameSync,
  statSync,
  unlinkSync,
  writeFileSync,
} from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { DuckDBInstance } from "@duckdb/node-api";
import { NICHES, allCategories } from "../src/lib/niches.ts";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..");

const RELEASE = process.env.OVERTURE_RELEASE ?? "2026-07-22.0";
const SOURCE = `s3://overturemaps-us-west-2/release/${RELEASE}/theme=places/type=place/*`;

// Mainland + offshore Brazil. Generous on purpose: this bbox only exists so
// Parquet row-group statistics can skip other continents. It is *not* a country
// filter — it also covers Paraguay, Uruguay, Bolivia and chunks of Argentina,
// Chile, Peru and Colombia, which is why `country = 'BR'` below is required.
const BR_BBOX = { xmin: -74.0, xmax: -34.0, ymin: -34.0, ymax: 5.5 };

// The 27 federative units. Overture's `region` is free text: it arrives as "MG",
// sometimes "BR-MG", and sometimes as junk ("X", "S", a full state name, or a
// foreign province). Anything not on this list becomes NULL rather than being
// kept as a bogus state code that no city could ever match.
const UFS = [
  "AC",
  "AL",
  "AM",
  "AP",
  "BA",
  "CE",
  "DF",
  "ES",
  "GO",
  "MA",
  "MG",
  "MS",
  "MT",
  "PA",
  "PB",
  "PE",
  "PI",
  "PR",
  "RJ",
  "RN",
  "RO",
  "RR",
  "RS",
  "SC",
  "SE",
  "SP",
  "TO",
];

// From the registry's own reverse map, which is also what guarantees no category
// is claimed by two niches.
const categories = allCategories();
for (const c of categories) {
  if (!/^[a-z0-9_]+$/.test(c))
    throw new Error(`Invalid category in niches.ts: ${c}`);
}

const outDir = path.join(root, "data");
const out = path.join(outDir, "br-leads.parquet");
// Write to a temp path and rename, so an interrupted run can't leave a truncated
// Parquet file behind that the app would then fail to open.
const tmp = `${out}.partial`;

mkdirSync(outDir, { recursive: true });
if (existsSync(tmp)) unlinkSync(tmp);

console.log(`Overture release : ${RELEASE}`);
console.log(
  `Niches           : ${NICHES.length} (${categories.length} categories)`,
);
console.log(`Output           : ${out}`);
console.log("");
console.log(
  "Scanning Overture over S3. This pulls a few GB of Parquet and takes",
);
console.log(
  "roughly 5-20 minutes depending on your connection. It runs once per release.",
);
console.log("");

const started = Date.now();
const instance = await DuckDBInstance.create(":memory:");
const db = await instance.connect();

await db.run("INSTALL httpfs");
await db.run("LOAD httpfs");
await db.run("SET s3_region='us-west-2'");
// Public bucket: blank the credentials or DuckDB signs with ambient AWS env vars and 403s.
await db.run("SET s3_access_key_id=''");
await db.run("SET s3_secret_access_key=''");
// We re-sort on write anyway; not preserving order lets DuckDB stream in parallel.
await db.run("SET preserve_insertion_order=false");

const quoted = categories.map((c) => `'${c}'`).join(", ");
const quotedUfs = UFS.map((u) => `'${u}'`).join(", ");

// Normalised state code, or NULL when Overture's region field is unusable.
const ufExpr = `nullif(upper(replace(coalesce(addresses[1].region, ''), 'BR-', '')), '')`;

// Some records put the state inside the city field — "Belo Horizonte, MG",
// "São Paulo SP", "Curitiba - PR". Left alone each one becomes its own city in
// the index, a near-duplicate of the real entry holding a handful of businesses.
// Splitting it here both cleans the name and, when `region` was empty, recovers
// the state from it.
const tail = `upper(regexp_extract(trim(addresses[1].locality), '[,\\s-]+([A-Za-z]{2})$', 1))`;
// Only when the two agree, so a contradictory record can't be silently rewritten.
const splittable = `${tail} IN (${quotedUfs})
       AND (${ufExpr} IS NULL OR ${ufExpr} = ${tail})
       AND length(regexp_replace(trim(addresses[1].locality), '[,\\s-]+[A-Za-z]{2}$', '')) >= 3`;

await db.run(
  `COPY (
     SELECT
       id,
       names.primary            AS name,
       categories.primary       AS category,
       addresses[1].freeform    AS address,
       CASE WHEN ${splittable}
            THEN trim(regexp_replace(trim(addresses[1].locality), '[,\\s-]+[A-Za-z]{2}$', ''))
            ELSE trim(addresses[1].locality) END AS city,
       CASE WHEN ${ufExpr} IN (${quotedUfs}) THEN ${ufExpr}
            WHEN ${splittable} THEN ${tail} END AS uf,
       phones[1]                AS phone,
       websites[1]              AS website,
       socials[1]               AS social,
       emails[1]                AS email,
       ((bbox.xmin + bbox.xmax) / 2)::FLOAT AS lon,
       ((bbox.ymin + bbox.ymax) / 2)::FLOAT AS lat,
       confidence::FLOAT        AS confidence
     FROM read_parquet('${SOURCE}', hive_partitioning = 1)
     WHERE bbox.xmin BETWEEN ${BR_BBOX.xmin} AND ${BR_BBOX.xmax}
       AND bbox.ymin BETWEEN ${BR_BBOX.ymin} AND ${BR_BBOX.ymax}
       -- The bbox spills into seven neighbouring countries. Without this,
       -- Asunción, Santiago, Córdoba, Santa Cruz de la Sierra and Rosario all
       -- land in the extract: measured at 284k foreign businesses, most of them
       -- with no region set, polluting the city index with cities we can't sell to.
       AND addresses[1].country = 'BR'
       AND names.primary IS NOT NULL
       AND addresses[1].locality IS NOT NULL
       AND trim(addresses[1].locality) <> ''
       AND categories.primary IN (${quoted})
     -- Sorting by city clusters each municipality into contiguous row groups, so
     -- a city query touches a handful of them instead of the whole file.
     ORDER BY uf, city
   ) TO '${tmp.replace(/'/g, "''")}' (FORMAT PARQUET, COMPRESSION ZSTD)`,
);

renameSync(tmp, out);

const stats = await db.runAndReadAll(
  `SELECT count(*) AS n_rows,
          count(DISTINCT city || '/' || coalesce(uf, '?')) AS cities,
          count(*) FILTER (WHERE website IS NULL OR website = '') AS no_site,
          count(*) FILTER (WHERE uf IS NULL) AS no_uf
   FROM read_parquet('${out.replace(/'/g, "''")}')`,
);
const s = stats.getRowObjectsJS()[0];
const mb = (statSync(out).size / 1024 / 1024).toFixed(0);
const mins = ((Date.now() - started) / 60000).toFixed(1);
const br = (v) => Number(v).toLocaleString("pt-BR");

// Records which release this file came from. Nothing about a Parquet file says
// that, so without it a bumped OVERTURE_RELEASE leaves the app reporting one
// release in the header while querying an extract built from another, with no way
// to notice. scripts/start.mjs reads this and warns.
writeFileSync(
  path.join(outDir, "extract.json"),
  JSON.stringify(
    {
      release: RELEASE,
      rows: Number(s.n_rows),
      noWebsite: Number(s.no_site),
      categories: categories.length,
      builtAt: new Date().toISOString(),
    },
    null,
    2,
  ),
);

console.log("");
console.log(`Done in ${mins} min.`);
console.log(`  businesses : ${br(s.n_rows)}`);
console.log(`  cities     : ${br(s.cities)}`);
console.log(`  no website : ${br(s.no_site)}`);
console.log(`  no state   : ${br(s.no_uf)} (reachable via bbox + locality)`);
console.log(`  file size  : ${mb} MB`);
console.log("");
console.log("Next: npm run cities   (rebuilds the searchable city index)");
