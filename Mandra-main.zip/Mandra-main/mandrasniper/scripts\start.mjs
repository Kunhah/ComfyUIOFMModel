#!/usr/bin/env node
/**
 * One command to get the tool running: check what's missing, do only that, then
 * start the dev server.
 *
 * Run: npm run up        (from Prospector/, or `npm run prospector` from the root)
 *
 * Every check answers a specific way this has actually gone wrong, rather than
 * just testing that files exist:
 *
 *   - deps missing            -> npm install
 *   - extract missing/empty   -> npm run sync
 *   - extract truncated       -> npm run sync  (a killed sync used to leave a file
 *                                that opens fine and then fails mid-query)
 *   - city index missing      -> npm run cities
 *   - city index older than
 *     the extract             -> npm run cities  (the counts and the set of
 *                                searchable names both come from the extract, so
 *                                syncing without rebuilding leaves the picker
 *                                describing data that is no longer there)
 *   - extract built from a
 *     different release       -> warn (the header would claim one release while
 *                                querying another)
 *   - port already taken      -> say it's already running and stop
 *
 * Flags:
 *   --check        report what would happen and exit, change nothing
 *   --force-sync   re-download the extract even if it looks fine
 *   --port <n>     override the port (default 3001)
 */
import { existsSync, readFileSync, statSync, unlinkSync } from "node:fs";
import { createRequire } from "node:module";
import net from "node:net";
import path from "node:path";
import { spawn, spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..");
const repoRoot = path.resolve(root, "..");

const argv = process.argv.slice(2);
const has = (flag) => argv.includes(flag);
const CHECK_ONLY = has("--check");
const FORCE_SYNC = has("--force-sync");
const PORT = (() => {
  const i = argv.indexOf("--port");
  const v = i >= 0 ? Number(argv[i + 1]) : NaN;
  return Number.isInteger(v) && v > 0 && v < 65536 ? v : 3001;
})();

const RELEASE = process.env.OVERTURE_RELEASE ?? "2026-07-22.0";
const EXTRACT = path.join(root, "data", "br-leads.parquet");
const PARTIAL = `${EXTRACT}.partial`;
const MANIFEST = path.join(root, "data", "extract.json");
const CITIES = path.join(root, "src", "data", "br-cities.json");
const NPM = process.platform === "win32" ? "npm.cmd" : "npm";

const br = (n) => Number(n).toLocaleString("pt-BR");
const mb = (bytes) => `${(bytes / 1024 / 1024).toFixed(0)} MB`;

let ok = true;
const say = (icon, text) => console.log(`${icon} ${text}`);
const good = (t) => say("  ok  ", t);
const warn = (t) => say(" warn ", t);
const todo = (t) => {
  ok = false;
  say(" ...  ", t);
};

console.log("Atlas Prospector\n");

// --- 1. dependencies ---------------------------------------------------------
// Resolved rather than checked as a directory: npm workspaces hoist to the repo
// root, so Prospector/node_modules may legitimately not exist at all.
const require_ = createRequire(import.meta.url);
let depsMissing = false;
try {
  require_.resolve("@duckdb/node-api");
  good("dependências instaladas");
} catch {
  depsMissing = true;
  todo("dependências ausentes — vou rodar npm install");
}

// --- 2. the Brazil extract ---------------------------------------------------
let needSync = FORCE_SYNC;
if (FORCE_SYNC) {
  todo("--force-sync pedido — vou baixar o extrato de novo");
} else if (!existsSync(EXTRACT)) {
  needSync = true;
  todo("extrato do Brasil ausente — vou rodar npm run sync (~2 min)");
} else {
  const size = statSync(EXTRACT).size;
  if (size < 1024 * 1024) {
    needSync = true;
    todo(
      `extrato com apenas ${mb(size)} — parece incompleto, vou baixar de novo`,
    );
  } else if (depsMissing) {
    // Can't open it without DuckDB; re-checked after install below.
    good(
      `extrato presente (${mb(size)}) — conteúdo será verificado após o install`,
    );
  } else {
    const rows = await countRows(EXTRACT);
    if (rows === null) {
      needSync = true;
      todo("extrato ilegível (download interrompido?) — vou baixar de novo");
    } else if (rows === 0) {
      needSync = true;
      todo("extrato sem nenhum negócio — vou baixar de novo");
    } else {
      good(`extrato: ${br(rows)} negócios (${mb(size)})`);
    }
  }
}

// A leftover .partial is a sync that was killed. Harmless but confusing, and it
// costs the same disk as the real thing.
if (existsSync(PARTIAL)) {
  warn(
    `br-leads.parquet.partial de uma sync interrompida — ${
      CHECK_ONLY ? "seria removido" : "removido"
    }`,
  );
  if (!CHECK_ONLY) unlinkSync(PARTIAL);
}

// --- 3. release match --------------------------------------------------------
// Only checkable when the extract carries a manifest; older extracts don't, and
// a missing manifest is not an error.
if (!needSync && existsSync(MANIFEST)) {
  try {
    const m = JSON.parse(readFileSync(MANIFEST, "utf8"));
    if (m.release && m.release !== RELEASE) {
      warn(
        `extrato é do release ${m.release}, mas OVERTURE_RELEASE é ${RELEASE}. ` +
          `Rode npm run sync para alinhar, ou ajuste a variável.`,
      );
    } else if (m.release) {
      good(`release ${m.release}`);
    }
  } catch {
    warn("data/extract.json ilegível — ignorando a checagem de release");
  }
}

// --- 4. the searchable city index -------------------------------------------
let needCities = needSync;
if (needSync) {
  todo("índice de cidades será reconstruído depois da sync");
} else if (!existsSync(CITIES)) {
  needCities = true;
  todo("índice de cidades ausente — vou rodar npm run cities");
} else {
  let cities = null;
  try {
    const parsed = JSON.parse(readFileSync(CITIES, "utf8"));
    if (
      Array.isArray(parsed) &&
      parsed.length > 0 &&
      Array.isArray(parsed[0])
    ) {
      cities = parsed;
    }
  } catch {
    /* handled below */
  }

  if (cities === null) {
    needCities = true;
    todo("índice de cidades corrompido — vou reconstruir");
  } else if (
    existsSync(EXTRACT) &&
    statSync(EXTRACT).mtimeMs > statSync(CITIES).mtimeMs
  ) {
    needCities = true;
    todo("índice de cidades mais antigo que o extrato — vou reconstruir");
  } else {
    const reach = cities.reduce((a, c) => a + (Number(c[7]) || 0), 0);
    good(`${br(cities.length)} cidades · ${br(reach)} negócios sem site`);
  }
}

// --- 5. port -----------------------------------------------------------------
const portBusy = await inUse(PORT);
if (portBusy) {
  warn(`porta ${PORT} já está em uso`);
}

// --- report / act ------------------------------------------------------------
console.log("");

if (CHECK_ONLY) {
  // A busy port is not a missing setup step — it almost always means the thing is
  // already up. Reporting "faltam passos" for it sent you looking for work that
  // didn't exist, so the two are kept separate, and only real gaps fail the exit
  // code (which is what makes this usable in a precondition check).
  if (!ok) {
    console.log("Faltam passos (marcados com ... acima).");
    console.log("Rode npm run up para executá-los e subir o servidor.");
  } else if (portBusy) {
    console.log(`Tudo pronto — e já está rodando: http://localhost:${PORT}`);
  } else {
    console.log("Tudo pronto. Rode: npm run up");
  }
  process.exit(ok ? 0 : 1);
}

if (portBusy) {
  // Almost always means you already have it open in another terminal, which is
  // not a failure worth an error exit.
  console.log(`Já está rodando: http://localhost:${PORT}`);
  console.log(`Para reiniciar:  kill $(lsof -ti :${PORT})`);
  process.exit(0);
}

if (depsMissing) run(NPM, ["install"], repoRoot, "Instalando dependências");
if (needSync)
  run(
    process.execPath,
    [path.join(here, "sync-places.mjs")],
    root,
    "Baixando o extrato do Brasil",
  );
if (needCities)
  run(
    process.execPath,
    [path.join(here, "build-city-index.mjs")],
    root,
    "Montando o índice de cidades",
  );

console.log(`\nSubindo em http://localhost:${PORT}\n`);
const dev = spawn(...devCommand(), { cwd: root, stdio: "inherit" });
// Ctrl+C reaches the child through the shared process group; this only makes sure
// our own exit code matches its fate rather than always being 0.
dev.on("exit", (code, signal) => process.exit(signal ? 1 : (code ?? 0)));

// --- helpers -----------------------------------------------------------------

/**
 * Row count straight from the Parquet footer — no full scan, so this is fast even
 * on the 120MB extract. Returns null when the file can't be read at all, which is
 * what a half-downloaded file looks like.
 */
async function countRows(file) {
  try {
    const { DuckDBInstance } = await import("@duckdb/node-api");
    const db = await (await DuckDBInstance.create(":memory:")).connect();
    const reader = await db.runAndReadAll(
      `SELECT count(*) AS n FROM read_parquet('${file.replace(/'/g, "''")}')`,
    );
    return Number(reader.getRowObjectsJS()[0].n);
  } catch {
    return null;
  }
}

/**
 * Launch Next directly rather than through `npm run dev`.
 *
 * The dev script hardcodes `--port 3001`, so forwarding a port through npm gave
 * `next dev --port 3001 --port 3001` — fine by luck at the default and wrong the
 * moment you pass --port. Resolving the binary also drops a layer of npm process
 * between Ctrl+C and the server. Falls back to npm if the resolve fails, since a
 * launcher that can't launch is worse than one that's a bit indirect.
 */
function devCommand() {
  try {
    return [
      process.execPath,
      [require_.resolve("next/dist/bin/next"), "dev", "--port", String(PORT)],
    ];
  } catch {
    return [NPM, ["run", "dev", "--", "--port", String(PORT)]];
  }
}

function inUse(port) {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.once("error", (err) =>
      resolve(err.code === "EADDRINUSE" || err.code === "EACCES"),
    );
    server.once("listening", () => server.close(() => resolve(false)));
    server.listen(port, "127.0.0.1");
  });
}

function run(cmd, args, cwd, label) {
  console.log(`— ${label}...\n`);
  const r = spawnSync(cmd, args, { cwd, stdio: "inherit" });
  if (r.status !== 0) {
    console.error(`\n${label} falhou. Nada foi iniciado.`);
    process.exit(r.status ?? 1);
  }
  console.log("");
}
