import Link from "next/link";
import { MandraLogo } from "@/components/mandra-logo";
import { StatusPicker } from "@/components/status-picker";
import {
  filtersToQuery,
  historyFacets,
  nicheBreakdown,
  parseFilters,
  queryHistory,
} from "@/lib/history";
import { NICHES, findNiche, nichesByGroup } from "@/lib/niches";
import { outreachMessage, whatsappUrl } from "@/lib/score";
import { LEAD_STATUSES, type LeadStatus } from "@/lib/types";

/**
 * Everything the tool has ever found, read back out of SQLite.
 *
 * The board on `/` only ever shows the search you just ran, so before this page
 * existed the history was write-only — accumulating on every search with no way
 * to look at it. This is the read side.
 *
 * Filters live entirely in the query string and the whole thing is a GET form, so
 * a view is a shareable URL and works with JavaScript off. The only client-side
 * piece is the status dropdown, which has to POST.
 */

export const dynamic = "force-dynamic";

const fmt = (n: number): string => n.toLocaleString("pt-BR");

const STATUS_LABEL: Record<LeadStatus, string> = {
  novo: "novo",
  contatado: "contatado",
  respondeu: "respondeu",
  cliente: "cliente",
  descartado: "descartado",
};

const SORTS: { value: string; label: string }[] = [
  { value: "score", label: "Maior score" },
  { value: "recent", label: "Encontrado por último" },
  { value: "oldest", label: "Encontrado primeiro" },
  { value: "name", label: "Nome (A-Z)" },
];

export default async function HistoryPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const filters = parseFilters(await searchParams);
  const facets = historyFacets(filters);
  const page = queryHistory({ ...filters, perPage: 100 });
  const byNiche = nicheBreakdown(filters);

  const nicheLabel = (slug: string | null): string =>
    NICHES.find((n) => n.slug === slug)?.label ?? slug ?? "—";

  const link = (o: Parameters<typeof filtersToQuery>[1]) =>
    `/historico${filtersToQuery(filters, { ...o, page: 1 })}`;

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[#1E2026]">
            Histórico Local (Leads Encontrados)
          </h1>
          <p className="mt-1 text-sm text-[#6E7381]">
            Tudo o que já foi encontrado e salvo em <code className="bg-[#EFECE6] px-1.5 py-0.5 rounded text-xs text-[#1E2026]">data/prospector.db</code>.
          </p>
        </div>
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-xs font-semibold text-[#FF9E1B] hover:underline"
        >
          ← Voltar para a busca
        </Link>
      </div>

      {facets.total === 0 && !hasFilters(filters) ? (
        <p className="border-line bg-surface text-fg-muted rounded-lg border px-4 py-10 text-center text-sm">
          Nada salvo ainda. Faça uma busca em{" "}
          <Link href="/" className="text-brand hover:underline">
            /
          </Link>{" "}
          e os negócios encontrados aparecem aqui.
        </p>
      ) : (
        <>
          {/* GET, so submitting only changes the URL. */}
          <form
            method="GET"
            action="/historico"
            className="border-line bg-surface mb-5 rounded-xl border p-4"
          >
            <div className="grid gap-3 md:grid-cols-[1fr_auto_auto_auto_auto]">
              <Field label="Buscar">
                <input
                  name="q"
                  defaultValue={filters.q ?? ""}
                  placeholder="nome ou endereço"
                  className="bg-surface-2 border-line focus:border-brand w-full rounded-md border px-3 py-2 text-sm outline-none"
                />
              </Field>
              <Field label="Nicho">
                <select
                  name="niche"
                  defaultValue={filters.niche ?? ""}
                  className="bg-surface-2 border-line focus:border-brand rounded-md border px-3 py-2 text-sm outline-none"
                >
                  <option value="">todos</option>
                  {nichesByGroup().map((g) => {
                    // Only niches you actually have leads in — a dropdown of 33
                    // where most select nothing is worse than a short honest one.
                    const present = g.niches.filter((n) =>
                      facets.niches.some((f) => f.niche === n.slug),
                    );
                    if (present.length === 0) return null;
                    return (
                      <optgroup key={g.group} label={g.group}>
                        {present.map((n) => (
                          <option key={n.slug} value={n.slug}>
                            {n.label} (
                            {fmt(
                              facets.niches.find((f) => f.niche === n.slug)
                                ?.count ?? 0,
                            )}
                            )
                          </option>
                        ))}
                      </optgroup>
                    );
                  })}
                </select>
              </Field>
              <Field label="Cidade">
                <select
                  name="city"
                  defaultValue={filters.city ?? ""}
                  className="bg-surface-2 border-line focus:border-brand rounded-md border px-3 py-2 text-sm outline-none"
                >
                  <option value="">todas</option>
                  {facets.cities.map((c) => (
                    <option key={`${c.city}-${c.uf}`} value={c.city}>
                      {c.city} — {c.uf} ({fmt(c.count)})
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Situação">
                <select
                  name="status"
                  defaultValue={filters.status ?? ""}
                  className="bg-surface-2 border-line focus:border-brand rounded-md border px-3 py-2 text-sm outline-none"
                >
                  <option value="">todas</option>
                  {LEAD_STATUSES.map((s) => (
                    <option key={s} value={s}>
                      {STATUS_LABEL[s]} (
                      {fmt(
                        facets.byStatus.find((b) => b.status === s)?.count ?? 0,
                      )}
                      )
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Ordenar">
                <select
                  name="sort"
                  defaultValue={filters.sort ?? "score"}
                  className="bg-surface-2 border-line focus:border-brand rounded-md border px-3 py-2 text-sm outline-none"
                >
                  {SORTS.map((s) => (
                    <option key={s.value} value={s.value}>
                      {s.label}
                    </option>
                  ))}
                </select>
              </Field>
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-4 text-sm">
              <label className="flex cursor-pointer items-center gap-2">
                <input
                  type="checkbox"
                  name="nosite"
                  value="1"
                  defaultChecked={filters.onlyNoSite}
                  className="accent-brand"
                />
                Só quem não tem site
              </label>
              <label className="flex cursor-pointer items-center gap-2">
                <input
                  type="checkbox"
                  name="wa"
                  value="1"
                  defaultChecked={filters.onlyWhatsapp}
                  className="accent-brand"
                />
                Só com WhatsApp
              </label>
              <button
                type="submit"
                className="bg-brand ml-auto rounded-md px-4 py-2 text-sm font-medium text-white"
              >
                Aplicar
              </button>
              {hasFilters(filters) && (
                <Link
                  href="/historico"
                  className="text-fg-muted hover:text-fg text-sm"
                >
                  limpar
                </Link>
              )}
            </div>
          </form>

          <div className="mb-4 flex flex-wrap items-end justify-between gap-4">
            <div className="flex flex-wrap gap-6">
              <Stat label="no filtro" value={fmt(facets.total)} />
              <Stat label="sem site" value={fmt(facets.noSite)} />
              <Stat label="com whatsapp" value={fmt(facets.whatsapp)} />
              {facets.byStatus
                .filter((s) => s.status !== "novo" && s.count > 0)
                .map((s) => (
                  <Stat
                    key={s.status}
                    label={STATUS_LABEL[s.status]}
                    value={fmt(s.count)}
                  />
                ))}
            </div>
            {/* Exports every matching row, not just this page. */}
            <a
              href={`/api/history/export${filtersToQuery(filters, { page: 1 })}`}
              className="border-line bg-surface-2 hover:border-brand rounded-md border px-3 py-2 text-sm"
            >
              Baixar CSV ({fmt(facets.total)})
            </a>
          </div>

          {/* Per-niche breakdown. Sits above the rows because "which niche do I
              work next" is the question you arrive with; the row list answers
              "who exactly", which only matters once that's decided. */}
          {byNiche.length > 1 && (
            <details
              open={!filters.niche}
              className="border-line bg-surface mb-4 rounded-xl border"
            >
              <summary className="cursor-pointer px-4 py-3 text-sm font-medium">
                Por nicho{" "}
                <span className="text-fg-muted font-normal">
                  ({fmt(byNiche.length)})
                </span>
              </summary>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-sm">
                  <thead>
                    <tr className="text-fg-muted border-line border-t text-left text-xs tracking-wide uppercase">
                      <th className="px-4 py-2 font-medium">Nicho</th>
                      <th className="px-3 py-2 text-right font-medium">
                        Leads
                      </th>
                      <th className="px-3 py-2 text-right font-medium">
                        Sem site
                      </th>
                      <th className="px-3 py-2 text-right font-medium">
                        WhatsApp
                      </th>
                      <th className="px-3 py-2 text-right font-medium">
                        Trabalhados
                      </th>
                      <th className="px-4 py-2 font-medium"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {byNiche.map((n) => (
                      <tr key={n.niche} className="border-line border-t">
                        <td className="px-4 py-2">
                          <span className="font-medium">
                            {nicheLabel(n.niche)}
                          </span>
                          <span className="text-fg-muted ml-2 text-xs">
                            {findNiche(n.niche)?.group ?? ""}
                          </span>
                        </td>
                        <td className="tnum px-3 py-2 text-right">
                          {fmt(n.total)}
                        </td>
                        <td className="tnum px-3 py-2 text-right">
                          {fmt(n.noSite)}
                        </td>
                        <td className="tnum text-brand px-3 py-2 text-right">
                          {fmt(n.whatsapp)}
                        </td>
                        <td className="tnum text-fg-muted px-3 py-2 text-right">
                          {n.worked > 0 ? fmt(n.worked) : "—"}
                        </td>
                        <td className="px-4 py-2 text-right">
                          <Link
                            href={link({ niche: n.niche })}
                            className="text-brand text-xs hover:underline"
                          >
                            abrir
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </details>
          )}

          {page.leads.length === 0 ? (
            <p className="border-line bg-surface text-fg-muted rounded-lg border px-4 py-10 text-center text-sm">
              Nenhum negócio do histórico com esses filtros.
            </p>
          ) : (
            <div className="border-line overflow-x-auto rounded-xl border">
              <table className="w-full border-collapse text-sm">
                <thead>
                  <tr className="bg-surface-2 text-fg-muted text-left text-xs tracking-wide uppercase">
                    <th className="w-16 px-3 py-2.5 font-medium">Score</th>
                    <th className="px-3 py-2.5 font-medium">Negócio</th>
                    <th className="px-3 py-2.5 font-medium">Onde</th>
                    <th className="px-3 py-2.5 font-medium">Visto</th>
                    <th className="w-40 px-3 py-2.5 font-medium">Situação</th>
                    <th className="w-32 px-3 py-2.5 font-medium">Contato</th>
                  </tr>
                </thead>
                <tbody>
                  {page.leads.map((l) => {
                    const wa = whatsappUrl(l.phone, outreachMessage(l));
                    return (
                      <tr
                        key={l.id}
                        className="border-line hover:bg-surface/60 border-t"
                      >
                        <td className="px-3 py-2.5 align-top">
                          <span className="border-warm/40 text-warm tnum inline-block rounded border px-1.5 py-0.5 text-xs font-semibold">
                            {l.score}
                          </span>
                        </td>
                        <td className="px-3 py-2.5 align-top">
                          <div className="font-medium">{l.name}</div>
                          <div className="text-fg-muted text-xs">
                            {l.category}
                            {l.website ? " · tem site" : ""}
                          </div>
                        </td>
                        <td className="text-fg-muted px-3 py-2.5 align-top">
                          <div>{l.address ?? "—"}</div>
                          <div className="text-xs">
                            {l.city}
                            {l.uf ? `, ${l.uf}` : ""} · {nicheLabel(l.niche)}
                          </div>
                        </td>
                        <td className="text-fg-muted px-3 py-2.5 align-top text-xs">
                          <div>{shortDate(l.firstSeenAt)}</div>
                          {l.lastSeenAt.slice(0, 10) !==
                            l.firstSeenAt.slice(0, 10) && (
                            <div className="opacity-70">
                              revisto {shortDate(l.lastSeenAt)}
                            </div>
                          )}
                        </td>
                        <td className="px-3 py-2.5 align-top">
                          <StatusPicker id={l.id} status={l.status} />
                        </td>
                        <td className="px-3 py-2.5 align-top">
                          {wa ? (
                            <a
                              href={wa}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-block rounded-md bg-[#25D366] px-2.5 py-1.5 text-xs font-medium text-black"
                            >
                              WhatsApp
                            </a>
                          ) : (
                            <span className="text-fg-muted text-xs">
                              {l.phone ?? "sem telefone"}
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {page.pages > 1 && (
            <nav className="text-fg-muted mt-4 flex items-center justify-between text-sm">
              <span>
                página {fmt(page.page)} de {fmt(page.pages)} · {fmt(page.total)}{" "}
                no total
              </span>
              <span className="flex gap-2">
                {page.page > 1 && (
                  <Link
                    href={`/historico${filtersToQuery(filters, { page: page.page - 1 })}`}
                    className="border-line hover:border-brand rounded-md border px-3 py-1.5"
                  >
                    anterior
                  </Link>
                )}
                {page.page < page.pages && (
                  <Link
                    href={`/historico${filtersToQuery(filters, { page: page.page + 1 })}`}
                    className="border-line hover:border-brand rounded-md border px-3 py-1.5"
                  >
                    próxima
                  </Link>
                )}
              </span>
            </nav>
          )}

          {/* Quick pivots that would otherwise need the form. */}
          <div className="text-fg-muted mt-6 flex flex-wrap gap-3 text-xs">
            <Link
              href={link({ onlyNoSite: true, onlyWhatsapp: true })}
              className="hover:text-fg underline"
            >
              sem site + WhatsApp
            </Link>
            <Link
              href={link({ status: "contatado" })}
              className="hover:text-fg underline"
            >
              já contatados
            </Link>
            <Link
              href={link({ status: "cliente" })}
              className="hover:text-fg underline"
            >
              clientes
            </Link>
            <Link
              href={link({ sort: "recent" })}
              className="hover:text-fg underline"
            >
              mais recentes
            </Link>
          </div>
        </>
      )}
    </div>
  );
}

function hasFilters(f: ReturnType<typeof parseFilters>): boolean {
  return Boolean(
    f.q ||
    f.niche ||
    f.city ||
    f.uf ||
    f.status ||
    f.onlyNoSite ||
    f.onlyWhatsapp ||
    f.minScore,
  );
}

/** ISO timestamps are stored in UTC; render them in pt-BR for reading. */
function shortDate(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso.slice(0, 10);
  return d.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "2-digit",
  });
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="flex flex-col gap-1">
      <span className="text-fg-muted text-xs tracking-wide uppercase">
        {label}
      </span>
      {children}
    </label>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="tnum text-xl font-semibold">{value}</div>
      <div className="text-fg-muted text-xs tracking-wide uppercase">
        {label}
      </div>
    </div>
  );
}
