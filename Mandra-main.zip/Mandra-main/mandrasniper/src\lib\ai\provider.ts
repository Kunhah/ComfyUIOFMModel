import type { Lead, LeadInsight, OutreachScriptAI } from "@/types";
import type { SearchPromptResult } from "./schemas";

export interface AIProvider {
  /** Interprets a natural language search query into structured search filters */
  interpretSearchPrompt(promptText: string): Promise<SearchPromptResult>;

  /** Qualifies a lead and extracts pain points, opportunities, and recommended offer */
  qualifyLead(lead: Lead): Promise<LeadInsight>;

  /** Generates a non-generic, fact-based outreach message for a specified channel, tone & objective */
  generateOutreachScript(
    lead: Lead,
    channel: "WHATSAPP" | "INSTAGRAM" | "EMAIL" | "CALL_SCRIPT",
    tone: "DIRECT" | "CONSULTATIVE" | "CASUAL" | "EXECUTIVE",
    objective: string
  ): Promise<OutreachScriptAI>;

  /** AI Command Bar query execution (Ctrl+K) */
  queryCommandBar(
    queryText: string,
    contextLeads: Lead[]
  ): Promise<{ answer: string; matchingLeadIds: string[]; actionMessage?: string }>;
}
