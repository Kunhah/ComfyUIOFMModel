export type InstagramMatchStatus = "CONFIRMED" | "PROBABLE" | "NOT_FOUND";

export interface InstagramMatchResult {
  status: InstagramMatchStatus;
  handle: string | null;
  profileUrl: string | null;
  confidenceScore: number;
}

export class InstagramMatchEngine {
  /**
   * Matches candidate business info to an Instagram handle with explicit confidence scoring.
   */
  public evaluateMatch(
    candidateName: string,
    candidateCity: string,
    socialUrl?: string | null,
    websiteUrl?: string | null
  ): InstagramMatchResult {
    if (!socialUrl) {
      return {
        status: "NOT_FOUND",
        handle: null,
        profileUrl: null,
        confidenceScore: 0,
      };
    }

    const cleanName = candidateName.toLowerCase().replace(/[^a-z0-9]/g, "");
    const handleMatch = socialUrl.match(/instagram\.com\/([a-zA-Z0-9_\.]+)/i);
    const handle = handleMatch ? handleMatch[1] : null;

    if (!handle) {
      return {
        status: "NOT_FOUND",
        handle: null,
        profileUrl: null,
        confidenceScore: 0,
      };
    }

    const cleanHandle = handle.toLowerCase().replace(/[^a-z0-9]/g, "");
    let score = 50;

    // High confidence if website links directly to Instagram
    if (websiteUrl && websiteUrl.includes("instagram.com")) {
      score = 95;
    } else if (cleanHandle.includes(cleanName) || cleanName.includes(cleanHandle)) {
      score = 85;
    } else if (cleanHandle.includes(candidateCity.toLowerCase().replace(/[^a-z0-9]/g, ""))) {
      score = 75;
    }

    let status: InstagramMatchStatus = "NOT_FOUND";
    if (score >= 80) status = "CONFIRMED";
    else if (score >= 50) status = "PROBABLE";

    return {
      status,
      handle: `@${handle}`,
      profileUrl: `https://instagram.com/${handle}`,
      confidenceScore: score,
    };
  }
}
