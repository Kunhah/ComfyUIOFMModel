import React from "react";

export function MandraLogo({
  className = "",
  dark = false,
}: {
  className?: string;
  dark?: boolean;
}) {
  return (
    <div className={`inline-flex items-center gap-2.5 ${className}`}>
      {/* Mandra Mascot SVG Badge */}
      <div className="relative flex items-center justify-center">
        <svg
          width="30"
          height="34"
          viewBox="0 0 32 36"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="shrink-0 drop-shadow-sm"
        >
          {/* Body */}
          <path
            d="M16 2C8.82 2 3 7.82 3 15C3 20.8 6.8 25.7 12 27.3V32C12 33.1 12.9 34 14 34H18C19.1 34 20 33.1 20 32V27.3C25.2 25.7 29 20.8 29 15C29 7.82 23.18 2 16 2Z"
            fill={dark ? "#1C1F28" : "#181A20"}
            stroke={dark ? "#2E3240" : "#2B2E3A"}
            strokeWidth="1.5"
          />
          {/* M Hair Emblem */}
          <path
            d="M8.5 10C8.5 7.5 11 5.5 16 5.5C21 5.5 23.5 7.5 23.5 10C23.5 13 21 14.5 19 12C17.5 10.1 16 11.5 16 11.5C16 11.5 14.5 10.1 13 12C11 14.5 8.5 13 8.5 10Z"
            fill="#FFF3D6"
          />
          {/* Eyes */}
          <ellipse
            cx="11.5"
            cy="17"
            rx="2.5"
            ry="1.8"
            fill="#FF9E1B"
            transform="rotate(-12 11.5 17)"
          />
          <ellipse
            cx="20.5"
            cy="17"
            rx="2.5"
            ry="1.8"
            fill="#FF9E1B"
            transform="rotate(12 20.5 17)"
          />
          <circle cx="11.8" cy="17" r="0.9" fill="#101216" />
          <circle cx="20.2" cy="17" r="0.9" fill="#101216" />
          {/* Mouth */}
          <path
            d="M14 21.2C15 22 17 22 18 21.2"
            stroke="#FF9E1B"
            strokeWidth="1.2"
            strokeLinecap="round"
          />
        </svg>
      </div>

      {/* Brand Text */}
      <span
        className={`font-black text-xl tracking-wider font-sans uppercase flex items-center ${
          dark ? "text-white" : "text-[#181A20]"
        }`}
      >
        MANDR
        <span className="inline-block relative">
          A
          <span className="absolute bottom-1 left-1/2 -translate-x-1/2 size-1 rounded-full bg-brand"></span>
        </span>
        <span className="text-brand">.</span>
      </span>
    </div>
  );
}
