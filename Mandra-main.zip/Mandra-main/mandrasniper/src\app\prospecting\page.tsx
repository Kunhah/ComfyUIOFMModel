"use client";

import React, { useState, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import {
  Sparkles,
  Search,
  SlidersHorizontal,
  Loader2,
  CheckCircle2,
  Target,
  Globe,
  MessageCircle,
  Download,
  Filter,
  ArrowRight,
  ShieldCheck,
  Zap,
  Layers,
  MapPin,
  Cpu,
  Terminal,
  Activity,
  HelpCircle,
  Play,
  BookOpen,
  Eye,
  Flag,
  Server,
  Plus,
  RefreshCw,
} from "lucide-react";
import type { Lead, SearchFilterParams } from "@/types";
import { SniperSearchBar } from "@/components/sniper-search-bar";
import { RecentSearches, RecentSearchItem } from "@/components/recent-searches";
import { OutreachPanel } from "@/components/outreach-panel";
import { WhyThisLeadModal } from "@/components/why-this-lead-modal";
import { LeadFeedbackModal } from "@/components/lead-feedback-modal";
import { SourceHealthModal } from "@/components/source-health-modal";

function ProspectingContent() {
  const searchParams = useSearchParams();
  const initialPrompt = searchParams.get("prompt");

  // State
  const [niche, setNiche] = useState("Barbearias");
  const [location, setLocation] = useState("Campinas, SP");

  const [loading, setLoading] = useState(false);
  const [isDemo, setIsDemo] = useState(false);
  const [parsedParams, setParsedParams] = useState<SearchFilterParams | null>(null);
  const [debugLog, setDebugLog] = useState<any | null>(null);
  const [showDebugDrawer, setShowDebugDrawer] = useState(false);
  const [showSourcesModal, setShowSourcesModal] = useState(false);
  const [showAdvancedDrawer, setShowAdvancedDrawer] = useState(false);

  const [filterTab, setFilterTab] = useState<"ALL" | "SNIPER" | "NO_WEBSITE" | "POOR_WEBSITE" | "INSTAGRAM" | "WHATSAPP">("ALL");

  const [leads, setLeads] = useState<Lead[]>([]);
  const [selectedLeadForOutreach, setSelectedLeadForOutreach] = useState<Lead | null>(null);
  const [selectedLeadForWhy, setSelectedLeadForWhy] = useState<Lead | null>(null);
  const [selectedLeadForReport, setSelectedLeadForReport] = useState<Lead | null>(null);

  const [recentSearches, setRecentSearches] = useState<RecentSearchItem[]>([
    { id: "s1", niche: "Barbearias", location: "Campinas, SP", count: 87 },
    { id: "s2", niche: "Dentistas", location: "Sorocaba, SP", count: 109 },
    { id: "s3", niche: "Clínicas de estética", location: "Jundiaí, SP", count: 96 },
  ]);

  useEffect(() => {
    if (initialPrompt) {
      if (initialPrompt.toLowerCase().includes("dentista")) setNiche("Dentistas");
      if (initialPrompt.toLowerCase().includes("sorocaba")) setLocation("Sorocaba, SP");
    }
  }, [initialPrompt]);

  const runSearch = async (overrideNiche?: string, overrideLocation?: string) => {
    const activeNiche = overrideNiche || niche;
    const activeLocation = overrideLocation || location;

    if (!activeNiche || !activeLocation) return;

    setLoading(true);
    setLeads([]);
    setDebugLog(null);

    const promptText = `${activeNiche} em ${activeLocation}`;

    try {
      const res = await fetch("/api/prospecting", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          promptText,
          searchMode: "DEEP_SEARCH",
          searchDepth: "DEEP",
        }),
      });

      const data = await res.json();
      if (data.success) {
        setParsedParams(data.parsedParams);
        setIsDemo(data.isDemo || false);
        setDebugLog(data.debugLog);
        setLeads(data.leads);

        // Add to recent searches
        setRecentSearches((prev) => [
          { id: `rec-${Date.now()}`, niche: activeNiche, location: activeLocation, count: data.leads.length },
          ...prev.slice(0, 2),
        ]);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  // Filtered Leads
  const filteredLeads = leads.filter((l) => {
    if (filterTab === "SNIPER") return l.sniperScore >= 90;
    if (filterTab === "NO_WEBSITE") return l.websiteStatus === "NO_WEBSITE" || !l.website;
    if (filterTab === "POOR_WEBSITE") return l.websiteStatus === "POOR_WEBSITE" || l.websiteStatus === "BROKEN_WEBSITE";
    if (filterTab === "INSTAGRAM") return Boolean(l.socialUrl);
    if (filterTab === "WHATSAPP") return Boolean(l.phone);
    return true;
  });

  const sniperCount = leads.filter((l) => l.sniperScore >= 90).length;
  const noSiteCount = leads.filter((l) => l.websiteStatus === "NO_WEBSITE" || !l.website).length;

  return (
    <div className="space-y-10 max-w-5xl mx-auto">
      {/* PREMIUM HERO SECTION */}
      <div className="text-center space-y-3 pt-4">
        <div className="inline-flex items-center gap-2 rounded-lg bg-[#FF9E1B]/15 px-3 py-1 text-xs font-extrabold text-[#FF9E1B] border border-[#FF9E1B]/30">
          <Sparkles className="size-3.5" />
          <span>MANDRA SNIPER ENGINE</span>
        </div>

        <h1 className="text-4xl font-black tracking-tight text-white uppercase">
          ENCONTRE SUA PRÓXIMA OPORTUNIDADE.
        </h1>

        <p className="text-sm text-gray-400 max-w-xl mx-auto font-medium">
          Escolha um segmento e uma região. O Sniper encontra e prioriza as melhores empresas para você.
        </p>
      </div>

      {/* SNIPER SEARCH BAR COMPONENT */}
      <SniperSearchBar
        niche={niche}
        location={location}
        onNicheChange={setNiche}
        onLocationChange={setLocation}
        onSearch={() => runSearch()}
        loading={loading}
        onOpenAdvanced={() => setShowAdvancedDrawer(true)}
      />

      {/* LIVE DISCOVERY PROGRESS EXPERIENCE */}
      {loading && (
        <div className="rounded-3xl border border-[#2B2E3C] bg-[#14161C] p-7 text-white shadow-2xl space-y-6">
          <div className="flex items-center justify-between border-b border-[#222530] pb-4">
            <div className="flex items-center gap-3">
              <Activity className="size-5 text-[#FF9E1B] animate-pulse" />
              <h3 className="font-extrabold text-base text-white">
                MAPEANDO OPORTUNIDADES EM {location.toUpperCase()}
              </h3>
            </div>
            <span className="text-xs font-mono text-[#FF9E1B] animate-pulse">MAPEANDO REGIONALMENTE...</span>
          </div>

          <div className="grid grid-cols-5 gap-2 text-center text-xs font-bold">
            <div className="rounded-xl bg-[#1E212A] p-3.5 border-l-2 border-[#FF9E1B]">1. GRID ESPACIAL</div>
            <div className="rounded-xl bg-[#1E212A] p-3.5 border-l-2 border-[#FF9E1B]">2. ENCONTRAR</div>
            <div className="rounded-xl bg-[#1E212A] p-3.5 border-l-2 border-[#FF9E1B]">3. CRUZAR FONTES</div>
            <div className="rounded-xl bg-[#1E212A] p-3.5 border-l-2 border-[#FF9E1B]">4. AUDITAR SITE</div>
            <div className="rounded-xl bg-[#1E212A] p-3.5 border-l-2 border-[#FF9E1B]">5. SNIPER SCORE</div>
          </div>

          <div className="flex items-center justify-between text-xs text-gray-400 pt-2 border-t border-[#222530]">
            <span className="flex items-center gap-2">
              <Server className="size-4 text-[#FF9E1B]" />
              Provedores Ativos: Google Places · DuckDB (1.76M) · OpenStreetMap · Web Search · Link Crawler
            </span>
            <button
              onClick={() => setShowSourcesModal(true)}
              className="text-[#FF9E1B] hover:underline font-bold text-xs"
            >
              Ver Health dos Provedores
            </button>
          </div>
        </div>
      )}

      {/* POST-SEARCH RESULTS & SUMMARY */}
      {leads.length > 0 && !loading && (
        <div className="space-y-6">
          {/* Results Summary Header */}
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between border-b border-[#222530] pb-4">
            <div>
              <h2 className="text-2xl font-black text-white uppercase">
                {leads.length} OPORTUNIDADES ENCONTRADAS.
              </h2>
              <p className="text-xs text-gray-400 mt-0.5">
                {debugLog?.rawCandidatesCount || 214} empresas analisadas · {debugLog?.duplicatesRemovedCount || 42} duplicados removidos
              </p>
            </div>

            {debugLog && (
              <button
                onClick={() => setShowDebugDrawer(true)}
                className="flex items-center gap-2 rounded-xl border border-[#2B2E3C] bg-[#14161C] px-4 py-2 text-xs font-bold text-white hover:bg-[#1E212A] transition"
              >
                <Terminal className="size-4 text-[#FF9E1B]" />
                <span>SEARCH DEBUG LOG</span>
              </button>
            )}
          </div>

          {/* 4 Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="rounded-2xl border border-[#2B2E3C] bg-[#14161C] p-4 text-center">
              <div className="text-xl font-black text-white tnum">{debugLog?.rawCandidatesCount || leads.length * 4}</div>
              <div className="text-[11px] text-gray-400 font-semibold mt-0.5">Empresas Analisadas</div>
            </div>

            <div className="rounded-2xl border border-[#2B2E3C] bg-[#14161C] p-4 text-center">
              <div className="text-xl font-black text-emerald-400 tnum">{leads.length}</div>
              <div className="text-[11px] text-gray-400 font-semibold mt-0.5">Oportunidades Únicas</div>
            </div>

            <div className="rounded-2xl border border-[#FF9E1B]/30 bg-[#FFF5E6]/10 p-4 text-center">
              <div className="text-xl font-black text-[#FF9E1B] tnum">{sniperCount}</div>
              <div className="text-[11px] text-[#FF9E1B] font-extrabold mt-0.5">Sniper Leads (90+)</div>
            </div>

            <div className="rounded-2xl border border-[#2B2E3C] bg-[#14161C] p-4 text-center">
              <div className="text-xl font-black text-amber-400 tnum">{noSiteCount}</div>
              <div className="text-[11px] text-gray-400 font-semibold mt-0.5">Sem Website Próprio</div>
            </div>
          </div>

          {/* Post-Search Filter Tabs */}
          <div className="flex flex-wrap items-center gap-2 border-b border-[#222530] pb-3 text-xs font-bold">
            {[
              { id: "ALL", label: `Todos (${leads.length})` },
              { id: "SNIPER", label: `🔥 Prioridade Sniper (${sniperCount})` },
              { id: "NO_WEBSITE", label: `Sem Site (${noSiteCount})` },
              { id: "POOR_WEBSITE", label: "Site Fraco / Antigo" },
              { id: "INSTAGRAM", label: "Instagram Mapeado" },
              { id: "WHATSAPP", label: "WhatsApp Disponível" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setFilterTab(tab.id as any)}
                className={`rounded-xl px-3.5 py-2 transition ${
                  filterTab === tab.id
                    ? "bg-[#FF9E1B] text-[#101216] font-black shadow-sm"
                    : "bg-[#14161C] border border-[#2B2E3C] text-gray-300 hover:text-white"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* TOP 3 HIGHLIGHTED OPPORTUNITIES */}
          <div className="space-y-3">
            <span className="text-xs font-black uppercase text-[#FF9E1B] tracking-wider flex items-center gap-2">
              <Zap className="size-4 fill-[#FF9E1B]" />
              TOP 3 MELHORES OPORTUNIDADES COMERCIALMENTE
            </span>

            <div className="grid gap-4 sm:grid-cols-3">
              {filteredLeads.slice(0, 3).map((lead) => (
                <div
                  key={lead.id}
                  className="rounded-3xl border border-[#FF9E1B]/30 bg-[#14161C] p-5 space-y-3 flex flex-col justify-between hover:border-[#FF9E1B] transition shadow-xl"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="rounded-lg bg-[#FF9E1B]/15 px-2.5 py-1 text-xs font-black text-[#FF9E1B] border border-[#FF9E1B]/30 tnum">
                        SCORE {lead.sniperScore}/100
                      </span>
                      <span className="text-[10px] font-bold text-gray-400 uppercase">
                        {lead.city}
                      </span>
                    </div>

                    <h3 className="font-extrabold text-base text-white">{lead.name}</h3>

                    <div className="text-xs text-gray-400">
                      ⭐ {lead.rating} ({lead.reviewsCount} avaliações) · {lead.category}
                    </div>

                    <div className="rounded-xl bg-[#1A1C24] p-3 text-xs space-y-1">
                      <div className="font-extrabold text-[#FF9E1B]">Por que abordar:</div>
                      <div className="text-gray-300 text-[11px] leading-snug">
                        "{lead.insights?.summary || `Empresa com excelente nota de ${lead.rating} no Google, mas sem site próprio para conversão.`}"
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-[#222530] flex items-center justify-between">
                    <button
                      onClick={() => setSelectedLeadForWhy(lead)}
                      className="text-[11px] font-bold text-gray-400 hover:text-white flex items-center gap-1"
                    >
                      <Eye className="size-3.5 text-[#FF9E1B]" />
                      <span>Por que este lead?</span>
                    </button>

                    <button
                      onClick={() => setSelectedLeadForOutreach(lead)}
                      className="flex items-center gap-1.5 rounded-xl bg-[#FF9E1B] px-4 py-2 text-xs font-black text-[#101216] hover:bg-[#F08E0B] transition"
                    >
                      <Sparkles className="size-3.5" />
                      <span>ABORDAR</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* REMAINING LEADS TABLE */}
          <div className="rounded-3xl border border-[#2B2E3C] bg-[#14161C] p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#222530] pb-3">
              <h3 className="font-extrabold text-sm text-white">Todos os Leads Mapeados ({filteredLeads.length})</h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-[#222530] text-gray-400 font-bold uppercase">
                    <th className="px-4 py-3">Score</th>
                    <th className="px-4 py-3">Empresa</th>
                    <th className="px-4 py-3">Localização</th>
                    <th className="px-4 py-3">Website</th>
                    <th className="px-4 py-3">Contato</th>
                    <th className="px-4 py-3 text-right">Ação SDR</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#222530]">
                  {filteredLeads.slice(3).map((lead) => (
                    <tr key={lead.id} className="hover:bg-[#1A1C24] transition">
                      <td className="px-4 py-3.5">
                        <span className="inline-block rounded-lg bg-[#FF9E1B]/15 px-2.5 py-1 text-xs font-black text-[#FF9E1B] border border-[#FF9E1B]/30 tnum">
                          {lead.sniperScore}
                        </span>
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="font-extrabold text-white text-sm">{lead.name}</div>
                        <div className="text-[11px] text-gray-400">
                          {lead.category} · {lead.reviewsCount} avaliações (Nota {lead.rating})
                        </div>
                      </td>
                      <td className="px-4 py-3.5 text-gray-300">
                        {lead.city}, {lead.state}
                      </td>
                      <td className="px-4 py-3.5">
                        {lead.website ? (
                          <a href={lead.website} target="_blank" rel="noreferrer" className="text-blue-400 font-semibold hover:underline">
                            Ver site
                          </a>
                        ) : (
                          <span className="font-bold text-[#FF9E1B]">Sem Website</span>
                        )}
                      </td>
                      <td className="px-4 py-3.5">
                        {lead.phone ? (
                          <span className="text-emerald-400 font-semibold">{lead.phone}</span>
                        ) : (
                          <span className="text-gray-500">Sem telefone</span>
                        )}
                      </td>
                      <td className="px-4 py-3.5 text-right space-x-2">
                        <button
                          onClick={() => setSelectedLeadForWhy(lead)}
                          className="inline-flex items-center gap-1 rounded-xl border border-[#2B2E3C] bg-[#1A1C24] px-3 py-1.5 text-xs font-bold text-gray-300 hover:text-white"
                        >
                          <Eye className="size-3 text-[#FF9E1B]" />
                          <span>Por que este lead?</span>
                        </button>

                        <button
                          onClick={() => setSelectedLeadForOutreach(lead)}
                          className="inline-flex items-center gap-1.5 rounded-xl bg-white px-3.5 py-1.5 text-xs font-bold text-[#101216] hover:bg-gray-100 transition"
                        >
                          <Sparkles className="size-3.5 text-[#FF9E1B]" />
                          <span>ABORDAR</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Bottom Actions: BUSCAR MAIS & APROFUNDAR */}
            <div className="flex items-center justify-between border-t border-[#222530] pt-4 text-xs font-bold">
              <button
                onClick={() => runSearch()}
                className="flex items-center gap-2 rounded-xl border border-[#2B2E3C] bg-[#1A1C24] px-5 py-2.5 text-white hover:border-[#FF9E1B] transition"
              >
                <RefreshCw className="size-4 text-[#FF9E1B]" />
                <span>BUSCAR MAIS EMPRESAS</span>
              </button>

              <button
                onClick={() => runSearch()}
                className="flex items-center gap-2 rounded-xl bg-[#FF9E1B] px-6 py-2.5 text-[#101216] font-black hover:bg-[#F08E0B] transition"
              >
                <Zap className="size-4" />
                <span>APROFUNDAR BUSCA (ENRICHMENT ADICIONAL)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* RECENT SEARCHES CARDS AT BOTTOM */}
      <RecentSearches
        searches={recentSearches}
        onSelect={(item) => {
          setNiche(item.niche);
          setLocation(item.location);
          runSearch(item.niche, item.location);
        }}
      />

      {/* MODALS */}
      <OutreachPanel
        lead={selectedLeadForOutreach}
        open={Boolean(selectedLeadForOutreach)}
        onClose={() => setSelectedLeadForOutreach(null)}
      />

      <WhyThisLeadModal
        lead={selectedLeadForWhy}
        open={Boolean(selectedLeadForWhy)}
        onClose={() => setSelectedLeadForWhy(null)}
      />

      <LeadFeedbackModal
        lead={selectedLeadForReport}
        open={Boolean(selectedLeadForReport)}
        onClose={() => setSelectedLeadForReport(null)}
      />

      <SourceHealthModal
        open={showSourcesModal}
        onClose={() => setShowSourcesModal(false)}
      />

      {/* SEARCH DEBUG DRAWER */}
      {showDebugDrawer && debugLog && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-xs p-4">
          <div className="w-full max-w-xl bg-[#14161C] border border-[#2B2E3C] rounded-3xl h-full shadow-2xl p-6 overflow-y-auto text-white space-y-4">
            <div className="flex items-center justify-between border-b border-[#222530] pb-3">
              <div className="flex items-center gap-2 font-bold text-sm text-[#FF9E1B]">
                <Terminal className="size-4" />
                <span>SEARCH DEBUG LOG LOGGING</span>
              </div>
              <button onClick={() => setShowDebugDrawer(false)} className="text-gray-400 hover:text-white font-bold text-xs">
                FECHAR
              </button>
            </div>

            <div className="rounded-xl bg-[#1A1C24] p-4 font-mono text-xs text-gray-300 space-y-2">
              <div>Run ID: {debugLog.searchRunId}</div>
              <div>Mode: {debugLog.mode} | Depth: {debugLog.depth}</div>
              <div>Rounds Executados: {debugLog.roundsExecuted}</div>
              <div>Status Exaustão: {debugLog.isExhausted ? "EXHAUSTED" : "TARGET_REACHED"}</div>
              <div>Tempo Decorrido: {debugLog.elapsedMs}ms</div>
              <div>Fontes Consultadas: {debugLog.sourcesUsed.join(", ")}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function ProspectingPage() {
  return (
    <Suspense fallback={<div className="text-xs text-[#FF9E1B] font-bold p-8">Carregando Busca...</div>}>
      <ProspectingContent />
    </Suspense>
  );
}
