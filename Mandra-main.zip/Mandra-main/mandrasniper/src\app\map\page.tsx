"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { MapPin, Search, Target, Sparkles, Filter } from "lucide-react";
import type { Lead } from "@/types";

export default function MapPage() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);

  useEffect(() => {
    fetch("/api/leads")
      .then((r) => r.json())
      .then((d) => {
        if (d.leads) setLeads(d.leads);
      });
  }, []);

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between border-b border-[#ECE8E0] pb-4">
        <div>
          <h1 className="text-2xl font-black text-[#1E2026] uppercase flex items-center gap-2">
            <MapPin className="size-6 text-[#FF9E1B]" />
            <span>Mapa de Inteligência Geográfica</span>
          </h1>
          <p className="text-xs text-[#6E7381]">
            Visualização de empresas mapeadas no território com pins coloridos por Sniper Score.
          </p>
        </div>

        <button className="flex items-center gap-2 rounded-xl bg-[#1C1F26] px-4 py-2.5 text-xs font-bold text-white hover:bg-[#2A2E38] transition shadow-xs">
          <Search className="size-4 text-[#FF9E1B]" />
          <span>BUSCAR NESTA ÁREA</span>
        </button>
      </div>

      {/* Simulated High-End Map Container */}
      <div className="relative h-[550px] w-full rounded-2xl border border-[#2B2E3C] bg-[#14161C] overflow-hidden shadow-xl p-6 flex flex-col justify-between">
        {/* Map Header Overlay Controls */}
        <div className="z-10 flex items-center justify-between">
          <div className="rounded-xl border border-[#2B2E3C] bg-[#1A1C24]/90 backdrop-blur-xs px-4 py-2 text-xs font-bold text-white flex items-center gap-3">
            <span className="flex items-center gap-1.5 text-[#FF9E1B]">
              <span className="size-2.5 rounded-full bg-[#FF9E1B]" /> Sniper (90+)
            </span>
            <span className="flex items-center gap-1.5 text-emerald-400">
              <span className="size-2.5 rounded-full bg-emerald-400" /> Quente (75-89)
            </span>
            <span className="flex items-center gap-1.5 text-blue-400">
              <span className="size-2.5 rounded-full bg-blue-400" /> Bom (60-74)
            </span>
          </div>

          <div className="rounded-xl border border-[#2B2E3C] bg-[#1A1C24]/90 backdrop-blur-xs px-3 py-2 text-xs text-gray-300 font-medium">
            Mostrando <strong>{leads.length}</strong> empresas geolocalizadas
          </div>
        </div>

        {/* Map Grid Surface Pins Representation */}
        <div className="absolute inset-0 p-12 grid grid-cols-2 sm:grid-cols-4 gap-8 items-center justify-items-center opacity-90 pointer-events-auto">
          {leads.map((lead, idx) => {
            const isSniper = lead.sniperScore >= 90;
            const isQuente = lead.sniperScore >= 75 && lead.sniperScore < 90;

            return (
              <button
                key={lead.id}
                onClick={() => setSelectedLead(lead)}
                className={`group relative flex flex-col items-center p-3 rounded-2xl border transition-all duration-200 shadow-lg ${
                  isSniper
                    ? "bg-[#1E212D] border-[#FF9E1B] text-white"
                    : isQuente
                    ? "bg-[#16201B] border-emerald-500 text-white"
                    : "bg-[#1A1C24] border-blue-400 text-white"
                }`}
              >
                <div className="flex items-center gap-1.5 text-xs font-bold">
                  <MapPin className={`size-4 ${isSniper ? "text-[#FF9E1B]" : isQuente ? "text-emerald-400" : "text-blue-400"}`} />
                  <span>{lead.name}</span>
                </div>
                <div className="text-[10px] text-gray-300 mt-1">
                  Score: <strong className="text-[#FF9E1B]">{lead.sniperScore}</strong> · {lead.city}
                </div>
              </button>
            );
          })}
        </div>

        {/* Lead Details Drawer Overlay */}
        {selectedLead && (
          <div className="z-10 rounded-xl border border-[#2B2E3C] bg-[#1A1C24] p-4 text-xs text-white max-w-sm flex items-center justify-between">
            <div>
              <div className="font-bold text-sm text-[#FF9E1B]">{selectedLead.name}</div>
              <div className="text-gray-300">{selectedLead.category} · {selectedLead.city}</div>
            </div>
            <Link
              href={`/leads/${selectedLead.id}`}
              className="rounded-lg bg-[#FF9E1B] px-3 py-1.5 text-xs font-bold text-[#101216]"
            >
              Ver Detalhes
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
