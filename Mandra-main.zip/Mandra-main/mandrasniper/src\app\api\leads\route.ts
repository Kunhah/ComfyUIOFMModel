import { NextResponse } from "next/server";
import { MandraRepository } from "@/lib/db/repository";
import type { LeadCrmStatus } from "@/types";

export const runtime = "nodejs";
const repo = new MandraRepository();

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const query = searchParams.get("q") || undefined;
    const city = searchParams.get("city") || undefined;
    const niche = searchParams.get("niche") || undefined;
    const minScore = searchParams.get("minScore") ? Number(searchParams.get("minScore")) : undefined;
    const websiteStatus = searchParams.get("websiteStatus") || undefined;
    const crmStatus = (searchParams.get("crmStatus") as LeadCrmStatus) || undefined;

    const leads = await repo.getLeads({
      query,
      city,
      niche,
      minScore,
      websiteStatus,
      crmStatus,
    });

    return NextResponse.json({ leads, total: leads.length });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Erro ao carregar leads" },
      { status: 500 }
    );
  }
}
