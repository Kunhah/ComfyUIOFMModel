import { NextResponse } from "next/server";
import { OpenAIProvider } from "@/lib/ai/openai";
import { MandraRepository } from "@/lib/db/repository";

export const runtime = "nodejs";
const aiProvider = new OpenAIProvider();
const repo = new MandraRepository();

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { queryText } = body;

    if (!queryText || queryText.trim().length === 0) {
      return NextResponse.json({ error: "Comando é obrigatório." }, { status: 400 });
    }

    const leads = await repo.getLeads();
    const result = await aiProvider.queryCommandBar(queryText, leads);

    return NextResponse.json({ success: true, result });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Erro ao executar comando de IA" },
      { status: 500 }
    );
  }
}
