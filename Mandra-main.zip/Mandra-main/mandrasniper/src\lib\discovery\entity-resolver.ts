import type { Lead } from "@/types";
import { normalise } from "@/lib/cities";

export interface SourceProvenance {
  provider: "google_places" | "duckdb" | "osm" | "web_search" | "website_crawler" | "instagram";
  externalId?: string;
  sourceUrl?: string;
  verifiedAt: string;
}

export class EntityResolver {
  /**
   * Merges multi-source candidate records into deduplicated Lead entities while preserving fact provenance.
   */
  public resolveEntities(candidates: Lead[]): Lead[] {
    const entityMap = new Map<string, Lead>();

    for (const candidate of candidates) {
      const normName = normalise(candidate.name);
      const normPhone = candidate.phone ? candidate.phone.replace(/\D/g, "") : "";
      const normWebsite = candidate.website ? candidate.website.toLowerCase().replace(/^https?:\/\//, "").replace(/\/$/, "") : "";
      const normCity = normalise(candidate.city || "");

      // Entity Dedup Key: Google Place ID -> Website -> Phone -> Normalized Name + City
      let key = candidate.googlePlaceId
        ? `place-${candidate.googlePlaceId}`
        : normWebsite.length > 5
        ? `web-${normWebsite}`
        : normPhone.length >= 8
        ? `phone-${normPhone}`
        : `name-${normName}-${normCity}`;

      if (entityMap.has(key)) {
        // Merge attributes and augment facts
        const existing = entityMap.get(key)!;
        existing.phone = existing.phone || candidate.phone;
        existing.website = existing.website || candidate.website;
        existing.socialUrl = existing.socialUrl || candidate.socialUrl;
        existing.email = existing.email || candidate.email;
        existing.rating = Math.max(existing.rating, candidate.rating);
        existing.reviewsCount = Math.max(existing.reviewsCount, candidate.reviewsCount);
      } else {
        entityMap.set(key, candidate);
      }
    }

    return Array.from(entityMap.values());
  }
}
