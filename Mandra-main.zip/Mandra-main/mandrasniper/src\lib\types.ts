/** A business as we store and display it, normalised from whatever provider found it. */
export type Lead = {
  /** Provider-stable id. Overture GERS ids are stable across releases, so this doubles as the dedupe key. */
  id: string;
  name: string;
  category: string | null;
  /** Street address as a single line, e.g. "Rua Caramuru, 272". */
  address: string | null;
  city: string | null;
  /** Two-letter state code, e.g. "MG". */
  uf: string | null;
  /** E.164, e.g. "+5531987911222". */
  phone: string | null;
  website: string | null;
  /** Facebook/Instagram profile, when the business has one but no site. */
  social: string | null;
  email: string | null;
  lat: number | null;
  lon: number | null;
  /** Provider's own 0–1 confidence that this record is real and current. */
  confidence: number;
};

/** A lead with our qualification verdict attached. */
export type ScoredLead = Lead & {
  /** 0–100. Higher means it needs what Atlas sells more badly and is easier to reach. */
  score: number;
  /** Short pt-BR phrases explaining the score, for display on the row. */
  reasons: string[];
  /** True when the phone is a Brazilian mobile, so wa.me will actually resolve. */
  whatsapp: boolean;
  /**
   * Not in the local history before this search. Absent when the history write
   * failed, so the board can distinguish "not new" from "don't know".
   */
  isNew?: boolean;
};

/** Outreach state. Mirrors the CHECK constraint on `leads.status`. */
export type LeadStatus =
  "novo" | "contatado" | "respondeu" | "cliente" | "descartado";

export const LEAD_STATUSES: LeadStatus[] = [
  "novo",
  "contatado",
  "respondeu",
  "cliente",
  "descartado",
];

/**
 * A lead read back out of the local history, carrying the bookkeeping the live
 * search can't know: when you first saw it and where it is in your pipeline.
 */
export type StoredLead = ScoredLead & {
  status: LeadStatus;
  /** The niche whose search first surfaced it. */
  niche: string | null;
  searchedCity: string | null;
  searchedUf: string | null;
  firstSeenAt: string;
  lastSeenAt: string;
};

export type SearchRequest = {
  niche: string;
  city: string;
  uf: string;
  /** Only return businesses with no website — the default, since that's the sellable pool. */
  onlyWithoutWebsite?: boolean;
  minConfidence?: number;
  limit?: number;
};

export type SearchResponse = {
  leads: ScoredLead[];
  /**
   * Counted across every match, not just the returned page — `leads` is capped
   * by the request's `limit`.
   */
  stats: {
    /** Businesses matched before the no-website filter. */
    total: number;
    withoutWebsite: number;
    withPhone: number;
    withWhatsapp: number;
    /** How many rows `leads` actually holds. */
    returned: number;
    elapsedMs: number;
  };
  /**
   * Local history outcome, so the UI can say what was new vs already known.
   * The ids themselves stay server-side — each lead already carries `isNew`.
   */
  persisted?: { inserted: number; alreadyKnown: number } | null;
  warnings: string[];
};
