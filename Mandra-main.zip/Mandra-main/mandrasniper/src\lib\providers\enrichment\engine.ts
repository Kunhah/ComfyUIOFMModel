import type { Lead, LeadWebsiteAudit, LeadValidationStatus, OfferFitScores, ValidationCriteria } from "@/types";
import type { GooglePlaceRecord, EnrichmentEngine } from "../types";
import { ServerWebsiteAnalyzer } from "../website/analyzer";
import { InstagramProviderImpl } from "../instagram";
import { calculateSniperScore } from "@/lib/scoring/sniper-score";
import { OpenAIProvider } from "@/lib/ai/openai";

export class MandraEnrichmentEngine implements EnrichmentEngine {
  private websiteAnalyzer = new ServerWebsiteAnalyzer();
  private instagramProvider = new InstagramProviderImpl();
  private aiProvider = new OpenAIProvider();

  public async enrichLead(raw: GooglePlaceRecord): Promise<Lead> {
    const now = new Date().toISOString();

    // 1. Analyze Website
    const auditRes = await this.websiteAnalyzer.analyzeWebsite(raw.website);
    const audit: LeadWebsiteAudit = auditRes.data || {
      url: raw.website,
      statusCode: 0,
      hasHttps: false,
      isResponsive: false,
      title: null,
      metaDescription: null,
      hasCta: false,
      hasWhatsapp: false,
      hasForm: false,
      hasSocialLinks: false,
      performanceScore: 0,
      seoScore: 0,
      websiteScore: 0,
      status: raw.website ? "GOOD_WEBSITE" : "NO_WEBSITE",
    };

    // 2. Analyze Instagram
    const isInstagramUrl = Boolean(raw.website?.toLowerCase().includes("instagram.com"));
    const socialUrl = isInstagramUrl && raw.website ? raw.website : `https://instagram.com/${raw.name.toLowerCase().replace(/[^a-z0-9]/g, "")}`;
    const instaRes = await this.instagramProvider.getProfile(socialUrl);
    const hasInstagram = Boolean(instaRes.data && instaRes.data.isActive);

    // 3. Validate Phone & WhatsApp
    const phone = raw.phone ? raw.phone.trim() : null;
    const digits = phone ? phone.replace(/\D/g, "") : "";
    const isWhatsapp = digits.length >= 10 && (digits.includes("9") || digits.length === 11 || digits.length === 13);

    // 4. Calculate Sniper Score
    const scoring = calculateSniperScore({
      websiteStatus: audit.status,
      hasInstagram,
      hasWhatsapp: isWhatsapp,
      reviewsCount: raw.reviewsCount,
      rating: raw.rating,
      phone,
      hasAddress: Boolean(raw.address && raw.address.length > 5),
    });

    // 5. Construct Validation Criteria Match
    const criteriaMatch: ValidationCriteria = {
      categoryMatch: Boolean(raw.category && raw.category.length > 2),
      locationMatch: Boolean(raw.city && raw.city.length > 2),
      noWebsiteFound: audit.status === "NO_WEBSITE" || audit.status === "SOCIAL_ONLY",
      instagramFound: hasInstagram,
      whatsappFound: isWhatsapp,
      ratingScore: raw.rating,
      reviewsCount: raw.reviewsCount,
    };

    // 6. Calculate Offer Fit Scores
    const offerFitScores: OfferFitScores = {
      landingPage: audit.status === "NO_WEBSITE" ? 96 : 45,
      website: audit.status === "POOR_WEBSITE" || audit.status === "BROKEN_WEBSITE" ? 92 : 30,
      googleProfile: raw.reviewsCount < 30 ? 88 : 50,
      crm: isWhatsapp ? 85 : 40,
      automation: isWhatsapp && hasInstagram ? 90 : 55,
      socialPresence: !hasInstagram ? 80 : 35,
    };

    // 7. Determine Lead Validation Status
    let validationStatus: LeadValidationStatus = "UNVERIFIED";
    if (phone && raw.address && raw.rating > 0) {
      validationStatus = "VERIFIED";
    } else if (phone || raw.address) {
      validationStatus = "PARTIALLY_VERIFIED";
    }

    // 8. Construct Fact Origins
    const facts = {
      name: {
        value: raw.name,
        source: "google_places" as const,
        collectedAt: now,
        confidence: "HIGH" as const,
      },
      phone: {
        value: phone,
        source: "google_places" as const,
        collectedAt: now,
        confidence: phone ? ("HIGH" as const) : ("LOW" as const),
      },
      website: {
        value: raw.website,
        source: "google_places" as const,
        collectedAt: now,
        confidence: "HIGH" as const,
      },
      social: {
        value: hasInstagram ? socialUrl : null,
        source: "instagram" as const,
        collectedAt: now,
        confidence: hasInstagram ? ("HIGH" as const) : ("LOW" as const),
      },
      rating: {
        value: raw.rating,
        source: "google_places" as const,
        collectedAt: now,
        confidence: "HIGH" as const,
      },
      reviewsCount: {
        value: raw.reviewsCount,
        source: "google_places" as const,
        collectedAt: now,
        confidence: "HIGH" as const,
      },
    };

    // 9. Build Lead Record
    const lead: Lead = {
      id: raw.placeId || `lead-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      name: raw.name,
      category: raw.category,
      address: raw.address,
      city: raw.city,
      state: raw.state,
      phone,
      website: raw.website,
      socialUrl: hasInstagram ? socialUrl : null,
      email: null,
      googlePlaceId: raw.placeId,
      rating: raw.rating,
      reviewsCount: raw.reviewsCount,
      mapsUrl: raw.mapsUrl,
      lat: raw.coordinates?.lat,
      lon: raw.coordinates?.lon,
      sniperScore: scoring.score,
      scoreTier: scoring.tier,
      scoreBreakdown: scoring.breakdown,
      confidenceLevel: scoring.confidence,
      validationStatus,
      criteriaMatch,
      offerFitScores,
      websiteStatus: audit.status,
      websiteScore: audit.websiteScore,
      crmStatus: "NOVO",
      facts,
      audit,
      socialProfiles: hasInstagram
        ? [
            {
              platform: "INSTAGRAM",
              url: socialUrl,
              username: instaRes.data?.username,
              followersCount: instaRes.data?.followersCount || 1200,
              isActive: true,
            },
          ]
        : [],
      contacts: phone
        ? [
            {
              id: `cnt-${Date.now()}`,
              name: "Atendimento Comercial",
              phone,
              isWhatsapp,
              source: "google_places",
            },
          ]
        : [],
      firstSeenAt: now,
      lastSeenAt: now,
    };

    // 10. Qualify Lead with AI Insights
    try {
      const insights = await this.aiProvider.qualifyLead(lead);
      lead.insights = insights;
    } catch (e) {
      console.warn("AI qualification fallback:", e);
    }

    return lead;
  }
}
