// MANDRA SNIPER AI - Core Domain Types

export type ConfidenceLevel = 'HIGH' | 'MEDIUM' | 'LOW';

export type LeadValidationStatus =
  | 'VERIFIED'
  | 'PARTIALLY_VERIFIED'
  | 'UNVERIFIED'
  | 'STALE'
  | 'INVALID';

export type WebsiteStatus =
  | 'NO_WEBSITE'
  | 'SOCIAL_ONLY'
  | 'BROKEN_WEBSITE'
  | 'POOR_WEBSITE'
  | 'GOOD_WEBSITE'
  | 'UNKNOWN';

export type LeadCrmStatus =
  | 'NOVO'
  | 'QUALIFICADO'
  | 'ABORDAGEM'
  | 'CONTATADO'
  | 'RESPONDEU'
  | 'REUNIÃO'
  | 'PROPOSTA'
  | 'GANHO'
  | 'PERDIDO';

export type ScoreTier = 'FRIO' | 'POSSÍVEL' | 'BOM' | 'QUENTE' | 'SNIPER';

export type OfferType =
  | 'LANDING_PAGE'
  | 'WEBSITE'
  | 'GOOGLE_PROFILE'
  | 'CRM'
  | 'AUTOMATION'
  | 'SOCIAL_MEDIA';

export type OpportunityType =
  | 'NO_WEBSITE'
  | 'BAD_WEBSITE'
  | 'STRONG_INSTAGRAM_WEAK_SITE'
  | 'HIGH_REVIEWS_LOW_DIGITAL'
  | 'NO_WHATSAPP_CTA'
  | 'NO_LEAD_CAPTURE'
  | 'POOR_LOCAL_PRESENCE'
  | 'STRONG_REPUTATION_WEAK_CONVERSION';

export type SellerRole = 'SDR' | 'CLOSER' | 'MANAGER' | 'ADMIN' | 'VIEWER';

export type OnboardingStatus = 'COMPLETO' | 'EM_ANDAMENTO' | 'NÃO_INICIADO';

export interface SellerProfile {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: SellerRole;
  region: string;
  mainOffer: string;
  dailyContactGoal: number;
  onboardingStatus: OnboardingStatus;
  onboardingCompleted: boolean;
  assignedLeadsCount?: number;
  completedContactsToday?: number;
  dealsClosedCount?: number;
  createdAt: string;
}

export interface SellerFirstDayChecklist {
  onboardingCompleted: boolean;
  firstListGenerated: boolean;
  firstLeadOpened: boolean;
  firstContactMade: boolean;
  firstFollowUpCreated: boolean;
  firstPipelineUpdated: boolean;
}

export interface OfferFitScores {
  website: number;
  landingPage: number;
  googleProfile: number;
  crm: number;
  automation: number;
  socialPresence: number;
}

export interface ValidationCriteria {
  categoryMatch: boolean;
  locationMatch: boolean;
  noWebsiteFound: boolean;
  instagramFound: boolean;
  whatsappFound: boolean;
  ratingScore: number;
  reviewsCount: number;
}

export interface FactOrigin {
  value: string | number | boolean | null;
  source: 'google_places' | 'website_analyzer' | 'instagram' | 'duckdb' | 'manual';
  collectedAt: string;
  confidence: ConfidenceLevel;
}

export interface ScoreReason {
  reason: string;
  points: number;
}

export interface LeadPainPoint {
  problem: string;
  evidence: string;
  confidence: number;
}

export interface LeadInsight {
  summary: string;
  painPoints: LeadPainPoint[];
  opportunities: string[];
  recommendedOffer: string;
  recommendedAngle: string;
  icebreaker: string;
  priority: 'HIGH' | 'MEDIUM' | 'LOW';
  confidenceScore: number;
}

export interface LeadWebsiteAudit {
  url: string | null;
  statusCode?: number;
  hasHttps: boolean;
  isResponsive: boolean;
  title?: string | null;
  metaDescription?: string | null;
  hasCta: boolean;
  hasWhatsapp: boolean;
  hasForm: boolean;
  hasSocialLinks: boolean;
  performanceScore: number;
  seoScore: number;
  websiteScore: number;
  status: WebsiteStatus;
}

export interface LeadSocialProfile {
  platform: 'INSTAGRAM' | 'FACEBOOK' | 'LINKEDIN' | 'LINKTREE' | 'WHATSAPP' | 'OTHER';
  username?: string;
  url: string;
  followersCount?: number;
  isActive: boolean;
  lastPostAt?: string;
}

export interface LeadContact {
  id: string;
  name?: string;
  role?: string;
  phone?: string;
  email?: string;
  isWhatsapp: boolean;
  source: string;
}

export interface Lead {
  id: string;
  organizationId?: string;
  name: string;
  category: string;
  address: string;
  city: string;
  state: string;
  uf?: string;
  phone: string | null;
  website: string | null;
  socialUrl: string | null;
  social?: string | null;
  email: string | null;
  googlePlaceId?: string;
  rating: number;
  reviewsCount: number;
  mapsUrl?: string;
  lat?: number;
  lon?: number;
  sniperScore: number;
  scoreTier: ScoreTier;
  scoreBreakdown: ScoreReason[];
  confidenceLevel: ConfidenceLevel;
  confidence?: number;
  validationStatus?: LeadValidationStatus;
  opportunityTypes?: OpportunityType[];
  offerFitScores?: OfferFitScores;
  criteriaMatch?: ValidationCriteria;
  websiteStatus: WebsiteStatus;
  websiteScore: number;
  crmStatus: LeadCrmStatus;
  assignedTo?: string;
  facts: {
    name: FactOrigin;
    phone: FactOrigin;
    website: FactOrigin;
    social: FactOrigin;
    rating: FactOrigin;
    reviewsCount: FactOrigin;
  };
  audit?: LeadWebsiteAudit;
  socialProfiles?: LeadSocialProfile[];
  contacts?: LeadContact[];
  insights?: LeadInsight;
  firstSeenAt: string;
  lastSeenAt: string;
  isDemo?: boolean;
}

export interface SearchFilterParams {
  niche: string;
  location: string;
  radiusKm: number;
  limit: number;
  minReviews: number;
  requireInstagram: boolean;
  requireWhatsapp: boolean;
  websiteCondition: 'missing' | 'poor' | 'broken' | 'social' | 'any';
}

export interface OutreachScriptAI {
  id?: string;
  leadId?: string;
  channel: 'WHATSAPP' | 'INSTAGRAM' | 'EMAIL' | 'CALL_SCRIPT';
  tone: 'DIRECT' | 'CONSULTATIVE' | 'CASUAL' | 'EXECUTIVE';
  objective: string;
  content: string;
  createdAt?: string;
}

export interface CrmStage {
  id: string;
  name: LeadCrmStatus;
  label: string;
  color: string;
  position: number;
}

export interface CrmDeal {
  id: string;
  leadId: string;
  lead: Lead;
  stageId: string;
  status: LeadCrmStatus;
  dealValue: number;
  expectedClose?: string;
  position: number;
}

export type ProviderStatus = 'CONFIGURED' | 'DEMO_MODE' | 'NOT_CONFIGURED' | 'ERROR';

export interface ProviderHealth {
  name: string;
  status: ProviderStatus;
  message: string;
}
