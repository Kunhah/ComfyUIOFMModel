import { mkdirSync } from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { normalise } from "./cities";
import { nicheFingerprint, nicheForCategory } from "./niches";
import type { Lead, ScoredLead } from "./types";

/**
 * Local lead history, in SQLite.
 *
 * The search itself needs no database — Overture plus the local extract is the
 * whole engine. This adds the one thing a search can't tell you: whether you have
 * seen a business before. Without it, running the same city twice looks identical
 * both times and there is no way to spot the businesses that appeared since.
 *
 * `node:sqlite` ships with Node, so there is no dependency, no native build step
 * and nothing to keep out of the bundler. Its API is synchronous, which for a
 * single-user tool on localhost is a feature: a search writes ~1.000 rows in one
 * transaction in single-digit milliseconds, and there is no connection pool, no
 * network hop and no service to be down.
 *
 * The file sits next to the extract in `data/`, and is gitignored for the same
 * reason — it is local state, not source.
 */

const COLUMNS = [
  "id",
  "name",
  "category",
  "address",
  "city",
  "uf",
  "phone",
  "website",
  "social",
  "email",
  "lat",
  "lon",
  "confidence",
  "score",
  "whatsapp",
  "niche",
  "searched_city",
  "searched_uf",
  "search_norm",
] as const;

/**
 * Created on open rather than through migration tooling. This is a local
 * single-user database that can be deleted and rebuilt by re-running a search,
 * so versioned migrations would be ceremony with nothing to protect.
 */
const SCHEMA = `
  CREATE TABLE IF NOT EXISTS leads (
    -- Overture GERS id. Stable across releases, which is what makes dedupe work
    -- at all once the extract is re-synced.
    id            TEXT PRIMARY KEY,
    name          TEXT NOT NULL,
    category      TEXT,
    address       TEXT,
    city          TEXT,
    uf            TEXT,
    phone         TEXT,
    website       TEXT,
    social        TEXT,
    email         TEXT,
    lat           REAL,
    lon           REAL,
    confidence    REAL,
    score         INTEGER,
    whatsapp      INTEGER NOT NULL DEFAULT 0,
    -- Which search surfaced it, so a lead can be traced back to a niche/city.
    niche         TEXT,
    searched_city TEXT,
    searched_uf   TEXT,
    -- Name and address, accent- and punctuation-folded by the same normalise()
    -- the city index uses. SQLite has no strip_accents, so free-text search would
    -- otherwise miss "Estudio" for "Estúdio" — folding once on write is cheaper
    -- than failing to find the lead later.
    search_norm   TEXT,
    -- Outreach fields. Nothing writes these yet; they exist so adding a pipeline
    -- view later doesn't need a schema change.
    status        TEXT NOT NULL DEFAULT 'novo'
                  CHECK (status IN ('novo','contatado','respondeu','cliente','descartado')),
    notes         TEXT,
    contacted_at  TEXT,
    -- ISO-8601 UTC with milliseconds. datetime('now') was the obvious choice and
    -- is wrong twice over: it resolves to whole seconds, so two searches in the
    -- same second are indistinguishable, and it prints no timezone marker
    -- despite being UTC.
    first_seen_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    last_seen_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

`;

/**
 * Indexes are applied separately, and only after addMissingColumns() has run.
 * They have to be: CREATE INDEX on a column an older database doesn't have yet
 * throws, which killed the whole schema statement before the column could be
 * added — leaving the table permanently one migration behind and every search
 * failing with "no such column".
 */
const META = `
  CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
`;

const INDEXES = `
  CREATE INDEX IF NOT EXISTS leads_city_niche ON leads (searched_uf, searched_city, niche);
  CREATE INDEX IF NOT EXISTS leads_status ON leads (status);
  CREATE INDEX IF NOT EXISTS leads_score ON leads (score DESC);
  CREATE INDEX IF NOT EXISTS leads_search ON leads (search_norm);
`;

export function databasePath(): string {
  return (
    process.env.PROSPECTOR_DB ??
    path.join(process.cwd(), "data", "prospector.db")
  );
}

let db: DatabaseSync | null = null;

export function getDb(): DatabaseSync {
  if (db) return db;

  const file = databasePath();
  mkdirSync(path.dirname(file), { recursive: true });
  const handle = new DatabaseSync(file);

  // WAL survives an unclean shutdown without corrupting the file, and lets the
  // dev server's overlapping requests read while a write is in flight.
  handle.exec("PRAGMA journal_mode = WAL");
  // The default (FULL) fsyncs on every commit. NORMAL can lose the last few
  // commits if the machine loses power, which for a re-derivable lead cache is
  // the right trade for not fsyncing once per search.
  handle.exec("PRAGMA synchronous = NORMAL");
  handle.exec("PRAGMA foreign_keys = ON");
  handle.exec(SCHEMA);
  handle.exec(META);
  addMissingColumns(handle);
  handle.exec(INDEXES);
  reniche(handle);

  db = handle;
  return db;
}

/**
 * Additive schema catch-up for a database created by an older build.
 *
 * `CREATE TABLE IF NOT EXISTS` does nothing to a table that already exists, so
 * adding a column to SCHEMA left existing files behind — and because the column
 * is in the INSERT list, *every search* would fail with "no such column" rather
 * than degrading. That is too sharp an edge for a file people are told they can
 * keep, so missing columns get added on open.
 *
 * Deliberately only additive: no renames, no type changes, no drops. Anything
 * beyond that and deleting the file is the honest answer.
 */
function addMissingColumns(handle: DatabaseSync): void {
  const existing = new Set(
    (
      handle.prepare("PRAGMA table_info(leads)").all() as { name: string }[]
    ).map((c) => c.name),
  );

  const additive: { name: string; ddl: string }[] = [
    {
      name: "search_norm",
      ddl: "ALTER TABLE leads ADD COLUMN search_norm TEXT",
    },
  ];

  let addedSearchNorm = false;
  for (const col of additive) {
    if (existing.has(col.name)) continue;
    handle.exec(col.ddl);
    if (col.name === "search_norm") addedSearchNorm = true;
  }

  // A column added after the fact is NULL on every existing row, which would
  // quietly hide all your older leads from free-text search. Fill it in once.
  if (addedSearchNorm) {
    const rows = handle
      .prepare("SELECT id, name, address FROM leads")
      .all() as { id: string; name: string; address: string | null }[];
    const update = handle.prepare(
      "UPDATE leads SET search_norm = ? WHERE id = ?",
    );
    handle.exec("BEGIN");
    try {
      for (const r of rows) {
        update.run(normalise(`${r.name} ${r.address ?? ""}`), r.id);
      }
      handle.exec("COMMIT");
    } catch (err) {
      handle.exec("ROLLBACK");
      throw err;
    }
  }
}

/**
 * Re-derives every stored `niche` from the lead's category when the niche
 * vocabulary has changed since the database was last written.
 *
 * Without this, splitting or renaming a niche leaves the history full of slugs
 * that no longer exist — the filter offers "barbearias" while the rows still say
 * "barbearias-saloes", so a niche you have hundreds of leads in reads as empty.
 * Since the category is stored on every row and the mapping is now one-to-one,
 * the correct value can always be recomputed rather than guessed at.
 */
function reniche(handle: DatabaseSync): void {
  const KEY = "niche_fingerprint";
  const current = nicheFingerprint();

  const stored = handle
    .prepare("SELECT value FROM meta WHERE key = ?")
    .get(KEY) as { value: string } | undefined;
  if (stored?.value === current) return;

  const categories = handle
    .prepare("SELECT DISTINCT category FROM leads WHERE category IS NOT NULL")
    .all() as { category: string }[];

  handle.exec("BEGIN");
  try {
    // One UPDATE per category rather than per row: a city search stores up to
    // 1.000 rows but there are only ~55 categories in total.
    const update = handle.prepare(
      "UPDATE leads SET niche = ? WHERE category = ? AND niche IS NOT ?",
    );
    for (const { category } of categories) {
      const slug = nicheForCategory(category);
      if (slug) update.run(slug, category, slug);
    }
    handle
      .prepare(
        "INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
      )
      .run(KEY, current);
    handle.exec("COMMIT");
  } catch (err) {
    handle.exec("ROLLBACK");
    throw err;
  }
}

export type PersistMeta = { niche: string; city: string; uf: string };

export type PersistResult = {
  inserted: number;
  alreadyKnown: number;
  /** Ids not previously in the database, so the board can mark them. */
  newIds: string[];
};

/**
 * Upsert a batch of leads, reporting which were new.
 *
 * `first_seen_at` is deliberately never overwritten — it is the whole point of
 * keeping history. Everything else is refreshed, because a business that has
 * since published a website or changed its phone should update rather than
 * linger at whatever it looked like the first time it was seen.
 *
 * Returns null on failure rather than throwing: a database problem should cost
 * you the new-vs-seen badges, not the search results you just waited for.
 */
export function persistLeads(
  leads: ScoredLead[],
  meta: PersistMeta,
): { result: PersistResult | null; warning?: string } {
  if (leads.length === 0) {
    return { result: { inserted: 0, alreadyKnown: 0, newIds: [] } };
  }

  try {
    const handle = getDb();

    // Read the existing ids before writing, since the upsert destroys the
    // distinction. Chunked to stay well under SQLite's variable limit (999 by
    // default) — a city search returns up to 1.000 rows.
    const known = new Set<string>();
    for (let i = 0; i < leads.length; i += 500) {
      const chunk = leads.slice(i, i + 500);
      const holes = chunk.map(() => "?").join(",");
      const rows = handle
        .prepare(`SELECT id FROM leads WHERE id IN (${holes})`)
        .all(...chunk.map((l) => l.id)) as { id: string }[];
      for (const row of rows) known.add(row.id);
    }

    const assignments = COLUMNS.filter((c) => c !== "id")
      .map((c) => `${c} = excluded.${c}`)
      .join(", ");

    const upsert = handle.prepare(`
      INSERT INTO leads (${COLUMNS.join(", ")})
      VALUES (${COLUMNS.map(() => "?").join(", ")})
      ON CONFLICT(id) DO UPDATE SET
        ${assignments},
        last_seen_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
    `);

    // One transaction for the batch. Committing per row would fsync per row and
    // turn a 10ms write into seconds.
    handle.exec("BEGIN");
    try {
      for (const l of leads) {
        upsert.run(
          l.id,
          l.name,
          l.category,
          l.address,
          l.city,
          l.uf,
          l.phone,
          l.website,
          l.social,
          l.email,
          l.lat,
          l.lon,
          l.confidence,
          l.score,
          // SQLite has no boolean type; store the integer the column expects.
          l.whatsapp ? 1 : 0,
          // Derived from the business's own category, not from meta.niche. The
          // search's niche made this depend on which search ran last, so a lead
          // could change niche just by being found again.
          nicheForCategory(l.category) ?? meta.niche,
          meta.city,
          meta.uf,
          normalise(`${l.name} ${l.address ?? ""}`),
        );
      }
      handle.exec("COMMIT");
    } catch (err) {
      handle.exec("ROLLBACK");
      throw err;
    }

    const newIds = leads.map((l) => l.id).filter((id) => !known.has(id));
    return {
      result: {
        inserted: newIds.length,
        alreadyKnown: known.size,
        newIds,
      },
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return {
      result: null,
      warning: `Não foi possível salvar o histórico: ${message}`,
    };
  }
}

/** How much history exists, for the header. */
export function historyCount(): number {
  try {
    const row = getDb().prepare("SELECT count(*) AS n FROM leads").get() as
      { n: number } | undefined;
    return Number(row?.n ?? 0);
  } catch {
    return 0;
  }
}

export type { Lead };
