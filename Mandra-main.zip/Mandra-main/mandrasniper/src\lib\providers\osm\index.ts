import type { BoundingBox } from "@/lib/discovery/geo-grid";

export interface OsmBusinessRecord {
  id: string;
  name: string;
  category: string;
  lat: number;
  lon: number;
  address: string;
  phone: string | null;
  website: string | null;
  tags: Record<string, string>;
}

/**
 * Maps MANDRA business niches to OpenStreetMap Overpass query tags.
 */
function nicheToOsmTags(niche: string): string[] {
  const q = niche.toLowerCase();
  if (q.includes("barbearia") || q.includes("cabeleireiro")) return ['["shop"="hairdresser"]', '["shop"="barber"]'];
  if (q.includes("dentista") || q.includes("odonto")) return ['["healthcare"="dentist"]', '["amenity"="dentist"]'];
  if (q.includes("estética") || q.includes("spa")) return ['["shop"="beauty"]', '["leisure"="spa"]'];
  if (q.includes("restaurante") || q.includes("comida")) return ['["amenity"="restaurant"]', '["amenity"="fast_food"]'];
  if (q.includes("oficina") || q.includes("mecânica")) return ['["shop"="car_repair"]'];
  if (q.includes("pet") || q.includes("vet")) return ['["shop"="pet"]', '["amenity"="veterinary"]'];
  if (q.includes("academia") || q.includes("fitness")) return ['["leisure"="fitness_centre"]', '["leisure"="sports_centre"]'];
  if (q.includes("imobiliária") || q.includes("imoveis")) return ['["office"="estate_agent"]'];

  return ['["shop"]', '["amenity"]'];
}

export class OpenStreetMapProvider {
  /**
   * Queries public Overpass API for real businesses within a bounding box.
   */
  public async searchOsm(niche: string, bbox: BoundingBox, limit: number = 50): Promise<OsmBusinessRecord[]> {
    try {
      const tagQueries = nicheToOsmTags(niche);
      const bboxStr = `${bbox.ymin},${bbox.xmin},${bbox.ymax},${bbox.xmax}`;
      
      const query = `
        [out:json][timeout:15];
        (
          ${tagQueries.map((t) => `node${t}(${bboxStr});`).join("\n")}
        );
        out body ${limit};
      `;

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 6000);

      const res = await fetch("https://overpass-api.de/api/interpreter", {
        method: "POST",
        body: `data=${encodeURIComponent(query)}`,
        signal: controller.signal,
      });

      clearTimeout(timeout);

      if (!res.ok) {
        return [];
      }

      const data = await res.json();
      const elements = data.elements || [];

      const records: OsmBusinessRecord[] = [];
      for (const el of elements) {
        if (!el.tags || (!el.tags.name && !el.tags["brand"])) continue;

        const name = el.tags.name || el.tags["brand"];
        const phone = el.tags.phone || el.tags["contact:phone"] || el.tags["phone:mobile"] || null;
        const website = el.tags.website || el.tags["contact:website"] || el.tags["url"] || null;
        const street = el.tags["addr:street"] || "";
        const housenumber = el.tags["addr:housenumber"] || "";
        const suburb = el.tags["addr:suburb"] || el.tags["addr:neighbourhood"] || "";
        
        const addressParts = [street, housenumber, suburb].filter(Boolean);
        const address = addressParts.length > 0 ? addressParts.join(", ") : "Logradouro Mapeado OSM";

        records.push({
          id: `osm-${el.id}`,
          name,
          category: niche,
          lat: el.lat,
          lon: el.lon,
          address,
          phone,
          website,
          tags: el.tags,
        });
      }

      return records;
    } catch (e) {
      console.warn("OSM Overpass query exception fallback:", e);
      return [];
    }
  }
}
