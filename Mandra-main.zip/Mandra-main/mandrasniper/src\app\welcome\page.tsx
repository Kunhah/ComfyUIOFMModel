"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Sparkles,
  Target,
  MessageCircle,
  ArrowRight,
  CheckCircle2,
  XCircle,
  Building2,
  ShieldCheck,
  Zap,
  BookOpen,
  Play,
  Check,
  Calendar,
  Layers,
} from "lucide-react";

export default function WelcomeOnboardingPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);

  // Default initial configuration assigned by admin or preset
  const [offer] = useState("Landing Page de Agendamento");
  const [region] = useState("Campinas, SP");
  const [contactMade, setContactMade] = useState(false);

  const handleFinish = () => {
    if (typeof window !== "undefined") {
      localStorage.setItem("mandra_seller_onboarding_completed", "true");
    }
    router.push("/seller");
  };

  return (
    <div className="min-h-screen bg-[#101216] flex items-center justify-center p-4 text-white font-sans">
      <div className="w-full max-w-2xl rounded-3xl border border-[#2B2E3C] bg-[#14161C] p-8 shadow-2xl space-y-6">
        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-gray-400">
            <span className="text-[#FF9E1B] uppercase font-mono">NEW SELLER ONBOARDING</span>
            <span>Etapa {step} de 11</span>
          </div>
          <div className="h-1.5 w-full rounded-full bg-[#1E212A] overflow-hidden">
            <div
              className="h-full bg-[#FF9E1B] transition-all duration-300"
              style={{ width: `${(step / 11) * 100}%` }}
            />
          </div>
        </div>

        {/* STEP 1: BEM-VINDO À MANDRA */}
        {step === 1 && (
          <div className="text-center space-y-6 py-6">
            <div className="flex size-16 items-center justify-center rounded-3xl bg-[#FF9E1B]/15 text-[#FF9E1B] border border-[#FF9E1B]/30 mx-auto">
              <Sparkles className="size-8" />
            </div>
            <div className="space-y-2">
              <h1 className="text-3xl font-black text-white uppercase tracking-tight">
                BEM-VINDO À MANDRA.
              </h1>
              <p className="text-sm text-gray-400 max-w-md mx-auto">
                Você está prestes a começar sua prospecção comercial inteligente. Em 2 minutos você saberá quem abordar e o que falar.
              </p>
            </div>
            <button
              onClick={() => setStep(2)}
              className="inline-flex items-center gap-2 rounded-2xl bg-[#FF9E1B] px-8 py-4 text-xs font-black text-[#101216] hover:bg-[#F08E0B] transition shadow-lg"
            >
              <span>COMEÇAR MINHA JORNADA</span>
              <ArrowRight className="size-4" />
            </button>
          </div>
        )}

        {/* STEP 2: COMO FUNCIONA (3 CARDS) */}
        {step === 2 && (
          <div className="space-y-6">
            <h2 className="text-xl font-black text-white uppercase">COMO A MANDRA FUNCIONA</h2>
            <div className="grid gap-4 sm:grid-cols-3 text-xs">
              <div className="rounded-2xl border border-[#222530] bg-[#1A1C24] p-5 space-y-2">
                <div className="font-extrabold text-[#FF9E1B] text-sm">1. ENCONTRE</div>
                <p className="text-gray-300 leading-relaxed">
                  A plataforma mapeia milhares de empresas reais na sua cidade com oportunidade comercial real.
                </p>
              </div>
              <div className="rounded-2xl border border-[#222530] bg-[#1A1C24] p-5 space-y-2">
                <div className="font-extrabold text-[#FF9E1B] text-sm">2. PRIORIZE</div>
                <p className="text-gray-300 leading-relaxed">
                  O Sniper Score (0 a 100) calcula exatamente quais empresas valem a pena abordar primeiro.
                </p>
              </div>
              <div className="rounded-2xl border border-[#222530] bg-[#1A1C24] p-5 space-y-2">
                <div className="font-extrabold text-[#FF9E1B] text-sm">3. ABORDE</div>
                <p className="text-gray-300 leading-relaxed">
                  A IA cria mensagens personalizadas para o WhatsApp baseadas em fatos reais da empresa.
                </p>
              </div>
            </div>
            <div className="flex justify-end">
              <button
                onClick={() => setStep(3)}
                className="flex items-center gap-2 rounded-2xl bg-white px-7 py-3.5 text-xs font-bold text-[#101216] hover:bg-gray-100 transition"
              >
                <span>CONTINUAR</span>
                <ArrowRight className="size-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: SUA OFERTA PRINCIPAL */}
        {step === 3 && (
          <div className="space-y-6">
            <h2 className="text-xl font-black text-white uppercase">SUA OFERTA PRINCIPAL</h2>
            <div className="rounded-2xl border border-[#FF9E1B]/30 bg-[#1A1C24] p-6 space-y-3">
              <div className="text-xs font-bold text-[#FF9E1B] uppercase">Oferta Definida para Você:</div>
              <div className="text-2xl font-black text-white">{offer}</div>
              <p className="text-xs text-gray-300 leading-relaxed">
                Você vai procurar empresas que tenham presença digital e boa reputação no Google, mas que não possuem uma página própria para converter visitantes em agendamentos no WhatsApp.
              </p>
            </div>
            <div className="flex justify-end">
              <button
                onClick={() => setStep(4)}
                className="flex items-center gap-2 rounded-2xl bg-[#FF9E1B] px-7 py-3.5 text-xs font-black text-[#101216] hover:bg-[#F08E0B] transition"
              >
                <span>ENTENDI A MINHA OFERTA</span>
                <ArrowRight className="size-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: EXPLICAR QUEM É UM BOM LEAD */}
        {step === 4 && (
          <div className="space-y-6">
            <h2 className="text-xl font-black text-white uppercase">QUAL LEAD VOCÊ DEVE PROCURAR?</h2>
            <div className="grid gap-3 sm:grid-cols-2 text-xs">
              <div className="rounded-2xl border border-emerald-500/30 bg-emerald-950/20 p-5 space-y-2">
                <div className="font-extrabold text-emerald-400 text-sm flex items-center gap-1.5">
                  <CheckCircle2 className="size-4" />
                  EMPRESAS IDEAIS (PROCURAR):
                </div>
                <ul className="space-y-1.5 text-gray-300 font-medium">
                  <li>✓ Instagram ativo com postagens</li>
                  <li>✓ Boas avaliações no Google</li>
                  <li>✓ Telefone / WhatsApp disponível</li>
                  <li>✓ Negócio ativo com movimento</li>
                </ul>
              </div>

              <div className="rounded-2xl border border-amber-500/30 bg-amber-950/20 p-5 space-y-2">
                <div className="font-extrabold text-amber-400 text-sm flex items-center gap-1.5">
                  <XCircle className="size-4" />
                  GARGALO QUE GERAM VENDAS:
                </div>
                <ul className="space-y-1.5 text-gray-300 font-medium">
                  <li>✕ Não possuem site próprio</li>
                  <li>✕ Site antigo ou quebrado</li>
                  <li>✕ Não possuem agendamento direto</li>
                </ul>
              </div>
            </div>
            <div className="flex justify-end">
              <button
                onClick={() => setStep(5)}
                className="flex items-center gap-2 rounded-2xl bg-white px-7 py-3.5 text-xs font-bold text-[#101216] transition"
              >
                <span>ENTENDI O PERFIL DO LEAD</span>
                <ArrowRight className="size-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 5: EXPLICAR SNIPER SCORE */}
        {step === 5 && (
          <div className="space-y-6">
            <h2 className="text-xl font-black text-white uppercase">COMO ENTENDER O SNIPER SCORE</h2>
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between rounded-xl bg-[#1A1C24] p-3.5 border-l-4 border-[#FF9E1B]">
                <span className="font-extrabold text-white">90 – 100</span>
                <span className="font-black text-[#FF9E1B]">🔥 PRIORIDADE MÁXIMA (ABORDAR AGORA)</span>
              </div>
              <div className="flex items-center justify-between rounded-xl bg-[#1A1C24] p-3.5 border-l-4 border-emerald-500">
                <span className="font-extrabold text-white">75 – 89</span>
                <span className="font-black text-emerald-400">ÓTIMA OPORTUNIDADE</span>
              </div>
              <div className="flex items-center justify-between rounded-xl bg-[#1A1C24] p-3.5 border-l-4 border-blue-500">
                <span className="font-extrabold text-white">60 – 74</span>
                <span className="font-black text-blue-400">BOA OPORTUNIDADE</span>
              </div>
            </div>
            <p className="text-xs text-gray-400">
              💡 <em>Dica de Ouro: Quando tiver dúvidas sobre por onde começar o seu dia, sempre aborde primeiro os maiores scores da sua lista.</em>
            </p>
            <div className="flex justify-end">
              <button
                onClick={() => setStep(6)}
                className="flex items-center gap-2 rounded-2xl bg-[#FF9E1B] px-7 py-3.5 text-xs font-black text-[#101216] transition"
              >
                <span>GERAR MEUS PRIMEIROS LEADS</span>
                <ArrowRight className="size-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 6: PRIMEIRA PROSPECÇÃO GUIADA */}
        {step === 6 && (
          <div className="space-y-6 text-center py-4">
            <h2 className="text-xl font-black text-white uppercase">VAMOS GERAR SUA PRIMEIRA LISTA</h2>
            <p className="text-xs text-gray-300 max-w-md mx-auto">
              O sistema vai buscar automaticamente empresas de <strong>{offer}</strong> em <strong>{region}</strong>.
            </p>
            <button
              onClick={() => setStep(7)}
              className="inline-flex items-center gap-2.5 rounded-2xl bg-[#FF9E1B] px-8 py-4 text-xs font-black text-[#101216] hover:bg-[#F08E0B] transition shadow-lg"
            >
              <Sparkles className="size-4" />
              <span>BUSCAR LEADS EM {region.toUpperCase()}</span>
            </button>
          </div>
        )}

        {/* STEP 7: PRIMEIROS LEADS GUIADOS (TOP 5) */}
        {step === 7 && (
          <div className="space-y-6">
            <h2 className="text-xl font-black text-white uppercase">SEUS PRIMEIROS 5 LEADS ESTÃO PRONTOS!</h2>
            <div className="space-y-2 text-xs">
              {[
                { name: "Bella Estética Avançada", score: 94, reason: "184 avaliações + Instagram ativo + sem site" },
                { name: "Odonto Prime Cambuí", score: 92, reason: "Nota 4.9 no Google + sem agendamento direto" },
                { name: "Studio Masculino Barba & Corte", score: 89, reason: "Alta busca na região + sem domínio próprio" },
              ].map((item, idx) => (
                <div key={idx} className="rounded-xl border border-[#222530] bg-[#1A1C24] p-4 flex items-center justify-between">
                  <div>
                    <div className="font-extrabold text-white text-sm">{item.name}</div>
                    <div className="text-[11px] text-gray-400">{item.reason}</div>
                  </div>
                  <span className="rounded-lg bg-[#FF9E1B]/15 px-3 py-1 font-black text-[#FF9E1B] border border-[#FF9E1B]/30 tnum">
                    {item.score}
                  </span>
                </div>
              ))}
            </div>
            <div className="flex justify-end">
              <button
                onClick={() => setStep(8)}
                className="flex items-center gap-2 rounded-2xl bg-white px-7 py-3.5 text-xs font-bold text-[#101216] transition"
              >
                <span>VER COMO ABORDAR O PRIMEIRO LEAD</span>
                <ArrowRight className="size-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 8: PRIMEIRA ABORDAGEM GUIADA */}
        {step === 8 && (
          <div className="space-y-6">
            <h2 className="text-xl font-black text-white uppercase">SUA PRIMEIRA MENSAGEM PRONTA</h2>
            <div className="rounded-2xl border border-[#222530] bg-[#1A1C24] p-5 text-xs font-mono text-gray-300 leading-relaxed">
              "Oi, tudo bem? Vi que a Bella Estética possui 184 avaliações excelentes no Google em Campinas, mas hoje ainda não conta com uma página própria de agendamento no WhatsApp. Desenvolvemos uma estrutura de alta conversão para captar esses clientes. Posso enviar um exemplo de 2 minutos?"
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <button
                onClick={() => setContactMade(true)}
                className={`rounded-xl px-5 py-3 text-xs font-extrabold transition ${
                  contactMade ? "bg-emerald-600 text-white" : "bg-[#FF9E1B] text-[#101216]"
                }`}
              >
                {contactMade ? "✓ REGISTRADO: CONTATO REALIZADO" : "SIM, FIZ O CONTATO NO WHATSAPP"}
              </button>

              <button
                onClick={() => setStep(9)}
                className="flex items-center gap-2 rounded-2xl bg-white px-6 py-3 text-xs font-bold text-[#101216] transition"
              >
                <span>PRÓXIMO PASSO</span>
                <ArrowRight className="size-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 9: ENSINAR FOLLOW-UP */}
        {step === 9 && (
          <div className="space-y-6">
            <h2 className="text-xl font-black text-white uppercase">COMO FAZER FOLLOW-UP</h2>
            <p className="text-xs text-gray-300 leading-relaxed">
              Se o cliente não responder de imediato, não se preocupe. O sistema sugere automaticamente um lembrete de follow-up em <strong>2 dias</strong> para manter o contato aquecido.
            </p>
            <div className="flex justify-end">
              <button
                onClick={() => setStep(10)}
                className="flex items-center gap-2 rounded-2xl bg-white px-7 py-3.5 text-xs font-bold text-[#101216] transition"
              >
                <span>ENTENDI O FOLLOW-UP</span>
                <ArrowRight className="size-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 10: CRM SIMPLIFICADO */}
        {step === 10 && (
          <div className="space-y-6">
            <h2 className="text-xl font-black text-white uppercase">ACOMPANHE SUA VENDA (CRM)</h2>
            <div className="grid grid-cols-5 gap-2 text-center text-[10px] font-bold">
              <div className="rounded-xl bg-[#1A1C24] p-3 border-t-2 border-[#FF9E1B]">1. NOVO</div>
              <div className="rounded-xl bg-[#1A1C24] p-3 border-t-2 border-[#FF9E1B]">2. CONTATADO</div>
              <div className="rounded-xl bg-[#1A1C24] p-3 border-t-2 border-emerald-500">3. RESPONDEU</div>
              <div className="rounded-xl bg-[#1A1C24] p-3 border-t-2 border-blue-500">4. PROPOSTA</div>
              <div className="rounded-xl bg-[#1A1C24] p-3 border-t-2 border-emerald-400">5. VENDA</div>
            </div>
            <div className="flex justify-end">
              <button
                onClick={() => setStep(11)}
                className="flex items-center gap-2 rounded-2xl bg-[#FF9E1B] px-7 py-3.5 text-xs font-black text-[#101216] transition"
              >
                <span>FINALIZAR TREINAMENTO</span>
                <ArrowRight className="size-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 11: PRONTO! (FINAL) */}
        {step === 11 && (
          <div className="text-center space-y-6 py-4">
            <div className="flex size-16 items-center justify-center rounded-3xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 mx-auto">
              <Check className="size-8" />
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-black text-white uppercase">VOCÊ ESTÁ PRONTO!</h2>
              <p className="text-xs text-gray-300 max-w-md mx-auto">
                Você aprendeu a gerar leads, filtrar os melhores scores, abordar pelo WhatsApp e acompanhar suas vendas.
              </p>
            </div>
            <button
              onClick={handleFinish}
              className="inline-flex items-center gap-2 rounded-2xl bg-[#FF9E1B] px-8 py-4 text-xs font-black text-[#101216] hover:bg-[#F08E0B] transition shadow-lg"
            >
              <span>IR PARA MINHA ÁREA DE TRABALHO</span>
              <ArrowRight className="size-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
