import { searchCities } from "@/lib/cities";

// The city index is a ~480KB module. Keeping the lookup server-side means the
// browser never downloads it just to autocomplete a text field.
export const runtime = "nodejs";

export async function GET(request: Request): Promise<Response> {
  const q = new URL(request.url).searchParams.get("q") ?? "";
  // Only what the picker renders. The bounding box is a query-planning detail
  // and would roughly double the response for nothing.
  const cities = searchCities(q, 12).map((c) => ({
    name: c.name,
    uf: c.uf,
    businesses: c.businesses,
    noSite: c.noSite,
  }));
  return Response.json({ cities });
}
