import { NextResponse } from "next/server";
import { OpenAIProvider } from "@/lib/ai/openai";
import { MandraRepository } from "@/lib/db/repository";

export const runtime = "nodejs";

const aiProvider = new OpenAIProvider();
const repo = new MandraRepository();

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { promptText, filterParams, searchMode = "DEEP_SEARCH", searchDepth = "DEEP" } = body;

    let params = filterParams;

    // If natural language promptText is supplied, interpret it with AI server-side
    if (promptText && promptText.trim().length > 0) {
      params = await aiProvider.interpretSearchPrompt(promptText);
    }

    if (!params || !params.niche || !params.location) {
      return NextResponse.json(
        { error: "Nicho e localização são obrigatórios." },
        { status: 400 }
      );
    }

    // Save search history
    await repo.saveSearch(
      `${params.niche.toUpperCase()} em ${params.location}`,
      promptText || `${params.niche} em ${params.location}`,
      params
    );

    // Execute multi-source prospecting job
    const jobResult = await repo.runProspectingJob(params, { searchMode, searchDepth });

    return NextResponse.json({
      success: true,
      jobId: jobResult.jobId,
      isDemo: jobResult.isDemo,
      parsedParams: params,
      leads: jobResult.leads,
      debugLog: jobResult.debugLog,
      totalCount: jobResult.leads.length,
    });
  } catch (err) {
    console.error("Prospecting API error:", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Erro ao processar prospecção" },
      { status: 500 }
    );
  }
}
