"use client";

import React, { useState } from "react";
import { ThumbsUp, ThumbsDown, AlertTriangle, Check, X, ShieldAlert } from "lucide-react";
import type { Lead } from "@/types";

export function LeadFeedbackModal({
  lead,
  open,
  onClose,
}: {
  lead: Lead | null;
  open: boolean;
  onClose: () => void;
}) {
  const [reason, setReason] = useState("Telefone incorreto");
  const [sent, setSent] = useState(false);

  if (!open || !lead) return null;

  const handleSubmit = () => {
    setSent(true);
    setTimeout(() => {
      setSent(false);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
      <div className="w-full max-w-md rounded-3xl border border-[#ECE8E0] bg-white p-6 text-[#1E2026] shadow-2xl space-y-5">
        <div className="flex items-center justify-between border-b border-[#ECE8E0] pb-3">
          <div className="flex items-center gap-2 font-extrabold text-sm text-[#1E2026]">
            <ShieldAlert className="size-4 text-amber-500" />
            <span>REPORTAR DADO INCORRETO</span>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-gray-400 hover:bg-gray-100">
            <X className="size-4" />
          </button>
        </div>

        {sent ? (
          <div className="py-8 text-center text-xs font-bold text-emerald-600 space-y-2">
            <Check className="size-8 mx-auto text-emerald-600" />
            <div>Obrigado! Feedback registrado para revalidação de dados.</div>
          </div>
        ) : (
          <div className="space-y-4 text-xs">
            <div className="text-[#6E7381]">
              Qual informação sobre <strong>{lead.name}</strong> precisa ser corrigida?
            </div>

            <div className="grid gap-2 font-bold">
              {[
                "Telefone incorreto",
                "Website informado está errado",
                "Perfil do Instagram incorreto",
                "Empresa fechada permanentemente",
                "Localização ou cidade errada",
                "Não faz parte do nicho correto",
              ].map((item) => (
                <button
                  key={item}
                  onClick={() => setReason(item)}
                  className={`rounded-xl border p-3 text-left transition ${
                    reason === item
                      ? "border-amber-500 bg-amber-50 text-amber-900"
                      : "border-[#ECE8E0] bg-[#FAF8F4] text-[#1E2026]"
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={handleSubmit}
                className="rounded-xl bg-[#1C1F26] px-5 py-2.5 text-xs font-bold text-white hover:bg-[#2A2E38] transition"
              >
                ENVIAR RELATÓRIO
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
