import { setStatus } from "@/lib/history";
import { LEAD_STATUSES, type LeadStatus } from "@/lib/types";

// node:sqlite is a Node builtin, so this can't run on the edge runtime.
export const runtime = "nodejs";

/** Move one lead along the pipeline. Called by the status dropdown. */
export async function POST(request: Request): Promise<Response> {
  let body: { id?: string; status?: string };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const id = String(body.id ?? "");
  const status = String(body.status ?? "");
  if (!id) return Response.json({ error: "id ausente." }, { status: 400 });
  if (!LEAD_STATUSES.includes(status as LeadStatus)) {
    return Response.json(
      { error: `Situação inválida: ${status}` },
      { status: 400 },
    );
  }

  // False means no row matched — a stale page pointing at a deleted database,
  // which the client should hear about rather than see silently succeed.
  const ok = setStatus(id, status as LeadStatus);
  if (!ok) {
    return Response.json({ error: "Lead não encontrado." }, { status: 404 });
  }
  return Response.json({ ok: true });
}
