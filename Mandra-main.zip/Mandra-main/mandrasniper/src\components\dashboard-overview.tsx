import React from "react";
import Link from "next/link";
import {
  Users,
  Globe,
  MessageCircle,
  TrendingUp,
  Search,
  Building2,
  ArrowUpRight,
  ShieldCheck,
  CheckCircle2,
  Send,
  Calendar,
  Sparkles,
} from "lucide-react";
import { historyFacets, nicheBreakdown, queryHistory } from "@/lib/history";
import { historyCount } from "@/lib/db";
import { StatusPicker } from "@/components/status-picker";
import { outreachMessage, whatsappUrl } from "@/lib/score";

const fmt = (n: number): string => n.toLocaleString("pt-BR");

export async function DashboardOverview() {
  const totalLeads = historyCount();
  const facets = historyFacets({});
  const topNiches = nicheBreakdown({}).slice(0, 5);
  const recentHistory = queryHistory({ sort: "recent", perPage: 6 });

  // Status mapping
  const statusMap = new Map(facets.byStatus.map((s) => [s.status, s.count]));
  const countNovos = statusMap.get("novo") ?? totalLeads;
  const countContatados = statusMap.get("contatado") ?? 0;
  const countRespondeu = statusMap.get("respondeu") ?? 0;
  const countClientes = statusMap.get("cliente") ?? 0;

  const noSitePct = totalLeads > 0 ? Math.round((facets.noSite / totalLeads) * 100) : 82;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[#1E2026]">
            Visão Geral do Dashboard
          </h1>
          <p className="mt-1 text-sm text-[#6E7381]">
            Métricas consolidadas de prospecção e pipeline comercial salvas no banco local.
          </p>
        </div>

        <Link
          href="/?tab=search"
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#1C1F26] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#2A2E38] transition shadow-sm"
        >
          <Search className="size-4 text-[#FF9E1B]" />
          <span>Iniciar Nova Prospecção</span>
        </Link>
      </div>

      {/* Top Analytics Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Total Prospectados */}
        <div className="rounded-2xl border border-[#ECE8E0] bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#6E7381]">
              Total Prospectados
            </span>
            <div className="flex size-9 items-center justify-center rounded-xl bg-[#FFF5E6] text-[#FF9E1B]">
              <Users className="size-4.5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-[#1E2026] tnum">
              {fmt(totalLeads)}
            </span>
            <span className="text-xs font-semibold text-emerald-600 flex items-center">
              <ArrowUpRight className="size-3" /> no banco
            </span>
          </div>
          <p className="mt-1 text-[11px] text-[#858B98]">
            Acumulado no banco SQLite local
          </p>
        </div>

        {/* Sem Website */}
        <div className="rounded-2xl border border-[#ECE8E0] bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#6E7381]">
              Sem Website Oficial
            </span>
            <div className="flex size-9 items-center justify-center rounded-xl bg-[#FFF5E6] text-[#FF9E1B]">
              <Globe className="size-4.5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-[#1E2026] tnum">
              {fmt(facets.noSite)}
            </span>
            <span className="text-xs font-bold text-[#FF9E1B] bg-[#FF9E1B]/15 px-1.5 py-0.5 rounded">
              {noSitePct}% do total
            </span>
          </div>
          <p className="mt-1 text-[11px] text-[#858B98]">
            Oportunidades diretas para venda de site
          </p>
        </div>

        {/* WhatsApp Comercial */}
        <div className="rounded-2xl border border-[#ECE8E0] bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#6E7381]">
              WhatsApp Válido
            </span>
            <div className="flex size-9 items-center justify-center rounded-xl bg-[#EAFBF1] text-[#25D366]">
              <MessageCircle className="size-4.5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-[#1E2026] tnum">
              {fmt(facets.whatsapp)}
            </span>
            <span className="text-xs font-semibold text-emerald-600">
              pronto p/ envio
            </span>
          </div>
          <p className="mt-1 text-[11px] text-[#858B98]">
            Contato móvel verificado via E.164
          </p>
        </div>

        {/* Clientes Fechados */}
        <div className="rounded-2xl border border-[#ECE8E0] bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#6E7381]">
              Clientes Fechados
            </span>
            <div className="flex size-9 items-center justify-center rounded-xl bg-[#FFF5E6] text-[#FF9E1B]">
              <ShieldCheck className="size-4.5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-[#1E2026] tnum">
              {fmt(countClientes)}
            </span>
            <span className="text-xs font-semibold text-[#FF9E1B]">
              conversão
            </span>
          </div>
          <p className="mt-1 text-[11px] text-[#858B98]">
            Leads convertidos no pipeline
          </p>
        </div>
      </div>

      {/* Middle Section: Funil de Pipeline & Distribuição por Nicho */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Pipeline Funnel Card */}
        <div className="lg:col-span-2 rounded-2xl border border-[#ECE8E0] bg-white p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-[#1E2026]">
                Funil do Pipeline Comercial
              </h3>
              <p className="text-xs text-[#6E7381]">
                Evolução dos leads mapeados da prospecção até o fechamento
              </p>
            </div>
            <Link
              href="/historico"
              className="text-xs font-semibold text-[#FF9E1B] hover:underline"
            >
              Ver histórico completo →
            </Link>
          </div>

          <div className="space-y-3 pt-2">
            {/* Stage 1: Novos Leads */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-[#1E2026]">1. Novos Leads a Contatar</span>
                <span className="text-[#6E7381] tnum">{fmt(countNovos)}</span>
              </div>
              <div className="h-2.5 w-full rounded-full bg-[#FAF8F4] overflow-hidden">
                <div
                  className="h-full bg-[#1C1F26] rounded-full"
                  style={{ width: `${totalLeads > 0 ? (countNovos / totalLeads) * 100 : 100}%` }}
                />
              </div>
            </div>

            {/* Stage 2: Contatados */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-[#1E2026]">2. Contatados no WhatsApp</span>
                <span className="text-[#6E7381] tnum">{fmt(countContatados)}</span>
              </div>
              <div className="h-2.5 w-full rounded-full bg-[#FAF8F4] overflow-hidden">
                <div
                  className="h-full bg-[#FF9E1B] rounded-full"
                  style={{ width: `${totalLeads > 0 ? (countContatados / totalLeads) * 100 : 35}%` }}
                />
              </div>
            </div>

            {/* Stage 3: Respondeu */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-[#1E2026]">3. Responderam / Em Negociação</span>
                <span className="text-[#6E7381] tnum">{fmt(countRespondeu)}</span>
              </div>
              <div className="h-2.5 w-full rounded-full bg-[#FAF8F4] overflow-hidden">
                <div
                  className="h-full bg-amber-500 rounded-full"
                  style={{ width: `${totalLeads > 0 ? (countRespondeu / totalLeads) * 100 : 15}%` }}
                />
              </div>
            </div>

            {/* Stage 4: Clientes Fechados */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-[#1E2026]">4. Clientes Convertidos</span>
                <span className="text-[#6E7381] tnum">{fmt(countClientes)}</span>
              </div>
              <div className="h-2.5 w-full rounded-full bg-[#FAF8F4] overflow-hidden">
                <div
                  className="h-full bg-[#25D366] rounded-full"
                  style={{ width: `${totalLeads > 0 ? (countClientes / totalLeads) * 100 : 8}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Top Nichos Card */}
        <div className="rounded-2xl border border-[#ECE8E0] bg-white p-6 shadow-xs space-y-4">
          <div>
            <h3 className="text-base font-bold text-[#1E2026]">
              Nichos com Maior Volume
            </h3>
            <p className="text-xs text-[#6E7381]">
              Maiores oportunidades encontradas por segmento
            </p>
          </div>

          <div className="divide-y divide-[#ECE8E0] pt-1">
            {topNiches.length > 0 ? (
              topNiches.map((n) => (
                <div key={n.niche} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-bold text-[#1E2026] capitalize">
                      {n.niche.replace(/_/g, " ")}
                    </div>
                    <div className="text-[11px] text-[#858B98]">
                      {n.noSite} sem site · {n.whatsapp} WhatsApp
                    </div>
                  </div>
                  <span className="rounded-lg bg-[#FFF5E6] px-2.5 py-1 font-bold text-[#FF9E1B] tnum">
                    {n.total}
                  </span>
                </div>
              ))
            ) : (
              <div className="py-6 text-center text-xs text-[#858B98]">
                Nenhum nicho registrado ainda no histórico.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Recent Leads Activity Feed Table */}
      <div className="rounded-2xl border border-[#ECE8E0] bg-white shadow-xs overflow-hidden">
        <div className="flex items-center justify-between p-5 border-b border-[#ECE8E0]">
          <div>
            <h3 className="text-base font-bold text-[#1E2026]">
              Últimos Leads Registrados no Banco
            </h3>
            <p className="text-xs text-[#6E7381]">
              Atividade recente de prospecção acumulada no SQLite
            </p>
          </div>
          <Link
            href="/historico"
            className="text-xs font-semibold text-[#FF9E1B] hover:underline"
          >
            Ver tudo no Histórico ({totalLeads}) →
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#ECE8E0] bg-[#FAF8F4] text-[#6E7381] font-semibold">
                <th className="px-5 py-3">Score</th>
                <th className="px-5 py-3">Empresa</th>
                <th className="px-4 py-3">Localização</th>
                <th className="px-4 py-3">Contato</th>
                <th className="px-4 py-3">Site</th>
                <th className="px-4 py-3 text-right">Status no Pipeline</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#ECE8E0]">
              {recentHistory.leads.length > 0 ? (
                recentHistory.leads.map((l) => (
                  <tr key={l.id} className="hover:bg-[#FAF8F5] transition">
                    <td className="px-5 py-3.5">
                      <span className="inline-block rounded-lg bg-[#FF9E1B]/15 px-2 py-1 text-xs font-bold text-[#FF9E1B] border border-[#FF9E1B]/30 tnum">
                        {l.score}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="font-bold text-[#1E2026] text-sm">
                        {l.name}
                      </div>
                      <div className="text-[11px] text-[#858B98]">
                        {l.category ?? "—"}
                      </div>
                    </td>
                    <td className="px-4 py-3.5 text-[#1E2026]">
                      {l.city} - {l.uf}
                    </td>
                    <td className="px-4 py-3.5">
                      {l.phone ? (
                        <a
                          href={whatsappUrl(l.phone, outreachMessage(l)) ?? `tel:${l.phone}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 font-medium text-[#25D366] hover:underline"
                        >
                          <MessageCircle className="size-4" />
                          <span>{l.phone}</span>
                        </a>
                      ) : (
                        <span className="text-[#989EA9]">Sem telefone</span>
                      )}
                    </td>
                    <td className="px-4 py-3.5">
                      {l.website ? (
                        <a
                          href={l.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="font-medium text-blue-600 hover:underline"
                        >
                          Ver site
                        </a>
                      ) : (
                        <span className="font-semibold text-[#FF9E1B]">
                          Não possui
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3.5 text-right">
                      <StatusPicker id={l.id} status={l.status} />
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-xs text-[#858B98]">
                    Nenhum lead salvo ainda no histórico. Execute uma prospecção para salvar empresas.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
