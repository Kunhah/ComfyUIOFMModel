"use client";

import React, { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Bell,
  Calendar,
  ChevronDown,
  Home,
  Layers,
  LineChart,
  MessageSquare,
  Search,
  Send,
  Settings,
  Users,
  X,
  Menu,
} from "lucide-react";
import { MandraLogo } from "@/components/mandra-logo";

const NAV_ITEMS = [
  { label: "Dashboard", href: "/", tab: "dashboard", icon: Home },
  { label: "Buscar Leads", href: "/?tab=search", tab: "search", icon: Search },
  { label: "Leads Encontrados", href: "/historico", tab: "historico", icon: Users },
  { label: "Mensagens", href: "/?tab=messages", tab: "messages", icon: MessageSquare },
  { label: "Campanhas", href: "/historico?status=contatado", tab: "campanhas", icon: Send },
  { label: "Agendamentos", href: "/historico?status=respondeu", tab: "agendamentos", icon: Calendar },
  { label: "Relatórios", href: "/", tab: "dashboard", icon: LineChart },
  { label: "Integrações", href: "/", tab: "dashboard", icon: Layers },
  { label: "Configurações", href: "/", tab: "dashboard", icon: Settings },
];

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-[#FAF8F4] text-[#1E2026]">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Left Sidebar */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 flex w-[250px] flex-col justify-between border-r border-[#22252C] bg-[#14161C] text-[#9A9FA9] transition-transform duration-200 ease-in-out md:static md:translate-x-0 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div>
          {/* Sidebar Header Logo */}
          <div className="flex h-16 items-center justify-between px-5 border-b border-[#1E2129]">
            <MandraLogo dark />
            <button
              onClick={() => setSidebarOpen(false)}
              className="rounded p-1 text-gray-400 hover:text-white md:hidden"
            >
              <X className="size-5" />
            </button>
          </div>

          {/* Navigation Items */}
          <nav className="mt-4 px-3 space-y-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const currentTab = typeof window !== "undefined" ? new URLSearchParams(window.location.search).get("tab") : null;
              
              let isActive = false;
              if (item.tab === "dashboard") {
                isActive = pathname === "/" && (!currentTab || currentTab === "dashboard");
              } else if (item.tab === "search") {
                isActive = pathname === "/" && currentTab === "search";
              } else if (item.tab === "messages") {
                isActive = pathname === "/" && currentTab === "messages";
              } else {
                isActive = pathname.startsWith(item.href) && item.href !== "/";
              }

              return (
                <Link
                  key={item.label}
                  href={item.href}
                  className={`group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition ${
                    isActive
                      ? "bg-[#22252C] text-white font-semibold shadow-sm border-l-2 border-[#FF9E1B]"
                      : "text-[#9A9FA9] hover:bg-[#1C1E26] hover:text-white"
                  }`}
                >
                  <Icon
                    className={`size-4.5 transition ${
                      isActive
                        ? "text-[#FF9E1B]"
                        : "text-[#858B98] group-hover:text-white"
                    }`}
                  />
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Bottom Sidebar Widget: "Dica Mandra" Mascot Card */}
        <div className="p-4">
          <div className="relative overflow-hidden rounded-xl border border-[#2B2F3A] bg-[#191B22] p-4 text-white shadow-lg">
            <div className="flex items-center gap-3 mb-2">
              {/* Mascot Mini Badge */}
              <div className="flex size-9 items-center justify-center rounded-lg bg-[#252834]">
                <span className="text-lg">🔍</span>
              </div>
              <span className="text-xs font-semibold text-[#FF9E1B] tracking-wide uppercase">
                Dica Mandra
              </span>
            </div>
            <p className="text-xs leading-relaxed text-[#B0B5C0]">
              Quanto mais filtros você usa, mais assertivos serão seus leads.
            </p>

            {/* Progress bar line matching screenshot */}
            <div className="mt-3 h-1.5 w-full rounded-full bg-[#2A2E3B] overflow-hidden">
              <div className="h-full w-1/3 rounded-full bg-[#FF9E1B]" />
            </div>
          </div>
        </div>
      </aside>

      {/* Main Workspace Container */}
      <div className="flex flex-1 flex-col min-w-0">
        {/* Top Header Bar */}
        <header className="flex h-16 items-center justify-between border-b border-[#ECE8E0] bg-[#FAF8F4] px-6">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="rounded-lg p-2 text-gray-600 hover:bg-gray-200 md:hidden"
            >
              <Menu className="size-5" />
            </button>
          </div>

          <div className="flex items-center gap-4">
            {/* Bell Notifications */}
            <button className="relative rounded-full p-2 text-[#6E7381] hover:bg-[#EFECE6] hover:text-[#1E2026] transition">
              <Bell className="size-5" />
              <span className="absolute top-1.5 right-1.5 size-2 rounded-full bg-[#FF9E1B]" />
            </button>

            {/* User Profile Info */}
            <div className="flex items-center gap-3 border-l border-[#ECE8E0] pl-4">
              <div className="flex size-8 items-center justify-center rounded-full bg-[#252830] text-xs font-bold text-white shadow-sm">
                G
              </div>
              <div className="hidden text-left sm:block">
                <div className="text-xs font-bold text-[#1E2026]">
                  Guilherme Silva
                </div>
                <div className="text-[11px] text-[#6E7381]">
                  Diretor Comercial
                </div>
              </div>
              <ChevronDown className="size-4 text-[#858B98]" />
            </div>
          </div>
        </header>

        {/* Dynamic Page Content */}
        <main className="flex-1 px-6 py-6 overflow-y-auto">{children}</main>
      </div>
    </div>
  );
}
