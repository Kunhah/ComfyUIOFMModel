import { getDb } from "./db";
import { normalise } from "./cities";
import { scoreLead } from "./score";
import { LEAD_STATUSES, type LeadStatus, type StoredLead } from "./types";

/**
 * Reading the local history back out.
 *
 * Everything a search finds is written to SQLite, and until this existed none of
 * it could be looked at again — the board only ever showed the search you had
 * just run, so the accumulated database was write-only. This is the read side:
 * browse it, filter it, export it.
 *
 * Filters arrive from the query string and are all optional, so the page is a
 * plain GET form. That keeps every view shareable as a URL and working without
 * JavaScript, the same way searches already do.
 */

export type HistoryFilters = {
  /** Free text over name and address. */
  q?: string;
  niche?: string;
  uf?: string;
  city?: string;
  status?: LeadStatus;
  /** Only rows whose phone is a WhatsApp-capable mobile. */
  onlyWhatsapp?: boolean;
  /** Only rows with no website — the sellable pool. */
  onlyNoSite?: boolean;
  minScore?: number;
  sort?: "score" | "recent" | "oldest" | "name";
  page?: number;
  perPage?: number;
};

export type HistoryPage = {
  leads: StoredLead[];
  total: number;
  page: number;
  perPage: number;
  pages: number;
};

export type HistoryFacets = {
  total: number;
  noSite: number;
  whatsapp: number;
  byStatus: { status: LeadStatus; count: number }[];
  niches: { niche: string; count: number }[];
  cities: { city: string; uf: string; count: number }[];
};

/** One row of the per-niche breakdown. */
export type NicheBreakdown = {
  niche: string;
  total: number;
  noSite: number;
  whatsapp: number;
  /** Anything past 'novo' — how far along that niche's outreach is. */
  worked: number;
};

type Row = {
  id: string;
  name: string;
  category: string | null;
  address: string | null;
  city: string | null;
  uf: string | null;
  phone: string | null;
  website: string | null;
  social: string | null;
  email: string | null;
  lat: number | null;
  lon: number | null;
  confidence: number | null;
  status: string;
  niche: string | null;
  searched_city: string | null;
  searched_uf: string | null;
  first_seen_at: string;
  last_seen_at: string;
};

/** Everything we bind is a string or a number; naming that keeps node:sqlite happy. */
type Param = string | number;

/**
 * Builds the shared WHERE clause. Every filter is a bound parameter — the free
 * text one especially, since it comes straight from a query string.
 */
function where(f: HistoryFilters): { sql: string; params: Param[] } {
  const clauses: string[] = [];
  const params: Param[] = [];

  const needle = normalise(f.q ?? "");
  if (needle.length > 0) {
    // Matched against `search_norm`, which db.ts folds on write with the same
    // normalise() the city index uses — so "estudio" finds "Estúdio" and
    // "sao joao" finds "São João". Covers name and address together.
    clauses.push("instr(search_norm, ?) > 0");
    params.push(needle);
  }
  if (f.niche) {
    clauses.push("niche = ?");
    params.push(f.niche);
  }
  if (f.uf) {
    clauses.push("uf = ?");
    params.push(f.uf.toUpperCase());
  }
  if (f.city) {
    clauses.push("city = ?");
    params.push(f.city);
  }
  if (f.status) {
    clauses.push("status = ?");
    params.push(f.status);
  }
  if (f.onlyWhatsapp) clauses.push("whatsapp = 1");
  if (f.onlyNoSite) clauses.push("(website IS NULL OR website = '')");
  if (typeof f.minScore === "number" && f.minScore > 0) {
    clauses.push("score >= ?");
    params.push(f.minScore);
  }

  return {
    sql: clauses.length > 0 ? `WHERE ${clauses.join(" AND ")}` : "",
    params,
  };
}

const ORDER: Record<NonNullable<HistoryFilters["sort"]>, string> = {
  // Same tiebreak as the live board: confidence, not name, because scores bunch
  // at the ceiling and alphabetical ordering buries the best records under
  // every business starting with "A".
  score: "score DESC, confidence DESC",
  recent: "first_seen_at DESC, score DESC",
  oldest: "first_seen_at ASC, score DESC",
  name: "name COLLATE NOCASE ASC",
};

function toStored(r: Row): StoredLead {
  const scored = scoreLead({
    id: r.id,
    name: r.name,
    category: r.category,
    address: r.address,
    city: r.city,
    uf: r.uf,
    phone: r.phone,
    website: r.website,
    social: r.social,
    email: r.email,
    lat: r.lat,
    lon: r.lon,
    confidence: r.confidence ?? 0,
  });

  // Score and reasons are recomputed rather than read back. The stored score is
  // what SQL sorts and filters on (it's indexed), but the rules live in score.ts
  // and recomputing means a row displays under today's rules instead of whatever
  // was in force the day it was first saved.
  return {
    ...scored,
    status: (LEAD_STATUSES as string[]).includes(r.status)
      ? (r.status as LeadStatus)
      : "novo",
    niche: r.niche,
    searchedCity: r.searched_city,
    searchedUf: r.searched_uf,
    firstSeenAt: r.first_seen_at,
    lastSeenAt: r.last_seen_at,
  };
}

export function queryHistory(f: HistoryFilters): HistoryPage {
  const db = getDb();
  const { sql: whereSql, params } = where(f);

  const perPage = clamp(f.perPage ?? 100, 1, 1000);
  const total = Number(
    (
      db
        .prepare(`SELECT count(*) AS n FROM leads ${whereSql}`)
        .get(...params) as { n: number }
    ).n,
  );

  const pages = Math.max(1, Math.ceil(total / perPage));
  const page = clamp(f.page ?? 1, 1, pages);
  const order = ORDER[f.sort ?? "score"];

  const rows = db
    .prepare(
      `SELECT id, name, category, address, city, uf, phone, website, social,
              email, lat, lon, confidence, status, niche, searched_city,
              searched_uf, first_seen_at, last_seen_at
       FROM leads ${whereSql}
       ORDER BY ${order}
       LIMIT ? OFFSET ?`,
    )
    .all(...params, perPage, (page - 1) * perPage) as Row[];

  return { leads: rows.map(toStored), total, page, perPage, pages };
}

/**
 * Every row matching the filters, for the CSV export. Deliberately unpaginated:
 * exporting only the page you happen to be looking at is the behaviour that made
 * the board's export feel broken on wide searches.
 */
export function allMatching(f: HistoryFilters): StoredLead[] {
  const db = getDb();
  const { sql: whereSql, params } = where(f);
  const rows = db
    .prepare(
      `SELECT id, name, category, address, city, uf, phone, website, social,
              email, lat, lon, confidence, status, niche, searched_city,
              searched_uf, first_seen_at, last_seen_at
       FROM leads ${whereSql}
       ORDER BY ${ORDER[f.sort ?? "score"]}`,
    )
    .all(...params) as Row[];
  return rows.map(toStored);
}

/**
 * Counts for the filter bar. Scoped to the current filters *except* the one each
 * facet drives, so the numbers describe what picking an option would give you.
 */
export function historyFacets(f: HistoryFilters): HistoryFacets {
  const db = getDb();
  const base = where(f);

  const scalar = (expr: string): number => {
    const row = db
      .prepare(`SELECT ${expr} AS n FROM leads ${base.sql}`)
      .get(...base.params) as { n: number } | undefined;
    return Number(row?.n ?? 0);
  };

  const byStatusWhere = where({ ...f, status: undefined });
  const byNicheWhere = where({ ...f, niche: undefined });
  const byCityWhere = where({ ...f, city: undefined, uf: undefined });

  return {
    total: scalar("count(*)"),
    noSite: scalar("count(*) FILTER (WHERE website IS NULL OR website = '')"),
    whatsapp: scalar("count(*) FILTER (WHERE whatsapp = 1)"),
    byStatus: (
      db
        .prepare(
          `SELECT status, count(*) AS count FROM leads ${byStatusWhere.sql}
           GROUP BY status ORDER BY count DESC`,
        )
        .all(...byStatusWhere.params) as { status: string; count: number }[]
    ).map((r) => ({ status: r.status as LeadStatus, count: Number(r.count) })),
    niches: (
      db
        .prepare(
          `SELECT niche, count(*) AS count FROM leads ${byNicheWhere.sql}
           ${byNicheWhere.sql ? "AND" : "WHERE"} niche IS NOT NULL
           GROUP BY niche ORDER BY count DESC`,
        )
        .all(...byNicheWhere.params) as { niche: string; count: number }[]
    ).map((r) => ({ niche: r.niche, count: Number(r.count) })),
    cities: (
      db
        .prepare(
          `SELECT city, uf, count(*) AS count FROM leads ${byCityWhere.sql}
           ${byCityWhere.sql ? "AND" : "WHERE"} city IS NOT NULL
           GROUP BY city, uf ORDER BY count DESC LIMIT 60`,
        )
        .all(...byCityWhere.params) as {
        city: string;
        uf: string;
        count: number;
      }[]
    ).map((r) => ({ city: r.city, uf: r.uf, count: Number(r.count) })),
  };
}

/**
 * Leads per niche, so you can see which niches you've built up and which you've
 * actually worked. Respects every filter *except* the niche one — the point is to
 * compare niches against each other, so fixing one would leave a single row.
 *
 * Trustworthy only because a category now maps to exactly one niche; while
 * `nail_salon` sat in two, these counts summed to more than the total.
 */
export function nicheBreakdown(f: HistoryFilters): NicheBreakdown[] {
  const db = getDb();
  const { sql: whereSql, params } = where({ ...f, niche: undefined });

  const rows = db
    .prepare(
      `SELECT niche,
              count(*) AS total,
              count(*) FILTER (WHERE website IS NULL OR website = '') AS no_site,
              count(*) FILTER (WHERE whatsapp = 1) AS whatsapp,
              count(*) FILTER (WHERE status <> 'novo') AS worked
       FROM leads ${whereSql}
       ${whereSql ? "AND" : "WHERE"} niche IS NOT NULL
       GROUP BY niche
       ORDER BY no_site DESC, total DESC`,
    )
    .all(...params) as {
    niche: string;
    total: number;
    no_site: number;
    whatsapp: number;
    worked: number;
  }[];

  return rows.map((r) => ({
    niche: r.niche,
    total: Number(r.total),
    noSite: Number(r.no_site),
    whatsapp: Number(r.whatsapp),
    worked: Number(r.worked),
  }));
}

/** Move a lead along the pipeline. Returns false if the id isn't in the history. */
export function setStatus(id: string, status: LeadStatus): boolean {
  if (!LEAD_STATUSES.includes(status)) return false;
  const db = getDb();
  const result = db
    .prepare(
      `UPDATE leads
       SET status = ?,
           -- Only the states that imply you actually reached out get a timestamp,
           -- and going back to 'novo' clears it, so contacted_at never claims an
           -- outreach that didn't happen or was undone. 'descartado' on its own
           -- doesn't stamp it — you can discard a lead without ever messaging it.
           contacted_at = CASE
             WHEN ? = 'novo' THEN NULL
             WHEN ? IN ('contatado', 'respondeu', 'cliente')
                  AND contacted_at IS NULL
               THEN strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
             ELSE contacted_at
           END
       WHERE id = ?`,
    )
    .run(status, status, status, id);
  return Number(result.changes) > 0;
}

/** Normalises query-string values into filters. */
export function parseFilters(
  params: Record<string, string | string[] | undefined>,
): HistoryFilters {
  const one = (v: string | string[] | undefined): string | undefined => {
    const s = Array.isArray(v) ? v[0] : v;
    const t = (s ?? "").trim();
    return t.length > 0 ? t : undefined;
  };

  const status = one(params.status);
  const sort = one(params.sort);
  const score = Number(one(params.score));
  const page = Number(one(params.page));

  return {
    q: one(params.q),
    niche: one(params.niche),
    uf: one(params.uf)?.toUpperCase(),
    city: one(params.city),
    status: LEAD_STATUSES.includes(status as LeadStatus)
      ? (status as LeadStatus)
      : undefined,
    onlyWhatsapp: one(params.wa) === "1",
    onlyNoSite: one(params.nosite) === "1",
    minScore: Number.isFinite(score) ? clamp(score, 0, 100) : undefined,
    sort:
      sort === "recent" || sort === "oldest" || sort === "name"
        ? sort
        : "score",
    page: Number.isFinite(page) ? Math.max(1, Math.trunc(page)) : 1,
  };
}

/** Rebuilds the query string, so links can change one filter and keep the rest. */
export function filtersToQuery(
  f: HistoryFilters,
  overrides: Partial<HistoryFilters> = {},
): string {
  const merged = { ...f, ...overrides };
  const p = new URLSearchParams();
  if (merged.q) p.set("q", merged.q);
  if (merged.niche) p.set("niche", merged.niche);
  if (merged.uf) p.set("uf", merged.uf);
  if (merged.city) p.set("city", merged.city);
  if (merged.status) p.set("status", merged.status);
  if (merged.onlyWhatsapp) p.set("wa", "1");
  if (merged.onlyNoSite) p.set("nosite", "1");
  if (merged.minScore) p.set("score", String(merged.minScore));
  if (merged.sort && merged.sort !== "score") p.set("sort", merged.sort);
  if (merged.page && merged.page > 1) p.set("page", String(merged.page));
  const s = p.toString();
  return s.length > 0 ? `?${s}` : "";
}

function clamp(n: number, lo: number, hi: number): number {
  if (!Number.isFinite(n)) return lo;
  return Math.min(hi, Math.max(lo, Math.trunc(n)));
}
