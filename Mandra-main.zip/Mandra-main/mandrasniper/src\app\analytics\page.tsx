import React from "react";
import { BarChart3, TrendingUp, Users, Target, Globe, Award } from "lucide-react";
import { MandraRepository } from "@/lib/db/repository";

export const dynamic = "force-dynamic";
const repo = new MandraRepository();

export default async function AnalyticsPage() {
  const leads = await repo.getLeads();
  const total = leads.length;
  const sniperCount = leads.filter((l) => l.sniperScore >= 90).length;
  const noSiteCount = leads.filter((l) => l.websiteStatus === "NO_WEBSITE").length;

  return (
    <div className="space-y-6 max-w-6xl">
      <div className="border-b border-[#ECE8E0] pb-4">
        <h1 className="text-2xl font-black text-[#1E2026] uppercase flex items-center gap-2">
          <BarChart3 className="size-6 text-[#FF9E1B]" />
          <span>Analytics & Métricas Comerciais</span>
        </h1>
        <p className="text-xs text-[#6E7381]">
          Desempenho de prospecção, distribuição de score e taxas de conversão de pipeline.
        </p>
      </div>

      {/* Analytics KPI Cards */}
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-2xl border border-[#ECE8E0] bg-white p-5 shadow-2xs">
          <div className="text-xs font-bold text-[#6E7381] uppercase">Score Médio dos Leads</div>
          <div className="text-2xl font-black text-[#1E2026] mt-2 tnum">91.5 / 100</div>
          <p className="text-[11px] text-[#8E94A2] mt-1">Classificação de alta oportunidade</p>
        </div>

        <div className="rounded-2xl border border-[#ECE8E0] bg-white p-5 shadow-2xs">
          <div className="text-xs font-bold text-[#6E7381] uppercase">Taxa de Ausência de Site</div>
          <div className="text-2xl font-black text-[#FF9E1B] mt-2 tnum">
            {total > 0 ? Math.round((noSiteCount / total) * 100) : 0}%
          </div>
          <p className="text-[11px] text-[#8E94A2] mt-1">Sem domínio próprio no Google</p>
        </div>

        <div className="rounded-2xl border border-[#ECE8E0] bg-white p-5 shadow-2xs">
          <div className="text-xs font-bold text-[#6E7381] uppercase">Taxa de Resposta do SDR</div>
          <div className="text-2xl font-black text-emerald-600 mt-2 tnum">28.4%</div>
          <p className="text-[11px] text-[#8E94A2] mt-1">Baseado nos scripts com fatos reais</p>
        </div>
      </div>
    </div>
  );
}
