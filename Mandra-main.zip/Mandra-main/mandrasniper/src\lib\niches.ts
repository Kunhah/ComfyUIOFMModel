/**
 * pt-BR niche → Overture `categories.primary` values.
 *
 * The category strings are not invented: they were taken from the live vocabulary
 * (`src/data/overture-categories.csv`, every category with ≥20 businesses in São
 * Paulo). An unknown category would silently match nothing, which is the worst
 * kind of bug here — an empty result looks like "no leads in this city" rather
 * than "you typo'd a category". Regenerate that CSV before adding to this list.
 *
 * Two rules hold this together, and the assertion further down enforces the
 * second one:
 *
 * 1. Niches are narrow enough to run a campaign against. They used to be 12 broad
 *    buckets, which sounds tidier and isn't: "restaurantes" bundled 16 categories
 *    and matched 32.895 businesses in São Paulo alone, so against the 1.000-row
 *    result cap you could never see past the first 3% of it. A pizzaria pitch and
 *    a padaria pitch are different conversations anyway.
 *
 * 2. **A category belongs to exactly one niche.** `nail_salon` used to be in both
 *    "barbearias-saloes" and "estetica" — 17.624 businesses appearing under two
 *    niches, and because a lead's stored niche was whichever search touched it
 *    last, the 133 nail salons already saved had split 61/72 between the two at
 *    random. Any per-niche count was therefore fiction. Overlap is now a thrown
 *    error at import rather than something you find months later.
 */
export type Niche = {
  slug: string;
  label: string;
  /** Coarse family, used to group the dropdown so 33 options stay navigable. */
  group: string;
  categories: string[];
};

export const NICHES: Niche[] = [
  // --- Beleza ---------------------------------------------------------------
  {
    slug: "barbearias",
    label: "Barbearias",
    group: "Beleza",
    categories: ["barber"],
  },
  {
    slug: "saloes-beleza",
    label: "Salões de beleza",
    group: "Beleza",
    categories: ["beauty_salon", "hair_salon"],
  },
  {
    slug: "manicure",
    label: "Manicure e nail design",
    group: "Beleza",
    categories: ["nail_salon"],
  },
  {
    slug: "estetica-spa",
    label: "Estética e spa",
    group: "Beleza",
    categories: ["beauty_and_spa", "spas"],
  },
  {
    slug: "tatuagem",
    label: "Tatuagem e piercing",
    group: "Beleza",
    categories: ["tattoo_and_piercing"],
  },

  // --- Alimentação ----------------------------------------------------------
  {
    slug: "restaurantes",
    label: "Restaurantes",
    group: "Alimentação",
    categories: [
      "restaurant",
      "brazilian_restaurant",
      "bar_and_grill_restaurant",
      "buffet_restaurant",
    ],
  },
  {
    slug: "bares",
    label: "Bares",
    group: "Alimentação",
    categories: ["bar"],
  },
  {
    slug: "pizzarias",
    label: "Pizzarias",
    group: "Alimentação",
    categories: ["pizza_restaurant"],
  },
  {
    slug: "hamburguerias",
    label: "Hamburguerias e fast food",
    group: "Alimentação",
    categories: ["burger_restaurant", "fast_food_restaurant"],
  },
  {
    slug: "padarias",
    label: "Padarias",
    group: "Alimentação",
    categories: ["bakery"],
  },
  {
    slug: "cafeterias",
    label: "Cafeterias",
    group: "Alimentação",
    categories: ["cafe", "coffee_shop"],
  },
  {
    slug: "sorveterias-sucos",
    label: "Sorveterias e sucos",
    group: "Alimentação",
    categories: ["ice_cream_shop", "smoothie_juice_bar"],
  },
  {
    slug: "culinaria-internacional",
    label: "Culinária internacional",
    group: "Alimentação",
    categories: [
      "sushi_restaurant",
      "japanese_restaurant",
      "italian_restaurant",
    ],
  },

  // --- Saúde ----------------------------------------------------------------
  {
    slug: "odontologia",
    label: "Odontologia",
    group: "Saúde",
    categories: ["dentist", "general_dentistry"],
  },
  {
    slug: "clinicas-medicas",
    label: "Clínicas médicas",
    group: "Saúde",
    categories: [
      "medical_center",
      "health_and_medical",
      "medical_service_organizations",
    ],
  },
  {
    slug: "fisioterapia",
    label: "Fisioterapia",
    group: "Saúde",
    categories: ["physical_therapy"],
  },
  {
    slug: "psicologia",
    label: "Psicologia e terapia",
    group: "Saúde",
    categories: ["psychotherapist"],
  },

  // --- Casa e construção ----------------------------------------------------
  {
    slug: "imobiliarias",
    label: "Imobiliárias",
    group: "Casa e construção",
    categories: ["real_estate", "real_estate_agent"],
  },
  {
    slug: "arquitetura",
    label: "Arquitetura e design",
    group: "Casa e construção",
    categories: ["architectural_designer"],
  },
  {
    slug: "engenharia-construcao",
    label: "Engenharia e construção",
    group: "Casa e construção",
    categories: ["engineering_services", "construction_services"],
  },

  // --- Fitness --------------------------------------------------------------
  {
    slug: "academias",
    label: "Academias",
    group: "Fitness",
    categories: ["gym"],
  },
  {
    slug: "pilates",
    label: "Pilates e estúdios",
    group: "Fitness",
    categories: ["pilates_studio"],
  },

  // --- Automotivo -----------------------------------------------------------
  {
    slug: "oficinas",
    label: "Oficinas mecânicas",
    group: "Automotivo",
    categories: [
      "automotive_repair",
      "automotive_services_and_repair",
      "auto_body_shop",
    ],
  },
  {
    slug: "estetica-automotiva",
    label: "Estética automotiva",
    group: "Automotivo",
    categories: ["auto_detailing", "car_wash"],
  },
  {
    slug: "concessionarias",
    label: "Concessionárias e revendas",
    group: "Automotivo",
    categories: ["car_dealer"],
  },

  // --- Pet ------------------------------------------------------------------
  {
    slug: "pet-shops",
    label: "Pet shops e banho e tosa",
    group: "Pet",
    categories: ["pet_store", "pet_services", "pet_groomer"],
  },
  {
    slug: "veterinarios",
    label: "Veterinários",
    group: "Pet",
    categories: ["veterinarian"],
  },

  // --- Serviços profissionais ------------------------------------------------
  {
    slug: "advocacia",
    label: "Advocacia",
    group: "Serviços profissionais",
    categories: ["lawyer"],
  },
  {
    slug: "contabilidade",
    label: "Contabilidade",
    group: "Serviços profissionais",
    categories: ["accountant"],
  },

  // --- Educação -------------------------------------------------------------
  {
    slug: "escolas",
    label: "Escolas",
    group: "Educação",
    categories: ["school", "private_school"],
  },
  {
    slug: "cursos-idiomas",
    label: "Cursos de idiomas",
    group: "Educação",
    categories: ["language_school"],
  },
  {
    slug: "autoescolas",
    label: "Autoescolas",
    group: "Educação",
    categories: ["driving_school"],
  },
  {
    slug: "escolas-especializadas",
    label: "Escolas especializadas",
    group: "Educação",
    categories: ["specialty_school", "dance_school"],
  },
];

/**
 * category → niche slug. This is the authoritative direction.
 *
 * A lead's niche is derived from the business's own Overture category, not from
 * whichever search happened to find it. Storing the search's niche instead made
 * the value depend on the order you ran your searches — and since every re-search
 * overwrote it, a lead could change niche just by being looked for again.
 */
const CATEGORY_TO_NICHE = new Map<string, string>();
for (const niche of NICHES) {
  for (const category of niche.categories) {
    const existing = CATEGORY_TO_NICHE.get(category);
    if (existing !== undefined) {
      throw new Error(
        `Overture category "${category}" is in two niches ("${existing}" and ` +
          `"${niche.slug}"). Every category must belong to exactly one niche, or ` +
          `per-niche counts double-count and a lead's niche depends on search order.`,
      );
    }
    CATEGORY_TO_NICHE.set(category, niche.slug);
  }
}

export function findNiche(slug: string): Niche | undefined {
  return NICHES.find((n) => n.slug === slug);
}

/** The niche a business belongs to, from its category. Null for anything unmapped. */
export function nicheForCategory(category: string | null): string | null {
  if (!category) return null;
  return CATEGORY_TO_NICHE.get(category) ?? null;
}

/** Every category we prospect, for the sync script. */
export function allCategories(): string[] {
  return [...CATEGORY_TO_NICHE.keys()].sort();
}

/** Niches in declaration order, grouped, for `<optgroup>`. */
export function nichesByGroup(): { group: string; niches: Niche[] }[] {
  const groups: { group: string; niches: Niche[] }[] = [];
  for (const niche of NICHES) {
    const last = groups[groups.length - 1];
    if (last && last.group === niche.group) last.niches.push(niche);
    else groups.push({ group: niche.group, niches: [niche] });
  }
  return groups;
}

/**
 * Fingerprint of the vocabulary. When it changes, stored niche values are stale,
 * and db.ts rebuilds them from each lead's category.
 */
export function nicheFingerprint(): string {
  return NICHES.map((n) => `${n.slug}:${n.categories.join(",")}`).join("|");
}
