-- MANDRA SNIPER AI - PostgreSQL Supabase Database Schema
-- Multi-tenant Sales Intelligence & AI SDR Platform

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. USERS TABLE
CREATE TABLE IF NOT EXISTS public.users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email TEXT UNIQUE NOT NULL,
    full_name TEXT,
    avatar_url TEXT,
    role TEXT DEFAULT 'SDR',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. ORGANIZATIONS (TENANTS)
CREATE TABLE IF NOT EXISTS public.organizations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    plan TEXT DEFAULT 'ENTERPRISE',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. ORGANIZATION MEMBERS
CREATE TABLE IF NOT EXISTS public.organization_members (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    role TEXT NOT NULL DEFAULT 'SDR' CHECK (role IN ('OWNER', 'ADMIN', 'MANAGER', 'SDR', 'VIEWER')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(organization_id, user_id)
);

-- 4. LEADS TABLE
CREATE TABLE IF NOT EXISTS public.leads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    category TEXT,
    address TEXT,
    city TEXT NOT NULL,
    state TEXT NOT NULL,
    postal_code TEXT,
    lat DOUBLE PRECISION,
    lon DOUBLE PRECISION,
    phone TEXT,
    website TEXT,
    social_url TEXT,
    email TEXT,
    google_place_id TEXT,
    rating DOUBLE PRECISION DEFAULT 0.0,
    reviews_count INT DEFAULT 0,
    maps_url TEXT,
    sniper_score INT DEFAULT 0 CHECK (sniper_score >= 0 AND sniper_score <= 100),
    confidence_level TEXT DEFAULT 'MEDIUM' CHECK (confidence_level IN ('HIGH', 'MEDIUM', 'LOW')),
    website_status TEXT DEFAULT 'UNKNOWN' CHECK (website_status IN ('NO_WEBSITE', 'SOCIAL_ONLY', 'BROKEN_WEBSITE', 'POOR_WEBSITE', 'GOOD_WEBSITE', 'UNKNOWN')),
    website_score INT DEFAULT 0 CHECK (website_score >= 0 AND website_score <= 100),
    crm_status TEXT DEFAULT 'NOVO' CHECK (crm_status IN ('NOVO', 'QUALIFICADO', 'ABORDAGEM', 'CONTATADO', 'RESPONDEU', 'REUNIÃO', 'PROPOSTA', 'GANHO', 'PERDIDO')),
    assigned_to UUID REFERENCES public.users(id) ON DELETE SET NULL,
    first_seen_at TIMESTAMPTZ DEFAULT NOW(),
    last_seen_at TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. LEAD CONTACTS
CREATE TABLE IF NOT EXISTS public.lead_contacts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
    name TEXT,
    role TEXT,
    phone TEXT,
    email TEXT,
    is_whatsapp BOOLEAN DEFAULT FALSE,
    source TEXT DEFAULT 'google_places',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. LEAD SOURCES (DATA ORIGIN & CONFIDENCE TRACKING)
CREATE TABLE IF NOT EXISTS public.lead_sources (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
    source_name TEXT NOT NULL,
    field_name TEXT NOT NULL,
    value TEXT,
    confidence TEXT DEFAULT 'HIGH' CHECK (confidence IN ('HIGH', 'MEDIUM', 'LOW')),
    raw_data JSONB,
    collected_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. LEAD SOCIAL PROFILES
CREATE TABLE IF NOT EXISTS public.lead_social_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
    platform TEXT NOT NULL CHECK (platform IN ('INSTAGRAM', 'FACEBOOK', 'LINKEDIN', 'LINKTREE', 'WHATSAPP', 'OTHER')),
    username TEXT,
    url TEXT NOT NULL,
    followers_count INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    last_post_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. LEAD WEBSITES (TECHNICAL WEBSITE AUDIT)
CREATE TABLE IF NOT EXISTS public.lead_websites (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
    url TEXT,
    status_code INT,
    has_https BOOLEAN DEFAULT FALSE,
    is_responsive BOOLEAN DEFAULT FALSE,
    title TEXT,
    meta_description TEXT,
    has_cta BOOLEAN DEFAULT FALSE,
    has_whatsapp BOOLEAN DEFAULT FALSE,
    has_form BOOLEAN DEFAULT FALSE,
    has_social_links BOOLEAN DEFAULT FALSE,
    performance_score INT DEFAULT 0,
    seo_score INT DEFAULT 0,
    audited_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. LEAD SCORES (DETAILED SCORE EXPLANATIONS)
CREATE TABLE IF NOT EXISTS public.lead_scores (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
    sniper_score INT NOT NULL,
    breakdown JSONB NOT NULL, -- Array of { reason: string, points: number }
    calculated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10. LEAD INSIGHTS (AI ANALYSIS)
CREATE TABLE IF NOT EXISTS public.lead_insights (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
    summary TEXT NOT NULL,
    pain_points JSONB NOT NULL, -- Array of { problem: string, evidence: string, confidence: number }
    opportunities JSONB NOT NULL,
    recommended_offer TEXT,
    recommended_angle TEXT,
    icebreaker TEXT,
    priority TEXT DEFAULT 'HIGH' CHECK (priority IN ('HIGH', 'MEDIUM', 'LOW')),
    confidence_score INT DEFAULT 85,
    generated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11. LEAD OPPORTUNITIES
CREATE TABLE IF NOT EXISTS public.lead_opportunities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    estimated_value NUMERIC(10, 2) DEFAULT 0.00,
    priority TEXT DEFAULT 'HIGH',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 12. LEAD OUTREACH (GENERATED AI SDR MESSAGES)
CREATE TABLE IF NOT EXISTS public.lead_outreach (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
    channel TEXT NOT NULL CHECK (channel IN ('WHATSAPP', 'INSTAGRAM', 'EMAIL', 'CALL_SCRIPT')),
    tone TEXT NOT NULL DEFAULT 'CONSULTATIVE',
    objective TEXT DEFAULT 'LANDING_PAGE',
    content TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 13. LEAD ACTIVITIES (TIMELINE)
CREATE TABLE IF NOT EXISTS public.lead_activities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
    user_id UUID REFERENCES public.users(id) ON DELETE SET NULL,
    activity_type TEXT NOT NULL,
    description TEXT NOT NULL,
    metadata JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 14. SEARCHES (SAVED PROMPTS & PARAMETERS)
CREATE TABLE IF NOT EXISTS public.searches (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    query_text TEXT NOT NULL,
    parsed_params JSONB NOT NULL,
    is_saved BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 15. SEARCH RUNS (JOB EXECUTIONS)
CREATE TABLE IF NOT EXISTS public.search_runs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    search_id UUID REFERENCES public.searches(id) ON DELETE CASCADE,
    organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    status TEXT DEFAULT 'RUNNING' CHECK (status IN ('RUNNING', 'COMPLETED', 'FAILED')),
    total_found INT DEFAULT 0,
    websites_verified INT DEFAULT 0,
    enriched_count INT DEFAULT 0,
    qualified_count INT DEFAULT 0,
    sniper_count INT DEFAULT 0,
    is_demo BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

-- 16. CRM STAGES
CREATE TABLE IF NOT EXISTS public.crm_stages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    color TEXT DEFAULT '#FF9E1B',
    position INT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 17. CRM DEALS
CREATE TABLE IF NOT EXISTS public.crm_deals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
    organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    stage_id UUID REFERENCES public.crm_stages(id) ON DELETE SET NULL,
    deal_value NUMERIC(10, 2) DEFAULT 0.00,
    expected_close TIMESTAMPTZ,
    position INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 18. TASKS
CREATE TABLE IF NOT EXISTS public.tasks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID REFERENCES public.leads(id) ON DELETE CASCADE,
    organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    due_date TIMESTAMPTZ,
    completed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 19. AI GENERATIONS (USAGE TRACKING)
CREATE TABLE IF NOT EXISTS public.ai_generations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    model TEXT NOT NULL,
    feature TEXT NOT NULL,
    prompt_tokens INT DEFAULT 0,
    completion_tokens INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 20. PROVIDER CONFIGS
CREATE TABLE IF NOT EXISTS public.provider_configs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    provider_name TEXT NOT NULL,
    is_enabled BOOLEAN DEFAULT FALSE,
    status TEXT DEFAULT 'NOT_CONFIGURED',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 21. USAGE EVENTS
CREATE TABLE IF NOT EXISTS public.usage_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    event_name TEXT NOT NULL,
    metadata JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 22. AUDIT LOGS
CREATE TABLE IF NOT EXISTS public.audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    user_id UUID REFERENCES public.users(id) ON DELETE SET NULL,
    action TEXT NOT NULL,
    resource TEXT NOT NULL,
    details JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- INDEXES FOR MAXIMUM QUERY PERFORMANCE
CREATE INDEX IF NOT EXISTS idx_leads_organization ON public.leads(organization_id);
CREATE INDEX IF NOT EXISTS idx_leads_sniper_score ON public.leads(sniper_score DESC);
CREATE INDEX IF NOT EXISTS idx_leads_city ON public.leads(city);
CREATE INDEX IF NOT EXISTS idx_leads_category ON public.leads(category);
CREATE INDEX IF NOT EXISTS idx_leads_crm_status ON public.leads(crm_status);
CREATE INDEX IF NOT EXISTS idx_leads_website_status ON public.leads(website_status);
CREATE INDEX IF NOT EXISTS idx_crm_deals_organization ON public.crm_deals(organization_id);
CREATE INDEX IF NOT EXISTS idx_crm_deals_stage ON public.crm_deals(stage_id);

-- ROW LEVEL SECURITY (RLS) POLICIES FOR MULTI-TENANCY
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.searches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.search_runs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crm_stages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crm_deals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
