"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import {
  Users,
  Target,
  Sparkles,
  MessageCircle,
  Calendar,
  DollarSign,
  ArrowRight,
  Globe,
  ShieldCheck,
  TrendingUp,
  Search,
  BookOpen,
  Play,
  Flame,
  CheckCircle2,
  Clock,
  Layers,
  Award,
  Zap,
} from "lucide-react";
import type { Lead } from "@/types";
import { SdrOnboardingWizard } from "@/components/sdr-onboarding-wizard";
import { FocusQueueModal } from "@/components/focus-queue-modal";

export default function DashboardPage() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [showWizard, setShowWizard] = useState(false);
  const [showFocusQueue, setShowFocusQueue] = useState(false);

  useEffect(() => {
    fetch("/api/leads")
      .then((r) => r.json())
      .then((d) => {
        if (d.leads) setLeads(d.leads);
        setLoading(false);
      });
  }, []);

  const sniperLeads = leads.filter((l) => l.sniperScore >= 90);
  const hotLeads = leads.filter((l) => l.sniperScore >= 75);
  const noSiteLeads = leads.filter((l) => l.websiteStatus === "NO_WEBSITE" || !l.website);

  return (
    <div className="space-y-8 max-w-7xl">
      {/* VENDEDOR WELCOME HERO BANNER */}
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between border-b border-[#ECE8E0] pb-6">
        <div>
          <div className="inline-flex items-center gap-2 rounded-lg bg-[#FF9E1B]/15 px-3 py-1 text-xs font-extrabold text-[#FF9E1B] border border-[#FF9E1B]/30 mb-2">
            <Sparkles className="size-3.5" />
            <span>MANDRA SNIPER AI · HOME DO VENDEDOR</span>
          </div>
          <h1 className="text-3xl font-black tracking-tight text-[#1E2026] uppercase">
            OLÁ, GUILHERME — O QUE VOCÊ QUER FAZER AGORA?
          </h1>
          <p className="mt-1 text-sm text-[#6E7381]">
            Encontre empresas com oportunidade real e saiba exatamente como abordar com 1 clique.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setShowWizard(true)}
            className="inline-flex items-center gap-2 rounded-2xl border border-[#E2DDD3] bg-white px-5 py-3 text-xs font-bold text-[#1E2026] hover:bg-[#FAF8F4] transition shadow-xs"
          >
            <BookOpen className="size-4 text-[#FF9E1B]" />
            <span>Guia do Novo Vendedor</span>
          </button>

          <Link
            href="/prospecting"
            className="inline-flex items-center justify-center gap-2.5 rounded-2xl bg-[#1C1F26] px-6 py-3.5 text-xs font-bold text-white hover:bg-[#2A2E38] transition shadow-md group"
          >
            <Sparkles className="size-4 text-[#FF9E1B]" />
            <span>🔥 GERAR NOVOS LEADS</span>
            <ArrowRight className="size-4 group-hover:translate-x-0.5 transition" />
          </Link>
        </div>
      </div>

      {/* BIG ACTION CARDS FOR SALESPEOPLE */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Action 1: Gerar Novos Leads */}
        <Link
          href="/prospecting"
          className="group rounded-2xl border border-[#ECE8E0] bg-white p-5 shadow-2xs hover:border-[#FF9E1B] transition space-y-3"
        >
          <div className="flex size-10 items-center justify-center rounded-xl bg-[#FFF5E6] text-[#FF9E1B]">
            <Sparkles className="size-5" />
          </div>
          <div>
            <div className="font-extrabold text-sm text-[#1E2026]">Gerar Novos Leads</div>
            <div className="text-xs text-[#6E7381] mt-0.5">Encontre empresas sem site em 3 cliques</div>
          </div>
          <div className="text-xs font-bold text-[#FF9E1B] flex items-center gap-1">
            <span>Começar Busca</span>
            <ArrowRight className="size-3.5 group-hover:translate-x-1 transition" />
          </div>
        </Link>

        {/* Action 2: Minha Fila (Modo Foco) */}
        <button
          onClick={() => setShowFocusQueue(true)}
          className="group text-left rounded-2xl border border-[#ECE8E0] bg-white p-5 shadow-2xs hover:border-[#FF9E1B] transition space-y-3"
        >
          <div className="flex size-10 items-center justify-center rounded-xl bg-[#FFF5E6] text-[#FF9E1B]">
            <Target className="size-5" />
          </div>
          <div>
            <div className="font-extrabold text-sm text-[#1E2026]">Minha Fila (Modo Foco)</div>
            <div className="text-xs text-[#6E7381] mt-0.5">Prospecção 1 lead por vez sem distrações</div>
          </div>
          <div className="text-xs font-bold text-[#FF9E1B] flex items-center gap-1">
            <span>Iniciar Fila</span>
            <ArrowRight className="size-3.5 group-hover:translate-x-1 transition" />
          </div>
        </button>

        {/* Action 3: CRM Kanban */}
        <Link
          href="/crm"
          className="group rounded-2xl border border-[#ECE8E0] bg-white p-5 shadow-2xs hover:border-[#FF9E1B] transition space-y-3"
        >
          <div className="flex size-10 items-center justify-center rounded-xl bg-[#EAFBF1] text-[#25D366]">
            <MessageCircle className="size-5" />
          </div>
          <div>
            <div className="font-extrabold text-sm text-[#1E2026]">Continuar Prospecções</div>
            <div className="text-xs text-[#6E7381] mt-0.5">Gerenciar negociações no CRM</div>
          </div>
          <div className="text-xs font-bold text-emerald-600 flex items-center gap-1">
            <span>Ver Pipeline</span>
            <ArrowRight className="size-3.5 group-hover:translate-x-1 transition" />
          </div>
        </Link>

        {/* Action 4: Ver Desempenho */}
        <Link
          href="/analytics"
          className="group rounded-2xl border border-[#ECE8E0] bg-white p-5 shadow-2xs hover:border-[#FF9E1B] transition space-y-3"
        >
          <div className="flex size-10 items-center justify-center rounded-xl bg-blue-50 text-blue-600">
            <TrendingUp className="size-5" />
          </div>
          <div>
            <div className="font-extrabold text-sm text-[#1E2026]">Meu Desempenho</div>
            <div className="text-xs text-[#6E7381] mt-0.5">Taxas de resposta e vendas</div>
          </div>
          <div className="text-xs font-bold text-blue-600 flex items-center gap-1">
            <span>Ver Métricas</span>
            <ArrowRight className="size-3.5 group-hover:translate-x-1 transition" />
          </div>
        </Link>
      </div>

      {/* PRÓXIMA MELHOR AÇÃO (NEXT BEST ACTION) & TODAY VIEW */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Next Best Action Card */}
        <div className="lg:col-span-2 rounded-2xl border border-[#FF9E1B]/30 bg-[#FFF9F0] p-6 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 text-xs font-black text-[#FF9E1B] uppercase tracking-wider">
            <Zap className="size-4 fill-[#FF9E1B]" />
            <span>PRÓXIMA MELHOR AÇÃO RECOMENDADA</span>
          </div>

          <h2 className="text-xl font-black text-[#1E2026]">
            Você possui {sniperLeads.length} Sniper Leads quentes ainda não contatados.
          </h2>

          <p className="text-xs text-[#6E7381] leading-relaxed">
            Essas empresas possuem nota superior a 4.8 no Google e Instagram ativo, mas não têm site próprio. Aborde agora via WhatsApp com a mensagem gerada pela IA.
          </p>

          <div className="pt-2 flex items-center gap-3">
            <button
              onClick={() => setShowFocusQueue(true)}
              className="flex items-center gap-2 rounded-xl bg-[#1C1F26] px-5 py-3 text-xs font-bold text-white hover:bg-[#2A2E38] transition shadow-xs"
            >
              <Play className="size-4 text-[#FF9E1B]" />
              <span>COMEÇAR PROSPECÇÃO AGORA</span>
            </button>
          </div>
        </div>

        {/* HOJE (Today View) */}
        <div className="rounded-2xl border border-[#ECE8E0] bg-white p-6 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-[#ECE8E0] pb-3">
            <h3 className="font-black text-sm text-[#1E2026] uppercase">HOJE</h3>
            <span className="text-xs text-[#6E7381] font-bold">{new Date().toLocaleDateString("pt-BR")}</span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#FAF8F4] border border-[#ECE8E0]">
              <span className="font-semibold text-[#1E2026]">Leads Novos no Sistema</span>
              <span className="font-black text-[#1E2026] tnum">{leads.length}</span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#FAF8F4] border border-[#ECE8E0]">
              <span className="font-semibold text-[#1E2026]">Para Abordar Hoje</span>
              <span className="font-black text-[#FF9E1B] tnum">{hotLeads.length}</span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#FAF8F4] border border-[#ECE8E0]">
              <span className="font-semibold text-[#1E2026]">Respostas Aguardando</span>
              <span className="font-black text-emerald-600 tnum">3</span>
            </div>
          </div>
        </div>
      </div>

      {/* RADAR DE OPORTUNIDADES POR NICHO & CIDADE */}
      <div className="rounded-2xl border border-[#ECE8E0] bg-white p-6 shadow-2xs space-y-5">
        <div className="flex items-center justify-between border-b border-[#ECE8E0] pb-4">
          <div>
            <h2 className="text-base font-extrabold text-[#1E2026] uppercase">
              RADAR DE OPORTUNIDADES (EXPLORER POR NICHO)
            </h2>
            <p className="text-xs text-[#6E7381]">
              Volume de oportunidades por segmento com base nos dados reais mapeados
            </p>
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 text-xs">
          {[
            { niche: "Estética e Spa", count: 189, avgScore: 92, tag: "Alta Oportunidade" },
            { niche: "Barbearias", count: 142, avgScore: 89, tag: "Sem Site Proprio" },
            { niche: "Odontologia", count: 128, avgScore: 94, tag: "Site Antigo" },
            { niche: "Academias & Fitness", count: 110, avgScore: 91, tag: "Instagram Forte" },
          ].map((item) => (
            <Link
              key={item.niche}
              href={`/prospecting?prompt=${encodeURIComponent(`${item.niche} sem site`)}`}
              className="rounded-xl border border-[#ECE8E0] bg-[#FAF8F4] p-4 hover:border-[#FF9E1B] transition space-y-2"
            >
              <div className="font-extrabold text-sm text-[#1E2026]">{item.niche}</div>
              <div className="text-xs text-[#6E7381]">
                <strong>{item.count}</strong> empresas · Score Médio <strong className="text-[#FF9E1B]">{item.avgScore}</strong>
              </div>
              <span className="inline-block rounded bg-[#FF9E1B]/15 px-2 py-0.5 text-[9px] font-black text-[#FF9E1B] uppercase">
                {item.tag}
              </span>
            </Link>
          ))}
        </div>
      </div>

      {/* MODALS */}
      <SdrOnboardingWizard open={showWizard} onClose={() => setShowWizard(false)} />
      <FocusQueueModal leads={sniperLeads} open={showFocusQueue} onClose={() => setShowFocusQueue(false)} />
    </div>
  );
}
