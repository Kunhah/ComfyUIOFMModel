import { z } from "zod";

// 1. Natural Language Search Prompt Interpreter Schema
export const SearchPromptResultSchema = z.object({
  niche: z.string().describe("The business segment or niche, e.g. academia, estética, barbearia, dentista"),
  location: z.string().describe("The target city and state code, e.g. Campinas, SP or Sorocaba, SP"),
  radiusKm: z.number().default(25).describe("Search radius in kilometers"),
  limit: z.number().default(50).describe("Maximum number of leads requested"),
  minReviews: z.number().default(0).describe("Minimum number of Google reviews"),
  requireInstagram: z.boolean().default(false).describe("Whether active Instagram presence is required"),
  requireWhatsapp: z.boolean().default(false).describe("Whether valid WhatsApp contact is required"),
  websiteCondition: z
    .enum(["missing", "poor", "broken", "social", "any"])
    .default("missing")
    .describe("Website presence filter condition"),
});

export type SearchPromptResult = z.infer<typeof SearchPromptResultSchema>;

// 2. AI Lead Qualification & Opportunity Detector Schema
export const LeadInsightSchema = z.object({
  summary: z
    .string()
    .describe("Brief factual summary of why this lead is a strong commercial opportunity"),
  painPoints: z.array(
    z.object({
      problem: z.string().describe("Specific pain point or digital absence"),
      evidence: z.string().describe("Concrete evidence derived strictly from lead facts"),
      confidence: z.number().min(0).max(100).describe("Confidence level 0-100"),
    })
  ),
  opportunities: z.array(z.string()).describe("Specific high-value service opportunities"),
  recommendedOffer: z
    .string()
    .describe("Primary recommended service offer, e.g. Landing Page de Alta Conversão p/ WhatsApp"),
  recommendedAngle: z
    .string()
    .describe("Strategic approach angle based on business reputation vs digital gap"),
  icebreaker: z
    .string()
    .describe("Hyper-personalized opening line referencing real facts (reviews, rating, Instagram)"),
  priority: z.enum(["HIGH", "MEDIUM", "LOW"]),
  confidenceScore: z.number().min(0).max(100),
});

export type LeadInsightAI = z.infer<typeof LeadInsightSchema>;

// 3. AI SDR Outreach Script Schema
export const OutreachScriptSchema = z.object({
  channel: z.enum(["WHATSAPP", "INSTAGRAM", "EMAIL", "CALL_SCRIPT"]),
  tone: z.enum(["DIRECT", "CONSULTATIVE", "CASUAL", "EXECUTIVE"]),
  objective: z.string(),
  content: z
    .string()
    .describe(
      "Hyper-personalized non-generic message content referencing exact business name, rating, reviews count or Instagram details"
    ),
});

export type OutreachScriptAI = z.infer<typeof OutreachScriptSchema>;
