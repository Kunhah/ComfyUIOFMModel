"use client";

import React, { useEffect, useState } from "react";
import { Search, Sparkles, X, Command, ArrowRight, Loader2 } from "lucide-react";
import { useRouter } from "next/navigation";

export function AiCommandBar({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{
    answer: string;
    matchingLeadIds: string[];
    actionMessage?: string;
  } | null>(null);
  const router = useRouter();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "k") {
        e.preventDefault();
        onOpenChange(!open);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [open, onOpenChange]);

  const executeCommand = async (text: string) => {
    if (!text.trim()) return;
    setLoading(true);
    setResult(null);

    try {
      const res = await fetch("/api/ai/command-bar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ queryText: text }),
      });
      const data = await res.json();
      if (data.success) {
        setResult(data.result);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 bg-black/70 backdrop-blur-xs p-4">
      <div className="w-full max-w-xl rounded-2xl border border-[#2B2E3C] bg-[#14161C] p-4 text-white shadow-2xl space-y-4">
        {/* Header Input Bar */}
        <div className="relative flex items-center border-b border-[#222530] pb-3">
          <Sparkles className="absolute left-3 size-5 text-[#FF9E1B]" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                executeCommand(query);
              }
            }}
            autoFocus
            placeholder="Digite um comando (ex: Mostre empresas sem site, Quem devo abordar primeiro?)..."
            className="w-full bg-transparent pl-10 pr-10 text-sm font-medium text-white outline-none placeholder:text-[#6E7381]"
          />
          {query ? (
            <button onClick={() => setQuery("")} className="absolute right-3 text-gray-400 hover:text-white">
              <X className="size-4" />
            </button>
          ) : (
            <span className="absolute right-3 rounded-md bg-[#222530] px-2 py-0.5 text-[10px] text-gray-400">
              ESC
            </span>
          )}
        </div>

        {/* Suggested Quick Prompts */}
        {!result && !loading && (
          <div className="space-y-2">
            <span className="text-[11px] font-bold text-[#6E7381] uppercase tracking-wider">
              Sugestões Rápidas de Comando:
            </span>
            <div className="grid gap-1.5 text-xs text-[#C5C9D3]">
              {[
                "Mostre empresas sem site",
                "Quem devo abordar primeiro?",
                "Quais leads têm score maior que 90?",
                "Mostre clínicas de Campinas",
              ].map((cmd) => (
                <button
                  key={cmd}
                  onClick={() => {
                    setQuery(cmd);
                    executeCommand(cmd);
                  }}
                  className="flex items-center justify-between rounded-xl border border-[#222530] bg-[#1A1C24] px-3 py-2 text-left hover:border-[#FF9E1B] hover:bg-[#20232E] transition"
                >
                  <span>{cmd}</span>
                  <ArrowRight className="size-3.5 text-[#FF9E1B]" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Loading Spinner */}
        {loading && (
          <div className="flex items-center justify-center py-6 text-xs text-[#FF9E1B] gap-2">
            <Loader2 className="size-4 animate-spin" />
            <span>Consultando banco de dados com IA...</span>
          </div>
        )}

        {/* AI Answer Result */}
        {result && (
          <div className="space-y-3 pt-1">
            <div className="rounded-xl border border-[#2B2E3C] bg-[#1A1C24] p-4 text-xs leading-relaxed text-[#E1E4EC]">
              {result.answer}
            </div>

            {result.matchingLeadIds && result.matchingLeadIds.length > 0 && (
              <button
                onClick={() => {
                  onOpenChange(false);
                  router.push(`/leads?minScore=75`);
                }}
                className="w-full flex items-center justify-center gap-2 rounded-xl bg-[#FF9E1B] px-4 py-2 text-xs font-bold text-[#101216] hover:bg-[#F08E0B] transition"
              >
                <span>Ver {result.matchingLeadIds.length} Leads Filtrados no Sistema</span>
                <ArrowRight className="size-4" />
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
