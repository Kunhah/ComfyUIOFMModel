"use client";

import React, { useState, useRef, useEffect } from "react";
import { MapPin, ChevronDown, Check } from "lucide-react";
import { searchCities } from "@/lib/cities";

export const POPULAR_CITIES = [
  "Campinas, SP",
  "Sorocaba, SP",
  "Jundiaí, SP",
  "São Paulo, SP",
  "Belo Horizonte, MG",
  "Curitiba, PR",
  "Rio de Janeiro, RJ",
  "Piracicaba, SP",
  "Ribeirão Preto, SP",
  "Santos, SP",
];

export function LocationAutocomplete({
  value,
  onChange,
}: {
  value: string;
  onChange: (loc: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const searchResults = search.trim().length > 0 ? searchCities(search, 8) : [];

  const handleSelect = (cityStr: string) => {
    onChange(cityStr);
    setSearch("");
    setOpen(false);
  };

  return (
    <div ref={containerRef} className="relative w-full">
      <label className="block text-[11px] font-extrabold uppercase text-[#8E94A2] tracking-wider mb-1">
        Onde? (Cidade / Região)
      </label>

      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between rounded-xl border border-[#2B2E3C] bg-[#14161C] px-4 py-3 text-left text-sm font-bold text-white transition hover:border-[#FF9E1B] focus:border-[#FF9E1B]"
      >
        <span className="truncate flex items-center gap-2">
          <MapPin className="size-4 text-[#FF9E1B]" />
          <span>{value || "Selecione uma cidade..."}</span>
        </span>
        <ChevronDown className="size-4 text-[#8E94A2]" />
      </button>

      {open && (
        <div className="absolute top-full left-0 right-0 z-50 mt-2 rounded-2xl border border-[#2B2E3C] bg-[#14161C] p-3 shadow-2xl text-white space-y-2">
          <input
            autoFocus
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Digite qualquer cidade do Brasil..."
            className="w-full rounded-xl border border-[#222530] bg-[#1A1C24] p-2.5 text-xs font-semibold text-white outline-none focus:border-[#FF9E1B]"
          />

          <div className="max-h-56 overflow-y-auto space-y-1 text-xs pr-1">
            {searchResults.length > 0 ? (
              searchResults.map((c) => {
                const label = `${c.name}, ${c.uf}`;
                return (
                  <button
                    key={label}
                    onClick={() => handleSelect(label)}
                    className={`w-full flex items-center justify-between rounded-xl px-3 py-2 text-left font-medium transition ${
                      value === label
                        ? "bg-[#1E212A] text-[#FF9E1B] font-bold"
                        : "text-gray-300 hover:bg-[#1A1C24] hover:text-white"
                    }`}
                  >
                    <span>{label}</span>
                    {value === label && <Check className="size-4 text-[#FF9E1B]" />}
                  </button>
                );
              })
            ) : (
              POPULAR_CITIES.map((city) => (
                <button
                  key={city}
                  onClick={() => handleSelect(city)}
                  className={`w-full flex items-center justify-between rounded-xl px-3 py-2 text-left font-medium transition ${
                    value === city
                      ? "bg-[#1E212A] text-[#FF9E1B] font-bold"
                      : "text-gray-300 hover:bg-[#1A1C24] hover:text-white"
                  }`}
                >
                  <span>{city}</span>
                  {value === city && <Check className="size-4 text-[#FF9E1B]" />}
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
