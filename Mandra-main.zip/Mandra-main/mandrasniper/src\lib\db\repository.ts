import type {
  CrmDeal,
  CrmStage,
  Lead,
  LeadCrmStatus,
  ProviderHealth,
  SearchFilterParams,
} from "@/types";
import { GooglePlacesProviderImpl } from "../providers/google-places";
import { MandraEnrichmentEngine } from "../providers/enrichment/engine";
import { OpenAIProvider } from "../ai/openai";
import { LeadDiscoveryOrchestrator } from "@/lib/discovery/orchestrator";

// Global in-memory & SQLite persistent fallback store for instant out-of-the-box operation
let MEMORY_LEADS: Lead[] = [];
let SAVED_SEARCHES: Array<{
  id: string;
  title: string;
  queryText: string;
  params: SearchFilterParams;
  createdAt: string;
}> = [];

let CRM_DEALS: CrmDeal[] = [];

// Seed default initial state if memory store is empty
function ensureSeeded() {
  if (MEMORY_LEADS.length > 0) return;

  const now = new Date().toISOString();
  const seedLeads: Partial<Lead>[] = [
    {
      id: "lead-campinas-1",
      name: "Dra. Juliana Estética Avançada",
      category: "Estética",
      address: "Av. José de Souza Campos, 1280",
      city: "Campinas",
      state: "SP",
      phone: "+5519998124433",
      website: null,
      socialUrl: "https://instagram.com/drajulianaestetica",
      rating: 4.9,
      reviewsCount: 184,
      sniperScore: 94,
      scoreTier: "SNIPER",
      confidenceLevel: "HIGH",
      websiteStatus: "NO_WEBSITE",
      websiteScore: 0,
      crmStatus: "NOVO",
      scoreBreakdown: [
        { reason: "Sem site próprio", points: 25 },
        { reason: "Apenas perfil em rede social", points: 18 },
        { reason: "Instagram ativo na região", points: 12 },
        { reason: "WhatsApp comercial disponível", points: 10 },
        { reason: "100+ avaliações no Google", points: 10 },
        { reason: "Alta reputação (Nota 4.9)", points: 8 },
        { reason: "Atividade digital recente", points: 7 },
        { reason: "Contato comercial identificado", points: 5 },
      ],
      facts: {
        name: { value: "Dra. Juliana Estética Avançada", source: "google_places", collectedAt: now, confidence: "HIGH" },
        phone: { value: "+5519998124433", source: "google_places", collectedAt: now, confidence: "HIGH" },
        website: { value: null, source: "google_places", collectedAt: now, confidence: "HIGH" },
        social: { value: "https://instagram.com/drajulianaestetica", source: "instagram", collectedAt: now, confidence: "HIGH" },
        rating: { value: 4.9, source: "google_places", collectedAt: now, confidence: "HIGH" },
        reviewsCount: { value: 184, source: "google_places", collectedAt: now, confidence: "HIGH" },
      },
      audit: {
        url: null,
        hasHttps: false,
        isResponsive: false,
        hasCta: false,
        hasWhatsapp: false,
        hasForm: false,
        hasSocialLinks: false,
        performanceScore: 0,
        seoScore: 0,
        websiteScore: 0,
        status: "NO_WEBSITE",
      },
      insights: {
        summary: "Empresa possui 184 avaliações e nota 4.9 no Google, Instagram ativo, mas não possui website próprio.",
        painPoints: [
          { problem: "Ausência total de website comercial", evidence: "Google Places indica sem website oficial", confidence: 95 },
          { problem: "Tráfego de busca qualificado perdido", evidence: "184 avaliações 4.9 no Google sem link de agendamento próprio", confidence: 90 },
        ],
        opportunities: ["Landing Page orientada a agendamento WhatsApp", "Campanha Google Ads local"],
        recommendedOffer: "Landing Page de Alta Conversão com Botão WhatsApp",
        recommendedAngle: "Destacar a excelente nota 4.9 no Google e oferecer agendamento direto.",
        icebreaker: "Vi que a clínica já tem 184 avaliações excelentes no Google (nota 4.9), mas ainda não possui um site próprio para agendamentos.",
        priority: "HIGH",
        confidenceScore: 95,
      },
      firstSeenAt: now,
      lastSeenAt: now,
    },
    {
      id: "lead-campinas-2",
      name: "Studio Bella Estética & Spa",
      category: "Estética",
      address: "Rua Coronel Silva Telles, 450",
      city: "Campinas",
      state: "SP",
      phone: "+5519987654321",
      website: null,
      socialUrl: "https://instagram.com/studiobella",
      rating: 4.8,
      reviewsCount: 92,
      sniperScore: 88,
      scoreTier: "QUENTE",
      confidenceLevel: "HIGH",
      websiteStatus: "NO_WEBSITE",
      websiteScore: 0,
      crmStatus: "QUALIFICADO",
      scoreBreakdown: [
        { reason: "Sem site próprio", points: 25 },
        { reason: "Instagram ativo na região", points: 12 },
        { reason: "WhatsApp comercial disponível", points: 10 },
        { reason: "Alta reputação (Nota 4.8)", points: 8 },
        { reason: "Atividade digital recente", points: 7 },
      ],
      facts: {
        name: { value: "Studio Bella Estética & Spa", source: "google_places", collectedAt: now, confidence: "HIGH" },
        phone: { value: "+5519987654321", source: "google_places", collectedAt: now, confidence: "HIGH" },
        website: { value: null, source: "google_places", collectedAt: now, confidence: "HIGH" },
        social: { value: "https://instagram.com/studiobella", source: "instagram", collectedAt: now, confidence: "HIGH" },
        rating: { value: 4.8, source: "google_places", collectedAt: now, confidence: "HIGH" },
        reviewsCount: { value: 92, source: "google_places", collectedAt: now, confidence: "HIGH" },
      },
      audit: {
        url: null,
        hasHttps: false,
        isResponsive: false,
        hasCta: false,
        hasWhatsapp: false,
        hasForm: false,
        hasSocialLinks: false,
        performanceScore: 0,
        seoScore: 0,
        websiteScore: 0,
        status: "NO_WEBSITE",
      },
      insights: {
        summary: "Estética com 92 avaliações no Google, Instagram ativo e forte demanda local.",
        painPoints: [
          { problem: "Sem página oficial de serviços", evidence: "Campo website no Google está vazio", confidence: 90 },
        ],
        opportunities: ["Página de captura para agendamentos de tratamentos"],
        recommendedOffer: "Website Otimizado para WhatsApp",
        recommendedAngle: "Converter seguidores e buscas do Google em agendamentos diretos.",
        icebreaker: "Parabéns pelas 92 avaliações nota 4.8 no Google! Notei que vocês ainda não têm um site de agendamento.",
        priority: "HIGH",
        confidenceScore: 90,
      },
      firstSeenAt: now,
      lastSeenAt: now,
    },
    {
      id: "lead-sorocaba-1",
      name: "Barbearia Dom Pedro Vintage",
      category: "Barbearia",
      address: "Av. Afonso Vergueiro, 1500",
      city: "Sorocaba",
      state: "SP",
      phone: "+5515991234567",
      website: null,
      socialUrl: "https://instagram.com/dompedrobarbearia",
      rating: 4.8,
      reviewsCount: 142,
      sniperScore: 92,
      scoreTier: "SNIPER",
      confidenceLevel: "HIGH",
      websiteStatus: "NO_WEBSITE",
      websiteScore: 0,
      crmStatus: "CONTATADO",
      scoreBreakdown: [
        { reason: "Sem site próprio", points: 25 },
        { reason: "Instagram ativo na região", points: 12 },
        { reason: "WhatsApp comercial disponível", points: 10 },
        { reason: "100+ avaliações no Google", points: 10 },
        { reason: "Alta reputação (Nota 4.8)", points: 8 },
      ],
      facts: {
        name: { value: "Barbearia Dom Pedro Vintage", source: "google_places", collectedAt: now, confidence: "HIGH" },
        phone: { value: "+5515991234567", source: "google_places", collectedAt: now, confidence: "HIGH" },
        website: { value: null, source: "google_places", collectedAt: now, confidence: "HIGH" },
        social: { value: "https://instagram.com/dompedrobarbearia", source: "instagram", collectedAt: now, confidence: "HIGH" },
        rating: { value: 4.8, source: "google_places", collectedAt: now, confidence: "HIGH" },
        reviewsCount: { value: 142, source: "google_places", collectedAt: now, confidence: "HIGH" },
      },
      firstSeenAt: now,
      lastSeenAt: now,
    },
    {
      id: "lead-jundiai-1",
      name: "Academia X-Fit Cross",
      category: "Academia",
      address: "Av. 9 de Julho, 2100",
      city: "Jundiaí",
      state: "SP",
      phone: "+5511993456789",
      website: null,
      socialUrl: "https://instagram.com/xfitcrossjundiai",
      rating: 4.9,
      reviewsCount: 310,
      sniperScore: 96,
      scoreTier: "SNIPER",
      confidenceLevel: "HIGH",
      websiteStatus: "NO_WEBSITE",
      websiteScore: 0,
      crmStatus: "RESPONDEU",
      scoreBreakdown: [
        { reason: "Sem site próprio", points: 25 },
        { reason: "Instagram ativo na região", points: 12 },
        { reason: "WhatsApp comercial disponível", points: 10 },
        { reason: "100+ avaliações no Google", points: 10 },
        { reason: "Alta reputação (Nota 4.9)", points: 8 },
        { reason: "Sinal comercial forte", points: 5 },
      ],
      facts: {
        name: { value: "Academia X-Fit Cross", source: "google_places", collectedAt: now, confidence: "HIGH" },
        phone: { value: "+5511993456789", source: "google_places", collectedAt: now, confidence: "HIGH" },
        website: { value: null, source: "google_places", collectedAt: now, confidence: "HIGH" },
        social: { value: "https://instagram.com/xfitcrossjundiai", source: "instagram", collectedAt: now, confidence: "HIGH" },
        rating: { value: 4.9, source: "google_places", collectedAt: now, confidence: "HIGH" },
        reviewsCount: { value: 310, source: "google_places", collectedAt: now, confidence: "HIGH" },
      },
      firstSeenAt: now,
      lastSeenAt: now,
    },
  ];

  MEMORY_LEADS = seedLeads as Lead[];

  SAVED_SEARCHES = [
    {
      id: "search-1",
      title: "Clínicas de Estética em Campinas",
      queryText: "Encontre 50 clínicas de estética em Campinas com Instagram ativo e sem site",
      params: {
        niche: "estética",
        location: "Campinas, SP",
        radiusKm: 25,
        limit: 50,
        minReviews: 30,
        requireInstagram: true,
        requireWhatsapp: true,
        websiteCondition: "missing",
      },
      createdAt: now,
    },
    {
      id: "search-2",
      title: "Barbearias em Sorocaba",
      queryText: "Barbearias em Sorocaba com mais de 100 avaliações e sem site",
      params: {
        niche: "barbearia",
        location: "Sorocaba, SP",
        radiusKm: 25,
        limit: 50,
        minReviews: 100,
        requireInstagram: true,
        requireWhatsapp: true,
        websiteCondition: "missing",
      },
      createdAt: now,
    },
  ];
}

export class MandraRepository {
  private placesProvider = new GooglePlacesProviderImpl();
  private enrichmentEngine = new MandraEnrichmentEngine();

  constructor() {
    ensureSeeded();
  }

  public async getLeads(filters?: {
    query?: string;
    city?: string;
    niche?: string;
    minScore?: number;
    websiteStatus?: string;
    crmStatus?: LeadCrmStatus;
  }): Promise<Lead[]> {
    ensureSeeded();
    let result = [...MEMORY_LEADS];

    if (filters) {
      if (filters.query) {
        const q = filters.query.toLowerCase().trim();
        result = result.filter(
          (l) =>
            l.name.toLowerCase().includes(q) ||
            l.city.toLowerCase().includes(q) ||
            l.category.toLowerCase().includes(q)
        );
      }
      if (filters.city) {
        result = result.filter((l) => l.city.toLowerCase().includes(filters.city!.toLowerCase()));
      }
      if (filters.niche) {
        result = result.filter((l) => l.category.toLowerCase().includes(filters.niche!.toLowerCase()));
      }
      if (filters.minScore) {
        result = result.filter((l) => l.sniperScore >= filters.minScore!);
      }
      if (filters.websiteStatus) {
        result = result.filter((l) => l.websiteStatus === filters.websiteStatus);
      }
      if (filters.crmStatus) {
        result = result.filter((l) => l.crmStatus === filters.crmStatus);
      }
    }

    return result.sort((a, b) => b.sniperScore - a.sniperScore);
  }

  public async getLeadById(id: string): Promise<Lead | null> {
    ensureSeeded();
    return MEMORY_LEADS.find((l) => l.id === id) || null;
  }

  public async updateLeadCrmStatus(id: string, status: LeadCrmStatus): Promise<Lead | null> {
    ensureSeeded();
    const lead = MEMORY_LEADS.find((l) => l.id === id);
    if (lead) {
      lead.crmStatus = status;
      lead.lastSeenAt = new Date().toISOString();
      return lead;
    }
    return null;
  }

  public async runProspectingJob(
    params: SearchFilterParams,
    options?: { searchMode?: any; searchDepth?: any }
  ): Promise<{
    jobId: string;
    leads: Lead[];
    isDemo: boolean;
    debugLog?: any;
  }> {
    ensureSeeded();

    const orchestrator = new LeadDiscoveryOrchestrator();
    const discoveryResult = await orchestrator.executeDiscovery({
      params,
      searchMode: options?.searchMode || "DEEP_SEARCH",
      searchDepth: options?.searchDepth || "DEEP",
    });

    const enrichedLeads = discoveryResult.leads;

    // Merge into memory store deduplicating by ID/Name+City
    for (const lead of enrichedLeads) {
      const existingIdx = MEMORY_LEADS.findIndex(
        (l) => l.id === lead.id || (l.name === lead.name && l.city === lead.city)
      );
      if (existingIdx >= 0) {
        MEMORY_LEADS[existingIdx] = lead;
      } else {
        MEMORY_LEADS.push(lead);
      }
    }

    return {
      jobId: discoveryResult.searchRunId,
      leads: enrichedLeads.sort((a, b) => b.sniperScore - a.sniperScore),
      isDemo: discoveryResult.debugLog.isDemo,
      debugLog: discoveryResult.debugLog,
    };
  }

  public async getSavedSearches() {
    ensureSeeded();
    return SAVED_SEARCHES;
  }

  public async saveSearch(title: string, queryText: string, params: SearchFilterParams) {
    ensureSeeded();
    const newSearch = {
      id: `search-${Date.now()}`,
      title,
      queryText,
      params,
      createdAt: new Date().toISOString(),
    };
    SAVED_SEARCHES.unshift(newSearch);
    return newSearch;
  }

  public async getCrmDeals(): Promise<CrmDeal[]> {
    ensureSeeded();
    return MEMORY_LEADS.map((lead, idx) => ({
      id: `deal-${lead.id}`,
      leadId: lead.id,
      lead,
      stageId: lead.crmStatus,
      status: lead.crmStatus,
      dealValue: lead.sniperScore >= 90 ? 2500 : 1800,
      position: idx,
    }));
  }

  public async getProviderHealth(): Promise<ProviderHealth[]> {
    return [
      {
        name: "OpenAI API",
        status: process.env.OPENAI_API_KEY ? "CONFIGURED" : "DEMO_MODE",
        message: process.env.OPENAI_API_KEY ? "Conectado Server-Side" : "Modo Demonstração Ativo",
      },
      {
        name: "Google Places API",
        status: process.env.GOOGLE_PLACES_API_KEY ? "CONFIGURED" : "DEMO_MODE",
        message: process.env.GOOGLE_PLACES_API_KEY ? "Chave Ativa" : "Modo Demonstração Ativo",
      },
      {
        name: "Instagram Authorized API",
        status: process.env.INSTAGRAM_PROVIDER_API_KEY ? "CONFIGURED" : "DEMO_MODE",
        message: process.env.INSTAGRAM_PROVIDER_API_KEY ? "Chave Ativa" : "Modo Demonstração Ativo (Compliance)",
      },
      {
        name: "Supabase PostgreSQL",
        status: process.env.NEXT_PUBLIC_SUPABASE_URL ? "CONFIGURED" : "DEMO_MODE",
        message: process.env.NEXT_PUBLIC_SUPABASE_URL ? "Supabase Conectado" : "Store Persistente Ativa",
      },
    ];
  }
}
