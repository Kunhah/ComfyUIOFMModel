# Mandra

Marketing site for Mandra — a Brazilian agency selling websites, custom
systems, AI and automation. Single-page, pt-BR, with alternating light/dark
section bands and a custom-shader Three.js globe in the hero that responds to
scroll.

It also hosts two internal lead-generation tools, same app, same tokens, no
marketing chrome — see their docs for everything about them:

- **[Mandra Prospector](docs/prospector.md)** at `/prospector` — local
  businesses _without_ a website, ranked by how badly they need one. Brazil out
  of the box; any country in the registry after one `npm run sync -- --countries`.
- **[Prospector B2B](docs/prospector-b2b.md)** — the other tab of the same
  screen: companies that _do_ have one (industry, engineering, health, finance,
  logistics, ISPs, mostly Europe), crawled for the e-mail address of someone who
  can sign. `/prospector/b2b` still opens it directly.

Where the CRM around them is going — one WhatsApp inbox, an agenda and outreach
sequences, with a login for each client we sell a website to — is planned in
**[Atlas Plataforma](docs/plataforma.md)**. That document is a design, not a
description: only the parts it marks as built exist today.

Wiring a client's site — its own repository, hosted wherever — to this CRM is a
script tag, two environment variables and one HTTP call:
**[Integração do cliente](docs/integracao-cliente.md)**. Each account's
pre-filled kit, key included, lives at `/admin/contas/<slug>`.

Built with Next.js 16 (App Router, Turbopack), React 19, Tailwind CSS v4 and
react-three-fiber.

## Getting started

This project lives in `Website/` inside a repo wired together as an **npm
workspace**. Install from the repo root:

```bash
cd ..            # repo root
npm install      # hoists dependencies for every workspace
npm run dev      # forwards to this workspace
```

You can still run the scripts below from inside `Website/`.

> The workspace root is not cosmetic. Turbopack resolves the Next.js package
> relative to the repo root in dev; without a root `package.json` +
> `node_modules` it panics with "Next.js package not found" on every Fast
> Refresh, and the browser hard-reloads a few times a second — which looks like
> the animations endlessly restarting. Don't nest a project here without adding
> it to `workspaces`.

| Script                    | What it does                                                                                |
| ------------------------- | ------------------------------------------------------------------------------------------- |
| `npm run dev`             | Dev server (Turbopack)                                                                      |
| `npm run build`           | Production build                                                                            |
| `npm start`               | Serve the production build                                                                  |
| `npm run lint`            | ESLint                                                                                      |
| `npm run typecheck`       | `tsc --noEmit`                                                                              |
| `npm run format`          | Prettier                                                                                    |
| `npm run globe:points`    | Regenerate the globe's land-point data (rarely needed)                                      |
| `npm run globe:monogram`  | Regenerate the Mandra-mark point cloud the dots reform into                                 |
| `npm run up`              | Prospector: check its data is in place, fix what isn't, then start                          |
| `npm run check`           | Prospector: report what's missing and exit                                                  |
| `npm run sync` / `cities` | Prospector: rebuild the Overture extract / city index. `sync -- --list` shows the countries |
| `npm run sync:b2b`        | Prospector B2B: build the multi-country company extract (optional)                          |

## Architecture

```
src/
  app/
    layout.tsx    document shell only — <html>, <body>, fonts
    globals.css   design tokens; sitemap/robots/opengraph-image alongside
    (marketing)/  the public site: its layout owns header, footer, providers
    prospector/   the internal tool — no marketing chrome
    api/prospector/  its route handlers
  content/        all copy and data as typed modules — sections stay presentational
  components/
    layout/       header, mobile nav, footer
    sections/     one file per band of the page
    ui/           button, card, section, container, badge, headings, logo
    motion/       scroll tracker, reveals, hero pin, pinned showcases
    globe/        the WebGL hero globe (see below)
    prospector/   the tool's board and status picker
  lib/            cn(), scroll store
    prospector/   search engine, scoring, DuckDB + SQLite access
    b2b/          discovery, crawler, e-mail/company extractors, scoring, history
  data/prospector/  committed city index and the Overture category reference
  hooks/          useMediaQuery
scripts/          build-time land-point generator
  prospector/     launcher, Overture sync, city-index builder, B2B sync
data/             gitignored — the Overture extracts and the lead history DBs
```

The split is two route trees over one root layout. `app/layout.tsx` is
deliberately just the document shell: the header, footer and motion providers
live in `(marketing)/layout.tsx`, which is what lets `/prospector` opt out of
them without a second _root_ layout — that would turn every crossing between the
two into a full page reload.

### Theming: tones, not a toggle

There is no light/dark switch. Sections carry a fixed tone, matching the design.
`<Section tone="light" | "muted" | "dark" | "brand">` sets `data-tone`, which
remaps the semantic CSS variables (`--fg`, `--surface`, `--line`, …) for its
whole subtree. Components style against those semantic tokens only, so a card or
button is automatically correct on any band and no `dark:` variants are needed.

One subtlety worth knowing before editing `globals.css`: the semantic colours
**must** live in `@theme inline`. A plain `@theme` emits
`--color-surface: var(--surface)` on `:root`, where the `var()` is substituted
against `:root`'s value — so `[data-tone]` overrides deeper in the tree would
never take effect.

`[data-prospector]` is the same mechanism, applied to a whole route rather than
a band: the tool remaps those semantic variables to its darker dashboard
surfaces, so its components use the ordinary `bg-surface` / `text-fg-muted`
utilities and needed no second stylesheet when it was merged in. A new semantic
colour has to be given a value in _every_ tone block, or it resolves to nothing
on the bands that lack it.

### Motion

**Scrolling itself is native.** There is deliberately no smooth-scroll library:
hijacking the wheel to add inertia makes the page feel detached from the input
device. What's animated is the _content_.

Most sections use `Appear` — a one-shot fade-and-rise the first time they scroll
into view, `once: true` so nothing re-animates when you scroll back up. The
elaborate treatments are reserved for three places where the movement is the
point:

| Where                                               | What happens                                                                                                                           |
| --------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| **Hero** (`motion/hero-pin.tsx`)                    | Pins for ~2.2 screens while the globe runs its three-act sequence; the copy and metric cards peel away on a stagger as it takes over.  |
| **Serviços / Cases** (`motion/pinned-showcase.tsx`) | Pin and step through their items — one large panel transitions into the next while an index tracks progress, instead of a static grid. |
| **Ecosystem / Process**                             | The Mandra Core board scales up with each node sliding in from its own edge; the 7-step timeline's rule draws itself from origin.      |

`ScrollTracker` publishes native scroll position and hero progress into a
**vanilla** Zustand store (`lib/scroll-store`), coalesced into one rAF tick. The
globe reads that store imperatively inside `useFrame`, so 60fps scroll updates
drive shader uniforms without ever re-rendering React.

#### Three traps worth knowing before editing any of this

1. **`overflow` other than `visible` on _any_ ancestor silently kills
   `position: sticky`.** Both pinned components keep their `overflow-hidden` on
   the sticky panel itself. Decorative glows that need clipping go in a wrapper
   that is a _sibling_ of the pinned subtree, never an ancestor.

2. **Motion accelerates simple scroll→style maps onto a native `ViewTimeline`.**
   That timeline measures how far the element itself has crossed the viewport —
   meaningless for a pinned panel, which by definition isn't moving. The symptom
   is an accelerated property (opacity) drifting out of sync with a JS-driven one
   (transform) despite both reading the same source. `useDetachedProgress` mirrors
   the value into a plain `MotionValue` to opt out.

3. **Never branch DOM structure or inline style on a client-only media query.**
   The server can't know whether the user prefers reduced motion, so the markup
   won't match and React discards and re-renders the whole subtree. Un-pinning —
   both for reduced motion and below `lg`, where a two-column showcase can't fit
   a viewport — is done entirely with `motion-reduce:` / `max-lg:` CSS variants
   over a single rendered tree.

### The globe

`components/globe/`, mounted through `GlobeStage`:

- **Land points** come from `public/data/land-points.bin` — 48,831 lat/lon pairs
  as `Int16Array` (~190 KB), generated once by `scripts/generate-globe-points.mjs`
  from Natural Earth's **50m** land polygons via a Fibonacci-sphere sample.
  Committed, so there is no build-time dependency. Chosen over sampling a
  land-mask PNG at runtime: no image asset to source, no decode cost, no canvas
  readback on first paint.
  The 50m set (rather than 110m) is what makes islands, peninsulas and inlets
  survive sampling instead of smoothing into blobs. Generation takes a few
  minutes — it is point-in-polygon over far more edges — which is fine for a
  script run by hand.
  Dot size and point budget are coupled: a denser cloud needs _smaller_ dots or
  the continents merge into a solid mass and the extra detail is thrown away.
- **Shaders** live in `.ts` modules as template literals (`shaders/`), not
  `.glsl` files — Turbopack needs no loader configuration that way. Four
  programs: the dot cloud, the opaque body, the fresnel atmosphere, and the
  connection arcs.
- **The body sphere** exists mainly for depth: by writing depth it genuinely
  occludes dots on the far hemisphere, which the dot shader's facing term alone
  cannot do correctly.
- **The scroll sequence** — one `useFrame` reads `heroProgress`, damps it, and
  derives three overlapping phases from it:
  1. _globe_ — dots sit on the sphere, arcs pulsing, idle rotation;
  2. _explode_ — they burst outward into a swirling cloud while the body, glow,
     arcs and city markers all clear out;
  3. _reform_ — the cloud converges into the Mandra "M", staggered by seed so the
     mark assembles progressively, with rotation unwinding to zero so it settles
     square to the camera.
     The mark's point cloud is generated by `npm run globe:monogram`, which samples
     the logo's own path geometry.
- **Dots use normal, not additive, blending.** Additive can only brighten what's
  behind it, so the moment they leave the dark globe for the white page they
  would vanish; they also shift to saturated brand blue for the loose phase.
- **Pointer steering** — the mouse adds pronounced yaw (±0.42 rad) and pitch
  (±0.3 rad) on top of the idle spin, plus translation for depth, so the globe
  feels steered rather than merely nudged.

Two sizing constraints are load-bearing and easy to break: the atmosphere shell
must stay inside the camera frustum (at fov 35 / z 3.6 the visible half-height is
~1.135, so the shell is 1.055), or its additive glow fills the canvas as a
bright rectangle; and the shell is a fixed ratio of the globe, so enlarging the
render widens its halo into a heavy band.

Guardrails, all verified by measuring GPU draw calls:

| Condition                | Behaviour                                    |
| ------------------------ | -------------------------------------------- |
| Hero in view             | ~826 draws/sec (60fps)                       |
| Scrolled past the hero   | **0** draws — `frameloop` flips to `"never"` |
| `prefers-reduced-motion` | One static frame, then **0** draws           |
| No WebGL                 | Canvas never mounts; the static poster stays |
| Viewport ≤ 768px         | Point budget drops from 44k to 12k           |

The canvas is deliberately held back until after the `load` event and then until
the main thread is idle. Parsing Three.js costs ~2s of CPU on a throttled device,
and running that before first paint pushes LCP out by the same amount. The static
poster (`globe-poster.tsx`) is painted server-side throughout and cross-fades out
once WebGL has a real frame, so nothing ever looks unfinished.

## Deploying with Docker

The `Dockerfile` and `scripts/publish_images.sh` live at the **repo root**, not
here — this is an npm workspace and the lockfile is one level up, so the build
context has to be the root.

```bash
cd ..                                  # repo root
./scripts/publish_images.sh --no-push   # build and load locally
./scripts/publish_images.sh             # build and push :latest + :<git-sha>
docker run -d -p 28527:28527 -v atlas-data:/app/Website/data kunhah/atlas-digital
```

`--help` lists the flags (`--platform`, `--user`, `--image`, `--no-latest`); each
has an environment-variable equivalent for CI.

### Dokploy

`docker-compose.yml` at the repo root **pulls** the published image rather than
building one, so a deploy is a pull and a restart on the server, not a Next build
on it. The loop is:

```bash
./scripts/publish_images.sh   # from your machine: build, push :latest + :<git-sha>
                             # then hit Redeploy in Dokploy
```

Setting it up once: create a **Compose** application, point it at this repo,
leave the compose path at `./docker-compose.yml`, then add the domain under the
**Domains** tab against service `web`, port `28527`. Dokploy writes the Traefik
labels and joins `dokploy-network` itself — that's why the file contains neither,
and doing it in the UI _and_ the file leaves two routers fighting over one host
rule. If the Hub repository is private, add the credential under Dokploy's
**Registry** settings first.

The app listens on **28527**, not 3000 — the VPS is shared and the common ports
are the ones already taken. It's set in three places that must agree: `ENV PORT`
and `EXPOSE` in the Dockerfile, `expose` and `PORT` in the compose file, and the
port you type into the Domains tab.

Two variables in the compose file are meant to be set from Dokploy's
**Environment** tab:

| Variable      | Default                | Use                                           |
| ------------- | ---------------------- | --------------------------------------------- |
| `ATLAS_IMAGE` | `kunhah/atlas-digital` | Point at a different Hub repository           |
| `ATLAS_TAG`   | `latest`               | Pin a release, or roll back to a `:<git-sha>` |

`ATLAS_TAG` is what the commit-SHA tags are for: `latest` alone gives a running
container no way to say which build it is, or to go back to a specific one.

Also set `MANDRA_ADMIN_USER`, `MANDRA_ADMIN_PASSWORD`, and
`MANDRA_SESSION_SECRET` there. They are passed through to the container by
Compose and are required for the protected admin and prospector tools.

The file runs anywhere else `docker compose up -d` does — uncomment the `ports`
block when there's no proxy in front.

Two things about the image are worth knowing before changing it:

- **`/app/Website/data` must be a volume.** The Overture extract (~127MB) and
  lead history are runtime state, never baked into the image, so a normal
  redeploy reuses them without transferring the extract again. A new volume
  starts empty and the prospector uses its slower S3 fallback until you copy the
  extract in once (`docker cp`) or bind-mount the host folder.
- **The base image is Debian (`node:26-slim`), not Alpine.** DuckDB's binding
  links against glibc and has no musl build; on Alpine it installs cleanly and
  then fails at the first search.

`OVERTURE_RELEASE`, `PROSPECTOR_DB`, and the optional `GEOAPIFY_API_KEY` are
read from the environment — see `.env.example`.

## Known state

- **The contact form is presentational only.** Submit is disabled by design;
  there is no route handler, validation schema or email provider yet. The visible
  note tells visitors to use the direct channels meanwhile.
- **Case-study imagery is placeholder** — tinted gradient plates stand in until
  real screenshots are supplied (`content/cases.ts`, `sections/cases.tsx`).
- **`/privacidade` and `/termos` are placeholders.** The routes exist so the
  footer links resolve rather than 404, and they're `noindex`, but the actual
  policy text must come from the client's counsel — inventing legal copy would
  be worse than stating it's pending. Required before launch.
- "Saiba mais" / "Ver projeto" links anchor in-page; there are no detail routes.
- No analytics, no CMS, no i18n (pt-BR only).

## Measured quality

Lighthouse against the production build, in a headless container with **no GPU**
(software WebGL via SwiftShader) and Lighthouse's default 4× CPU throttling:

| Category       | Score                       |
| -------------- | --------------------------- |
| Accessibility  | 100                         |
| Best practices | 100                         |
| SEO            | 100                         |
| Performance    | 64–70 (run-to-run variance) |

CLS is 0 and FCP ~1.2s. The performance score is dominated by Three.js parse cost
plus software rasterisation of the globe on the CPU; **this environment cannot
measure real-GPU performance**, so treat that number as a floor, not as what
users on real hardware will see. Re-measure on target hardware before drawing
conclusions. Page renders with no horizontal overflow at 390 / 768 / 1440.
