<!-- BEGIN:nextjs-agent-rules -->

# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` before writing any code. Heed deprecation notices.
<!-- END:nextjs-agent-rules -->

# Layout of the app

- **Two trees, one root layout.** `src/app/(marketing)/` is the public site and
  owns the header, footer and motion providers; `src/app/prospector/` is an
  internal tool and owns none of them. `src/app/layout.tsx` is deliberately just
  the document shell (`<html>`, `<body>`, fonts) — putting chrome back in it
  would put a marketing header on the tool. Don't split these into two _root_
  layouts; that makes every crossing between them a full page reload.
- **The tool is styled by remapping tokens, not by a second stylesheet.**
  `[data-prospector]` in `globals.css` is a tone block like `[data-tone="dark"]`,
  so the tool's components use the same `bg-surface` / `text-fg-muted` /
  `border-line` utilities the marketing components do. New semantic colours must
  go in `@theme inline` and be given a value in _every_ tone block, or they
  resolve to nothing on the bands that lack them.

# The Google Ads landing pages

- **`src/app/(ads)/` is a third route group, not a folder inside
  `(marketing)/`**, and the header is the whole reason. The marketing header
  carries five navigation links and every one of them is a way for a click we
  paid for to leave the page without calling. The ads chrome has two things:
  the wordmark and the number.
- **All six pages are one template over `src/content/ads.ts`.** A seventh ad
  group is an entry in that file, never a new route. `(ads)/[slug]` sits at the
  root so the URLs stay short (`/sites-energia-solar`), with
  `dynamicParams = false` — an unknown slug is a 404, and the static
  `(marketing)` routes still win over the dynamic segment.
- **The copy is written per trade and must stay that way.** Six pages differing
  only in a noun are duplicate content to a crawler and a bounce to a reader;
  the pains, the deliverables and the FAQ are the parts that have to be
  genuinely different, and they are what the page is for.
- **Nothing on these pages asserts a figure we do not have.** Same rule as the
  rest of the marketing surface (PRODUCT.md): no rating, no client count, no
  invented result — which is also why the structured data has a
  `ProfessionalService`, a `Service` and a `FAQPage` and deliberately no
  `AggregateRating`. `investimento` is null on every page and the price row
  only renders when someone sets it.
- **A `tel:` link is invisible to Google Ads.** It leaves the browser with no
  page view, so without `reportConversion()` firing on the tap the campaign
  optimises towards clicks forever. That is what `src/lib/ads/gtag.ts` exists
  for, and it is inert until `NEXT_PUBLIC_GOOGLE_ADS_ID` and the two label vars
  are set — an empty gtag would be a third-party request on the exact pages
  whose load time the quality score is measured on.
- **No WebGL here.** The hero field is the largest contentful paint on the home
  page, and on a landing page that is a number Google charges money for. The
  ads tree renders no canvas at all.
- **The sticky call bar is load-bearing and the layout reserves its height**
  (`pb-[76px] lg:pb-0`). Drop the padding and it covers the last line of the
  footer on every phone.
- **`site.contact.phone` is real now.** It was the `(11) 99999-9999`
  placeholder and was deliberately unrendered; the footer and the Terminal band
  show it again. E-mail, postal address and the social URLs in
  `src/content/site.ts` are still placeholders.
- **The pages measure themselves, and that layer is first-party on purpose.**
  `src/lib/analytics/` + `/api/v1/analytics` +
  `components/analytics/tracker.tsx` + `/admin/analytics`, over
  `data/analytics.db` — a third SQLite file, separate from `prospector.db` and
  `b2b.db` for the same reason those two are separate from each other. Google
  answers "how many"; this answers "where on the page do we lose them", which
  is the only one of the two that changes the page.
- **It measures the whole site, not just the ads.** The allowlist is the
  registry in `lib/analytics/pages.ts`, not `adPageBySlug`. Adding a page means
  an entry there plus `<PageTracker page="<slug>" />` on it; the collector
  refuses anything else. Site slugs share a namespace with ad slugs and
  `pages.test.ts` fails on a collision — an ad group named `home` would take
  over the home page's row, funnel and history without a word.
- **The collector needs a writable disk, and it gets one from the container's
  volume.** The whole app is one Next process on the VPS with
  `prospector-data:/app/Website/data` mounted, so `data/analytics.db` sits
  beside the prospector's extract and history and the beacon is same-origin —
  which is why the route has no CORS and the tracker has no configurable
  endpoint. Netlify was a test target, not the deployment; a deploy there
  serves the pages and records nothing, because its function bundle is
  read-only. `/admin/analytics` calls `health()` and shows the unmounted-volume
  failure rather than a confident zero, which is the same courtesy the
  prospector's empty-extract checks pay.
- **The one-line account suffix is what makes the keyword column exist.**
  Google appends only `gclid`; everything else — keyword, match type, ad group
  — comes from the Final URL suffix pasted once at account level.
  `FINAL_URL_SUFFIX` in `lib/analytics/tagging.ts` is the single source for it,
  read by both the docs and the dashboard's banner so the two cannot drift, and
  `untaggedPaid()` is what makes the dashboard ask rather than assume. The
  tracker drops a value that still looks like `{keyword}`: Google leaves the
  placeholder in place when a click has no value for it, and storing that
  literal would be worse than storing nothing.
- **Nothing in the analytics path may store personal data.** No IP, no cookie,
  no cross-site id, and the referrer is reduced to a host before it is written.
  The session id lives in `sessionStorage` and dies with the tab. That is what
  lets these pages ship with no consent banner, and a new column that could
  identify someone would cost that.
- **An element is measured by carrying an attribute, never by importing the
  tracker.** `data-section`, `data-ads-action` + `data-placement`, `data-faq`.
  The listeners are delegated from the document, so the same `CallAction` works
  on the marketing site's Terminal band and is measured there too — an action
  that has to be told about analytics is one that ships without it.
- **There is one funnel per template, not one funnel.** `ADS_FUNNEL` and
  `SITE_FUNNEL` in `lib/analytics/events.ts`, looked up per page by
  `funnelFor()`. A new step goes in the right list, in page order — that list
  _is_ the funnel, and a `data-section` no list knows is dropped by the
  collector and reads on the dashboard as a step nobody reached.
- **Never compare `deepest` against a funnel's length.** The lengths differ (six
  bands and eight), so the comparison files a home-page reader who stopped two
  bands early as having read everything. `reached_end` is stored on the session
  for exactly this, and `multi-page.test.ts` pins it.
- **A funnel needs a scope of one shape.** `funnel()` returns `[]` when the
  scope names neither a page nor a template, because a chart adding two page
  structures together shows steps that exist on neither. The screen says so
  rather than rendering an empty chart that reads as missing data.
- **The collector validates `page` against the registry** and validates the
  `name` of `section`, `exit` and `dwell` against `ALL_SECTIONS`. Those three
  are grouped on directly by the dashboard, so an unrecognised name is not a
  harmless extra row — it is a made-up band that anyone who can POST could put
  in the exit table.
- **No backticks inside the SQL template literals in `db.ts`.** One ends the
  literal, and the parse error points at the SQL rather than at the quote. The
  schema comment says so; it is still the easiest way to break that file.
- **Clamp an event's `value` by what the value means.** A scroll depth is a
  percentage; clamping it to the generic ceiling let a client post 9999, which
  does not throw and silently moves that session into the deepest scroll
  bucket. Found by a smoke test, not by a type.
- **The rollups on `sessions` use `max()`/`min()`, never `+`.** `sendBeacon`
  gives no delivery guarantee in either direction, so a repeated batch must be
  harmless — `db.test.ts` pins that, and the CTA counters are the deliberate
  exception because a second tap is a second tap.
- **The WhatsApp opener is the only attribution a `wa.me` link carries.** The
  link has no metadata channel, so `whatsappMessage` _is_ the source: each of
  them is written by hand to name its page and ask for something only
  that page offers, so an opener tells you which landing page produced the
  conversation and what the person already read. Templating them off the
  trade's name is how every page ends up with one message you cannot tell apart
  in the inbox — `ads.test.ts` pins uniqueness.
- **New pages belong in `sitemap.ts` and in `footerSegmentLinks`.** The sitemap
  is how they get crawled at all; the footer link is how they get crawled from
  a page with some authority. A landing page with neither is one the paid click
  has to carry on its own. Past a handful of them the footer column is a
  curated subset rather than the whole list — the sitemap is what has to stay
  complete, and it is generated from `adPages`, so it is.

# Prospector specifics

- **DuckDB is a native module.** Route handlers that touch it must declare
  `export const runtime = "nodejs"`, and both `@duckdb/node-api` and
  `@duckdb/node-bindings` must stay in `serverExternalPackages` (next.config.ts).
  Bundling them breaks `require` of the `.node` binary.
- **The standalone build needs `libduckdb.so` named explicitly.** Next's tracer
  finds `duckdb.node` (it is required by name) but not the `.so` beside it, which
  the binary dlopens — invisible to static analysis. That is what
  `outputFileTracingIncludes` in next.config.ts is for; drop it and the Docker
  image starts fine, then fails every prospector request with "libduckdb.so:
  cannot open shared object file". `outputFileTracingRoot` next to it is equally
  load-bearing: node_modules is hoisted to the workspace root, so the default
  trace root excludes every dependency.
- **The runner image must install `ca-certificates`.** `node:slim` purges it after
  bootstrapping Node, and DuckDB's httpfs reads the system CA bundle rather than
  Node's compiled-in one — so remote (S3) searches fail with "Problem with the SSL
  CA cert (path? access rights?)" while the rest of the site is fine. Seeding the
  extract volume avoids the network entirely and is still the real fix.
- **The platform binding is an optionalDependency.** If `@duckdb/node-api` throws
  `MODULE_NOT_FOUND` on `duckdb.node`, npm skipped the per-platform package —
  check `optionalDependencies` in package.json covers your platform.
- **The city filter must match `city_norm`, not `nrm(city)`.** A function over a
  column is opaque to Parquet's row-group statistics, so `nrm(city) = '...'` prunes
  nothing no matter how the file is sorted — a Belo Horizonte search read 82MB of
  the 122MB extract. Matching the stored, pre-folded column that `ORDER BY
city_norm, uf` sorts on reads 9MB. `queryOverture` probes for the column and
  falls back to `nrm()` when it's missing, so an older extract still works, just
  slower; `npm run upgrade-extract` adds it in seconds without re-downloading.
- **The `uf` disjunction is why the city predicate has to carry the pruning.**
  `(uf = $uf OR uf IS NULL)` can't use min/max statistics, so `uf` prunes nothing
  even though the file is sorted by it. Don't "fix" this by dropping the NULL
  branch — that silently discards the state-less records the bbox already pins.
- **The deployment is the container with `data/` on a Docker volume**, not
  Netlify. Netlify builds the marketing site; the prospector routes exist in that
  build and will answer, but with no extract they fall back to the planet-wide S3
  bucket at 90s–230s and die on the ~30s function timeout as a 502. Seed the
  volume with `./scripts/seed_prospector_volume.sh` — it starts empty on purpose,
  and an empty one is indistinguishable from a broken tool.
- **The local extract is now the only source.** `resolveSource()` throws when
  `data/places.parquet` (or the older `data/br-leads.parquet`) is missing — the `PROSPECTOR_EXTRACT_URL` and S3
  fallbacks were removed, and the mentions still left in the Dockerfile and
  docker-compose comments are stale. A host with no disk has no prospector; the
  volume must be seeded (`./scripts/seed_prospector_volume.sh`).
- **DuckDB needs `home_directory` when `HOME` is empty.** Lambda-based hosts
  (Netlify Functions) give the process no HOME, and `INSTALL httpfs` then fails
  with "Can't find the home directory at ''" before any query runs. `duckdbConfig()`
  points it at /tmp only in that case, so a normal machine keeps its extension cache.
- **Never invent an Overture category string.** They come from
  `src/data/prospector/overture-categories.csv`. An unknown category matches
  nothing and fails silently, which reads as "no businesses in this city".
- **After changing `src/lib/prospector/niches.ts`, re-run `npm run sync` then
  `npm run cities`.** New categories are not in the existing extract, and the city
  index and its counts are derived from the extract.
- **The prospector is no longer Brazil-only, and the extract is what decides its
  reach.** `npm run sync` defaults to Brazil; `-- --countries PT,ES`,
  `-- --region "Europa Ocidental"`, `-- --add` and `-- --all-countries` widen it,
  and `npm run cities` has to follow. The country picker is built from
  `indexedCountries()` — the countries actually in `src/data/prospector/cities.json` —
  never from the registry, or it offers searches that return nothing.
- **`src/lib/countries.ts` is the one country table**, shared by the prospector and
  by B2B (`src/lib/b2b/countries.ts` re-exports it plus its crawl-only helpers).
  Duplicating a bounding box is how the two halves start disagreeing about where a
  country is, and a wrong box is silent: the scan just returns less.
- **`mobile` in that table decides the WhatsApp button, and it is run twice** — in
  JS by `isWhatsappCapable()` and interpolated into SQL by `whatsappSql()` in
  `overture.ts`, because the "com WhatsApp" total is counted over every match
  rather than over the returned page. Keep the patterns free of quotes and of
  anything RE2 can't parse; `score.test.ts` enforces both.
- **`null` in `mobile` means "we can't tell", not "no WhatsApp".** The US and
  Canada share one format for mobiles and landlines, and a wa.me link to a
  landline opens a dead chat. Don't "fix" it with a length heuristic.
- **The state code is optional outside Brazil.** Brazil has 27 codes we validate;
  elsewhere the region is normalised free text and is empty for whole countries.
  `resolveCity` accepts a city with no region and the query drops the `uf`
  predicate for it — country, bbox and locality already pin it.
- **Only sync scripts that import shared TS run through `--import
./scripts/ts-register.mjs`** (see package.json). Bare `node` can't resolve the
  `@/` alias, an extensionless relative import, or a directory import
  (`./discovery` → `discovery/index.ts`, which bare Node rejects outright rather
  than falling back), so a script importing a module that has imports of its own
  fails at load. `scripts/ts-hooks.mjs` teaches it all three; anything Next's
  bundler resolves silently has to be taught there before a script can import it.
- **Aggregate stats belong in SQL, not in JS over the returned rows.** The result
  set is capped by `limit`; counting it reports the limit back as the pool size.
- **`normalise()` in `src/lib/prospector/cities.ts` and `nrm()` in
  `src/lib/prospector/overture.ts` must fold identically** (case, accents,
  punctuation), and `build-city-index.mjs` has a third copy as a SQL macro. If they
  drift, a city resolves in the picker and then returns zero rows — which reads as
  "no businesses here".
- **The city index is derived from the extract, never from Overture's division
  boundaries.** Boundary names that no business uses are unsearchable by
  definition; that is how Brasília's 7,283 businesses were invisible. Divisions
  supply display spelling only.
- **Don't fuzzy-match city names.** It was tried and reverted: 13 of 19 generated
  pairs joined different municipalities. `ALIASES` in `build-city-index.mjs` is
  hand-written on purpose.
- **The country filter in the sync is required, not redundant** with the bounding
  box. The box is the union of the selected countries' rectangles, so it covers
  everything between and around them; Brazil's alone covers seven neighbours and
  let 284k foreign businesses into the extract before the test existed.
- **`instrumentation.ts` must never let `warmProspector()` reject.** Next treats a
  failed instrumentation hook as a failure to start, so a missing extract took the
  _whole_ site down — marketing pages included — which is exactly the state a
  container is in the first time it runs against an empty volume. Swallowing it
  costs nothing: `getConnection()` doesn't cache a failed init, so the prospector
  starts working the moment the volume is seeded, with no restart.
- **History is SQLite via `node:sqlite`** (`src/lib/prospector/db.ts`), a Node
  builtin — no dependency and nothing for `serverExternalPackages`. Don't add
  `better-sqlite3` or an ORM. The API is synchronous by design; `persistLeads` is
  not async.
- **Watch backticks inside the SQL template literals in `db.ts`.** A backtick in a
  comment inside the schema string terminates the literal and the parse error
  points at the SQL, not at the quote.
- **Only _additive_ schema changes reach an existing `data/prospector.db`**, and
  only via `addMissingColumns()`. The table DDL itself is
  `CREATE TABLE IF NOT EXISTS`, so renames, type changes and constraint changes
  need the file deleted.
- **The search URL has one parser, `parseInitialSearch` in `search-url.ts`**, and
  it is the counterpart of `runSearch` in prospector.tsx, which is what writes
  that query string. It was a copy per page and they drifted exactly as
  `parseFilters` already taught: the `/admin/prospector` copy predated broad
  searches and still demanded a city, so a state-wide search there emptied the
  screen on reload while the address bar still described it. A new key belongs
  in both halves or in neither.
- **`/admin/prospector` is the same `<ProspectorWorkspace>` as `/prospector`**,
  mounted in the CRM shell with `chrome="crm"` — same niches, same
  `performSearch`, same sources, and the B2B crawler on the same tab strip. Fork
  the page and the two screens start disagreeing about what a search is. What
  legitimately differs is chrome: the CRM mount links to `/admin/historico`
  rather than `/prospector/historico`, is titled by the job rather than by the
  product, and carries the CNPJ-register warning.
- **`/prospector` writes the history, `/prospector/historico` reads it.** Search
  results are persisted by `performSearch`, so any new discovery path must go
  through it or its leads never reach the history.
- **`npm run harvest` is the bulk path and it goes through `performSearch` too.**
  It only chooses which city × niche combinations to run; the moment it grows its
  own query the bulk base and the interactive one start scoring, deduping and
  niching differently, and nothing reports it. It also keeps OpenStreetMap off by
  default — the interactive search hits the shared Overpass service once, a sweep
  would hit it thousands of times — and resumes from `data/harvest.json`, which is
  why re-running a combination has to stay idempotent (it is: persistence is keyed
  on the Overture id).
- **`save: false` on a search must write nothing at all** — not the leads, not a
  partial row. `isNew` then stays undefined on every lead, which is what it means:
  the run never asked. The audit row in `prospector_searches` is still written;
  that records who used the tool, not what was kept.
- **Deleting is the only destructive path, and it shares `where()` with the table
  it deletes from.** A second, hand-written predicate in `deleteMatching` is how
  you delete more than the screen ever showed. Bulk delete is admin-only and an
  unfiltered one needs `everything: true` as well.
- **Log the deletion before running it.** `recordProspectorActivity` resolves a
  lead's name and city from the `leads` table, which no longer holds them
  afterwards — `leadNames()` exists to be read first.
- **Indexes are applied after `addMissingColumns()` in `db.ts`, not with the table.**
  `CREATE INDEX` on a column an older database lacks throws, which aborts the whole
  schema statement before the column can be added — the table then stays a
  migration behind and every search fails with "no such column".
- **Column changes need an entry in `addMissingColumns()`**, additive only. People
  are told they can keep the `.db` file, so a new column must not break it.
- **CSV columns live in `src/lib/prospector/csv.ts`**, shared by the board export
  and the history export. Don't add columns to a route handler.
- **`scripts/prospector/start.mjs` is the entry point people actually use**
  (`npm run up`, `npm run prospector`). Any new setup step belongs in its checks,
  or a fresh clone silently starts half-configured.
- **It launches Next by resolving `next/dist/bin/next`, not via `npm run dev`** —
  that keeps `--port` in one place and drops an npm process between Ctrl+C and the
  server.
- **`data/` is resolved from `process.cwd()`**, so the extract and the history
  database live in `Website/data/` and every prospector command must be run from
  `Website/` (or through the root workspace scripts). The image's `WORKDIR` is
  `/app/Website` for the same reason, and its data volume mounts there.
- **A lead's niche comes from `nicheForCategory(category)`, never from the search.**
  Storing the search's niche made the value depend on which search ran last, and
  every re-search overwrote it.
- **`niches.ts` throws at import if a category is in two niches.** That is
  deliberate — `nail_salon` sat in two for a while and silently corrupted every
  per-niche count. Don't catch it; fix the registry.
- **Regrouping existing categories needs no re-sync**; `reniche()` in `db.ts`
  rebuilds stored niches from category when `nicheFingerprint()` changes. Adding a
  category that isn't in the extract does need `npm run sync`.
- **A niche's `intent` decides which way it is qualified, and `parceiro` inverts
  everything.** The "Marketing e parcerias" family is people to work with, not to
  sell to: `performSearch` forces `onlyWithoutWebsite` off for them (an old
  `?all=` link must not be able to make a partner search return the dormant
  one-person agencies), and `scorePartner` scores having a site as the top signal
  rather than the bottom one. Don't add a `parceiro` niche without both.
- **Intent is derived from the business's own category, exactly like the niche.**
  `intentForCategory()` is what makes the CRM's WhatsApp button, the CSV export
  and the history page offer a marketing agency a partnership opener without any
  of them learning that parcerias exist. A search passes the intent explicitly on
  top of that, because a supplementary OSM/Geoapify row carries that directory's
  vocabulary and would fall back to `cliente`.
- **The outreach copy is data now, not code, and it belongs to a person.**
  `DEFAULT_BODIES` in `lib/prospector/templates.ts` is what ships; the rows in
  `outreach_templates` are what somebody wrote on `/admin/mensagens`
  (`/prospector/mensagens` outside the shell). Resolution is **your row → the
  team row (`owner_id IS NULL`) → the code**, and `activeTemplates(ownerId)` is
  the one place it is written. An empty table is a working state and deleting
  every row is the way back. Don't rewrite an opener in the source to change the
  pitch — the point of the screen is that the people sending it don't need a
  deploy, or anyone's permission.
- **Nothing an operator does on that screen reaches another person, which is why
  nothing there is gated.** Their row carries their `owner_id` and resolves for
  them alone. The single exception is `escopo: "time"` — the row everybody who
  has never opened the editor sends — and that one is admin-only, checked in the
  routes and again in `denyTeamEdit`. Only team-scoped writes are audited: a feed
  reporting every operator's wording tweak would bury the lead activity it
  exists to show.
- **`templates.ts` is pure and `templates-store.ts` opens SQLite, and the split
  is load-bearing.** `score.ts` is imported by the search board, which is a
  client component; one `node:sqlite` import anywhere in that graph breaks the
  bundle. Which is why every caller _passes_ an `OutreachContext` in — the board
  gets it from `localPanel({ viewer })`, the CRM table from the page, the CSV
  from `csvResponse(..., { viewer })` — and why a `toCrmRow` that looked it up
  itself would be one query per row. A page that forgets the viewer doesn't
  break; it quietly serves the team's copy, which is the failure to look for.
- **Six slots, audience × language, and no more — per owner.** A German machine
  shop reading English is a normal cold e-mail and one reading Portuguese is
  spam; "Munich vs Hamburg" is not worth a template. Exactly one row is active
  per `(owner_id, intent, speaks)`, enforced inside a transaction in
  `activateWithin()`, which uses `IS NOT DISTINCT FROM` — `owner_id = NULL` is
  never true, so a plain equality would leave two team rows active at once and
  make the message a lead receives depend on which one SQLite returned first.
- **"Voltar para a do time" deactivates, never deletes.** `releaseSlot()` turns
  the personal row off and lets resolution fall through. The text and the notes
  under it are the record of why it was written, and somebody who reverts on a
  Tuesday usually wants it back on Thursday.
- **A token that resolves to nothing must take its punctuation with it.** Most
  leads have no `contact_name`, so `[nome]` is empty far more often than not, and
  "Oi ! Tudo bem?" tells the reader they are one of a thousand. That is what the
  tidy pass in `render()` is for, and `templates.test.ts` pins it. An unknown
  token is left exactly as typed, on purpose: a swallowed `[negocios]` is a
  mistake the operator only hears about from the prospect.
- **`[meu-nome]` comes from the session, never from the row.** The same stored
  body is rendered by whoever opens the screen, so a message that signed itself
  with the name of the person who _wrote_ it would be worse than one that didn't
  sign itself at all. `outreachContextFor()` is what supplies it, and it supplies
  neither a name nor a personal template to a `cliente` — the portal shows a
  customer their own leads, and putting our operator's name on a message they
  send is the one outcome here that would be a real mistake.
- **The notes are the feature; the counters are there so the notes aren't
  guesses.** `outreach_template_uses` is stamped by `/history/outreach` from the
  row that is live _for that actor_ — never passed down from the button, because
  four screens render a WhatsApp link and one of them forgetting would be a
  reading that silently never happens. Don't turn those three counts into a rate:
  eleven sends is a coin toss, and this is the screen somebody would act on it.
- **The CNPJ extract is a second, separate extract and must stay that way.**
  `npm run sync:cnpj` builds `data/cnpj.parquet` from the Receita Federal's open
  register; `src/lib/prospector/cnpj.ts` queries it. Different provenance,
  different refresh cadence, different columns — merging it into
  `places.parquet` would put one script's output under another's rebuild. It
  exists because a map only holds businesses with a surveyed storefront and the
  trade we want to partner with largely has none.
- **A CNPJ row's blank `website` is "never asked", not "hasn't got one".** The
  Receita publishes no such column. `KNOWS_WEBSITE` in score.ts is what keeps
  `scorePartner` from reading the schema as a fact about the business, and the
  search's `withoutWebsite` stat excludes these rows for the same reason. This
  is the same unknown-versus-absent distinction `isNew` already makes.
- **Never take a broad CNAE whole.** `cnaes` on a niche identifies the trade and
  is taken as-is; `broadCnaes` only counts when the business's own name also
  matches `MARKETING_NAME`. Measured: `7319-0/02` is 70% of a plain CNAE
  filter's output and samples as glaziers and mechanics. Adding a code to the
  wrong list does not fail — it triples the base with junk.
- **The Receita's files are cp1252 with genuinely invalid bytes in them**, so
  DuckDB's `encoding='latin-1'` refuses whole files and the sync pipes them
  through `iconv -c`. Its download URL is a Nextcloud WebDAV share behind an
  opaque token that has already changed once; `CNPJ_SHARE_TOKEN` overrides it.
- **DuckDB's `temp_directory` in that sync points at `data/`, never `/tmp`.** On
  a normal Linux desktop /tmp is a RAM-backed tmpfs, so spilling a join there is
  not spilling at all — it is the OOM reaper killing the process with no message.
  The same reason the sync writes its downloads under `data/`.
- **`--parts 1` builds a deliberately partial extract for testing**, and records
  `partial: true` in `data/cnpj.json` so it cannot later be mistaken for a real
  one. Don't prospect from it. It limits Estabelecimentos only: the ten parts of
  Estabelecimentos and of Empresas are partitioned _independently_, so pairing
  part N with part N drops 98% of the rows on the razão social join — 24.213 in,
  409 out — and looks like a broken filter rather than a broken sample.
- **A CNPJ row's phone is pre-2016 and must never be "fixed" by prepending a 9.**
  6.350 of 6.357 are ten national digits, captured at registration; a third of
  them were mobiles before the nine-digit migration. Recovering those is a guess
  about a specific number, and a wrong one opens a stranger's WhatsApp with a
  partnership pitch — the exact failure `normalisePhone` is written to prevent.
  E-mail is the channel for these rows, and the search says so.
- **Three DuckDB keywords bite in this pipeline: `source`, `rows` and `matched`.** Unquoted,
  each is a parser error rather than a column, and the `rows` one fires in the
  stats query _after_ the extract is written — a sync that succeeded reporting
  itself as failed.
- **Never build a shell command string around a Receita filename.** Several are
  named `F.K03200$Z.D60808.…`, and `$Z` inside a double-quoted shell word
  expands to nothing — the redirect then writes an empty file from a path that
  does not exist, and the failure surfaces three steps later as "conversão
  vazia". `iconv` is spawned with an argv and an opened descriptor for exactly
  this reason. `iconv -c` also exits non-zero whenever it drops a character,
  which here is always, so its status is ignored and the output is validated
  instead (a complete CSV ends in a newline).
- **`web_designer` must stay out of the niche registry.** It is a competitor, not
  a partner and not a prospect; putting it in "Marketing e parcerias" fills a
  partner search with agencies selling the one thing Mandra sells.

# Prospector B2B specifics

- **`/prospector/b2b` is nested under `/prospector` on purpose.** That is how it
  inherits the `data-prospector` tone block, the `noindex`, and the
  `Disallow: /prospector` in robots.ts without any of them learning about a second
  tool. Moving it to its own root means repeating all three.
- **The two tools are one screen, and the tab is state — never a navigation.**
  `ProspectorWorkspace` is mounted by four routes — `/prospector`,
  `/prospector/b2b`, `/admin/prospector`, `/admin/prospector/b2b` — differing
  only in `initialTool` and `chrome`, so every URL still works as a deep link
  while switching inside the tool changes no URL and reloads nothing. Both panels stay mounted and the inactive one is hidden with a
  class: a `{tool === "b2b" && <B2b/>}` reads better and unmounts a crawl that is
  minutes long and streaming NDJSON into React state, which is the bug this
  replaced.
- **`chrome` is what keeps the CRM mount from being a fork.** `crm` and `tool`
  differ in exactly three things — the page's gutters, the header's typography,
  and whether "histórico" points at `/admin/historico` or
  `/prospector/historico`. The sidebar's B2B entry used to link at
  `/prospector/b2b`, which left the shell for the dark standalone tree: the same
  tool wearing a different page, reached by a full navigation, with the sidebar
  and every other CRM affordance gone. A second copy of the workspace for the
  CRM is how the two would start disagreeing about what the tool says.
- **Both panels' props come from `app/prospector/panels.ts`, never assembled per
  page.** Same rule as `parseFilters()` and the CSV column lists: two pages
  building them by hand is how one grows a counter or a warning banner the other
  never learns about, and both render fine while disagreeing about what the tool
  says. Everything in there is a local read (SQLite counters, the city index, an
  `existsSync`), which is what makes the second panel affordable on both routes.
- **`b2bPanel()` returns null without the `b2b` grant and the tab disappears.**
  A tab that 403s is worse than a tab that isn't there — same courtesy as
  `canExport` and the `/operador` tile; the routes stay the control.
- **Its page must keep `export const dynamic = "force-dynamic"`.** It takes no
  searchParams, so Next otherwise prerenders it — baking the company counters and
  the "extract present?" check into the build (the tool then reports zero forever)
  and touching `data/`, which only exists at runtime.
- **Two extracts and two databases, never merged.** `b2b-companies.parquet` keeps
  _only_ records that have a website and is built for the B2B categories;
  `places.parquet` is the prospector's and keeps the ones that don't. Both are
  multi-country now, which makes them easier to confuse, not harder.
  `data/b2b.db` is separate from `prospector.db` because the schemas are unrelated
  and the prospector's file rewrites every row's niche when it opens.
- **`sectors.ts` follows the same two rules as `niches.ts`** — categories copied
  from `overture-categories.csv`, never invented, and one category per sector
  (it throws at import otherwise). `sync-b2b.mjs` re-checks the whole list against
  that CSV before starting a 20-minute download, and `sectors.test.ts` checks it
  before the commit: the sync only _warns_, and it warns after you have already
  decided to spend twenty minutes on Parquet.
- **`ticket` is 1–5 and centred on 3 in `score.ts`.** The registry spans a print
  shop and a hospital group, so the prior is the widest band in the score (±10).
  It is still only a tiebreak — a company with no reachable address is not a lead
  at any deal size, which is why `contato` dominates. A sector at 4 or 5 says so
  on the row (`setor de ticket alto`), or the ordering is a number to take on
  faith.
- **A campaign with `minTicket` derives its members, and that is on purpose.** A
  copied list of sector slugs stops meaning what the label says the moment a
  ticket is retuned; "Ticket máximo" has to follow the registry, not shadow it.
- **The extract manifest records `categoryList`, not only a count.** A sector
  added after the Parquet was built matches nothing, and "no companies" is
  indistinguishable from "no chemical plants in Portugal" — the worst bug class
  in this tool, restated. `uncoveredSectors()` reads that list so the picker can
  mark the profiles the current file cannot answer for; an extract predating the
  field reports `extractCoverageUnknown()` rather than guessing coverage in
  either direction.
- **`fold()` and `nrm()` both live in `src/lib/b2b/overture.ts`** for the same
  reason the prospector's twins must agree: the JS one folds the typed city, the
  SQL one folds the column. They are in one file so they cannot drift.
- **`isNew` is computed from `knownDomains(false)` before the crawl starts.**
  Persistence happens once at the end, so asking afterwards marks every row new.
  `knownDomains(true)` — only domains that produced an address — is the separate
  question "should this run skip it?".
- **Everything the client posts to `/enrich` is rebuilt, not trusted.** Each
  candidate's website goes back through `normaliseWebsite()`, which is what
  rejects `localhost`, private ranges and non-HTTP schemes; the sector is
  re-derived from the category. Without that the route is an SSRF primitive, since
  the seed list is a textarea.
- **The enrich route streams NDJSON, so failures after the first byte must be
  in-band** (`{type:"error"}`). The status line is already gone; returning an
  HTTP error code at that point is not possible.
- **Keep the crawler's ceilings** (8 pages, 35s/site, 12s/request, 2MB/response,
  depth 2). They are what make 200 companies a coffee break; an industrial site
  has 30.000 catalogue pages and none of them hold an address.
- **Concurrency is across companies, never within one**, plus a per-host delay.
  Eight requests into one small plant's server is how the tool gets blocked.
- **Don't add Playwright.** ~300MB on an image that already ships Next + DuckDB,
  to recover the minority of sites whose contact page is client-rendered. A site
  we can't read is reported as reached-with-nothing, which is the honest answer.
- **Don't loosen the postcode regex in `extract/company.ts`.** A four-digit number
  followed by a capitalised word is also "© 1997-2026 SPI" and "12025 Waterfront
  Drive"; the street match is the anchor and ambiguous codes are only believed
  within 160 characters of it.
- **Cloudflare's e-mail decode must stay restricted to printable ASCII.** XOR will
  "decode" any hex blob into something, and without the check a stray one becomes
  a plausible address that was never on the site.
- **CSV columns live in `src/lib/b2b/csv.ts`**, shared by the board export and the
  history export. Same rule, same reason as the prospector's.
- **Editing `src/lib/b2b/db.ts` while the dev server is running can leave
  Turbopack unable to load `node:sqlite`** ("Failed to load external module
  node:sqlite: require is not defined") on the API routes, while pages using the
  same module keep working. It is an HMR artefact — restart the dev server rather
  than rearranging the imports.

# Admin CRM specifics

- **`/admin` reads and writes the prospector's SQLite history — there is no second
  store.** A search fills the CRM by running, which is the whole reason the tool
  and the CRM share `data/prospector.db`. New pipeline fields go in
  `addMissingColumns()` in `src/lib/prospector/db.ts` like any other column.
- **The shell lives in `admin/(crm)/layout.tsx`, not `admin/layout.tsx`.** The
  route group exists so `/admin/login` — which renders before there is a session
  to hang a sidebar on — stays outside it. `admin/layout.tsx` is metadata only.
- **`[data-admin]` and `[data-admin-shell]` are tone blocks**, same mechanism as
  `[data-prospector]`: the sidebar's `bg-surface` and the table's `bg-surface` are
  one utility resolving against different tokens. They also remap `--color-brand`
  to amber, darker on the paper tone than on the charcoal one because #f3a33a
  only reaches 2.4:1 on white. Don't reach for a hex in an admin component.
- **The sidebar lists only views that exist.** Routing an unbuilt section back to
  `/admin` reads as a broken link, not as a roadmap.
- **The whole view is in the query string** — filters, sort, page and page size —
  parsed by the shared `parseFilters()` and rebuilt by `filtersToQuery()`. A
  second, page-local parser was what let `/admin` read `noSite` while the rest of
  the app wrote `nosite`, so the toggle silently did nothing.
- **The filter form must not contain a `page` field**, or applying a filter keeps
  you on a page number that the new result set may not have.
- **Both `queryHistory` and `allMatching` select `SELECT_COLUMNS`.** When the
  lists were written out twice, `notes` reached the CRM table and not the CSV.
- **"Today" counters compare `date(col, 'localtime')` on both sides.** The
  timestamps are UTC and the working day is the operator's; reading `first_seen_at`
  as a plain prefix counts an evening lead as tomorrow's, so the metric row resets
  in the middle of the afternoon.
- **`LeadTable` is one client component for the whole tbody**, because selection,
  row expansion and the bulk bar are state that spans rows. The page stays a
  server component and passes flattened rows — the niche registry and the scoring
  module never reach the browser.
- **Optimistic edits roll back the row's whole override entry, not one key.** Each
  mutation refreshes the route afterwards, and the arriving server data drops the
  optimistic values it has caught up with.

# Watching the operators

- **`/admin/uso-prospector` answers "did they use it", the `[id]` page answers "did
  it come to anything".** They are kept apart because they disagree more often than
  you would like: fifty searches and nothing contacted is a real week, and a
  usage-only screen reports it as a good one.
- **Outcome metrics attribute by _touch_, not ownership.** `operatorOutcomes()`
  joins `prospector_activity` back to `leads`, so a lead counts for everyone who
  acted on it and the per-person columns do **not** sum to the pipeline. The table
  says so in its subtitle — remove that note and the numbers start reading as a
  total that doesn't add up. `leads.owner_id` exists now (see "Exclusividade de
  atendimento") and is deliberately **not** what these metrics read: it says who
  may contact the business, not who did the work on it.
- **Whether a follow-up is overdue is decided in SQL, never recomputed in the page.**
  `OPERATOR_LEAD_SELECT` returns `follow_up_overdue`, folded with
  `date('now','localtime')` — the same fold as the counter above the list. A page
  that asked JavaScript would answer in the renderer's timezone and disagree with
  its own headline by a day on any container that isn't on Brasília time.
- **The audit's view is in the query string, parsed once by
  `parseActivityFilters()`** — by the page and by its CSV route both, for the same
  reason `parseFilters()` is shared by the lead views. And its filter form carries no
  `pagina` field, or applying a filter lands on a page the new result set may not have.
- **`knownActors()` unions searches and activity.** An operator who only ever worked
  leads someone else found has no row in `prospector_searches`, and reading the actor
  list from that table alone made their whole history unreachable from the filter.
- **Deleted accounts stay visible.** `accountDirectory()` keeps actors that exist
  only in the audit, and `/admin/uso-prospector/[id]` resolves them. The audit
  outlives the row on purpose; a 404 there would make the history look like it never
  happened.

# Access control

- **Two kinds of account, in two places on purpose.** The administrator is
  `MANDRA_ADMIN_USER` / `MANDRA_ADMIN_PASSWORD` and has no database row — it must
  exist before the database does, and the account that grants access should not be
  creatable by a write to the thing it grants access to. Everyone else is a row in
  `users` (`src/lib/auth/users.ts`), created and revoked at `/admin/usuarios`.
- **The proxy is an optimistic check, never the boundary.** `src/proxy.ts`
  verifies the cookie's HMAC and expiry and nothing else — no database, per Next's
  own guidance. `requireUser()` / `requireAdmin()` in `src/lib/auth/server.ts` is
  what actually decides, and every protected page and route calls one. A revoked
  operator still holds a validly signed cookie; the proxy lets them past and the
  page does not.
- **Repeat the check in each route.** They look redundant next to the matcher, and
  that is the point: a matcher edit or a route that moves must not be able to
  silently open an endpoint. The same applies to layouts — `(crm)/layout.tsx` calls
  `requireUser()` for the identity chip, but a layout doesn't re-run on client
  navigations, so pages check for themselves.
- **A redirect from the proxy must be built with `NextResponse.redirect()` and an
  absolute URL.** Next parses the `Location` of a proxy response itself, and a
  relative one throws `ERR_INVALID_URL` _inside_ the proxy — which surfaces as a
  500 on every protected page while the API routes, which answer with JSON
  instead of a redirect, keep working. Clone `request.nextUrl`; Next strips the
  origin again on the way out, so the browser still gets `location: /admin/login…`
  and keeps the host it arrived on. Route handlers are not affected and may set a
  relative `Location` directly.
- **The session cookie's `Secure` flag follows the transport, not `NODE_ENV`.**
  A production build reached over plain HTTP — the VPS by IP and port, before a
  domain and a certificate are in front of it — sets a `Secure` cookie the browser
  silently drops, and the login bounces back to the form with nothing to explain
  why. `isSecureRequest()` reads `x-forwarded-proto` first, because behind a TLS
  terminator Next only ever sees HTTP.
- **`lib/auth/session.ts` uses Web Crypto, not `node:crypto`**, so the same module
  runs in the proxy, in route handlers, and on a host that runs proxies at the edge.
  `users.ts` is the Node-only half (scrypt, SQLite) and must not be imported from
  the proxy.
- **Revoking and resetting a password bump `sessions_valid_from`.** Without it
  "revoke" would only mean "can't log in again", and someone already inside would
  stay inside for the rest of their eight-hour session.
- **`authenticate()` hashes even when the username doesn't exist.** A fast "no such
  user" and a slow "wrong password" is an account enumeration oracle.
- **The prospector is behind the same login as the CRM.** They share one database;
  an ungated lead tool is an ungated export of it. That is also why the session
  cookie's path is `/` — scoped to `/admin` it never reaches `/api/prospector/*`.
- **Permissions live on the user row, never in the cookie.** `Permission` is
  declared in `session.ts` but stored in `users.permissions` and re-read by
  `currentUser()` on every request, exactly like `active`. A grant baked into a
  signed token could not be taken back until it expired, which is the one thing
  these exist to do — the admin revokes "Exportar CSV" and it stops working on the
  operator's next click, with no sign-out.
- **The admin is not on the permission list and must not be added to it.** It holds
  all of them by definition (see `currentUser`), so a permission added to
  `PERMISSIONS` is automatically on for the administrator and deny-by-default for
  every operator, with no migration and no chance of locking the admin out.
- **`DEFAULT_PERMISSIONS` omits `export` on purpose.** A CSV of the history is the
  whole lead base in one file; an account that can take it on the way out is a
  different kind of account from one that works leads in the CRM. New operators get
  B2B and nothing else, and the migration in `users.ts` hands existing operators the
  same grant — that is the change, not an accident of migration order.
- **`denyWithout()` in each route is the control; a hidden button is courtesy.**
  Both CSV exports, all three B2B routes and `/prospector/b2b` check for themselves.
  The `canExport` props on `Prospector` and `B2b` only stop the tool offering
  something that would 403.
- **The audit's own CSV (`/api/admin/activity/export`) is admin-only and is _not_
  behind `export`.** That grant is about letting leads out of the building; this is
  the record of who did what, and an operator holding one must not get the other.
- **`users` has its own `addMissingColumns()`**, same rule and same reason as the
  one in `lib/prospector/db.ts`: the DDL is `CREATE TABLE IF NOT EXISTS`, so an
  existing file never sees a new column and a login turns into a 500. Additive only.
- **Signing out and revoking are different actions.** `revokeSessions()` bumps
  `sessions_valid_from` alone; `setActive(false)` bumps it _and_ clears `active`.
  Achieving the first by revoking and reactivating leaves a lie in the account's
  state. Changing permissions deliberately ends no sessions — they are already live.

# Fechado e perdido

- **`CLOSED_STAGES` is derived from `STAGE_STATUS`, never written out.** Same
  rule as `REACHED_LIST`: a stage added to the funnel and forgotten in a
  hand-written list would quietly re-enter the calling queue, and a won customer
  being cold-pitched again reports itself as nothing at all.
- **Both list builders exclude them, and they read the same constant.**
  `dailyCandidates` always did; `createCallList` did not, so a list built from a
  CRM filter walked straight past that rule and handed an operator a customer to
  cold-pitch or a business that had already said no. `CLOSED_STAGES_SQL` in
  calls.ts is the one interpolated form — safe, since the values come from our
  own union type and never from a request.
- **The route's `excluded` count already covers it.** It is the difference
  between what was asked for and `list.total`, and it exists precisely so a
  silently shrunk list is impossible; closed leads join phoneless and owned ones
  under the same honest number.
- **The dialer still warns, because an old list can hold one.** Lists built
  before this rule are still pending, so `CallCard.closedStage` is resolved
  server-side and the session shows it above the dial button.
- **Nothing blocks the contact.** Phoning a customer back, or a lost lead with a
  new reason, is a real thing to do — it must just never happen by working down
  a queue on autopilot. `ownership.ts` remains the only thing that refuses.

# Já contatado

- **Every contact button says whether the business has already been contacted,
  and it reads `contacted_at` to say it.** The four places are the live search,
  `/prospector/historico`, the CRM table (three layouts) and the dialer. Adding
  a fifth WhatsApp or `tel:` link without the mark is how a prospect gets cold-
  called twice by two people, which is the one mistake they always notice. The
  same component carries the closed/lost warning and lets it supersede this one:
  a lead cannot reach a closed stage without having been contacted, so showing
  both spends two lines of a dense table on one fact.
- **It is not `isNew` and it is not the funnel stage.** `isNew` says we had never
  _seen_ the business before this search — one found six months ago and never
  phoned is neither new nor contacted. The stage is no better: a lead can sit in
  `descoberta` after a conversation, and one in `contato feito` may have got
  there from somebody opening WhatsApp yesterday. `contacted_at` is the only
  field that means an outreach actually happened.
- **`contactHistoryFor()` returns only contacted leads, and is Atlas-scoped.**
  Absence is the answer for everything else, so decorating 200 search results
  carries three entries rather than 200 and "no row" cannot be read as "a row
  saying nothing happened". The scope is not a precaution: our screens must not
  be told what a client did with their own pipeline.
- **The search reads it even when `save` is off.** Not writing the history is a
  reason to leave it alone, never a reason to stop reading it — an exploratory
  search that offers an un-warned WhatsApp button to a business a colleague
  phoned on Tuesday is exactly the failure the mark exists to prevent.
- **It is a warning, never a block.** Re-contacting is often right — a follow-up,
  a callback, a number that never answered — so the buttons stay live.
  `ownership.ts` is what actually refuses a contact, and it renders separately;
  a mark that blocked would duplicate that rule badly and in the wrong place.
- **The dialer's "primeira tentativa" reads `lead_calls`, which is why it also
  needs `contactedAt`.** A lead messaged from the prospector has a
  `contacted_at` and no call row, and the history panel confidently told the
  operator they were the first person to make contact.

# The funnel

- **`funnel_stage` and `status` are two questions, kept from contradicting each
  other.** `status` is what happened to the outreach and the prospector's board
  still reads it; `funnel_stage` is how far the deal has come and is what the CRM
  edits. `setFunnelStage()` writes both; `setStatus()` writes the stage too, but
  only when the current one doesn't already imply that status — otherwise
  re-marking "respondeu" would drag a lead back from "negociação" to "qualificado".
- **`STAGE_STATUS` in types.ts is the single mapping.** The client mirrors it for
  the optimistic update; if it ever disagrees with the server the row will flicker
  to the wrong stage and back.
- **The funnel chips are rendered in `FUNNEL_STAGES` order with every stage shown,
  even at zero.** Sorting by count turns a funnel into a bar chart, and hiding the
  empty stages hides the gap you were looking for.
- **`socials` is one JSON column, not a column per network.** The set of networks
  that matter changes faster than the schema should, and `parseSocials()` degrades
  an unreadable value to an empty list rather than taking the page down — people
  are told they can keep the `.db` file, so someone will edit it by hand.
- **Every social URL is re-parsed server-side** in `api/prospector/history/details`.
  They become `href`s an operator clicks all day, and the textarea they came from
  accepts `javascript:` just as happily as `https:`.

# Cold calling

- **A call is an event, not a column.** `lead_calls` holds one row per dial, and
  the questions worth asking of cold calling — dials per contact, which operator
  converts, which niche answers the phone — are questions about attempts. A
  `last_call_outcome` column on `leads` was the obvious shape and can only ever
  answer the last one.
- **The queue's position is in SQLite, not in the browser.** `call_list_items.state`
  is what makes a session resumable the next morning, on another machine, by
  another person. A client-side cursor breaks that and looks fine in testing. It
  is _not_ what stops two operators being handed the same business — a position
  is only `concluido` after the call, and the window before that is exactly when
  the double-dial happens. `ownership.ts` is what closes it.
- **`recordCall()` is the only writer that closes a call**, and it does the four
  writes in one transaction: the log row, the queue position, the lead's
  stage/status pair, and the follow-up date. Split them and you get a lead marked
  "sem interesse" still pending in the queue, or a closed deal still due Friday.
- **`stageAfterCall()` never moves a lead backwards** — except for the terminal
  outcomes, which always apply. A lead in `negociacao` that doesn't pick up the
  phone has not regressed to "contato feito"; a lead in `proposta` that says no
  has genuinely become `perdido`. `STAGE_RANK` is what encodes that, and it is
  deliberately not the index in `FUNNEL_STAGES`: `perdido` sits last there and is
  not "further along" than anything.
- **The outcome and the next step are two questions.** The outcome is what
  happened (`CallOutcome`); the next step is what the operator decided to do about
  it (`NextStep`), and it can carry the lead further than the outcome would —
  "interessado" argues for `qualificado`, but deciding on the call to send a
  proposal is the stronger signal. Both propose a stage; the later one wins.
- **`followUpAt` has three meanings and the route preserves all three.** Absent is
  "use the next step's default", `null` is "no follow-up at all", a date is that
  date. Collapsing the first two is how an agreed callback silently disappears.
- **The funnel board's queries take a `LeadScope` and never default it.**
  `funnel.ts` reads `leads` directly instead of going through `queryHistory`,
  which is precisely the query shape that leaks one account's pipeline onto
  another's board. The scope is a required argument so the compiler catches a
  caller that forgets, and `/admin/funil` pins it to `SCOPE_ATLAS` rather than
  reading it from the query string — a board re-pointable by URL edit is the
  leak the scope exists to close.
- **`callsToday` / `callsTodayTotal` are NOT scoped yet.** `lead_calls` has no
  `account_id`, so the daily counter counts every account's dials. Fine while
  Atlas is the only caller; revisit when a client can log calls of their own.
- **The board's column totals never come from the card list.** Cards are capped
  at `BOARD_COLUMN_LIMIT`; counting them would report the cap as the size of the
  stage, and `descoberta` alone holds ~395k leads.
- **Outcome colour encodes reached-vs-not, not the outcome.** Seven hues for
  seven outcomes would be noise, and valence colouring is worse: `sem_interesse`
  is a _reached_ call, so painting it the green of `fechado` would call a
  rejection a win. Colour carries "did a human pick up"; the text carries what
  they said. The pair (`#a85f09` / `#7d8792`) is validated against the `#fdfbf7`
  surface — ΔE 14.4 deutan, 15.9 normal, both marks over 3:1 — not eyeballed.
- **The card carries the CRM note, and posts it to the CRM's route.** The note
  is what a card is actually missing when you come back to it — "pediu para
  chamar em janeiro" is the reason the lead is where it is, and reading it used
  to mean leaving the board for the table. It collapses to two clamped lines and
  saves on blur, the same contract as `NoteEditor`; the write goes to
  `/api/prospector/history/notes`, so `setNotes` stays the single writer and the
  note gets the same audit row wherever it was typed.
- **A card stops being draggable while any of its controls is open** — the stage
  menu and the note editor both. Dragging through a textarea has to select text,
  not move the lead.
- **Drag-and-drop is never the only way to move a card.** It is unreachable by
  keyboard and invisible to a screen reader, so every card also carries an
  explicit stage menu. The board writes through
  `/api/prospector/history/details`, so `setFunnelStage` stays the single writer.
- **That menu is buttons, and must not go back to being a `<select>`.** A native
  select inside a `draggable` ancestor is half the browser's: the press that
  opens the popup also starts a drag, and the release lands on whatever option
  is under the cursor — so opening the dropdown moved the lead, usually several
  stages along. A wheel tick over a focused select does the same with no popup
  at all. Both wrote a stage nobody chose, which here means announcing a lead as
  "em negociação" that never was. The card also stops being draggable while the
  menu is open, and the menu expands inline rather than floating: the columns
  live in a horizontal scroller that clips an absolutely positioned popup.
- **The board's search is a SQL predicate, never a filter over the rendered
  cards.** Columns are capped at `BOARD_COLUMN_LIMIT`, so filtering what is on
  screen searches forty leads per stage and then reports confidently that the
  lead is not in the funnel. `searchClause()` narrows the card query _and_ the
  totals query — a header still counting the whole stage under a filtered column
  reads as "the rest are hidden by the cap", which is a worse lie than the cap.
  The call-result stats above the board are deliberately not narrowed: they
  answer what comes back when we dial, which is a question about the operation.
- **The daily counter is scoped by the page, not by the component.**
  `callsToday()` / `callsTodayTotal()` take an optional actor and `CallsToday`
  renders whatever it is handed; `/operador` passes its own `user.id` and `/admin`
  passes nothing. Putting the "operators see themselves, the admin sees everyone"
  rule in the component would make it a reusable way to leak the whole team's
  numbers into an operator's screen.
- **The dashboard's call counter is deliberately _not_ filter-scoped**, unlike
  every other number on that page. "How much calling happened today" is a
  question about the day; answering it through the filter bar would make the
  team's output change when somebody ticks a niche.
- **The team target is per account that could dial, never per account that has.**
  `DEFAULT_DAILY_TARGET × countActive()`. Deriving it from `callsToday().length`
  grows the denominator through the morning, so the bar slides backwards each
  time another operator starts — the one thing a progress bar must not do.
- **`callsToday` is its own query, not `callStats`.** `callStats` groups every
  call ever logged by outcome; asking it about one day scans the whole log twice
  on a base that grows by 500 calls a week. `lead_calls_actor_time` serves the
  daily one directly.
- **`REACHED_SQL` is derived from `OUTCOME_REACHED`**, unlike the older
  hardcoded outcome lists around it. The counter is a number people are measured
  by, and a new outcome missing from a hand-written list would deflate everyone's
  day silently instead of failing.
- **Skipping is not an outcome.** `/api/prospector/calls/skip` writes no call row,
  no stage, no `contacted_at` and no audit event — nothing was dialled. Storing a
  skip as "não atendeu" inflates every attempt statistic the log exists to answer
  and marks as contacted a business nobody has phoned.
- **A list only takes leads with a phone**, filtered in `createCallList`'s own
  query. A queue position nobody can dial is one the operator skips past every
  time they reach it. The route reports the difference between what was asked for
  and `list.total` rather than shrinking the list quietly.
- **A list is normally created from the CRM, not from the Ligações screen.**
  `CreateCallListButton` sits in the `/admin` header (carrying the filter on
  screen) and in the bulk bar (carrying the ticked rows), and drops you straight
  into the queue — building a list is never the goal, calling is. The query-string
  box on `/admin/ligacoes` is the hand-typed fallback; don't make it the headline.
- **Lists are built from the filter server-side, never from ids the client holds.**
  `/api/prospector/calls/lists` re-runs `parseFilters` + `allMatching`, for the
  same reason the CSV export does: posting the loaded rows caps the list at
  whatever page size happened to be on screen.
- **The session page holds no cursor.** It renders `nextInList()` and the client
  calls `router.refresh()`; the form is reset by keying `<CallSession>` on the
  lead id, not by an effect. The draft note must survive a refresh that returns
  the same lead and must not survive one that returns a different lead.
- **Deleting a lead cascades its queue positions away**, which is why
  `call_list_items` has `ON DELETE CASCADE` on both sides and why `CallList.pending`
  is derived rather than stored — a stored counter keeps counting work that is gone.

# Phone quality and the automatic queue

- **`phone_norm` is what makes shared numbers visible.** The raw `phone` column
  keeps whatever the source wrote, so `(31) 98791-1222` and `+55 31 98791 1222`
  are two strings and one line. Folding on write (and backfilling on open, like
  `search_norm`) is what lets `phone-quality.ts` count how many businesses list
  the same number.
- **A number listed by `MAX_SHARED_PHONE` businesses is treated as not theirs.**
  This is the answer to "sometimes the lead phone does not correlate to the
  business": no directory has a field for it, but a switchboard reveals itself by
  appearing on forty records. Two businesses sharing a line stay callable with a
  warning — a real second branch is common, and excluding it throws away leads.
- **`numero_invalido` kills the number, not just the lead.** Matched on
  `phone_norm`, so one operator finding a dead line protects every other lead
  carrying it — which, for the reason above, is often several.
- **The rules exist in two shapes and a test keeps them identical.**
  `GOOD_PHONE_SQL` is correlated so it composes into the CRM filter's WHERE;
  `PHONE_QUALITY_CTE` + `GOOD_PHONE_CTE_SQL` answer the same question in one pass
  for the whole-table queries. The correlated form re-counted every shared number
  once per row and took 2,2s to summarise 50.000 leads; the CTE form does 200.000
  in ~0,5s. `daily.test.ts` asserts both select exactly the same ids — without it
  there are simply two definitions of "telefone confiável".
- **A due follow-up outranks any score** in `QUEUE_ORDER_SQL`, and a follow-up set
  for _next week_ excludes the lead entirely. That date was a promise made on a
  call; a queue that pre-empts it phones people four days early, and one that
  ignores it is worse than no queue.
- **Three separate reasons a lead is unavailable, and they are not the same.**
  Already pending in someone's queue, dialled past `MAX_UNANSWERED_ATTEMPTS`, or
  called inside `RECALL_COOLDOWN_DAYS` with nothing scheduled. Collapsing them
  is how the daily list hands back the same unanswered numbers every morning.
- **`dailyList` is idempotent per operator per day**, keyed on the actor and a
  date-stamped name. The button _will_ be pressed twice — a refresh, a second tab,
  back from lunch — and a second hundred leads handed out while the first eighty
  are pending is a day's work doubled silently.
- **Top up, don't rebuild.** `topUpList` appends after the last position with
  `INSERT OR IGNORE`, so the order being worked is untouched and a lead already in
  that list is never re-queued. Building a fresh list instead scatters one
  campaign across a week of counters.
- **The pool counters on `/admin/ligacoes` are load-bearing, not decoration.**
  "Prontos para ligar agora" against the excluded totals is what tells an operator
  whether today's job is calling or prospecting — a 100-a-day operation runs out
  of base long before it runs out of day, and finding that out at 9am on Thursday
  is finding it out too late.

# Exclusividade de atendimento

- **`ownership.ts` answers two questions and they are not the same.** A _claim_
  (`lead_claims`) is "somebody is dialling this right now" — short, renewed by the
  open dialer, expiring on its own. _Ownership_ (`leads.owner_id`) is "this
  relationship belongs to whoever contacted them first" — permanent, stamped by
  the first logged call or outreach. Collapsing them gives you either a lock a
  closed laptop holds forever, or no protection at all during the one window that
  matters.
- **The claim is the `INSERT .. ON CONFLICT DO UPDATE`, not a read then a write.**
  Two dialers _will_ render the same next position — the queue is read before
  either writes — so the conflict clause is what decides between them. Checking
  first is the same code with the race left in.
- **Claims expire and are swept lazily.** Every predicate already ignores an
  expired row, so `sweepClaims()` is housekeeping and nothing depends on it
  running. A release that must arrive is a release a crashed tab never sends.
- **Ownership is never backfilled.** `addMissingColumns()` adds the three columns
  empty on purpose: deriving an owner from the call log would lock every lead in
  the history to whoever last dialled it, including people who have left.
- **`blockFor()` is called by the writer, not only by the route.** The route
  produces the good error message; the writer is what makes the rule true, and
  `recordCall` returns a refusal (`isRefusal()`) rather than logging the call.
- **The screen has to stop the click, not just refuse the log.** A 409 on
  `/history/outreach` does nothing about the WhatsApp tab that already opened with
  a message to a business a colleague is negotiating with. `toCrmRow` resolves
  `blockedBy` server-side and the contact controls render inert; the route is
  still the control.
- **The queue steps over blocked positions, it never deletes them.** A block can
  lapse, and the position has to survive it. `blockedInList()` is the honest
  counterpart — without it "80 na fila" over an empty dialer reads as a bug and
  the operator rebuilds a queue they did not need.
- **Admins are exempt, and `callActor()` is the only place that is decided.** The
  exemption restated per route is an exemption half-applied. `releaseOwnership`
  (admin-only, audited as `atendimento`) is the escape hatch the permanent half
  needs — without it the first contact is an irreversible decision made by one
  click.
- **`dailyCandidates()` without an actor is a preview, with one it is a build.**
  The no-actor form counts the whole pool for the "there is more work" button; a
  build must never draw a lead that belongs to somebody else.

# Audiences for ads

- **The seed is defined by the call log, not only by the funnel.** "Interessados"
  and "perdidos" ask `lead_calls`; a lead that was interested on the phone and
  later went cold has moved on in the funnel but is still exactly the business the
  ads should be finding more of. The stage-based seeds ask the other question.
- **Nothing here fails loudly.** A wrongly normalised phone or a field hashed that
  the platform wanted in the clear produces a file that uploads cleanly and matches
  nobody, and the only symptom is a lookalike that quietly underperforms for a
  month. `audience.test.ts` pins the digests; do not "simplify" the two row
  builders into one shared one.
- **Meta hashes every column; Google wants `Country` in the clear.** That
  asymmetry is the single easiest thing to get wrong.
- **An empty field stays empty — never the hash of an empty string.** A column of
  `e3b0c442…` is a column of identical fake identities, and both platforms score
  the upload down for it.
- **The hashed files carry no BOM** (`textCsvResponse`'s `bom: false`). The
  platforms' uploaders read it as part of the first header name, so `email`
  arrives unrecognised and the whole upload matches on nothing. Excel's BOM is
  right for every file a _person_ opens, which is why the plain CSV keeps it.
- **Rows with neither a phone nor an e-mail are dropped**, and the screen says how
  many. Padding the file with unmatchable rows reports as a worse audience than
  the same leads without them.
- **The ads export is behind the `export` permission**, like the history CSV. The
  hashing is what the platforms require of the upload, not a privacy control — a
  SHA-256 of a phone number is trivially reversible by anyone holding a list of
  phone numbers, which is precisely what an ad platform is.

# Lead intake from customer sites

- **`/api/v1/leads` is one of exactly two routes that answer without a session**
  (the other is `/api/v1/analytics`), and it is under `/api/v1/` precisely so it
  falls outside the matcher in `src/proxy.ts`. Moving it under `/api/prospector` or `/api/admin` would mean the
  gate grows an exception, which is the kind of edit that quietly opens the
  others. The `v1` is also a promise: sites we shipped depend on this path and it
  cannot be renamed the way an internal route can.
- **The site key is public and is stored in the clear.** It ships in the page
  source of a customer's website — hashing it would be theatre that only makes it
  impossible to show a customer their own key again. The origin allowlist and the
  rate limit are what actually bound the endpoint; the key only says _which_ site
  a submission claims to be from.
- **The origin allowlist stops another website, never curl.** A browser sends
  `Origin` on a cross-origin POST, so a wrong one is refused; an absent one is
  allowed, because refusing it breaks server-side integrations and stops nothing
  (curl can send any `Origin` it likes). Don't "harden" this by rejecting the
  absent case — it buys nothing and breaks the legitimate caller.
- **`normaliseOrigin()` must not be reduced to `new URL()`.** WHATWG URL parses
  `https://lixo!!` and reports `lixo!!` as the hostname, so a typo'd domain would
  store, would never match a real `Origin`, and would read as configured on the
  admin screen while the customer's form silently 403s. `HOSTNAME` is the check
  that catches it; the credentials and single-label rejections are there for the
  same reason.
- **An intake site must have at least one origin.** An empty allowlist would have
  to mean "allow everything" or "allow nothing", and both are bad defaults for an
  endpoint that writes to a lead base — one fills a customer's pipeline with junk,
  the other ships a site whose form silently fails.
- **List `www` and the apex separately.** The browser sends the exact origin it is
  on; a site answering on both with only one allowlisted has a form that works for
  half its visitors, and nothing anywhere reports it.
- **Intake does not go through `persistLeads()`, on purpose.** That writer
  overwrites every column on conflict, which is right for a re-run search and
  wrong for a person filling in a form twice — it would clobber the notes, the
  funnel stage and the tags an operator has already put on the lead.
  `submitLead()` upserts only the contact fields, appends to `notes`, and never
  touches `status`, `funnel_stage`, `tags` or `next_follow_up_at`. Any new
  pipeline column belongs on that same do-not-touch list.
- **The dedupe key is `web:<siteId>:<sha256(email or phone)>`**, and the phone is
  folded through `normalisePhone()` before hashing — otherwise "31 99999-8888" and
  "+5531999998888" become two leads for one person. A submission with neither gets
  a fresh UUID, which is the honest answer: there is nothing to recognise them by.
- **A follow-up submission that omits the company must not erase it from the
  name.** The company has no column of its own (inventing one would leave every
  prospector row null in it forever), so it lives in the name after `QUALIFIER`,
  and `submitLead` keeps the stored name when the new submission has no company.
- **The audit actor for an inbound lead is `site:<uuid>`.** `prospector_activity`
  has `actor_id NOT NULL` and there is no operator behind a form fill, so the site
  stands in as one — which is also what lets the admin's filter show everything
  one customer's site produced.
- **`intake_site` is a value, not a foreign key.** Deleting a site must not
  cascade into the customer's pipeline; the leads it brought are theirs and
  outlive the form. Readers tolerate a dangling reference, which is exactly what a
  deleted site leaves.
- **The rate limit is in memory and resets on deploy** (`lib/crm/rate-limit.ts`).
  That is deliberate and its limits are written down there: it stops a stuck retry
  loop, not a distributed flood, and it has to move out of the process the day the
  CRM runs on more than one instance. Nothing else here does.
- **`public/atlas-crm.js` is hand-written ES5 served from `/public`, not a bundled
  module.** It is pasted into sites we did not necessarily build this year, and its
  whole value is working when nothing else on the page does. It derives the
  endpoint from its own `src` — a customer copying the tag to another site gets a
  working install rather than one pointing at a host that no longer answers.
- **The snippet's field names are aliased both ways** (`nome`/`name`,
  `telefone`/`phone`), because renaming an input on a live site is exactly the
  edit that breaks someone's existing analytics. Anything unrecognised rides along
  under its visible label and becomes a line in the lead's note.
- **The honeypot is answered with 202, not with an error.** A bot told it failed
  retries with the field cleared; a bot told it succeeded goes away.

# Client accounts and the /app portal

- **`accounts` is the tenant, and Atlas is deliberately not a row in it.**
  `leads.account_id IS NULL` means "ours" — every lead the prospector ever found.
  Giving ourselves an account would make our own pipeline a tenant of itself,
  force every existing query to learn about accounts on day one, and require a
  backfill that can only guess. New tables carry `account_id NOT NULL`; the old
  ones predate tenancy and are allowed to say so.
- **`LeadScope` is a _required_ field on `HistoryFilters`.** That is the whole
  enforcement mechanism: `parseFilters()` cannot be called without deciding whose
  leads may come back, so the compiler catches a new screen that forgets. Making
  it optional, or defaulting it to `tudo`, converts a build error into a silent
  cross-tenant read.
- **The scope never comes from the query string.** `parseFilters(params, scope)`
  takes it from the session; `?conta=` is honoured **only** when the caller
  already holds `tudo`, so it can narrow our view and can never widen a client's.
  `scope.test.ts` asserts exactly that, including `?conta=` pointed at another
  account.
- **`scopeFor(user)` in lib/auth/server.ts is the only place a scope is derived.**
  A page that picks its own is a page that can pick differently. A `cliente` with
  no account resolves to an id that matches nothing rather than to everything —
  an empty pipeline is a visible bug, a full one is an invisible breach.
- **Reads are safe by construction; writes are not.** Every read goes through
  `where()`, which always carries the scope. `setStatus(id, …)` and its
  neighbours take a bare id, so each mutating route calls `denyOutsideScope()`
  (single lead) or `idsInScope()` (bulk) first — same shape and same reasoning as
  `denyWithout()`: the control belongs where the request arrives.
- **Out of scope answers 404, never 403.** A 403 confirms the lead exists, which
  turns the endpoint into a way to probe another account's pipeline.
- **A lead is stamped with its account in exactly one place** — `submitLead()`,
  from `site.accountId`. Never from the submission: the form is on a public page
  and everything in the post body is a stranger's typing.
- **`users.role` needed a table rebuild, not an `ALTER`.** SQLite cannot widen a
  CHECK constraint and the DDL is `CREATE TABLE IF NOT EXISTS`, so an existing
  `prospector.db` would keep the two-role constraint forever and every client
  login would fail at the INSERT. `widenRoleCheck()` does the rename-copy-drop in
  one transaction, guarded on the stored DDL, and must run _after_
  `addMissingColumns()` — the copy names every column explicitly.
- **An account is suspended, never deleted.** Their leads outlive the
  arrangement, and a cascade would erase a client's pipeline because we stopped
  invoicing them. `requireClient()` re-reads the account on every request, so
  suspending one ends its sessions on the next click.
- **`/app` is a sibling of `/admin`, not a group inside it.** A route group under
  /admin would put a client one guessed URL away from our prospecting and would
  make every future `/admin/*` page a question about who can see it.
- **The portal reuses the CRM's tone blocks** (`[data-admin]`,
  `[data-admin-shell]`) rather than declaring a third. A `[data-app]` block would
  have to give a value to every semantic colour again just to look the same. Add
  one the day the portal should look like the client's brand instead of ours.
- **Three login forms, one route.** `/admin/login`, `/operador/login` and
  `/app/login` all post to `/api/admin/session` with a `portal` field the route
  checks against the account's role. Three forms because the copy is the
  difference — "Entrar como administrador" is not a sentence to show a dentist.
- **`toCrmRow()` in lib/crm/rows.ts is shared by /admin and /app**, same rule as
  the CSV columns: two copies is how the two screens start disagreeing about a
  lead's WhatsApp link or niche label, and both would render fine while doing it.
- **`logins: 0` on an account is a to-do, not a statistic.** It means the site is
  feeding a pipeline the client has never been able to open. The accounts screen
  says so in words for that reason.
- **`callsToday` and the operator/usage screens are NOT scoped.** They read
  `lead_calls` and `prospector_activity`, neither of which has an `account_id`.
  That is correct today — only we make calls — and has to be revisited before a
  client can log one.

# Reachability

- **The sidebar lists only views that exist — and every view that exists must be
  reachable.** The first half was already written down; the second is the half
  that actually broke. A page nobody can navigate to is not a feature, and it
  fails silently: it builds, it typechecks, its tests pass, and no one uses it.
- **The call queue is mounted twice**, at `/admin/ligacoes` for us and at
  `/operador/ligacoes` for the people who dial. It has to be: the whole `/admin`
  tree is `requireAdmin` at the layout, so cold calling — the queue, the daily
  list, resumable sessions, per-operator metrics — was unreachable by the only
  role that uses it. `/operador` showed a daily call _target_ with no way to
  place a call.
- **`CallListsView` and `CallSessionView` are exported from their page files**
  and mounted in both trees, the same shape as `HistoryPage`. Forking them into
  a second copy is how the two screens start disagreeing about what an outcome
  does.
- **`basePath` is load-bearing on every call component** (`DailyQueueButton`,
  `CallListManager`, `CreateCallListButton`, `CallSessionView`). A list built by
  an operator that opens under `/admin` drops them on `/operador` with the list
  created and no way to reach it. `TopUpButton` deliberately has no `basePath`:
  it refreshes in place rather than navigating.
- **`requireStaff()` is for screens both of our roles use.** `requireAdmin` on a
  shared view makes the operator mount redirect in a loop; `requireUser` lets a
  client in. Server actions inside those views repeat it — an action is a public
  endpoint, and the page having checked is not enough.
- **The metric row on a shared screen is scoped by the page, never the view.**
  `CallListsView` takes an `actorId` and `callStats({ actorId })` honours it, so
  the operator mount shows their own numbers and ours shows everyone's — the
  same rule `CallsToday` already follows, for the same reason.
- **`LeadTable` takes `canCall`.** The client portal renders the same table, and
  the calling queue is our tooling living under `/admin` — a client pressing
  "criar lista de ligações" would be pushed to a page their session cannot open.
  The route scopes what it can queue either way; the prop is only about not
  offering a dead end.
- **A card that 403s is worse than a card that isn't there.** `/operador` hides
  the B2B tile without the `b2b` grant, the same courtesy `canExport` already
  provides — the route stays the control.

# WhatsApp automation

- **The agent lives in the app, the bridge lives in a container.** `src/lib/whatsapp/`
  is the whole feature; Evolution API is a separate service in `docker-compose.yml`
  that publishes no host port. It holds a long-lived socket and a paired session on
  disk, which is exactly the state a Next.js container — restarted on every deploy —
  is the wrong place for. An Evolution instance reachable from the internet is a
  WhatsApp account anyone can send from.
- **`evolution.ts` is the only file that knows what a JID is.** Everything else
  deals in folded phone numbers and strings, so replacing the unofficial bridge
  with Meta's Cloud API touches one file. Don't let `@s.whatsapp.net` leak upward.
- **The webhook is under `/api/v1/`, like `/api/v1/leads`, and for the same reason** —
  it answers without a session and therefore must fall _outside_ the matcher in
  `src/proxy.ts`. Putting it under `/api/admin` or `/api/prospector` would make the
  session gate grow an exception, which is the edit that quietly opens the others.
- **No `EVOLUTION_WEBHOOK_SECRET` means no webhook is accepted.** The opposite
  default — accept everything when unset — turns a forgotten variable into an open
  endpoint that writes to the lead base and makes the agent talk to strangers. It is
  deliberately a different value from `EVOLUTION_API_KEY`: that one authenticates us
  _to_ the bridge, this one authenticates the bridge _to us_, and sharing one value
  means compromising the bridge also hands over the ability to inject fake client
  messages into the CRM.
- **`provider_id` on `wa_messages` is UNIQUE and it is the entire idempotency
  story.** Evolution retries a webhook it reads as failed; without the constraint
  the same client message is answered twice. `recordMessage` returns null on a
  replay, so callers must check the return rather than assume a write happened.
- **The model's JSON is validated as if a stranger wrote it, because effectively
  one did.** `actions.ts` is the single validator, and its limits protect the
  _number_, not the model: `* * * * *` is valid cron that messages a customer every
  minute forever, and it is what a confused model emits for "lembrar sempre". Hence
  `MIN_INTERVAL_MINUTES`, a mandatory `max_runs`, and `MAX_HORIZON_DAYS`.
- **The hand-written schedule form goes through that same validator**, by
  synthesising an envelope in `/api/admin/whatsapp/jobs`. It looks roundabout and
  is not: an operator with a text box can get the number banned exactly as fast as
  a language model can, and a second set of limits is a set that drifts.
- **The recurrence gap is sampled, never inferred from the fields.** `0 9,10 * * *`
  fires twice thirty minutes apart once a day; reading the expression calls that a
  daily reminder. `minimumInterval` computes four consecutive runs and takes the
  smallest gap.
- **Cron is evaluated in a named timezone, never the container's.** Every deploy
  runs UTC, and a reminder is a wall-clock promise — "segunda às 9" means 9am in
  São Paulo. `cron.ts` has no dependency on purpose: `croner` and `node-cron` both
  bring a scheduler, and the queue is in SQLite precisely so there isn't one.
- **The model writes local wall time and never an offset.** Asking a language model
  for a UTC offset is asking it to do arithmetic it is bad at, and a wrong one books
  the meeting three hours out with nothing to show for it. `resolveWhen` folds it
  through `wallToInstant`; a string carrying its own offset is honoured as written.
- **A rejected action triggers one corrective round-trip.** The worst failure this
  feature has is the model writing "pronto, agendei!" over an action that was
  refused — the client is told something that did not happen and finds out when
  nobody calls. `runTurn` shows the model why it was refused and asks once more;
  a second failure sends the reply without the promise.
- **The job queue is SQLite, not `setTimeout`.** A timer is lost on every deploy,
  and a reminder that evaporates on restart is worse than one that never existed
  because the client was told it was coming. `tick.ts` only asks "anything due?",
  so losing it costs the delay and nothing else.
- **`dueJobs` matches `next_run_at <= now`, and `MAX_LATENESS_MS` is what stops
  that being cruel.** A container down for a weekend comes back holding Friday's
  reminders; "lembrando da nossa conversa de amanhã" arriving Monday about a
  Saturday that has passed damages the relationship it was meant to maintain. Late
  jobs are skipped, and a recurrence still advances so it resumes next slot.
- **A failed send still advances the job.** Leaving `next_run_at` in the past makes
  the tick retry every 30 seconds forever — against a disconnected bridge that is a
  log full of one error, against a blocked number a queue that never drains. A
  one-off gets exactly one retry; a recurrence just waits for its next slot.
- **The tick guards against overlapping itself.** `dispatchDue` awaits a network
  call per job, so a hanging bridge can outlast the 30s interval, and a second pass
  over rows the first hasn't advanced yet sends the client the same reminder twice —
  the exact failure a durable queue was supposed to remove.
- **Sending as a human turns the agent off on that thread.** `auto_reply` is a
  column rather than a setting because a human and a model both answering is the
  most embarrassing thing this feature could do in front of a customer. The send
  route does it server-side, so taking over is not something you can forget.
- **Failed outbound messages are stored and excluded from the prompt.** Stored,
  because an operator has to see what the client did _not_ receive — a gap with no
  row reads as the agent having said nothing. Excluded, because a model that reads
  them back believes it already said something the other phone never showed.
- **Booking a meeting schedules its own reminders**, in `scheduleAppointment`, and
  skips any whose offset has already passed. The client's experience of "agendado"
  _is_ the reminder; leaving it to the model makes it a coin flip per conversation.
  It also writes the CRM's own `next_follow_up_at`, so a booked call reaches the
  operator's work queue and not only the WhatsApp screen.
- **`instrumentation.ts` must never let the scheduler's start reject**, same rule
  and same reason as `warmProspector()`: Next treats a failed hook as a failure to
  start, and the marketing site must not go down over a reminder.
- **No constructor parameter properties in `src/lib/whatsapp/`.** Node's type
  stripping (`node --test`) rejects them outright while the bundler accepts them, so
  the shorthand compiles in the app and fails only under test.
- **Watch `*/` inside comments in these files.** Writing a cron example like a
  stepped wildcard in a JSDoc block terminates the comment, and the parse error
  points at the code below rather than at the comment — the same trap as a backtick
  inside the SQL template literals in `db.ts`.

# Análise de reuniões

- **`rubric.ts` é o `roteiro-ligacao.md` compilado, e os dois têm de mudar
  juntos.** A rubrica é o que faz o relatório dizer "você pulou a implicação" em
  vez de conselho genérico de vendas; se ela divergir do roteiro, a ferramenta
  passa a treinar a equipe num método que ninguém combinou — e nada reporta isso,
  porque as duas versões produzem relatórios igualmente plausíveis.
- **Implicação e necessidade pesam mais que as outras seis etapas somadas**, e
  isso está escrito na rubrica em vez de calculado em código. São as duas etapas
  que correlacionam com fechamento e as duas que um vendedor experiente pula.
- **A transcrição roda no servidor, com binários que `npm install` não instala.**
  ffmpeg, `whisper-cli` e o modelo em `data/whisper/`. `readiness()` reporta os
  três separadamente porque "a transcrição não está configurada" manda alguém ler
  código; saber que é o modelo e não o binário é uma linha de download.
- **Nunca troque o whisper local por uma API sem decidir isso em voz alta.** O
  arquivo é a voz de um cliente discutindo os números dele, enviada por um
  vendedor que não negociou contrato de tratamento de dados com ninguém.
- **O áudio é apagado depois da transcrição** (`REVIEW_KEEP_AUDIO=1` desliga).
  Todo recurso posterior lê a transcrição, não o áudio, então guardar o arquivo
  compra re-transcrição e nada mais — ao custo de uma pasta de conversas de
  clientes sem política de retenção.
- **O upload é o corpo cru da requisição com os metadados na query string**, não
  um `multipart`. `request.formData()` bufferiza os 300 MB inteiros em memória
  antes de escrever o primeiro byte, e falha no fim de um upload de cinco
  minutos. O nome do arquivo vem de um `randomUUID()` e nunca do navegador —
  aquela string é um path traversal para dentro do volume de dados.
- **Os dois passos lentos rodam fora da requisição, e a coluna `status` é o único
  canal entre eles e a tela.** Uma promise em memória é invisível para a página
  que faz polling. `runReview()` nunca lança: é chamada com `void` de um route
  handler, onde uma rejeição não tratada derruba o processo.
- **A função do pipeline chama-se `runReview`, não `process`.** O nome óbvio
  sombreia o `process` global e `process.env` dentro do módulo passa a resolver
  para a própria função — o typecheck pega, mas só depois de confundir.
- **`extractJson` vem de `whatsapp/actions.ts`.** Duas implementações de "extrai
  o objeto de dentro das cercas" são dois conjuntos de casos-limite para
  descobrir separadamente.
- **`validate()` materializa as oito etapas mesmo quando o modelo omitiu sete.**
  Um relatório mais curto e mais arrumado é um relatório que perdeu um critério em
  silêncio; `analyse.test.ts` fixa isso, junto com a rejeição de uma resposta sem
  resumo.
- **A tela é montada nas duas árvores**, `/admin/reunioes` e `/operador/reunioes`,
  como a fila de ligações e pela mesma razão. `scope`/`viewerId` null significa
  "vê de todo mundo" e é só do admin; uma reunião de outra pessoa responde 404 e
  nunca 403, porque um 403 confirma que ela existe.

# WhatsApp por conta

- **One Evolution server, one instance per account.** `EVOLUTION_API_URL` and
  `EVOLUTION_API_KEY` stay in the environment because there is one bridge beside
  this app serving everyone; what differs per client is `accounts.wa_instance` —
  which paired number to act as. `evolutionServer()` and `evolutionConfig(instance)`
  are that split. A URL per client would be a second container to run, pair and
  monitor for every customer sold.
- **`accounts.wa_instance` is UNIQUE, and that is load-bearing.** The webhook
  resolves the account _from_ it, so two accounts sharing an instance is an
  inbound message that cannot be attributed to either. It is a partial unique
  index, because the accounts with no instance yet — on an existing database,
  all of them — must not collide with each other on NULL.
- **`instance` is the only field in an inbound webhook that identifies the
  recipient.** The sender's number says who wrote, never who they wrote to. It is
  therefore parsed out in `parseInbound` and pinned by `evolution.test.ts`; losing
  it does not fail loudly, it files one client's customer under another's
  pipeline.
- **An unroutable message is dropped, never defaulted to ours.** `routeToAccount`
  in the webhook has three outcomes on purpose — our own instance, a bound
  account, and neither. Falling back to Atlas for the third would have the agent
  answer a stranger with our persona on a number that is not ours. It answers 200
  and logs, because the bridge retries a non-2xx forever and none of these resolve
  by being retried.
- **`wa_conversations.phone` is unique per account, not globally**, and getting
  there needed the project's second table rebuild (`dropGlobalPhoneUnique`) — see
  `widenRoleCheck` in users.ts for the first. Two differences from that one:
  three tables carry foreign keys into this table, so the rename-first order used
  for `users` would silently repoint `wa_messages` at the scratch table (SQLite
  rewrites a child's REFERENCES on parent rename); and `PRAGMA foreign_keys`
  cannot change inside a transaction, so it is toggled around the BEGIN. The
  order used is SQLite's documented one: build under a scratch name, copy, drop,
  rename into place.
- **The uniqueness is two partial indexes, not `UNIQUE (account_id, phone)`.**
  SQLite treats every NULL as distinct in a unique tuple, so the plain constraint
  would let our own rows — the ones with a null account — duplicate freely, which
  is the exact split-history the constraint exists to prevent.
- **`conversationsDdl(table)` is a function so the rebuild cannot drift.** Writing
  the DDL twice is how a rebuilt table ends up a column behind the one fresh
  databases get, on machines nobody tests.
- **`findConversation` and `openConversation` take a required `accountId`, and
  null is a real value meaning ours.** Optional would make "I forgot to pass it"
  and "this is ours" the same call, and the compiler is the only thing that
  catches the first.
- **The lead lookup inside `openConversation` is account-scoped too.** Matching a
  client's inbound number against _our_ lead base attaches their conversation to a
  business we prospected, and the agent then answers holding another company's
  history.
- **`deliver()` resolves the instance from the thread, never from its caller.**
  Every caller already has the conversation and none of them should be trusted to
  remember whose number it is. A client account with no instance is a refusal, not
  a fallback to ours — quietly sending from our number puts our WhatsApp in front
  of their customer.
- **The agent's persona comes from `accounts.wa_brief`, and a client thread
  without one is NOT answered.** `brief()` used to read `src/content/site` and
  `services` unconditionally, which is right for us — our bot cannot offer a
  service our website does not — and catastrophic once routed: a dentist's patient
  introduced to a digital agency, on the dentist's number, with nothing in the
  logs saying anything went wrong. `runTurn` hands the thread to a human instead;
  the message is still stored. `agent.test.ts` pins both directions.
- **The guardrails are shared, the identity is not.** Only the "who is speaking"
  half of the prompt varies per account; "nunca invente preço", "nunca peça senha"
  and "nunca diga que é humano" are in every prompt and are not something a client
  brief can drop.
- **`/api/admin/whatsapp/*` is staff-only, and that is a fix rather than a
  precaution.** Those routes checked authentication and not role, and the proxy
  admits any valid session to `/api/admin/*` — so a `cliente` could post a
  `conversationId` from another account and send from our number into a
  stranger's thread. `staff()` in each of them is the control.

# O CLAUDE.md do site do cliente

- **`clientClaudeMd()` é gerado por conta, nunca um template estático.** O site
  de cada cliente vive em outro repositório, sem pacote nosso, sem import, sem
  tipo — nada ali revela que este CRM existe. `CLAUDE.md` é o único arquivo que
  o Claude Code lê garantidamente em toda sessão, então é onde essas regras
  cabem. Um template com `SEU-CRM` dentro é um template que alguém cola
  literalmente, e o formulário falha do jeito que este projeto inteiro tenta
  evitar: em silêncio.
- **A chave, o endpoint e os domínios saem do banco, não de um exemplo.**
  `claude-md.test.ts` recusa qualquer saída que contenha placeholder quando a
  conta já tem site — e exige o placeholder, bem visível, quando não tem. Um
  placeholder óbvio é pego por quem cola; uma chave plausível e errada é pega
  por um cliente.
- **O arquivo é escrito como instrução, com o motivo junto.** O leitor é um
  agente decidindo o que construir, e uma regra sem motivo é uma regra que ele
  "melhora". As quatro que mais importam — não escrever o submit à mão, não
  esconder a chave atrás de proxy, não trocar a chave para resolver 401, não
  instalar serviço de formulário — são exatamente as decisões que um agente toma
  com confiança e erra quando nada no repositório o contradiz.
- **Se o contrato de `/api/v1/leads` mudar, este gerador muda junto.** Ele
  documenta campos obrigatórios e códigos de status para repositórios que não
  temos como reimplantar em massa; um texto desatualizado aqui é uma instalação
  quebrada em um site que ninguém vai revisitar.
- **O download existe porque o nome do arquivo importa.** `CLAUDE.md` na raiz é
  lido; `docs/claude.md` não é. Um botão de copiar convida a colar em um arquivo
  com o nome errado.

## Parear o número de um cliente

- **The pairing flow is four Evolution calls behind one button**, and they live
  in `evolution.ts` with everything else that knows what the bridge's API looks
  like. They used to be `curl` commands in a comment in docker-compose.yml, which
  is fine for our own number — paired once, years ago — and unusable as something
  done per customer.
- **The instance is named after the account slug, never randomly.**
  `instanceNameFor()` makes re-running connect idempotent: a random name would
  strand a second instance holding a paired session every time someone pressed
  the button twice, and orphaned instances are invisible from every screen.
- **`ensureInstance` treats "already in use" as success.** The operator pressing
  connect again on a half-finished pairing means "carry on", not "start over".
  Anything else is re-thrown — a bridge that is down must not read as a
  successful create followed by a QR that never appears.
- **The webhook is set on every connect, not only on create.** The URL is built
  from the request, so it changes whenever the CRM moves host, and a stale one is
  the invisible failure of this whole feature: the number pairs, the screen says
  connected, and not one message ever arrives.
- **Pairing is refused when `EVOLUTION_WEBHOOK_SECRET` is unset.** The webhook
  rejects everything without it, so pairing anyway produces a connected number
  whose messages can never be accepted.
- **The account row is bound _before_ the bridge is touched**, and stays bound if
  a later step fails. An instance that exists in Evolution and belongs to no
  account has its inbound messages dropped as unroutable, and nothing on any
  screen would explain why; leaving the binding keeps it visible to the one
  screen that can finish or remove it.
- **Evolution returns the QR as bare base64 on some versions and as a data: URI
  on others.** Normalised in `connectInstance`, because an `<img>` with a bare
  base64 `src` renders as a broken image and reads as a pairing failure to
  whoever is holding the phone.
- **The panel polls only while a QR is up or the state is `connecting`.** A
  connected account is a screen someone leaves open all afternoon; polling it
  forever is a request every four seconds for a value that changes once a year.
- **`fetchStatus` and `applyStatus` are split so a late answer can be dropped.**
  A poll resolving after the panel unmounted — or after "desconectar" was pressed
  — would otherwise write a stale "connected" over the state that replaced it.
- **Disconnecting logs out before deleting**, or the session stays on the
  client's linked-devices list as a device they cannot remove from our side. Both
  calls are best-effort and the row is unbound regardless: the row is what routes
  inbound messages, and one pointing at an instance we tried to delete is a
  number that keeps answering after we said it stopped.
- **Disconnecting keeps the conversations.** They are the record of what was said
  to real people and they outlive the connection, exactly as a suspended
  account's leads outlive the arrangement.
- **`wa_number` is cleared with the instance and captured only once.** Asked for
  on the first poll that sees `open` rather than on every poll, because the panel
  polls every few seconds while a QR is up and this is a second network call each
  time.

# A infraestrutura de IA (`src/lib/ai/`)

- **Nada chama um provedor direto.** Todo caminho até um modelo passa por
  `runSkill()` (skills novas, com envelope e `validate()`) ou por
  `runCompletion()` (quem tem laço próprio de parsing). Um `complete()` solto em
  `src/app/api/` funciona perfeitamente e abre um buraco invisível no log: a
  execução não aparece em `/admin/ia`, o custo daquele cliente fica subestimado, e
  ninguém descobre até a fatura. `providers.ts` exporta `complete()` porque as
  duas funções acima precisam dela — não porque seja uma API pública.
- **Uma skill é `context` / `system` / `user` / `validate`.** A separação que
  importa é `context()` das outras três: tudo abaixo dela é função pura das
  linhas já buscadas, e é isso que torna a skill testável contra uma fixture sem
  banco e sem rede. Uma skill que lê dentro de `system()` não é avaliável, e um
  recurso de IA que ninguém avalia é um que piora sem ninguém perceber.
- **`context()` recebe o `LeadScope` como primeiro argumento, nunca como
  filtro opcional.** Mesma regra do resto do CRM, e aqui ela pesa mais: um
  vazamento por uma feature de IA é um vazamento narrado em português fluente. A
  skill não constrói escopo; recebe o da rota, que veio da sessão.
- **`invalido` não é `erro`.** Um envelope que volta bem formado e vazio é
  problema de prompt; um provedor fora do ar é outra coisa. Colapsar os dois
  esconde o único sinal que diz que o modelo está piorando. `runSkill()` grava os
  dois estados, e cobra pelos dois — as falhas gastam tokens de verdade.
- **`cost_brl` nulo não é zero.** Um provedor que não reportou uso, ou um modelo
  que não está na tabela de `cost.ts`, é um desconhecido conhecido. Somar como
  gratuito é o erro que faz o relatório mentir na direção cara.
- **O teto (`AI_QUOTA_BRL`) é checado antes da chamada**, não depois. Todo
  mecanismo que só _avisa_ avisa depois de já ter sido pago.
- **O registry (`registry.ts`) é mantido à mão e pode divergir.** É lista de
  descrições, não de objetos `Skill` — porque nem tudo que gasta é uma skill (o
  agente do WhatsApp e a análise de reunião têm laço próprio). `unknownSkills()`
  é a checagem: um id no log sem descrição ou é skill removida, ou é id digitado
  errado partindo o gasto de uma skill em duas linhas.
- **`lib/whatsapp/llm.ts` não existe mais**, virou `lib/ai/providers.ts`, e
  `extractJson` saiu de `whatsapp/actions.ts` para `lib/ai/envelope.ts`. A
  análise de reunião já importava o extrator do agente do WhatsApp; o resto do
  arquivo é aquele comentário aplicado aos coercers, que estavam escritos duas
  vezes.

# Insight de vendas (`src/lib/ai/skills/`)

- **Toda afirmação sai de um fato numerado.** `facts.ts` monta a lista que vai no
  prompt, e o `validate()` da skill descarta qualquer observação que cite um id
  que a gente não mandou. Pedir no prompt para não inventar reduz a frequência;
  só a filtragem torna o resultado verificável. O custo é que uma observação
  certa com citação errada também morre — é a troca certa para um texto que
  alguém lê trinta segundos antes de ligar para um estranho.
- **`observado` e `hipotese` nunca se juntam.** Uma é fato com fonte, a outra é
  achismo, e a tela mostra as duas diferentes. Achatar em uma lista de frases
  confiantes é exatamente como nasce "eles perdem 30% dos leads".
- **Nada é gerado no carregamento da página.** O insight vem do cache
  (`cachedOutput`) ou de um clique. Gerar no load paga por lead que o operador
  vai pular, e um insight que muda a cada refresh parece pouco sério mesmo
  quando as duas versões são boas.
- **Segmento, não nicho.** São 43 nichos e seis segmentos de venda
  (`segments.ts`). O que muda o pitch não é o ramo, é como o cliente chega e
  quanto custa perder um: salão e manicure são a mesma venda, salão e dentista
  não são. Escrever template por nicho é como se ganha 43 templates com seis
  atualizados. O mapa sai do `group` que o nicho já tem — nicho novo entra
  segmentado no dia em que é adicionado — com `OVERRIDES` para os grupos que
  racham de verdade, e `intent: "parceiro"` ganha de tudo.
- **`insight.objecao` é cacheado por segmento.** Duas barbearias compartilham uma
  resposta; gerar por nicho paga a cadeia cara duas vezes pela mesma coisa.
  `objecaoSubject()` é a chave, e a rota e o `context()` têm que usar a mesma —
  senão é cache que nunca acerta.
- **Prompt que perde contexto não quebra, só piora.** O bloco de segmento já
  deixou de ser interpolado uma vez sem que teste, lint ou build percebessem.
  Por isso cada skill tem teste de prompt afirmando que o segmento chega lá e que
  dois segmentos produzem prompts diferentes.
- **`skills/roteiro.ts` não é cópia de `roteiro-ligacao.md`.** O markdown está
  fora do app Next e o build standalone não o rastreia — ler em runtime funciona
  local e quebra no container. Quando os dois divergirem, o markdown está certo e
  o TS está desatualizado; diga isso na revisão em vez de ampliar em silêncio o
  que o modelo pode dizer.
- **`insight.fila` ordena, não filtra.** Todo lead que entra sai com posição; o
  que o modelo esqueceu é anexado no fim. Uma skill que sumisse com leads estaria
  decidindo sozinha que uma empresa nunca é contatada, e de forma invisível —
  ninguém confere o que falta numa lista.
- **A ordenação acontece na criação da lista e em lugar nenhum mais.**
  `createCallList` grava as posições na ordem que recebe, então escolher a ordem
  ali molda uma fila sem mexer em nenhuma. Reordenar lista viva move trabalho que
  alguém está no meio — o operador volta do almoço com outro lead na posição 12 e
  sem como saber por quê. E falha aberto: sem IA, a lista sai na ordem do filtro.
- **`npm run eval` roda offline.** As fixtures são respostas gravadas, não
  chamadas ao vivo: uma checagem que custa dinheiro por execução é uma checagem
  que alguém acaba desligando. Editou prompt, rode. As três skills têm fixtures;
  uma skill nova sem fixture é uma skill sem guardrail testado.
