/*
 * The drop-in. One script tag on a customer's site and their contact form lands
 * in the CRM.
 *
 *   <form data-atlas-crm>
 *     <input name="name" required>
 *     <input name="email" type="email">
 *     <input name="phone">
 *     <textarea name="message"></textarea>
 *     <button type="submit">Enviar</button>
 *   </form>
 *   <script src="https://SEU-CRM/atlas-crm.js" data-key="atlas_..."></script>
 *
 * Deliberately hand-written, dependency-free ES5 served straight from /public
 * rather than a bundled module. It is pasted into sites we did not necessarily
 * build this year, some of them on hosting that predates modules, and the whole
 * value of the thing is that it works when nothing else on the page does. It is
 * also the one file here a customer might open and read, so it stays readable.
 *
 * It never touches the page's styling. Fields it does not recognise are sent
 * through as-is under their own labels, so a form we have never seen still
 * arrives complete.
 */
(function () {
  "use strict";

  /*
   * The endpoint is derived from where this script was loaded from, not
   * configured. A customer who copies the tag from one site to another gets a
   * working install rather than one pointing at a host that no longer answers,
   * and there is one fewer value to get wrong in a paste.
   */
  var script =
    document.currentScript ||
    (function () {
      var all = document.getElementsByTagName("script");
      for (var i = all.length - 1; i >= 0; i--) {
        if (/atlas-crm\.js/.test(all[i].src)) return all[i];
      }
      return null;
    })();

  if (!script) return;

  var key = script.getAttribute("data-key") || "";
  var endpoint = script.src.replace(/\/atlas-crm\.js.*$/, "") + "/api/v1/leads";

  if (!key) {
    // Console rather than silence: the failure is at install time, on a page the
    // developer is looking at, and a form that quietly posts nowhere is the
    // worst possible way to find that out — the customer discovers it weeks
    // later as "we stopped getting enquiries".
    console.error("[atlas-crm] Falta o atributo data-key no <script>.");
    return;
  }

  /* The fields that map onto real columns. Everything else rides along as an
   * extra, keyed by its label. */
  var KNOWN = {
    name: 1,
    nome: 1,
    email: 1,
    "e-mail": 1,
    phone: 1,
    telefone: 1,
    whatsapp: 1,
    celular: 1,
    message: 1,
    mensagem: 1,
    company: 1,
    empresa: 1,
    city: 1,
    cidade: 1,
    uf: 1,
    estado: 1,
  };

  /* Portuguese first because these forms are ours, but a site in English works
   * without renaming its inputs — which matters, because renaming an input is
   * exactly the kind of edit that breaks someone's existing analytics. */
  var ALIAS = {
    nome: "name",
    "e-mail": "email",
    telefone: "phone",
    celular: "phone",
    whatsapp: "phone",
    mensagem: "message",
    empresa: "company",
    cidade: "city",
    estado: "uf",
  };

  function canonical(name) {
    var lower = String(name || "")
      .trim()
      .toLowerCase();
    return ALIAS[lower] || lower;
  }

  /*
   * The honeypot.
   *
   * Off-screen rather than display:none — some bots skip anything with
   * display:none, and a few screen readers announce it, so it is also removed
   * from the accessibility tree and from the tab order. autocomplete="off" keeps
   * the browser from helpfully filling it for a real person, which would send
   * every one of their submissions to the trap.
   */
  function addHoneypot(form) {
    if (form.querySelector('input[name="_gotcha"]')) return;
    var trap = document.createElement("input");
    trap.type = "text";
    trap.name = "_gotcha";
    trap.tabIndex = -1;
    trap.setAttribute("autocomplete", "off");
    trap.setAttribute("aria-hidden", "true");
    trap.style.cssText =
      "position:absolute!important;left:-9999px!important;width:1px;height:1px;opacity:0;";
    form.appendChild(trap);
  }

  /*
   * Reads the form without FormData.entries(), which older browsers lack.
   * Unchecked radios and checkboxes are skipped, multiple values for one name
   * are joined — a checkbox group is one answer, not several fields with the
   * same label.
   */
  function readForm(form) {
    var payload = { key: key, fields: {} };
    var elements = form.elements;

    for (var i = 0; i < elements.length; i++) {
      var el = elements[i];
      var name = el.name;
      if (
        !name ||
        el.disabled ||
        el.type === "submit" ||
        el.type === "button"
      ) {
        continue;
      }
      if ((el.type === "checkbox" || el.type === "radio") && !el.checked) {
        continue;
      }

      var value = el.value == null ? "" : String(el.value);
      if (!value) continue;

      if (name === "_gotcha") {
        payload._gotcha = value;
        continue;
      }

      var field = canonical(name);
      if (KNOWN[field]) {
        payload[field] = payload[field] ? payload[field] + ", " + value : value;
      } else {
        // The visible label if the form has one, so the note in the CRM reads
        // "Orçamento previsto" rather than "budget_range".
        var label = labelFor(el) || name;
        payload.fields[label] = payload.fields[label]
          ? payload.fields[label] + ", " + value
          : value;
      }
    }

    payload.pageUrl = window.location.href;
    return payload;
  }

  function labelFor(el) {
    if (el.id) {
      var byFor = document.querySelector(
        'label[for="' + cssEscape(el.id) + '"]',
      );
      if (byFor) return textOf(byFor);
    }
    var parent = el.parentNode;
    while (parent && parent !== document.body) {
      if (parent.tagName === "LABEL") return textOf(parent);
      parent = parent.parentNode;
    }
    return (
      el.getAttribute("aria-label") || el.getAttribute("placeholder") || ""
    );
  }

  function textOf(node) {
    return (node.textContent || "").replace(/\s+/g, " ").trim().slice(0, 60);
  }

  /* CSS.escape is not everywhere, and an id with a quote in it would otherwise
   * break the selector. */
  function cssEscape(value) {
    if (window.CSS && window.CSS.escape) return window.CSS.escape(value);
    return String(value).replace(/["\\]/g, "\\$&");
  }

  /*
   * Status is written into an element the site provides, or into one appended
   * after the form. Never an alert(): the form is on the customer's page, styled
   * to the customer's design, and a browser dialog in the middle of it is not.
   */
  function statusTarget(form) {
    var provided = form.querySelector("[data-atlas-status]");
    if (provided) return provided;
    var created = document.createElement("p");
    created.setAttribute("data-atlas-status", "");
    created.setAttribute("role", "status");
    created.setAttribute("aria-live", "polite");
    created.style.margin = "0.75em 0 0";
    form.appendChild(created);
    return created;
  }

  function post(payload) {
    return fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      // No credentials: this is a cross-origin call to a CRM the visitor has no
      // account on, and sending cookies would only add a preflight condition.
      credentials: "omit",
      body: JSON.stringify(payload),
    }).then(function (response) {
      return response
        .json()
        .catch(function () {
          return {};
        })
        .then(function (data) {
          if (!response.ok) {
            throw new Error(
              data.error || "Falha ao enviar (" + response.status + ").",
            );
          }
          return data;
        });
    });
  }

  function attach(form) {
    if (form.getAttribute("data-atlas-bound")) return;
    form.setAttribute("data-atlas-bound", "1");
    addHoneypot(form);

    form.addEventListener("submit", function (event) {
      event.preventDefault();

      // The browser's own validation still runs first — the site's `required`
      // and `type="email"` attributes are the customer's decision about their
      // form, and this must not quietly override them.
      if (form.checkValidity && !form.checkValidity()) {
        if (form.reportValidity) form.reportValidity();
        return;
      }

      var status = statusTarget(form);
      var button = form.querySelector(
        'button[type="submit"], input[type="submit"]',
      );
      var buttonLabel = button ? button.textContent : null;

      if (button) {
        button.disabled = true;
        if (button.tagName === "BUTTON") button.textContent = "Enviando…";
      }
      status.textContent = "";

      post(readForm(form))
        .then(function () {
          status.textContent =
            form.getAttribute("data-atlas-success") ||
            "Recebemos seu contato. Retornaremos em breve.";
          form.reset();
          // Re-added because reset() empties the trap but does not remove it,
          // and because a form submitted twice must not lose it either way.
          addHoneypot(form);
          var redirect = form.getAttribute("data-atlas-redirect");
          if (redirect) window.location.href = redirect;
        })
        .catch(function (error) {
          status.textContent =
            form.getAttribute("data-atlas-error") ||
            "Não foi possível enviar agora. Tente novamente ou fale com a gente.";
          console.error("[atlas-crm]", error);
        })
        .then(function () {
          if (button) {
            button.disabled = false;
            if (button.tagName === "BUTTON" && buttonLabel !== null) {
              button.textContent = buttonLabel;
            }
          }
        });
    });
  }

  function scan() {
    var forms = document.querySelectorAll("form[data-atlas-crm]");
    for (var i = 0; i < forms.length; i++) attach(forms[i]);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", scan);
  } else {
    scan();
  }

  /*
   * For sites whose form is built by a framework and re-mounted on navigation,
   * and for the ones that would rather call this themselves than have their
   * submit handler taken over. `scan()` is idempotent — `data-atlas-bound` is
   * what stops a second call binding every form twice and sending each lead
   * twice with it.
   */
  window.AtlasCRM = {
    submit: function (data) {
      var payload = { key: key, fields: {}, pageUrl: window.location.href };
      for (var field in data) {
        if (!Object.prototype.hasOwnProperty.call(data, field)) continue;
        var canon = canonical(field);
        if (KNOWN[canon]) payload[canon] = data[field];
        else payload.fields[field] = data[field];
      }
      return post(payload);
    },
    scan: scan,
    endpoint: endpoint,
  };
})();
