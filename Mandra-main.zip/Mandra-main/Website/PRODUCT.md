# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Users

Two audiences on one page, SMB first.

1. **Primary — the Brazilian SMB owner or manager.** Runs a small-to-medium
   business, is not technical, and arrives wanting more customers and less
   manual work. Decides largely alone, is price-sensitive, and evaluates by
   whether the page sounds like it understands their operation. Portuguese (BR)
   is their language; the site is written in it.
2. **Secondary — the technical evaluator.** A marketing or operations lead who
   scrolls deeper and buys on capability and proof: what is actually built, on
   what stack, and whether the team can run it.

The page must convert the first without losing the second. Depth is allowed as
long as it sits below the part that has to work for a non-technical reader.

## Product Purpose

Mandra is a digital agency that builds and runs the systems a business is
found and served through: websites, custom web systems, applied AI, automation,
and Google Ads campaigns. Success for the marketing site is a qualified inbound
contact — an orçamento request from a business that could actually be served.

## Positioning

Mandra builds and *operates* the whole chain rather than selling one link of it:
the site that gets found, the ads that feed it, the automation that answers, the
AI that qualifies, and the system the business runs on afterwards. The internal
proof is that Mandra runs on its own stack — a CRM, a lead prospector over an
open business register, a WhatsApp agent, and meeting analysis are all built and
in daily use in this same repository. That is a claim a reseller or a single-
service agency cannot truthfully make.

## Operating Context

- Sales happens through inbound contact and WhatsApp; the phone/WhatsApp path is
  a real conversion route, not an afterthought.
- The public site (`src/app/(marketing)/`) shares a root layout with two
  internal trees — `src/app/prospector/` (lead tool) and `src/app/admin/` (CRM)
  — which are styled by remapping the same semantic tokens. Marketing changes
  must not disturb those tone blocks.
- Clients are handed a login at `/app` (client portal, Phase 0 built), so the
  marketing site sits in front of a real product surface.

## Capabilities and Constraints

- **Stack (fixed):** Next.js 16 App Router, React 19, Tailwind CSS v4 with
  `@theme` / `@theme inline` tokens, `motion` (Framer Motion successor),
  `@react-three/fiber` + `drei` + `three` 0.185, `lucide-react`, `simple-icons`.
  All already installed; no new rendering dependency is needed.
- **Token architecture is load-bearing.** Semantic colours live in
  `@theme inline` in `src/app/globals.css` and are remapped per section by
  `[data-tone]`, `[data-prospector]`, `[data-admin]`. Any new semantic colour
  must be given a value in *every* tone block or it resolves to nothing.
- **Services offered (confirmed):** Desenvolvimento de Sites, Sistemas Web,
  Inteligência Artificial, Automação, Publicidade Digital — with the sub-items
  listed in `src/content/services.ts`.
- Content is Portuguese (BR). Contact details in `src/content/site.ts`
  (phone, email, endereço) are still placeholders and are undecided product
  facts.
- Deployment of the marketing site is Netlify; the internal tools ship as a
  container. Marketing pages must never depend on the DuckDB extract.

## Brand Commitments

- **Name:** Mandra. **Amber `#f3a33a` is binding** as the brand hue, with the
  charcoal `#0b0e12`–`#171c21` family as its pairing; the amber ramp's
  contrast split (400 for display on dark, 600 for small text on light) is a
  standing accessibility constraint, not a preference.
- A mascot exists and the amber is described as "the mascot's own value".
- Everything else about the current look — layout, sections, motion, the cream
  paper bands — is not a commitment.

## Evidence on Hand

**Confirmed by the user: every proof figure currently on the site is
placeholder and must not be reused or restated.** Specifically fabricated:

- the four case studies in `src/content/cases.ts` and their results
  ("+142% nas vendas", "60% no tempo operacional", "+3.2k horas", "85% na
  conversão");
- "+120 empresas atendidas" and the 5.0 star rating in the hero;
- the testimonials in `src/content/testimonials.tsx`;
- the stat tiles in `src/content/stats.ts`;
- the social links and contact details in `src/content/site.ts`.

Real assets that do exist: the working product surfaces in this repository
(CRM, prospector, WhatsApp agent, client portal) and the generated globe point
data in `public/data/`. No client logos, screenshots, photography, press, or
testimonials are on hand. Future work must design proof sections that hold real
content when it arrives rather than asserting invented numbers.

## Product Principles

1. **Say only what is true.** With no metrics or logos on hand, credibility has
   to come from specificity about the work and from the craft of the page
   itself, never from a fabricated number.
2. **SMB-legible first, technically deep second.** Anything a non-technical
   owner must understand comes before anything that rewards an evaluator.
3. **The chain is the pitch.** Site → ads → automation → AI → system is one
   connected offer; presenting the services as five disconnected cards
   undersells the only defensible position.
4. **The site is the portfolio.** For an agency that sells sites and systems,
   the marketing page is the strongest demonstration available; its execution
   is a product claim.
5. **Contact must always be one gesture away.** WhatsApp and orçamento are the
   conversion events; every scroll depth needs a path to them.

## Accessibility & Inclusion

Portuguese (BR) content. The amber ramp's contrast rule above is binding:
`brand-600` is the first step that clears 4.5:1 on light surfaces and is the
only one permitted to carry small text there; `brand-300/400` are the display
values on dark surfaces. Motion-heavy work must honour
`prefers-reduced-motion`, and the WebGL work needs a non-WebGL fallback.
