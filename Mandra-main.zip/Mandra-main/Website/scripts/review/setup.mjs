#!/usr/bin/env node
import { spawn } from "node:child_process";
import { createWriteStream } from "node:fs";
import { mkdir, rename, rm, stat } from "node:fs/promises";
import path from "node:path";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";

/**
 * Everything the meeting review needs that `npm install` cannot provide.
 *
 * Transcription runs on two native binaries and a model file, none of which is a
 * Node dependency. This checks for the binaries, tells you exactly how to get
 * the one that is missing on the platform you are on, and downloads the model —
 * which is the part that is tedious rather than hard, and the part people put
 * off until the first upload fails.
 *
 * Idempotent. Run it on a fresh clone, run it again on a machine that is already
 * set up, and the second run downloads nothing.
 */

const ROOT = process.cwd();
const MODEL_DIR = path.join(ROOT, "data", "whisper");
const MODEL_NAME = "ggml-large-v3-turbo.bin";
const MODEL_PATH = path.join(MODEL_DIR, MODEL_NAME);

/**
 * large-v3-turbo, not base or small.
 *
 * The whole tool rests on the transcript: a review arguing with words the client
 * never said is worse than no review, because it is wrong with the same
 * confidence as when it is right. Turbo is ~1.6 GB and roughly as accurate as
 * large-v3 in Portuguese at a fraction of the runtime — the smallest model where
 * the transcript stops being the weak link.
 */
const MODEL_URL =
  "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3-turbo.bin";

const INSTALL_HINTS = `
  Arch/Manjaro   sudo pacman -S whisper.cpp
  Debian/Ubuntu  não há pacote; compile (abaixo)
  macOS          brew install whisper-cpp

  Compilando (qualquer sistema, precisa de git e cmake):
    git clone https://github.com/ggml-org/whisper.cpp
    cd whisper.cpp && cmake -B build && cmake --build build -j --config Release
    sudo install build/bin/whisper-cli /usr/local/bin/

  Se o binário existir com outro nome ou fora do PATH, aponte WHISPER_BIN para ele.`;

function check(bin, args) {
  return new Promise((resolve) => {
    const child = spawn(bin, args, { stdio: "ignore" });
    child.on("error", () => resolve(false));
    child.on("close", (code) => resolve(code === 0));
  });
}

async function exists(file) {
  try {
    const info = await stat(file);
    return info.size > 0;
  } catch {
    return false;
  }
}

async function download(url, target) {
  // To a .partial first, renamed on success: an interrupted download that lands
  // at the real path is a file that opens and then fails mid-transcription,
  // which reads as a broken model rather than as a truncated one.
  const partial = `${target}.partial`;
  await rm(partial, { force: true });

  const response = await fetch(url);
  if (!response.ok || !response.body) {
    throw new Error(`HTTP ${response.status} ao baixar o modelo.`);
  }

  const total = Number(response.headers.get("content-length") ?? 0);
  let done = 0;
  let lastPrint = 0;

  const source = Readable.fromWeb(response.body);
  source.on("data", (chunk) => {
    done += chunk.length;
    const now = Date.now();
    if (now - lastPrint > 500) {
      lastPrint = now;
      const mb = (done / 1024 / 1024).toFixed(0);
      const pct = total ? ` (${Math.round((done / total) * 100)}%)` : "";
      process.stdout.write(`\r  baixando ${mb} MB${pct}`);
    }
  });

  await pipeline(source, createWriteStream(partial));
  process.stdout.write("\r".padEnd(40) + "\r");
  await rename(partial, target);
}

async function main() {
  console.log("Análise de reuniões — verificando o servidor\n");

  const ffmpeg = await check(process.env.FFMPEG_BIN || "ffmpeg", ["-version"]);
  console.log(`  ffmpeg       ${ffmpeg ? "ok" : "FALTANDO"}`);
  if (!ffmpeg) {
    console.log(
      "\n  ffmpeg converte o áudio para o formato que o whisper lê.\n" +
        "    Arch: sudo pacman -S ffmpeg · Debian: sudo apt install ffmpeg · macOS: brew install ffmpeg\n",
    );
  }

  const whisper = await check(process.env.WHISPER_BIN || "whisper-cli", [
    "--help",
  ]);
  console.log(`  whisper-cli  ${whisper ? "ok" : "FALTANDO"}`);
  if (!whisper) console.log(`\n${INSTALL_HINTS}\n`);

  if (await exists(MODEL_PATH)) {
    console.log(`  modelo       ok (${MODEL_PATH})`);
  } else {
    console.log(`  modelo       baixando para ${MODEL_PATH}`);
    await mkdir(MODEL_DIR, { recursive: true });
    await download(MODEL_URL, MODEL_PATH);
    console.log(`  modelo       ok (${MODEL_PATH})`);
  }

  const ready = ffmpeg && whisper;
  console.log(
    ready
      ? "\nPronto. /admin/reunioes já aceita uploads."
      : "\nFalta instalar o que está marcado acima. O modelo já está no lugar.",
  );
  // Non-zero so a provisioning script that runs this notices, rather than
  // reporting success and failing on the first upload weeks later.
  if (!ready) process.exitCode = 1;
}

main().catch((error) => {
  console.error(`\nFalhou: ${error.message}`);
  process.exitCode = 1;
});
