#!/usr/bin/env node
/**
 * Add the `city_norm` column to an extract built before it existed.
 *
 * Run: npm run upgrade-extract        (from Website/)
 *
 * Why this exists rather than "just re-run the sync": the sync re-downloads the
 * planet-wide places theme and takes ~20 minutes. The column is derived entirely
 * from data already in the file, so rewriting it locally takes a few seconds and
 * produces the same result.
 *
 * What the column buys: the search matches a city by its folded name, and a
 * function over a column (`nrm(city) = '...'`) is opaque to Parquet's row-group
 * statistics — so before this, every search read most of the 122MB file. Matching
 * a stored, sorted column prunes properly: a Belo Horizonte search drops from 82MB
 * to 9MB. On disk that is 4.6x less I/O; over HTTP it is the difference between a
 * search that fits in a serverless timeout and one that does not.
 *
 * Safe to re-run: an extract that already has the column is left alone.
 */
import {
  existsSync,
  renameSync,
  statSync,
  unlinkSync,
  utimesSync,
} from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { DuckDBInstance } from "@duckdb/node-api";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..", "..");

// The current name first, then the Brazil-only one the sync used to write —
// the same pair, in the same order, that the app resolves in localExtractPath().
const EXTRACT =
  [
    path.join(root, "data", "places.parquet"),
    path.join(root, "data", "br-leads.parquet"),
  ].find((file) => existsSync(file)) ??
  path.join(root, "data", "places.parquet");
const TMP = `${EXTRACT}.partial`;

// Must fold identically to nrm() in src/lib/prospector/overture.ts, normalise()
// in cities.ts, and the copy in sync-places.mjs. If they drift, a city resolves
// in the picker and then returns nothing.
const nrm = (expr) =>
  `trim(regexp_replace(lower(strip_accents(${expr})), '[^a-z0-9]+', ' ', 'g'))`;

const q = (v) => v.replace(/'/g, "''");

if (!existsSync(EXTRACT)) {
  console.error(`Não encontrei ${path.relative(root, EXTRACT)}.`);
  console.error("Rode `npm run sync` primeiro para baixar o extrato.");
  process.exit(1);
}

const instance = await DuckDBInstance.create(":memory:");
const db = await instance.connect();

const columns = (
  await db.runAndReadAll(
    `SELECT column_name FROM (DESCRIBE SELECT * FROM read_parquet('${q(EXTRACT)}'))`,
  )
).getRowObjectsJS();

if (columns.some((c) => c.column_name === "city_norm")) {
  console.log("O extrato já tem a coluna city_norm — nada a fazer.");
  process.exit(0);
}

const { size: before, atime, mtime } = statSync(EXTRACT);
const started = Date.now();
console.log("Reescrevendo o extrato com city_norm...");

// Written to .partial and renamed, so an interrupted run can never leave a
// truncated file where the app expects a valid one. `npm run up` already knows
// to clean a leftover .partial up.
if (existsSync(TMP)) unlinkSync(TMP);
await db.run(
  `COPY (
     SELECT *, ${nrm("city")} AS city_norm
     FROM read_parquet('${q(EXTRACT)}')
     -- Same order as the sync: the sort column has to be the one the query
     -- filters on, or the statistics are useless again.
     ORDER BY city_norm, uf
   ) TO '${q(TMP)}' (FORMAT PARQUET, COMPRESSION ZSTD)`,
);
renameSync(TMP, EXTRACT);

// `npm run up` rebuilds the city index whenever the extract is newer than it.
// Not one business changed here — the column is derived from rows that were
// already in the file — so a fresh mtime would only buy a pointless rebuild.
utimesSync(EXTRACT, atime, mtime);

const after = statSync(EXTRACT).size;
const mb = (v) => (v / 1024 / 1024).toFixed(0);
console.log("");
console.log(`Pronto em ${((Date.now() - started) / 1000).toFixed(1)}s.`);
console.log(`  antes  : ${mb(before)} MB`);
console.log(`  depois : ${mb(after)} MB`);
console.log("");
console.log("Para servir esse arquivo a um deploy sem disco, suba-o para uma");
console.log("URL pública e aponte PROSPECTOR_EXTRACT_URL para ela.");
process.exit(0);
