#!/usr/bin/env node
/**
 * Build the local B2B company extract that /prospector/b2b queries.
 *
 * Run: npm run sync:b2b                    (from Website/)
 *      npm run sync:b2b -- --countries DE,AT,CH
 *      npm run sync:b2b -- --all-countries
 *      npm run sync:b2b -- --universal --countries DE,AT,CH
 *
 * Why it exists: Overture places is one unpartitioned set of Parquet files
 * covering the planet, so querying it over S3 per search measured minutes and
 * was wildly variable. Pulling the countries and categories we actually
 * prospect, once, turns discovery into a sub-second local scan.
 *
 * Why it is a *different* file from the prospector's `places.parquet`: that
 * one is Brazil-only, keeps businesses *without* a website, and has no country
 * or postcode column. This one is multi-country, keeps only records that have a
 * website (the crawler's entry point) and is filtered to the industrial and
 * wholesale categories in `src/lib/b2b/sectors.ts`.
 *
 * Re-run it when Overture publishes a release (roughly monthly) or when you add
 * a sector — new categories are not in the existing extract and would silently
 * return nothing. The manifest records the exact category list for that reason,
 * so /prospector/b2b can mark the profiles the current file cannot answer for
 * instead of returning zero companies and letting it read as an empty market.
 */
import {
  mkdirSync,
  existsSync,
  readFileSync,
  renameSync,
  statSync,
  unlinkSync,
  writeFileSync,
} from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { DuckDBInstance } from "@duckdb/node-api";
import { SECTORS, allSectorCategories } from "../../src/lib/b2b/sectors.ts";
import { COUNTRIES, EUROPE, unionBbox } from "../../src/lib/b2b/countries.ts";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..", "..");

const RELEASE = process.env.OVERTURE_RELEASE ?? "2026-07-22.0";
const SOURCE = `s3://overturemaps-us-west-2/release/${RELEASE}/theme=places/type=place/*`;

// --- what to pull -----------------------------------------------------------

const args = process.argv.slice(2);
const argValue = (name) => {
  const flag = `--${name}`;
  const index = args.indexOf(flag);
  if (index >= 0 && args[index + 1]) return args[index + 1];
  const inline = args.find((a) => a.startsWith(`${flag}=`));
  return inline ? inline.slice(flag.length + 1) : null;
};

const requested = argValue("countries");
const universal = args.includes("--universal");
const countries = args.includes("--all-countries")
  ? COUNTRIES.map((c) => c.code)
  : requested
    ? requested
        .split(",")
        .map((c) => c.trim().toUpperCase())
        .filter(Boolean)
    : EUROPE;

const unknown = countries.filter(
  (code) => !COUNTRIES.some((c) => c.code === code),
);
if (unknown.length > 0) {
  console.error(`Países desconhecidos: ${unknown.join(", ")}`);
  console.error(`Disponíveis: ${COUNTRIES.map((c) => c.code).join(", ")}`);
  process.exit(1);
}

const categories = allSectorCategories();
for (const category of categories) {
  if (!/^[a-z0-9_]+$/.test(category)) {
    throw new Error(`Categoria inválida em sectors.ts: ${category}`);
  }
}

/**
 * Cross-check every category against the live vocabulary before spending twenty
 * minutes on a download. An invented category matches nothing and fails
 * silently, which reads as "no companies in this sector" — the single worst bug
 * class in this tool, and the reason the prospector has the same rule.
 */
const vocabularyPath = path.join(
  root,
  "src",
  "data",
  "prospector",
  "overture-categories.csv",
);
if (existsSync(vocabularyPath)) {
  const known = new Set(
    readFileSync(vocabularyPath, "utf8")
      .split(/\r?\n/)
      .slice(1)
      .map((line) => line.split(",")[0]?.trim())
      .filter(Boolean),
  );
  const missing = categories.filter((c) => !known.has(c));
  if (missing.length > 0) {
    console.warn("");
    console.warn("AVISO: categorias fora do vocabulário conhecido:");
    for (const category of missing) console.warn(`  - ${category}`);
    console.warn(
      "Elas não vão casar com nada. Confira src/lib/b2b/sectors.ts.",
    );
    console.warn("");
  }
}

// One rectangle around every selected country, so Parquet row-group statistics
// can prune. It always over-selects — the country filter below is what makes
// the result correct, not this.
const bbox = unionBbox(countries);

const outDir = path.join(root, "data");
const out = path.join(outDir, "b2b-companies.parquet");
// Written to a temp path and renamed, so an interrupted run can't leave a
// truncated Parquet file the app would then fail to open.
const tmp = `${out}.partial`;

mkdirSync(outDir, { recursive: true });
if (existsSync(tmp)) unlinkSync(tmp);

console.log(`Overture release : ${RELEASE}`);
console.log(
  universal
    ? "Escopo           : universal (todas as empresas com site)"
    : `Setores          : ${SECTORS.length} (${categories.length} categorias)`,
);
console.log(`Países           : ${countries.length} — ${countries.join(", ")}`);
console.log(`Saída            : ${out}`);
console.log("");
console.log(
  "Varrendo o Overture no S3. Isso baixa alguns GB de Parquet e leva",
);
console.log("de 5 a 25 minutos conforme a conexão. Roda uma vez por release.");
console.log("");

const started = Date.now();
const instance = await DuckDBInstance.create(":memory:");
const db = await instance.connect();

await db.run("INSTALL httpfs");
await db.run("LOAD httpfs");
await db.run("SET s3_region='us-west-2'");
// Public bucket: blank the credentials or DuckDB signs with ambient AWS env vars and 403s.
await db.run("SET s3_access_key_id=''");
await db.run("SET s3_secret_access_key=''");
// We re-sort on write anyway; not preserving order lets DuckDB stream in parallel.
await db.run("SET preserve_insertion_order=false");

const categoryFilter = universal
  ? ""
  : `AND categories.primary IN (${categories.map((c) => `'${c}'`).join(", ")})`;
const quotedCountries = countries.map((c) => `'${c}'`).join(", ");

await db.run(
  `COPY (
     SELECT
       id,
       names.primary            AS name,
       categories.primary       AS category,
       addresses[1].freeform    AS address,
       trim(addresses[1].locality) AS city,
       addresses[1].region      AS region,
       upper(addresses[1].country) AS country,
       addresses[1].postcode    AS postcode,
       phones[1]                AS phone,
       websites[1]              AS website,
       emails[1]                AS email,
       ((bbox.xmin + bbox.xmax) / 2)::FLOAT AS lon,
       ((bbox.ymin + bbox.ymax) / 2)::FLOAT AS lat,
       confidence::FLOAT        AS confidence
     FROM read_parquet('${SOURCE}', hive_partitioning = 1)
     WHERE bbox.xmin BETWEEN ${bbox.xmin} AND ${bbox.xmax}
       AND bbox.ymin BETWEEN ${bbox.ymin} AND ${bbox.ymax}
       -- The box is a rectangle around every selected country and spills across
       -- every border it touches; this is what makes the extract the countries
       -- that were asked for.
       AND upper(addresses[1].country) IN (${quotedCountries})
       ${categoryFilter}
       AND names.primary IS NOT NULL
       -- The website is the crawler's entry point. A company without one cannot
       -- be prospected by this tool at all, so carrying it would only inflate
       -- the file and the scan.
       AND websites[1] IS NOT NULL
       AND websites[1] <> ''
     -- Clusters each country into contiguous row groups, so a single-country
     -- query touches a handful of them instead of the whole file.
     ORDER BY country, city
   ) TO '${tmp.replace(/'/g, "''")}' (FORMAT PARQUET, COMPRESSION ZSTD)`,
);

renameSync(tmp, out);

const stats = await db.runAndReadAll(
  `SELECT count(*) AS n_rows,
          count(DISTINCT lower(regexp_replace(regexp_replace(website, '^https?://', ''), '^www\\.', ''))) AS domains,
          count(DISTINCT country) AS countries,
          count(*) FILTER (WHERE email IS NOT NULL AND email <> '') AS with_email
   FROM read_parquet('${out.replace(/'/g, "''")}')`,
);
const s = stats.getRowObjectsJS()[0];
const mb = (statSync(out).size / 1024 / 1024).toFixed(0);
const mins = ((Date.now() - started) / 60000).toFixed(1);
const fmt = (v) => Number(v).toLocaleString("pt-BR");

// Nothing about a Parquet file records which release it came from, so without
// this a bumped OVERTURE_RELEASE leaves the app reporting one release in the
// header while querying an extract built from another.
writeFileSync(
  path.join(outDir, "extract-b2b.json"),
  JSON.stringify(
    {
      release: RELEASE,
      countries,
      rows: Number(s.n_rows),
      domains: Number(s.domains),
      categories: categories.length,
      // The list, not only the count. This is what lets the app tell a sector
      // that returns nothing because there are no chemical plants in Portugal
      // apart from one added to sectors.ts after this file was built — which
      // matches nothing and looks identical. `uncoveredSectors()` reads it;
      // without it the app cannot answer the question at all and says so.
      categoryList: universal ? [] : categories,
      scope: universal ? "universal" : "sectors",
      builtAt: new Date().toISOString(),
    },
    null,
    2,
  ),
);

console.log("");
console.log(`Pronto em ${mins} min.`);
console.log(`  empresas       : ${fmt(s.n_rows)}`);
console.log(`  domínios únicos: ${fmt(s.domains)}`);
console.log(`  países         : ${fmt(s.countries)}`);
console.log(`  já com e-mail  : ${fmt(s.with_email)} (o crawler acha o resto)`);
console.log(`  arquivo        : ${mb} MB`);
console.log("");
console.log("Abra /prospector/b2b e escolha um perfil de busca.");
