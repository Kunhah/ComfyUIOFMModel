#!/usr/bin/env node
/**
 * Build the local places extract that the app queries.
 *
 * Run: npm run sync                                (from Website/) — Brazil, or PROSPECTOR_COUNTRIES
 *      npm run sync -- --countries PT,ES,DE        — those countries
 *      npm run sync -- --region "Europa Ocidental" — a whole part of the world
 *      npm run sync -- --add --countries MX        — keep what is there, add Mexico
 *      npm run sync -- --list                      — what can be asked for
 *
 * Why this exists: the Overture places dataset is a single unpartitioned set of
 * Parquet files covering the planet. Querying it over S3 per search measured
 * 90s–230s and was wildly variable, because row-group pruning still requires
 * fetching metadata for everything. Pulling the countries we prospect once,
 * filtered to the categories we actually sell to, turns every subsequent search
 * into a local sub-second scan.
 *
 * Re-run it when Overture publishes a new release (roughly monthly), when you
 * add a niche to src/lib/prospector/niches.ts — new categories are not in the
 * existing extract and would silently return nothing — or when you want to
 * prospect somewhere the extract doesn't cover yet.
 *
 * Every run is followed by `npm run cities`, which rebuilds the searchable city
 * index from whatever this wrote.
 */
import {
  mkdirSync,
  existsSync,
  renameSync,
  statSync,
  unlinkSync,
  writeFileSync,
  readFileSync,
} from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { DuckDBInstance } from "@duckdb/node-api";
import { NICHES, allCategories } from "../../src/lib/prospector/niches.ts";
import {
  COUNTRIES,
  WORLD_REGIONS,
  countriesInRegion,
  normaliseCountries,
  unionBbox,
} from "../../src/lib/countries.ts";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..", "..");

const RELEASE = process.env.OVERTURE_RELEASE ?? "2026-07-22.0";
const SOURCE = `s3://overturemaps-us-west-2/release/${RELEASE}/theme=places/type=place/*`;

const argv = process.argv.slice(2);
const flag = (name) => {
  const i = argv.indexOf(`--${name}`);
  return i >= 0 ? (argv[i + 1] ?? "") : null;
};
const has = (name) => argv.includes(`--${name}`);

if (has("list")) {
  console.log("Países disponíveis (--countries):");
  for (const region of WORLD_REGIONS) {
    const inRegion = COUNTRIES.filter((c) => c.region === region);
    if (inRegion.length === 0) continue;
    console.log(`\n  ${region}`);
    for (const c of inRegion) console.log(`    ${c.code}  ${c.label}`);
  }
  console.log("\nRegiões (--region):");
  for (const region of WORLD_REGIONS) console.log(`  "${region}"`);
  process.exit(0);
}

// The 27 federative units. Overture's `region` is free text: it arrives as "MG",
// sometimes "BR-MG", and sometimes as junk ("X", "S", a full state name, or a
// foreign province). Anything not on this list becomes NULL rather than being
// kept as a bogus state code that no city could ever match.
//
// Brazil gets a whitelist and nowhere else does, because Brazil is the only
// country whose state codes we can enumerate with confidence and the only one
// where records habitually smuggle the state into the city field. Everywhere
// else the region is normalised and kept as-is; it is an opaque grouping key
// for the city index, not something anybody types.
const UFS = [
  "AC",
  "AL",
  "AM",
  "AP",
  "BA",
  "CE",
  "DF",
  "ES",
  "GO",
  "MA",
  "MG",
  "MS",
  "MT",
  "PA",
  "PB",
  "PE",
  "PI",
  "PR",
  "RJ",
  "RN",
  "RO",
  "RR",
  "RS",
  "SC",
  "SE",
  "SP",
  "TO",
];

const outDir = path.join(root, "data");
const out = path.join(outDir, "places.parquet");
const legacy = path.join(outDir, "br-leads.parquet");
const manifestPath = path.join(outDir, "extract.json");
// Write to a temp path and rename, so an interrupted run can't leave a truncated
// Parquet file behind that the app would then fail to open.
const tmp = `${out}.partial`;

/** What the extract already covers, so `--add` can widen it instead of replacing it. */
function existingCountries() {
  try {
    const manifest = JSON.parse(readFileSync(manifestPath, "utf8"));
    if (Array.isArray(manifest.countries)) {
      return normaliseCountries(manifest.countries);
    }
    // A manifest written before the sync learned about countries described a
    // Brazil-only extract, which is what those builds were.
    return ["BR"];
  } catch {
    return [];
  }
}

const asked = [
  ...(flag("countries") ?? "").split(","),
  ...(flag("country") ?? "").split(","),
  ...(flag("region") ? countriesInRegion(flag("region")) : []),
  // A deploy should not have to patch this script every time the Overture
  // release changes just to keep its international market enabled. CLI flags
  // remain authoritative: the environment is only the default when no country
  // was requested explicitly.
  ...(flag("countries") || flag("country") || flag("region")
    ? []
    : (process.env.PROSPECTOR_COUNTRIES ?? "").split(",")),
].filter((c) => c.trim().length > 0);

if (flag("region") && countriesInRegion(flag("region")).length === 0) {
  console.error(
    `Região desconhecida: ${flag("region")}\nRode --list para ver as opções.`,
  );
  process.exit(1);
}

let countries = has("all-countries")
  ? COUNTRIES.map((c) => c.code)
  : normaliseCountries(asked);

// `--add` keeps whatever is already covered. Without it a sync replaces the
// extract, which is the behaviour you want when narrowing it back down.
if (has("add")) {
  countries = normaliseCountries([...existingCountries(), ...countries]);
}

// The default is Brazil, unchanged from when that was the only option — an
// existing setup that runs `npm run sync` on a new release gets what it had.
if (countries.length === 0) countries = ["BR"];

const unknown = asked
  .map((c) => c.trim().toUpperCase())
  .filter((c) => c.length > 0 && !countries.includes(c));
if (unknown.length > 0) {
  console.error(
    `Países desconhecidos, ignorados: ${unknown.join(", ")}\n` +
      "Rode --list para ver os códigos aceitos.",
  );
}

// From the registry's own reverse map, which is also what guarantees no category
// is claimed by two niches.
const categories = allCategories();
for (const c of categories) {
  if (!/^[a-z0-9_]+$/.test(c))
    throw new Error(`Invalid category in niches.ts: ${c}`);
}

// The union box only exists so Parquet row-group statistics can skip the rest of
// the planet. It is *not* a country filter — every box is a rectangle and spills
// over its borders, and a union of two distant countries covers everything in
// between — which is why `addresses[1].country IN (…)` below is required.
const BBOX = unionBbox(countries);

mkdirSync(outDir, { recursive: true });
if (existsSync(tmp)) unlinkSync(tmp);

const label = (code) => COUNTRIES.find((c) => c.code === code)?.label ?? code;

console.log(`Overture release : ${RELEASE}`);
console.log(
  `Países           : ${countries.length} (${countries.map(label).join(", ")})`,
);
console.log(
  `Nichos           : ${NICHES.length} (${categories.length} categorias)`,
);
console.log(`Saída            : ${out}`);
console.log("");
console.log(
  "Varrendo o Overture no S3. Isso baixa alguns GB de Parquet e leva de 5 a 20",
);
console.log(
  "minutos por país, dependendo da conexão. Roda uma vez por release.",
);
console.log("");

const started = Date.now();
const instance = await DuckDBInstance.create(":memory:");
const db = await instance.connect();

await db.run("INSTALL httpfs");
await db.run("LOAD httpfs");
await db.run("SET s3_region='us-west-2'");
// Public bucket: blank the credentials or DuckDB signs with ambient AWS env vars and 403s.
await db.run("SET s3_access_key_id=''");
await db.run("SET s3_secret_access_key=''");
// We re-sort on write anyway; not preserving order lets DuckDB stream in parallel.
await db.run("SET preserve_insertion_order=false");

const quoted = categories.map((c) => `'${c}'`).join(", ");
const quotedUfs = UFS.map((u) => `'${u}'`).join(", ");
const quotedCountries = countries.map((c) => `'${c}'`).join(", ");

const countryExpr = `upper(addresses[1].country)`;

// Normalised region: the ISO subdivision code with its country prefix removed
// ("DE-BY" -> "BY"), upper-cased, accents stripped. Whatever Overture happens to
// carry for a country — a code, a numbered district, a province name — becomes a
// stable grouping key for the city index. Trimmed to 24 characters so a record
// with a full postal address in the field can't become its own "state".
const regionRaw = `nullif(trim(coalesce(addresses[1].region, '')), '')`;
const regionGeneric = `nullif(upper(strip_accents(regexp_replace(${regionRaw}, '^[A-Za-z]{2}-', ''))), '')`;

// Brazil only. Overture's region field for BR is a two-letter code often written
// as "BR-MG", and anything off the list is junk.
const ufExpr = `nullif(upper(replace(coalesce(addresses[1].region, ''), 'BR-', '')), '')`;

// Some Brazilian records put the state inside the city field — "Belo Horizonte,
// MG", "São Paulo SP", "Curitiba - PR". Left alone each one becomes its own city
// in the index, a near-duplicate of the real entry holding a handful of
// businesses. Splitting it here both cleans the name and, when `region` was
// empty, recovers the state from it.
const tail = `upper(regexp_extract(trim(addresses[1].locality), '[,\\s-]+([A-Za-z]{2})$', 1))`;
// Only when the two agree, so a contradictory record can't be silently rewritten.
const splittable = `${countryExpr} = 'BR'
       AND ${tail} IN (${quotedUfs})
       AND (${ufExpr} IS NULL OR ${ufExpr} = ${tail})
       AND length(regexp_replace(trim(addresses[1].locality), '[,\\s-]+[A-Za-z]{2}$', '')) >= 3`;

// The city name the search actually matches on, folded once at build time rather
// than per query. A function over a column is opaque to Parquet's row-group
// statistics, so `nrm(city) = '...'` prunes nothing however the file is sorted;
// a plain equality on a sorted column prunes well. Measured on Belo Horizonte
// over HTTP: 9MB and 10 requests against 82MB and 80. That is what makes the
// extract queryable over the network inside a serverless timeout.
//
// It must fold identically to nrm() in src/lib/prospector/overture.ts and
// normalise() in src/lib/prospector/cities.ts.
const nrm = (expr) =>
  `trim(regexp_replace(lower(strip_accents(${expr})), '[^a-z0-9]+', ' ', 'g'))`;

await db.run(
  `COPY (
   SELECT *, ${nrm("city")} AS city_norm FROM (
     SELECT
       id,
       names.primary            AS name,
       categories.primary       AS category,
       addresses[1].freeform    AS address,
       CASE WHEN ${splittable}
            THEN trim(regexp_replace(trim(addresses[1].locality), '[,\\s-]+[A-Za-z]{2}$', ''))
            ELSE trim(addresses[1].locality) END AS city,
       CASE WHEN ${countryExpr} = 'BR' THEN
              CASE WHEN ${ufExpr} IN (${quotedUfs}) THEN ${ufExpr}
                   WHEN ${splittable} THEN ${tail} END
            ELSE substr(${regionGeneric}, 1, 24) END AS uf,
       ${countryExpr}           AS country,
       phones[1]                AS phone,
       websites[1]              AS website,
       socials[1]               AS social,
       emails[1]                AS email,
       ((bbox.xmin + bbox.xmax) / 2)::FLOAT AS lon,
       ((bbox.ymin + bbox.ymax) / 2)::FLOAT AS lat,
       confidence::FLOAT        AS confidence
     FROM read_parquet('${SOURCE}', hive_partitioning = 1)
     WHERE bbox.xmin BETWEEN ${BBOX.xmin} AND ${BBOX.xmax}
       AND bbox.ymin BETWEEN ${BBOX.ymin} AND ${BBOX.ymax}
       -- The union box spills across every border it touches. Without this,
       -- Asunción, Santiago, Córdoba, Santa Cruz de la Sierra and Rosario all
       -- landed in the Brazil extract: measured at 284k foreign businesses, most
       -- with no region set, polluting the city index with cities we can't sell
       -- to. The same is true of every other selection.
       AND ${countryExpr} IN (${quotedCountries})
       AND names.primary IS NOT NULL
       AND addresses[1].locality IS NOT NULL
       AND trim(addresses[1].locality) <> ''
       AND categories.primary IN (${quoted})
   )
   -- Sorting by country then by the folded name clusters each municipality into
   -- contiguous row groups, so a city query touches a handful of them instead of
   -- the whole file. Both columns are ones the query filters on — sorting by
   -- \`city\` while matching on \`city_norm\` would leave the statistics useless
   -- again, and leading with the country keeps a search in Portugal from reading
   -- Brazil's row groups at all.
   ORDER BY country, city_norm, uf
   ) TO '${tmp.replace(/'/g, "''")}' (FORMAT PARQUET, COMPRESSION ZSTD)`,
);

renameSync(tmp, out);

const stats = await db.runAndReadAll(
  `SELECT count(*) AS n_rows,
          count(DISTINCT country) AS countries,
          count(DISTINCT country || '/' || city || '/' || coalesce(uf, '?')) AS cities,
          count(*) FILTER (WHERE website IS NULL OR website = '') AS no_site,
          count(*) FILTER (WHERE uf IS NULL) AS no_uf
   FROM read_parquet('${out.replace(/'/g, "''")}')`,
);
const s = stats.getRowObjectsJS()[0];
const perCountry = (
  await db.runAndReadAll(
    `SELECT country, count(*) AS n,
            count(*) FILTER (WHERE website IS NULL OR website = '') AS no_site
     FROM read_parquet('${out.replace(/'/g, "''")}')
     GROUP BY country ORDER BY n DESC`,
  )
).getRowObjectsJS();
const mb = (statSync(out).size / 1024 / 1024).toFixed(0);
const mins = ((Date.now() - started) / 60000).toFixed(1);
const br = (v) => Number(v).toLocaleString("pt-BR");

// Records which release and which countries this file came from. Nothing about a
// Parquet file says that, so without it a bumped OVERTURE_RELEASE leaves the app
// reporting one release in the header while querying an extract built from
// another, with no way to notice. scripts/prospector/start.mjs reads this and
// warns, and `--add` reads it to know what it is widening.
writeFileSync(
  manifestPath,
  JSON.stringify(
    {
      release: RELEASE,
      countries,
      rows: Number(s.n_rows),
      noWebsite: Number(s.no_site),
      categories: categories.length,
      builtAt: new Date().toISOString(),
    },
    null,
    2,
  ),
);

console.log("");
console.log(`Pronto em ${mins} min.`);
console.log(`  negócios   : ${br(s.n_rows)}`);
console.log(`  países     : ${br(s.countries)}`);
console.log(`  cidades    : ${br(s.cities)}`);
console.log(`  sem site   : ${br(s.no_site)}`);
console.log(`  sem estado : ${br(s.no_uf)} (alcançáveis por bbox + cidade)`);
console.log(`  arquivo    : ${mb} MB`);
console.log("");
for (const row of perCountry) {
  console.log(
    `  ${row.country}  ${label(row.country).padEnd(22)} ${br(row.n).padStart(10)} negócios · ${br(row.no_site)} sem site`,
  );
}

// The old name is still read by the app when it is the only file present, so an
// extract left behind after this one is built would simply be ignored — but it
// is also 100+MB of a dataset that has been superseded, and its presence makes
// "which file is the app reading?" a question rather than a fact.
if (existsSync(legacy)) {
  console.log("");
  console.log(
    `Aviso: ${path.relative(root, legacy)} ainda existe e foi substituído por ` +
      `${path.relative(root, out)}. Pode apagar.`,
  );
}

console.log("");
console.log("Próximo: npm run cities   (reconstrói o índice de cidades)");
