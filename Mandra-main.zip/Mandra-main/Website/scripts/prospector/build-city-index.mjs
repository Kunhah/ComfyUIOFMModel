#!/usr/bin/env node
/**
 * Regenerate src/data/prospector/cities.json — every place name you can actually
 * search, with its country, its bounding box and how many prospectable
 * businesses sit behind it.
 *
 * Run: npm run cities        (from Website/, after npm run sync)
 *
 * This is committed output. Re-run it after every `npm run sync`, since the
 * counts, the set of searchable names and the set of *countries* all come from
 * the extract.
 *
 * Why the extract is the source of truth rather than Overture's division
 * boundaries: the boundaries say what a municipality is *called*, the business
 * records say what their addresses actually *say*, and where those disagree the
 * boundary name is unsearchable. Measured on the previous divisions-only index,
 * 784 localities holding 10.753 businesses could not be reached from the UI at
 * all. Brasília was 9.094 of them — Overture models the Federal District as 35
 * administrative regions (Plano Piloto, Ceilândia, Taguatinga…) and has no
 * locality named "Brasília", while the businesses there say exactly that.
 *
 * Building from the places side makes that whole class of bug impossible: a name
 * is in the index because businesses use it. Divisions are still read, but only
 * to supply nicely typeset display names and to register their spelling as an
 * alias when it differs from what the records say.
 */
import { writeFileSync, existsSync, statSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { DuckDBInstance } from "@duckdb/node-api";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..", "..");
const out = path.join(root, "src", "data", "prospector", "cities.json");

// `places.parquet` is what the current sync writes; `br-leads.parquet` is the
// Brazil-only name it used to write, still read when it is all there is. The app
// resolves the same pair in the same order — see localExtractPath().
const extract = [
  path.join(root, "data", "places.parquet"),
  path.join(root, "data", "br-leads.parquet"),
].find((file) => existsSync(file));

const RELEASE = process.env.OVERTURE_RELEASE ?? "2026-07-22.0";
const DIVISIONS = `s3://overturemaps-us-west-2/release/${RELEASE}/theme=divisions/type=division_area/*`;

/**
 * Alternate spellings, written by hand.
 *
 * This was generated automatically at first, pairing each unused boundary name
 * with its closest unreachable locality (Jaro-Winkler ≥ 0.90, restricted to names
 * that had nothing to lose on either side). It looked principled and was not:
 * of 19 pairs produced, 13 joined genuinely different municipalities —
 * "Capão Bonito do Sul" to "Capão Bonito", "Alagoinha do Piauí" to "Alagoinha",
 * "Santa Rita" to "Santa Luzia". A wrong alias is worse than a missing one,
 * because the search succeeds and quietly returns another town's businesses.
 * Tightening the threshold didn't rescue it either — the case that prompted the
 * whole idea, "Assu" for records spelling it "Açu", scores below every cutoff
 * that excludes the false pairs.
 *
 * So: [alias typed by the user, name in the records, region, country]. Add only
 * pairs you have actually confirmed are one municipality.
 */
const ALIASES = [
  // IBGE writes it "Assu"; the business records say "Açu".
  ["Assu", "Açu", "RN", "BR"],
];

if (!extract) {
  console.error(
    `Extrato ausente em ${path.relative(root, path.join(root, "data", "places.parquet"))} — rode npm run sync primeiro.`,
  );
  process.exit(1);
}

const q = (s) => s.replace(/'/g, "''");
const br = (v) => Number(v).toLocaleString("pt-BR");

console.log(`Overture release : ${RELEASE}`);
console.log(`Extrato          : ${path.relative(root, extract)}`);
console.log(`Saída            : ${path.relative(root, out)}`);
console.log("");

const instance = await DuckDBInstance.create(":memory:");
const db = await instance.connect();
const rows = async (sql) => (await db.runAndReadAll(sql)).getRowObjectsJS();

// Must fold exactly like normalise() in src/lib/prospector/cities.ts: accents and
// punctuation both go, so "São João del-Rei" and "Sao Joao del Rei" agree.
await db.run(`CREATE MACRO nrm(s) AS
  trim(regexp_replace(regexp_replace(lower(strip_accents(s)), '[^a-z0-9]+', ' ', 'g'), '\\s+', ' ', 'g'))`);

// Snap outwards, never inwards. round() can push a bound past the business that
// defined it, and the query filters on `lon BETWEEN xmin AND xmax` — a bound
// rounded the wrong way silently drops the very lead that set it.
await db.run(`CREATE MACRO lo(v) AS floor(v * 10000) / 10000`);
await db.run(`CREATE MACRO hi(v) AS ceil(v * 10000) / 10000`);

const NOSITE = `count(*) FILTER (WHERE website IS NULL OR website = '')`;

// An extract built before the sync learned `--countries` has no country column
// and is Brazil in its entirety, which is what it was built as.
const columns = await rows(
  `SELECT column_name FROM (DESCRIBE SELECT * FROM read_parquet('${q(extract)}'))`,
);
const hasCountry = columns.some((c) => c.column_name === "country");
const countryExpr = hasCountry ? "upper(country)" : "'BR'";
if (!hasCountry) {
  console.log("Extrato sem coluna `country`: tratando tudo como Brasil.");
  console.log("");
}

await db.run(`CREATE TABLE ext AS
  SELECT nrm(city) AS n, uf, ${countryExpr} AS country,
         city AS raw, website, lon, lat
  FROM read_parquet('${q(extract)}')
  WHERE city IS NOT NULL AND lon IS NOT NULL AND lat IS NOT NULL`);

const countries = (
  await rows("SELECT DISTINCT country FROM ext ORDER BY country")
).map((r) => r.country);
console.log(`Países no extrato: ${countries.join(", ")}`);
console.log("");

// Localities that name a region. These are the queryable units.
await db.run(`CREATE TABLE grp AS
  SELECT country, n, uf,
         mode(raw) AS display,          -- most common spelling, so accents survive
         count(*) AS biz, ${NOSITE} AS nosite,
         lo(min(lon)) AS xmin, hi(max(lon)) AS xmax,
         lo(min(lat)) AS ymin, hi(max(lat)) AS ymax
  FROM ext WHERE uf IS NOT NULL GROUP BY country, n, uf`);

// Rows whose address gave a city but no region. The query reaches them with
// `uf IS NULL` once country, bbox and locality already match, so fold their
// counts and extent into the city they belong to — but only when the name occurs
// in exactly one region of that country, otherwise "Santa Luzia" would be
// credited to all of them.
await db.run(`CREATE TABLE nouf AS
  SELECT country, n, count(*) AS biz, ${NOSITE} AS nosite,
         lo(min(lon)) AS xmin, hi(max(lon)) AS xmax,
         lo(min(lat)) AS ymin, hi(max(lat)) AS ymax
  FROM ext WHERE uf IS NULL GROUP BY country, n`);
await db.run(`CREATE TABLE unique_names AS
  SELECT country, n FROM grp GROUP BY country, n HAVING count(*) = 1`);

// Narrowed to unambiguous names up front: DuckDB can't take a subquery in a
// LEFT JOIN condition, and folding the filter into the join would silently
// become an inner join if written carelessly.
await db.run(`CREATE TABLE nouf_unique AS
  SELECT u.* FROM nouf u
  WHERE EXISTS (SELECT 1 FROM unique_names k
                WHERE k.country = u.country AND k.n = u.n)`);

// Whole countries can arrive with no readable region at all — Overture's region
// field is free text and for some of them it is empty on every record. Those
// cities would otherwise vanish from the index, since `grp` only holds rows that
// named a region. They enter with an empty region and are matched on country,
// locality and bbox alone, which is what the query does when the city carries no
// state code.
await db.run(`CREATE TABLE noregion_only AS
  SELECT u.* FROM nouf u
  WHERE NOT EXISTS (SELECT 1 FROM grp g WHERE g.country = u.country AND g.n = u.n)`);

await db.run(`CREATE TABLE merged AS
  SELECT g.country, g.n, g.uf, g.display,
         g.biz + coalesce(u.biz, 0) AS biz,
         g.nosite + coalesce(u.nosite, 0) AS nosite,
         least(g.xmin, coalesce(u.xmin, g.xmin)) AS xmin,
         greatest(g.xmax, coalesce(u.xmax, g.xmax)) AS xmax,
         least(g.ymin, coalesce(u.ymin, g.ymin)) AS ymin,
         greatest(g.ymax, coalesce(u.ymax, g.ymax)) AS ymax
  FROM grp g
  LEFT JOIN nouf_unique u ON u.country = g.country AND u.n = g.n
  UNION ALL
  SELECT r.country, r.n, '' AS uf,
         (SELECT mode(e.raw) FROM ext e
          WHERE e.country = r.country AND e.n = r.n) AS display,
         r.biz, r.nosite, r.xmin, r.xmax, r.ymin, r.ymax
  FROM noregion_only r`);

// --- divisions: display names, authoritative extents, alias spellings ---------
await db.run("INSTALL httpfs");
await db.run("LOAD httpfs");
await db.run("SET s3_region='us-west-2'");
// Public bucket: blank the credentials or DuckDB signs with ambient AWS env vars and 403s.
await db.run("SET s3_access_key_id=''");
await db.run("SET s3_secret_access_key=''");

const quotedCountries = countries.map((c) => `'${q(c)}'`).join(", ");

// The region has to be folded the same way `sync-places.mjs` folds the places
// side, or the join finds nothing and every city keeps the records' own
// spelling. Brazil is the one country with a two-letter code we trust; the rest
// are normalised generically.
const divRegion = `CASE WHEN upper(country) = 'BR'
       THEN nullif(upper(replace(coalesce(region, ''), 'BR-', '')), '')
       ELSE substr(nullif(upper(strip_accents(regexp_replace(nullif(trim(coalesce(region, '')), ''), '^[A-Za-z]{2}-', ''))), ''), 1, 24) END`;

console.log("Lendo os limites administrativos para as grafias canônicas...");
await db.run(`CREATE TABLE div AS
  SELECT names.primary AS display, nrm(names.primary) AS n,
         upper(country) AS country,
         ${divRegion} AS uf,
         lo(bbox.xmin) AS xmin, hi(bbox.xmax) AS xmax,
         lo(bbox.ymin) AS ymin, hi(bbox.ymax) AS ymax
  FROM read_parquet('${DIVISIONS}', hive_partitioning = 1)
  WHERE upper(country) IN (${quotedCountries})
    AND subtype = 'locality' AND names.primary IS NOT NULL
  -- A locality can appear more than once; keep the largest polygon, which is the
  -- municipality proper rather than a district inside it.
  QUALIFY row_number() OVER (
    PARTITION BY upper(country), nrm(names.primary), ${divRegion}
    ORDER BY (bbox.xmax - bbox.xmin) * (bbox.ymax - bbox.ymin) DESC
  ) = 1`);

// The region-less entries can only be joined on the name, so they take the
// largest polygon of that name in the country. Kept in a separate table because
// joining them the same way as the rest would let a city in one province borrow
// a same-named city's boundary in another.
await db.run(`CREATE TABLE div_by_name AS
  SELECT country, n, any_value(display) AS display,
         min(xmin) AS xmin, max(xmax) AS xmax,
         min(ymin) AS ymin, max(ymax) AS ymax
  FROM div GROUP BY country, n HAVING count(*) = 1`);

const aliasValues = ALIASES.map(
  ([alias, target, uf, country]) =>
    `('${q(alias)}', nrm('${q(target)}'), '${q(uf)}', '${q(country ?? "BR")}')`,
).join(", ");

await db.run(`CREATE TABLE alias AS
  SELECT * FROM (VALUES ${aliasValues}) AS t(alias, target_n, target_uf, target_country)`);

// A curated pair that no longer matches anything is a silent no-op, so surface it
// rather than letting the list rot as the data shifts under it.
const staleAliases = await rows(
  `SELECT a.alias, a.target_uf AS uf, a.target_country AS country FROM alias a
   WHERE NOT EXISTS (SELECT 1 FROM merged m
                     WHERE m.n = a.target_n AND m.uf = a.target_uf
                       AND m.country = a.target_country)`,
);

const aliasPairs = await rows(
  `SELECT a.alias, m.display AS target, a.target_uf AS uf,
          a.target_country AS country, m.biz
   FROM alias a JOIN merged m
     ON m.n = a.target_n AND m.uf = a.target_uf AND m.country = a.target_country
   ORDER BY m.biz DESC`,
);

// Final rows. Division extent is unioned in, never substituted: it is the legal
// boundary, while a business can sit just outside it, and losing that business
// would be worse than a slightly loose box.
const final = await rows(`
  WITH agg AS (
    SELECT target_n AS n, target_uf AS uf, target_country AS country,
           list(alias) AS aliases
    FROM alias GROUP BY 1, 2, 3
  ),
  boundary AS (
    SELECT m.country, m.n, m.uf,
           coalesce(d.display, b.display) AS display,
           coalesce(d.xmin, b.xmin) AS xmin, coalesce(d.xmax, b.xmax) AS xmax,
           coalesce(d.ymin, b.ymin) AS ymin, coalesce(d.ymax, b.ymax) AS ymax
    FROM merged m
    LEFT JOIN div d
      ON d.country = m.country AND d.n = m.n AND d.uf = m.uf AND m.uf <> ''
    LEFT JOIN div_by_name b
      ON b.country = m.country AND b.n = m.n AND m.uf = ''
  )
  SELECT coalesce(d.display, m.display) AS name, m.uf, m.country,
         least(m.xmin, coalesce(d.xmin, m.xmin)) AS xmin,
         greatest(m.xmax, coalesce(d.xmax, m.xmax)) AS xmax,
         least(m.ymin, coalesce(d.ymin, m.ymin)) AS ymin,
         greatest(m.ymax, coalesce(d.ymax, m.ymax)) AS ymax,
         m.biz, m.nosite, coalesce(a.aliases, []) AS aliases
  FROM merged m
  LEFT JOIN boundary d
    ON d.country = m.country AND d.n = m.n AND d.uf = m.uf
  LEFT JOIN agg a
    ON a.country = m.country AND a.n = m.n AND a.uf = m.uf
  ORDER BY m.biz DESC
`);

// The tuple layout is documented by the `Row` type in
// src/lib/prospector/cities.ts. Aliases stay last and optional — one city in
// thousands has any, and a null in every other row costs more than it says.
const tuples = final.map((r) => {
  const t = [
    r.name,
    r.uf ?? "",
    Number(r.xmin),
    Number(r.xmax),
    Number(r.ymin),
    Number(r.ymax),
    Number(r.biz),
    Number(r.nosite),
    r.country,
  ];
  const aliases = (r.aliases ?? []).filter((a) => a);
  if (aliases.length > 0) t.push(aliases);
  return t;
});

writeFileSync(out, JSON.stringify(tuples));

// --- report -------------------------------------------------------------------
const [stat] = await rows(`SELECT
  (SELECT count(*) FROM merged) AS cities,
  (SELECT sum(biz) FROM merged) AS biz,
  (SELECT sum(nosite) FROM merged) AS nosite,
  (SELECT count(*) FROM ext) AS ext_rows,
  (SELECT coalesce(sum(u.biz), 0) FROM nouf u
     WHERE NOT EXISTS (SELECT 1 FROM unique_names k
                       WHERE k.country = u.country AND k.n = u.n)
       AND EXISTS (SELECT 1 FROM grp g
                   WHERE g.country = u.country AND g.n = u.n)) AS orphan_nouf,
  (SELECT count(*) FROM div d WHERE NOT EXISTS (
     SELECT 1 FROM merged m
     WHERE m.country = d.country AND m.n = d.n AND m.uf = d.uf)) AS empty_divisions`);

const kb = (statSync(out).size / 1024).toFixed(0);
const reachable = Number(stat.biz);
const extRows = Number(stat.ext_rows);

console.log("");
console.log(`Gravadas ${br(stat.cities)} localidades pesquisáveis (${kb} KB).`);
console.log(
  `  negócios alcançáveis : ${br(reachable)} de ${br(extRows)} no extrato`,
);
console.log(`  sem site             : ${br(stat.nosite)}`);
console.log(
  `  inalcançáveis        : ${br(extRows - reachable)} (nome de cidade ambíguo, sem região)`,
);
console.log(
  `  sem região, deixados : ${br(Number(stat.orphan_nouf))} (nome repetido em mais de uma região)`,
);
console.log(
  `  limites sem negócios : ${br(stat.empty_divisions)} (fora do índice — completariam para zero resultados)`,
);

const byCountry = await rows(
  `SELECT country, count(*) AS cities, sum(biz) AS biz, sum(nosite) AS nosite
   FROM merged GROUP BY country ORDER BY biz DESC`,
);
console.log("");
for (const row of byCountry) {
  console.log(
    `  ${row.country}  ${br(row.cities).padStart(7)} cidades · ${br(row.biz).padStart(11)} negócios · ${br(row.nosite)} sem site`,
  );
}

if (aliasPairs.length > 0) {
  console.log("");
  console.log(`Grafias alternativas (${aliasPairs.length}):`);
  for (const a of aliasPairs) {
    console.log(
      `  ${a.alias} -> ${a.target}/${a.uf} (${a.country})  (${br(a.biz)} negócios)`,
    );
  }
}

if (staleAliases.length > 0) {
  console.log("");
  console.log("Aliases obsoletos em ALIASES — o alvo não está mais nos dados:");
  for (const a of staleAliases)
    console.log(`  ${a.alias}/${a.uf} (${a.country})`);
}
