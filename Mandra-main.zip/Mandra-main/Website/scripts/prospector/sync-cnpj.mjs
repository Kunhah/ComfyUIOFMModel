#!/usr/bin/env node
/**
 * Build the local CNPJ extract: marketing and advertising firms taken from the
 * Receita Federal's open company registry.
 *
 * Run: npm run sync:cnpj                    — the newest month published
 *      npm run sync:cnpj -- --month 2026-07 — a specific month
 *      npm run sync:cnpj -- --list          — what months are on offer
 *
 * Why this exists, when `places.parquet` already covers marketing categories:
 * a map only holds businesses with a mapped storefront, and the trade we want
 * to partner with largely has none. A gestor de tráfego works from home for
 * clients in four states; Overture has never heard of them, and no amount of
 * category tuning invents a POI that was never surveyed. The Receita has heard
 * of every one of them that formalised, because it is what formalising *is*.
 *
 * Measured on one of the ten Estabelecimentos parts (2026-08): 5.997 active
 * establishments under the precise CNAEs, of which 90,6% carry an e-mail and
 * 99% a telephone. The map route's equivalent is a fraction of that, and the
 * contact fields on a POI are whatever a surveyor happened to see on a door.
 *
 * This does NOT replace `npm run sync`. The two extracts answer different
 * questions and are queried separately — see `cnpj.ts` next to `overture.ts`.
 *
 * Re-run it monthly, when the Receita publishes, or after changing the `cnaes`
 * / `broadCnaes` of a niche: like the Overture extract, a code that isn't in
 * the file returns nothing and reads as "there are none of these in Brazil".
 */
import {
  closeSync,
  mkdirSync,
  existsSync,
  openSync,
  readSync,
  renameSync,
  rmSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { execFileSync } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { DuckDBInstance } from "@duckdb/node-api";
import {
  MARKETING_NAME,
  broadCnaes,
  preciseCnaes,
} from "../../src/lib/prospector/niches.ts";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..", "..");
const dataDir = path.join(root, "data");
const workDir = path.join(dataDir, "cnpj-src");
const target = path.join(dataDir, "cnpj.parquet");

const argv = process.argv.slice(2);
const flag = (name) => {
  const i = argv.indexOf(`--${name}`);
  return i >= 0 ? (argv[i + 1] ?? "") : null;
};

/**
 * Which of the ten Estabelecimentos/Empresas parts to read. All of them, unless
 * asked otherwise.
 *
 * `--parts 1` exists so the whole pipeline can be exercised end to end against
 * ~2GB instead of ~7GB — the joins, the name rule, the output schema and the
 * app's read path are all the same, only the establishment base is a tenth of
 * the size. Use it to check a change works before committing an hour to the
 * full run; never to build a real extract, which is why the metadata records it.
 *
 * It limits *Estabelecimentos* only. Empresas is always read in full, because
 * the two tables' ten parts are partitioned independently: part 1 of one does
 * not hold the same companies as part 1 of the other, and pairing them drops
 * 98% of the sample on the razão social join — measured, 24.213 establishments
 * in, 409 rows out. A sample that small says nothing about anything.
 */
const PARTS = (() => {
  const raw = flag("parts");
  if (raw === null) return [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  const parts = raw
    .split(",")
    .map((n) => Number(n.trim()))
    .filter((n) => Number.isInteger(n) && n >= 0 && n <= 9);
  if (parts.length === 0) throw new Error("--parts espera números de 0 a 9.");
  return parts;
})();
const partial = PARTS.length < 10;

/**
 * The Receita moved these files onto a Nextcloud public share in Jan/2026, so
 * the "directory" is a WebDAV collection behind an opaque share token. The
 * token is not documented anywhere and has changed before; it is therefore
 * overridable without editing this file, and a failure to list says so rather
 * than reporting an empty month list.
 */
const SHARE = process.env.CNPJ_SHARE_TOKEN?.trim() || "YggdBLfdninEJX9";
const DAV = `https://arquivos.receitafederal.gov.br/public.php/dav/files/${SHARE}`;

async function propfind(url) {
  const response = await fetch(url, {
    method: "PROPFIND",
    headers: { Depth: "1" },
  });
  if (!response.ok) {
    throw new Error(
      `PROPFIND ${url} respondeu ${response.status}. O share token da Receita ` +
        `provavelmente mudou — descubra o novo e rode com ` +
        `CNPJ_SHARE_TOKEN=<token> npm run sync:cnpj`,
    );
  }
  return response.text();
}

async function months() {
  const xml = await propfind(`${DAV}/`);
  const found = [...xml.matchAll(/\/([0-9]{4}-[0-9]{2})\/<\/d:href>/g)].map(
    (m) => m[1],
  );
  return [...new Set(found)].sort();
}

/** Every .zip in a month, with its size, so a resumed run can skip what it has. */
async function filesIn(month) {
  const xml = await propfind(`${DAV}/${month}/`);
  const out = new Map();
  const re =
    /<d:href>([^<]*?([^/]+\.zip))<\/d:href>[\s\S]*?<d:getcontentlength>(\d+)</g;
  for (const m of xml.matchAll(re)) out.set(m[2], Number(m[3]));
  return out;
}

const available = await months();
if (available.length === 0) {
  throw new Error("Nenhum mês encontrado no share da Receita.");
}
if (argv.includes("--list")) {
  console.log(available.join("\n"));
  process.exit(0);
}
const month = flag("month") || available[available.length - 1];
if (!available.includes(month)) {
  throw new Error(
    `Mês ${month} não publicado. Disponíveis: ${available.join(", ")}`,
  );
}

const remote = await filesIn(month);
// Sócios is deliberately not downloaded. It is the register of natural persons
// behind each company, we have no use for it here, and pulling a table of
// names and CPF fragments we will never read is not a neutral act.
const ALL_PARTS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
const expected = [
  ...PARTS.map((n) => `Estabelecimentos${n}.zip`),
  ...ALL_PARTS.map((n) => `Empresas${n}.zip`),
  "Simples.zip",
  "Municipios.zip",
];
const wanted = expected.filter((name) => remote.has(name));
if (wanted.length < expected.length) {
  const missing = expected.filter((name) => !remote.has(name));
  throw new Error(
    `Mês ${month} não tem ${missing.join(", ")} — provavelmente ainda está ` +
      `sendo publicado. Rode --list e tente o mês anterior.`,
  );
}

mkdirSync(workDir, { recursive: true });
console.log(`Receita CNPJ    : ${month}`);
console.log(`Arquivos        : ${wanted.length}`);
console.log(
  `Download        : ${(
    wanted.reduce((n, f) => n + remote.get(f), 0) / 1e9
  ).toFixed(1)} GB`,
);

for (const name of wanted) {
  const dest = path.join(workDir, name);
  const size = remote.get(name);
  // Size-matched rather than existence-matched: a run killed mid-download
  // leaves a short file that unzips to a truncated CSV, and a truncated CSV is
  // a silently smaller base rather than an error.
  if (existsSync(dest) && statSync(dest).size === size) continue;
  process.stdout.write(`  ${name} … `);
  const response = await fetch(`${DAV}/${month}/${name}`);
  if (!response.ok) throw new Error(`${name}: HTTP ${response.status}`);
  writeFileSync(dest, Buffer.from(await response.arrayBuffer()));
  console.log(`${(statSync(dest).size / 1e6).toFixed(0)} MB`);
}

/**
 * Unzip one archive and re-encode it as UTF-8.
 *
 * Two things the Receita's files do that a plain reader does not survive. They
 * are cp1252, not UTF-8; and they contain a handful of bytes that are valid in
 * neither cp1252 nor latin-1 (0x8F appears inside an e-mail field), which makes
 * DuckDB's own `encoding='latin-1'` refuse the whole file. `iconv -c` drops
 * exactly those bytes and keeps every row, which is the right trade for a
 * corrupt character in one address out of five million.
 */
function extract(zipName) {
  const csv = path.join(workDir, `${zipName}.csv`);
  if (existsSync(csv)) return csv;
  execFileSync("unzip", [
    "-o",
    "-q",
    path.join(workDir, zipName),
    "-d",
    workDir,
  ]);
  const inner = execFileSync("unzip", ["-Z1", path.join(workDir, zipName)])
    .toString()
    .trim()
    .split("\n")[0];
  const raw = path.join(workDir, inner);
  // `iconv -c` exits 1 whenever it drops a character, which for these files is
  // always — that is what -c is for. Its status therefore says nothing, and the
  // conversion has to be checked rather than trusted. A complete CSV ends with a
  // newline; a run killed halfway ends mid-record, which would otherwise enter
  // the extract as a truncated final row and a quietly smaller base.
  //
  // Run without a shell, writing straight into an opened descriptor. The
  // Receita names several of these files `F.K03200$Z.D60808.…`, and inside a
  // double-quoted shell word `$Z` expands to nothing — so a shell redirect
  // silently converts a file that does not exist and leaves an empty output.
  const out = openSync(csv, "w");
  try {
    execFileSync("iconv", ["-c", "-f", "WINDOWS-1252", "-t", "UTF-8", raw], {
      stdio: ["ignore", out, "ignore"],
      maxBuffer: Infinity,
    });
  } catch {
    // Swallowed deliberately — see above. The check below is the real one.
  } finally {
    closeSync(out);
  }
  rmSync(raw, { force: true });
  const size = statSync(csv).size;
  if (size === 0) throw new Error(`${zipName}: conversão vazia`);
  const fd = openSync(csv, "r");
  const last = Buffer.alloc(1);
  readSync(fd, last, 0, 1, size - 1);
  closeSync(fd);
  if (last[0] !== 0x0a) {
    rmSync(csv, { force: true });
    throw new Error(
      `${zipName}: conversão truncada (não termina em nova linha). Rode de novo.`,
    );
  }
  return csv;
}

const q = (s) => `'${String(s).replace(/'/g, "''")}'`;
const list = (xs) => xs.map(q).join(", ");

const instance = await DuckDBInstance.create(":memory:");
const db = await instance.connect();

// Estabelecimentos is ~90M rows and Empresas ~60M, and both are semi-joined
// here. Left to itself DuckDB will size its hash tables against available RAM
// and get killed by the OOM reaper on a laptop that is also running a browser —
// which fails as a dead process with no message, not as an error. A ceiling
// plus a spill directory on the same disk as the download turns that into a
// slower join instead. The temp directory sits under `data/`, never /tmp: on a
// normal Linux desktop /tmp is a RAM-backed tmpfs, so spilling there is not
// spilling at all.
await db.run(`SET memory_limit = '${process.env.CNPJ_MEMORY_LIMIT ?? "4GB"}'`);
await db.run(`SET temp_directory = ${q(path.join(workDir, "duckdb-tmp"))}`);
// We re-sort on write anyway; not preserving order lets DuckDB stream.
await db.run(`SET preserve_insertion_order = false`);
// The one fold, copied from build-city-index.mjs. It must stay identical to
// that macro and to normalise() in cities.ts, or a Receita city resolves in the
// picker and returns nothing — which reads as "no agencies here".
await db.run(`CREATE MACRO nrm(s) AS
  trim(regexp_replace(regexp_replace(lower(strip_accents(s)), '[^a-z0-9]+', ' ', 'g'), '\\s+', ' ', 'g'))`);

const EST = [
  "cnpj_basico",
  "cnpj_ordem",
  "cnpj_dv",
  "matriz_filial",
  "nome_fantasia",
  "situacao",
  "data_situacao",
  "motivo",
  "cidade_exterior",
  "pais",
  "data_inicio",
  "cnae",
  "cnae_secundaria",
  "tipo_logradouro",
  "logradouro",
  "numero",
  "complemento",
  "bairro",
  "cep",
  "uf",
  "municipio",
  "ddd1",
  "tel1",
  "ddd2",
  "tel2",
  "ddd_fax",
  "fax",
  "email",
  "situacao_especial",
  "data_situacao_especial",
];
const EMP = [
  "cnpj_basico",
  "razao_social",
  "natureza_juridica",
  "qualificacao_responsavel",
  "capital_social",
  "porte",
  "ente_federativo",
];
const SIMPLES = [
  "cnpj_basico",
  "opcao_simples",
  "data_opcao_simples",
  "data_exclusao_simples",
  "opcao_mei",
  "data_opcao_mei",
  "data_exclusao_mei",
];
const MUN = ["codigo", "nome"];

const csvOf = (file, names) =>
  `read_csv(${q(file)}, delim=';', quote='"', header=false, all_varchar=true, ` +
  `names=[${list(names)}])`;

const precise = preciseCnaes();
const broad = broadCnaes();

// Pass one: every active establishment under any CNAE we look at, precise or
// broad. The name rule cannot be applied yet — most rows have no nome fantasia
// and the razão social lives in a different file — so this keeps both and the
// join below decides. It is ~24k rows per part, so the intermediate is small
// even though the input is not.
console.log("\nFiltrando estabelecimentos…");
await db.run(`CREATE TABLE est (
  cnpj VARCHAR, cnae VARCHAR, fantasia VARCHAR, uf VARCHAR, municipio VARCHAR,
  logradouro VARCHAR, phone VARCHAR, email VARCHAR, cnpj_basico VARCHAR,
  data_inicio VARCHAR, matriz_filial VARCHAR)`);

for (const part of PARTS) {
  const file = extract(`Estabelecimentos${part}.zip`);
  await db.run(`INSERT INTO est SELECT
      cnpj_basico || cnpj_ordem || cnpj_dv,
      cnae,
      nullif(trim(nome_fantasia), ''),
      uf,
      municipio,
      nullif(trim(concat_ws(' ', tipo_logradouro, logradouro, nullif(numero, 'S/N'))), ''),
      -- E.164 assembled here rather than in the app: a DDD and a number are
      -- two columns in this file and one field everywhere else, and a number
      -- without its DDD is unusable rather than merely incomplete.
      -- Filler numbers are common in this register and a repeated digit is
      -- never a line: "5555-5555" and "99999999" are what gets typed when the
      -- form demands a phone. Left in, they inflate the coverage figure this
      -- source is chosen for and hand an operator a dead dial.
      CASE WHEN length(ddd1) BETWEEN 2 AND 3 AND length(tel1) BETWEEN 8 AND 9
            -- "every character is the first one", written without a
            -- backreference: DuckDB's regex engine is RE2, which has none.
            AND length(replace(tel1, substr(tel1, 1, 1), '')) > 0
           THEN '+55' || ddd1 || tel1 END,
      -- The field carries its own label often enough to matter
      -- ("e-mail: anuncios@…"), and anything that is not shaped like an address
      -- is worse than a blank: it becomes a mailto that silently goes nowhere.
      CASE WHEN regexp_matches(
             regexp_replace(lower(trim(email)), '^e-?mail\\s*:\\s*', ''),
             '^[^[:space:]@]+@[^[:space:]@]+\\.[^[:space:]@]+$')
           THEN regexp_replace(lower(trim(email)), '^e-?mail\\s*:\\s*', '')
      END,
      cnpj_basico,
      data_inicio,
      matriz_filial
    FROM ${csvOf(file, EST)}
    WHERE situacao = '02' AND cnae IN (${list([...precise, ...broad])})`);
  rmSync(file, { force: true });
  const n = await db.runAndReadAll(`SELECT count(*) n FROM est`);
  console.log(
    `  parte ${part}: ${Number(n.getRowObjects()[0].n).toLocaleString("pt-BR")} acumulados`,
  );
}

console.log("\nLendo empresas, simples e municípios…");
await db.run(
  `CREATE TABLE emp (cnpj_basico VARCHAR, razao VARCHAR, porte VARCHAR)`,
);
for (const part of ALL_PARTS) {
  const file = extract(`Empresas${part}.zip`);
  // Semi-joined against `est` on the way in: the full table is ~60M rows and we
  // need the ~240k that survived the CNAE filter.
  await db.run(`INSERT INTO emp SELECT e.cnpj_basico, nullif(trim(e.razao_social), ''), e.porte
    FROM ${csvOf(file, EMP)} e
    WHERE EXISTS (SELECT 1 FROM est WHERE est.cnpj_basico = e.cnpj_basico)`);
  rmSync(file, { force: true });
}

const simplesFile = extract("Simples.zip");
await db.run(`CREATE TABLE mei AS SELECT cnpj_basico, opcao_mei
  FROM ${csvOf(simplesFile, SIMPLES)} s
  WHERE EXISTS (SELECT 1 FROM est WHERE est.cnpj_basico = s.cnpj_basico)`);
rmSync(simplesFile, { force: true });

const munFile = extract("Municipios.zip");
await db.run(
  `CREATE TABLE mun AS SELECT codigo, nome FROM ${csvOf(munFile, MUN)}`,
);
rmSync(munFile, { force: true });

/**
 * Pass two: join, then apply the name rule to the broad CNAEs only.
 *
 * The rule reads razão social and nome fantasia together because 71% of these
 * rows have no fantasia at all — judging on the fantasia alone would discard
 * most of the broad pool unread rather than filtering it.
 */
console.log("\nAplicando a regra de nome nos CNAEs largos e gravando…");
const nameMatch = `regexp_matches(nrm(concat_ws(' ', emp.razao, est.fantasia)), ${q(MARKETING_NAME)})`;

await db.run(`COPY (
  SELECT
    'cnpj:' || est.cnpj                                    AS id,
    -- "source" is a DuckDB keyword; unquoted it is a parser error, not a
    -- column named source.
    'cnpj'                                                 AS "source",
    -- A MEI has no trading name, and its razão social is the registration
    -- number glued to the person: "41.729.911 THAMIRES AMARAL VIEIRA", or
    -- "EDUARDO BERTI 03738029940" with the CPF on the end. Left alone that goes
    -- into the CRM and onto a WhatsApp opener exactly like that. The raw value
    -- is kept in razao_social; this is only what a human should be shown.
    -- Falls back to the original if stripping would empty it.
    coalesce(
      nullif(trim(regexp_replace(
        regexp_replace(coalesce(est.fantasia, emp.razao),
                       '^[0-9][0-9./-]{9,}[[:space:]]+', ''),
        '[[:space:]]+[0-9]{11}$', '')), ''),
      est.fantasia, emp.razao)                             AS name,
    est.cnae                                               AS category,
    est.logradouro                                         AS address,
    mun.nome                                               AS city,
    est.uf                                                 AS uf,
    'BR'                                                   AS country,
    est.phone                                              AS phone,
    NULL                                                   AS website,
    NULL                                                   AS social,
    est.email                                              AS email,
    NULL::DOUBLE                                           AS lon,
    NULL::DOUBLE                                           AS lat,
    -- Not the Receita's number: it publishes none. This carries how long the
    -- establishment has been trading, which is the one durability signal the
    -- register has and is a fair reading of "is this record real and current" —
    -- a firm twelve years old is more certainly both than one registered last
    -- month.
    --
    -- It also has to do real work in the sort. Every row here scores the same
    -- 75 under scorePartner (registro ativo + telefone + e-mail + cadastro),
    -- and scoreAndSort breaks ties on confidence before name -- so a constant
    -- would leave a partner list ordered alphabetically, which is the failure
    -- scoreAndSort's own comment warns about. (No backticks in here: this is
    -- inside a JS template literal and one would end the string.)
    (0.75 + least(
      coalesce(date_diff('year', try_strptime(est.data_inicio, '%Y%m%d')::DATE,
                         current_date), 0), 20) / 100.0)::DOUBLE AS confidence,
    nrm(mun.nome)                                          AS city_norm,
    est.cnpj                                               AS cnpj,
    emp.razao                                              AS razao_social,
    (mei.opcao_mei = 'S')                                  AS mei,
    est.matriz_filial = '1'                                AS matriz,
    try_strptime(est.data_inicio, '%Y%m%d')::DATE          AS opened_at
  FROM est
  JOIN emp ON emp.cnpj_basico = est.cnpj_basico
  LEFT JOIN mei ON mei.cnpj_basico = est.cnpj_basico
  LEFT JOIN mun ON mun.codigo = est.municipio
  WHERE coalesce(est.fantasia, emp.razao) IS NOT NULL
    AND mun.nome IS NOT NULL
    AND (est.cnae IN (${list(precise)}) OR ${nameMatch})
  -- Same sort as places.parquet, and for the same reason: the city predicate is
  -- what has to prune row groups, so the file is ordered on what it filters by.
  ORDER BY city_norm, uf
) TO ${q(target + ".tmp")} (FORMAT PARQUET, COMPRESSION ZSTD)`);

renameSync(target + ".tmp", target);

// `rows` is a DuckDB keyword, like `source` above — quoted, or it is a parser
// error thrown after the extract has already been written, which reads as a
// failed sync that actually succeeded.
const stats = await db.runAndReadAll(`SELECT
    count(*) AS "rows",
    count(*) FILTER (WHERE email IS NOT NULL) with_email,
    count(*) FILTER (WHERE phone IS NOT NULL) with_phone,
    count(*) FILTER (WHERE mei) mei,
    -- Reported rather than filtered. In this register the e-mail is very often
    -- the accountant who opened the company, not the business — a real limit of
    -- the source that an operator should see stated rather than discover on the
    -- fortieth reply. It is still a route in, so dropping the row would cost
    -- more than it saves.
    count(*) FILTER (WHERE regexp_matches(email, 'contab|contador|escritorio')) accountant_email,
    count(DISTINCT city_norm) cities
  FROM read_parquet(${q(target)})`);
const s = stats.getRowObjects()[0];
const n = (v) => Number(v).toLocaleString("pt-BR");

writeFileSync(
  path.join(dataDir, "cnpj.json"),
  JSON.stringify(
    {
      month,
      // Recorded so a partial extract cannot be mistaken for a real one later.
      parts: PARTS,
      partial,
      rows: Number(s.rows),
      withEmail: Number(s.with_email),
      withPhone: Number(s.with_phone),
      mei: Number(s.mei),
      accountantEmail: Number(s.accountant_email),
      cities: Number(s.cities),
      preciseCnaes: precise,
      broadCnaes: broad,
      builtAt: new Date().toISOString(),
    },
    null,
    2,
  ),
);

console.log(`\nExtrato CNPJ    : ${target}`);
console.log(`Estabelecimentos: ${n(s.rows)}`);
console.log(`  com e-mail    : ${n(s.with_email)}`);
console.log(`  com telefone  : ${n(s.with_phone)}`);
console.log(`  MEI           : ${n(s.mei)}`);
console.log(`  e-mail de contador (aprox.): ${n(s.accountant_email)}`);
console.log(`Cidades         : ${n(s.cities)}`);
if (partial) {
  console.log(
    `\nATENÇÃO: extrato PARCIAL (partes ${PARTS.join(", ")} de 0–9). ` +
      `Serve para testar o pipeline, não para prospectar.`,
  );
}
console.log(
  `\nOs zips ficam em ${workDir} para o próximo mês. Apague à vontade.`,
);
