#!/usr/bin/env node
/**
 * One command to get the tool running: check what's missing, do only that, then
 * start the dev server.
 *
 * Run: npm run up        (from Website/, or `npm run prospector` from the root)
 *
 * The Prospector is a route on the main site (/prospector), not its own app, so
 * this starts the site's dev server — it just refuses to do so until the data
 * the tool needs is actually in place. `npm run dev` skips every check and is
 * the right command when you're working on the marketing pages.
 *
 * Every check answers a specific way this has actually gone wrong, rather than
 * just testing that files exist:
 *
 *   - deps missing            -> npm install
 *   - extract missing/empty   -> npm run sync
 *   - extract truncated       -> npm run sync  (a killed sync used to leave a file
 *                                that opens fine and then fails mid-query)
 *   - city index missing      -> npm run cities
 *   - city index older than
 *     the extract             -> npm run cities  (the counts and the set of
 *                                searchable names both come from the extract, so
 *                                syncing without rebuilding leaves the picker
 *                                describing data that is no longer there)
 *   - extract built from a
 *     different release       -> warn (the header would claim one release while
 *                                querying another)
 *   - extract older than a
 *     niche                   -> warn (the niche searches for categories the
 *                                file does not contain and finds nothing, which
 *                                looks exactly like an empty city)
 *   - B2B extract missing     -> note only (that route also works from a pasted
 *                                list, and falls back to S3 — never a blocker)
 *   - port already taken      -> say it's already running and stop
 *
 * Flags:
 *   --check        report what would happen and exit, change nothing
 *   --force-sync   re-download the extract even if it looks fine
 *   --port <n>     override the port (default 3000)
 */
import { existsSync, readFileSync, statSync, unlinkSync } from "node:fs";
import { createRequire } from "node:module";
import net from "node:net";
import path from "node:path";
import { spawn, spawnSync } from "node:child_process";
import { fileURLToPath, pathToFileURL } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..", "..");
const repoRoot = path.resolve(root, "..");

// The root launcher sources this file already, but `npm run prospector` starts
// in the Website workspace directly. Load it here as well so the same
// PROSPECTOR_COUNTRIES setting drives an automatic first sync either way.
loadRepoEnv(path.join(repoRoot, ".env"));

const argv = process.argv.slice(2);
const has = (flag) => argv.includes(flag);
const CHECK_ONLY = has("--check");
const FORCE_SYNC = has("--force-sync");
const PORT = (() => {
  const i = argv.indexOf("--port");
  const v = i >= 0 ? Number(argv[i + 1]) : NaN;
  return Number.isInteger(v) && v > 0 && v < 65536 ? v : 3000;
})();

const RELEASE = process.env.OVERTURE_RELEASE ?? "2026-07-22.0";
const SYNC_COUNTRIES = process.env.PROSPECTOR_COUNTRIES?.trim();
const REQUESTED_COUNTRIES = new Set(
  (SYNC_COUNTRIES ?? "")
    .split(",")
    .map((country) => country.trim().toUpperCase())
    .filter(Boolean),
);
// The current name first, then the Brazil-only one the sync used to write. The
// app resolves the same pair in the same order — see localExtractPath().
const EXTRACT_CANDIDATES = [
  path.join(root, "data", "places.parquet"),
  path.join(root, "data", "br-leads.parquet"),
];
const EXTRACT =
  EXTRACT_CANDIDATES.find((file) => existsSync(file)) ?? EXTRACT_CANDIDATES[0];
// Only the current name is ever written, so that is the only leftover to sweep.
const PARTIAL = `${EXTRACT_CANDIDATES[0]}.partial`;
const MANIFEST = path.join(root, "data", "extract.json");
const CITIES = path.join(root, "src", "data", "prospector", "cities.json");
// Optional, and separate from the Brazil extract in every way: multi-country,
// B2B categories only, and only records that have a website. See sync-b2b.mjs.
const B2B_EXTRACT = path.join(root, "data", "b2b-companies.parquet");
const B2B_MANIFEST = path.join(root, "data", "extract-b2b.json");
const NPM = process.platform === "win32" ? "npm.cmd" : "npm";

const br = (n) => Number(n).toLocaleString("pt-BR");
const mb = (bytes) => `${(bytes / 1024 / 1024).toFixed(0)} MB`;

let ok = true;
const say = (icon, text) => console.log(`${icon} ${text}`);
const good = (t) => say("  ok  ", t);
const warn = (t) => say(" warn ", t);
const todo = (t) => {
  ok = false;
  say(" ...  ", t);
};

console.log("Mandra Prospector\n");

// --- 1. dependencies ---------------------------------------------------------
// Resolved rather than checked as a directory: npm workspaces hoist to the repo
// root, so Website/node_modules may legitimately not exist at all.
const require_ = createRequire(import.meta.url);
let depsMissing = false;
try {
  require_.resolve("@duckdb/node-api");
  good("dependências instaladas");
} catch {
  depsMissing = true;
  todo("dependências ausentes — vou rodar npm install");
}

// --- 2. the Brazil extract ---------------------------------------------------
let needSync = FORCE_SYNC;
if (FORCE_SYNC) {
  todo("--force-sync pedido — vou baixar o extrato de novo");
} else if (!existsSync(EXTRACT)) {
  needSync = true;
  todo("extrato de negócios ausente — vou rodar npm run sync");
} else {
  const size = statSync(EXTRACT).size;
  if (size < 1024 * 1024) {
    needSync = true;
    todo(
      `extrato com apenas ${mb(size)} — parece incompleto, vou baixar de novo`,
    );
  } else if (depsMissing) {
    // Can't open it without DuckDB; re-checked after install below.
    good(
      `extrato presente (${mb(size)}) — conteúdo será verificado após o install`,
    );
  } else {
    const rows = await countRows(EXTRACT);
    if (rows === null) {
      needSync = true;
      todo("extrato ilegível (download interrompido?) — vou baixar de novo");
    } else if (rows === 0) {
      needSync = true;
      todo("extrato sem nenhum negócio — vou baixar de novo");
    } else {
      good(`extrato: ${br(rows)} negócios (${mb(size)})`);
      // Not a reason to re-sync: without the column every search still works, it
      // just reads most of the file instead of a few row groups. Worth saying so,
      // because the upgrade takes seconds and the re-download takes ~20 minutes.
      if ((await hasCityNorm(EXTRACT)) === false) {
        warn(
          "extrato sem a coluna city_norm — buscas leem ~9x mais do arquivo. " +
            "Rode npm run upgrade-extract (segundos, sem baixar nada de novo).",
        );
      }
    }
  }
}

// A leftover .partial is a sync that was killed. Harmless but confusing, and it
// costs the same disk as the real thing.
if (existsSync(PARTIAL)) {
  warn(
    `places.parquet.partial de uma sync interrompida — ${
      CHECK_ONLY ? "seria removido" : "removido"
    }`,
  );
  if (!CHECK_ONLY) unlinkSync(PARTIAL);
}

// A valid Brazil-only file is still not the configured international market.
// The manifest is written by sync-places.mjs, so an older file without one is
// conservatively rebuilt rather than silently leaving the country picker on BR.
if (!needSync && REQUESTED_COUNTRIES.size > 0) {
  const extractedCountries = extractCountries(MANIFEST);
  const missingCountries = extractedCountries
    ? [...REQUESTED_COUNTRIES].filter(
        (country) => !extractedCountries.has(country),
      )
    : [...REQUESTED_COUNTRIES];
  if (missingCountries.length > 0) {
    needSync = true;
    todo(
      `extrato não cobre os países configurados (${missingCountries.join(", ")}) — vou rodar npm run sync`,
    );
  }
}

// --- 3. release match --------------------------------------------------------
// Only checkable when the extract carries a manifest; older extracts don't, and
// a missing manifest is not an error.
if (!needSync && existsSync(MANIFEST)) {
  try {
    const m = JSON.parse(readFileSync(MANIFEST, "utf8"));
    if (m.release && m.release !== RELEASE) {
      warn(
        `extrato é do release ${m.release}, mas OVERTURE_RELEASE é ${RELEASE}. ` +
          `Rode npm run sync para alinhar, ou ajuste a variável.`,
      );
    } else if (m.release) {
      good(`release ${m.release}`);
    }
  } catch {
    warn("data/extract.json ilegível — ignorando a checagem de release");
  }
}

// --- 3b. niche vocabulary ----------------------------------------------------
// The extract contains only the categories that existed in niches.ts when it was
// built, so a niche added afterwards searches for rows the file does not hold
// and comes back empty — which reads on screen as "no leads in this city"
// rather than "your extract predates this niche". The manifest records how many
// categories went in, and that is enough to catch the drift: the count only ever
// grows, and a sync is the fix either way.
if (!needSync && existsSync(MANIFEST)) {
  try {
    const built = JSON.parse(readFileSync(MANIFEST, "utf8")).categories;
    const current = registryCategoryCount();
    if (Number.isInteger(built) && current !== null && current > built) {
      warn(
        `o extrato cobre ${built} categorias e os nichos já pedem ${current} — ` +
          `os nichos novos vão buscar e não achar nada. Rode npm run sync.`,
      );
    }
  } catch {
    // An unreadable manifest is already reported by the release check above.
  }
}

// --- 4. the searchable city index -------------------------------------------
let needCities = needSync;
if (needSync) {
  todo("índice de cidades será reconstruído depois da sync");
} else if (!existsSync(CITIES)) {
  needCities = true;
  todo("índice de cidades ausente — vou rodar npm run cities");
} else {
  let cities = null;
  try {
    const parsed = JSON.parse(readFileSync(CITIES, "utf8"));
    if (
      Array.isArray(parsed) &&
      parsed.length > 0 &&
      Array.isArray(parsed[0])
    ) {
      cities = parsed;
    }
  } catch {
    /* handled below */
  }

  if (cities === null) {
    needCities = true;
    todo("índice de cidades corrompido — vou reconstruir");
  } else if (
    existsSync(EXTRACT) &&
    statSync(EXTRACT).mtimeMs > statSync(CITIES).mtimeMs
  ) {
    needCities = true;
    todo("índice de cidades mais antigo que o extrato — vou reconstruir");
  } else {
    const reach = cities.reduce((a, c) => a + (Number(c[7]) || 0), 0);
    good(`${br(cities.length)} cidades · ${br(reach)} negócios sem site`);
  }
}

// --- 5. the B2B extract (optional) -------------------------------------------
// Deliberately never a `todo`: /prospector/b2b works without it. A pasted list
// of domains needs no extract at all, and sector discovery falls back to
// querying Overture over S3 — slow, but correct. Blocking the dev server on a
// 20-minute download for a route you may not be working on would be wrong.
if (!existsSync(B2B_EXTRACT)) {
  good(
    "extrato B2B ausente (opcional) — npm run sync:b2b acelera /prospector/b2b",
  );
} else if (existsSync(B2B_MANIFEST)) {
  try {
    const m = JSON.parse(readFileSync(B2B_MANIFEST, "utf8"));
    good(
      `extrato B2B: ${br(m.rows ?? 0)} empresas em ${
        (m.countries ?? []).length
      } países (${mb(statSync(B2B_EXTRACT).size)})`,
    );
    if (m.release && m.release !== RELEASE) {
      warn(
        `extrato B2B é do release ${m.release}, mas OVERTURE_RELEASE é ${RELEASE}. ` +
          `Rode npm run sync:b2b para alinhar.`,
      );
    }
  } catch {
    warn(
      "data/extract-b2b.json ilegível — ignorando a checagem do extrato B2B",
    );
  }
} else {
  good(`extrato B2B presente (${mb(statSync(B2B_EXTRACT).size)})`);
}

if (existsSync(`${B2B_EXTRACT}.partial`)) {
  warn(
    `b2b-companies.parquet.partial de uma sync interrompida — ${
      CHECK_ONLY ? "seria removido" : "removido"
    }`,
  );
  if (!CHECK_ONLY) unlinkSync(`${B2B_EXTRACT}.partial`);
}

// --- 6. port -----------------------------------------------------------------
const portBusy = await inUse(PORT);
if (portBusy) {
  warn(`porta ${PORT} já está em uso`);
}

// --- report / act ------------------------------------------------------------
console.log("");

if (CHECK_ONLY) {
  // A busy port is not a missing setup step — it almost always means the thing is
  // already up. Reporting "faltam passos" for it sent you looking for work that
  // didn't exist, so the two are kept separate, and only real gaps fail the exit
  // code (which is what makes this usable in a precondition check).
  if (!ok) {
    console.log("Faltam passos (marcados com ... acima).");
    console.log("Rode npm run up para executá-los e subir o servidor.");
  } else if (portBusy) {
    console.log(
      `Tudo pronto — e já está rodando: http://localhost:${PORT}/prospector`,
    );
  } else {
    console.log("Tudo pronto. Rode: npm run up");
  }
  process.exit(ok ? 0 : 1);
}

if (portBusy) {
  // Almost always means you already have it open in another terminal, which is
  // not a failure worth an error exit.
  console.log(`Já está rodando: http://localhost:${PORT}/prospector`);
  console.log(`Para reiniciar:  kill $(lsof -ti :${PORT})`);
  process.exit(0);
}

if (depsMissing) run(NPM, ["install"], repoRoot, "Instalando dependências");
if (needSync)
  run(
    process.execPath,
    [path.join(here, "sync-places.mjs")],
    root,
    SYNC_COUNTRIES
      ? `Baixando o extrato internacional (${SYNC_COUNTRIES})`
      : "Baixando o extrato do Brasil",
  );
if (needCities)
  run(
    process.execPath,
    [path.join(here, "build-city-index.mjs")],
    root,
    "Montando o índice de cidades",
  );

console.log(`\nSubindo em http://localhost:${PORT}/prospector\n`);
const dev = spawn(...devCommand(), { cwd: root, stdio: "inherit" });
// Ctrl+C reaches the child through the shared process group; this only makes sure
// our own exit code matches its fate rather than always being 0.
dev.on("exit", (code, signal) => process.exit(signal ? 1 : (code ?? 0)));

// --- helpers -----------------------------------------------------------------

/**
 * How many Overture categories the niche registry currently asks for.
 *
 * It lives in TypeScript and this launcher deliberately runs as plain node — it
 * is the one thing that must work before anything is installed or compiled — so
 * the registry is read in a child process through the same loader the other
 * scripts use. Any failure returns null and the check quietly does not run: a
 * launcher must never refuse to start over its own diagnostics.
 */
function registryCategoryCount() {
  const niches = pathToFileURL(
    path.join(root, "src", "lib", "prospector", "niches.ts"),
  ).href;
  const result = spawnSync(
    process.execPath,
    [
      "--import",
      pathToFileURL(path.join(root, "scripts", "ts-register.mjs")).href,
      "-e",
      `import(${JSON.stringify(niches)}).then((m) => console.log(m.allCategories().length))`,
    ],
    { cwd: root, encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] },
  );
  const n = Number(String(result.stdout ?? "").trim());
  return Number.isInteger(n) && n > 0 ? n : null;
}

/**
 * Minimal dotenv reader for the launcher, deliberately dependency-free.
 * Existing process variables win, which keeps Docker/Dokploy environment
 * values authoritative over a developer's local file.
 */
function loadRepoEnv(file) {
  if (!existsSync(file)) return;
  for (const line of readFileSync(file, "utf8").split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if (!match || process.env[match[1]] !== undefined) continue;
    const raw = match[2];
    const quoted = raw.match(/^(?:"([\s\S]*)"|'([\s\S]*)')$/);
    process.env[match[1]] = quoted?.[1] ?? quoted?.[2] ?? raw;
  }
}

function extractCountries(file) {
  if (!existsSync(file)) return null;
  try {
    const parsed = JSON.parse(readFileSync(file, "utf8"));
    if (!Array.isArray(parsed.countries)) return null;
    return new Set(
      parsed.countries
        .map((country) => String(country).trim().toUpperCase())
        .filter(Boolean),
    );
  } catch {
    return null;
  }
}

/**
 * Row count straight from the Parquet footer — no full scan, so this is fast even
 * on the 120MB extract. Returns null when the file can't be read at all, which is
 * what a half-downloaded file looks like.
 */
async function countRows(file) {
  try {
    const { DuckDBInstance } = await import("@duckdb/node-api");
    const db = await (await DuckDBInstance.create(":memory:")).connect();
    const reader = await db.runAndReadAll(
      `SELECT count(*) AS n FROM read_parquet('${file.replace(/'/g, "''")}')`,
    );
    return Number(reader.getRowObjectsJS()[0].n);
  } catch {
    return null;
  }
}

/**
 * Whether the extract carries the pre-folded city column the search prunes on.
 * Reads only the Parquet footer, so it costs nothing. Null when it can't be read,
 * which the caller treats as "don't nag" — countRows has already reported that.
 */
async function hasCityNorm(file) {
  try {
    const { DuckDBInstance } = await import("@duckdb/node-api");
    const db = await (await DuckDBInstance.create(":memory:")).connect();
    const reader = await db.runAndReadAll(
      `SELECT column_name FROM (DESCRIBE SELECT * FROM read_parquet('${file.replace(/'/g, "''")}'))
       WHERE column_name = 'city_norm'`,
    );
    return reader.getRowObjectsJS().length > 0;
  } catch {
    return null;
  }
}

/**
 * Launch Next directly rather than through `npm run dev`.
 *
 * Resolving the binary drops a layer of npm process between Ctrl+C and the
 * server, and keeps `--port` in one place — forwarding it through npm has bitten
 * this script before, back when the dev script carried a hardcoded port of its
 * own and produced `next dev --port 3001 --port 3001`. Falls back to npm if the
 * resolve fails, since a launcher that can't launch is worse than an indirect one.
 */
function devCommand() {
  try {
    return [
      process.execPath,
      [require_.resolve("next/dist/bin/next"), "dev", "--port", String(PORT)],
    ];
  } catch {
    return [NPM, ["run", "dev", "--", "--port", String(PORT)]];
  }
}

function inUse(port) {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.once("error", (err) =>
      resolve(err.code === "EADDRINUSE" || err.code === "EACCES"),
    );
    server.once("listening", () => server.close(() => resolve(false)));
    server.listen(port, "127.0.0.1");
  });
}

function run(cmd, args, cwd, label) {
  console.log(`— ${label}...\n`);
  const r = spawnSync(cmd, args, { cwd, stdio: "inherit" });
  if (r.status !== 0) {
    console.error(`\n${label} falhou. Nada foi iniciado.`);
    process.exit(r.status ?? 1);
  }
  console.log("");
}
