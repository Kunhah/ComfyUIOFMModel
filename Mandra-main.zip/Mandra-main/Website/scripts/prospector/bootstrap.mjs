import { existsSync, mkdirSync, statSync } from "node:fs";
import path from "node:path";

const dataDir = path.join(process.cwd(), "data");
// The name the current sync writes, and the Brazil-only name it used to write.
// The app resolves the same pair in the same order — see localExtractPath().
const candidates = [
  path.join(dataDir, "places.parquet"),
  path.join(dataDir, "br-leads.parquet"),
];

const log = (event, fields = {}) =>
  console.info(JSON.stringify({ service: "prospector", event, ...fields }));

mkdirSync(dataDir, { recursive: true });
const extract = candidates.find((file) => existsSync(file));
if (extract) {
  log("extract.present", { path: extract, bytes: statSync(extract).size });
} else {
  log("extract.absent", { destination: candidates[0] });
}

await import("../../server.js");
