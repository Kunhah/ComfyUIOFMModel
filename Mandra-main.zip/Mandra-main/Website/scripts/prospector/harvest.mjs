#!/usr/bin/env node
/**
 * Fill the CRM with leads in bulk, by sweeping city × niche.
 *
 * Run: npm run harvest                              (from Website/) — top 25 cities, every niche
 *      npm run harvest -- --uf SC,PR,RS             — only those states
 *      npm run harvest -- --cities 100 --niches odontologia,saloes-beleza
 *      npm run harvest -- --dry-run                 — print the plan, run nothing
 *
 * Why this exists: the extract holds 1.87M Brazilian businesses, 1.14M of them
 * with no website, but a lead only enters the CRM when somebody runs a search in
 * the UI — one city and one niche at a time. That is a fine way to work a market
 * you have chosen and a hopeless way to stock a queue that eats 100 leads a day.
 * Two niches across three cities is where that path had got to: 737 leads, about
 * a week of dialling.
 *
 * So this is the same search, run for every combination, unattended. It calls
 * `performSearch` rather than reimplementing the query, which is what keeps the
 * bulk path from drifting from the interactive one: same scoring, same dedupe,
 * same niche derivation, same writes. The only things it decides are which
 * combinations to run and in what order.
 *
 * The sweep is resumable. It writes `data/harvest.json` after every combination,
 * so a crash, a Ctrl-C or a laptop lid closing costs one search rather than the
 * run — which matters when a full national sweep is tens of thousands of them.
 */
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { NICHES } from "../../src/lib/prospector/niches.ts";
import { performSearch } from "../../src/lib/prospector/search.ts";
import { phonePoolStats } from "../../src/lib/prospector/phone-quality.ts";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..", "..");
const CITIES = path.join(root, "src", "data", "prospector", "cities.json");
const STATE = path.join(root, "data", "harvest.json");

const argv = process.argv.slice(2);
const flag = (name) => {
  const i = argv.indexOf(`--${name}`);
  return i >= 0 ? (argv[i + 1] ?? "") : null;
};
const has = (name) => argv.includes(`--${name}`);
const num = (name, fallback) => {
  const raw = flag(name);
  if (raw === null || raw.trim() === "") return fallback;
  const n = Number(raw);
  return Number.isFinite(n) ? n : fallback;
};
const list = (name) =>
  (flag(name) ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

if (has("help")) {
  console.log(`
Uso: npm run harvest -- [opções]

  --cities N        quantas cidades varrer, as maiores primeiro (padrão 25)
  --uf SC,PR        apenas estes estados
  --country BR      país do índice de cidades (padrão BR)
  --niches a,b      apenas estes nichos (padrão: todos os ${NICHES.length})
  --limit N         linhas por busca (padrão 5000, o teto do motor)
  --conf N          confiança mínima 0–1 (padrão 0.5)
  --min-pool N      pula cidades com menos de N negócios sem site (padrão 200)
  --all             inclui quem já tem site (leads de redesign)
  --osm             consulta também o OpenStreetMap (desligado em massa)
  --fresh           ignora o progresso salvo e recomeça
  --dry-run         mostra o plano e sai
`);
  process.exit(0);
}

/* -------------------------------------------------------------------------- */
/* The plan                                                                    */
/* -------------------------------------------------------------------------- */

// [name, uf, xmin, xmax, ymin, ymax, businesses, noSite, country, aliases?]
const rows = JSON.parse(readFileSync(CITIES, "utf8"));

const country = (flag("country") ?? "BR").toUpperCase();
const ufs = new Set(list("uf").map((s) => s.toUpperCase()));
const wantedNiches = new Set(list("niches"));
const niches = wantedNiches.size
  ? NICHES.filter((n) => wantedNiches.has(n.slug))
  : NICHES;

if (niches.length === 0) {
  console.error(
    `Nenhum nicho corresponde a --niches. Disponíveis: ${NICHES.map((n) => n.slug).join(", ")}`,
  );
  process.exit(1);
}

// Ranked by the sellable pool, not by total businesses. A city's worth to a
// cold-calling day is how many businesses there have no website — the ones the
// pitch is for — and the two orders disagree enough to matter.
const minPool = num("min-pool", 200);
const cities = rows
  .filter((r) => (r[8] ?? "BR").toUpperCase() === country)
  .filter((r) => ufs.size === 0 || ufs.has(String(r[1]).toUpperCase()))
  .filter((r) => Number(r[7]) >= minPool)
  .sort((a, b) => Number(b[7]) - Number(a[7]))
  .slice(0, Math.max(1, Math.trunc(num("cities", 25))))
  .map((r) => ({ name: r[0], uf: r[1], noSite: Number(r[7]) }));

if (cities.length === 0) {
  console.error(
    `Nenhuma cidade em ${country}${ufs.size ? ` (${[...ufs].join(",")})` : ""} com ${minPool}+ negócios sem site.`,
  );
  process.exit(1);
}

const options = {
  limit: Math.trunc(num("limit", 5000)),
  minConfidence: num("conf", 0.5),
  onlyWithoutWebsite: !has("all"),
  // Off by default here, and only here. Overpass is a shared public service and
  // the interactive search hits it once; a sweep would hit it once per
  // combination — thousands of times — which is rude and also the slowest part
  // of every search. Overture alone is already the complete local answer.
  includeOpenStreetMap: has("osm"),
};

const combos = [];
for (const city of cities) {
  for (const niche of niches) {
    combos.push({ city, niche: niche.slug });
  }
}

const key = (c) => `${country}|${c.city.uf}|${c.city.name}|${c.niche}`;

/* -------------------------------------------------------------------------- */
/* Resume state                                                                */
/* -------------------------------------------------------------------------- */

let done = new Set();
if (!has("fresh") && existsSync(STATE)) {
  try {
    const saved = JSON.parse(readFileSync(STATE, "utf8"));
    if (Array.isArray(saved.done)) done = new Set(saved.done);
  } catch {
    // A corrupt state file must not stop a harvest. The worst case of ignoring
    // it is repeating searches that insert nothing, since persistence is by
    // Overture id and re-running a combination is idempotent.
  }
}

const pending = combos.filter((c) => !done.has(key(c)));

console.log(
  `${combos.length.toLocaleString("pt-BR")} combinações · ` +
    `${cities.length} cidades × ${niches.length} nichos` +
    (done.size ? ` · ${done.size.toLocaleString("pt-BR")} já feitas` : ""),
);
console.log(
  `Pendentes: ${pending.length.toLocaleString("pt-BR")}  ·  ` +
    `limite ${options.limit}/busca  ·  conf ≥ ${options.minConfidence}  ·  ` +
    `${options.onlyWithoutWebsite ? "sem site" : "todos"}  ·  ` +
    `OSM ${options.includeOpenStreetMap ? "on" : "off"}`,
);

if (has("dry-run")) {
  for (const city of cities) {
    console.log(
      `  ${String(city.noSite).padStart(7)} sem site · ${city.name}/${city.uf}`,
    );
  }
  process.exit(0);
}

if (pending.length === 0) {
  console.log("Nada a fazer. Use --fresh para varrer tudo de novo.");
  process.exit(0);
}

/* -------------------------------------------------------------------------- */
/* The sweep                                                                   */
/* -------------------------------------------------------------------------- */

const before = phonePoolStats();
const started = Date.now();
let inserted = 0;
let failed = 0;

const save = () => {
  mkdirSync(path.dirname(STATE), { recursive: true });
  writeFileSync(
    STATE,
    `${JSON.stringify({ updatedAt: new Date().toISOString(), done: [...done] }, null, 2)}\n`,
  );
};

// A sweep is long enough that somebody will stop it. Saving on the way out means
// the next run resumes at the next combination rather than redoing the batch.
let stopping = false;
process.on("SIGINT", () => {
  if (stopping) process.exit(130);
  stopping = true;
  console.log("\nParando após a busca atual… (Ctrl-C de novo para sair já)");
});

const actor = {
  id: "harvest",
  username: "harvest",
  displayName: "Coleta em massa",
};

for (const [i, combo] of pending.entries()) {
  if (stopping) break;

  const label = `${combo.city.name}/${combo.city.uf} · ${combo.niche}`;
  const progress = `[${String(i + 1).padStart(String(pending.length).length)}/${pending.length}]`;

  let outcome;
  try {
    outcome = await performSearch(
      {
        niche: combo.niche,
        city: combo.city.name,
        uf: combo.city.uf,
        country,
        ...options,
      },
      actor,
    );
  } catch (err) {
    // One bad combination must not end a sweep of thousands. It stays out of
    // `done`, so the next run retries exactly it.
    failed += 1;
    console.log(`${progress} ${label} — erro: ${err?.message ?? err}`);
    continue;
  }

  if (!outcome.ok) {
    failed += 1;
    console.log(`${progress} ${label} — ${outcome.error}`);
    continue;
  }

  const added = outcome.response.leads.filter((l) => l.isNew).length;
  inserted += added;
  done.add(key(combo));
  save();

  console.log(
    `${progress} ${label} — ${String(added).padStart(4)} novos ` +
      `(${outcome.response.stats.total.toLocaleString("pt-BR")} encontrados) ` +
      `· total ${inserted.toLocaleString("pt-BR")}`,
  );
}

/* -------------------------------------------------------------------------- */
/* What it means for the phone                                                 */
/* -------------------------------------------------------------------------- */

const after = phonePoolStats();
const minutes = Math.round((Date.now() - started) / 60000);

console.log(`
Coleta concluída em ${minutes} min${failed ? ` · ${failed} combinações falharam` : ""}
  ${inserted.toLocaleString("pt-BR")} leads novos

Fila de ligação (leads abertos):
  com telefone utilizável   ${after.good.toLocaleString("pt-BR")}  (antes: ${before.good.toLocaleString("pt-BR")})
  disponíveis para hoje     ${after.available.toLocaleString("pt-BR")}  (antes: ${before.available.toLocaleString("pt-BR")})
  sem telefone              ${after.noPhone.toLocaleString("pt-BR")}
  número compartilhado      ${after.shared.toLocaleString("pt-BR")}
  número morto              ${after.dead.toLocaleString("pt-BR")}

A ${100} ligações por dia, isso é ${Math.floor(after.available / 100).toLocaleString("pt-BR")} dias de fila.`);
