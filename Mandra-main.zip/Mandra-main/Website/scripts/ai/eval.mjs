/**
 * `npm run eval` — replays the recorded fixtures through each skill's
 * `validate()` and reports what the guardrails caught.
 *
 * Free, offline and deterministic: it makes no provider calls and needs no keys
 * or database. That is the point. A prompt edit is the one change in this
 * codebase that can degrade production without failing a test, and a check that
 * costs money per run is a check somebody eventually stops running.
 *
 * What it does not do is judge the writing. See evals/harness.ts for why, and
 * for where the fixtures are supposed to come from.
 */

import { readFileSync, readdirSync, existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "../..");
const evalsDir = path.join(root, "src/lib/ai/evals");

const { runFixture } = await import(path.join(evalsDir, "harness.ts"));
const { insightLead } = await import(
  path.join(root, "src/lib/ai/skills/insight-lead.ts")
);
const { insightFila } = await import(
  path.join(root, "src/lib/ai/skills/insight-fila.ts")
);
const { insightObjecao } = await import(
  path.join(root, "src/lib/ai/skills/insight-objecao.ts")
);

/**
 * Fixture directory name → the skill, and how a fixture's `contexto` becomes
 * the context that skill's `validate()` reads.
 *
 * The adapter is per skill because the context is: `insight.lead` needs only the
 * fact list the harness already builds, while `insight.fila` filters against the
 * ids it was sent and `insight.objecao` counts how often each objection appears
 * in the corpus. Anything a fixture cannot supply is a read that belongs in
 * `context()` rather than in `validate()` — see the note in harness.ts.
 */
const SKILLS = {
  "insight.lead": { skill: insightLead, context: () => ({}) },
  "insight.fila": {
    skill: insightFila,
    context: (fixture) => {
      // The rows *are* the facts here: one fact per lead, keyed by its id. That
      // makes the citation whitelist and the id filter the same list, and lets
      // the invented-number check see the scores we actually sent.
      const rows = fixture.contexto?.rows ?? [];
      return { rows, ids: new Set(rows.map((row) => row.id)) };
    },
  },
  "insight.objecao": {
    skill: insightObjecao,
    context: (fixture) => ({ samples: fixture.contexto?.samples ?? [] }),
  },
};

let failed = 0;
let ran = 0;

for (const [id, { skill, context }] of Object.entries(SKILLS)) {
  const dir = path.join(evalsDir, id);
  if (!existsSync(dir)) {
    console.log(`· ${id}: sem fixtures`);
    continue;
  }

  const files = readdirSync(dir)
    .filter((name) => name.endsWith(".json"))
    .sort();

  console.log(`\n${id} — ${files.length} fixture(s)`);
  for (const file of files) {
    const fixture = JSON.parse(readFileSync(path.join(dir, file), "utf8"));
    const result = runFixture(skill, fixture, context(fixture));
    ran += 1;
    if (result.ok) {
      console.log(`  ✔ ${result.fixture}`);
    } else {
      failed += 1;
      console.log(`  ✘ ${result.fixture}`);
      for (const falha of result.falhas) console.log(`      ${falha}`);
    }
  }
}

console.log(
  `\n${ran - failed}/${ran} fixtures passaram${failed > 0 ? "" : " — nenhuma regressão"}`,
);
process.exit(failed > 0 ? 1 : 0);
