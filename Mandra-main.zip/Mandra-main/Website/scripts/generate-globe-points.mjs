/**
 * Generates the globe's land-point cloud, once, at author time.
 *
 * Distributes candidate points evenly over a sphere with a Fibonacci spiral,
 * keeps only those falling on land (Natural Earth polygons via world-atlas),
 * and writes them as an Int16Array of lat/lon pairs scaled by 100.
 *
 *   npm run globe:points
 *
 * Output: public/data/land-points.bin  (committed — no build-time dependency)
 *
 * Chosen over sampling a land-mask PNG on a canvas at runtime: no image asset
 * to source, no decode cost, and no canvas readback jank on first paint.
 */
import { writeFileSync, mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";
import { feature } from "topojson-client";
import { geoContains } from "d3-geo";

const require = createRequire(import.meta.url);
const __dirname = dirname(fileURLToPath(import.meta.url));

const CANDIDATES = 170_000; // sampled over the whole sphere
const OUT = resolve(__dirname, "../public/data/land-points.bin");

// 50m rather than 110m: an order of magnitude more coastline detail, so
// islands, peninsulas and inlets actually survive the sampling instead of
// being smoothed into blobs.
const topology = require("world-atlas/land-50m.json");
const land = feature(topology, topology.objects.land);

// Fibonacci sphere: near-uniform angular spacing, no polar clustering.
const golden = Math.PI * (3 - Math.sqrt(5));
const lats = [];
const lons = [];

for (let i = 0; i < CANDIDATES; i++) {
  const y = 1 - (i / (CANDIDATES - 1)) * 2; // 1 → -1
  const lat = Math.asin(y) * (180 / Math.PI);
  const lon = (((golden * i) * (180 / Math.PI)) % 360) - 180;

  if (geoContains(land, [lon, lat])) {
    lats.push(lat);
    lons.push(lon);
  }
}

const count = lats.length;
const data = new Int16Array(count * 2);
for (let i = 0; i < count; i++) {
  // ±90 and ±180 scaled by 100 both fit comfortably inside Int16.
  data[i * 2] = Math.round(lats[i] * 100);
  data[i * 2 + 1] = Math.round(lons[i] * 100);
}

mkdirSync(dirname(OUT), { recursive: true });
writeFileSync(OUT, Buffer.from(data.buffer));

console.log(
  `${count} land points from ${CANDIDATES} candidates ` +
    `(${(count / CANDIDATES * 100).toFixed(1)}% land) → ` +
    `${(data.byteLength / 1024).toFixed(1)} KB`,
);
