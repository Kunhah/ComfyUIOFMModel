// Entry point for `node --import`. The hooks themselves live in ts-hooks.mjs
// because module.register loads them on a separate thread.
import { register } from "node:module";
register("./ts-hooks.mjs", import.meta.url);
