/**
 * Generates the point cloud the globe's dots reassemble into: the Mandra mark,
 * sampled from the supplied SVG artwork.
 *
 *   npm run globe:monogram
 *
 * Output: public/data/monogram-points.bin  (Int16 x/y pairs, scaled ×1000)
 *
 * Done at author time rather than in the browser so there's no Path2D
 * rasterisation or 70k point-in-path tests on the main thread at runtime, and
 * so the cloud is byte-identical on every load.
 */
import { writeFileSync, mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const OUT = resolve(__dirname, "../public/data/monogram-points.bin");

// Kept in sync with public/mandra.svg. The artwork's group is translated by
// (-56.464015, -36.797866), so sample the original coordinates here.
const VIEWBOX = { x: 56.464015, y: 36.797866, w: 102.27245, h: 89.62957 };
const PATHS = [
  "m 56.464015,36.797868 c 1.476697,0.345465 22.323791,14.720874 24.555347,16.236977 l 34.611238,23.52136 c 2.5077,1.728031 6.70233,4.339787 8.85138,6.120978 -1.19927,1.038945 -3.33557,2.428739 -4.68794,3.36094 -2.5474,1.743767 -5.07636,3.512909 -7.58831,5.307002 L 108.29604,94.131094 84.981361,78.117105 C 80.20567,74.867157 74.923764,71.49601 70.272679,68.142152 c -1.277104,0.786474 -2.883647,2.081151 -4.121055,2.97366 -3.192534,2.303001 -6.382518,4.867265 -9.64494,7.048217 0.07726,-13.788675 0.06308,-27.577772 -0.04265,-41.366161 z",
  "m 158.38485,36.879237 c 0.0836,0.03572 0.28352,0.195626 0.28069,0.246234 -0.0595,1.270295 -0.0553,5.308134 -0.0524,6.247139 -0.0865,11.672366 -0.0454,23.34544 0.12333,35.01681 -4.29953,-3.699317 -8.96479,-6.692118 -13.3522,-10.244717 -3.86008,2.611044 -7.70172,5.248735 -11.52494,7.913083 -2.50628,1.757376 -5.02107,3.637515 -7.57555,5.305014 l -3.40787,-2.316043 -12.90708,-8.854215 c 7.80804,-5.241649 15.82446,-10.969528 23.5758,-16.344147 8.24749,-5.704489 16.52758,-11.360922 24.84027,-16.969158 z",
  "m 69.922108,71.241837 c 2.435833,1.307434 6.177251,4.254303 8.568432,5.890614 0.339507,0.232346 0.258851,0.633092 0.265934,1.051562 l -0.02068,31.718667 c -0.529328,0.37793 -1.488179,1.01953 -1.954141,1.41163 -0.546334,0.405 -1.513264,1.07878 -1.976108,1.5256 -0.777398,0.46228 -1.734407,1.25201 -2.472404,1.82599 l -10.469686,7.76763 c -1.726901,1.28788 -3.511494,2.74657 -5.261498,3.95449 -0.14459,-5.73256 -0.03927,-12.01953 -0.03756,-17.7949 l -0.08832,-27.310414 c 1.384125,-1.144557 3.304951,-2.474955 4.800497,-3.580668 2.897111,-2.133038 5.779055,-4.286343 8.645546,-6.460201 z",
  "m 136.51016,77.297032 c 2.34042,-1.435866 6.54214,-4.521518 8.78758,-6.243026 l 13.33236,10.09063 0.01,45.282794 c -1.54091,-0.99897 -3.03788,-2.26799 -4.52776,-3.36265 -3.11584,-2.28967 -6.21184,-4.75372 -9.34327,-7.0115 l -8.27867,-6.24898 c -0.0624,-4.13423 0.10348,-8.84797 -0.0978,-12.920262 0.3062,-6.181928 -0.0127,-13.273239 0.11766,-19.587006 z",
];

const TARGET_POINTS = 50_000;
const BEZIER_STEPS = 18;

/** Flattens an SVG path (M/L/C/z only) into a list of closed polygons. */
function pathToPolygons(d) {
  const tokens = d.match(/[MLCZz]|-?\d*\.?\d+(?:e[-+]?\d+)?/gi) ?? [];
  const polygons = [];
  let current = [];
  let cursor = [0, 0];
  let start = [0, 0];
  let i = 0;

  const num = () => parseFloat(tokens[i++]);

  while (i < tokens.length) {
    const token = tokens[i];

    if (/[MLCZz]/i.test(token)) {
      i++;
      const relative = token === token.toLowerCase();
      if (token.toUpperCase() === "M") {
        if (current.length > 2) polygons.push(current);
        current = [];
        // A moveto may carry several coordinate pairs; every pair after the
        // first is an implicit lineto. Reading only the first silently drops
        // vertices, which is how the mark's right-hand shapes came out
        // malformed while the left ones looked fine.
        let first = true;
        while (i < tokens.length && !/[MLCZz]/i.test(tokens[i])) {
          const [x0, y0] = cursor;
          let x = num();
          let y = num();
          if (relative) {
            x += x0;
            y += y0;
          }
          cursor = [x, y];
          if (first) {
            start = cursor;
            first = false;
          }
          current.push(cursor);
        }
      } else if (token.toUpperCase() === "L") {
        // Same repetition rule as moveto.
        while (i < tokens.length && !/[MLCZz]/i.test(tokens[i])) {
          const [x0, y0] = cursor;
          let x = num();
          let y = num();
          if (relative) {
            x += x0;
            y += y0;
          }
          cursor = [x, y];
          current.push(cursor);
        }
      } else if (token.toUpperCase() === "C") {
        // A command letter can be followed by several coordinate sets.
        while (i < tokens.length && !/[MLCZz]/i.test(tokens[i])) {
          let [x1, y1, x2, y2, x, y] = [
            num(),
            num(),
            num(),
            num(),
            num(),
            num(),
          ];
          const [x0, y0] = cursor;
          if (relative) {
            x1 += x0;
            y1 += y0;
            x2 += x0;
            y2 += y0;
            x += x0;
            y += y0;
          }
          for (let s = 1; s <= BEZIER_STEPS; s++) {
            const t = s / BEZIER_STEPS;
            const u = 1 - t;
            current.push([
              u * u * u * x0 +
                3 * u * u * t * x1 +
                3 * u * t * t * x2 +
                t * t * t * x,
              u * u * u * y0 +
                3 * u * u * t * y1 +
                3 * u * t * t * y2 +
                t * t * t * y,
            ]);
          }
          cursor = [x, y];
        }
      } else {
        current.push(start);
        if (current.length > 2) polygons.push(current);
        current = [];
        cursor = start;
      }
    } else {
      i++; // stray number — skip
    }
  }

  if (current.length > 2) polygons.push(current);
  return polygons;
}

/** Even-odd fill test across every subpath. */
function isInside(polygons, px, py) {
  let inside = false;
  for (const poly of polygons) {
    for (let a = 0, b = poly.length - 1; a < poly.length; b = a++) {
      const [xa, ya] = poly[a];
      const [xb, yb] = poly[b];
      if (
        ya > py !== yb > py &&
        px < ((xb - xa) * (py - ya)) / (yb - ya) + xa
      ) {
        inside = !inside;
      }
    }
  }
  return inside;
}

const polygons = PATHS.flatMap(pathToPolygons);

// Scale so the mark stands roughly as tall as the globe is wide, and flip Y
// (SVG grows downward, GL upward). Centre on the viewBox so it sits where the
// globe was.
const scale = 1.85 / VIEWBOX.h;
const cx = VIEWBOX.x + VIEWBOX.w / 2;
const cy = VIEWBOX.y + VIEWBOX.h / 2;

// Jittered grid sampling: even coverage without the clumping of pure random
// rejection sampling. Jitter is deterministic, so output never changes.
const xs = [];
const ys = [];
const cols = 430;
const rows = Math.round(cols * (VIEWBOX.h / VIEWBOX.w));

for (let r = 0; r < rows; r++) {
  for (let c = 0; c < cols; c++) {
    const h = Math.sin(r * 12.9898 + c * 78.233) * 43758.5453;
    const jx = h - Math.floor(h);
    const h2 = Math.sin(c * 39.3468 + r * 11.135) * 24634.6345;
    const jy = h2 - Math.floor(h2);

    const px = VIEWBOX.x + ((c + jx) / cols) * VIEWBOX.w;
    const py = VIEWBOX.y + ((r + jy) / rows) * VIEWBOX.h;

    if (isInside(polygons, px, py)) {
      xs.push((px - cx) * scale);
      ys.push(-(py - cy) * scale);
    }
  }
}

if (xs.length < 1000) {
  throw new Error(
    `Only ${xs.length} points sampled — path parsing likely failed`,
  );
}

// Even stride down to the target count, keeping coverage across the whole mark.
const stride = Math.max(1, xs.length / TARGET_POINTS);
const count = Math.min(TARGET_POINTS, Math.floor(xs.length / stride));
const data = new Int16Array(count * 2);

for (let i = 0; i < count; i++) {
  const src = Math.floor(i * stride);
  data[i * 2] = Math.round(xs[src] * 1000);
  data[i * 2 + 1] = Math.round(ys[src] * 1000);
}

mkdirSync(dirname(OUT), { recursive: true });
writeFileSync(OUT, Buffer.from(data.buffer));

console.log(
  `${xs.length} sampled inside the mark → ${count} written ` +
    `(${(data.byteLength / 1024).toFixed(1)} KB)`,
);
