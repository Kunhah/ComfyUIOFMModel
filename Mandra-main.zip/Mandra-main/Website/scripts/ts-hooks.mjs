/**
 * Module hooks that let `node --test` run the TypeScript under src/ directly.
 *
 * Node 26 strips the types itself; what it can't do is resolve the two things
 * Next's bundler normally handles — the "@/…" alias and extensionless imports —
 * or import a .json module that was written without an import attribute. Doing
 * it here keeps the source honest: no test-only import style leaks into files
 * the app also builds.
 *
 * Node builtins only, deliberately. Same reason `db.ts` uses `node:sqlite`.
 */
import { existsSync, readFileSync, statSync } from "node:fs";
import { fileURLToPath, pathToFileURL } from "node:url";
import { dirname, resolve as resolvePath } from "node:path";

const SRC = pathToFileURL(
  resolvePath(dirname(fileURLToPath(import.meta.url)), "..", "src") + "/",
).href;

const EXTENSIONS = [".ts", ".tsx", ".mts", ".json", ".mjs", ".js"];

/** True for a path that exists and is a file — a directory is not a module. */
function isFile(path) {
  return existsSync(path) && statSync(path).isFile();
}

/**
 * Next resolves "./x" to "./x.ts"; bare Node does not.
 *
 * It also resolves "./x" to "./x/index.ts" when x is a directory, which bare
 * Node rejects outright (ERR_UNSUPPORTED_DIR_IMPORT) rather than falling back.
 * Both forms are used in src/, so both have to be understood here or a module
 * that builds and tests fine fails the moment a script imports it.
 */
function withExtension(url) {
  const path = fileURLToPath(url);
  if (isFile(path)) return url;
  for (const ext of EXTENSIONS) {
    if (isFile(fileURLToPath(url + ext))) return url + ext;
  }
  if (existsSync(path) && statSync(path).isDirectory()) {
    const dir = url.endsWith("/") ? url : `${url}/`;
    for (const ext of EXTENSIONS) {
      if (isFile(fileURLToPath(`${dir}index${ext}`)))
        return `${dir}index${ext}`;
    }
  }
  return url;
}

export async function resolve(specifier, context, next) {
  if (specifier.startsWith("@/")) {
    return {
      url: withExtension(new URL(specifier.slice(2), SRC).href),
      shortCircuit: true,
    };
  }
  if (specifier.startsWith(".") && context.parentURL?.startsWith("file:")) {
    const target = new URL(specifier, context.parentURL).href;
    const resolved = withExtension(target);
    if (resolved !== target) return { url: resolved, shortCircuit: true };
  }
  return next(specifier, context);
}

export async function load(url, context, next) {
  // `import raw from "….json"` has no `with { type: "json" }`, because the
  // bundler doesn't need one. Hand Node the parsed value instead.
  if (url.startsWith("file:") && url.endsWith(".json")) {
    const source = readFileSync(fileURLToPath(url), "utf8");
    return {
      format: "module",
      source: `export default ${source};`,
      shortCircuit: true,
    };
  }
  return next(url, context);
}
