import {
  MonitorSmartphone,
  LayoutDashboard,
  BrainCircuit,
  Workflow,
  Megaphone,
  type LucideIcon,
} from "lucide-react";

/**
 * A Rede's content.
 *
 * Everything here is either a service Mandra sells or a system that is
 * genuinely running in this repository. Nothing in this file is a metric, a
 * client name, or a testimonial — the previous site's were invented, and the
 * proof on this page is deliberately made of things that can be shown instead.
 */

export type Line = {
  /** The stamped identifier on the plate. Also the anchor id. */
  code: string;
  id: string;
  name: string;
  /** What the line carries, in the customer's words — one short phrase. */
  load: string;
  /** The sentence that makes the line worth terminating. */
  detail: string;
  items: string[];
  icon: LucideIcon;
};

export const lines: Line[] = [
  {
    code: "LN-01",
    id: "sites",
    name: "Sites",
    load: "ser encontrado",
    detail:
      "O site é o único ponto da sua empresa que trabalha às duas da manhã. Ele carrega quem procurou por você e ainda não sabe seu nome.",
    items: ["Landing pages", "Institucionais", "Portais", "E-commerce", "Blogs"],
    icon: MonitorSmartphone,
  },
  {
    code: "LN-02",
    id: "sistemas",
    name: "Sistemas",
    load: "operar sem planilha",
    detail:
      "O jeito como sua empresa trabalha não cabe num software de prateleira. Construímos o sistema em volta da operação que já existe.",
    items: ["CRMs", "ERPs", "Dashboards", "Painéis administrativos", "SaaS"],
    icon: LayoutDashboard,
  },
  {
    code: "LN-03",
    id: "ia",
    name: "Inteligência Artificial",
    load: "atender e decidir",
    detail:
      "IA aplicada ao que a sua empresa já faz: ler, responder, classificar e resumir — não uma demonstração, um turno de trabalho.",
    items: [
      "Chatbots",
      "Assistentes",
      "Análise de dados",
      "Atendimento com IA",
      "Visão computacional",
    ],
    icon: BrainCircuit,
  },
  {
    code: "LN-04",
    id: "automacao",
    name: "Automação",
    load: "responder sozinho",
    detail:
      "As tarefas que alguém faz de novo toda segunda-feira. Ligadas ponta a ponta, elas param de depender de alguém lembrar.",
    items: ["WhatsApp", "E-mail", "CRM", "Fluxos", "Integrações", "APIs"],
    icon: Workflow,
  },
  {
    code: "LN-05",
    id: "midia",
    name: "Publicidade digital",
    load: "trazer demanda",
    detail:
      "Google Ads ligado ao site e ao atendimento, para que o dinheiro do anúncio termine numa conversa e não num clique perdido.",
    items: [
      "Google Ads",
      "Campanhas de pesquisa",
      "Remarketing",
      "Landing pages",
      "Mensuração e relatórios",
    ],
    icon: Megaphone,
  },
];

/**
 * The before state, written as absences rather than as pain-point copy. Each
 * one is a line that exists in every business and is terminated nowhere.
 */
export const tangle = [
  { fault: "SEM SINAL", text: "O site que ninguém acha" },
  { fault: "CURTO", text: "O anúncio que gasta e não vende" },
  { fault: "ABERTO", text: "A mensagem de sábado sem resposta" },
  { fault: "ISOLADO", text: "A planilha que só uma pessoa entende" },
  { fault: "PERDA", text: "O cliente que sumiu e ninguém viu" },
] as const;

export const rota = [
  {
    step: "01",
    name: "Levantamento",
    text: "Vamos até a operação e mapeamos as pontas soltas antes de propor qualquer coisa.",
  },
  {
    step: "02",
    name: "Projeto",
    text: "Definimos o que entra na caixa, o que fica de fora e por onde cada linha passa.",
  },
  {
    step: "03",
    name: "Desenho",
    text: "Projetamos a experiência e a interface antes de escrever a primeira linha de código.",
  },
  {
    step: "04",
    name: "Construção",
    text: "Site, sistema, automação e campanha construídos para conversarem entre si desde o primeiro dia.",
  },
  {
    step: "05",
    name: "Ensaio",
    text: "Testamos carga, falha e borda — a rede tem que aguentar o dia ruim, não o dia bom.",
  },
  {
    step: "06",
    name: "Energização",
    text: "Ligamos linha por linha, com você olhando junto, e treinamos quem vai operar.",
  },
  {
    step: "07",
    name: "Operação",
    text: "Acompanhamos, medimos e ajustamos. Uma rede sem manutenção volta a virar emaranhado.",
  },
] as const;

/**
 * The proof section. These are the systems running inside Mandra itself, which
 * is the one claim on this page a competitor cannot copy-paste — and the only
 * kind of proof available while there are no client metrics on hand.
 */
export const carga = [
  {
    code: "SYS-01",
    name: "CRM e funil",
    text: "Contas, leads, funil e histórico de contato. É onde a nossa própria operação comercial vive.",
  },
  {
    code: "SYS-02",
    name: "Prospector",
    text: "Busca empresas em registros públicos por cidade e ramo, e devolve quem ainda não tem presença digital.",
  },
  {
    code: "SYS-03",
    name: "Agente de WhatsApp",
    text: "Atende, qualifica e agenda em conversa real, com escalada para uma pessoa quando precisa.",
  },
  {
    code: "SYS-04",
    name: "Portal do cliente",
    text: "Quem contrata um site recebe um login: os contatos que o formulário recebe caem no funil dele.",
  },
  {
    code: "SYS-05",
    name: "Análise de reunião",
    text: "Transcreve a conversa, separa o que foi combinado e devolve os próximos passos.",
  },
] as const;
