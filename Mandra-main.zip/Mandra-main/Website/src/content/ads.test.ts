import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { adPages, adPageBySlug } from "./ads";

/**
 * The landing page registry's invariants.
 *
 * Everything checked here is something that costs money when it is wrong and
 * that nothing else reports. A page whose H1 does not contain the search it is
 * bought for gets a worse quality score and a higher cost per click; a meta
 * title past the pixel budget gets truncated in the result with an ellipsis; a
 * page with fewer than a couple of FAQ entries loses the expanded result the
 * structured data is claiming. None of it throws at runtime — the page renders
 * beautifully and just earns less, which is the worst failure mode there is.
 *
 * The uniqueness checks are in `ads.ts` itself rather than here, because a
 * duplicate slug has to fail the build and not only the test run.
 */

/** Google truncates the result around here, and the suffix is " · Mandra". */
const TITLE_BUDGET = 60;
const SUFFIX = " · Mandra".length;

/** Below this, the description gets padded by Google with page text. */
const DESCRIPTION_MIN = 110;
const DESCRIPTION_MAX = 165;

function words(value: string): string[] {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .split(/[^a-z0-9]+/)
    .filter((word) => word.length > 3);
}

describe("ad landing pages", () => {
  it("has a page for every ad group we intend to run", () => {
    assert.ok(adPages.length >= 6);
    assert.equal(adPageBySlug.size, adPages.length);
  });

  for (const page of adPages) {
    describe(page.slug, () => {
      it("uses a URL-safe slug", () => {
        assert.match(page.slug, /^[a-z0-9]+(-[a-z0-9]+)*$/);
      });

      it("keeps the title inside what a result shows", () => {
        assert.ok(
          page.metaTitle.length + SUFFIX <= TITLE_BUDGET,
          `"${page.metaTitle}" + sufixo = ${page.metaTitle.length + SUFFIX} caracteres`,
        );
      });

      it("writes a description Google will not rewrite", () => {
        assert.ok(
          page.metaDescription.length >= DESCRIPTION_MIN &&
            page.metaDescription.length <= DESCRIPTION_MAX,
          `${page.metaDescription.length} caracteres`,
        );
      });

      it("puts the phone number in the description", () => {
        // The description is what a searcher reads before clicking, and on a
        // phone the number in it is itself a conversion path.
        assert.match(page.metaDescription, /98425-6517/);
      });

      it("repeats the search back in the H1", () => {
        // The single biggest lever on quality score: the headline has to
        // contain most of the words of the keyword the ad group buys.
        const headline = new Set(words(page.h1.join(" ")));
        const anchor = words(page.keywords[0]);
        const hits = anchor.filter((word) => headline.has(word)).length;
        assert.ok(
          hits >= Math.ceil(anchor.length * 0.6),
          `H1 "${page.h1.join(" ")}" não repete "${page.keywords[0]}"`,
        );
      });

      it("carries enough of the ad group's terms to be worth a metatag", () => {
        assert.ok(page.keywords.length >= 5);
      });

      it("has a funnel's worth of content", () => {
        assert.ok(page.assurances.length >= 3, "assurances");
        assert.ok(page.pains.length >= 3, "pains");
        assert.ok(page.deliverables.length >= 5, "deliverables");
        assert.ok(page.steps.length >= 3, "steps");
        assert.ok(page.faq.length >= 4, "faq — o FAQPage precisa valer a pena");
      });

      it("splits the headline in two so the band can break it", () => {
        assert.equal(page.h1.length, 2);
        assert.ok(page.h1.every((half) => half.trim().length > 0));
      });

      it("opens WhatsApp with something already typed", () => {
        assert.ok(page.whatsappMessage.length > 30);
      });

      it("names the page it came from in the WhatsApp opener", () => {
        // The opener is the only attribution a wa.me link carries, so it has
        // to say which of the ad pages produced the conversation.
        assert.match(page.whatsappMessage, /Vim pela página/);
      });

      it("keeps the deliverable codes unique within the page", () => {
        const codes = new Set(page.deliverables.map((item) => item.code));
        assert.equal(codes.size, page.deliverables.length);
      });

      it("never asks a question twice", () => {
        const questions = new Set(page.faq.map((entry) => entry.q));
        assert.equal(questions.size, page.faq.length);
      });
    });
  }

  it("does not ship two pages with the same headline", () => {
    // Near-identical pages are duplicate content to a crawler and a bounce to
    // a reader. The H1 is the cheapest place to catch a copy-paste.
    const headlines = new Set(adPages.map((page) => page.h1.join(" ")));
    assert.equal(headlines.size, adPages.length);
  });

  it("does not open WhatsApp with the same message twice", () => {
    // Two identical openers means two landing pages you cannot tell apart in
    // the inbox, which is the whole point of writing them per page.
    const openers = new Set(adPages.map((page) => page.whatsappMessage));
    assert.equal(openers.size, adPages.length);
  });

  it("does not ship two pages with the same description", () => {
    const descriptions = new Set(adPages.map((page) => page.metaDescription));
    assert.equal(descriptions.size, adPages.length);
  });
});
