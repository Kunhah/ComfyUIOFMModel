export const navLinks = [
  { label: "O emaranhado", href: "#emaranhado" },
  { label: "As linhas", href: "#linhas" },
  { label: "A rota", href: "#rota" },
  { label: "O que já roda", href: "#carga" },
  { label: "Contato", href: "#contato" },
] as const;

/**
 * Second footer column — the services, pointing at a real page wherever one
 * exists.
 *
 * The two that resolve to a page are the two with a landing page written for
 * them, and that is the point: the footer is on every marketing page, so it is
 * how a crawler reaches the ad pages without being told about the sitemap. The
 * remaining anchors are prefixed with `/` so they still work from
 * `/privacidade` and `/termos`, where a bare `#sistemas` goes nowhere.
 */
export const footerServiceLinks = [
  { label: "Criação de sites", href: "/criacao-de-sites" },
  { label: "Sistemas", href: "/#sistemas" },
  { label: "Inteligência Artificial", href: "/#ia" },
  { label: "Automação no WhatsApp", href: "/automacao-whatsapp" },
  { label: "Publicidade digital", href: "/#midia" },
  { label: "Parceria para agências", href: "/parceria-agencias" },
] as const;

/**
 * Third footer column — the pages written for one trade each.
 *
 * Same reason as above: an ad landing page with no internal link is a page the
 * paid click has to carry on its own, and these are the ones most likely to
 * rank for a search nobody is bidding much on.
 */
/**
 * Third footer column — a curated handful of the per-trade pages.
 *
 * Deliberately not all of them. A footer listing every landing page is a
 * footer nobody reads; the sitemap is what makes
 * every one of them crawlable, and this column is for the ones a human
 * visitor might actually want. Rotate it as the campaign learns which trades
 * convert.
 */
export const footerSegmentLinks = [
  { label: "Sites em Florianópolis", href: "/criacao-de-sites-florianopolis" },
  { label: "Energia solar", href: "/sites-energia-solar" },
  { label: "Oficina mecânica", href: "/sites-oficina-mecanica" },
  { label: "Ar condicionado", href: "/sites-ar-condicionado" },
  { label: "Clínica odontológica", href: "/sites-clinica-odontologica" },
  { label: "Advocacia", href: "/sites-advocacia" },
  { label: "Contabilidade", href: "/sites-contabilidade" },
  { label: "Imobiliária", href: "/sites-imobiliaria" },
] as const;
