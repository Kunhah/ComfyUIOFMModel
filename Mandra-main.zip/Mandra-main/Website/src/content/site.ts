export const site = {
  name: "Mandra",
  url: "https://mandra.com.br",
  tagline: "Soluções digitais inteligentes",
  description:
    "Criamos sites, sistemas, automações, soluções com Inteligência Artificial e campanhas de Google Ads para empresas que querem crescer.",
  blurb:
    "Sites, automação, Inteligência Artificial e publicidade digital para empresas que querem crescer.",
  // The phone is real and is the site's primary conversion route — the ad
  // landing pages under `src/app/(ads)/` exist to end in a tap on it, so it is
  // rendered rather than hidden. E-mail, address, and the social URLs below are
  // still inherited placeholders; replace them before launch.
  contact: {
    phone: "(48) 98425-6517",
    phoneHref: "tel:+5548984256517",
    /** E.164, no punctuation — what wa.me and schema.org both want. */
    phoneE164: "+5548984256517",
    whatsapp: "5548984256517",
    email: "contato@mandra.com.br",
    emailHref: "mailto:contato@mandra.com.br",
    address: "Florianópolis, SC · Brasil",
    /** Where the ads are bought and what the landing pages claim to serve. */
    region: { locality: "Florianópolis", uf: "SC", country: "BR" },
  },
  social: [
    { label: "LinkedIn", href: "https://linkedin.com", icon: "linkedin" },
    { label: "Behance", href: "https://behance.net", icon: "behance" },
    { label: "Instagram", href: "https://instagram.com", icon: "instagram" },
    { label: "YouTube", href: "https://youtube.com", icon: "youtube" },
    { label: "GitHub", href: "https://github.com", icon: "github" },
  ],
} as const;

/**
 * The WhatsApp deep link, with the opening message already typed.
 *
 * A pre-filled message is the difference between a tap and a blank chat nobody
 * writes into, and it is also what tells us which page the conversation came
 * from — the ad landing pages each pass their own.
 */
export function whatsappHref(message: string) {
  return `https://wa.me/${site.contact.whatsapp}?text=${encodeURIComponent(message)}`;
}

export const legalLinks = [
  { label: "Política de Privacidade", href: "/privacidade" },
  { label: "Termos de Uso", href: "/termos" },
] as const;
