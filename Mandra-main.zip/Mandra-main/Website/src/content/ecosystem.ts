export type EcosystemNode = {
  id: string;
  title: string;
  caption: string;
  /** Key into the icon map in `ecosystem.tsx`. */
  icon: string;
};

/** Feeds into Mandra Core from the left. */
export const inputNodes: EcosystemNode[] = [
  {
    id: "website",
    title: "Website",
    caption: "Presença digital",
    icon: "monitor",
  },
  {
    id: "ecommerce",
    title: "E-commerce",
    caption: "Vendas online",
    icon: "cart",
  },
  {
    id: "landing",
    title: "Landing Pages",
    caption: "Geração de leads",
    icon: "layout",
  },
];

/** Receives from Mandra Core on the right. */
export const outputNodes: EcosystemNode[] = [
  { id: "crm", title: "CRM", caption: "Relacionamento", icon: "users" },
  {
    id: "whatsapp",
    title: "WhatsApp",
    caption: "Atendimento",
    icon: "whatsapp",
  },
  { id: "email", title: "E-mail", caption: "Comunicação", icon: "mail" },
];

/** Sits above the core. */
export const topNode: EcosystemNode = {
  id: "ia",
  title: "IA & Automação",
  caption: "Inteligência que executa",
  icon: "brain",
};

/** Sits below the core. */
export const baseNodes: EcosystemNode[] = [
  {
    id: "dashboard",
    title: "Dashboard",
    caption: "Dados em tempo real",
    icon: "chart",
  },
  { id: "api", title: "API", caption: "Conexões ilimitadas", icon: "plug" },
  { id: "erp", title: "ERP", caption: "Gestão completa", icon: "boxes" },
];
