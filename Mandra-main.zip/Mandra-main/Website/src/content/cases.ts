export type CaseStudy = {
  id: string;
  category: string;
  title: string;
  result: string;
  stack: string[];
  /** Gradient stand-in until real screenshots land. */
  gradient: string;
};

export const caseStudies: CaseStudy[] = [
  {
    id: "ecommerce",
    category: "E-commerce",
    title: "Plataforma de E-commerce",
    result: "+142% nas vendas em 6 meses",
    stack: ["Next.js", "Stripe", "PostgreSQL"],
    gradient: "from-brand-300/40 via-brand-600/12 to-ink-950",
  },
  {
    id: "crm",
    category: "Sistema Web",
    title: "CRM Personalizado",
    result: "Redução de 60% no tempo operacional da equipe",
    stack: ["React", "Node.js", "PostgreSQL"],
    gradient: "from-brand-400/40 via-brand-700/12 to-ink-950",
  },
  {
    id: "automacao",
    category: "Automação",
    title: "Automação de Processos",
    result: "+3.2k horas economizadas por mês em tarefas manuais",
    stack: ["Make", "API", "WhatsApp"],
    gradient: "from-brand-200/40 via-brand-500/12 to-ink-950",
  },
  {
    id: "chatbot",
    category: "IA & Chatbot",
    title: "Assistente Inteligente",
    result: "Atendimento 24/7 com IA e aumento de 85% na conversão",
    stack: ["OpenAI", "Node.js", "WhatsApp"],
    gradient: "from-brand-500/45 via-brand-800/12 to-ink-950",
  },
];
