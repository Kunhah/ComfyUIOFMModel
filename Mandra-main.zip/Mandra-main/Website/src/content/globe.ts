/** Marker nodes on the globe. Weighted toward Mandra's home market. */
export const globeCities = [
  { name: "São Paulo", lat: -23.55, lon: -46.63 },
  { name: "Rio de Janeiro", lat: -22.91, lon: -43.17 },
  { name: "Brasília", lat: -15.79, lon: -47.88 },
  { name: "Recife", lat: -8.05, lon: -34.88 },
  { name: "Buenos Aires", lat: -34.6, lon: -58.38 },
  { name: "Cidade do México", lat: 19.43, lon: -99.13 },
  { name: "Miami", lat: 25.76, lon: -80.19 },
  { name: "Nova York", lat: 40.71, lon: -74.01 },
  { name: "Lisboa", lat: 38.72, lon: -9.14 },
  { name: "Londres", lat: 51.51, lon: -0.13 },
  { name: "Berlim", lat: 52.52, lon: 13.4 },
  { name: "Dubai", lat: 25.2, lon: 55.27 },
  { name: "Singapura", lat: 1.35, lon: 103.82 },
  { name: "Tóquio", lat: 35.68, lon: 139.69 },
  { name: "Sydney", lat: -33.87, lon: 151.21 },
  { name: "Joanesburgo", lat: -26.2, lon: 28.05 },
] as const;

/** Index pairs into `globeCities` — the routes that light up. */
export const globeRoutes: [number, number][] = [
  [0, 7], // São Paulo → Nova York
  [0, 8], // São Paulo → Lisboa
  [0, 4], // São Paulo → Buenos Aires
  [0, 13], // São Paulo → Tóquio
  [0, 15], // São Paulo → Joanesburgo
  [1, 6], // Rio → Miami
  [2, 9], // Brasília → Londres
  [3, 10], // Recife → Berlim
  [5, 7], // Cidade do México → Nova York
  [11, 12], // Dubai → Singapura
];
