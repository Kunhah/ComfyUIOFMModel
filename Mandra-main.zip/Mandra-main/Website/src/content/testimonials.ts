export type Testimonial = {
  id: string;
  name: string;
  role: string;
  rating: number;
  quote: string;
  /** Initials fallback until real headshots are supplied. */
  initials: string;
};

export const testimonials: Testimonial[] = [
  {
    id: "carlos",
    name: "Carlos Mendes",
    role: "CEO, TechStore",
    rating: 5,
    quote:
      "A Mandra transformou nossa operação com um sistema completo e intuitivo. O resultado foi além do que esperávamos.",
    initials: "CM",
  },
  {
    id: "juliana",
    name: "Juliana Rocha",
    role: "Diretora, Clínica Viva",
    rating: 5,
    quote:
      "O atendimento e a qualidade técnica são impecáveis. Nossa automação com IA revolucionou nosso atendimento.",
    initials: "JR",
  },
  {
    id: "rafael",
    name: "Rafael Lima",
    role: "Founder, LogiTech",
    rating: 5,
    quote:
      "Profissionais extremamente competentes e entregas sempre no prazo. Recomendo de olhos fechados.",
    initials: "RL",
  },
  {
    id: "patricia",
    name: "Patrícia Nunes",
    role: "COO, Grupo Aurora",
    rating: 5,
    quote:
      "Ganhamos previsibilidade e escala. Os dashboards viraram a fonte de verdade da diretoria.",
    initials: "PN",
  },
];
