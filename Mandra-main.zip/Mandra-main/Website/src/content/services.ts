import {
  MonitorSmartphone,
  LayoutDashboard,
  BrainCircuit,
  Workflow,
  Megaphone,
  type LucideIcon,
} from "lucide-react";

export type Service = {
  id: string;
  title: string;
  icon: LucideIcon;
  items: string[];
};

export const services: Service[] = [
  {
    id: "sites",
    title: "Desenvolvimento de Sites",
    icon: MonitorSmartphone,
    items: ["Landing Pages", "Institucionais", "Portais", "E-commerce", "Blogs"],
  },
  {
    id: "sistemas",
    title: "Sistemas Web",
    icon: LayoutDashboard,
    items: ["CRMs", "ERPs", "Dashboards", "Painéis Admin", "SaaS"],
  },
  {
    id: "ia",
    title: "Inteligência Artificial",
    icon: BrainCircuit,
    items: [
      "Chatbots",
      "Assistentes",
      "Análise de dados",
      "Atendimento IA",
      "Visão computacional",
    ],
  },
  {
    id: "automacao",
    title: "Automação",
    icon: Workflow,
    items: ["WhatsApp", "E-mail", "CRM", "Fluxos", "Integrações", "APIs"],
  },
  {
    id: "publicidade-digital",
    title: "Publicidade Digital",
    icon: Megaphone,
    items: [
      "Google Ads",
      "Campanhas de pesquisa",
      "Remarketing",
      "Landing Pages",
      "Mensuração e relatórios",
    ],
  },
];
