export type ProcessStep = {
  step: number;
  title: string;
  description: string;
};

export const processSteps: ProcessStep[] = [
  {
    step: 1,
    title: "Descoberta",
    description: "Entendemos seu negócio e desafios",
  },
  {
    step: 2,
    title: "Planejamento",
    description: "Definimos a estratégia e o roadmap",
  },
  {
    step: 3,
    title: "Design",
    description: "Projetamos a melhor experiência",
  },
  {
    step: 4,
    title: "Desenvolvimento",
    description: "Transformamos em soluções reais",
  },
  {
    step: 5,
    title: "Testes",
    description: "Garantimos qualidade e performance",
  },
  {
    step: 6,
    title: "Entrega",
    description: "Implantamos e treinamos sua equipe",
  },
  {
    step: 7,
    title: "Suporte",
    description: "Acompanhamento contínuo",
  },
];
