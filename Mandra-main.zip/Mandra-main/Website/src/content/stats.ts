import { Users, Briefcase, Clock, Star, type LucideIcon } from "lucide-react";

export type Stat = {
  value: string;
  label: string;
  icon: LucideIcon;
};

export const stats: Stat[] = [
  { value: "120+", label: "Empresas atendidas", icon: Users },
  { value: "350+", label: "Projetos entregues", icon: Briefcase },
  { value: "3.2K+", label: "Horas economizadas", icon: Clock },
  { value: "98%", label: "Clientes satisfeitos", icon: Star },
];

/** Floating cards layered around the hero globe. */
export const heroMetrics = [
  {
    id: "crescimento",
    icon: "trending-up",
    title: "Crescimento",
    value: "+34.8%",
    caption: "em receita média",
  },
  {
    id: "automacao",
    icon: "zap",
    title: "Automação",
    value: "2.317h",
    caption: "de processos automatizados",
  },
  {
    id: "ia",
    icon: "brain",
    title: "IA Inteligente",
    value: "+92%",
    caption: "de eficiência operacional",
  },
  {
    id: "sistemas",
    icon: "boxes",
    title: "Sistemas",
    value: "100%",
    caption: "integração e escalabilidade",
  },
] as const;
