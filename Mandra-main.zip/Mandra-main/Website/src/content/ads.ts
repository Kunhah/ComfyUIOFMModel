/**
 * The Google Ads landing pages.
 *
 * One entry per ad group, and the ad group's keywords land here and nowhere
 * else. That is the whole point: a person who searched "site para oficina
 * mecânica" must not arrive on a page about an agency that does five things,
 * because the ad's quality score, the page's conversion rate and the cost of
 * the click are all decided by whether the first line of the page repeats the
 * search back.
 *
 * Two rules govern the copy in this file:
 *
 *   1. **Every page is written, not templated.** Six near-identical pages are
 *      duplicate content to a crawler and a bounce to a reader, so the pains,
 *      the deliverables and the FAQ are specific to the trade each page sells
 *      to. Only the page's *shape* is shared.
 *   2. **Nothing here asserts a number we do not have.** PRODUCT.md records
 *      that every metric on the old site was invented; none of them come back.
 *      The proof offered is the work itself — the CRM, the prospector, the
 *      WhatsApp agent and the client portal that live in this repository and
 *      are in daily use.
 *
 * `investimento` is the one field deliberately left null: a published price
 * band raises lead quality a lot, and it is a commercial decision rather than
 * a copy decision. Set it and the page grows a price row; leave it and the
 * page never mentions price.
 */

export type AdFaq = { q: string; a: string };

export type AdPage = {
  slug: string;
  /** The Google Ads ad group this page is the only destination for. */
  adGroup: string;
  /** The stamped plate code, and this page's position in the campaign. */
  code: string;
  metaTitle: string;
  metaDescription: string;
  /** The ad group's terms, in the page's own metadata. */
  keywords: string[];
  /** Split in two so the second half can carry the amber. */
  h1: [string, string];
  deck: string;
  /** Three answers to "por que agora", as a divided strip under the action. */
  assurances: string[];
  painsHeading: string;
  painsDeck: string;
  pains: { title: string; text: string }[];
  deliverablesHeading: string;
  deliverablesDeck: string;
  deliverables: { code: string; name: string; text: string }[];
  stepsHeading: string;
  steps: { step: string; name: string; text: string }[];
  faq: AdFaq[];
  closing: { heading: [string, string]; text: string };
  /**
   * The message already typed into WhatsApp when the button is tapped.
   *
   * Written per page, never templated off the trade's name. WhatsApp gives a
   * link no metadata channel — the text *is* the attribution — so this opener
   * is the only thing that tells you which of the ad pages produced the
   * conversation before you have asked a single question. It therefore names
   * the page it came from and asks for something only that page offers, which
   * also means you open the chat already knowing what the person read.
   *
   * `ads.test.ts` enforces that no two are the same.
   */
  whatsappMessage: string;
  /** schema.org `Service.serviceType`. */
  serviceType: string;
  /** A published price band, or null for a page that never mentions price. */
  investimento: string | null;
};

export const adPages: AdPage[] = [
  {
    slug: "criacao-de-sites",
    adGroup: "Sites — alta intenção",
    code: "LP-01",
    metaTitle: "Criação de sites profissionais para empresas",
    metaDescription:
      "Empresa de criação de sites para negócios que precisam ser encontrados no Google e receber orçamento pelo WhatsApp. Orçamento por telefone: (48) 98425-6517.",
    keywords: [
      "criação de sites profissionais",
      "empresa de criação de sites",
      "criação de site para empresa",
      "desenvolvimento de site empresarial",
      "orçamento criação de site",
      "agência de criação de sites",
      "site profissional para empresa",
    ],
    h1: [
      "Criação de sites para empresas que precisam",
      "aparecer e receber orçamento",
    ],
    deck: "Um site não é um folheto na internet. É o único ponto da sua empresa que trabalha às duas da manhã, responde quem pesquisou seu serviço e entrega o contato no seu WhatsApp. É esse que a gente constrói.",
    assurances: [
      "Você fala direto com quem vai construir o site",
      "Orçamento fechado antes de começar, sem hora extra",
      "Feito para carregar rápido e ser encontrado no Google",
    ],
    painsHeading: "O site que não traz cliente sempre falha no mesmo lugar",
    painsDeck:
      "Nenhum desses é um problema de design. São problemas de engenharia e de intenção, e são os quatro que mais aparecem quando abrimos um site que não converte.",
    pains: [
      {
        title: "Demora a abrir no celular",
        text: "A maior parte de quem procura seu serviço está no celular, num 4G médio. Um site que leva mais de três segundos perde a visita antes de mostrar o que faz — e o Google sabe disso e mostra menos o seu site.",
      },
      {
        title: "Não diz o que a empresa faz na primeira tela",
        text: "Quem chegou do Google tem uma pergunta específica. Se a primeira tela é uma foto bonita e a palavra 'soluções', a pessoa volta para a busca e clica no concorrente de baixo.",
      },
      {
        title: "O contato está escondido no rodapé",
        text: "Cada rolagem entre a pessoa e o telefone é uma parte dos visitantes que some. O contato tem que estar na primeira tela, fixo na tela do celular e repetido a cada seção.",
      },
      {
        title: "Não existe para o Google",
        text: "Sem títulos, descrições, dados estruturados e um sitemap, o site pode estar no ar há dois anos e continuar invisível para quem procura exatamente o que você vende.",
      },
    ],
    deliverablesHeading: "O que entra no site",
    deliverablesDeck:
      "Tudo abaixo faz parte da entrega. Não é uma lista de pacotes — é o mínimo para um site de empresa funcionar.",
    deliverables: [
      {
        code: "TR-01",
        name: "Site sob medida, não template",
        text: "Estrutura, textos e páginas montados a partir do que a sua empresa vende, e não um tema comprado com o conteúdo trocado.",
      },
      {
        code: "TR-02",
        name: "Rápido no celular",
        text: "Construído em Next.js e servido pronto. Imagens otimizadas, nada de plugin pesado, e a primeira tela aparece antes de a pessoa desistir.",
      },
      {
        code: "TR-03",
        name: "SEO técnico completo",
        text: "Títulos e descrições por página, dados estruturados, sitemap, robots, endereços limpos e páginas separadas por serviço — o que faz o Google entender e mostrar o site.",
      },
      {
        code: "TR-04",
        name: "Botão de WhatsApp e telefone em todo lugar",
        text: "Fixo no celular, na primeira tela e no fim de cada seção. O caminho entre a visita e a conversa é um toque.",
      },
      {
        code: "TR-05",
        name: "Formulário que chega onde você lê",
        text: "O contato cai no seu WhatsApp ou e-mail na hora, com a origem marcada — e, se quiser, dentro de um CRM.",
      },
      {
        code: "TR-06",
        name: "Google Analytics e Search Console",
        text: "Instalados e configurados. Sem medição não há como saber se o site trouxe cliente, e opinião não é dado.",
      },
      {
        code: "TR-07",
        name: "Hospedagem, domínio e certificado",
        text: "Colocamos no ar, com HTTPS e domínio configurado. Você não precisa saber o que é um registro DNS.",
      },
    ],
    stepsHeading: "Do telefonema ao site no ar",
    steps: [
      {
        step: "01",
        name: "A ligação",
        text: "Quinze minutos. Você conta o que a empresa faz, para quem vende e o que hoje traz cliente. É levantamento, não apresentação comercial.",
      },
      {
        step: "02",
        name: "O orçamento",
        text: "Escopo, prazo e preço por escrito, fechados. Se o que você precisa não justifica o investimento, a gente diz isso na ligação.",
      },
      {
        step: "03",
        name: "A construção",
        text: "Você acompanha o site num endereço de teste desde o primeiro dia e responde a uma rodada de ajustes antes de ele ir ao ar.",
      },
      {
        step: "04",
        name: "No ar e medindo",
        text: "Publicação, medição ligada e uma conversa depois de trinta dias sobre o que os dados mostraram.",
      },
    ],
    faq: [
      {
        q: "Quanto custa a criação de um site para empresa?",
        a: "Depende do número de páginas, de haver ou não integração com sistema, e de quem escreve os textos. Fechamos o preço na primeira ligação, por escrito, antes de qualquer trabalho começar — e não cobramos hora extra sobre o escopo acordado.",
      },
      {
        q: "Em quanto tempo o site fica pronto?",
        a: "Um site institucional ou uma página de captação costuma levar de duas a quatro semanas, contadas a partir do momento em que temos textos e imagens. O prazo exato entra no orçamento e é um compromisso, não uma estimativa.",
      },
      {
        q: "Vocês fazem o site aparecer no Google?",
        a: "O site sai com toda a base técnica que o Google precisa: estrutura, velocidade, dados estruturados, sitemap e páginas separadas por serviço. Aparecer nas primeiras posições em buscas disputadas é trabalho contínuo de conteúdo e autoridade, e isso a gente contrata à parte ou acelera com Google Ads.",
      },
      {
        q: "Eu consigo editar o site depois?",
        a: "Sim. Entregamos com um painel para as partes que mudam — textos, serviços, publicações — e sem painel para o que não deveria mudar, que é justamente o que costuma quebrar um site.",
      },
      {
        q: "Vocês atendem fora de Florianópolis?",
        a: "Sim. O trabalho é feito por telefone, WhatsApp e videochamada, e atendemos empresas no Brasil inteiro. Estamos em Florianópolis, o que só significa que reuniões presenciais são possíveis na Grande Florianópolis.",
      },
      {
        q: "E se eu já tenho um site?",
        a: "Aí a primeira conversa é sobre se vale reconstruir ou corrigir. Nem todo site precisa ser jogado fora; alguns precisam de velocidade e SEO, não de um redesenho. Falamos isso na ligação, de graça.",
      },
    ],
    closing: {
      heading: ["Ligue agora e saia da ligação", "sabendo quanto custa"],
      text: "Quinze minutos no telefone resolvem o que uma semana de trocas de e-mail não resolve. Você conta o que precisa e recebe escopo, prazo e preço.",
    },
    whatsappMessage:
      "Olá! Vim pela página de criação de sites. Quero um orçamento de site para a minha empresa — pode me passar escopo, prazo e valor?",
    serviceType: "Criação de sites para empresas",
    investimento: null,
  },

  {
    slug: "criacao-de-sites-florianopolis",
    adGroup: "Sites — Florianópolis (local)",
    code: "LP-02",
    metaTitle: "Criação de sites em Florianópolis — SC",
    metaDescription:
      "Desenvolvedor de sites em Florianópolis, São José, Palhoça e Biguaçu. Site profissional, rápido e encontrável no Google. Fale agora: (48) 98425-6517.",
    keywords: [
      "criação de sites Florianópolis",
      "desenvolvedor de sites Florianópolis",
      "agência de criação de sites Florianópolis",
      "criação de sites São José SC",
      "empresa de criação de sites em Santa Catarina",
      "site profissional Florianópolis",
    ],
    h1: ["Criação de sites em Florianópolis", "com quem atende o telefone"],
    deck: "Atendemos empresas de Florianópolis, São José, Palhoça, Biguaçu e região. Você fala com quem constrói o site, não com um atendimento que repassa o pedido para outra cidade.",
    assurances: [
      "Atendimento na Grande Florianópolis, presencial se você preferir",
      "Você fala direto com quem vai construir o site",
      "Orçamento por escrito na primeira conversa",
    ],
    painsHeading: "O que costuma dar errado na contratação de um site aqui",
    painsDeck:
      "Não é falta de fornecedor — é o formato. Estes são os quatro desencontros que mais escutamos de empresas da região que já contrataram um site antes.",
    pains: [
      {
        title: "O site foi entregue e ninguém mais respondeu",
        text: "O trabalho acaba na publicação, e a primeira dúvida seis meses depois não encontra ninguém do outro lado. Aqui existe um responsável com nome e telefone.",
      },
      {
        title: "Está no ar, mas não aparece para quem é daqui",
        text: "Um site sem página de cidade, sem dados estruturados de negócio local e sem perfil de empresa no Google não compete com quem fez esse básico — mesmo sendo melhor.",
      },
      {
        title: "Você virou o gerente de projeto sem querer",
        text: "Três fornecedores diferentes para site, domínio e e-mail, e a pessoa no meio explicando um para o outro é você. Entregamos a coisa inteira funcionando.",
      },
      {
        title: "O site é bonito e não pede nada",
        text: "Design premiado que não diz o que fazer em seguida é decoração. A conversão vem de dizer com clareza qual é o próximo passo, e de ele caber num toque.",
      },
    ],
    deliverablesHeading: "O que entra no site",
    deliverablesDeck:
      "A mesma entrega para uma empresa em Florianópolis ou em Palhoça — o que muda é que aqui a reunião pode ser na sua sala.",
    deliverables: [
      {
        code: "TR-01",
        name: "Site sob medida para a sua operação",
        text: "Montado a partir do que a sua empresa vende e de como ela vende, não a partir de um tema pronto com o texto trocado.",
      },
      {
        code: "TR-02",
        name: "SEO local de verdade",
        text: "Páginas por serviço e por cidade, dados estruturados de negócio local, NAP consistente e ligação com o perfil da empresa no Google — o que decide se você aparece para quem busca aqui.",
      },
      {
        code: "TR-03",
        name: "Rápido no celular, no 4G da ponte",
        text: "Servido pronto, sem plugin pesado. A primeira tela aparece antes de a pessoa voltar para a busca.",
      },
      {
        code: "TR-04",
        name: "Telefone e WhatsApp em um toque",
        text: "Fixos na tela no celular e repetidos em cada seção. Nenhuma rolagem entre a visita e a conversa.",
      },
      {
        code: "TR-05",
        name: "Domínio, hospedagem e e-mail profissional",
        text: "Registro, DNS, HTTPS e o e-mail no seu domínio — resolvidos por nós, entregues no seu nome e na sua conta.",
      },
      {
        code: "TR-06",
        name: "Medição ligada desde o primeiro dia",
        text: "Analytics e Search Console configurados, para que a conversa de trinta dias depois seja sobre dados e não sobre impressão.",
      },
      {
        code: "TR-07",
        name: "Uma pessoa responsável pelo seu site",
        text: "Com telefone. Não é uma fila de chamados, e não é um formulário de suporte.",
      },
    ],
    stepsHeading: "Como funciona por aqui",
    steps: [
      {
        step: "01",
        name: "A ligação",
        text: "Quinze minutos por telefone ou, se preferir, um café na Grande Florianópolis. Você conta o que a empresa faz e o que hoje traz cliente.",
      },
      {
        step: "02",
        name: "O orçamento",
        text: "Escopo, prazo e preço por escrito, fechados antes de começar. Se o site não for o que vai resolver o seu problema, dizemos isso.",
      },
      {
        step: "03",
        name: "A construção",
        text: "Você acompanha num endereço de teste desde o início e faz uma rodada de ajustes antes da publicação.",
      },
      {
        step: "04",
        name: "No ar, medindo, com quem ligar",
        text: "Publicação, medição ligada e o telefone de quem construiu, que continua sendo o mesmo depois da entrega.",
      },
    ],
    faq: [
      {
        q: "Vocês atendem presencialmente em Florianópolis?",
        a: "Sim. Reuniões presenciais são possíveis em Florianópolis, São José, Palhoça, Biguaçu e região. A maior parte do trabalho acontece por telefone e videochamada porque é mais rápido, mas a escolha é sua.",
      },
      {
        q: "Quanto custa um site em Florianópolis?",
        a: "O preço depende do número de páginas, de haver integração com sistema e de quem escreve os textos. Fechamos na primeira ligação, por escrito, e o valor acordado é o valor final.",
      },
      {
        q: "Em quanto tempo fica pronto?",
        a: "Duas a quatro semanas para um site institucional ou uma página de captação, contadas de quando temos textos e imagens. O prazo entra no orçamento como compromisso.",
      },
      {
        q: "O site vai aparecer no Google para buscas da região?",
        a: "Entregamos toda a base que o SEO local exige: páginas por serviço e por cidade, dados estruturados de negócio local, endereço e telefone consistentes e ligação com o perfil da empresa no Google. Posição em buscas disputadas é trabalho contínuo, e Google Ads é o caminho para aparecer enquanto isso amadurece.",
      },
      {
        q: "Vocês registram o domínio no meu nome?",
        a: "Sempre. Domínio, hospedagem e contas de medição ficam em nome da sua empresa. Fornecedor que registra o domínio no próprio nome está segurando o seu negócio como garantia, e isso não se faz.",
      },
      {
        q: "Vocês fazem só site?",
        a: "Não. Construímos também sistemas sob medida, automação de WhatsApp e campanhas de Google Ads — e usamos todos internamente. Mas a conversa começa pelo site, porque é ele que sustenta o resto.",
      },
    ],
    closing: {
      heading: ["Ligue agora e fale com", "quem vai construir"],
      text: "Sem central de atendimento e sem proposta de trinta páginas. Quinze minutos no telefone e você sai sabendo escopo, prazo e preço.",
    },
    whatsappMessage:
      "Olá! Vim pela página de criação de sites em Florianópolis. Minha empresa é aqui na região e quero um orçamento — dá para conversar presencialmente?",
    serviceType: "Criação de sites em Florianópolis",
    investimento: null,
  },

  {
    slug: "sites-energia-solar",
    adGroup: "Sites — energia solar",
    code: "LP-03",
    metaTitle: "Site para empresa de energia solar",
    metaDescription:
      "Criação de site para empresa de energia solar: simulação de economia, provas de instalação e orçamento caindo no WhatsApp. Fale agora: (48) 98425-6517.",
    keywords: [
      "site para empresa de energia solar",
      "criação de site para energia solar",
      "site para integrador solar",
      "site para instalador de energia solar",
      "site para empresa de energia fotovoltaica",
      "landing page energia solar",
    ],
    h1: [
      "Site para empresa de energia solar",
      "que traz orçamento, não visita",
    ],
    deck: "Quem pesquisa energia solar já decidiu que quer economizar — falta escolher em quem confiar. O site decide isso em trinta segundos: quanto eu economizo, quem já instalou, e como falo com alguém agora.",
    assurances: [
      "Simulador de economia na primeira tela",
      "Provas de instalação e potência instalada, sem papo de catálogo",
      "O orçamento cai direto no seu WhatsApp",
    ],
    painsHeading: "Por que o site de integrador raramente converte",
    painsDeck:
      "A concorrência no setor é enorme e quase toda ela tem o mesmo site. Estes são os quatro pontos em que o seu pode deixar de ser mais um.",
    pains: [
      {
        title: "Fala de placa, e o cliente quer falar de conta de luz",
        text: "Ninguém compra módulo fotovoltaico. As pessoas compram uma conta de luz menor e a certeza de que aquilo se paga. O site precisa falar em reais e em anos, não em watt-pico.",
      },
      {
        title: "Não mostra nenhuma instalação sua",
        text: "É o setor onde a desconfiança é maior, porque todo mundo já ouviu a história do integrador que sumiu. Fotos das suas obras, com cidade e potência, valem mais que qualquer texto sobre qualidade.",
      },
      {
        title: "Pede dados demais antes de dar qualquer coisa",
        text: "Um formulário de dez campos antes de a pessoa saber se vale a pena é o ponto onde a maioria desiste. Primeiro entregue a estimativa, depois peça o contato.",
      },
      {
        title: "Some da busca local",
        text: "A instalação é física e a busca é local. Sem páginas por cidade de atuação e sem dados estruturados de negócio local, você compete em pé de igualdade com integrador de outro estado.",
      },
    ],
    deliverablesHeading: "O que entra no site do integrador",
    deliverablesDeck:
      "Construído em torno de uma pergunta só: quanto essa pessoa economiza, e como ela fala com você agora.",
    deliverables: [
      {
        code: "TR-01",
        name: "Simulador de economia",
        text: "A pessoa digita o valor da conta de luz e vê a economia estimada, o porte do sistema e o tempo de retorno. É a primeira tela, não uma página escondida no menu.",
      },
      {
        code: "TR-02",
        name: "Galeria de instalações com dados",
        text: "Cada obra com cidade, potência instalada e tipo de telhado. É a prova que o seu cliente procura e que o concorrente com site de template não tem.",
      },
      {
        code: "TR-03",
        name: "Páginas por cidade de atuação",
        text: "Uma página real para cada cidade que você atende, e não uma lista de nomes no rodapé — que o Google trata como o que é.",
      },
      {
        code: "TR-04",
        name: "Separação residencial, comercial e rural",
        text: "São três compradores diferentes, com três objeções diferentes. Um site que fala com os três ao mesmo tempo não fala com nenhum.",
      },
      {
        code: "TR-05",
        name: "Orçamento no WhatsApp, com os dados juntos",
        text: "O contato chega com o valor da conta, a cidade e o tipo de imóvel já preenchidos — o vendedor abre a conversa sabendo o que oferecer.",
      },
      {
        code: "TR-06",
        name: "Financiamento explicado antes da objeção",
        text: "A pergunta sobre parcela vem em toda conversa. Responder antes, no site, encurta o ciclo e afasta quem não tem orçamento.",
      },
      {
        code: "TR-07",
        name: "SEO técnico e medição ligada",
        text: "Títulos por página, dados estruturados, sitemap, Analytics e Search Console. Sem isso não há como saber qual cidade traz cliente.",
      },
    ],
    stepsHeading: "Do telefonema ao site no ar",
    steps: [
      {
        step: "01",
        name: "A ligação",
        text: "Quinze minutos. Que cidades você atende, qual o ticket médio, se vende residencial ou comercial, e de onde vêm os clientes hoje.",
      },
      {
        step: "02",
        name: "O orçamento",
        text: "Escopo, prazo e preço por escrito. O simulador e as páginas por cidade entram no escopo, não como adicional.",
      },
      {
        step: "03",
        name: "A construção",
        text: "Mandamos a lista do que precisamos de você — fotos de obras, potências, cidades — e você acompanha num endereço de teste.",
      },
      {
        step: "04",
        name: "No ar e medindo",
        text: "Publicação, medição ligada e uma conversa depois de trinta dias sobre quais cidades e quais anúncios trouxeram orçamento.",
      },
    ],
    faq: [
      {
        q: "O simulador de economia é confiável?",
        a: "Ele dá uma estimativa a partir do valor da conta, da tarifa da distribuidora da região e da irradiação local — o suficiente para a pessoa decidir se quer falar com você, e a página deixa claro que o dimensionamento final é seu. É uma ferramenta de captação, não um projeto.",
      },
      {
        q: "Vocês integram com o meu CRM ou com a planilha da equipe?",
        a: "Sim. O contato pode cair no WhatsApp, num e-mail, numa planilha ou direto num CRM — inclusive num CRM que a gente constrói. O que ele não pode é ficar parado num formulário que ninguém abre.",
      },
      {
        q: "Quanto custa o site de uma empresa de energia solar?",
        a: "Depende de quantas cidades e quantos segmentos você atende e de o simulador entrar ou não. Fechamos na primeira ligação, por escrito, antes de qualquer trabalho começar.",
      },
      {
        q: "Em quanto tempo fica pronto?",
        a: "Duas a quatro semanas a partir do momento em que temos as fotos das instalações e a lista de cidades. O prazo entra no orçamento como compromisso.",
      },
      {
        q: "Vocês também fazem os anúncios do Google?",
        a: "Fazemos, e é a combinação que costuma fazer sentido: o site converte melhor e o anúncio manda a busca certa para a página certa. Mas o site vem primeiro — pagar clique para uma página que não converte é a forma mais cara de descobrir isso.",
      },
      {
        q: "Atendem integrador de fora de Santa Catarina?",
        a: "Sim, atendemos no Brasil inteiro por telefone e videochamada. O que muda por região é a tarifa e a irradiação usadas no simulador, e isso é configuração.",
      },
    ],
    closing: {
      heading: ["Ligue agora e conte", "quantas cidades você atende"],
      text: "Em quinze minutos a gente mapeia como o seu site deveria estar organizado e você recebe escopo, prazo e preço.",
    },
    whatsappMessage:
      "Olá! Vim pela página de sites para energia solar. Sou integrador e quero um site com simulador de economia e página por cidade de atuação.",
    serviceType: "Criação de sites para empresas de energia solar",
    investimento: null,
  },

  {
    slug: "sites-oficina-mecanica",
    adGroup: "Sites — oficina mecânica",
    code: "LP-04",
    metaTitle: "Site para oficina mecânica",
    metaDescription:
      "Criação de site para oficina mecânica: aparecer no Google da sua cidade, agendamento e orçamento pelo WhatsApp. Fale agora: (48) 98425-6517.",
    keywords: [
      "site para oficina mecânica",
      "criação de site para oficina",
      "site para auto center",
      "site para funilaria e pintura",
      "site para centro automotivo",
      "criação de site oficina mecânica",
    ],
    h1: ["Site para oficina mecânica", "que enche a agenda da semana"],
    deck: "Quem está com o carro parado procura no celular, na hora, e liga para o primeiro que parecer sério e perto. O site da oficina existe para ganhar essa ligação — não para ter um portfólio.",
    assurances: [
      "Aparecer na busca da sua cidade e do seu bairro",
      "Botão de ligar e de WhatsApp fixos na tela",
      "Agendamento sem a pessoa precisar falar com alguém",
    ],
    painsHeading: "O que faz a oficina perder a ligação",
    painsDeck:
      "A concorrência da oficina é o mecânico a três quarteirões e o resultado de busca acima do seu. Estes são os quatro pontos onde a ligação costuma se perder.",
    pains: [
      {
        title: "Não aparece na busca de quem está perto",
        text: "'Oficina mecânica perto de mim' é a busca que decide o dia. Sem página com bairro, serviços e dados de negócio local, você não está na disputa — mesmo tendo a melhor oficina da rua.",
      },
      {
        title: "Não diz em que a oficina é especialista",
        text: "Câmbio automático, injeção eletrônica, diesel, funilaria, alinhamento, elétrica: são buscas diferentes, feitas por gente com problemas diferentes. Uma página só dizendo 'serviços automotivos' não ganha nenhuma delas.",
      },
      {
        title: "Só tem telefone fixo, e ninguém mais liga para fixo",
        text: "A pessoa está no acostamento com o carro apitando. Ela quer tocar no WhatsApp e mandar um áudio, e quer isso sem rolar a página.",
      },
      {
        title: "Nenhuma prova de que o serviço é honesto",
        text: "Todo mundo já foi enganado numa oficina. Fotos do serviço, tempo de casa, garantia por escrito e avaliações no Google fazem mais pela conversão do que qualquer adjetivo.",
      },
    ],
    deliverablesHeading: "O que entra no site da oficina",
    deliverablesDeck:
      "Feito para ser aberto no celular, com pressa, por alguém que está com um problema no carro agora.",
    deliverables: [
      {
        code: "TR-01",
        name: "Ligar e WhatsApp fixos na tela",
        text: "Barra fixa no rodapé do celular com os dois botões, visível em qualquer ponto da página. Um toque, sem rolagem.",
      },
      {
        code: "TR-02",
        name: "Uma página por especialidade",
        text: "Câmbio automático, injeção, diesel, freios, suspensão, elétrica, funilaria. Cada busca chega na página que responde exatamente ela.",
      },
      {
        code: "TR-03",
        name: "SEO local e perfil no Google",
        text: "Dados estruturados de negócio local, endereço e telefone consistentes, horário de funcionamento e ligação com o perfil da empresa no Google — o que decide o 'perto de mim'.",
      },
      {
        code: "TR-04",
        name: "Agendamento sem telefonema",
        text: "A pessoa escolhe serviço, dia e turno e você recebe o pedido pronto. Boa parte de quem não liga por vergonha de não saber o nome da peça agenda assim.",
      },
      {
        code: "TR-05",
        name: "Prova visível de serviço honesto",
        text: "Fotos dos serviços, garantia por escrito, formas de pagamento e as avaliações do Google na própria página.",
      },
      {
        code: "TR-06",
        name: "Mapa, horário e como chegar",
        text: "Com estacionamento, ponto de referência e o botão que abre a rota direto no aplicativo do celular.",
      },
      {
        code: "TR-07",
        name: "Rápido em 4G ruim",
        text: "A pessoa pode estar na rua, com sinal fraco e pressa. O site abre assim mesmo.",
      },
    ],
    stepsHeading: "Do telefonema ao site no ar",
    steps: [
      {
        step: "01",
        name: "A ligação",
        text: "Quinze minutos. Em que a oficina é especialista, que bairros atende, o que dá mais lucro e o que hoje traz carro para dentro.",
      },
      {
        step: "02",
        name: "O orçamento",
        text: "Escopo, prazo e preço por escrito, fechados antes de começar.",
      },
      {
        step: "03",
        name: "A construção",
        text: "A gente pede fotos da oficina e dos serviços, monta as páginas por especialidade e você revisa num endereço de teste.",
      },
      {
        step: "04",
        name: "No ar e medindo",
        text: "Publicação, perfil do Google ajustado, medição ligada e uma conversa depois de trinta dias sobre o que trouxe agendamento.",
      },
    ],
    faq: [
      {
        q: "Minha oficina é pequena, vale a pena ter site?",
        a: "Vale se você quer aparecer para quem busca no celular na sua região. Um perfil no Google ajuda, mas é o site que responde a busca por especialidade — 'câmbio automático' ou 'injeção eletrônica' — e é essa busca que traz o serviço de maior valor.",
      },
      {
        q: "O site substitui o perfil da empresa no Google?",
        a: "Não, os dois trabalham juntos e um reforça o outro. Ajustamos o perfil junto com a publicação do site: mesmo endereço, mesmo telefone, mesmo horário, e o site ligado a ele por dados estruturados.",
      },
      {
        q: "Eu consigo mexer no site sozinho?",
        a: "Sim, nas partes que mudam — serviços, preços de referência, fotos, horário. O resto fica travado de propósito: é o que normalmente quebra um site.",
      },
      {
        q: "Quanto custa e em quanto tempo fica pronto?",
        a: "O preço depende de quantas páginas de especialidade e de o agendamento entrar ou não; fechamos na primeira ligação, por escrito. O prazo costuma ser de duas a quatro semanas a partir do momento em que temos as fotos.",
      },
      {
        q: "Dá para receber o agendamento no WhatsApp da oficina?",
        a: "Dá, e é o mais comum. O pedido chega com serviço, dia, turno e telefone já preenchidos, no número que a sua equipe já usa.",
      },
      {
        q: "Vocês fazem anúncio no Google também?",
        a: "Fazemos. Para oficina costuma valer: a busca é local, imediata e com intenção de contratar. Mas o site vem primeiro — mandar clique pago para uma página que não converte é caro e ensina pouco.",
      },
    ],
    closing: {
      heading: ["Ligue agora e conte", "em que sua oficina é a melhor"],
      text: "Quinze minutos no telefone e você sai sabendo como o site deveria estar organizado, o prazo e o preço.",
    },
    whatsappMessage:
      "Olá! Vim pela página de sites para oficina mecânica. Quero aparecer no Google da minha região e receber agendamento sem depender do telefone.",
    serviceType: "Criação de sites para oficinas mecânicas",
    investimento: null,
  },

  {
    slug: "sites-ar-condicionado",
    adGroup: "Sites — ar condicionado e climatização",
    code: "LP-05",
    metaTitle: "Site para empresa de ar condicionado",
    metaDescription:
      "Criação de site para empresa de ar condicionado: instalação, manutenção e PMOC com orçamento chegando no WhatsApp. Fale agora: (48) 98425-6517.",
    keywords: [
      "site para empresa de ar condicionado",
      "site para instalador de ar condicionado",
      "criação de site climatização",
      "site para empresa de refrigeração",
      "site para manutenção de ar condicionado",
      "site para empresa de PMOC",
    ],
    h1: [
      "Site para empresa de ar condicionado",
      "que separa instalação de contrato",
    ],
    deck: "Instalação é uma venda; manutenção e PMOC são receita todo mês. O site precisa capturar as duas, e elas não falam com a mesma pessoa nem respondem à mesma busca.",
    assurances: [
      "Páginas separadas para residencial, comercial e PMOC",
      "Orçamento com BTUs e ambiente já preenchidos",
      "Contrato de manutenção pedido pelo próprio site",
    ],
    painsHeading: "Onde o site de climatização deixa dinheiro na mesa",
    painsDeck:
      "O setor tem duas receitas com ciclos completamente diferentes, e a maior parte dos sites trata as duas como uma coisa só.",
    pains: [
      {
        title: "Vende instalação e esquece o contrato",
        text: "A instalação é sazonal e disputada no preço. A manutenção preventiva e o PMOC são previsíveis e recorrentes — e quase nenhum site do setor pede esse contrato.",
      },
      {
        title: "Fala com o morador e com o síndico ao mesmo tempo",
        text: "Quem instala um split no quarto e quem contrata a climatização de um prédio comercial têm objeções opostas. Uma página só, para os dois, perde os dois.",
      },
      {
        title: "Não responde sobre PMOC, que é obrigação legal",
        text: "Quem busca PMOC está resolvendo uma exigência, não comparando preço. É o cliente mais qualificado do setor e ele precisa de uma página que fale a linguagem da norma.",
      },
      {
        title: "O orçamento chega sem nenhuma informação útil",
        text: "'Quero um orçamento' obriga três mensagens antes de qualquer número. Perguntar ambiente, tamanho e quantidade no próprio formulário economiza um dia de conversa.",
      },
    ],
    deliverablesHeading: "O que entra no site da empresa de climatização",
    deliverablesDeck:
      "Duas entradas, dois compradores, dois caminhos — e um número de telefone sempre visível.",
    deliverables: [
      {
        code: "TR-01",
        name: "Caminhos separados: residencial e comercial",
        text: "Duas primeiras telas, dois argumentos, dois formulários. Cada anúncio chega no lado certo.",
      },
      {
        code: "TR-02",
        name: "Página de PMOC e manutenção preventiva",
        text: "Escrita para síndico, administradora e responsável técnico, com o que a norma exige e o que o contrato cobre. É a página que traz a receita recorrente.",
      },
      {
        code: "TR-03",
        name: "Orçamento com os dados que você precisa",
        text: "Tipo de ambiente, metragem, quantidade de equipamentos e se é instalação, troca ou manutenção — tudo já preenchido quando a mensagem chega.",
      },
      {
        code: "TR-04",
        name: "Páginas por cidade e por serviço",
        text: "Instalação, higienização, carga de gás, troca de compressor, manutenção. Cada busca tem onde cair, com dados estruturados de negócio local.",
      },
      {
        code: "TR-05",
        name: "Prova técnica visível",
        text: "Fotos de obras, marcas com que você trabalha, certificações e garantia. Em climatização a desconfiança é sobre competência técnica, não sobre preço.",
      },
      {
        code: "TR-06",
        name: "Atendimento de urgência em destaque",
        text: "Quando o equipamento para num dia de calor, quem responde primeiro ganha. O botão de ligar é fixo e visível em qualquer ponto da página.",
      },
      {
        code: "TR-07",
        name: "SEO técnico e medição ligada",
        text: "Títulos por página, dados estruturados, sitemap, Analytics e Search Console — para saber se o dinheiro veio da instalação ou do contrato.",
      },
    ],
    stepsHeading: "Do telefonema ao site no ar",
    steps: [
      {
        step: "01",
        name: "A ligação",
        text: "Quinze minutos. Quanto do faturamento é instalação e quanto é contrato, que cidades você atende e onde está a margem.",
      },
      {
        step: "02",
        name: "O orçamento",
        text: "Escopo, prazo e preço por escrito. A página de PMOC entra no escopo, não como adicional.",
      },
      {
        step: "03",
        name: "A construção",
        text: "Pedimos fotos de obra, marcas atendidas e o que o seu contrato de manutenção cobre; você revisa num endereço de teste.",
      },
      {
        step: "04",
        name: "No ar e medindo",
        text: "Publicação, medição ligada e uma conversa depois de trinta dias sobre qual dos dois caminhos trouxe mais dinheiro.",
      },
    ],
    faq: [
      {
        q: "Vale a pena ter uma página só de PMOC?",
        a: "Vale, e costuma ser a página mais rentável do site. Quem busca PMOC está cumprindo uma exigência legal, tem prazo e compara menos no preço — é o oposto da busca por instalação de split, que é disputada no centavo.",
      },
      {
        q: "O site ajuda a vender contrato de manutenção?",
        a: "Ajuda se pedir o contrato explicitamente, com o que ele cobre, a periodicidade e a forma de contratação — e não como uma linha na lista de serviços. É exatamente essa a página que a maior parte dos concorrentes não tem.",
      },
      {
        q: "Quanto custa e em quanto tempo fica pronto?",
        a: "O preço depende de quantos segmentos e cidades o site cobre; fechamos na primeira ligação, por escrito. O prazo costuma ser de duas a quatro semanas a partir de termos fotos e conteúdo técnico.",
      },
      {
        q: "Dá para o orçamento chegar direto no WhatsApp da equipe?",
        a: "Dá, com ambiente, metragem e quantidade já preenchidos. Também pode cair num e-mail, numa planilha ou num CRM.",
      },
      {
        q: "Atendem empresas fora da Grande Florianópolis?",
        a: "Sim, atendemos no Brasil inteiro por telefone e videochamada. Estamos em Florianópolis, o que só muda a possibilidade de reunião presencial.",
      },
      {
        q: "Vocês fazem anúncio no Google para climatização?",
        a: "Fazemos, e é um setor em que a separação por campanha importa muito: instalação residencial, manutenção e PMOC têm custos por clique e valores de cliente bem diferentes e não deveriam dividir o mesmo orçamento.",
      },
    ],
    closing: {
      heading: ["Ligue agora e conte", "onde está a sua margem"],
      text: "Quinze minutos no telefone e a gente mapeia as duas entradas do seu site. Você sai com escopo, prazo e preço.",
    },
    whatsappMessage:
      "Olá! Vim pela página de sites para ar condicionado. Quero separar instalação de contrato de manutenção e ter uma página de PMOC.",
    serviceType:
      "Criação de sites para empresas de ar condicionado e climatização",
    investimento: null,
  },

  {
    slug: "automacao-whatsapp",
    adGroup: "Automação — atendimento no WhatsApp",
    code: "LP-06",
    metaTitle: "Automação de atendimento no WhatsApp para empresas",
    metaDescription:
      "Automação de WhatsApp com IA: responde na hora, qualifica, agenda e recupera quem sumiu. Rodando na nossa própria operação. Fale agora: (48) 98425-6517.",
    keywords: [
      // The first entry is the anchor: it is the phrase the H1 has to repeat
      // back, which is what `ads.test.ts` checks and what the quality score
      // rewards. "automação de WhatsApp para empresas" sits second because the
      // headline answers "atendimento", not "para empresas".
      "automação de atendimento WhatsApp",
      "automação de WhatsApp para empresas",
      "chatbot WhatsApp para empresas",
      "IA para atendimento WhatsApp",
      "automação de leads WhatsApp",
      "automatizar atendimento ao cliente",
      "recuperação de leads WhatsApp",
    ],
    h1: ["Automação de atendimento no WhatsApp", "que não parece um robô"],
    deck: "Responder em cinco minutos ou em cinco horas é a diferença entre um cliente e um orçamento perdido. A automação responde na hora, entende o que a pessoa quer, agenda, e chama um humano no momento certo.",
    assurances: [
      "Responde em segundos, inclusive de madrugada e no domingo",
      "Passa para uma pessoa quando a conversa exige — e avisa quem",
      "Roda na nossa própria operação antes de rodar na sua",
    ],
    painsHeading: "O que a automação resolve na prática",
    painsDeck:
      "Nada aqui é sobre 'inovação'. São quatro perdas de dinheiro que acontecem no WhatsApp de quase toda empresa que vende por ele.",
    pains: [
      {
        title: "A primeira resposta demora e o cliente já falou com outro",
        text: "Quem pede orçamento manda para três empresas. Quem responde primeiro costuma fechar, e a hora em que essa mensagem chega raramente é a hora em que sua equipe está livre.",
      },
      {
        title: "Metade das mensagens é a mesma pergunta",
        text: "Preço, prazo, endereço, horário, formas de pagamento, se atende tal bairro. É trabalho repetido que ocupa a pessoa que deveria estar fechando venda.",
      },
      {
        title: "Ninguém faz o segundo contato",
        text: "A conversa morre no 'vou ver e te falo' e nunca mais alguém volta. Um retorno no dia seguinte e outro na semana seguinte recuperam uma parte do que já estava pago e perdido.",
      },
      {
        title: "Não existe registro de nada",
        text: "A conversa está no celular de alguém. Se essa pessoa sai, sai com o histórico, com o combinado e com o cliente.",
      },
    ],
    deliverablesHeading: "O que entra na automação",
    deliverablesDeck:
      "Construída sobre o WhatsApp que a sua empresa já usa, com o mesmo número — e com uma pessoa podendo assumir a conversa a qualquer momento.",
    deliverables: [
      {
        code: "TR-01",
        name: "Resposta imediata, dia e noite",
        text: "Toda mensagem é respondida em segundos, com o contexto do que a pessoa perguntou. Fora do horário comercial isso costuma ser metade do volume.",
      },
      {
        code: "TR-02",
        name: "Qualificação antes de ocupar um vendedor",
        text: "A automação descobre o que a pessoa quer, onde ela está e qual o porte do serviço, e entrega isso pronto para quem vai vender.",
      },
      {
        code: "TR-03",
        name: "Passagem para humano, no momento certo",
        text: "Quando a conversa sai do que a automação deve responder — negociação, reclamação, um caso fora do padrão — ela entrega para uma pessoa e avisa quem. Nenhum cliente fica preso num menu.",
      },
      {
        code: "TR-04",
        name: "Agendamento direto na conversa",
        text: "A pessoa escolhe dia e horário sem sair do WhatsApp, e o compromisso aparece na agenda da equipe.",
      },
      {
        code: "TR-05",
        name: "Recuperação de quem sumiu",
        text: "Retomada automática das conversas que pararam, com intervalo e texto que você aprova. É a parte que costuma se pagar sozinha.",
      },
      {
        code: "TR-06",
        name: "Tudo registrado, fora do celular de alguém",
        text: "Histórico, etapa do funil e combinados ficam num painel da empresa. Quem sai não leva o cliente junto.",
      },
      {
        code: "TR-07",
        name: "Regras suas, texto seu",
        text: "O que a automação pode e não pode dizer é definido por você, por escrito. Preço, prazo e promessa não são improvisados por um modelo de linguagem.",
      },
    ],
    stepsHeading: "Do telefonema ao atendimento rodando",
    steps: [
      {
        step: "01",
        name: "A ligação",
        text: "Quinze minutos. Quantas mensagens por dia, quem responde hoje, o que mais perguntam e o que nunca pode ser dito automaticamente.",
      },
      {
        step: "02",
        name: "O desenho da conversa",
        text: "Escrevemos o que a automação responde, o que ela pergunta e onde ela entrega para uma pessoa. Você aprova antes de ela falar com qualquer cliente.",
      },
      {
        step: "03",
        name: "Ligação no seu número",
        text: "Conectamos ao WhatsApp que a empresa já usa, com a equipe podendo assumir qualquer conversa a qualquer momento.",
      },
      {
        step: "04",
        name: "Uma semana observando",
        text: "A primeira semana é acompanhada conversa a conversa, e o texto é ajustado com base no que as pessoas realmente perguntaram.",
      },
    ],
    faq: [
      {
        q: "O cliente vai perceber que está falando com um robô?",
        a: "Ele vai perceber que foi respondido na hora, com informação correta e sem menu numerado. A automação não finge ser humana quando perguntada, e passa para uma pessoa assim que a conversa exige — que é o oposto do chatbot que prende o cliente num labirinto.",
      },
      {
        q: "Funciona no número de WhatsApp que a empresa já usa?",
        a: "Sim, e é o recomendado: o número que os clientes já têm salvo. A equipe continua enxergando e podendo assumir qualquer conversa.",
      },
      {
        q: "A IA pode inventar um preço ou prometer um prazo?",
        a: "Não, porque o que ela pode afirmar é definido por escrito por você. Preço, prazo e condições ou vêm de uma regra que você escreveu ou a conversa vai para uma pessoa. Essa é a parte que mais cuidamos.",
      },
      {
        q: "Quanto custa uma automação de WhatsApp?",
        a: "Há um valor de construção e um valor mensal de operação, e os dois dependem do volume de mensagens e de quantos caminhos a conversa tem. Fechamos na primeira ligação, por escrito, e dizemos se o seu volume ainda não justifica o investimento.",
      },
      {
        q: "Em quanto tempo entra no ar?",
        a: "O desenho da conversa costuma levar alguns dias e depende da sua aprovação; a ligação técnica é rápida. A maior parte dos casos está atendendo em duas a três semanas, com a primeira semana acompanhada de perto.",
      },
      {
        q: "Vocês usam isso de verdade ou é só o que vocês vendem?",
        a: "Usamos. O agente de WhatsApp, o CRM que guarda as conversas, a ferramenta de prospecção e o portal do cliente foram construídos por nós e rodam na nossa operação todo dia. É a única prova que oferecemos, e é uma que dá para mostrar numa chamada de tela.",
      },
    ],
    closing: {
      heading: ["Ligue agora e conte", "quantas mensagens chegam por dia"],
      text: "Com esse número já dá para dizer se a automação se paga. Quinze minutos no telefone, e você sai com escopo, prazo e preço.",
    },
    whatsappMessage:
      "Olá! Vim pela página de automação de atendimento no WhatsApp. Quero que as mensagens sejam respondidas na hora e saber se o meu volume justifica.",
    serviceType:
      "Automação de atendimento no WhatsApp com Inteligência Artificial",
    investimento: null,
  },

  {
    slug: "sites-clinica-odontologica",
    adGroup: "Sites — odontologia",
    code: "LP-07",
    metaTitle: "Site para clínica odontológica",
    metaDescription:
      "Criação de site para clínica odontológica: agendamento online, tratamentos separados por página e contato em um toque. Fale agora: (48) 98425-6517.",
    keywords: [
      "site para clínica odontológica",
      "criação de site para dentista",
      "site para consultório odontológico",
      "site para clínica de implantes",
      "agendamento online odontologia",
      "marketing odontológico site",
    ],
    h1: ["Site para clínica odontológica", "que enche a agenda sem desconto"],
    deck: "Quem procura dentista no Google já sente dor, já quebrou algo, ou já decidiu tratar. O site decide em trinta segundos se você é a clínica em que essa pessoa confia — e se ela consegue marcar sem falar com ninguém.",
    assurances: [
      "Agendamento online, sem a paciente precisar ligar",
      "Uma página por tratamento, para cada busca cair no lugar certo",
      "Dentro do que o CFO permite anunciar",
    ],
    painsHeading: "Onde a clínica perde a paciente antes da primeira consulta",
    painsDeck:
      "Odontologia é a busca local mais disputada que existe depois de advogado. Estes quatro pontos decidem quem fica com a ligação.",
    pains: [
      {
        title: "Uma página só, para vinte tratamentos",
        text: "Implante, ortodontia, lente de contato dental, clareamento, urgência e harmonização são buscas diferentes, feitas por pessoas em momentos diferentes. Uma página que lista tudo não ganha nenhuma delas.",
      },
      {
        title: "Não dá para marcar sem ligar",
        text: "Boa parte de quem procura dentista tem vergonha de perguntar preço por telefone. Se o único caminho é o telefonema, essa pessoa marca na clínica ao lado que tem um botão.",
      },
      {
        title: "Nada diz quem atende",
        text: "Odontologia se compra na confiança no profissional. Nome, CRO, formação e foto da equipe convertem mais que qualquer texto sobre tecnologia de ponta.",
      },
      {
        title: "Some da busca de quem está perto",
        text: "Sem dados estruturados de negócio local, horário, endereço e ligação com o perfil da empresa no Google, a clínica não entra na disputa por 'dentista perto de mim'.",
      },
    ],
    deliverablesHeading: "O que entra no site da clínica",
    deliverablesDeck:
      "Feito para ser aberto no celular por alguém decidindo em quem confiar, hoje.",
    deliverables: [
      {
        code: "TR-01",
        name: "Agendamento online de verdade",
        text: "A paciente escolhe tratamento, dia e turno, e o pedido chega no WhatsApp ou no sistema da recepção já preenchido.",
      },
      {
        code: "TR-02",
        name: "Uma página por especialidade",
        text: "Implante, ortodontia, estética, endodontia, urgência. Cada anúncio e cada busca orgânica cai na página que responde exatamente aquela pergunta.",
      },
      {
        code: "TR-03",
        name: "A equipe com nome e CRO",
        text: "Quem atende, onde se formou e há quanto tempo. É o que faz uma clínica parecer uma clínica e não uma franquia.",
      },
      {
        code: "TR-04",
        name: "Conteúdo dentro do que o CFO permite",
        text: "Sem promessa de resultado, sem antes e depois usado como propaganda e sem preço de procedimento em destaque. Escrevemos dentro do código de ética — e a página fica melhor por isso, não pior.",
      },
      {
        code: "TR-05",
        name: "SEO local e perfil no Google",
        text: "Dados estruturados de clínica, endereço, horário e convênios atendidos, ligados ao perfil da empresa no Google.",
      },
      {
        code: "TR-06",
        name: "Urgência em destaque",
        text: "Quem está com dor não lê a página institucional. O caminho para o telefone é imediato e visível em qualquer ponto.",
      },
    ],
    stepsHeading: "Do telefonema ao site no ar",
    steps: [
      {
        step: "01",
        name: "A ligação",
        text: "Quinze minutos. Quais tratamentos dão margem, quais convênios você atende, quem atende e o que hoje enche a agenda.",
      },
      {
        step: "02",
        name: "O orçamento",
        text: "Escopo, prazo e preço por escrito, fechados antes de começar.",
      },
      {
        step: "03",
        name: "A construção",
        text: "Pedimos fotos da clínica e da equipe, montamos as páginas por tratamento e você revisa num endereço de teste.",
      },
      {
        step: "04",
        name: "No ar e medindo",
        text: "Publicação, perfil do Google ajustado e uma conversa depois de trinta dias sobre quais tratamentos trouxeram consulta.",
      },
    ],
    faq: [
      {
        q: "O que eu posso e não posso colocar no site, segundo o CFO?",
        a: "O Código de Ética Odontológica veda promessa de resultado, uso de antes e depois como propaganda, preço de procedimento como chamariz e concorrência desleal. Escrevemos dentro disso desde o rascunho — e deixamos claro que não somos a sua assessoria jurídica: o conteúdo final é revisado por você antes de ir ao ar.",
      },
      {
        q: "Dá para integrar o agendamento com o sistema que já usamos?",
        a: "Na maioria dos casos sim, se o sistema tiver integração. Quando não tem, o pedido chega estruturado no WhatsApp da recepção com tratamento, dia e turno preenchidos — que já resolve a maior parte do atrito.",
      },
      {
        q: "Quanto custa e em quanto tempo fica pronto?",
        a: "Depende de quantas páginas de tratamento e de o agendamento entrar ou não. Fechamos na primeira ligação, por escrito. O prazo costuma ser de duas a quatro semanas depois de termos fotos e conteúdo.",
      },
      {
        q: "Vale mais investir em site ou em Instagram?",
        a: "São coisas diferentes: o Instagram mantém quem já conhece, o site captura quem está procurando agora. Para agenda cheia no mês que vem, a busca converte muito melhor — mas a resposta honesta depende de onde vêm os seus pacientes hoje, e isso a gente pergunta na ligação.",
      },
      {
        q: "Vocês também fazem os anúncios?",
        a: "Fazemos. Odontologia é um dos leilões mais caros da busca local, então a separação por tratamento não é refinamento: é o que impede que a campanha de implante gaste o orçamento em cliques de clareamento.",
      },
    ],
    closing: {
      heading: ["Ligue agora e conte", "qual cadeira está vazia"],
      text: "Quinze minutos no telefone e a gente mapeia como o site deveria estar organizado. Você sai com escopo, prazo e preço.",
    },
    whatsappMessage:
      "Olá! Vim pela página de sites para clínica odontológica. Quero agendamento online e uma página por tratamento, dentro do que o CFO permite.",
    serviceType: "Criação de sites para clínicas odontológicas",
    investimento: null,
  },

  {
    slug: "sites-clinica-medica",
    adGroup: "Sites — clínicas médicas",
    code: "LP-08",
    metaTitle: "Site para clínica médica e consultório",
    metaDescription:
      "Criação de site para clínica médica: especialidades separadas, convênios, agendamento e contato em um toque. Fale agora: (48) 98425-6517.",
    keywords: [
      "site para clínica médica",
      "criação de site para médico",
      "site para consultório médico",
      "agendamento online clínica",
      "site para clínica de especialidades",
      "marketing médico site",
    ],
    h1: [
      "Site para clínica médica",
      "que respeita o CFM e ainda traz paciente",
    ],
    deck: "A publicidade médica tem regras estreitas, e é justamente por isso que a maior parte dos sites do setor é um folheto sem função. Dá para ser correto e ser encontrado — o que muda é onde o esforço vai.",
    assurances: [
      "Escrito dentro do que a Resolução CFM 1.974/2011 permite",
      "Uma página por especialidade e por convênio",
      "Agendamento sem a pessoa precisar ligar",
    ],
    painsHeading: "Por que o site da clínica não traz consulta",
    painsDeck:
      "Não é falta de investimento. É que quase todo site do setor foi feito com medo das regras e acabou não dizendo nada.",
    pains: [
      {
        title: "Não diz quais convênios atende",
        text: "É a primeira pergunta de quem procura clínica, e a informação que mais falta. Uma página com a lista atualizada responde metade das ligações da recepção.",
      },
      {
        title: "Lista especialidades sem uma página para cada uma",
        text: "Quem busca 'endocrinologista' e quem busca 'ortopedista' são duas pessoas. Uma lista no menu não compete com quem tem uma página real por especialidade.",
      },
      {
        title: "Nenhum caminho para marcar",
        text: "Se marcar exige telefonar no horário comercial, você está perdendo todo mundo que decidiu procurar às onze da noite — que é quando as pessoas procuram.",
      },
      {
        title: "Ou ignora as regras do CFM, o que é pior",
        text: "Promessa de resultado, antes e depois, preço como chamariz e autopromoção sensacionalista expõem o corpo clínico a processo ético. Um site que gera consulta e um problema no CRM não foi um bom negócio.",
      },
    ],
    deliverablesHeading: "O que entra no site da clínica",
    deliverablesDeck:
      "Informação clara, caminho curto para a recepção, e nada que o corpo clínico não possa assinar.",
    deliverables: [
      {
        code: "TR-01",
        name: "Página por especialidade",
        text: "Cada especialidade com o que ela trata, quem atende e como marcar. É o que faz a clínica aparecer para a busca que importa.",
      },
      {
        code: "TR-02",
        name: "Convênios, sempre atualizados",
        text: "Numa página que você mesma edita, porque essa lista muda — e uma lista desatualizada gera mais irritação do que a ausência dela.",
      },
      {
        code: "TR-03",
        name: "Corpo clínico com CRM e RQE",
        text: "Nome, especialidade, registro e formação de cada profissional, como o CFM exige que a identificação apareça.",
      },
      {
        code: "TR-04",
        name: "Agendamento ou pedido de contato",
        text: "A pessoa escolhe especialidade, convênio e turno; a recepção recebe pronto, no WhatsApp ou no sistema.",
      },
      {
        code: "TR-05",
        name: "Conteúdo dentro da Resolução CFM 1.974/2011",
        text: "Sem promessa de cura, sem antes e depois, sem preço como chamariz e sem autopromoção. Informação em saúde é permitida e é exatamente o que faz a clínica ser encontrada.",
      },
      {
        code: "TR-06",
        name: "SEO local, LGPD e medição",
        text: "Dados estruturados de clínica, aviso de privacidade compatível com dado sensível de saúde, e Analytics e Search Console ligados.",
      },
    ],
    stepsHeading: "Do telefonema ao site no ar",
    steps: [
      {
        step: "01",
        name: "A ligação",
        text: "Quinze minutos. Quais especialidades, quais convênios, quem atende e onde a recepção está gastando tempo hoje.",
      },
      {
        step: "02",
        name: "O orçamento",
        text: "Escopo, prazo e preço por escrito, fechados antes de começar.",
      },
      {
        step: "03",
        name: "A construção",
        text: "Montamos as páginas por especialidade e o texto passa pela revisão do responsável técnico antes de qualquer publicação.",
      },
      {
        step: "04",
        name: "No ar e medindo",
        text: "Publicação, perfil do Google ajustado, medição ligada e uma conversa depois de trinta dias.",
      },
    ],
    faq: [
      {
        q: "O que a Resolução CFM 1.974/2011 proíbe num site?",
        a: "Em resumo: promessa de resultado, garantia de cura, imagens de antes e depois, preço como chamariz, autopromoção e sensacionalismo. O que ela permite — e incentiva — é informação em saúde com identificação clara do profissional. Escrevemos dentro disso, e o responsável técnico revisa antes de publicar. Não somos assessoria jurídica e não substituímos a leitura do seu conselho.",
      },
      {
        q: "Podemos divulgar preços de consulta?",
        a: "Preço como chamariz publicitário é vedado. Informar valor quando a paciente pergunta é outra coisa. Na prática, tratamos isso como informação de atendimento e não como argumento de venda — e a ligação é onde definimos o limite junto com você.",
      },
      {
        q: "Dá para integrar com o sistema de agendamento da clínica?",
        a: "Se o sistema tiver integração, sim. Quando não tem, o pedido chega estruturado para a recepção com especialidade, convênio e turno preenchidos.",
      },
      {
        q: "E a LGPD, já que lidamos com dado de saúde?",
        a: "O site não deve coletar dado de saúde em formulário — e o nosso não coleta. Ele coleta contato e intenção de agendamento, com aviso de privacidade próprio. Qualquer coisa além disso pertence ao prontuário, que é um sistema com outro nível de exigência.",
      },
      {
        q: "Quanto custa e em quanto tempo fica pronto?",
        a: "Depende do número de especialidades e de o agendamento entrar ou não. Fechamos na primeira ligação, por escrito; o prazo costuma ser de três a cinco semanas, porque a revisão do responsável técnico entra no meio.",
      },
    ],
    closing: {
      heading: ["Ligue agora e conte", "quantas especialidades atendem"],
      text: "Em quinze minutos a gente mapeia a estrutura do site e você recebe escopo, prazo e preço.",
    },
    whatsappMessage:
      "Olá! Vim pela página de sites para clínica médica. Quero página por especialidade e lista de convênios, dentro das regras do CFM.",
    serviceType: "Criação de sites para clínicas médicas",
    investimento: null,
  },

  {
    slug: "sites-advocacia",
    adGroup: "Sites — advocacia",
    code: "LP-09",
    metaTitle: "Site para escritório de advocacia",
    metaDescription:
      "Criação de site para escritório de advocacia dentro do Provimento 205/2021 da OAB: informativo, sóbrio e encontrável. Fale agora: (48) 98425-6517.",
    keywords: [
      "site para escritório de advocacia",
      "criação de site para advogado",
      "site jurídico institucional",
      "marketing jurídico OAB",
      "site para advogado trabalhista",
      "site para banca de advocacia",
    ],
    h1: ["Site para escritório de advocacia", "dentro do que a OAB permite"],
    deck: "A publicidade da advocacia é informativa, nunca de captação — e é por isso que a maior parte dos sites do setor ou é tímida demais para ser encontrada, ou arrisca o que não devia. Existe um caminho no meio, e ele é técnico.",
    assurances: [
      "Escrito dentro do Provimento 205/2021 e do Código de Ética",
      "Sóbrio por regra, encontrável por construção",
      "Áreas de atuação como páginas, não como lista",
    ],
    painsHeading: "O dilema que todo escritório conhece",
    painsDeck:
      "Não se pode fazer captação, não se pode mercantilizar, não se pode prometer resultado. E ainda assim o cliente procura no Google. Estes são os quatro pontos onde isso se resolve.",
    pains: [
      {
        title: "O site é tímido demais para existir na busca",
        text: "Uma página com o nome da banca e um telefone respeita todas as regras e não é encontrada por ninguém. Conteúdo informativo sobre as áreas de atuação é permitido e é exatamente o que faz o escritório aparecer.",
      },
      {
        title: "Ou arrisca o que não deveria",
        text: "Promessa de êxito, valores de honorários como chamariz, depoimento de cliente e linguagem de venda são vedados. Um site que traz cliente e um processo ético junto não compensou.",
      },
      {
        title: "Não diz em que o escritório é bom",
        text: "Trabalhista, previdenciário, tributário, família, empresarial: são clientes diferentes com problemas diferentes. Uma lista no menu não substitui uma página que explica a matéria.",
      },
      {
        title: "Nada acontece depois que a pessoa lê",
        text: "Quem chega num site jurídico está com um problema e precisa de um próximo passo claro e discreto. Um telefone no rodapé não é isso.",
      },
    ],
    deliverablesHeading: "O que entra no site do escritório",
    deliverablesDeck:
      "Sóbrio, informativo e tecnicamente bem construído — que é como se ganha busca sem sair das regras.",
    deliverables: [
      {
        code: "TR-01",
        name: "Uma página por área de atuação",
        text: "Explicando a matéria em linguagem que o cliente entende, sem prometer resultado. É conteúdo informativo, que o Provimento 205 permite — e é o que o Google usa para mostrar o escritório.",
      },
      {
        code: "TR-02",
        name: "Equipe com OAB e formação",
        text: "Identificação completa de cada advogado, como a publicidade da advocacia exige.",
      },
      {
        code: "TR-03",
        name: "Conteúdo revisado contra o Provimento 205/2021",
        text: "Sem captação, sem mercantilização, sem promessa de êxito, sem honorário como chamariz e sem depoimento de cliente. O texto final é aprovado por você — e um escritório é, convenientemente, o cliente que pode conferir.",
      },
      {
        code: "TR-04",
        name: "Contato discreto e direto",
        text: "Telefone e WhatsApp acessíveis em qualquer ponto, com a sobriedade que o setor exige. Discreto não significa escondido.",
      },
      {
        code: "TR-05",
        name: "Espaço para artigos",
        text: "Publicação de conteúdo jurídico informativo é o caminho permitido para ganhar autoridade na busca — e é o único que se acumula ao longo dos anos.",
      },
      {
        code: "TR-06",
        name: "SEO técnico e LGPD",
        text: "Estrutura, velocidade, dados estruturados e aviso de privacidade — com atenção ao sigilo, porque um formulário jurídico não deve pedir detalhes do caso.",
      },
    ],
    stepsHeading: "Do telefonema ao site no ar",
    steps: [
      {
        step: "01",
        name: "A ligação",
        text: "Quinze minutos. Quais áreas, que tipo de cliente, e como o escritório recebe consulta hoje.",
      },
      {
        step: "02",
        name: "O orçamento",
        text: "Escopo, prazo e preço por escrito, fechados antes de começar.",
      },
      {
        step: "03",
        name: "A construção e a revisão",
        text: "Montamos as páginas por área e o texto vai para a sua revisão — esta etapa é obrigatória aqui, não opcional.",
      },
      {
        step: "04",
        name: "No ar e medindo",
        text: "Publicação, medição ligada e uma conversa depois de trinta dias sobre quais áreas trouxeram consulta.",
      },
    ],
    faq: [
      {
        q: "Um escritório pode ter site e anunciar no Google?",
        a: "Pode ter site, e o Provimento 205/2021 admite publicidade informativa, inclusive em meios digitais, desde que sem captação de clientela, sem mercantilização e sem promessa de resultado. O impulsionamento pago é o ponto mais sensível e mais discutido — nós construímos a página informativa, e a decisão de anunciar é do escritório, idealmente depois de uma consulta à sua seccional. Nada aqui é orientação jurídica.",
      },
      {
        q: "O que definitivamente não pode entrar?",
        a: "Promessa ou garantia de êxito, valores de honorários como chamariz, depoimento de cliente, comparação com outros escritórios, linguagem de venda e qualquer coisa que configure captação. Escrevemos partindo dessa lista, e você revisa antes de publicar.",
      },
      {
        q: "Então como o site traz cliente sem fazer captação?",
        a: "Sendo encontrado por quem já está procurando e explicando bem a matéria. A pessoa com um problema trabalhista busca a solução, encontra um texto sério que a ajuda a entender, e liga. Isso é publicidade informativa, não captação.",
      },
      {
        q: "Vocês também constroem sistemas para o escritório?",
        a: "Sim — atendimento no WhatsApp com respostas aprovadas por um advogado, portal para o cliente acompanhar o andamento, painéis. Temos um documento de projeto inteiro sobre a vertical. Mas a conversa começa pelo site.",
      },
      {
        q: "Quanto custa e em quanto tempo fica pronto?",
        a: "Depende do número de áreas de atuação e do tamanho da equipe. Fechamos na primeira ligação, por escrito. O prazo costuma ser de três a cinco semanas porque a revisão do escritório entra no meio — e ela não é etapa que se pule.",
      },
    ],
    closing: {
      heading: ["Ligue agora e conte", "em que áreas vocês atuam"],
      text: "Quinze minutos no telefone, e você sai com a estrutura do site, o prazo e o preço. A revisão do conteúdo é sua, sempre.",
    },
    whatsappMessage:
      "Olá! Vim pela página de sites para escritório de advocacia. Quero um site informativo dentro do Provimento 205/2021 da OAB.",
    serviceType: "Criação de sites para escritórios de advocacia",
    investimento: null,
  },

  {
    slug: "sites-contabilidade",
    adGroup: "Sites — contabilidade",
    code: "LP-10",
    metaTitle: "Site para escritório de contabilidade",
    metaDescription:
      "Criação de site para escritório de contabilidade: abertura de empresa, troca de contador e orçamento chegando no WhatsApp. Fale agora: (48) 98425-6517.",
    keywords: [
      "site para escritório de contabilidade",
      "criação de site para contador",
      "site para contabilidade online",
      "site para abertura de empresa",
      "marketing contábil site",
      "site para assessoria contábil",
    ],
    h1: ["Site para escritório de contabilidade", "que vende o serviço certo"],
    deck: "Abrir empresa, trocar de contador e regularizar pendência são três clientes diferentes com três urgências diferentes. Um site que trata os três como 'serviços contábeis' perde os três para quem separou.",
    assurances: [
      "Caminhos separados: abrir, trocar e regularizar",
      "Honorário estimado antes da primeira conversa, se você quiser",
      "Contato chegando já com regime tributário e porte",
    ],
    painsHeading: "Onde o escritório perde o cliente que estava pronto",
    painsDeck:
      "Contabilidade é um serviço que a pessoa contrata uma vez e mantém por anos. O custo de perder um contato é o de perder uma mensalidade recorrente.",
    pains: [
      {
        title: "Não separa quem vai abrir de quem vai trocar",
        text: "Quem abre empresa quer velocidade e não sabe o que é um CNAE. Quem troca de contador está irritado e quer garantia de que a transição não vai doer. São dois textos completamente diferentes.",
      },
      {
        title: "Não fala de honorário nem por aproximação",
        text: "É a primeira pergunta e o maior filtro. Uma faixa por porte e regime economiza um dia de conversa e afasta quem nunca ia fechar.",
      },
      {
        title: "Não diz em que nicho o escritório é bom",
        text: "Médico, construtora, e-commerce, prestador de serviço, importador — cada um tem uma dor tributária própria, e um escritório que fala a língua de um deles ganha dele.",
      },
      {
        title: "O contato chega vazio",
        text: "'Quero um orçamento' obriga três mensagens antes de qualquer número. Porte, regime e número de funcionários no próprio formulário resolvem isso.",
      },
    ],
    deliverablesHeading: "O que entra no site do escritório",
    deliverablesDeck:
      "Três portas de entrada, um caminho curto para o telefone e um contato que já chega qualificado.",
    deliverables: [
      {
        code: "TR-01",
        name: "Página de abertura de empresa",
        text: "Com o passo a passo, o prazo real e o que o cliente precisa ter em mãos. É a busca de maior volume do setor.",
      },
      {
        code: "TR-02",
        name: "Página de troca de contador",
        text: "Escrita para quem está insatisfeito: como é a transição, quem fala com o contador antigo, o que pode dar errado e o que você garante.",
      },
      {
        code: "TR-03",
        name: "Páginas por nicho atendido",
        text: "O que o escritório entende melhor do que a média — e é onde a margem está.",
      },
      {
        code: "TR-04",
        name: "Orçamento com porte e regime",
        text: "O contato chega com faturamento aproximado, regime, número de funcionários e o serviço desejado já preenchidos.",
      },
      {
        code: "TR-05",
        name: "Faixa de honorário, se você quiser",
        text: "Publicar uma faixa reduz o volume e sobe muito a qualidade. É decisão sua, e a página funciona dos dois jeitos.",
      },
      {
        code: "TR-06",
        name: "SEO local e medição",
        text: "Dados estruturados, páginas por cidade e Analytics e Search Console ligados desde o primeiro dia.",
      },
    ],
    stepsHeading: "Do telefonema ao site no ar",
    steps: [
      {
        step: "01",
        name: "A ligação",
        text: "Quinze minutos. Que tipo de cliente dá mais margem, quantos honorários você quer por mês, e de onde vêm os clientes hoje.",
      },
      {
        step: "02",
        name: "O orçamento",
        text: "Escopo, prazo e preço por escrito, fechados antes de começar.",
      },
      {
        step: "03",
        name: "A construção",
        text: "Montamos as três entradas e as páginas de nicho; você revisa num endereço de teste.",
      },
      {
        step: "04",
        name: "No ar e medindo",
        text: "Publicação, medição ligada e uma conversa depois de trinta dias sobre qual entrada trouxe contrato.",
      },
    ],
    faq: [
      {
        q: "Vale publicar faixa de honorário no site?",
        a: "Vale se você prefere menos contatos e melhores. Uma faixa por porte e regime afasta quem procura o mais barato e encurta a negociação com quem sobra. A página funciona com ou sem, e é um campo que você liga quando quiser.",
      },
      {
        q: "O site ajuda a competir com contabilidade online?",
        a: "Ajuda, e o argumento não é preço — é ter alguém que atende o telefone e conhece o negócio do cliente. Isso precisa estar escrito na página, porque é exatamente o que a concorrência de plataforma não consegue dizer.",
      },
      {
        q: "Dá para o contato cair direto num CRM?",
        a: "Dá. Pode cair no WhatsApp, num e-mail, numa planilha ou num CRM — inclusive num que a gente constrói e usa na própria operação.",
      },
      {
        q: "Quanto custa e em quanto tempo fica pronto?",
        a: "Depende de quantas entradas e quantos nichos. Fechamos na primeira ligação, por escrito; o prazo costuma ser de duas a quatro semanas.",
      },
      {
        q: "Vocês fazem os anúncios também?",
        a: "Fazemos, e para contabilidade a separação por intenção é tudo: 'abrir empresa' e 'trocar de contador' têm custos por clique e valores de cliente muito diferentes e não deveriam dividir o mesmo orçamento.",
      },
    ],
    closing: {
      heading: ["Ligue agora e conte", "que cliente você quer mais"],
      text: "Quinze minutos no telefone e a gente desenha as entradas do site em volta disso. Você sai com escopo, prazo e preço.",
    },
    whatsappMessage:
      "Olá! Vim pela página de sites para contabilidade. Quero separar abertura de empresa de troca de contador e receber o contato já qualificado.",
    serviceType: "Criação de sites para escritórios de contabilidade",
    investimento: null,
  },

  {
    slug: "sites-imobiliaria",
    adGroup: "Sites — imobiliárias",
    code: "LP-11",
    metaTitle: "Site para imobiliária com busca de imóveis",
    metaDescription:
      "Criação de site para imobiliária: busca de imóveis, integração com o CRM e contato do corretor em um toque. Fale agora: (48) 98425-6517.",
    keywords: [
      "site para imobiliária",
      "criação de site para corretor de imóveis",
      "site com busca de imóveis",
      "portal de imóveis próprio",
      "site para incorporadora",
      "integração CRM imobiliário site",
    ],
    h1: ["Site para imobiliária", "que não depende do portal"],
    deck: "Enquanto o seu imóvel só existe no portal, o cliente é do portal — e a cada ano ele custa mais caro. Um site próprio com busca decente é como uma imobiliária recupera a origem do lead.",
    assurances: [
      "Busca por bairro, valor, dormitórios e finalidade",
      "Integra com o CRM ou com o sistema de imóveis que você já usa",
      "Cada imóvel com o corretor a um toque de distância",
    ],
    painsHeading: "O custo de o site ser só uma vitrine",
    painsDeck:
      "Imobiliária é um dos setores em que o site mal feito custa mais, porque a alternativa é pagar por lead para sempre.",
    pains: [
      {
        title: "Toda a captação de lead é do portal",
        text: "O portal cobra por lead que ele mesmo qualifica, e o preço sobe conforme você depende dele. Todo lead que chega direto pelo site é margem que volta.",
      },
      {
        title: "A busca não funciona",
        text: "Sem filtro por bairro, faixa de preço, dormitórios e vagas, o visitante rola dez imóveis fora do perfil e sai. É a função central do site e costuma ser a pior parte dele.",
      },
      {
        title: "Os imóveis estão desatualizados",
        text: "Imóvel vendido ainda no ar é o jeito mais rápido de perder a confiança. Se a atualização é manual, ela não acontece — a integração com o sistema é o que resolve.",
      },
      {
        title: "Não existe caminho para o corretor",
        text: "O visitante achou o imóvel e agora precisa preencher um formulário e esperar. O contato do corretor responsável, em um toque, na própria página do imóvel, é o que converte.",
      },
    ],
    deliverablesHeading: "O que entra no site da imobiliária",
    deliverablesDeck:
      "A busca é o produto. Todo o resto do site existe para levar até ela e para tirar a pessoa dela falando com alguém.",
    deliverables: [
      {
        code: "TR-01",
        name: "Busca com os filtros que importam",
        text: "Finalidade, bairro, faixa de preço, dormitórios, vagas e área. Rápida no celular, que é onde a busca por imóvel acontece.",
      },
      {
        code: "TR-02",
        name: "Integração com o seu sistema",
        text: "Os imóveis vêm do CRM ou do sistema de gestão que você já usa, para que ninguém precise cadastrar duas vezes e nada fique desatualizado.",
      },
      {
        code: "TR-03",
        name: "Página por imóvel, feita para o Google",
        text: "Com fotos, características, mapa, dados estruturados e endereço limpo — é assim que um imóvel seu aparece na busca em vez de só o do portal.",
      },
      {
        code: "TR-04",
        name: "WhatsApp do corretor responsável",
        text: "Na própria página do imóvel, já com o código do imóvel na mensagem. Sem formulário, sem espera.",
      },
      {
        code: "TR-05",
        name: "Páginas por bairro e por empreendimento",
        text: "'Apartamento no Centro' e 'casa no Campeche' são buscas reais, com volume, que uma vitrine sem páginas de bairro não disputa.",
      },
      {
        code: "TR-06",
        name: "Captação de imóvel também",
        text: "Metade do negócio é ter o que vender. Uma página para o proprietário que quer anunciar, com o contato caindo no mesmo lugar.",
      },
    ],
    stepsHeading: "Do telefonema ao site no ar",
    steps: [
      {
        step: "01",
        name: "A ligação",
        text: "Quinze minutos. Que sistema você usa, quantos imóveis na carteira, quais bairros e quanto do lead vem de portal hoje.",
      },
      {
        step: "02",
        name: "O orçamento",
        text: "Escopo, prazo e preço por escrito. A integração é a parte que mais varia, e é dimensionada nessa conversa.",
      },
      {
        step: "03",
        name: "A construção",
        text: "Ligamos o sistema primeiro — sem os imóveis entrando sozinhos, o resto não vale a pena — e você revisa num endereço de teste.",
      },
      {
        step: "04",
        name: "No ar e medindo",
        text: "Publicação, medição ligada e uma conversa depois de trinta dias sobre quantos contatos vieram direto.",
      },
    ],
    faq: [
      {
        q: "Vocês integram com o meu sistema de imóveis?",
        a: "Na maioria dos casos sim. Os sistemas do setor costumam oferecer integração por XML ou por API, e é a primeira coisa que checamos na ligação — porque se os imóveis não entram sozinhos, o site vira trabalho manual e para de ser atualizado em dois meses.",
      },
      {
        q: "O site substitui o portal?",
        a: "No começo, não. Ele reduz a dependência: cada contato que chega direto é um lead que você não pagou, e as páginas por imóvel e por bairro acumulam posição na busca ao longo do tempo. A conta muda devagar e não volta atrás.",
      },
      {
        q: "Quantos imóveis o site aguenta?",
        a: "Milhares, sem problema. O que importa não é o número e sim a busca ser rápida no celular e cada imóvel ter uma página própria que o Google consiga ler.",
      },
      {
        q: "Quanto custa e em quanto tempo fica pronto?",
        a: "Depende quase inteiramente da integração. Fechamos na primeira ligação, por escrito; um site com integração costuma levar de quatro a seis semanas.",
      },
      {
        q: "Dá para cada corretor ter a própria página?",
        a: "Dá, e costuma valer: o corretor divulga a própria página, os imóveis dele aparecem nela e o contato vai direto para o WhatsApp dele, com o código do imóvel junto.",
      },
    ],
    closing: {
      heading: ["Ligue agora e conte", "quanto você paga por lead hoje"],
      text: "Com esse número já dá para dizer em quanto tempo o site se paga. Quinze minutos no telefone.",
    },
    whatsappMessage:
      "Olá! Vim pela página de sites para imobiliária. Quero busca de imóveis integrada ao meu sistema para depender menos do portal.",
    serviceType: "Criação de sites para imobiliárias",
    investimento: null,
  },

  {
    slug: "sites-arquitetura",
    adGroup: "Sites — arquitetura e design de interiores",
    code: "LP-12",
    metaTitle: "Site para escritório de arquitetura",
    metaDescription:
      "Criação de site para escritório de arquitetura e design de interiores: portfólio que carrega rápido e cliente certo chegando. Fale: (48) 98425-6517.",
    keywords: [
      "site para escritório de arquitetura",
      "criação de site para arquiteto",
      "site portfólio arquitetura",
      "site para design de interiores",
      "site para arquiteto de interiores",
      "portfólio online arquitetura",
    ],
    h1: ["Site para escritório de arquitetura", "que filtra o cliente errado"],
    deck: "O portfólio é o argumento inteiro, e quase todo site de arquitetura o esconde atrás de vinte segundos de carregamento. O seu trabalho merece abrir instantaneamente e atrair quem tem orçamento para ele.",
    assurances: [
      "Portfólio que abre rápido, mesmo com fotos grandes",
      "Escrito para atrair o porte de projeto que você quer",
      "Contato em um toque, sem formulário de dez campos",
    ],
    painsHeading: "Por que o portfólio bonito não traz projeto",
    painsDeck:
      "O problema quase nunca é o trabalho. São quatro coisas em volta dele.",
    pains: [
      {
        title: "As fotos matam o carregamento",
        text: "Imagem de arquitetura é pesada por natureza. Sem otimização e carregamento sob demanda, a primeira tela demora tanto que a pessoa sai antes de ver o primeiro projeto.",
      },
      {
        title: "Nada diz para quem o escritório trabalha",
        text: "Residencial de alto padrão, comercial, corporativo e retrofit são clientes com orçamentos incomparáveis. Um portfólio sem contexto atrai todos e fecha com os menores.",
      },
      {
        title: "Nenhum projeto conta a história",
        text: "Metragem, prazo, desafio e solução são o que fazem um cliente entender o valor do que você faz. Uma galeria sem texto é decoração, não argumento.",
      },
      {
        title: "Não fala de investimento em lugar nenhum",
        text: "Sem nenhuma indicação de porte de projeto, você gasta reuniões com quem nunca teve orçamento. Uma frase basta para filtrar.",
      },
    ],
    deliverablesHeading: "O que entra no site do escritório",
    deliverablesDeck:
      "Um portfólio que abre rápido, diz para quem é e termina numa conversa.",
    deliverables: [
      {
        code: "TR-01",
        name: "Portfólio rápido, com imagem grande",
        text: "Imagens otimizadas em formatos modernos, carregadas conforme a rolagem. Qualidade que você aprova, tempo de abertura que o cliente aceita.",
      },
      {
        code: "TR-02",
        name: "Uma página por projeto",
        text: "Com metragem, tipologia, ano, o problema e a solução — o que transforma foto em argumento e o que o Google consegue indexar.",
      },
      {
        code: "TR-03",
        name: "Separação por tipologia",
        text: "Residencial, comercial, corporativo, interiores. Cada busca cai no lugar certo e cada cliente se vê no portfólio.",
      },
      {
        code: "TR-04",
        name: "Uma página sobre como o escritório trabalha",
        text: "Etapas, entregas, prazos e o que está incluído. É a página que mais reduz reunião perdida.",
      },
      {
        code: "TR-05",
        name: "Contato direto, sem interrogatório",
        text: "Telefone e WhatsApp em um toque. Um formulário longo antes da primeira conversa é o atrito errado, na hora errada.",
      },
      {
        code: "TR-06",
        name: "SEO técnico e medição",
        text: "Títulos por projeto, dados estruturados, sitemap e medição ligada — para saber qual tipologia traz cliente.",
      },
    ],
    stepsHeading: "Do telefonema ao site no ar",
    steps: [
      {
        step: "01",
        name: "A ligação",
        text: "Quinze minutos. Que porte de projeto você quer, que tipologias, e de onde vêm os clientes hoje.",
      },
      {
        step: "02",
        name: "O orçamento",
        text: "Escopo, prazo e preço por escrito, fechados antes de começar.",
      },
      {
        step: "03",
        name: "A construção",
        text: "Você manda os projetos com as fotos em alta; nós tratamos, montamos as páginas e você revisa num endereço de teste.",
      },
      {
        step: "04",
        name: "No ar e medindo",
        text: "Publicação, medição ligada e uma conversa depois de trinta dias.",
      },
    ],
    faq: [
      {
        q: "Meu portfólio tem fotos enormes. O site vai ficar lento?",
        a: "Não, e é uma das partes mais técnicas do trabalho. As imagens são convertidas para formatos modernos, servidas no tamanho exato que a tela pede e carregadas conforme a pessoa rola. A qualidade que você aprova é a que fica; o que muda é quantos bytes o visitante precisa baixar para ver a primeira.",
      },
      {
        q: "Devo publicar faixa de investimento?",
        a: "Uma indicação de porte — 'projetos a partir de X m²' ou uma faixa — reduz muito reunião com quem não tem orçamento. É opcional e é um campo que você liga quando decidir.",
      },
      {
        q: "Eu consigo publicar projeto novo sozinho?",
        a: "Sim. O portfólio é a parte que muda, então ela vem com painel; o resto fica travado de propósito, porque é o que costuma quebrar um site.",
      },
      {
        q: "Vale mais investir em Instagram ou em site?",
        a: "O Instagram mostra o trabalho para quem já segue; o site captura quem está procurando arquiteto agora e pesquisa por tipologia e cidade. Para projeto no próximo trimestre, a busca converte melhor — mas a resposta depende de onde vêm os seus clientes hoje.",
      },
      {
        q: "Quanto custa e em quanto tempo fica pronto?",
        a: "Depende do número de projetos no portfólio. Fechamos na primeira ligação, por escrito; o prazo costuma ser de três a cinco semanas, com o tratamento das imagens sendo a parte mais longa.",
      },
    ],
    closing: {
      heading: ["Ligue agora e conte", "que projeto você quer mais"],
      text: "Quinze minutos no telefone e a gente organiza o portfólio em volta disso. Você sai com escopo, prazo e preço.",
    },
    whatsappMessage:
      "Olá! Vim pela página de sites para escritório de arquitetura. Quero um portfólio que abra rápido mesmo com foto grande.",
    serviceType: "Criação de sites para escritórios de arquitetura",
    investimento: null,
  },

  {
    slug: "sites-construtora",
    adGroup: "Sites — construtoras e reformas",
    code: "LP-13",
    metaTitle: "Site para construtora e empresa de reformas",
    metaDescription:
      "Criação de site para construtora e empresa de reformas: obras entregues, orçamento qualificado e contato em um toque. Fale: (48) 98425-6517.",
    keywords: [
      "site para construtora",
      "criação de site para empresa de reformas",
      "site para empreiteira",
      "site para incorporadora",
      "site para empresa de construção civil",
      "orçamento de reforma online",
    ],
    h1: ["Site para construtora e reformas", "que traz obra, não curioso"],
    deck: "Reforma é uma compra de alto valor feita por alguém com medo de ser enganado. O site que ganha não é o mais bonito: é o que mostra obra entregue, prazo cumprido e alguém com nome do outro lado.",
    assurances: [
      "Obras entregues com metragem, prazo e tipo",
      "Orçamento chegando com escopo e metragem preenchidos",
      "Um responsável com nome e telefone, não um formulário",
    ],
    painsHeading: "O medo que o cliente traz para a primeira conversa",
    painsDeck:
      "Todo mundo conhece alguém que teve obra abandonada. O site precisa desmontar isso antes da primeira ligação.",
    pains: [
      {
        title: "Nenhuma obra entregue à vista",
        text: "É a única prova que importa no setor. Fotos de obras suas, com bairro, metragem e prazo, valem mais que qualquer texto sobre compromisso e qualidade.",
      },
      {
        title: "Mistura reforma de banheiro com obra de galpão",
        text: "Residencial, comercial e industrial são três compradores e três tickets. Uma página para os três não fala com nenhum e atrai o menor.",
      },
      {
        title: "O orçamento chega sem nada",
        text: "'Quero orçar uma reforma' exige três mensagens antes de qualquer número. Tipo de obra, metragem, ambiente e prazo desejado no formulário economizam um dia.",
      },
      {
        title: "Ninguém tem nome",
        text: "'Solicite um orçamento' num formulário anônimo é exatamente o que a pessoa com medo de obra abandonada não quer. Um responsável com nome e telefone muda a conversa inteira.",
      },
    ],
    deliverablesHeading: "O que entra no site da construtora",
    deliverablesDeck:
      "Prova, separação por tipo de obra, e o caminho mais curto possível até uma pessoa.",
    deliverables: [
      {
        code: "TR-01",
        name: "Obras entregues com dados",
        text: "Cada obra com tipo, metragem, bairro, prazo e fotos do antes e depois. É o portfólio que vende no setor.",
      },
      {
        code: "TR-02",
        name: "Caminhos separados por tipo de obra",
        text: "Reforma residencial, obra comercial, construção do zero, retrofit. Cada anúncio cai onde deve.",
      },
      {
        code: "TR-03",
        name: "Orçamento que já vem qualificado",
        text: "Tipo de obra, metragem, ambientes, prazo e faixa de investimento preenchidos antes de a mensagem chegar.",
      },
      {
        code: "TR-04",
        name: "Como a empresa trabalha",
        text: "Etapas, medição, cronograma e o que está no contrato. A página que mais desarma o medo do cliente.",
      },
      {
        code: "TR-05",
        name: "Páginas por cidade e por bairro",
        text: "Obra é serviço local. Sem páginas de área de atuação e dados estruturados, você não entra na busca da região.",
      },
      {
        code: "TR-06",
        name: "SEO técnico e medição ligada",
        text: "Estrutura, velocidade, sitemap, Analytics e Search Console — para saber qual tipo de obra o site está trazendo.",
      },
    ],
    stepsHeading: "Do telefonema ao site no ar",
    steps: [
      {
        step: "01",
        name: "A ligação",
        text: "Quinze minutos. Que tipo de obra dá margem, que região você atende, e o que hoje traz cliente.",
      },
      {
        step: "02",
        name: "O orçamento",
        text: "Escopo, prazo e preço por escrito, fechados antes de começar.",
      },
      {
        step: "03",
        name: "A construção",
        text: "Pedimos as fotos e os dados das obras entregues, montamos os caminhos e você revisa num endereço de teste.",
      },
      {
        step: "04",
        name: "No ar e medindo",
        text: "Publicação, medição ligada e uma conversa depois de trinta dias sobre o que trouxe orçamento.",
      },
    ],
    faq: [
      {
        q: "Não tenho fotos boas das obras. E agora?",
        a: "É o item que mais pesa no resultado, então vale resolver: fotos de celular bem feitas de três ou quatro obras entregues já mudam a página. A lista do que precisamos vai junto com o orçamento, e é curta de propósito.",
      },
      {
        q: "Dá para publicar faixa de preço por metro quadrado?",
        a: "Dá, e filtra bastante. Como varia com acabamento, muita empresa prefere uma faixa por padrão de obra em vez de um número único. É opcional e é decisão sua.",
      },
      {
        q: "O orçamento pode cair direto no WhatsApp da equipe?",
        a: "Pode, com tipo de obra, metragem e prazo já preenchidos. Também pode ir para um e-mail, uma planilha ou um CRM.",
      },
      {
        q: "Quanto custa e em quanto tempo fica pronto?",
        a: "Depende de quantos tipos de obra e quantas cidades. Fechamos na primeira ligação, por escrito; o prazo costuma ser de duas a quatro semanas a partir das fotos.",
      },
      {
        q: "Vocês fazem anúncio no Google para construtora?",
        a: "Fazemos. É um setor de ticket alto onde o clique é caro e vale a pena — desde que a campanha de reforma residencial não divida orçamento com a de obra comercial, que é o erro mais comum.",
      },
    ],
    closing: {
      heading: ["Ligue agora e conte", "que obra você quer mais"],
      text: "Quinze minutos no telefone e a gente desenha o site em volta disso. Você sai com escopo, prazo e preço.",
    },
    whatsappMessage:
      "Olá! Vim pela página de sites para construtora e reformas. Quero mostrar obras entregues e receber orçamento já com metragem e escopo.",
    serviceType: "Criação de sites para construtoras e empresas de reformas",
    investimento: null,
  },

  {
    slug: "sites-moveis-planejados",
    adGroup: "Sites — móveis planejados e marcenaria",
    code: "LP-14",
    metaTitle: "Site para loja de móveis planejados",
    metaDescription:
      "Criação de site para móveis planejados e marcenaria: ambientes, projetos entregues e orçamento no WhatsApp. Fale agora: (48) 98425-6517.",
    keywords: [
      "site para móveis planejados",
      "criação de site para marcenaria",
      "site para loja de planejados",
      "site para marceneiro",
      "site para móveis sob medida",
      "orçamento de móveis planejados online",
    ],
    h1: [
      "Site para móveis planejados",
      "que tira o cliente da loja da esquina",
    ],
    deck: "Quem procura planejados vai visitar três lojas e pedir três projetos. O site decide quais três — e é ganho mostrando ambiente entregue, não catálogo de fabricante.",
    assurances: [
      "Ambientes entregues, seus, não render de catálogo",
      "Orçamento chegando com ambiente e metragem",
      "Contato em um toque, do celular da cozinha do cliente",
    ],
    painsHeading: "Por que o site do planejados não gera visita",
    painsDeck:
      "É um setor onde todo mundo mostra a mesma imagem de fabricante, e o cliente não consegue diferenciar ninguém.",
    pains: [
      {
        title: "Mostra render de fabricante, não obra sua",
        text: "O cliente já viu essa cozinha em quatro sites. Foto do que a sua equipe entregou, na casa de alguém, é a única imagem que diferencia.",
      },
      {
        title: "Não separa por ambiente",
        text: "Cozinha, dormitório, closet, home office e corporativo são buscas com volumes e tickets diferentes. Uma página só perde todas.",
      },
      {
        title: "Não explica o processo",
        text: "Medição, projeto 3D, prazo de fábrica, montagem e assistência. É o que o cliente compara entre as três lojas, e quase nunca está escrito.",
      },
      {
        title: "Não fala de prazo",
        text: "Prazo de entrega é a segunda maior objeção depois do preço, e a que mais decide quando o cliente está com a obra parada esperando o móvel.",
      },
    ],
    deliverablesHeading: "O que entra no site",
    deliverablesDeck:
      "Feito para ser aberto no celular, dentro de um apartamento em obra, por alguém decidindo em quem confiar.",
    deliverables: [
      {
        code: "TR-01",
        name: "Galeria de ambientes entregues",
        text: "Seus projetos, com ambiente, material e prazo. É o que separa você da loja que só tem catálogo.",
      },
      {
        code: "TR-02",
        name: "Uma página por ambiente",
        text: "Cozinha, dormitório, closet, home office, comercial. Cada busca cai onde deve, com texto próprio.",
      },
      {
        code: "TR-03",
        name: "O processo, do orçamento à montagem",
        text: "Medição, projeto, prazo de fábrica, montagem e assistência. A página que ganha a comparação entre três lojas.",
      },
      {
        code: "TR-04",
        name: "Orçamento com ambiente e metragem",
        text: "O contato chega sabendo qual ambiente, metragem aproximada e prazo desejado.",
      },
      {
        code: "TR-05",
        name: "Prazo e garantia em destaque",
        text: "Escritos, não escondidos. É o que a concorrência evita dizer e o que o cliente mais quer saber.",
      },
      {
        code: "TR-06",
        name: "SEO local e medição",
        text: "Páginas por cidade, dados estruturados, Analytics e Search Console ligados.",
      },
    ],
    stepsHeading: "Do telefonema ao site no ar",
    steps: [
      {
        step: "01",
        name: "A ligação",
        text: "Quinze minutos. Que ambientes dão margem, que região atende, e de onde vêm os clientes hoje.",
      },
      {
        step: "02",
        name: "O orçamento",
        text: "Escopo, prazo e preço por escrito, fechados antes de começar.",
      },
      {
        step: "03",
        name: "A construção",
        text: "Pedimos fotos de ambientes entregues, montamos as páginas e você revisa num endereço de teste.",
      },
      {
        step: "04",
        name: "No ar e medindo",
        text: "Publicação, medição ligada e uma conversa depois de trinta dias sobre qual ambiente trouxe visita.",
      },
    ],
    faq: [
      {
        q: "Posso usar as imagens do fabricante?",
        a: "Pode, mas elas não diferenciam nada — o concorrente usa as mesmas. Fotos das suas entregas, mesmo feitas com celular e bem enquadradas, convertem muito mais. Quando não houver, misturamos as duas e deixamos claro o que é seu.",
      },
      {
        q: "Vale publicar preço?",
        a: "Uma faixa por ambiente filtra bastante e reduz medição perdida. Como varia com material e ferragem, muita loja prefere 'a partir de' por ambiente. É opcional.",
      },
      {
        q: "Dá para receber o pedido de orçamento no WhatsApp da loja?",
        a: "Dá, já com ambiente, metragem e prazo preenchidos, no número que a equipe já usa.",
      },
      {
        q: "Quanto custa e em quanto tempo fica pronto?",
        a: "Depende de quantos ambientes e quantas cidades. Fechamos na primeira ligação, por escrito; o prazo costuma ser de duas a quatro semanas a partir das fotos.",
      },
      {
        q: "Vocês fazem anúncio no Google também?",
        a: "Fazemos. Planejados é uma busca local com intenção alta e ticket alto — funciona bem, desde que separada por ambiente e por cidade.",
      },
    ],
    closing: {
      heading: ["Ligue agora e conte", "qual ambiente dá mais margem"],
      text: "Quinze minutos no telefone e a gente organiza o site em volta dele. Você sai com escopo, prazo e preço.",
    },
    whatsappMessage:
      "Olá! Vim pela página de sites para móveis planejados. Quero uma página por ambiente e orçamento chegando com metragem.",
    serviceType:
      "Criação de sites para lojas de móveis planejados e marcenarias",
    investimento: null,
  },

  {
    slug: "sites-seguranca-eletronica",
    adGroup: "Sites — segurança eletrônica e CFTV",
    code: "LP-15",
    metaTitle: "Site para empresa de segurança eletrônica",
    metaDescription:
      "Criação de site para empresa de CFTV, alarmes e controle de acesso: residencial e empresarial separados, com monitoramento recorrente. (48) 98425-6517.",
    keywords: [
      "site para empresa de segurança eletrônica",
      "site para empresa de CFTV",
      "criação de site para instalador de câmeras",
      "site para empresa de alarmes",
      "site para controle de acesso",
      "site para empresa de monitoramento",
    ],
    h1: [
      "Site para empresa de segurança eletrônica",
      "que vende o monitoramento",
    ],
    deck: "Instalar câmera é uma venda; monitorar é receita todo mês. A maior parte dos sites do setor vende a primeira e esquece a segunda, que é justamente a que sustenta a empresa.",
    assurances: [
      "Residencial, comercial e condomínio em caminhos separados",
      "O contrato de monitoramento pedido na própria página",
      "Atendimento de urgência em um toque",
    ],
    painsHeading: "Onde o setor deixa a receita recorrente na mesa",
    painsDeck:
      "Quatro pontos, e três deles são sobre a mesma coisa: a diferença entre vender um equipamento e vender uma assinatura.",
    pains: [
      {
        title: "Vende câmera, não segurança",
        text: "O cliente não quer um equipamento com tantos megapixels. Ele quer não ser assaltado e conseguir ver a casa do celular. O site precisa falar disso.",
      },
      {
        title: "Não pede o contrato de monitoramento",
        text: "É a receita previsível do setor e quase nunca tem uma página própria explicando o que cobre, qual o tempo de resposta e como contratar.",
      },
      {
        title: "Fala com o morador e com o síndico ao mesmo tempo",
        text: "Casa, comércio e condomínio têm objeções e orçamentos incomparáveis. Uma página para os três atrai o menor ticket dos três.",
      },
      {
        title: "Compete no preço do equipamento",
        text: "Sem falar de projeto, garantia, suporte e tempo de resposta, sobra só o preço da câmera — e sempre existe alguém mais barato no marketplace.",
      },
    ],
    deliverablesHeading: "O que entra no site",
    deliverablesDeck:
      "Duas receitas, três compradores, e o telefone sempre visível.",
    deliverables: [
      {
        code: "TR-01",
        name: "Caminhos separados por cliente",
        text: "Residencial, comercial e condomínio, com o argumento e o formulário de cada um.",
      },
      {
        code: "TR-02",
        name: "Página de monitoramento",
        text: "O que o contrato cobre, o tempo de resposta, o que acontece quando o alarme dispara e como contratar. A página que traz a recorrência.",
      },
      {
        code: "TR-03",
        name: "Páginas por serviço",
        text: "CFTV, alarme, cerca elétrica, controle de acesso, portaria remota, automação de portão. Cada busca com onde cair.",
      },
      {
        code: "TR-04",
        name: "Orçamento com o ambiente descrito",
        text: "Tipo de imóvel, metragem, número de pontos e se é instalação nova ou substituição, já preenchidos.",
      },
      {
        code: "TR-05",
        name: "Prova técnica e garantia",
        text: "Obras entregues, marcas com que você trabalha, certificações e prazo de atendimento por escrito.",
      },
      {
        code: "TR-06",
        name: "SEO local e medição",
        text: "Páginas por cidade, dados estruturados de negócio local, Analytics e Search Console.",
      },
    ],
    stepsHeading: "Do telefonema ao site no ar",
    steps: [
      {
        step: "01",
        name: "A ligação",
        text: "Quinze minutos. Quanto é instalação e quanto é contrato, que regiões você atende e onde está a margem.",
      },
      {
        step: "02",
        name: "O orçamento",
        text: "Escopo, prazo e preço por escrito. A página de monitoramento entra no escopo, não como adicional.",
      },
      {
        step: "03",
        name: "A construção",
        text: "Pedimos fotos de instalações, marcas atendidas e o que o seu contrato cobre; você revisa num endereço de teste.",
      },
      {
        step: "04",
        name: "No ar e medindo",
        text: "Publicação, medição ligada e uma conversa depois de trinta dias sobre qual caminho trouxe mais receita.",
      },
    ],
    faq: [
      {
        q: "Vale mesmo ter uma página só de monitoramento?",
        a: "É a página mais rentável do site na maior parte dos casos, porque vende assinatura em vez de equipamento. Quase nenhum concorrente tem uma — quase todos listam 'monitoramento' como um item entre dez.",
      },
      {
        q: "Como competir com câmera barata de marketplace?",
        a: "Não competindo nisso. O site precisa falar de projeto, instalação correta, garantia, suporte e tempo de resposta — coisas que um marketplace não entrega e que o cliente só valoriza quando alguém escreve.",
      },
      {
        q: "Dá para o orçamento chegar já com os pontos de câmera?",
        a: "Dá: tipo de imóvel, metragem, número aproximado de pontos e se é instalação ou substituição. A equipe abre a conversa sabendo o que oferecer.",
      },
      {
        q: "Quanto custa e em quanto tempo fica pronto?",
        a: "Depende de quantos segmentos e cidades o site cobre. Fechamos na primeira ligação, por escrito; o prazo costuma ser de duas a quatro semanas.",
      },
      {
        q: "Vocês fazem os anúncios também?",
        a: "Fazemos, e aqui a separação por campanha importa muito: instalação residencial, condomínio e monitoramento têm custos por clique e valores de cliente bem diferentes.",
      },
    ],
    closing: {
      heading: ["Ligue agora e conte", "quantos contratos você tem"],
      text: "Com esse número já dá para dizer onde o site deveria empurrar. Quinze minutos no telefone.",
    },
    whatsappMessage:
      "Olá! Vim pela página de sites para segurança eletrônica. Quero vender o contrato de monitoramento, não só a instalação de câmera.",
    serviceType: "Criação de sites para empresas de segurança eletrônica",
    investimento: null,
  },

  {
    slug: "sites-clinica-estetica",
    adGroup: "Sites — estética e bem-estar",
    code: "LP-16",
    metaTitle: "Site para clínica de estética",
    metaDescription:
      "Criação de site para clínica de estética: procedimentos por página, agendamento online e contato em um toque. Fale agora: (48) 98425-6517.",
    keywords: [
      "site para clínica de estética",
      "criação de site para estética avançada",
      "site para spa",
      "agendamento online estética",
      "site para clínica de depilação a laser",
      "site para esteticista",
    ],
    h1: ["Site para clínica de estética", "que preenche a agenda da semana"],
    deck: "Estética é decisão rápida, comparada no celular e fechada por quem responde primeiro. O site precisa explicar o procedimento, mostrar a estrutura e deixar marcar sem falar com ninguém.",
    assurances: [
      "Agendamento online, dia e turno, sem ligação",
      "Uma página por procedimento",
      "Escrito dentro do que os conselhos permitem anunciar",
    ],
    painsHeading: "O que segura a cliente antes de marcar",
    painsDeck:
      "Quatro dúvidas, e nenhuma delas é sobre preço na primeira tela.",
    pains: [
      {
        title: "Não explica o procedimento",
        text: "Quantas sessões, dói, precisa de repouso, quanto tempo dura o resultado. Quem não responde isso na página responde no WhatsApp, uma cliente por vez — ou não responde a tempo.",
      },
      {
        title: "Uma página para vinte procedimentos",
        text: "Depilação a laser, botox, preenchimento, limpeza de pele e drenagem são buscas diferentes com tickets diferentes. Uma lista não ganha nenhuma.",
      },
      {
        title: "Não mostra a estrutura nem quem atende",
        text: "É um procedimento no corpo da pessoa. Foto real da sala, do equipamento e da profissional, com registro, vale mais que qualquer adjetivo.",
      },
      {
        title: "Marcar exige telefonar",
        text: "A busca acontece à noite. Se o único caminho é ligar no horário comercial, a cliente marca em quem tinha um botão.",
      },
    ],
    deliverablesHeading: "O que entra no site da clínica",
    deliverablesDeck:
      "Explicação clara, prova visível e agendamento sem atrito.",
    deliverables: [
      {
        code: "TR-01",
        name: "Uma página por procedimento",
        text: "Com o que é, quantas sessões, como é a recuperação e para quem é indicado. É o que responde a busca e o que reduz mensagem repetida.",
      },
      {
        code: "TR-02",
        name: "Agendamento online",
        text: "Procedimento, dia e turno escolhidos pela cliente; o pedido chega pronto no WhatsApp ou no sistema da recepção.",
      },
      {
        code: "TR-03",
        name: "A estrutura e a equipe",
        text: "Fotos reais da clínica e dos equipamentos, com nome e registro de quem atende.",
      },
      {
        code: "TR-04",
        name: "Conteúdo dentro das regras do conselho",
        text: "Sem promessa de resultado e com cuidado no uso de antes e depois — as regras variam conforme quem executa o procedimento, e escrevemos dentro delas com a sua revisão.",
      },
      {
        code: "TR-05",
        name: "Contato em um toque",
        text: "Telefone e WhatsApp fixos na tela do celular, visíveis em qualquer ponto da página.",
      },
      {
        code: "TR-06",
        name: "SEO local e medição",
        text: "Dados estruturados, páginas por cidade e bairro, Analytics e Search Console ligados.",
      },
    ],
    stepsHeading: "Do telefonema ao site no ar",
    steps: [
      {
        step: "01",
        name: "A ligação",
        text: "Quinze minutos. Quais procedimentos dão margem, quem executa, e o que hoje enche a agenda.",
      },
      {
        step: "02",
        name: "O orçamento",
        text: "Escopo, prazo e preço por escrito, fechados antes de começar.",
      },
      {
        step: "03",
        name: "A construção",
        text: "Pedimos fotos da clínica e os detalhes de cada procedimento; você revisa num endereço de teste.",
      },
      {
        step: "04",
        name: "No ar e medindo",
        text: "Publicação, perfil do Google ajustado e uma conversa depois de trinta dias sobre o que trouxe agendamento.",
      },
    ],
    faq: [
      {
        q: "Posso publicar fotos de antes e depois?",
        a: "Depende de quem executa o procedimento e de qual conselho regula a atividade — as regras para médico, biomédico e esteticista não são as mesmas, e algumas vedam o uso publicitário. Escrevemos pelo critério mais conservador e você revisa antes de publicar. Não somos assessoria jurídica.",
      },
      {
        q: "Dá para publicar preço dos procedimentos?",
        a: "Onde o conselho permitir, uma faixa filtra bastante e reduz mensagem de curiosa. Definimos isso junto na ligação, procedimento a procedimento.",
      },
      {
        q: "O agendamento integra com o sistema da clínica?",
        a: "Se o sistema tiver integração, sim. Quando não tem, o pedido chega estruturado no WhatsApp da recepção, com procedimento, dia e turno preenchidos.",
      },
      {
        q: "Vale mais Instagram ou site?",
        a: "O Instagram mantém quem já segue; o site captura quem está procurando o procedimento agora e comparando clínicas. Para agenda no mês que vem, a busca converte melhor.",
      },
      {
        q: "Quanto custa e em quanto tempo fica pronto?",
        a: "Depende de quantos procedimentos e de o agendamento entrar. Fechamos na primeira ligação, por escrito; o prazo costuma ser de duas a quatro semanas.",
      },
    ],
    closing: {
      heading: ["Ligue agora e conte", "qual sala fica vazia"],
      text: "Quinze minutos no telefone e a gente organiza o site em volta dela. Você sai com escopo, prazo e preço.",
    },
    whatsappMessage:
      "Olá! Vim pela página de sites para clínica de estética. Quero agendamento online e uma página por procedimento.",
    serviceType: "Criação de sites para clínicas de estética",
    investimento: null,
  },

  {
    slug: "sites-clinica-veterinaria",
    adGroup: "Sites — veterinária e pet",
    code: "LP-17",
    metaTitle: "Site para clínica veterinária e pet shop",
    metaDescription:
      "Criação de site para clínica veterinária: emergência 24h, agendamento de consulta e banho e tosa em um toque. Fale agora: (48) 98425-6517.",
    keywords: [
      "site para clínica veterinária",
      "criação de site para veterinário",
      "site para pet shop",
      "site para hospital veterinário",
      "agendamento banho e tosa online",
      "site para veterinário 24 horas",
    ],
    h1: ["Site para clínica veterinária", "que atende quem está com pressa"],
    deck: "Metade de quem procura veterinário no Google está com o animal passando mal agora. A outra metade quer marcar banho. São duas urgências opostas, e o site precisa atender as duas sem confundir nenhuma.",
    assurances: [
      "Emergência no topo, com telefone em um toque",
      "Agendamento de banho e tosa sem ligação",
      "Especialidades e horário sempre visíveis",
    ],
    painsHeading: "Onde a clínica perde o cliente",
    painsDeck: "Quatro pontos, e o primeiro deles é o que decide um plantão.",
    pains: [
      {
        title: "Não diz o horário nem se atende emergência",
        text: "É a única informação que importa às onze da noite com um cachorro passando mal. Se ela não está na primeira tela, a pessoa liga para a próxima clínica da lista.",
      },
      {
        title: "Mistura consulta com banho e tosa",
        text: "São dois clientes com pressa diferente e ticket diferente. Um site que trata os dois igual atrasa a emergência e complica o agendamento de rotina.",
      },
      {
        title: "Não lista as especialidades",
        text: "Ortopedia, dermatologia, cardiologia, exames de imagem, animais silvestres. Quem procura especialista procura pelo nome da especialidade.",
      },
      {
        title: "Banho e tosa só por telefone",
        text: "É agendamento recorrente e de baixa complexidade — exatamente o tipo que a pessoa prefere fazer sozinha, à noite, sem falar com ninguém.",
      },
    ],
    deliverablesHeading: "O que entra no site da clínica",
    deliverablesDeck:
      "Emergência no topo, rotina agendável, e a informação que a pessoa procura antes de decidir.",
    deliverables: [
      {
        code: "TR-01",
        name: "Emergência em destaque",
        text: "Horário, se há plantão e o telefone em um toque, no ponto mais alto da página e fixo na tela do celular.",
      },
      {
        code: "TR-02",
        name: "Agendamento de banho e tosa",
        text: "Porte, serviço, dia e turno escolhidos pelo tutor; o pedido chega pronto para a recepção.",
      },
      {
        code: "TR-03",
        name: "Página por especialidade",
        text: "Cada especialidade com o que trata e quem atende, com CRMV. É o que faz a clínica aparecer para a busca certa.",
      },
      {
        code: "TR-04",
        name: "A estrutura e a equipe",
        text: "Fotos reais da clínica, do centro cirúrgico e dos equipamentos, com nome e registro de quem atende.",
      },
      {
        code: "TR-05",
        name: "Mapa, horário e como chegar",
        text: "Com estacionamento e o botão que abre a rota direto no aplicativo — porque quem está com pressa não digita endereço.",
      },
      {
        code: "TR-06",
        name: "SEO local e medição",
        text: "Dados estruturados de clínica veterinária, horário de funcionamento, perfil do Google ligado e medição desde o primeiro dia.",
      },
    ],
    stepsHeading: "Do telefonema ao site no ar",
    steps: [
      {
        step: "01",
        name: "A ligação",
        text: "Quinze minutos. Se há plantão, quais especialidades, se tem banho e tosa e o que hoje traz cliente.",
      },
      {
        step: "02",
        name: "O orçamento",
        text: "Escopo, prazo e preço por escrito, fechados antes de começar.",
      },
      {
        step: "03",
        name: "A construção",
        text: "Pedimos fotos da clínica e da equipe, montamos as páginas e você revisa num endereço de teste.",
      },
      {
        step: "04",
        name: "No ar e medindo",
        text: "Publicação, perfil do Google ajustado, medição ligada e uma conversa depois de trinta dias.",
      },
    ],
    faq: [
      {
        q: "Vale a pena separar banho e tosa do atendimento clínico?",
        a: "Vale, e costuma ser a mudança que mais alivia a recepção: o banho é agendamento recorrente e simples, que o tutor prefere fazer sozinho pelo celular, e tirá-lo do telefone libera a linha para a consulta e a emergência.",
      },
      {
        q: "O site ajuda em busca de emergência?",
        a: "Ajuda muito, porque 'veterinário 24 horas' e 'veterinário perto de mim' dependem de horário de funcionamento correto, dados estruturados e perfil do Google alinhado. É um trabalho técnico e é onde a maior parte das clínicas perde a ligação.",
      },
      {
        q: "Dá para integrar o agendamento com o sistema da clínica?",
        a: "Se o sistema tiver integração, sim. Quando não tem, o pedido chega estruturado no WhatsApp da recepção com porte, serviço, dia e turno.",
      },
      {
        q: "Quanto custa e em quanto tempo fica pronto?",
        a: "Depende de quantas especialidades e de o agendamento entrar. Fechamos na primeira ligação, por escrito; o prazo costuma ser de duas a quatro semanas.",
      },
      {
        q: "Vocês fazem anúncio no Google também?",
        a: "Fazemos. Emergência veterinária é uma das buscas locais de intenção mais alta que existe — e uma das que mais desperdiça dinheiro quando cai numa página institucional em vez de num telefone.",
      },
    ],
    closing: {
      heading: ["Ligue agora e conte", "se vocês atendem plantão"],
      text: "Quinze minutos no telefone e a gente monta o site em volta da urgência certa. Você sai com escopo, prazo e preço.",
    },
    whatsappMessage:
      "Olá! Vim pela página de sites para clínica veterinária. Quero destaque para emergência e agendamento de banho e tosa sem ligação.",
    serviceType: "Criação de sites para clínicas veterinárias",
    investimento: null,
  },

  {
    slug: "parceria-agencias",
    adGroup: "Parcerias — agências e gestores de tráfego",
    code: "LP-18",
    metaTitle: "Desenvolvimento de sites white label para agências",
    metaDescription:
      "Somos o time técnico da sua agência: sites, sistemas e automações entregues no seu nome, no prazo combinado. Fale agora: (48) 98425-6517.",
    keywords: [
      "desenvolvimento de sites white label",
      "parceria desenvolvimento para agências",
      "desenvolvedor parceiro de agência",
      "terceirizar desenvolvimento de sites",
      "landing page para gestor de tráfego",
      "fábrica de sites para agências",
    ],
    h1: ["Desenvolvimento white label", "para agências e gestores de tráfego"],
    deck: "Você vende a estratégia e a mídia. Nós somos o time técnico que entrega o site, a landing page e a automação no seu nome, no prazo, sem aparecer para o seu cliente.",
    assurances: [
      "Entregue no seu nome, com o seu domínio e o seu contrato",
      "Prazo fechado por escrito, com um responsável técnico",
      "Não prospectamos o seu cliente. Nunca.",
    ],
    painsHeading: "O gargalo que toda agência conhece",
    painsDeck:
      "Vender é a parte que você domina. O que trava é o que acontece entre o aceite e a entrega.",
    pains: [
      {
        title: "O freelancer some no meio do projeto",
        text: "É o risco que a agência assume sozinha, porque o cliente é seu e o prazo também. Uma empresa com contrato e mais de uma pessoa não some.",
      },
      {
        title: "A landing page atrasa e a campanha espera",
        text: "Mídia parada esperando página é dinheiro parado e cliente irritado. Uma landing page tem que sair em dias, não em semanas.",
      },
      {
        title: "O site é lento e destrói o Índice de qualidade",
        text: "Você otimiza a campanha e o clique fica caro mesmo assim, porque a página demora e converte mal. Isso é engenharia, não mídia.",
      },
      {
        title: "O parceiro técnico vira concorrente",
        text: "O medo legítimo de quem terceiriza. Aqui a regra é escrita em contrato: o cliente é seu, falamos com você, e não vendemos mídia para quem chega por você.",
      },
    ],
    deliverablesHeading: "Como a parceria funciona",
    deliverablesDeck:
      "Um time técnico anexado à sua agência, com regras claras sobre o que é seu.",
    deliverables: [
      {
        code: "TR-01",
        name: "Landing pages rápidas, em dias",
        text: "Construídas para converter tráfego pago: primeira tela que responde a busca, carregamento rápido no celular e medição já ligada.",
      },
      {
        code: "TR-02",
        name: "Sites institucionais e e-commerce",
        text: "O projeto inteiro, do domínio à publicação, entregue no nome da sua agência.",
      },
      {
        code: "TR-03",
        name: "Sistemas e automações",
        text: "CRM sob medida, automação de WhatsApp com IA, integrações e painéis — a parte que a maioria das agências não consegue vender por não ter quem entregue.",
      },
      {
        code: "TR-04",
        name: "Medição e conversão configuradas",
        text: "Analytics, Search Console, tags de conversão e eventos de clique e ligação. Sem isso a sua campanha otimiza para clique, e você sabe disso.",
      },
      {
        code: "TR-05",
        name: "Um responsável técnico com telefone",
        text: "Você fala com quem constrói, não com um gerente de conta. E o seu cliente nunca precisa saber que existimos.",
      },
      {
        code: "TR-06",
        name: "Acordo de não concorrência por escrito",
        text: "Não prospectamos, não vendemos mídia e não abordamos os clientes que chegam pela sua agência. Está no contrato, não na conversa.",
      },
    ],
    stepsHeading: "Como começa",
    steps: [
      {
        step: "01",
        name: "A ligação",
        text: "Quinze minutos. O que a sua agência vende, o que hoje trava na entrega e que volume você tem por mês.",
      },
      {
        step: "02",
        name: "A tabela de parceiro",
        text: "Preço por tipo de entrega e prazo por tipo de entrega, por escrito, para você precificar sem nos perguntar a cada proposta.",
      },
      {
        step: "03",
        name: "O primeiro projeto",
        text: "Começamos por um, pequeno, para você medir prazo e qualidade antes de colocar um cliente grande na mesa.",
      },
      {
        step: "04",
        name: "A rotina",
        text: "Fila de projetos, um canal direto e prazos combinados por entrega. Sem reunião semanal de status.",
      },
    ],
    faq: [
      {
        q: "Vocês vão roubar meu cliente?",
        a: "Não, e isso vira cláusula no contrato de parceria: não prospectamos, não vendemos mídia e não abordamos quem chega pela sua agência. Vale dizer também o motivo prático — a nossa operação é construir, e uma agência parceira que confia manda projeto todo mês, o que vale muito mais que um cliente tomado uma vez.",
      },
      {
        q: "A entrega é no meu nome?",
        a: "Sim. Domínio, hospedagem e contas no nome da sua agência ou do seu cliente, comunicação com o cliente feita por você, e nenhuma marca nossa na entrega.",
      },
      {
        q: "Quanto tempo leva uma landing page?",
        a: "Uma landing page de campanha costuma sair em poucos dias depois do briefing e do conteúdo; um site institucional leva de duas a quatro semanas. O prazo entra na tabela de parceiro por tipo de entrega, para você poder prometer sem perguntar.",
      },
      {
        q: "Vocês também fazem tráfego?",
        a: "Fazemos para clientes diretos nossos — e é justamente por isso que a cláusula acima existe. Para um cliente que chega pela sua agência, a mídia é sua; nós ficamos na parte técnica.",
      },
      {
        q: "Qual o volume mínimo?",
        a: "Nenhum. Começamos por um projeto pequeno de propósito, porque é assim que você mede prazo e qualidade com risco baixo antes de confiar um cliente importante.",
      },
    ],
    closing: {
      heading: ["Ligue agora e conte", "o que está travando na entrega"],
      text: "Quinze minutos no telefone e você sai com a tabela de parceiro: preço e prazo por tipo de entrega, por escrito.",
    },
    whatsappMessage:
      "Olá! Vim pela página de parceria white label. Tenho uma agência e quero a tabela de parceiro com preço e prazo por tipo de entrega.",
    serviceType:
      "Desenvolvimento de sites e sistemas white label para agências",
    investimento: null,
  },
];

/**
 * Two identities have to stay unique, and both fail silently if they do not.
 *
 * A duplicated slug means `generateStaticParams` builds the same URL twice and
 * one of the two pages simply never exists; a duplicated code means the
 * analytics screen and the closing plate name two different pages the same
 * thing. Same reason `niches.ts` throws at import rather than letting a
 * registry mistake become a wrong number three screens away.
 */
function assertUnique(field: "slug" | "code"): void {
  const seen = new Set<string>();
  for (const page of adPages) {
    if (seen.has(page[field])) {
      throw new Error(`ads.ts: ${field} duplicado — ${page[field]}`);
    }
    seen.add(page[field]);
  }
}

assertUnique("slug");
assertUnique("code");

export const adPageBySlug = new Map(adPages.map((page) => [page.slug, page]));
