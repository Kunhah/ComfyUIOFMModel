/**
 * Two things that happen once, before the server accepts requests: the Overture
 * extract is loaded so the first search doesn't pay for it, and the WhatsApp
 * scheduler's timer is started so reminders that came due while the container
 * was down go out now rather than at the next inbound message.
 *
 * A failure here must not be thrown. Next treats a rejected instrumentation hook
 * as a failure to start: the process never serves anything, and *every* route
 * answers 500 — the marketing site included — because a lead extract is missing
 * from a volume. That is the state a container starts in the first time it runs
 * against an empty volume, which the deployment explicitly supports.
 *
 * Swallowing it costs nothing: `getConnection()` doesn't cache a failed init, so
 * the next prospector request retries and the tool starts working the moment the
 * volume is seeded, without a restart. The prospector page already renders the
 * "extract missing" state on its own.
 */
export async function register(): Promise<void> {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;

  const { warmProspector } = await import("@/lib/prospector/overture");
  try {
    await warmProspector();
  } catch (error) {
    console.warn(
      JSON.stringify({
        service: "prospector",
        event: "warm.failed",
        message: error instanceof Error ? error.message : String(error),
      }),
    );
  }

  // Same swallow, same reason. The scheduler only ever sends messages that are
  // already in the database, so a failure to start it is a feature being late —
  // never a reason for the whole site to refuse to boot. It is also cheap when
  // WhatsApp is not configured: the tick checks and returns.
  try {
    const { startScheduler } = await import("@/lib/whatsapp/tick");
    startScheduler();
  } catch (error) {
    console.warn(
      JSON.stringify({
        service: "whatsapp",
        event: "scheduler.start.failed",
        message: error instanceof Error ? error.message : String(error),
      }),
    );
  }

  // Meeting reviews that were transcribing when the process stopped. The work
  // happens in a background task, so a deploy mid-transcription leaves a row
  // claiming to be busy with nothing working on it — and an operator watching
  // "Transcrevendo" forever has no way to tell that from a slow file. Swallowed
  // like the two above: a review picked up late is never a reason not to boot.
  try {
    const { resumePending } = await import("@/lib/review/pipeline");
    const count = await resumePending();
    if (count > 0) {
      console.warn(
        JSON.stringify({ service: "review", event: "resumed", count }),
      );
    }
  } catch (error) {
    console.warn(
      JSON.stringify({
        service: "review",
        event: "resume.failed",
        message: error instanceof Error ? error.message : String(error),
      }),
    );
  }
}
