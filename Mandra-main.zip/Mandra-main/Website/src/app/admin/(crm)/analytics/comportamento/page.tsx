import { requireAdmin } from "@/lib/auth/server";
import { fmt } from "@/lib/admin/format";
import {
  byViewport,
  deadClicks,
  depthBuckets,
  dwell,
  exitPoints,
  health,
  overview,
  recordedPages,
} from "@/lib/analytics/db";
import { SECTION_LABEL, type Section } from "@/lib/analytics/events";
import { parseScope, type Params } from "@/lib/analytics/scope";
import { Filters } from "@/components/admin/analytics/filters";
import {
  Bars,
  Broken,
  DataTable,
  Empty,
  NoSessions,
  Panel,
  ThinSample,
  Tile,
  pct,
  seconds,
} from "@/components/admin/analytics/ui";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const metadata = { title: "Analytics — comportamento" };

const PATH = "/admin/analytics/comportamento";

const sectionName = (name: string) =>
  SECTION_LABEL[name as Section] ?? name;

/**
 * What people do that the funnel cannot show.
 *
 * Every other screen in this section measures progress through a page. This
 * one measures friction, and the distinction matters because the two suggest
 * completely different work: a funnel drop is answered by rewriting, and
 * everything here is answered by fixing.
 *
 * The dead-click table is the reason the screen exists. It is the only block
 * in the whole section whose rows convert into a change with no interpretation
 * at all — each one is a reader who tried to go further, in the single moment
 * they were willing to act, and got nothing back. A heading styled like a
 * button. A card that looks tappable. A phone number set as text on a page
 * whose entire job is phone calls.
 */
export default async function BehaviourScreen({
  searchParams,
}: {
  searchParams: Promise<Params>;
}) {
  await requireAdmin("/admin/analytics");

  const parsed = parseScope(await searchParams);
  const { scope } = parsed;

  const disk = health();
  if (!disk.writable) return <Broken path={disk.path} reason={disk.reason} />;

  const recorded = new Set(recordedPages());
  const stats = overview(scope);

  if (stats.sessions === 0) {
    return (
      <>
        <Filters path={PATH} scope={parsed} recorded={recorded} />
        <NoSessions />
      </>
    );
  }

  const dead = deadClicks(scope);
  const exits = exitPoints(scope);
  const held = dwell(scope);

  return (
    <>
      <h1 className="mt-4 text-3xl font-semibold tracking-tight md:text-[34px]">
        Comportamento
      </h1>
      <p className="text-fg-muted mt-2 max-w-[70ch] text-sm">
        Atrito, não progresso. O funil diz o que reescrever; esta tela diz o que
        consertar — o que as pessoas tentam clicar e não funciona, onde
        estavam quando desistiram e qual largura de tela quebra a página.
      </p>

      <Filters path={PATH} scope={parsed} recorded={recorded} />
      <ThinSample sessions={stats.sessions} />

      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Tile
          label="Sessões com clique morto"
          value={fmt(stats.withDeadClicks)}
          note={pct((stats.withDeadClicks / stats.sessions) * 100)}
          alarm={stats.withDeadClicks > 0}
        />
        <Tile
          label="Sessões com clique repetido"
          value={fmt(stats.withRageClicks)}
          note="mesmo ponto, várias vezes seguidas"
          alarm={stats.withRageClicks > 0}
        />
        <Tile
          label="Até a primeira rolagem"
          value={seconds(stats.medianFirstScrollMs)}
          note="mediana · abaixo de 1s é primeira tela pulada"
        />
        <Tile
          label="Saíram na primeira tela"
          value={fmt(stats.bounced)}
          note={pct((stats.bounced / stats.sessions) * 100)}
        />
      </div>

      <Panel
        title="Cliques que não fazem nada"
        hint="A tabela mais direta desta seção: cada linha é alguém que quis avançar e a página respondeu com nada. Um título com cara de botão, um cartão que parece tocável, um telefone escrito como texto."
      >
        {dead.length === 0 ? (
          <Empty>
            Ninguém clicou em nada inerte no período. É o resultado que se quer
            aqui — a tabela vazia é boa notícia.
          </Empty>
        ) : (
          <DataTable
            columns={[
              { head: "O que foi clicado" },
              { head: "Sessões", numeric: true },
              { head: "Cliques", numeric: true },
              { head: "Repetidos", numeric: true },
            ]}
            rows={dead.map((row) => ({
              key: row.target,
              cells: [
                row.target,
                fmt(row.sessions),
                fmt(row.clicks),
                row.rage > 0 ? fmt(row.rage) : "—",
              ],
            }))}
          />
        )}
      </Panel>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel
          title="Onde estavam quando saíram"
          hint="Não é o mesmo que o funil. Quem chega ao fim, volta ao preço e desiste ali tem funil completo e objeção no preço — e só esta tabela mostra isso."
        >
          {exits.length === 0 ? (
            <Empty>
              Ainda sem saídas registradas. O sinal só existe para sessões
              abertas depois desta versão do medidor.
            </Empty>
          ) : (
            <Bars
              rows={exits.map((row) => ({
                label: sectionName(row.section),
                value: row.sessions,
                note: pct(row.share),
                fill: row.share,
              }))}
            />
          )}
        </Panel>

        <Panel
          title="Quanto tempo cada faixa segura"
          hint="Mediana do tempo visível. Abaixo de quatro segundos a faixa está sendo passada, não lida — e o funil registra isso como um degrau sem perda."
        >
          <Bars
            rows={held.map((row) => ({
              label: sectionName(row.section),
              value: row.medianMs,
              hideValue: true,
              note: `${seconds(row.medianMs)} · ${fmt(row.sessions)} sessões`,
              warn: row.medianMs < 4000,
            }))}
          />
        </Panel>

        <Panel
          title="Por largura de tela"
          hint={`"Celular converte pior" não é uma mudança que alguém possa fazer. Em qual largura ele quebra, é: um layout que vai bem em 390px e mal em 360px tem um problema de breakpoint, não de texto.`}
        >
          <DataTable
            columns={[
              { head: "Largura" },
              { head: "Sessões", numeric: true },
              { head: "Contatos", numeric: true },
              { head: "Taxa", numeric: true },
            ]}
            rows={byViewport(scope).map((row) => ({
              key: row.label,
              dim: row.sessions < 30,
              cells: [
                row.label,
                fmt(row.sessions),
                fmt(row.converted),
                pct(row.sessions ? (row.converted / row.sessions) * 100 : 0),
              ],
            }))}
          />
        </Panel>

        <Panel title="Onde a rolagem para">
          <Bars
            rows={depthBuckets(scope).map((bucket) => ({
              label: bucket.label,
              value: bucket.sessions,
              note: pct((bucket.sessions / stats.sessions) * 100),
            }))}
          />
        </Panel>
      </div>
    </>
  );
}
