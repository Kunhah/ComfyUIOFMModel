import Link from "next/link";
import { requireAdmin } from "@/lib/auth/server";
import { fmt } from "@/lib/admin/format";
import {
  byPage,
  dailySeries,
  deadClicks,
  exitPoints,
  funnel,
  health,
  overview,
  recordedPages,
} from "@/lib/analytics/db";
import { SECTION_LABEL, type Section } from "@/lib/analytics/events";
import { pageLabel } from "@/lib/analytics/pages";
import { parseScope, type Params } from "@/lib/analytics/scope";
import { Filters } from "@/components/admin/analytics/filters";
import {
  Bars,
  Broken,
  DataTable,
  NoSessions,
  Panel,
  ThinSample,
  Tile,
  Trend,
  pct,
  seconds,
} from "@/components/admin/analytics/ui";

// node:sqlite, and the counters must not be baked into the build.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const metadata = { title: "Analytics — visão geral" };

/**
 * The screen that answers "what should I change next".
 *
 * Everything else in this section is a table you arrive at with a question
 * already formed. This one exists to hand you the question: it states, in
 * sentences, the largest drop in the funnel, the thing readers click that does
 * nothing, and where they were standing when they left — and only then shows
 * the counters that size those claims.
 *
 * The ordering is deliberate and is the opposite of how dashboards are usually
 * built. Session counts sit *below* the findings, because a number at the top
 * of a screen gets read as the point, and the count of sessions is never the
 * point: it is the sample size of everything underneath it.
 */

export default async function AnalyticsOverview({
  searchParams,
}: {
  searchParams: Promise<Params>;
}) {
  await requireAdmin("/admin/analytics");

  const params = await searchParams;
  const parsed = parseScope(params);
  const { scope } = parsed;

  // Asked before anything is counted: an unwritable database and a campaign
  // that has not started look identical on this screen, and only one of them
  // is something to wait out.
  const disk = health();
  if (!disk.writable) return <Broken path={disk.path} reason={disk.reason} />;

  const recorded = new Set(recordedPages());
  const stats = overview(scope);

  if (stats.sessions === 0) {
    return (
      <>
        <Filters path="/admin/analytics" scope={parsed} recorded={recorded} />
        <NoSessions />
      </>
    );
  }

  const steps = funnel(scope);
  const worst = steps.reduce(
    (a, b) => (b.drop > a.drop ? b : a),
    steps[0] ?? { section: "hero" as Section, drop: 0, sessions: 0, share: 0 },
  );
  const dead = deadClicks(scope);
  const exits = exitPoints(scope);
  const rate = stats.sessions ? (stats.converted / stats.sessions) * 100 : 0;

  /**
   * The findings, in sentences, most actionable first.
   *
   * Built as a list rather than written into the markup so a period with
   * nothing wrong shows nothing. A dashboard that always has three complaints
   * on it teaches you to skip the complaints.
   */
  const findings: { title: string; detail: string; href?: string }[] = [];

  if (dead[0] && dead[0].sessions >= 3) {
    findings.push({
      title: `${fmt(dead[0].sessions)} sessões clicaram em algo que não faz nada`,
      detail: `O alvo mais clicado é "${dead[0].target}". Um clique morto é alguém que quis avançar no único momento em que estava disposto a agir — e a página não respondeu. É a correção mais barata desta tela.`,
      href: parsed.href("/admin/analytics/comportamento"),
    });
  }

  if (worst.drop > 10 && steps.length > 0) {
    findings.push({
      title: `${pct(worst.drop)} das sessões param antes de "${SECTION_LABEL[worst.section]}"`,
      detail:
        "A maior perda do funil. Uma queda grande entre duas faixas é um problema de texto naquele ponto — não de lance, não de oferta.",
      href: parsed.href("/admin/analytics/paginas"),
    });
  }

  if (exits[0] && exits[0].share > 25) {
    findings.push({
      title: `A maior parte das saídas acontece em "${SECTION_LABEL[exits[0].section as Section] ?? exits[0].section}"`,
      detail: `${pct(exits[0].share)} de quem saiu estava nessa faixa. Não é a mesma pergunta que o funil: quem volta ao preço e desiste ali tem funil completo e objeção no preço.`,
      href: parsed.href("/admin/analytics/comportamento"),
    });
  }

  if (stats.readAllNoCall > 0 && stats.sessions >= 30) {
    findings.push({
      title: `${fmt(stats.readAllNoCall)} leram tudo e não chamaram`,
      detail:
        "Essas pessoas se convenceram do serviço e não do preço, do prazo ou da confiança. É a objeção que falta na página, e ela não aparece em nenhuma taxa.",
    });
  }

  return (
    <>
      <h1 className="mt-4 text-3xl font-semibold tracking-tight md:text-[34px]">
        Visão geral
      </h1>
      <p className="text-fg-muted mt-2 max-w-[70ch] text-sm">
        Dados próprios, coletados pelas próprias páginas — site e landing pages.
        Sem cookie, sem IP e sem identificador que atravesse sites: a sessão
        morre com a aba. O que o Google Ads mede é o lance; o que está aqui é
        onde a página perde a pessoa.
      </p>

      <Filters path="/admin/analytics" scope={parsed} recorded={recorded} />

      {findings.length > 0 && (
        <section className="mt-8 space-y-3">
          {findings.map((finding) => (
            <div
              key={finding.title}
              className="border-line bg-surface-raised rounded-2xl border p-5"
            >
              <h2 className="text-base font-semibold">{finding.title}</h2>
              <p className="text-fg-muted mt-1.5 max-w-[80ch] text-sm">
                {finding.detail}
              </p>
              {finding.href && (
                <Link
                  href={finding.href}
                  className="text-brand mt-2 inline-block text-xs font-medium"
                >
                  Ver detalhe →
                </Link>
              )}
            </div>
          ))}
        </section>
      )}

      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Tile label="Sessões" value={fmt(stats.sessions)} />
        <Tile
          label="Contatos (ligar + WhatsApp)"
          value={fmt(stats.converted)}
          note={`${pct(rate)} de conversão`}
          highlight
        />
        <Tile
          label="Saíram na primeira tela"
          value={fmt(stats.bounced)}
          note={pct((stats.bounced / stats.sessions) * 100)}
        />
        <Tile
          label="Sessões com clique morto"
          value={fmt(stats.withDeadClicks)}
          note={`${fmt(stats.withRageClicks)} com cliques repetidos`}
          alarm={stats.withDeadClicks > 0}
        />
      </div>

      <ThinSample sessions={stats.sessions} />

      <Panel
        title="Sessões por dia"
        hint="A única coisa nesta tela que diz se uma mudança funcionou. A parte cheia de cada coluna é a fatia que chamou."
      >
        <Trend rows={dailySeries(scope)} />
      </Panel>

      {!parsed.page && (
        <Panel
          title="Por página"
          hint="Uma página com tráfego e nenhum contato é dinheiro identificado; uma sem tráfego nenhum é problema de distribuição, não de texto."
        >
          <DataTable
            columns={[
              { head: "Página" },
              { head: "Sessões", numeric: true },
              { head: "Contatos", numeric: true },
              { head: "Taxa", numeric: true },
            ]}
            rows={byPage(scope).map((row) => ({
              key: row.label,
              dim: row.sessions < 30,
              cells: [
                pageLabel(row.label),
                fmt(row.sessions),
                fmt(row.converted),
                pct(row.rate),
              ],
            }))}
          />
        </Panel>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel
          title="Até onde leem"
          hint={
            steps.length === 0
              ? "Escolha uma página ou um tipo acima: um funil sobre páginas de estruturas diferentes somaria faixas que não são a mesma coisa."
              : worst.drop > 0
                ? `Maior perda: ${pct(worst.drop)} param antes de "${SECTION_LABEL[worst.section]}".`
                : undefined
          }
        >
          <Bars
            rows={steps.map((step) => ({
              label: SECTION_LABEL[step.section],
              value: step.sessions,
              note: `${pct(step.share)}${step.drop > 0.5 ? ` · −${pct(step.drop)}` : ""}`,
              fill: Math.min(step.share, 100),
            }))}
          />
        </Panel>

        <Panel
          title="Tempo e ritmo"
          hint="Medianas, nunca médias: uma aba esquecida aberta no almoço move a média em minutos e a mediana em nada."
        >
          <div className="grid gap-3 sm:grid-cols-2">
            <Tile
              label="Tempo na página"
              value={seconds(stats.medianEngagedMs)}
              note={`rolagem ${stats.medianDepth ?? 0}%`}
            />
            <Tile
              label="Até o primeiro toque"
              value={seconds(stats.medianFirstActionMs)}
              note="de quem converteu"
            />
            <Tile
              label="Até a primeira rolagem"
              value={seconds(stats.medianFirstScrollMs)}
              note="abaixo de 1s é primeira tela pulada"
            />
            <Tile
              label="Leram tudo e não chamaram"
              value={fmt(stats.readAllNoCall)}
              note="chegaram ao fim sem tocar em nada"
            />
          </div>
        </Panel>
      </div>
    </>
  );
}
