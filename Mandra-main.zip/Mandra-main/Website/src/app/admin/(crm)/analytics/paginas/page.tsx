import { requireAdmin } from "@/lib/auth/server";
import { fmt } from "@/lib/admin/format";
import {
  byPage,
  byPlacement,
  depthBuckets,
  dwell,
  faqOpens,
  funnel,
  health,
  overview,
  recordedPages,
} from "@/lib/analytics/db";
import {
  PLACEMENT_LABEL,
  SECTION_LABEL,
  type Section,
} from "@/lib/analytics/events";
import { pageLabel } from "@/lib/analytics/pages";
import { parseScope, type Params } from "@/lib/analytics/scope";
import { Filters } from "@/components/admin/analytics/filters";
import {
  Bars,
  Broken,
  DataTable,
  Empty,
  NoSessions,
  Panel,
  ThinSample,
  pct,
  seconds,
} from "@/components/admin/analytics/ui";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const metadata = { title: "Analytics — páginas" };

const PATH = "/admin/analytics/paginas";

/**
 * Where each page loses the reader.
 *
 * The funnel is the block this whole layer was built for, and it now has to
 * cope with two page structures rather than one: the landing pages have six
 * bands and the home page eight. A funnel drawn over a scope containing both
 * would add bands that are not the same thing, so this screen refuses to draw
 * one until the scope names a page or a type — and says so, rather than
 * rendering an empty chart that looks like missing data.
 *
 * `dwell` sits directly under the funnel on purpose. The funnel counts a band
 * as reached when a third of it crosses the viewport, which is right for "did
 * they get there" and says nothing about "did they read it" — and a band
 * everyone reaches and nobody spends four seconds in reads on the funnel as a
 * step with no drop, which is to say a success.
 */
export default async function PagesScreen({
  searchParams,
}: {
  searchParams: Promise<Params>;
}) {
  await requireAdmin("/admin/analytics");

  const parsed = parseScope(await searchParams);
  const { scope } = parsed;

  const disk = health();
  if (!disk.writable) return <Broken path={disk.path} reason={disk.reason} />;

  const recorded = new Set(recordedPages());
  const stats = overview(scope);

  if (stats.sessions === 0) {
    return (
      <>
        <Filters path={PATH} scope={parsed} recorded={recorded} />
        <NoSessions />
      </>
    );
  }

  const steps = funnel(scope);
  const worst = steps.reduce(
    (a, b) => (b.drop > a.drop ? b : a),
    steps[0] ?? { section: "hero" as Section, drop: 0, sessions: 0, share: 0 },
  );
  const held = dwell(scope);
  const dwellBySection = new Map(held.map((row) => [row.section, row]));

  return (
    <>
      <h1 className="mt-4 text-3xl font-semibold tracking-tight md:text-[34px]">
        Páginas
      </h1>
      <p className="text-fg-muted mt-2 max-w-[70ch] text-sm">
        Até onde as pessoas leem, quanto tempo cada faixa as segura e qual botão
        é de fato usado. Uma queda grande entre duas faixas é um problema de
        texto naquele ponto.
      </p>

      <Filters path={PATH} scope={parsed} recorded={recorded} />
      <ThinSample sessions={stats.sessions} />

      <Panel
        title="Até onde as pessoas leem"
        hint={
          steps.length === 0
            ? undefined
            : worst.drop > 0
              ? `Maior perda: ${pct(worst.drop)} das sessões param antes de "${SECTION_LABEL[worst.section]}".`
              : undefined
        }
      >
        {steps.length === 0 ? (
          <Empty>
            Escolha uma página, ou o tipo &quot;Site&quot; ou &quot;Landing
            pages&quot;, acima. As duas estruturas têm faixas diferentes, e um
            funil somando as duas mostraria degraus que não existem em página
            nenhuma.
          </Empty>
        ) : (
          <DataTable
            columns={[
              { head: "Faixa" },
              { head: "Chegaram", numeric: true },
              { head: "Do total", numeric: true },
              { head: "Perda", numeric: true },
              { head: "Tempo mediano", numeric: true },
            ]}
            rows={steps.map((step) => {
              const time = dwellBySection.get(step.section);
              return {
                key: step.section,
                cells: [
                  SECTION_LABEL[step.section],
                  fmt(step.sessions),
                  pct(step.share),
                  step.drop > 0.5 ? `−${pct(step.drop)}` : "—",
                  seconds(time?.medianMs ?? null),
                ],
              };
            })}
          />
        )}
      </Panel>

      {steps.length > 0 && (
        <Panel
          title="Quanto tempo cada faixa segura"
          hint="A faixa que todo mundo alcança e ninguém lê é a que o funil mostra como um degrau sem perda — ou seja, como um acerto."
        >
          <Bars
            rows={steps
              .map((step) => {
                const time = dwellBySection.get(step.section);
                return {
                  label: SECTION_LABEL[step.section],
                  value: time?.medianMs ?? 0,
                  hideValue: true,
                  note: seconds(time?.medianMs ?? null),
                  // Under four seconds a band is being scrolled past, not read.
                  warn: (time?.medianMs ?? 0) > 0 && (time?.medianMs ?? 0) < 4000,
                };
              })
              .filter((row) => row.value > 0)}
          />
        </Panel>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title="Qual botão é usado">
          <DataTable
            columns={[
              { head: "Posição" },
              { head: "Ligar", numeric: true },
              { head: "WhatsApp", numeric: true },
            ]}
            rows={byPlacement(scope).map((row) => ({
              key: row.placement,
              cells: [
                PLACEMENT_LABEL[
                  row.placement as keyof typeof PLACEMENT_LABEL
                ] ?? row.placement,
                fmt(row.call),
                fmt(row.whatsapp),
              ],
            }))}
          />
        </Panel>

        <Panel
          title="Onde a rolagem para"
          hint="Uma página em que quase ninguém passa dos 50% é longa demais ou perde o argumento no meio."
        >
          <Bars
            rows={depthBuckets(scope).map((bucket) => ({
              label: bucket.label,
              value: bucket.sessions,
              note: pct((bucket.sessions / stats.sessions) * 100),
            }))}
          />
        </Panel>
      </div>

      <Panel
        title="Perguntas que as pessoas abrem"
        hint="Uma pergunta aberta por boa parte dos leitores é a objeção que a página não respondeu antes — ela pertence ao texto, não ao fim, atrás de um triângulo."
      >
        <DataTable
          columns={[
            { head: "Pergunta" },
            { head: "Sessões", numeric: true },
            { head: "Aberturas", numeric: true },
          ]}
          rows={faqOpens(scope).map((row) => ({
            key: row.question,
            cells: [row.question, fmt(row.sessions), fmt(row.opens)],
          }))}
        />
      </Panel>

      {!parsed.page && (
        <Panel title="Comparativo entre páginas">
          <DataTable
            columns={[
              { head: "Página" },
              { head: "Sessões", numeric: true },
              { head: "Contatos", numeric: true },
              { head: "Taxa", numeric: true },
            ]}
            rows={byPage(scope).map((row) => ({
              key: row.label,
              dim: row.sessions < 30,
              cells: [
                pageLabel(row.label),
                fmt(row.sessions),
                fmt(row.converted),
                pct(row.rate),
              ],
            }))}
          />
        </Panel>
      )}
    </>
  );
}
