import { requireAdmin } from "@/lib/auth/server";
import { fmt } from "@/lib/admin/format";
import {
  inboundByHour,
  replyTime,
  whatsappDaily,
  whatsappHealth,
  whatsappOverview,
} from "@/lib/analytics/whatsapp";
import { PERIODS, type Params } from "@/lib/analytics/scope";
import {
  Bars,
  Chip,
  DataTable,
  Empty,
  Panel,
  Tile,
  pct,
  seconds,
} from "@/components/admin/analytics/ui";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const metadata = { title: "Analytics — WhatsApp" };

const PATH = "/admin/analytics/whatsapp";

/**
 * Whether the agent is working, as opposed to whether it is running.
 *
 * `/admin/whatsapp` already answers "is it connected" and "what did it say to
 * this person". Neither of those is the question here. An agent that replies
 * to everything in four seconds and never produces a single appointment is a
 * very responsive dead end, and reading it one thread at a time is exactly how
 * that goes unnoticed for a month.
 *
 * The counter that earns the screen is "sem resposta". A median reply time is
 * computed only over messages that *were* answered, so a thread the agent
 * silently dropped contributes nothing to it — the failure is invisible in the
 * very statistic meant to catch it, unless the dropped ones are counted
 * separately. They are, and they sit next to it.
 */
export default async function WhatsappAnalytics({
  searchParams,
}: {
  searchParams: Promise<Params>;
}) {
  await requireAdmin("/admin/analytics");

  const params = await searchParams;
  const raw = Array.isArray(params.dias) ? params.dias[0] : params.dias;
  const days = PERIODS.some((period) => String(period.days) === raw)
    ? Number(raw)
    : 30;
  const scope = { days };

  const disk = whatsappHealth();
  if (!disk.ok) {
    return (
      <div className="border-brand/40 bg-brand/5 mt-8 rounded-2xl border p-6">
        <h2 className="text-base font-semibold">
          As tabelas do WhatsApp não puderam ser lidas
        </h2>
        <p className="text-fg-muted mt-2 max-w-[70ch] text-sm">
          Uma tela zerada aqui seria indistinguível de &quot;ninguém escreveu&quot;.
        </p>
        {disk.reason && (
          <p className="text-fg-subtle mt-3 font-mono text-xs">{disk.reason}</p>
        )}
      </div>
    );
  }

  const stats = whatsappOverview(scope);
  const reply = replyTime(scope);
  const series = whatsappDaily(scope);
  const hours = inboundByHour(scope);

  const total = reply.answered + reply.unanswered;
  const dropRate = total ? (reply.unanswered / total) * 100 : 0;
  const bookRate = stats.active
    ? (stats.appointments / stats.active) * 100
    : 0;

  return (
    <>
      <h1 className="mt-4 text-3xl font-semibold tracking-tight md:text-[34px]">
        WhatsApp
      </h1>
      <p className="text-fg-muted mt-2 max-w-[70ch] text-sm">
        Se o agente está funcionando, não se está rodando. A tela de atendimento
        mostra a conexão e cada conversa; esta mostra se as conversas terminam
        em alguma coisa.
      </p>

      <div className="mt-6 flex flex-wrap items-center gap-2">
        {PERIODS.map((period) => (
          <Chip
            key={period.days}
            href={`${PATH}?dias=${period.days}`}
            active={period.days === days}
          >
            {period.label}
          </Chip>
        ))}
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Tile
          label="Conversas ativas"
          value={fmt(stats.active)}
          note={`${fmt(stats.conversations)} abertas no período`}
        />
        <Tile
          label="Mensagens recebidas"
          value={fmt(stats.inbound)}
          note={`${fmt(stats.outbound)} enviadas`}
        />
        <Tile
          label="Tempo de resposta"
          value={
            reply.medianSeconds === null
              ? "—"
              : seconds(reply.medianSeconds * 1000)
          }
          note="mediana, só de quem foi respondido"
        />
        <Tile
          label="Sem resposta"
          value={fmt(reply.unanswered)}
          note={`${pct(dropRate)} das perguntas — não entram na mediana ao lado`}
          alarm={reply.unanswered > 0}
        />
      </div>

      <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Tile
          label="Agendamentos"
          value={fmt(stats.appointments)}
          note={`${pct(bookRate)} das conversas ativas`}
          highlight
        />
        <Tile
          label="Confirmados ou concluídos"
          value={fmt(stats.appointmentsKept)}
          note={
            stats.appointments
              ? `${pct((stats.appointmentsKept / stats.appointments) * 100)} dos agendados`
              : undefined
          }
        />
        <Tile
          label="Envios que falharam"
          value={fmt(stats.failed)}
          note="o provedor recusou a mensagem"
          alarm={stats.failed > 0}
        />
        <Tile
          label="Assumidas por humano"
          value={fmt(stats.handedOff)}
          note={`agora · ${fmt(stats.activeJobs)} lembretes ativos`}
        />
      </div>

      <Panel
        title="Quem respondeu"
        hint="Uma fatia grande de operador não é um defeito — é a medida de quanto trabalho o agente ainda não tira de ninguém."
      >
        <Bars
          rows={[
            { label: "Agente", value: stats.fromAgent },
            { label: "Operador", value: stats.fromOperator },
            { label: "Lembrete automático", value: stats.fromJob },
          ].filter((row) => row.value > 0)}
        />
      </Panel>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel
          title="Quando os clientes escrevem"
          hint="O agente atende a qualquer hora, que é boa parte do motivo de existir. Isto diz quando um humano precisa estar acessível para o que ele passa adiante."
        >
          <Bars
            rows={hours.map((row) => ({
              label: `${String(row.hour).padStart(2, "0")}h`,
              value: row.messages,
            }))}
          />
        </Panel>

        <Panel title="Mensagens por dia">
          {series.length === 0 ? (
            <Empty>Sem mensagens no período.</Empty>
          ) : (
            <DataTable
              columns={[
                { head: "Dia" },
                { head: "Recebidas", numeric: true },
                { head: "Enviadas", numeric: true },
              ]}
              rows={series.map((row) => ({
                key: row.day,
                cells: [row.day, fmt(row.inbound), fmt(row.outbound)],
              }))}
            />
          )}
        </Panel>
      </div>
    </>
  );
}
