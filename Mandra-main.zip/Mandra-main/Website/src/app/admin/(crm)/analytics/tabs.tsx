"use client";

import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";

/**
 * The tabs across the analytics section.
 *
 * Six screens rather than one long page, because they answer six different
 * questions and a reader scrolling past four blocks they did not want is a
 * reader who stops opening the screen. The split is by *question*, not by data
 * source — "where do we lose them" and "where does the traffic come from" are
 * two decisions even though they read the same table.
 *
 * The current query string rides along on every tab. Picking a period and a
 * page and then losing both by switching tabs is the fastest way to make a
 * dashboard annoying enough to go unused.
 */

const TABS = [
  { href: "/admin/analytics", label: "Visão geral", exact: true },
  { href: "/admin/analytics/paginas", label: "Páginas" },
  { href: "/admin/analytics/comportamento", label: "Comportamento" },
  { href: "/admin/analytics/aquisicao", label: "Aquisição" },
  { href: "/admin/analytics/comercial", label: "Comercial" },
  { href: "/admin/analytics/whatsapp", label: "WhatsApp" },
];

export function AnalyticsTabs() {
  const pathname = usePathname();
  // Read here rather than passed down from a page: this lives in the section
  // layout, and a layout in the App Router is never handed `searchParams`.
  const query = useSearchParams().toString();

  return (
    <nav className="border-line mt-5 flex gap-1 overflow-x-auto border-b pb-px">
      {TABS.map((tab) => {
        const active = tab.exact
          ? pathname === tab.href
          : pathname.startsWith(tab.href);
        return (
          <Link
            key={tab.href}
            href={query ? `${tab.href}?${query}` : tab.href}
            aria-current={active ? "page" : undefined}
            className={`shrink-0 rounded-t-lg px-3.5 py-2.5 text-sm font-medium whitespace-nowrap transition ${
              active
                ? "text-fg border-brand border-b-2"
                : "text-fg-muted hover:text-fg border-b-2 border-transparent"
            }`}
          >
            {tab.label}
          </Link>
        );
      })}
    </nav>
  );
}
