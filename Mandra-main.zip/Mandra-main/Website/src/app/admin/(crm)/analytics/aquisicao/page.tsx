import { requireAdmin } from "@/lib/auth/server";
import { fmt } from "@/lib/admin/format";
import {
  byAdGroup,
  byCampaign,
  byDevice,
  byHour,
  byMatchType,
  byReferrer,
  bySource,
  byTerm,
  byWeekday,
  dailySeries,
  health,
  overview,
  recordedPages,
  untaggedPaid,
  type Breakdown,
} from "@/lib/analytics/db";
import { FINAL_URL_SUFFIX, FINAL_URL_SUFFIX_PATH } from "@/lib/analytics/tagging";
import { parseScope, type Params } from "@/lib/analytics/scope";
import { Filters } from "@/components/admin/analytics/filters";
import {
  Bars,
  Broken,
  DataTable,
  NoSessions,
  Panel,
  ThinSample,
  Tile,
  Trend,
  pct,
} from "@/components/admin/analytics/ui";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const metadata = { title: "Analytics — aquisição" };

const PATH = "/admin/analytics/aquisicao";

const WEEKDAYS = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];

/**
 * Where the traffic comes from, and when.
 *
 * Read this screen *after* the other two, not before. A keyword table invites
 * moving money around, and moving money around a page that loses two thirds of
 * its readers at the same band just buys the same loss at a different price.
 * The order in `docs/analytics.md` is deliberate: fix the page, then the bid.
 *
 * The referrer table only became worth having when the site's own pages
 * started being measured. A landing page is reached from an ad and its
 * referrer column is a list of one; the home page is reached from search, from
 * a directory, from somebody's WhatsApp — and that is the only description
 * anywhere of the half of the business nobody is paying for.
 */
export default async function AcquisitionScreen({
  searchParams,
}: {
  searchParams: Promise<Params>;
}) {
  await requireAdmin("/admin/analytics");

  const parsed = parseScope(await searchParams);
  const { scope } = parsed;

  const disk = health();
  if (!disk.writable) return <Broken path={disk.path} reason={disk.reason} />;

  const recorded = new Set(recordedPages());
  const stats = overview(scope);

  if (stats.sessions === 0) {
    return (
      <>
        <Filters path={PATH} scope={parsed} recorded={recorded} />
        <NoSessions />
      </>
    );
  }

  const untagged = untaggedPaid(scope);
  const hours = byHour(scope);
  const peak = hours.reduce((a, b) => (b.sessions > a.sessions ? b : a), hours[0]);

  const table = (rows: Breakdown[]) =>
    rows.map((row) => ({
      key: row.label,
      dim: row.sessions < 30,
      cells: [
        row.label,
        fmt(row.sessions),
        fmt(row.converted),
        pct(row.rate),
      ],
    }));

  const COLUMNS = [
    { head: "—" },
    { head: "Sessões", numeric: true },
    { head: "Contatos", numeric: true },
    { head: "Taxa", numeric: true },
  ];

  return (
    <>
      <h1 className="mt-4 text-3xl font-semibold tracking-tight md:text-[34px]">
        Aquisição
      </h1>
      <p className="text-fg-muted mt-2 max-w-[70ch] text-sm">
        De onde vem o tráfego e em que horário. Leia esta tela depois das
        outras: mexer em lance numa página que perde dois terços dos leitores na
        mesma faixa só compra a mesma perda por outro preço.
      </p>

      <Filters path={PATH} scope={parsed} recorded={recorded} />
      <ThinSample sessions={stats.sessions} />

      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Tile label="Sessões" value={fmt(stats.sessions)} />
        <Tile
          label="Tráfego pago"
          value={fmt(stats.paid)}
          note={pct((stats.paid / stats.sessions) * 100)}
        />
        <Tile
          label="Pago sem palavra-chave"
          value={fmt(untagged)}
          note={untagged > 0 ? "dinheiro anônimo — marque a campanha" : "tudo marcado"}
          alarm={untagged > 0}
        />
        <Tile
          label="Horário de pico"
          value={peak ? `${String(peak.hour).padStart(2, "0")}h` : "—"}
          note={peak ? `${fmt(peak.sessions)} sessões` : undefined}
        />
      </div>

      {untagged > 0 && (
        <div className="border-brand/40 bg-brand/5 mt-4 rounded-2xl border p-5">
          <h2 className="text-base font-semibold">
            {fmt(untagged)} sessões pagas chegaram sem dizer qual busca as
            trouxe
          </h2>
          <p className="text-fg-muted mt-2 max-w-[75ch] text-sm">
            O Google acrescenta o <code className="text-fg">gclid</code> sozinho,
            então a sessão conta como paga — mas a palavra-chave não vem se a
            conta não a escrever na URL. Sem ela a tabela abaixo mostra
            &quot;(sem termo)&quot; para todo mundo e não há como saber qual
            busca gastou o orçamento. É uma colagem só, uma vez, em{" "}
            <span className="text-fg">{FINAL_URL_SUFFIX_PATH}</span>:
          </p>
          <pre className="border-line bg-surface mt-3 overflow-x-auto rounded-xl border p-3 font-mono text-xs">
            {FINAL_URL_SUFFIX}
          </pre>
        </div>
      )}

      <Panel title="Sessões por dia">
        <Trend rows={dailySeries(scope)} />
      </Panel>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel
          title="Por horário"
          hint="Serve para duas decisões: a programação do anúncio e quem está ao lado do telefone. Uma página cuja conversão é um tel: converte muito pior às 22h por um motivo que não é a página."
        >
          <Bars
            rows={hours.map((row) => ({
              label: `${String(row.hour).padStart(2, "0")}h`,
              value: row.sessions,
              note: row.converted > 0 ? `${fmt(row.converted)} contatos` : undefined,
            }))}
          />
        </Panel>

        <Panel title="Por dia da semana">
          <Bars
            rows={byWeekday(scope).map((row) => ({
              label: WEEKDAYS[row.weekday] ?? String(row.weekday),
              value: row.sessions,
              note: row.converted > 0 ? `${fmt(row.converted)} contatos` : undefined,
            }))}
          />
        </Panel>

        <Panel
          title="Por palavra-chave (utm_term)"
          hint="A coluna que transforma “a página converte a 8%” em “esta palavra converte a zero e já gastou”. Uma palavra com trinta sessões e nenhum contato é dinheiro identificado."
        >
          <DataTable columns={COLUMNS} rows={table(byTerm(scope))} />
        </Panel>

        <Panel
          title="Por tipo de correspondência"
          hint="É aqui que a correspondência ampla aparece gastando com buscas que ninguém escolheu."
        >
          <DataTable columns={COLUMNS} rows={table(byMatchType(scope))} />
        </Panel>

        <Panel title="Por campanha">
          <DataTable columns={COLUMNS} rows={table(byCampaign(scope))} />
        </Panel>

        <Panel title="Por grupo de anúncios">
          <DataTable columns={COLUMNS} rows={table(byAdGroup(scope))} />
        </Panel>

        <Panel
          title="Por origem"
          hint="utm_source quando a URL traz um; “direto / orgânico” para quem digitou o endereço ou veio de um lugar que não se identifica."
        >
          <DataTable columns={COLUMNS} rows={table(bySource(scope))} />
        </Panel>

        <Panel
          title="Por site de origem"
          hint="Só o host, nunca a URL inteira. Passou a valer alguma coisa quando o site próprio começou a se medir: uma landing page vem de um anúncio e só dele; a home vem de busca, de diretório e do WhatsApp de alguém."
        >
          <DataTable columns={COLUMNS} rows={table(byReferrer(scope))} />
        </Panel>

        <Panel
          title="Por dispositivo"
          hint="Celular convertendo muito abaixo do desktop quase sempre é a primeira tela, não a oferta. A largura exata está em Comportamento."
        >
          <DataTable columns={COLUMNS} rows={table(byDevice(scope))} />
        </Panel>
      </div>
    </>
  );
}
