import { requireAdmin } from "@/lib/auth/server";
import { fmt } from "@/lib/admin/format";
import {
  byNiche,
  byStage,
  callOutcomes,
  commercialDaily,
  commercialHealth,
  commercialOverview,
} from "@/lib/analytics/commercial";
import { CALL_OUTCOME_LABEL, FUNNEL_LABEL } from "@/lib/prospector/types";
import { PERIODS, type Params } from "@/lib/analytics/scope";
import {
  Bars,
  Chip,
  DataTable,
  Empty,
  Panel,
  Tile,
  pct,
} from "@/components/admin/analytics/ui";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const metadata = { title: "Analytics — comercial" };

const PATH = "/admin/analytics/comercial";

/**
 * What happens after somebody taps the phone number.
 *
 * The page analytics stop at the tap, because that is the last thing a browser
 * can witness — and the entire business happens afterwards. A landing page
 * converting at 9% into calls nobody ever reaches is a worse outcome than one
 * converting at 4% into calls that close, and until this screen existed no
 * view in the app could state that.
 *
 * It reads `prospector.db` rather than `analytics.db`. The two are not joined
 * and deliberately so: the page session is anonymous by construction and a
 * lead is a named business with a phone number, so a join would be the one
 * thing this whole layer is built not to do. What is shared is the period, so
 * the two halves describe the same weeks.
 */
export default async function CommercialScreen({
  searchParams,
}: {
  searchParams: Promise<Params>;
}) {
  await requireAdmin("/admin/analytics");

  const params = await searchParams;
  const raw = Array.isArray(params.dias) ? params.dias[0] : params.dias;
  const days = PERIODS.some((period) => String(period.days) === raw)
    ? Number(raw)
    : 30;
  const scope = { days };

  const disk = commercialHealth();
  if (!disk.ok) {
    return (
      <div className="border-brand/40 bg-brand/5 mt-8 rounded-2xl border p-6">
        <h2 className="text-base font-semibold">
          O banco do CRM não pôde ser lido
        </h2>
        <p className="text-fg-muted mt-2 max-w-[70ch] text-sm">
          Esta tela lê <code className="text-fg">data/prospector.db</code>. Uma
          tela zerada aqui seria indistinguível de &quot;ninguém ligou para
          ninguém&quot;, então ela prefere dizer o que houve.
        </p>
        {disk.reason && (
          <p className="text-fg-subtle mt-3 font-mono text-xs">{disk.reason}</p>
        )}
      </div>
    );
  }

  const stats = commercialOverview(scope);
  const stages = byStage();
  const outcomes = callOutcomes(scope);
  const niches = byNiche(scope);
  const series = commercialDaily(scope);

  const reachRate = stats.called ? (stats.reached / stats.called) * 100 : 0;
  const interestRate = stats.reached
    ? (stats.interested / stats.reached) * 100
    : 0;
  const callRate = stats.found ? (stats.called / stats.found) * 100 : 0;

  return (
    <>
      <h1 className="mt-4 text-3xl font-semibold tracking-tight md:text-[34px]">
        Comercial
      </h1>
      <p className="text-fg-muted mt-2 max-w-[70ch] text-sm">
        O que acontece depois do toque no telefone. As outras telas param no
        clique, porque é a última coisa que um navegador vê — e o negócio
        inteiro acontece depois dele.
      </p>

      <div className="mt-6 flex flex-wrap items-center gap-2">
        {PERIODS.map((period) => (
          <Chip
            key={period.days}
            href={`${PATH}?dias=${period.days}`}
            active={period.days === days}
          >
            {period.label}
          </Chip>
        ))}
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Tile
          label="Leads encontrados"
          value={fmt(stats.found)}
          note={`${fmt(stats.searches)} buscas no período`}
        />
        <Tile
          label="Leads ligados"
          value={fmt(stats.called)}
          note={`${pct(callRate)} dos encontrados · ${fmt(stats.dials)} ligações`}
        />
        <Tile
          label="Falou com alguém"
          value={fmt(stats.reached)}
          note={`${pct(reachRate)} de quem foi ligado`}
          highlight
        />
        <Tile
          label="Interessados"
          value={fmt(stats.interested)}
          note={`${pct(interestRate)} de quem atendeu`}
        />
      </div>

      <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Tile label="Fechados" value={fmt(stats.won)} highlight />
        <Tile label="Perdidos" value={fmt(stats.lost)} />
        <Tile
          label="Ligações por lead"
          value={
            stats.called ? (stats.dials / stats.called).toFixed(1).replace(".", ",") : "—"
          }
          note="mais de duas e a lista está sendo repicada"
        />
        <Tile
          label="Encontrados sem ligação"
          value={fmt(Math.max(stats.found - stats.called, 0))}
          note="lista construída e não trabalhada"
          alarm={stats.found - stats.called > stats.called}
        />
      </div>

      <Panel
        title="Leads encontrados e ligações por dia"
        hint="Construir lista e trabalhar lista são duas atividades. Quando as duas colunas se descolam por vários dias, uma delas parou."
      >
        {series.length === 0 ? (
          <Empty>Sem atividade no período.</Empty>
        ) : (
          <DataTable
            columns={[
              { head: "Dia" },
              { head: "Leads encontrados", numeric: true },
              { head: "Ligações", numeric: true },
            ]}
            rows={series.map((row) => ({
              key: row.day,
              cells: [row.day, fmt(row.leads), fmt(row.calls)],
            }))}
          />
        )}
      </Panel>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel
          title="Pipeline agora"
          hint="Uma fotografia, não um recorte do período: um lead encontrado há quatro meses e ainda em negociação faz parte do pipeline de hoje."
        >
          <Bars
            rows={stages.map((row) => ({
              label: FUNNEL_LABEL[row.stage],
              value: row.leads,
              note: pct(row.share),
              warn: row.stage === "perdido",
            }))}
          />
        </Panel>

        <Panel
          title="O que acontece ao discar"
          hint="As três primeiras linhas são conversas; as outras são tentativas. Uma lista em que a maior parte é “não atendeu” é um problema de horário ou de número, não de discurso."
        >
          <Bars
            rows={outcomes
              .filter((row) => row.calls > 0)
              .map((row) => ({
                label: CALL_OUTCOME_LABEL[row.outcome],
                value: row.calls,
                note: pct(row.share),
                warn: !row.reached,
              }))}
          />
        </Panel>
      </div>

      <Panel
        title="Por nicho"
        hint="A decisão que esta tela existe para informar. Um nicho com noventa leads, sessenta ligações e nenhuma conversa é uma lista que deveria parar de ser construída."
      >
        <DataTable
          columns={[
            { head: "Nicho" },
            { head: "Leads", numeric: true },
            { head: "Ligados", numeric: true },
            { head: "Atenderam", numeric: true },
            { head: "Fechados", numeric: true },
            { head: "Atendimento", numeric: true },
          ]}
          rows={niches.map((row) => ({
            key: row.niche,
            dim: row.called < 10,
            cells: [
              row.niche,
              fmt(row.leads),
              fmt(row.called),
              fmt(row.reached),
              fmt(row.won),
              pct(row.called ? (row.reached / row.called) * 100 : 0),
            ],
          }))}
        />
      </Panel>
    </>
  );
}
