import { Suspense } from "react";
import { requireAdmin } from "@/lib/auth/server";
import { AnalyticsTabs } from "./tabs";

/**
 * The analytics section's shell: one heading, one set of tabs.
 *
 * `requireAdmin` here is for the chrome, not for security — a layout does not
 * re-run on a client navigation, so every page under it repeats the check, the
 * same rule the CRM shell above it follows.
 */
export const metadata = { title: "Analytics" };

export default async function AnalyticsLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  await requireAdmin("/admin/analytics");

  return (
    <main className="mx-auto w-full max-w-[1200px] flex-1 px-5 py-8 md:px-8">
      <p className="text-brand text-xs font-semibold tracking-[0.16em]">
        ANALYTICS
      </p>
      {/* `useSearchParams` needs a boundary to fall back to while the router
          resolves; without one, Next refuses to render the whole subtree. */}
      <Suspense fallback={<div className="border-line mt-5 h-12 border-b" />}>
        <AnalyticsTabs />
      </Suspense>
      {children}
    </main>
  );
}
