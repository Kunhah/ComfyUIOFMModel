import { ShieldCheck } from "lucide-react";
import { UserManager } from "@/components/admin/user-manager";
import { adminAccount, requireAdmin } from "@/lib/auth/server";
import { probablySignedIn } from "@/lib/admin/operators";
import { listUsers } from "@/lib/auth/users";

/**
 * Who can get in.
 *
 * There are exactly two kinds of account and they live in different places on
 * purpose. The administrator is `MANDRA_ADMIN_USER` / `MANDRA_ADMIN_PASSWORD`
 * in the environment: it has to exist before the database does, and an account
 * that hands out access shouldn't be something a write to the database can
 * create. Everyone else is a row this page adds and takes away.
 */

export const dynamic = "force-dynamic";
export const metadata = { title: "Acessos" };

export default async function UsersPage() {
  const admin = await requireAdmin("/admin/usuarios");
  const account = adminAccount();
  const users = listUsers();

  return (
    <main className="mx-auto w-full max-w-[1100px] flex-1 px-5 py-8 md:px-8">
      <p className="text-brand text-xs font-semibold tracking-[0.16em]">
        ADMINISTRAÇÃO
      </p>
      <h1 className="mt-1.5 text-3xl font-semibold tracking-tight md:text-[34px]">
        Acessos
      </h1>
      <p className="text-fg-muted mt-2 text-sm">
        Quem pode entrar no CRM e no prospector. Revogar derruba as sessões
        abertas na hora.
      </p>

      <div className="border-line bg-surface mt-6 flex flex-wrap items-center gap-3 rounded-2xl border px-5 py-4">
        <span className="bg-brand/10 text-brand flex size-10 shrink-0 items-center justify-center rounded-xl">
          <ShieldCheck className="size-5" />
        </span>
        <div className="min-w-0">
          <p className="text-sm font-medium">
            Administrador: {account?.username ?? "não configurado"}
            {admin.username === account?.username && (
              <span className="text-fg-subtle font-normal"> (você)</span>
            )}
          </p>
          <p className="text-fg-muted mt-0.5 text-sm">
            Vem das variáveis <code className="text-xs">MANDRA_ADMIN_USER</code>{" "}
            e <code className="text-xs">MANDRA_ADMIN_PASSWORD</code>. Para
            trocá-lo, edite o ambiente e reinicie — não há como fazer isso por
            aqui, e é essa a intenção.
          </p>
        </div>
      </div>

      <UserManager
        users={users.map((user) => ({
          id: user.id,
          username: user.username,
          displayName: user.displayName,
          active: user.active,
          permissions: user.permissions,
          createdAt: user.createdAt,
          createdBy: user.createdBy,
          lastLoginAt: user.lastLoginAt,
          signedIn: probablySignedIn(user),
        }))}
      />
    </main>
  );
}
