import { AccountManager } from "@/components/admin/account-manager";
import { requireAdmin } from "@/lib/auth/server";
import { accountSummaries } from "@/lib/crm/accounts";

export const metadata = { title: "Contas de cliente" };
export const dynamic = "force-dynamic";

/**
 * The client accounts.
 *
 * Admin-only, and it re-checks rather than trusting the nav or the matcher —
 * the same rule every other page here follows. This screen hands out access to
 * a pipeline, which is a different kind of act from working a lead.
 *
 * `force-dynamic` because every number on it comes from SQLite at request time;
 * prerendering would bake the counters into the build and report zero forever,
 * exactly as it would for /prospector/b2b.
 */
export default async function ContasPage() {
  await requireAdmin("/admin/contas");
  const accounts = accountSummaries();

  return (
    <main className="bg-bg text-fg min-w-0 flex-1 px-5 py-8 md:px-8">
      <header className="mb-7">
        <h1 className="text-2xl font-semibold">Contas de cliente</h1>
        <p className="text-fg-muted mt-1.5 max-w-2xl text-sm leading-6">
          Cada conta é um cliente com site nosso. Os contatos que o formulário
          dele recebe ficam na conta, e o acesso que você criar aqui abre o
          portal em <code className="text-fg">/app</code> — só com os leads
          daquela conta.
        </p>
      </header>

      <AccountManager accounts={accounts} />
    </main>
  );
}
