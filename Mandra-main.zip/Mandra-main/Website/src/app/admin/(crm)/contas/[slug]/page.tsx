import { headers } from "next/headers";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  Download,
  ExternalLink,
  Globe,
  KeyRound,
} from "lucide-react";
import { CopyBlock } from "@/components/admin/client-kit";
import { WhatsappConnect } from "@/components/admin/whatsapp-connect";
import { requireAdmin } from "@/lib/auth/server";
import { findAccountBySlug } from "@/lib/crm/accounts";
import { listAccountSites } from "@/lib/crm/sites";
import { listAccountUsers } from "@/lib/auth/users";
import { clientClaudeMd } from "@/lib/crm/claude-md";
import { whatsappConfigured } from "@/lib/whatsapp/evolution";

export const dynamic = "force-dynamic";

/**
 * Everything needed to wire a new client repository to this account.
 *
 * We build each client's site in its own repository, on whatever host suits it,
 * so there is no shared package to depend on and no build step we control. The
 * integration is therefore deliberately three things a person can paste into
 * any stack: a script tag, two environment variables and one HTTP call.
 *
 * The page exists because the alternative — reading a key off /admin/sites,
 * remembering the endpoint, and retyping the payload from memory — is where the
 * mistakes happen, and every one of them fails silently: a form that posts
 * nowhere looks exactly like a form nobody has filled in.
 */

/**
 * The origin this CRM answers on, from the request rather than from an env var.
 *
 * The snippet names an absolute URL because it is pasted into somebody else's
 * site, and a value guessed in the browser would print `localhost` into an
 * instruction meant for production. Same reasoning as /admin/sites.
 */
async function crmOrigin(): Promise<string> {
  const head = await headers();
  const host = head.get("x-forwarded-host") ?? head.get("host") ?? "";
  const proto = head.get("x-forwarded-proto") ?? "https";
  return host ? `${proto}://${host}` : "";
}

export default async function AccountKitPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  await requireAdmin("/admin/contas");

  const { slug } = await params;
  const account = findAccountBySlug(slug);
  if (!account) notFound();

  const origin = await crmOrigin();
  const sites = listAccountSites(account.id);
  const logins = listAccountUsers(account.id).filter((user) => user.active);

  // The first active site is the one the kit is written against. A client with
  // a landing page and a main site has two keys and needs both blocks, so the
  // per-site snippets are listed below rather than collapsed into one.
  const primary = sites.find((site) => site.active) ?? sites[0] ?? null;

  const envBlock = [
    `ATLAS_CRM_URL=${origin}`,
    primary
      ? `ATLAS_SITE_KEY=${primary.key}`
      : `ATLAS_SITE_KEY=   # crie um site em /admin/sites e cole a chave aqui`,
  ].join("\n");

  const serverBlock = `// Qualquer backend: Next route handler, Express, Astro, PHP…
// A chave identifica o site; ela é pública e pode ficar no cliente,
// mas mantê-la no servidor evita que alguém a copie do código-fonte.
const res = await fetch(\`\${process.env.ATLAS_CRM_URL}/api/v1/leads\`, {
  method: "POST",
  headers: { "content-type": "application/json" },
  body: JSON.stringify({
    key: process.env.ATLAS_SITE_KEY,
    name: "Maria Silva",        // obrigatório
    email: "maria@exemplo.com", // e-mail OU telefone é obrigatório
    phone: "+55 31 98888-7777",
    message: "Gostaria de um orçamento.",
    company: "Padaria da Maria",
    pageUrl: "https://cliente.com.br/contato",
    fields: { "Como nos conheceu": "Instagram" },
  }),
});

// 201 lead novo · 200 pessoa já conhecida · 4xx com { error } legível
const body = await res.json();`;

  const claudeMd = clientClaudeMd({ account, sites, crmOrigin: origin });

  return (
    <main className="bg-bg text-fg min-w-0 flex-1 px-5 py-8 md:px-8">
      <Link
        href="/admin/contas"
        className="text-fg-muted hover:text-fg inline-flex items-center gap-1.5 text-sm transition"
      >
        <ArrowLeft className="size-4" />
        Contas de cliente
      </Link>

      <header className="mt-4 mb-8">
        <p className="text-brand text-xs font-semibold tracking-[0.16em]">
          KIT DE INSTALAÇÃO
        </p>
        <h1 className="mt-1.5 flex flex-wrap items-center gap-2.5 text-2xl font-semibold">
          {account.name}
          {!account.active && (
            <span className="border-line text-fg-subtle rounded-full border px-2.5 py-0.5 text-xs font-medium">
              Suspensa
            </span>
          )}
        </h1>
        <p className="text-fg-muted mt-2 max-w-2xl text-sm leading-6">
          Tudo o que o repositório do site deste cliente precisa. Não há pacote
          para instalar nem build a configurar: uma tag, duas variáveis de
          ambiente e uma chamada HTTP funcionam em qualquer stack e em qualquer
          hospedagem.
        </p>
      </header>

      {sites.length === 0 && (
        <p className="mb-8 rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-sm leading-6 text-amber-900">
          Esta conta ainda não tem nenhum site.{" "}
          <Link href="/admin/sites" className="font-semibold underline">
            Crie um em Sites conectados
          </Link>{" "}
          e escolha <strong>{account.name}</strong> no campo Conta — sem isso os
          contatos do formulário entram no nosso pipeline, não no dele.
        </p>
      )}

      <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div className="grid min-w-0 gap-6">
          <section className="grid gap-3">
            <div>
              <h2 className="font-semibold">
                1 · <code className="text-fg">CLAUDE.md</code> do repositório
              </h2>
              <p className="text-fg-muted mt-1 text-sm leading-6">
                Salve na raiz do repositório do site, com esse nome exato. O
                Claude Code lê esse arquivo em toda sessão, então quem for
                construir o site já começa sabendo a chave, o endpoint e os
                domínios liberados — em vez de inventar um formulário que não
                chega a lugar nenhum. Ele já vem preenchido com os dados desta
                conta.
              </p>
            </div>
            <CopyBlock
              label="CLAUDE.md"
              language="markdown"
              hint="Na raiz do repositório do site deste cliente — não em docs/, não com outro nome."
              scroll
              code={claudeMd}
              action={
                <a
                  href={`/api/admin/contas/${encodeURIComponent(account.slug)}/claude-md`}
                  download="CLAUDE.md"
                  className="border-line hover:border-brand text-fg-muted hover:text-fg inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs transition"
                >
                  <Download className="size-3.5" />
                  Baixar
                </a>
              }
            />
          </section>

          <section className="grid gap-3">
            <div>
              <h2 className="font-semibold">2 · O formulário do site</h2>
              <p className="text-fg-muted mt-1 text-sm leading-6">
                Cole a tag antes de{" "}
                <code className="text-fg">&lt;/body&gt;</code> e marque o
                formulário com <code className="text-fg">data-atlas-crm</code>.
                O script cuida do envio, do estado de carregando, da mensagem de
                erro e do honeypot — não é preciso JavaScript no repositório do
                cliente.
              </p>
            </div>

            {sites.map((site) => (
              <CopyBlock
                key={site.id}
                label={site.name}
                hint={
                  site.active
                    ? site.origins.join(" · ")
                    : "Desativado — o formulário não envia enquanto estiver assim."
                }
                code={`<script src="${origin}/atlas-crm.js" data-key="${site.key}" defer></script>`}
              />
            ))}

            <CopyBlock
              label="Formulário mínimo"
              hint="Os nomes dos campos podem ser em português ou inglês; qualquer campo extra vira uma linha na nota do lead."
              code={`<form data-atlas-crm>
  <input name="nome" required placeholder="Seu nome">
  <input name="email" type="email" placeholder="Seu e-mail">
  <input name="telefone" placeholder="WhatsApp">
  <textarea name="mensagem" placeholder="Como podemos ajudar?"></textarea>
  <button type="submit">Enviar</button>
</form>`}
            />
          </section>

          <section className="grid gap-3">
            <div>
              <h2 className="font-semibold">3 · Variáveis de ambiente</h2>
              <p className="text-fg-muted mt-1 text-sm leading-6">
                Para quem prefere enviar pelo servidor — um route handler, um
                formulário com Server Action, um back-end em qualquer linguagem.
                A chave é pública por natureza (ela viaja no HTML quando se usa
                a tag), então guardá-la no servidor é higiene, não segurança: o
                que protege o endpoint é a lista de domínios do site e o limite
                de envios.
              </p>
            </div>
            <CopyBlock label=".env" language="bash" code={envBlock} />
          </section>

          <section className="grid gap-3">
            <div>
              <h2 className="font-semibold">4 · Envio pelo servidor</h2>
              <p className="text-fg-muted mt-1 text-sm leading-6">
                O mesmo endpoint que a tag usa. Só{" "}
                <code className="text-fg">name</code> e um contato — e-mail ou
                telefone — são obrigatórios.
              </p>
            </div>
            <CopyBlock
              label="POST /api/v1/leads"
              language="javascript"
              code={serverBlock}
            />
          </section>

          {/* Rendered from the database only. Whether the phone is actually
              online is a question for the bridge, and the component asks it on
              mount — a dead Evolution must not hold up the install kit, which is
              useful with or without WhatsApp. */}
          <WhatsappConnect
            accountId={account.id}
            accountName={account.name}
            initial={{
              configured: whatsappConfigured(),
              instance: account.waInstance,
              state: account.waInstance ? "unknown" : "close",
              number: account.waNumber,
              brief: account.waBrief,
            }}
          />
        </div>

        <aside className="grid content-start gap-4">
          <section className="border-line bg-surface rounded-2xl border p-5">
            <h2 className="flex items-center gap-2 font-semibold">
              <ExternalLink className="text-brand size-4" />O portal do cliente
            </h2>
            <p className="text-fg-muted mt-2 text-sm leading-6">
              Onde ele acompanha os próprios contatos, muda o estágio de cada um
              e marca retorno. Só os leads desta conta aparecem lá.
            </p>
            <p className="bg-surface-2 border-line mt-3 rounded-lg border px-3 py-2 text-xs break-all">
              {origin}/app
            </p>

            <h3 className="mt-5 flex items-center gap-2 text-sm font-semibold">
              <KeyRound className="text-brand size-4" />
              Acessos ativos
            </h3>
            {logins.length === 0 ? (
              <p className="text-fg-muted mt-1.5 text-sm leading-6">
                Nenhum ainda — a conta existe, mas o cliente nunca a viu. Crie
                um acesso em{" "}
                <Link href="/admin/contas" className="underline">
                  Contas de cliente
                </Link>
                .
              </p>
            ) : (
              <ul className="mt-1.5 grid gap-1">
                {logins.map((login) => (
                  <li key={login.id} className="text-fg-muted text-sm">
                    {login.displayName}{" "}
                    <span className="text-fg-subtle">({login.username})</span>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="border-line bg-surface rounded-2xl border p-5">
            <h2 className="flex items-center gap-2 font-semibold">
              <Globe className="text-brand size-4" />
              Domínios liberados
            </h2>
            <p className="text-fg-muted mt-2 text-sm leading-6">
              O navegador envia a origem exata da página. Liste o apex e o{" "}
              <code className="text-fg">www</code> separadamente, ou o
              formulário funciona para metade dos visitantes sem que nada relate
              isso.
            </p>
            {sites.length > 0 && (
              <ul className="mt-3 grid gap-2">
                {sites.map((site) => (
                  <li key={site.id} className="text-sm">
                    <span className="font-medium">{site.name}</span>
                    <span className="text-fg-subtle block text-xs break-all">
                      {site.origins.join(" · ")}
                    </span>
                  </li>
                ))}
              </ul>
            )}
            <Link
              href="/admin/sites"
              className="border-line hover:border-brand mt-4 inline-flex rounded-xl border px-3 py-2 text-sm transition"
            >
              Gerenciar sites
            </Link>
          </section>
        </aside>
      </div>
    </main>
  );
}
