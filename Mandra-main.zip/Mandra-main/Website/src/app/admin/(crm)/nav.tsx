"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Building2,
  KeyRound,
  LayoutDashboard,
  MessageSquare,
  MessageSquareText,
  Mic,
  PlugZap,
  PhoneCall,
  BarChart3,
  LineChart,
  Search,
  Columns3,
  Cpu,
  UsersRound,
  type LucideIcon,
} from "lucide-react";
import type { Permission, Role } from "@/lib/auth/session";

/**
 * The sidebar's links.
 *
 * Every entry points at a view that exists. The temptation on a CRM shell is to
 * list the whole product — messages, campaigns, integrations — and route the
 * unbuilt half back to the dashboard, which reads as a broken link rather than
 * as a roadmap. Sections get added here when they have something to show.
 */

type Item = {
  label: string;
  href: string;
  icon: LucideIcon;
  /** Marks the item active for any deeper path, not just an exact match. */
  prefix?: boolean;
  /** Hidden from operators. The page and its API check the role again. */
  adminOnly?: boolean;
  /** Hidden without this grant. The page and its API check it again too. */
  needs?: Permission;
};

const GROUPS: { heading: string | null; items: Item[] }[] = [
  {
    heading: null,
    items: [{ label: "Visão geral", href: "/admin", icon: LayoutDashboard }],
  },
  {
    heading: "Prospecção",
    items: [
      { label: "Buscar leads", href: "/admin/prospector", icon: Search },
      {
        label: "Funil",
        href: "/admin/funil",
        icon: Columns3,
        prefix: true,
        adminOnly: true,
      },
      {
        label: "Histórico completo",
        href: "/admin/historico",
        icon: UsersRound,
        prefix: true,
      },
      // Not admin-only: every operator writes their own from
      // /prospector/mensagens, and this entry is the admin's door to theirs —
      // and to the team's default, which only they may change.
      {
        label: "Mensagem de abordagem",
        href: "/admin/mensagens",
        icon: MessageSquareText,
        prefix: true,
      },
      {
        label: "Ligações",
        href: "/admin/ligacoes",
        icon: PhoneCall,
        prefix: true,
        adminOnly: true,
      },
      {
        // Inside the shell, not the standalone /prospector/b2b tree: that one is
        // the same tool wearing a different page, and reaching it from here
        // dropped the sidebar and every other CRM affordance with it.
        label: "Empresas B2B",
        href: "/admin/prospector/b2b",
        icon: Building2,
        prefix: true,
        needs: "b2b",
      },
      // This sidebar only ever renders inside the admin-only tree; the
      // operator reaches the same screen from the tile on /operador. Marked
      // adminOnly anyway so the entry states the rule it actually lives under.
      {
        adminOnly: true,
        label: "Reuniões",
        href: "/admin/reunioes",
        icon: Mic,
        prefix: true,
      },
    ],
  },
  {
    // One entry, not six. The analytics section has its own tabs, and a
    // sidebar that lists every screen inside another screen's navigation is
    // how a shell stops being scannable.
    heading: "Analytics",
    items: [
      {
        label: "Site e anúncios",
        href: "/admin/analytics",
        icon: LineChart,
        prefix: true,
        adminOnly: true,
      },
    ],
  },
  {
    heading: "Atendimento",
    items: [
      {
        label: "WhatsApp",
        href: "/admin/whatsapp",
        icon: MessageSquare,
        prefix: true,
        adminOnly: true,
      },
    ],
  },
  {
    heading: "Administração",
    items: [
      {
        label: "Contas de cliente",
        href: "/admin/contas",
        icon: Building2,
        prefix: true,
        adminOnly: true,
      },
      {
        label: "Acessos",
        href: "/admin/usuarios",
        icon: KeyRound,
        prefix: true,
        adminOnly: true,
      },
      {
        label: "Sites conectados",
        href: "/admin/sites",
        icon: PlugZap,
        prefix: true,
        adminOnly: true,
      },
      {
        label: "IA",
        href: "/admin/ia",
        icon: Cpu,
        prefix: true,
        adminOnly: true,
      },
      {
        label: "Uso do prospector",
        href: "/admin/uso-prospector",
        icon: BarChart3,
        prefix: true,
        adminOnly: true,
      },
    ],
  },
];

export function AdminNav({
  role,
  permissions,
}: {
  role: Role;
  permissions: Permission[];
}) {
  const pathname = usePathname();

  const isActive = (item: Item): boolean =>
    item.prefix ? pathname.startsWith(item.href) : pathname === item.href;

  // The admin arrives holding every permission, so one filter covers both kinds
  // of gate. Hiding a link is only tidiness — each destination checks again.
  const allowed = (item: Item): boolean =>
    (!item.adminOnly || role === "admin") &&
    (!item.needs || permissions.includes(item.needs));

  const groups = GROUPS.map((group) => ({
    ...group,
    items: group.items.filter(allowed),
  })).filter((group) => group.items.length > 0);

  return (
    // Below lg the sidebar is a strip above the content, so the same links lay
    // out as one scrollable row instead of a column that pushes the CRM off
    // screen. The group headings only make sense in the column.
    <nav className="mt-5 flex gap-1 overflow-x-auto pb-1 lg:mt-9 lg:block lg:space-y-6 lg:overflow-visible lg:pb-0">
      {groups.map((group) => (
        <div key={group.heading ?? "principal"} className="flex gap-1 lg:block">
          {group.heading && (
            <p className="text-fg-subtle mb-2 hidden px-3 text-[11px] font-semibold tracking-[0.14em] uppercase lg:block">
              {group.heading}
            </p>
          )}
          <ul className="flex gap-1 lg:block lg:space-y-1">
            {group.items.map((item) => {
              const active = isActive(item);
              return (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    aria-current={active ? "page" : undefined}
                    className={`flex shrink-0 items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium whitespace-nowrap transition ${
                      active
                        ? "bg-surface-raised text-fg shadow-[inset_2px_0_0_var(--color-brand)]"
                        : "text-fg-muted hover:bg-surface-raised/60 hover:text-fg"
                    }`}
                  >
                    <item.icon
                      className={`size-[18px] shrink-0 ${active ? "text-brand" : ""}`}
                    />
                    {item.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
    </nav>
  );
}
