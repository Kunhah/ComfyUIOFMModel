import { headers } from "next/headers";
import { PlugZap } from "lucide-react";
import { SiteManager } from "@/components/admin/site-manager";
import { requireAdmin } from "@/lib/auth/server";
import { listSites } from "@/lib/crm/sites";
import { listAccounts } from "@/lib/crm/accounts";

/**
 * Where the CRM stops being ours and starts being the customer's.
 *
 * A row here is a website allowed to post into the lead base, and the snippet on
 * this page is the entire installation: paste it, and their contact form lands
 * in `/admin/historico` beside everything the prospector found. That is the point
 * of the shared table — a lead that came to us and a lead we went and found are
 * worked in the same place, with the same funnel.
 */

export const dynamic = "force-dynamic";
export const metadata = { title: "Sites conectados" };

/**
 * The origin the snippet must point at, taken from the request rather than from
 * an environment variable.
 *
 * The snippet is pasted into someone else's website, so the URL in it has to be
 * absolute and has to be right. Reading it from the request means it is correct
 * on the VPS, correct behind a domain, and correct in dev — with nothing to
 * configure and nothing to forget when the domain changes. `x-forwarded-proto`
 * comes first for the same reason the session cookie reads it: behind a TLS
 * terminator, Next only ever sees plain HTTP.
 */
async function scriptOrigin(): Promise<string> {
  const head = await headers();
  const host =
    head.get("x-forwarded-host") ?? head.get("host") ?? "localhost:3000";
  const proto =
    head.get("x-forwarded-proto")?.split(",")[0]?.trim() ??
    (host.startsWith("localhost") ? "http" : "https");
  return `${proto}://${host}`;
}

export default async function SitesPage() {
  await requireAdmin("/admin/sites");
  const sites = listSites();
  // Only active accounts are offered: filing a new form under a suspended
  // client is never the intent, and the picker is where that choice is made.
  const accounts = listAccounts().filter((account) => account.active);
  const origin = await scriptOrigin();

  return (
    <main className="mx-auto w-full max-w-[1100px] flex-1 px-5 py-8 md:px-8">
      <p className="text-brand text-xs font-semibold tracking-[0.16em]">
        ADMINISTRAÇÃO
      </p>
      <h1 className="mt-1.5 text-3xl font-semibold tracking-tight md:text-[34px]">
        Sites conectados
      </h1>
      <p className="text-fg-muted mt-2 text-sm">
        Os sites que enviam leads direto para este CRM. Um trecho de código no
        site do cliente e o formulário de contato dele cai aqui.
      </p>

      <div className="border-line bg-surface mt-6 flex flex-wrap items-center gap-3 rounded-2xl border px-5 py-4">
        <span className="bg-brand/10 text-brand flex size-10 shrink-0 items-center justify-center rounded-xl">
          <PlugZap className="size-5" />
        </span>
        <div className="min-w-0">
          <p className="text-sm font-medium">
            Os leads chegam em Histórico completo, marcados como{" "}
            <span className="font-mono text-xs">formulário</span>
          </p>
          <p className="text-fg-muted mt-0.5 text-sm">
            Entram na etapa <strong>descoberta</strong> como qualquer outro
            lead, com a mensagem do formulário já na anotação — e com o botão de
            WhatsApp pronto quando o telefone informado for um celular.
          </p>
        </div>
      </div>

      <SiteManager
        sites={sites.map((site) => ({
          id: site.id,
          key: site.key,
          accountId: site.accountId,
          name: site.name,
          origins: site.origins,
          country: site.country,
          active: site.active,
          createdAt: site.createdAt,
          createdBy: site.createdBy,
          lastLeadAt: site.lastLeadAt,
          leadCount: site.leadCount,
        }))}
        accounts={accounts.map((account) => ({
          id: account.id,
          name: account.name,
        }))}
        scriptOrigin={origin}
      />
    </main>
  );
}
