import { ProspectorWorkspace } from "@/components/prospector/workspace";
import { can, requirePermission } from "@/lib/auth/server";
import { b2bPanel, localPanel } from "@/app/prospector/panels";

export const dynamic = "force-dynamic";

/**
 * The B2B crawler inside the CRM shell.
 *
 * A sibling route rather than a query parameter so the sidebar entry keeps
 * working the way every other one does — it is a link with an active state, and
 * `needs: "b2b"` hides it from an account without the grant. Switching tools
 * once you are here changes no URL: this and `/admin/prospector` render the same
 * workspace and differ only in which tab opens first.
 */
export default async function AdminB2bPage() {
  // The sidebar hides this without the crawler grant; only this stops someone
  // typing the URL. The routes it calls check again.
  const user = await requirePermission("b2b", "/admin/prospector/b2b");

  return (
    <ProspectorWorkspace
      chrome="crm"
      initialTool="b2b"
      local={localPanel({
        initialSearch: null,
        initialResult: null,
        initialError: null,
        canExport: can(user, "export"),
        viewer: user,
      })}
      b2b={b2bPanel(user)}
    />
  );
}
