import { ProspectorWorkspace } from "@/components/prospector/workspace";
import { can, requireUser } from "@/lib/auth/server";
import { parseInitialSearch } from "@/lib/prospector/search-url";
import { performSearch } from "@/lib/prospector/search";
import { b2bPanel, localPanel } from "@/app/prospector/panels";

export const dynamic = "force-dynamic";

/**
 * The search tool rendered inside the CRM shell, rather than beside it.
 *
 * It is the same `<ProspectorWorkspace>` the standalone `/prospector` mounts,
 * with `chrome="crm"` for the shell's gutters, title voice and history link.
 * Both prospectors are tabs on it: the B2B one used to be a sidebar entry
 * pointing at `/prospector/b2b`, which left the shell for the dark standalone
 * tree — the same tool, a completely different-looking page, reached by a full
 * navigation. `/admin/prospector/b2b` opens the same screen on the other tab.
 */
export default async function AdminProspectorPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const user = await requireUser("/admin/prospector");

  const initialSearch = parseInitialSearch(await searchParams);
  const outcome = initialSearch
    ? await performSearch({ ...initialSearch, limit: 1000 }, user)
    : null;

  return (
    <ProspectorWorkspace
      chrome="crm"
      initialTool="local"
      local={localPanel({
        initialSearch,
        initialResult: outcome?.ok ? outcome.response : null,
        initialError: outcome && !outcome.ok ? outcome.error : null,
        canExport: can(user, "export"),
        viewer: user,
      })}
      b2b={b2bPanel(user)}
    />
  );
}
