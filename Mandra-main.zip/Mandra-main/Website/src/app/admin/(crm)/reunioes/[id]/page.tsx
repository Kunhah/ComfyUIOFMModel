import Link from "next/link";
import { notFound } from "next/navigation";
import { AlertTriangle, ArrowLeft, Loader2 } from "lucide-react";
import { MeetingActions } from "@/components/admin/meeting-actions";
import { requireStaff } from "@/lib/auth/server";
import {
  OUTCOME_LABEL,
  REVIEW_STATUS_LABEL,
  reviewById,
} from "@/lib/review/db";
import type { Analysis } from "@/lib/review/analyse";
import { PENDING_STATUS } from "@/lib/review/types";
import { STAGE_LABEL, type Stage } from "@/lib/review/rubric";

export const dynamic = "force-dynamic";
export const metadata = { title: "Análise da reunião" };

/**
 * One review, read.
 *
 * The order on the page is the order a seller can act on, which is not the order
 * the model produced: the probable cause of the loss first, then the three
 * actions, then the evidence. A report that opens with eight scores is a report
 * whose conclusion is below the fold.
 */

const TONE: Record<string, string> = {
  virada: "border-brand/40 bg-brand/5",
  acerto: "border-emerald-500/30 bg-emerald-500/5",
  erro: "border-red-500/30 bg-red-500/5",
  oportunidade_perdida: "border-amber-500/30 bg-amber-500/5",
};

const MOMENT_LABEL: Record<string, string> = {
  virada: "Virada",
  acerto: "Acerto",
  erro: "Erro",
  oportunidade_perdida: "Oportunidade perdida",
};

function scoreColour(nota: number, max: number): string {
  const ratio = nota / max;
  if (ratio >= 0.7) return "text-emerald-500";
  if (ratio >= 0.4) return "text-amber-500";
  return "text-red-500";
}

export async function MeetingReviewView({
  id,
  basePath,
  /** null = sees every seller's, which is only ever the admin. */
  viewerId,
}: {
  id: string;
  basePath: string;
  viewerId: string | null;
}) {
  const review = reviewById(id);

  // Same rule as the API: a recording that is not yours does not exist. 404
  // rather than 403 so the page cannot confirm somebody else's meeting.
  if (!review) notFound();
  if (viewerId !== null && review.actorId !== viewerId) notFound();

  const analysis = review.analysis as Analysis | null;
  const working = PENDING_STATUS.includes(review.status);

  return (
    <main className="mx-auto w-full max-w-[900px] flex-1 px-5 py-8 md:px-8">
      <Link
        href={basePath}
        className="text-fg-muted hover:text-fg inline-flex items-center gap-1.5 text-xs"
      >
        <ArrowLeft className="size-3.5" />
        Reuniões
      </Link>

      <div className="mt-3 flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0">
          <h1 className="text-2xl font-semibold tracking-tight md:text-[30px]">
            {review.title}
          </h1>
          <p className="text-fg-subtle mt-1 text-xs">
            {review.actorName} ·{" "}
            {new Date(review.createdAt).toLocaleString("pt-BR", {
              dateStyle: "short",
              timeStyle: "short",
            })}
            {review.durationSeconds
              ? ` · ${Math.round(review.durationSeconds / 60)} min`
              : ""}{" "}
            · {OUTCOME_LABEL[review.outcome]}
            {review.analysisModel ? ` · via ${review.analysisModel}` : ""}
          </p>
        </div>
        <MeetingActions
          id={review.id}
          status={review.status}
          basePath={basePath}
        />
      </div>

      {working && (
        <div className="border-line bg-surface mt-6 flex items-center gap-3 rounded-2xl border px-5 py-4">
          <Loader2 className="text-brand size-5 animate-spin" />
          <div>
            <p className="text-sm font-medium">
              {REVIEW_STATUS_LABEL[review.status]}…
            </p>
            <p className="text-fg-muted mt-0.5 text-sm">
              Uma reunião de 40 minutos leva alguns minutos para transcrever.
              Você pode fechar esta página — o processamento não depende dela.
            </p>
          </div>
        </div>
      )}

      {review.status === "erro" && (
        <div className="mt-6 flex items-start gap-3 rounded-2xl border border-red-500/30 bg-red-500/10 px-5 py-4">
          <AlertTriangle className="mt-0.5 size-5 shrink-0 text-red-500" />
          <div className="min-w-0">
            <p className="text-sm font-medium text-red-500">Falhou</p>
            <p className="text-fg-muted mt-0.5 text-sm break-words">
              {review.error ?? "Sem detalhe."}
            </p>
          </div>
        </div>
      )}

      {analysis && (
        <>
          <section className="border-line bg-surface mt-6 rounded-2xl border p-5 md:p-6">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <p className="text-brand text-xs font-semibold tracking-[0.16em]">
                {review.outcome === "fechou"
                  ? "O QUE QUASE CUSTOU A VENDA"
                  : "CAUSA PROVÁVEL"}
              </p>
              <span className="text-fg-subtle text-xs">
                confiança {analysis.motivo_provavel_da_nao_venda.confianca}
              </span>
            </div>
            <p className="mt-2 text-lg leading-snug font-medium">
              {analysis.motivo_provavel_da_nao_venda.hipotese}
            </p>
            {analysis.motivo_provavel_da_nao_venda.explicacao && (
              <p className="text-fg-muted mt-2 text-sm">
                {analysis.motivo_provavel_da_nao_venda.explicacao}
              </p>
            )}
            {analysis.motivo_provavel_da_nao_venda.evidencia.length > 0 && (
              <ul className="border-line mt-4 space-y-2 border-t pt-4">
                {analysis.motivo_provavel_da_nao_venda.evidencia.map(
                  (quote, index) => (
                    <li
                      key={index}
                      className="text-fg-muted border-line border-l-2 pl-3 text-sm italic"
                    >
                      {quote}
                    </li>
                  ),
                )}
              </ul>
            )}
          </section>

          {analysis.tres_acoes.length > 0 && (
            <section className="mt-4">
              <h2 className="text-sm font-semibold">Faça isto na próxima</h2>
              <ol className="mt-2 space-y-2">
                {analysis.tres_acoes.map((action, index) => (
                  <li
                    key={index}
                    className="border-line bg-surface flex gap-3 rounded-xl border px-4 py-3 text-sm"
                  >
                    <span className="bg-brand/10 text-brand flex size-6 shrink-0 items-center justify-center rounded-lg text-xs font-semibold">
                      {index + 1}
                    </span>
                    {action}
                  </li>
                ))}
              </ol>
            </section>
          )}

          <section className="mt-6">
            <div className="flex flex-wrap items-baseline justify-between gap-3">
              <h2 className="text-sm font-semibold">Etapas do SPIN</h2>
              <p className="text-sm">
                <span
                  className={`text-lg font-semibold tabular-nums ${scoreColour(analysis.nota_geral, 10)}`}
                >
                  {analysis.nota_geral.toFixed(1)}
                </span>
                <span className="text-fg-subtle text-xs">/10 geral</span>
              </p>
            </div>

            <ul className="mt-2 space-y-2">
              {analysis.etapas.map((stage) => (
                <li
                  key={stage.etapa}
                  className="border-line bg-surface rounded-xl border px-4 py-3"
                >
                  <div className="flex items-baseline justify-between gap-3">
                    <p className="text-sm font-medium">
                      {STAGE_LABEL[stage.etapa as Stage] ?? stage.etapa}
                    </p>
                    <span
                      className={`text-sm font-semibold tabular-nums ${scoreColour(stage.nota, 5)}`}
                    >
                      {stage.nota}
                      <span className="text-fg-subtle text-xs font-normal">
                        /5
                      </span>
                    </span>
                  </div>
                  {stage.o_que_funcionou && (
                    <p className="text-fg-muted mt-1.5 text-sm">
                      <span className="text-emerald-500">Funcionou:</span>{" "}
                      {stage.o_que_funcionou}
                    </p>
                  )}
                  {stage.o_que_faltou && (
                    <p className="text-fg-muted mt-1 text-sm">
                      <span className="text-amber-500">Faltou:</span>{" "}
                      {stage.o_que_faltou}
                    </p>
                  )}
                  {stage.evidencia && (
                    <p className="text-fg-subtle border-line mt-2 border-l-2 pl-3 text-xs italic">
                      [{stage.evidencia.timestamp}] {stage.evidencia.citacao}
                    </p>
                  )}
                </li>
              ))}
            </ul>
          </section>

          {analysis.momentos.length > 0 && (
            <section className="mt-6">
              <h2 className="text-sm font-semibold">Momentos</h2>
              <ul className="mt-2 space-y-2">
                {analysis.momentos.map((moment, index) => (
                  <li
                    key={index}
                    className={`rounded-xl border px-4 py-3 ${TONE[moment.tipo] ?? "border-line bg-surface"}`}
                  >
                    <p className="text-fg-subtle text-xs font-medium">
                      {moment.timestamp} ·{" "}
                      {MOMENT_LABEL[moment.tipo] ?? moment.tipo}
                    </p>
                    {moment.citacao && (
                      <p className="mt-1.5 text-sm italic">
                        &ldquo;{moment.citacao}&rdquo;
                      </p>
                    )}
                    <p className="text-fg-muted mt-1.5 text-sm">
                      {moment.comentario}
                    </p>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {analysis.objecoes.length > 0 && (
            <section className="mt-6">
              <h2 className="text-sm font-semibold">Objeções</h2>
              <ul className="mt-2 space-y-2">
                {analysis.objecoes.map((objection, index) => (
                  <li
                    key={index}
                    className="border-line bg-surface rounded-xl border px-4 py-3"
                  >
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <p className="text-sm font-medium">
                        &ldquo;{objection.objecao}&rdquo;
                      </p>
                      <span className="text-fg-subtle text-xs">
                        {objection.timestamp} · resposta {objection.avaliacao}
                      </span>
                    </div>
                    {objection.resposta_do_vendedor && (
                      <p className="text-fg-muted mt-1.5 text-sm">
                        Você respondeu: {objection.resposta_do_vendedor}
                      </p>
                    )}
                    {objection.melhor_resposta && (
                      <p className="mt-1.5 text-sm">
                        <span className="text-brand">Melhor:</span>{" "}
                        {objection.melhor_resposta}
                      </p>
                    )}
                  </li>
                ))}
              </ul>
            </section>
          )}

          <section className="mt-6 grid gap-4 md:grid-cols-2">
            <div className="border-line bg-surface rounded-2xl border p-5">
              <h2 className="text-sm font-semibold">Quem falou</h2>
              <p className="mt-2 text-sm">
                Vendedor{" "}
                <span
                  className={`font-semibold tabular-nums ${
                    analysis.proporcao_de_fala.vendedor_pct > 40
                      ? "text-red-500"
                      : "text-emerald-500"
                  }`}
                >
                  {analysis.proporcao_de_fala.vendedor_pct}%
                </span>{" "}
                · cliente{" "}
                <span className="font-semibold tabular-nums">
                  {analysis.proporcao_de_fala.cliente_pct}%
                </span>
              </p>
              {analysis.proporcao_de_fala.observacao && (
                <p className="text-fg-muted mt-1.5 text-sm">
                  {analysis.proporcao_de_fala.observacao}
                </p>
              )}
              <p className="text-fg-subtle mt-3 text-xs">
                A meta do roteiro é o vendedor abaixo de 30%.
              </p>
            </div>

            <div className="border-line bg-surface rounded-2xl border p-5">
              <h2 className="text-sm font-semibold">Sinais de alerta</h2>
              {analysis.sinais_de_alerta.length === 0 ? (
                <p className="text-fg-muted mt-2 text-sm">
                  Nenhum dos erros clássicos apareceu.
                </p>
              ) : (
                <ul className="text-fg-muted mt-2 space-y-1.5 text-sm">
                  {analysis.sinais_de_alerta.map((flag, index) => (
                    <li key={index} className="flex gap-2">
                      <span className="text-amber-500">•</span>
                      {flag}
                    </li>
                  ))}
                </ul>
              )}
              <p className="text-fg-subtle mt-3 text-xs">
                Próximo passo marcado:{" "}
                {analysis.proximo_passo_definido ? "sim" : "não"}
              </p>
            </div>
          </section>

          <section className="mt-6">
            <h2 className="text-sm font-semibold">Resumo</h2>
            <p className="text-fg-muted mt-2 text-sm">{analysis.resumo}</p>
          </section>
        </>
      )}

      {review.transcript && (
        <details className="border-line bg-surface mt-6 rounded-2xl border px-5 py-4">
          <summary className="cursor-pointer text-sm font-medium">
            Transcrição completa
          </summary>
          <div className="text-fg-muted mt-3 max-h-[420px] space-y-1.5 overflow-y-auto text-sm">
            {review.segments.map((segment, index) => (
              <p key={index}>
                <span className="text-fg-subtle font-mono text-xs">
                  {formatStamp(segment.start)}
                </span>{" "}
                {segment.text}
              </p>
            ))}
          </div>
          <p className="text-fg-subtle mt-3 text-xs">
            A transcrição não separa os interlocutores — quem fala é deduzido
            pelo contexto, e às vezes erra.
          </p>
        </details>
      )}
    </main>
  );
}

export default async function MeetingPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const user = await requireStaff(`/admin/reunioes/${id}`);
  return (
    <MeetingReviewView
      id={id}
      basePath="/admin/reunioes"
      viewerId={user.role === "admin" ? null : user.id}
    />
  );
}

function formatStamp(seconds: number): string {
  const total = Math.max(0, Math.round(seconds));
  return `${String(Math.floor(total / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
}
