import { Mic, TriangleAlert } from "lucide-react";
import { MeetingList } from "@/components/admin/meeting-list";
import { MeetingUploader } from "@/components/admin/meeting-uploader";
import { requireStaff } from "@/lib/auth/server";
import { listReviews } from "@/lib/review/db";
import { readiness } from "@/lib/review/transcribe";

/**
 * Reuniões gravadas, transcritas e avaliadas contra o roteiro SPIN.
 *
 * Exported as a view and mounted twice — here and at `/operador/reunioes` — for
 * the same reason the call queue is: the whole `/admin` tree is `requireAdmin`
 * at the layout, and the people whose meetings these are are operators. A review
 * the seller cannot open is a performance file, not a coaching tool, and nobody
 * uploads to one of those.
 *
 * Two arguments carry the difference and both are decided by the mount: `scope`
 * (null = every seller's, which is only ever the admin's view) and `basePath`,
 * so a review opened from `/operador` stays under `/operador`.
 */

export const dynamic = "force-dynamic";
export const metadata = { title: "Análise de reuniões" };

export async function MeetingsView({
  basePath,
  scope,
}: {
  basePath: string;
  scope: string | null;
}) {
  const [reviews, state] = await Promise.all([
    Promise.resolve(listReviews(scope)),
    readiness(),
  ]);

  return (
    <main className="mx-auto w-full max-w-[1100px] flex-1 px-5 py-8 md:px-8">
      <p className="text-brand text-xs font-semibold tracking-[0.16em]">
        VENDAS
      </p>
      <h1 className="mt-1.5 text-3xl font-semibold tracking-tight md:text-[34px]">
        Análise de reuniões
      </h1>
      <p className="text-fg-muted mt-2 text-sm">
        Suba a gravação de uma reunião comercial. Ela é transcrita neste
        servidor e avaliada contra o roteiro SPIN — onde o vendedor perdeu
        terreno e o que provavelmente impediu o fechamento.
      </p>

      <div className="border-line bg-surface mt-6 flex flex-wrap items-center gap-3 rounded-2xl border px-5 py-4">
        <span className="bg-brand/10 text-brand flex size-10 shrink-0 items-center justify-center rounded-xl">
          <Mic className="size-5" />
        </span>
        <div className="min-w-0">
          <p className="text-sm font-medium">
            Avise que está gravando, no começo da chamada
          </p>
          <p className="text-fg-muted mt-0.5 text-sm">
            Gravar uma conversa da qual você participa é legal no Brasil, mas o
            cliente que descobre depois é um cliente perdido. Uma frase resolve:
            &ldquo;posso gravar para eu revisar depois?&rdquo;
          </p>
        </div>
      </div>

      {!state.ready && (
        <div className="mt-4 flex flex-wrap items-start gap-3 rounded-2xl border border-amber-500/30 bg-amber-500/10 px-5 py-4">
          <TriangleAlert className="mt-0.5 size-5 shrink-0 text-amber-500" />
          <div className="min-w-0 text-sm">
            <p className="font-medium text-amber-500">
              A transcrição não está pronta neste servidor
            </p>
            <ul className="text-fg-muted mt-1 space-y-0.5">
              {!state.ffmpeg && <li>ffmpeg não está instalado.</li>}
              {!state.whisper && (
                <li>whisper-cli não está instalado ou não está no PATH.</li>
              )}
              {!state.model && (
                <li>
                  O modelo não está em{" "}
                  <span className="font-mono text-xs">{state.modelPath}</span>.
                </li>
              )}
            </ul>
            <p className="text-fg-muted mt-1.5">
              <span className="font-mono text-xs">npm run review:setup</span>{" "}
              resolve os dois últimos.
            </p>
          </div>
        </div>
      )}

      <MeetingUploader ready={state.ready} />

      <MeetingList
        basePath={basePath}
        initial={reviews.map((r) => ({
          id: r.id,
          title: r.title,
          status: r.status,
          outcome: r.outcome,
          actorName: r.actorName,
          durationSeconds: r.durationSeconds,
          error: r.error,
          createdAt: r.createdAt,
          notaGeral:
            r.analysis && typeof r.analysis === "object"
              ? ((r.analysis as { nota_geral?: number }).nota_geral ?? null)
              : null,
        }))}
      />
    </main>
  );
}

export default async function MeetingsPage() {
  const user = await requireStaff("/admin/reunioes");
  // The layout already refuses anyone but an admin; the scope is written out
  // anyway so the two mounts read the same and neither infers its own rule.
  return (
    <MeetingsView
      basePath="/admin/reunioes"
      scope={user.role === "admin" ? null : user.id}
    />
  );
}
