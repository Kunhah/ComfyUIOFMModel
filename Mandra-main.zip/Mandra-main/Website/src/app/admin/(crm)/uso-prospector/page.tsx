import Link from "next/link";
import { BarChart3, ChevronRight, Search, UsersRound } from "lucide-react";
import { ActivityFeed } from "@/components/admin/activity-feed";
import { parseActivityFilters } from "@/lib/admin/activity";
import { fmt, sinceLabel } from "@/lib/admin/format";
import {
  accountDirectory,
  KIND_LABEL,
  type OperatorAccount,
} from "@/lib/admin/operators";
import { requireAdmin } from "@/lib/auth/server";
import {
  activityFeed,
  EMPTY_OUTCOMES,
  operatorOutcomes,
  prospectorUsage,
  type OperatorOutcomes,
  type ProspectorUsage,
} from "@/lib/prospector/db";

export const dynamic = "force-dynamic";
export const metadata = { title: "Uso do prospector" };

/**
 * What each account did, and what came of it.
 *
 * Two questions on one page and deliberately not merged: the left half of the
 * table is "did they use the tool", the right half is "did it turn into
 * anything". They come apart more often than you would like — fifty searches
 * and nothing contacted is a real week, and a usage-only screen reports it as a
 * good one.
 *
 * The audit is the source for both. It is written by the tool as it is used and
 * never derived from the shared lead cache, because a lead says nothing about
 * who found it.
 */
export default async function ProspectorUsagePage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  await requireAdmin("/admin/uso-prospector");

  const params = await searchParams;
  const accounts = accountDirectory();
  const known = new Set(accounts.map((account) => account.id));

  const filters = parseActivityFilters(params);
  // An unknown id in the URL is dropped rather than shown as an empty account:
  // a typo would otherwise render as "this person did nothing", which is a
  // different and much more alarming statement.
  const actorId =
    filters.actorId && known.has(filters.actorId) ? filters.actorId : undefined;
  const scoped = { ...filters, actorId };

  const usage = prospectorUsage(actorId);
  const usageByActor = new Map(
    usage.byUser.map((entry) => [entry.actorId, entry]),
  );
  const outcomesByActor = new Map(
    operatorOutcomes(actorId).map((row) => [row.actorId, row]),
  );

  const rows = accounts
    .filter((account) => !actorId || account.id === actorId)
    .map((account) => ({
      account,
      usage: usageByActor.get(account.id) ?? emptyUsage(account),
      outcomes: outcomesByActor.get(account.id) ?? EMPTY_OUTCOMES(account.id),
    }))
    // Busiest first, but every account stays on the list — an operator who has
    // done nothing is exactly who this screen exists to show.
    .sort(
      (a, b) =>
        b.usage.searches +
        b.outcomes.actionsTotal -
        (a.usage.searches + a.outcomes.actionsTotal),
    );

  return (
    <main className="mx-auto w-full max-w-[1200px] flex-1 px-5 py-8 md:px-8">
      <p className="text-brand text-xs font-semibold tracking-[0.16em]">
        ADMINISTRAÇÃO
      </p>
      <h1 className="mt-1.5 text-3xl font-semibold tracking-tight md:text-[34px]">
        Uso do prospector
      </h1>
      <p className="text-fg-muted mt-2 text-sm">
        Quanto cada acesso usou a ferramenta e o que saiu disso. Clique em uma
        pessoa para ver o histórico completo, os follow-ups em aberto e os leads
        que pararam de andar.
      </p>

      <div className="border-line bg-surface mt-7 grid divide-y overflow-hidden rounded-2xl border sm:grid-cols-3 sm:divide-x sm:divide-y-0">
        <Metric
          icon={Search}
          label="Buscas realizadas"
          value={usage.totals.searches}
        />
        <Metric
          icon={BarChart3}
          label="Buscas hoje"
          value={usage.totals.searchesToday}
        />
        <Metric
          icon={UsersRound}
          label="Leads retornados"
          value={usage.totals.leadsReturned}
        />
      </div>

      <section className="border-line bg-surface mt-6 overflow-hidden rounded-2xl border">
        <div className="border-line border-b px-5 py-4">
          <h2 className="font-semibold">Uso e resultado por acesso</h2>
          <p className="text-fg-muted mt-1 text-sm">
            Inclui os operadores que ainda não fizeram nada. Um lead conta para
            todo mundo que mexeu nele, então as colunas comerciais não somam o
            pipeline — elas descrevem cada pessoa.
          </p>
        </div>
        <div className="hidden overflow-x-auto lg:block">
          <table className="w-full min-w-[1040px] text-left text-sm">
            <thead className="text-fg-subtle bg-surface-2 text-xs tracking-[0.08em] uppercase">
              <tr>
                <th className="px-5 py-3 font-semibold">Acesso</th>
                <th className="px-3 py-3 text-right font-semibold">Buscas</th>
                <th className="px-3 py-3 text-right font-semibold">Hoje</th>
                <th className="px-3 py-3 text-right font-semibold">
                  Leads novos
                </th>
                <th className="border-line border-l px-3 py-3 text-right font-semibold">
                  Trabalhados
                </th>
                <th className="px-3 py-3 text-right font-semibold">
                  Contatados
                </th>
                <th className="px-3 py-3 text-right font-semibold">Fechados</th>
                <th className="px-3 py-3 text-right font-semibold">
                  Atrasados
                </th>
                <th className="px-3 py-3 font-semibold">Última ação</th>
                <th className="px-5 py-3" />
              </tr>
            </thead>
            <tbody className="divide-line divide-y">
              {rows.map(({ account, usage: row, outcomes }) => (
                <UsageRow
                  key={account.id}
                  account={account}
                  usage={row}
                  outcomes={outcomes}
                />
              ))}
            </tbody>
          </table>
        </div>

        <div className="divide-line divide-y lg:hidden">
          {rows.map(({ account, usage: row, outcomes }) => (
            <UsageCard
              key={account.id}
              account={account}
              usage={row}
              outcomes={outcomes}
            />
          ))}
        </div>
      </section>

      <ActivityFeed
        basePath="/admin/uso-prospector"
        filters={scoped}
        feed={activityFeed(scoped)}
        accounts={accounts}
      />
    </main>
  );
}

function UsageRow({
  account,
  usage,
  outcomes,
}: {
  account: OperatorAccount;
  usage: ProspectorUsage;
  outcomes: OperatorOutcomes;
}) {
  const href = `/admin/uso-prospector/${account.id}`;

  return (
    <tr className="hover:bg-surface-2/60 transition">
      <td className="px-5 py-4">
        <Link href={href} className="hover:text-brand font-medium transition">
          {account.displayName}
        </Link>
        {!account.active && (
          <span className="text-fg-subtle font-normal"> · inativo</span>
        )}
        <p className="text-fg-subtle mt-0.5 text-xs">
          {account.username} · {KIND_LABEL[account.kind]}
          {account.signedIn && " · sessão aberta"}
        </p>
      </td>
      <Number value={usage.searches} strong />
      <Number value={usage.searchesToday} />
      <Number value={usage.leadsInserted} />
      <Number value={outcomes.leadsWorked} strong border />
      <Number value={outcomes.leadsContacted} />
      <Number value={outcomes.leadsWon} />
      {/* The one number on the row that is a problem rather than a measurement,
          so it is the only one that gets colour. */}
      <td
        className={`px-3 py-4 text-right tabular-nums ${
          outcomes.followUpsOverdue > 0 ? "font-semibold text-red-700" : ""
        }`}
      >
        {fmt(outcomes.followUpsOverdue)}
      </td>
      <td className="text-fg-muted px-3 py-4 whitespace-nowrap">
        {sinceLabel(outcomes.lastActivityAt)}
      </td>
      <td className="px-5 py-4 text-right">
        <Link
          href={href}
          aria-label={`Ver detalhes de ${account.displayName}`}
          className="text-fg-subtle hover:text-fg inline-flex transition"
        >
          <ChevronRight className="size-4" />
        </Link>
      </td>
    </tr>
  );
}

function UsageCard({
  account,
  usage,
  outcomes,
}: {
  account: OperatorAccount;
  usage: ProspectorUsage;
  outcomes: OperatorOutcomes;
}) {
  const href = `/admin/uso-prospector/${account.id}`;

  return (
    <Link href={href} className="hover:bg-surface-2/60 block px-5 py-4 transition">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-medium">
            {account.displayName}
            {!account.active && (
              <span className="text-fg-subtle font-normal"> · inativo</span>
            )}
          </p>
          <p className="text-fg-subtle mt-0.5 text-xs">
            {account.username} · {KIND_LABEL[account.kind]}
            {account.signedIn && " · sessão aberta"}
          </p>
        </div>
        <ChevronRight className="text-fg-subtle mt-0.5 size-4 shrink-0" />
      </div>

      <dl className="mt-3 grid grid-cols-4 gap-x-2 gap-y-3 text-center text-sm">
        <CardStat label="Buscas" value={usage.searches} />
        <CardStat label="Trabalhados" value={outcomes.leadsWorked} />
        <CardStat label="Contatados" value={outcomes.leadsContacted} />
        <CardStat label="Fechados" value={outcomes.leadsWon} />
      </dl>

      <p className="text-fg-muted mt-3 text-xs">
        {outcomes.followUpsOverdue > 0 && (
          <span className="font-semibold text-red-700">
            {fmt(outcomes.followUpsOverdue)}{" "}
            {outcomes.followUpsOverdue === 1 ? "atrasado" : "atrasados"} ·{" "}
          </span>
        )}
        última ação {sinceLabel(outcomes.lastActivityAt)}
      </p>
    </Link>
  );
}

function CardStat({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <dt className="text-fg-subtle text-[11px]">{label}</dt>
      <dd className="tnum mt-0.5 font-medium">
        {value === 0 ? <span className="text-fg-subtle">0</span> : fmt(value)}
      </dd>
    </div>
  );
}

function Number({
  value,
  strong,
  border,
}: {
  value: number;
  strong?: boolean;
  border?: boolean;
}) {
  return (
    <td
      className={`px-3 py-4 text-right tabular-nums ${strong ? "font-medium" : ""} ${
        border ? "border-line border-l" : ""
      }`}
    >
      {value === 0 ? <span className="text-fg-subtle">0</span> : fmt(value)}
    </td>
  );
}

function emptyUsage(account: OperatorAccount): ProspectorUsage {
  return {
    actorId: account.id,
    username: account.username,
    displayName: account.displayName,
    searches: 0,
    searchesToday: 0,
    leadsReturned: 0,
    leadsInserted: 0,
    lastSearchAt: null,
  };
}

function Metric({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Search;
  label: string;
  value: number;
}) {
  return (
    <div className="flex items-center gap-3 px-5 py-5">
      <span className="bg-brand/10 text-brand flex size-10 items-center justify-center rounded-xl">
        <Icon className="size-5" />
      </span>
      <div>
        <p className="text-fg-muted text-sm">{label}</p>
        <p className="mt-0.5 text-2xl font-semibold tabular-nums">
          {fmt(value)}
        </p>
      </div>
    </div>
  );
}
