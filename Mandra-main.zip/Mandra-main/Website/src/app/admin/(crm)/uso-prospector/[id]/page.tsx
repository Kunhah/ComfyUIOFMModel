import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  CalendarClock,
  Handshake,
  PauseCircle,
  Search,
  Send,
  Target,
} from "lucide-react";
import { ActivityFeed } from "@/components/admin/activity-feed";
import { parseActivityFilters } from "@/lib/admin/activity";
import { dateTime, fmt, shortDate, sinceLabel } from "@/lib/admin/format";
import { findAccount, KIND_LABEL } from "@/lib/admin/operators";
import { requireAdmin } from "@/lib/auth/server";
import { PERMISSIONS, PERMISSION_LABEL } from "@/lib/auth/session";
import {
  activityFeed,
  EMPTY_OUTCOMES,
  operatorFollowUps,
  operatorOutcomes,
  operatorRecentLeads,
  operatorStalled,
  prospectorUsage,
  type OperatorLead,
} from "@/lib/prospector/db";
import { FUNNEL_LABEL, type FunnelStage } from "@/lib/prospector/types";

export const dynamic = "force-dynamic";

/** Live leads nobody has touched in this long are treated as having stalled. */
const STALLED_AFTER_DAYS = 7;

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const account = findAccount((await params).id);
  return {
    title: account ? `Uso · ${account.displayName}` : "Uso do prospector",
  };
}

/**
 * One person's page.
 *
 * The overview answers "who is working"; this answers "how is this person
 * doing", which needs the three things a table of totals can't hold: what they
 * owe (follow-ups), what they have quietly dropped (stalled leads), and the full
 * audit rather than the most recent slice of it.
 *
 * Deleted accounts still resolve here — their audit outlives the row, and a
 * dead link would make the history look like it never happened.
 */
export default async function OperatorPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  await requireAdmin("/admin/uso-prospector");

  const { id } = await params;
  const account = findAccount(id);
  if (!account) notFound();

  const usage = prospectorUsage(id);
  const outcomes = operatorOutcomes(id)[0] ?? EMPTY_OUTCOMES(id);
  const followUps = operatorFollowUps(id);
  const stalled = operatorStalled(id, STALLED_AFTER_DAYS);
  const recent = operatorRecentLeads(id);

  // The actor is decided by the route, so the URL's own `usuario` is ignored
  // rather than allowed to point the feed at somebody else's history.
  const filters = { ...parseActivityFilters(await searchParams), actorId: id };
  const basePath = `/admin/uso-prospector/${id}`;

  // Won over worked, not over contacted: the denominator people reach for is
  // "leads they had", and a rate computed on the ones they got round to calling
  // flatters exactly the operator who called three.
  const conversion =
    outcomes.leadsWorked > 0
      ? Math.round((outcomes.leadsWon / outcomes.leadsWorked) * 100)
      : null;

  return (
    <main className="mx-auto w-full max-w-[1200px] flex-1 px-5 py-8 md:px-8">
      <Link
        href="/admin/uso-prospector"
        className="text-fg-muted hover:text-fg inline-flex items-center gap-2 text-sm transition"
      >
        <ArrowLeft className="size-4" />
        Uso do prospector
      </Link>

      <div className="mt-3 flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight md:text-[34px]">
            {account.displayName}
          </h1>
          <p className="text-fg-muted mt-1.5 text-sm">
            {account.username} · {KIND_LABEL[account.kind]}
            {account.lastLoginAt &&
              ` · último login ${dateTime(account.lastLoginAt)}`}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Chip tone={account.active ? "good" : "muted"}>
            {account.active ? "Ativo" : "Revogado"}
          </Chip>
          {account.signedIn && <Chip tone="muted">Sessão aberta</Chip>}
          {/* Only for real operator rows: the admin holds everything by
              definition and a deleted account holds nothing to show. */}
          {account.permissions &&
            PERMISSIONS.map((permission) => (
              <Chip
                key={permission}
                tone={
                  account.permissions?.includes(permission) ? "brand" : "off"
                }
              >
                {PERMISSION_LABEL[permission]}
              </Chip>
            ))}
        </div>
      </div>

      {account.kind === "operador" && (
        <p className="text-fg-subtle mt-3 text-sm">
          Permissões e senha ficam em{" "}
          <Link href="/admin/usuarios" className="text-brand hover:underline">
            Acessos
          </Link>
          .
        </p>
      )}

      <div className="mt-7 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        <Metric
          icon={Search}
          label="Buscas"
          value={fmt(usage.totals.searches)}
          note={
            usage.totals.searchesToday > 0
              ? `${fmt(usage.totals.searchesToday)} hoje`
              : "nenhuma hoje"
          }
        />
        <Metric
          icon={Target}
          label="Leads trabalhados"
          value={fmt(outcomes.leadsWorked)}
          note={`${fmt(outcomes.actionsTotal)} ações no total`}
        />
        <Metric
          icon={Send}
          label="Contatados"
          value={fmt(outcomes.leadsContacted)}
          note="conversa aberta no WhatsApp"
        />
        <Metric
          icon={Handshake}
          label="Fechados"
          value={fmt(outcomes.leadsWon)}
          note={
            conversion === null
              ? "sem leads trabalhados ainda"
              : `${conversion}% dos trabalhados · ${fmt(outcomes.leadsLost)} ${
                  outcomes.leadsLost === 1 ? "perdido" : "perdidos"
                }`
          }
        />
        <Metric
          icon={CalendarClock}
          label="Follow-ups atrasados"
          value={fmt(outcomes.followUpsOverdue)}
          note={`${fmt(outcomes.followUpsDue)} vencendo hoje ou antes`}
          alert={outcomes.followUpsOverdue > 0}
        />
        <Metric
          icon={PauseCircle}
          label="Parados"
          value={fmt(stalled.length)}
          note={`em aberto há ${STALLED_AFTER_DAYS}+ dias sem toque`}
          alert={stalled.length > 0}
        />
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-2">
        <LeadList
          title="Follow-ups em aberto"
          description="Só os leads que ainda estão vivos — um follow-up esquecido num lead já fechado é papelada, não compromisso."
          leads={followUps}
          empty="Nenhum follow-up agendado."
          column="follow-up"
        />
        <LeadList
          title={`Parados há ${STALLED_AFTER_DAYS}+ dias`}
          description="Em aberto e sem nenhum toque desta pessoa desde então. É a falha que a lista de follow-ups não pega: nada está atrasado porque nada foi agendado."
          leads={stalled}
          empty="Nada parado. Todo lead em aberto teve movimento recente."
          column="touch"
        />
      </div>

      <LeadList
        title="Leads recentes"
        description="Os últimos leads que esta pessoa moveu, do mais recente para o mais antigo."
        leads={recent}
        empty="Esta pessoa ainda não mexeu em nenhum lead."
        column="touch"
        className="mt-6"
      />

      <ActivityFeed
        basePath={basePath}
        filters={filters}
        feed={activityFeed(filters)}
        title="Histórico completo"
        description="Tudo que esta pessoa fez na ferramenta, filtrável por ação e período."
      />
    </main>
  );
}

function LeadList({
  title,
  description,
  leads,
  empty,
  column,
  className = "",
}: {
  title: string;
  description: string;
  leads: OperatorLead[];
  empty: string;
  /** Which date the right-hand column shows — the promise, or the last touch. */
  column: "follow-up" | "touch";
  className?: string;
}) {
  return (
    <section
      className={`border-line bg-surface overflow-hidden rounded-2xl border ${className}`}
    >
      <div className="border-line border-b px-5 py-4">
        <h2 className="font-semibold">{title}</h2>
        <p className="text-fg-muted mt-1 text-sm">{description}</p>
      </div>
      {leads.length === 0 ? (
        <p className="text-fg-muted px-5 py-8 text-sm">{empty}</p>
      ) : (
        <ul className="divide-line divide-y">
          {leads.map((lead) => {
            // Decided by SQL, so this list and the counter above it can never
            // disagree about whether the same date has passed.
            const overdue = column === "follow-up" && lead.followUpOverdue;
            return (
              <li
                key={lead.id}
                className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5"
              >
                <div className="min-w-0">
                  {/* Straight into the CRM with the lead already filtered for:
                      the point of seeing an overdue follow-up is to go and do
                      something about it. */}
                  <Link
                    href={`/admin?q=${encodeURIComponent(lead.name)}`}
                    className="hover:text-brand font-medium transition"
                  >
                    {lead.name}
                  </Link>
                  <p className="text-fg-subtle mt-0.5 text-xs">
                    {[
                      lead.city && lead.uf
                        ? `${lead.city}/${lead.uf}`
                        : lead.city,
                      FUNNEL_LABEL[lead.funnelStage as FunnelStage] ??
                        lead.funnelStage,
                    ]
                      .filter(Boolean)
                      .join(" · ")}
                  </p>
                </div>
                <p
                  className={`text-sm whitespace-nowrap ${
                    overdue ? "font-semibold text-red-700" : "text-fg-muted"
                  }`}
                >
                  {column === "follow-up"
                    ? `${overdue ? "venceu " : "para "}${shortDate(lead.nextFollowUpAt)}`
                    : sinceLabel(lead.lastTouchedAt)}
                </p>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}

function Metric({
  icon: Icon,
  label,
  value,
  note,
  alert,
}: {
  icon: typeof Search;
  label: string;
  value: string;
  note: string;
  alert?: boolean;
}) {
  return (
    <div className="border-line bg-surface flex items-start gap-3 rounded-2xl border px-5 py-5">
      <span
        className={`flex size-10 shrink-0 items-center justify-center rounded-xl ${
          alert ? "bg-red-50 text-red-700" : "bg-brand/10 text-brand"
        }`}
      >
        <Icon className="size-5" />
      </span>
      <div className="min-w-0">
        <p className="text-fg-muted text-sm">{label}</p>
        <p className="mt-0.5 text-2xl font-semibold tabular-nums">{value}</p>
        <p className="text-fg-subtle mt-0.5 text-xs">{note}</p>
      </div>
    </div>
  );
}

function Chip({
  tone,
  children,
}: {
  tone: "good" | "brand" | "muted" | "off";
  children: React.ReactNode;
}) {
  const tones = {
    good: "border-emerald-300 bg-emerald-50 text-emerald-800",
    brand: "border-brand/40 bg-brand/10 text-brand",
    muted: "border-line bg-surface-2 text-fg-muted",
    off: "border-line bg-surface-2 text-fg-subtle line-through",
  } as const;
  return (
    <span
      className={`rounded-full border px-2.5 py-1 text-xs font-medium ${tones[tone]}`}
    >
      {children}
    </span>
  );
}
