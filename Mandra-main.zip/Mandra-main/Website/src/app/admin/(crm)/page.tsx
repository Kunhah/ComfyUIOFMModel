import Link from "next/link";
import {
  CalendarClock,
  Download,
  Filter,
  MessageSquareReply,
  Search,
  Send,
  Tag,
  UsersRound,
  X,
} from "lucide-react";
import { LeadTable, type CrmLead } from "@/components/admin/lead-table";
import { nicheLabel, toCrmRow } from "@/lib/crm/rows";
import { callActor } from "@/lib/prospector/ownership";
import { accountNames } from "@/lib/crm/accounts";
import { CreateCallListButton } from "@/components/admin/create-call-list";
import { CallsToday } from "@/components/admin/calls-today";
import {
  callsToday,
  callsTodayTotal,
  DEFAULT_DAILY_TARGET,
} from "@/lib/prospector/calls";
import { countryLabel } from "@/lib/countries";
import { can, requireAdmin, scopeFor } from "@/lib/auth/server";
import { countActive } from "@/lib/auth/users";
import {
  SCOPE_TUDO,
  filtersToQuery,
  historyFacets,
  nicheBreakdown,
  parseFilters,
  queryHistory,
  type HistoryFilters,
} from "@/lib/prospector/history";
import { NICHES, nichesByGroup } from "@/lib/prospector/niches";
import { outreachMessage, whatsappUrl } from "@/lib/prospector/score";
import { outreachContextFor } from "@/lib/prospector/templates-store";
import { FUNNEL_LABEL, type FunnelStage } from "@/lib/prospector/types";

/**
 * The CRM.
 *
 * `/prospector` finds businesses and `/prospector/historico` lists what it has
 * found; this is where they get worked. The whole view — filters, page, page
 * size — lives in the query string, so a screen is a URL you can bookmark or
 * send to someone, and the filter bar is a plain GET form that works before any
 * JavaScript loads. Only the pipeline edits are client-side, because they POST.
 *
 * Reads the same SQLite history the prospector writes, so there is no second
 * store to keep in sync: a search fills the CRM by running.
 */

export const dynamic = "force-dynamic";

const PER_PAGE = [10, 25, 50, 100];
const DEFAULT_PER_PAGE = 25;

/** Every stage where the conversation is still open. */
const LIVE_STAGES: FunnelStage[] = [
  "contato",
  "qualificado",
  "proposta",
  "negociacao",
];
const CLOSING_STAGES: FunnelStage[] = ["proposta", "negociacao"];

const SORTS = [
  { value: "score", label: "Maior score" },
  { value: "recent", label: "Mais recentes" },
  { value: "followup", label: "Follow-up mais próximo" },
  { value: "name", label: "Nome (A-Z)" },
  { value: "oldest", label: "Mais antigos" },
];

const fmt = (value: number) => value.toLocaleString("pt-BR");
const plural = (count: number, one: string, many: string) =>
  count === 1 ? one : many;

export default async function CrmPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  // A layout doesn't re-run on client navigations, so the page checks for
  // itself rather than trusting the shell above it.
  const user = await requireAdmin("/admin");

  const filters = parseFilters(await searchParams, scopeFor(user));
  const perPage = filters.perPage ?? DEFAULT_PER_PAGE;

  const facets = historyFacets(filters);
  const results = queryHistory({ ...filters, perPage });
  const byNiche = nicheBreakdown(filters);

  // Deliberately *not* filter-scoped, unlike every other number on this screen.
  // "How much calling happened today" is a question about the day, and answering
  // it through whatever filter is on the bar would make the team's output change
  // when somebody ticks a niche.
  const dialled = callsTodayTotal();
  const perOperator = callsToday();

  // The team's target is a day's work per *account that could dial*, not per
  // account that already has. Deriving it from who has called would shrink the
  // denominator at 9am and grow it through the morning, so the bar would slide
  // backwards every time somebody else started — the one thing a progress bar
  // must never do. The floor of one covers the admin working alone, who has no
  // row in `users` at all.
  const teamTarget = DEFAULT_DAILY_TARGET * Math.max(1, countActive());

  // Flattened by the shared mapper so /app renders identical rows — see
  // lib/crm/rows.ts for why this is not inlined here any more.
  // The viewer is passed explicitly (never as `.map(toCrmRow)` — that hands the
  // array index in as the second argument). It decides which rows have their
  // contact actions closed off; an admin's are never closed. See ownership.ts.
  // Read once for the whole table. Every wa.me link on the page is rendered
  // from it, so an edit made on /admin/mensagens shows up on the next refresh
  // rather than on the next deploy — and it is *this* admin's copy, not a
  // colleague's, which is what makes the message personal.
  const outreach = outreachContextFor(user);
  const rows: CrmLead[] = results.leads.map((lead) =>
    toCrmRow(lead, callActor(user), outreach),
  );

  // What the ?conta= narrowing is currently pointed at, for the banner below.
  // Resolved to a name rather than shown as an id: an id in the chrome tells
  // the reader nothing and looks like a bug.
  const viewing =
    filters.scope.kind === "atlas"
      ? "leads da própria Atlas"
      : filters.scope.kind === "conta"
        ? (accountNames().get(filters.scope.id) ?? "uma conta removida")
        : null;

  const stageTotal = (stages: FunnelStage[]) =>
    facets.byStage
      .filter((entry) => stages.includes(entry.stage))
      .reduce((sum, entry) => sum + entry.count, 0);

  /** A link to this view with some filters changed, always back on page 1. */
  const view = (overrides: Partial<HistoryFilters>) =>
    `/admin${filtersToQuery(filters, { ...overrides, page: 1 })}`;

  const selectedTags = filters.tags ?? [];
  const filtered = hasFilters(filters);
  const emptyDatabase = facets.total === 0 && !filtered;

  return (
    <main className="mx-auto w-full max-w-[1400px] flex-1 px-5 py-8 md:px-8">
      <div className="flex flex-wrap items-start justify-between gap-5">
        <div>
          <p className="text-brand text-xs font-semibold tracking-[0.16em]">
            CRM MANDRA
          </p>
          <h1 className="mt-1.5 text-3xl font-semibold tracking-tight md:text-[34px]">
            Visão geral
          </h1>
          <p className="text-fg-muted mt-2 text-sm">
            Todos os leads encontrados pela prospecção, prontos para trabalhar.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Queues whatever the filter bar currently describes — every match,
              not the page on screen: the route re-runs the filter server-side.
              This is the path that makes a list "automatic"; the query-string
              box on /admin/ligacoes is the manual fallback behind it. */}
          <CreateCallListButton
            filters={filtersToQuery(filters, { page: 1 })}
            count={facets.total}
          />
          {/* Hidden without the grant. The route behind it checks the same
              permission, so this is only about not offering a dead button. */}
          {can(user, "export") && (
            <a
              href={`/api/prospector/history/export${filtersToQuery(filters, { page: 1 })}`}
              className="border-line bg-surface hover:border-line-strong inline-flex items-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-medium transition"
            >
              <Download className="size-4" />
              Exportar {filtered ? `seleção (${fmt(facets.total)})` : "CSV"}
            </a>
          )}
          <Link
            href="/admin/prospector"
            className="inline-flex items-center gap-2 rounded-xl bg-[#1d2228] px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-black"
          >
            <Search className="size-4" />
            Buscar leads
          </Link>
        </div>
      </div>

      {/* When the view is narrowed to one account, say so. A filtered list with
          no indication of *why* is how you read a client's pipeline as the
          whole base and conclude the week was terrible. */}
      {viewing && (
        <div className="border-brand bg-surface mt-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl border p-4">
          <p className="text-sm">
            Vendo apenas <strong>{viewing}</strong>.
          </p>
          <Link
            href={`/admin${filtersToQuery(filters, { scope: SCOPE_TUDO, page: 1 })}`}
            className="text-brand text-sm font-medium underline"
          >
            Ver todos os leads
          </Link>
        </div>
      )}

      {emptyDatabase ? (
        <EmptyDatabase />
      ) : (
        <>
          {/* The day's calling, above the base counters: on a hundred-a-day
              operation this is the number that decides what the afternoon looks
              like, and the size of the base is the number that changes slowest. */}
          <div className="mt-7">
            <CallsToday
              calls={dialled.calls}
              reached={dialled.reached}
              target={teamTarget}
              breakdown={perOperator}
              label="Ligações hoje (equipe)"
            />
          </div>

          <div className="border-line bg-surface mt-4 grid divide-y overflow-hidden rounded-2xl border sm:grid-cols-2 sm:divide-x sm:divide-y-0 xl:grid-cols-4">
            <Metric
              icon={UsersRound}
              label="Leads na base"
              value={facets.total}
              note={
                facets.addedToday > 0
                  ? `+${fmt(facets.addedToday)} hoje`
                  : "nenhum novo hoje"
              }
              accent={facets.addedToday > 0}
            />
            <Metric
              icon={Send}
              label="Em contato"
              value={stageTotal(LIVE_STAGES)}
              note={
                facets.contactedToday > 0
                  ? `${fmt(facets.contactedToday)} ${plural(facets.contactedToday, "abordado", "abordados")} hoje`
                  : "nenhum abordado hoje"
              }
              accent={facets.contactedToday > 0}
            />
            <Metric
              icon={MessageSquareReply}
              label="Fechando"
              value={stageTotal(CLOSING_STAGES)}
              note="proposta ou negociação"
              href={view({ stage: "negociacao" })}
            />
            <Metric
              icon={CalendarClock}
              label="Follow-ups"
              value={facets.due}
              note={
                facets.overdue > 0
                  ? `${fmt(facets.overdue)} ${plural(facets.overdue, "atrasado", "atrasados")}`
                  : "em dia"
              }
              accent={facets.overdue > 0}
              href={view({ onlyDue: true, sort: "followup" })}
            />
          </div>

          {/* The funnel doubles as the stage filter — the counts are the funnel,
              and clicking one is how you work that stage. In funnel order, not
              count order, and every stage shown even at zero: the empty stage is
              usually the thing worth noticing. */}
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <Chip href={view({ stage: undefined })} active={!filters.stage}>
              Todos ({fmt(facets.byStage.reduce((sum, s) => sum + s.count, 0))})
            </Chip>
            {facets.byStage.map(({ stage, count }) => (
              <Chip
                key={stage}
                href={view({ stage })}
                active={filters.stage === stage}
              >
                {FUNNEL_LABEL[stage]} ({fmt(count)})
              </Chip>
            ))}
          </div>

          {/* The operator's own axis, beside the funnel's. Only rendered once
              something has been labelled — an empty row of nothing would just
              be a permanent reminder of a feature. Selecting two narrows to the
              leads carrying both, so this is a toggle, not a radio. */}
          {facets.tags.length > 0 && (
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <span className="text-fg-subtle inline-flex items-center gap-1.5 text-xs font-medium">
                <Tag className="size-3.5" />
                Etiquetas
              </span>
              {facets.tags.map(({ tag, count }) => {
                const active = selectedTags.includes(tag);
                return (
                  <Chip
                    key={tag}
                    href={view({
                      tags: active
                        ? selectedTags.filter((t) => t !== tag)
                        : [...selectedTags, tag],
                    })}
                    active={active}
                  >
                    {tag} ({fmt(count)})
                  </Chip>
                );
              })}
              {selectedTags.length > 0 && (
                <Link
                  href={view({ tags: [] })}
                  className="text-fg-muted hover:text-fg inline-flex items-center gap-1 text-xs"
                >
                  <X className="size-3.5" />
                  limpar etiquetas
                </Link>
              )}
            </div>
          )}

          {/* GET, so applying a filter only changes the URL. `page` is
              deliberately not a field: a new filter starts at page 1. */}
          <form
            method="GET"
            action="/admin"
            className="border-line bg-surface mt-4 rounded-2xl border p-4"
          >
            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-[1.4fr_1fr_1fr_1fr_auto]">
              <Field label="Buscar">
                <div className="relative">
                  <Search className="text-fg-subtle pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2" />
                  <input
                    name="q"
                    defaultValue={filters.q ?? ""}
                    placeholder="Empresa ou endereço"
                    className="border-line bg-surface-2 focus:border-brand w-full rounded-lg border py-2.5 pr-3 pl-9 text-sm outline-none"
                  />
                </div>
              </Field>
              <Field label="Segmento">
                <select
                  name="niche"
                  defaultValue={filters.niche ?? ""}
                  className="border-line bg-surface-2 focus:border-brand w-full rounded-lg border px-3 py-2.5 text-sm outline-none"
                >
                  <option value="">Todos os segmentos</option>
                  {nichesByGroup().map((group) => {
                    // Only niches with leads in them. A dropdown of 33 where most
                    // options select nothing is worse than a short honest one.
                    const present = group.niches.filter((niche) =>
                      facets.niches.some((f) => f.niche === niche.slug),
                    );
                    if (present.length === 0) return null;
                    return (
                      <optgroup key={group.group} label={group.group}>
                        {present.map((niche) => (
                          <option key={niche.slug} value={niche.slug}>
                            {niche.label} (
                            {fmt(
                              facets.niches.find((f) => f.niche === niche.slug)
                                ?.count ?? 0,
                            )}
                            )
                          </option>
                        ))}
                      </optgroup>
                    );
                  })}
                </select>
              </Field>
              <Field label="Localização">
                <select
                  name="city"
                  defaultValue={filters.city ?? ""}
                  className="border-line bg-surface-2 focus:border-brand w-full rounded-lg border px-3 py-2.5 text-sm outline-none"
                >
                  <option value="">Todas as cidades</option>
                  {facets.cities.map((city) => (
                    <option key={`${city.city}-${city.uf}`} value={city.city}>
                      {city.city} — {city.uf} ({fmt(city.count)})
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Ordenar por">
                <select
                  name="sort"
                  defaultValue={filters.sort ?? "score"}
                  className="border-line bg-surface-2 focus:border-brand w-full rounded-lg border px-3 py-2.5 text-sm outline-none"
                >
                  {SORTS.map((sort) => (
                    <option key={sort.value} value={sort.value}>
                      {sort.label}
                    </option>
                  ))}
                </select>
              </Field>
              <button
                type="submit"
                className="mt-auto inline-flex items-center justify-center gap-2 rounded-lg bg-[#1d2228] px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-black"
              >
                <Filter className="size-4" />
                Filtrar
              </button>
            </div>

            <div className="mt-3.5 flex flex-wrap items-center gap-x-5 gap-y-2.5 text-sm">
              {/* The funnel stage lives in the chips above, but it has to ride
                  along in the form too or applying a text filter would silently
                  drop it. */}
              {filters.stage && (
                <input type="hidden" name="stage" value={filters.stage} />
              )}
              {filters.status && (
                <input type="hidden" name="status" value={filters.status} />
              )}
              {/* Same reason as the stage above: the chips write these into the
                  URL, and without them here the form would drop the selection
                  the moment someone typed a search term. */}
              {selectedTags.map((tag) => (
                <input key={tag} type="hidden" name="tag" value={tag} />
              ))}
              <Toggle name="nosite" checked={filters.onlyNoSite}>
                Só quem não tem site
              </Toggle>
              <Toggle name="wa" checked={filters.onlyWhatsapp}>
                Só com WhatsApp
              </Toggle>
              {/* The phone-quality filter. Worth its own toggle rather than
                  being folded into the score: a great business on a switchboard
                  number is a great business you cannot reach, and those are two
                  different reasons to skip a row. */}
              <Toggle name="telbom" checked={filters.onlyGoodPhone}>
                Só telefone confiável
              </Toggle>
              <Toggle name="due" checked={filters.onlyDue}>
                Follow-up pendente
              </Toggle>
              <label className="text-fg-muted ml-auto flex items-center gap-2 text-xs">
                Por página
                <select
                  name="per"
                  defaultValue={String(perPage)}
                  className="border-line bg-surface-2 focus:border-brand rounded-lg border px-2 py-1.5 text-xs outline-none"
                >
                  {PER_PAGE.map((size) => (
                    <option key={size} value={size}>
                      {size}
                    </option>
                  ))}
                </select>
              </label>
              {filtered && (
                <Link
                  href="/admin"
                  className="text-fg-muted hover:text-fg inline-flex items-center gap-1 text-xs"
                >
                  <X className="size-3.5" />
                  limpar filtros
                </Link>
              )}
            </div>
          </form>

          <section className="border-line bg-surface mt-4 overflow-hidden rounded-2xl border">
            <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
              <div>
                <h2 className="text-lg font-semibold">Leads encontrados</h2>
                <p className="text-fg-muted mt-0.5 text-sm">
                  {results.total === 0
                    ? "Nenhum lead nesta seleção"
                    : `Mostrando ${fmt(rangeStart(results))}–${fmt(rangeEnd(results))} de ${fmt(results.total)}`}
                </p>
              </div>
              <p className="text-fg-subtle text-xs">
                {facets.noSite > 0 && `${fmt(facets.noSite)} sem site · `}
                {fmt(facets.whatsapp)} com WhatsApp
              </p>
            </div>

            {rows.length === 0 ? (
              <div className="border-line border-t px-5 py-16 text-center">
                <Search className="text-brand mx-auto size-7" />
                <p className="mt-4 font-medium">Nenhum lead nesta seleção</p>
                <p className="text-fg-muted mt-1 text-sm">
                  Afrouxe os filtros ou faça uma nova busca para ampliar a base.
                </p>
                <Link
                  href="/admin"
                  className="text-brand mt-5 inline-flex text-sm font-semibold hover:underline"
                >
                  Limpar filtros
                </Link>
              </div>
            ) : (
              // canRelease: the admin is the only role that can hand a lead back
              // to the team — see ownership.ts on why that escape hatch exists.
              <LeadTable leads={rows} canRelease={user.role === "admin"} />
            )}

            {results.pages > 1 && (
              <nav className="border-line text-fg-muted flex flex-wrap items-center justify-between gap-3 border-t px-5 py-3.5 text-sm">
                <span>
                  Página {fmt(results.page)} de {fmt(results.pages)}
                </span>
                <span className="flex gap-2">
                  {results.page > 1 && (
                    <Link
                      href={`/admin${filtersToQuery(filters, { perPage, page: results.page - 1 })}`}
                      className="border-line hover:border-line-strong rounded-lg border px-3 py-2.5 sm:py-1.5"
                    >
                      Anterior
                    </Link>
                  )}
                  {results.page < results.pages && (
                    <Link
                      href={`/admin${filtersToQuery(filters, { perPage, page: results.page + 1 })}`}
                      className="border-line hover:border-line-strong rounded-lg border px-3 py-2.5 sm:py-1.5"
                    >
                      Próxima
                    </Link>
                  )}
                </span>
              </nav>
            )}
          </section>

          {byNiche.length > 1 && (
            <details className="border-line bg-surface mt-4 rounded-2xl border">
              <summary className="cursor-pointer px-5 py-4 text-sm font-semibold">
                Por segmento{" "}
                <span className="text-fg-muted font-normal">
                  ({fmt(byNiche.length)})
                </span>
              </summary>
              <div className="hidden overflow-x-auto sm:block">
                <table className="w-full min-w-[560px] text-left text-sm">
                  <thead className="bg-surface-2 text-fg-muted border-line border-y text-xs font-medium">
                    <tr>
                      <th className="px-5 py-2.5">Segmento</th>
                      <th className="px-3 py-2.5 text-right">Leads</th>
                      <th className="px-3 py-2.5 text-right">Sem site</th>
                      <th className="px-3 py-2.5 text-right">WhatsApp</th>
                      <th className="px-3 py-2.5 text-right">Trabalhados</th>
                      <th className="px-5 py-2.5" />
                    </tr>
                  </thead>
                  <tbody className="divide-line divide-y">
                    {byNiche.map((niche) => (
                      <tr key={niche.niche}>
                        <td className="px-5 py-2.5 font-medium">
                          {nicheLabel(niche.niche)}
                        </td>
                        <td className="tnum px-3 py-2.5 text-right">
                          {fmt(niche.total)}
                        </td>
                        <td className="tnum px-3 py-2.5 text-right">
                          {fmt(niche.noSite)}
                        </td>
                        <td className="tnum text-fg-muted px-3 py-2.5 text-right">
                          {fmt(niche.whatsapp)}
                        </td>
                        <td className="tnum text-fg-muted px-3 py-2.5 text-right">
                          {niche.worked > 0 ? fmt(niche.worked) : "—"}
                        </td>
                        <td className="px-5 py-2.5 text-right">
                          <Link
                            href={view({ niche: niche.niche })}
                            className="text-brand text-xs hover:underline"
                          >
                            abrir
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="divide-line divide-y sm:hidden">
                {byNiche.map((niche) => (
                  <div key={niche.niche} className="px-5 py-3.5">
                    <div className="flex items-center justify-between gap-3">
                      <span className="font-medium">
                        {nicheLabel(niche.niche)}
                      </span>
                      <Link
                        href={view({ niche: niche.niche })}
                        className="text-brand shrink-0 text-xs hover:underline"
                      >
                        abrir
                      </Link>
                    </div>
                    <p className="text-fg-muted mt-1 text-xs">
                      <span className="tnum">{fmt(niche.total)}</span> leads ·{" "}
                      <span className="tnum">{fmt(niche.noSite)}</span> sem site
                      · <span className="tnum">{fmt(niche.whatsapp)}</span>{" "}
                      WhatsApp
                      {niche.worked > 0 &&
                        ` · ${fmt(niche.worked)} trabalhados`}
                    </p>
                  </div>
                ))}
              </div>
            </details>
          )}
        </>
      )}
    </main>
  );
}

function EmptyDatabase() {
  return (
    <div className="border-line bg-surface mt-7 rounded-2xl border px-5 py-20 text-center">
      <Search className="text-brand mx-auto size-8" />
      <h2 className="mt-4 text-lg font-semibold">Seu CRM ainda está vazio</h2>
      <p className="text-fg-muted mx-auto mt-2 max-w-md text-sm leading-6">
        Todo negócio encontrado em uma busca entra aqui automaticamente, com
        etapa, follow-up e anotações. Faça a primeira busca para começar.
      </p>
      <Link
        href="/prospector"
        className="mt-6 inline-flex items-center gap-2 rounded-xl bg-[#1d2228] px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-black"
      >
        <Search className="size-4" />
        Buscar leads
      </Link>
    </div>
  );
}

function Metric({
  icon: Icon,
  label,
  value,
  note,
  accent,
  href,
}: {
  icon: typeof UsersRound;
  label: string;
  value: number;
  note: string;
  accent?: boolean;
  href?: string;
}) {
  const body = (
    <div className="flex items-center gap-3.5 px-5 py-5">
      <span className="bg-brand/10 text-brand flex size-11 shrink-0 items-center justify-center rounded-xl">
        <Icon className="size-5" />
      </span>
      <div className="min-w-0">
        <p className="text-fg-muted text-xs">{label}</p>
        <p className="tnum mt-0.5 text-2xl font-semibold tracking-tight">
          {fmt(value)}
        </p>
        <p
          className={`mt-0.5 text-xs ${accent ? "text-brand font-medium" : "text-fg-subtle"}`}
        >
          {note}
        </p>
      </div>
    </div>
  );

  return href ? (
    <Link href={href} className="hover:bg-surface-2 transition">
      {body}
    </Link>
  ) : (
    body
  );
}

function Chip({
  href,
  active,
  children,
}: {
  href: string;
  active: boolean;
  children: React.ReactNode;
}) {
  return (
    <Link
      href={href}
      aria-current={active ? "true" : undefined}
      className={`rounded-full border px-3.5 py-1.5 text-xs font-medium transition ${
        active
          ? "border-transparent bg-[#1d2228] text-white"
          : "border-line bg-surface text-fg-muted hover:border-line-strong hover:text-fg"
      }`}
    >
      {children}
    </Link>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="text-fg-muted block text-xs font-medium">
      <span className="mb-1.5 block">{label}</span>
      {children}
    </label>
  );
}

function Toggle({
  name,
  checked,
  children,
}: {
  name: string;
  checked?: boolean;
  children: React.ReactNode;
}) {
  return (
    <label className="flex cursor-pointer items-center gap-2">
      <input
        type="checkbox"
        name={name}
        value="1"
        defaultChecked={checked}
        className="accent-brand size-4"
      />
      {children}
    </label>
  );
}

function hasFilters(filters: HistoryFilters): boolean {
  return Boolean(
    filters.q ||
    filters.niche ||
    filters.city ||
    filters.uf ||
    filters.status ||
    filters.stage ||
    filters.onlyNoSite ||
    filters.onlyWhatsapp ||
    filters.onlyGoodPhone ||
    filters.onlyDue ||
    (filters.tags?.length ?? 0) > 0 ||
    filters.minScore,
  );
}

const rangeStart = (page: { page: number; perPage: number }) =>
  (page.page - 1) * page.perPage + 1;

const rangeEnd = (page: { page: number; perPage: number; total: number }) =>
  Math.min(page.page * page.perPage, page.total);
