import { requireAdmin } from "@/lib/auth/server";
import { CallResults } from "@/components/admin/call-results";
import { FunnelBoard } from "@/components/admin/funnel-board";
import { AddFunnelLead } from "@/components/admin/add-funnel-lead";
import { FunnelSearch } from "@/components/admin/funnel-search";
import {
  callResultStats,
  callStatsByNiche,
  funnelBoard,
} from "@/lib/prospector/funnel";
import { SCOPE_ATLAS } from "@/lib/prospector/history";
import { NICHES } from "@/lib/prospector/niches";

/**
 * The pipeline board, and what the phone did to it.
 *
 * Two halves of one question. The stats say what comes back when we dial; the
 * board says where that left every lead. They share a screen because reading
 * either alone invites the wrong move — a great reach rate means nothing if
 * nothing reached "proposta", and an empty "negociação" is only alarming once
 * you know how many calls were behind it.
 *
 * SCOPE. Fixed to `SCOPE_ATLAS`: this is Atlas's own cold-calling pipeline, not
 * a client's. That is the conservative end of the new `LeadScope` — it excludes
 * client-account leads rather than including them — and it is deliberately not
 * read from the query string, because a board that can be re-pointed at another
 * account by editing a URL is the leak the scope was introduced to close.
 */

export const dynamic = "force-dynamic";
export const metadata = {
  title: "Funil",
  robots: { index: false, follow: false },
};

export default async function FunnelPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  await requireAdmin("/admin/funil");

  const raw = (await searchParams).q;
  const search = (Array.isArray(raw) ? raw[0] : raw)?.slice(0, 120) ?? "";

  const scope = SCOPE_ATLAS;
  // Only the board narrows. The call stats answer "what comes back when we
  // dial", which is a question about the whole operation — filtering them by
  // whatever is typed in the box would turn a benchmark into a sample of one.
  const { columns, limit } = funnelBoard({ scope, search });
  const stats = callResultStats(scope);
  const byNiche = callStatsByNiche(scope);

  // Resolved here so the niche registry stays on the server, the same way the
  // CRM table receives labels rather than slugs.
  const nicheLabels = Object.fromEntries(
    NICHES.map((niche) => [niche.slug, niche.label]),
  );

  const included = columns.reduce((sum, column) => sum + column.total, 0);

  return (
    <main className="mx-auto w-full max-w-[1400px] flex-1 px-5 py-8 md:px-8">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-brand text-xs font-semibold tracking-[0.16em]">
            CRM MANDRA
          </p>
          <h1 className="mt-1.5 text-3xl font-semibold tracking-tight md:text-[34px]">
            Funil
          </h1>
          <p className="text-fg-muted mt-2 text-sm">
            {search
              ? included > 0
                ? `${included.toLocaleString("pt-BR")} ${included === 1 ? "lead encontrado" : "leads encontrados"} para “${search}”.`
                : `Nenhum lead do funil corresponde a “${search}”.`
              : included > 0
                ? `${included.toLocaleString("pt-BR")} ${included === 1 ? "lead no funil" : "leads no funil"}. Arraste um card para mudar a etapa.`
                : "O funil está vazio. Adicione um lead para começar."}
          </p>
        </div>
        <AddFunnelLead nicheLabels={nicheLabels} />
      </div>

      <div className="mt-5">
        <FunnelSearch value={search} />
      </div>

      <div className="mt-7">
        <CallResults
          stats={stats}
          byNiche={byNiche}
          nicheLabels={nicheLabels}
        />
      </div>

      <div className="mt-6">
        <FunnelBoard
          columns={columns}
          limit={limit}
          nicheLabels={nicheLabels}
        />
      </div>
    </main>
  );
}
