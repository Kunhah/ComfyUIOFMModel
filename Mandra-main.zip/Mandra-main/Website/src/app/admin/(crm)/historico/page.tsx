import { HistoryPage } from "@/app/prospector/historico/page";

export const dynamic = "force-dynamic";

/** The prospector's complete history, kept in the CRM shell. */
export default async function AdminHistoryPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  return (
    <HistoryPage
      searchParams={searchParams}
      basePath="/admin/historico"
      searchHref="/admin/prospector"
    />
  );
}
