import { requireAdmin } from "@/lib/auth/server";
import { llmConfigured } from "@/lib/ai/providers";
import { priced } from "@/lib/ai/cost";
import { describeSkill, unknownSkills } from "@/lib/ai/registry";
import {
  recentRuns,
  RUN_STATE_LABEL,
  usageBySkill,
  type RunState,
} from "@/lib/ai/db";
import { accountNames } from "@/lib/crm/accounts";

/**
 * What the models cost us, and which of them is answering.
 *
 * The screen exists because until `ai_runs` there was no way to answer either
 * question: the invoice arrives once, in dollars, with no account on it, and
 * "which provider replied" was only ever visible on a meeting review. Cost per
 * account per month is the number that decides what this can be priced at.
 *
 * Two tables, deliberately. The totals are what gets checked monthly; the tail
 * is what gets read when something looks wrong — and a failure is much easier to
 * see next to the run before it than aggregated into a percentage.
 */

export const dynamic = "force-dynamic";
export const metadata = { title: "IA" };

const STATE_TONE: Record<RunState, string> = {
  ok: "text-fg-muted",
  invalido: "text-amber-500",
  erro: "text-red-500",
  recusado: "text-amber-500",
};

const brl = (value: number): string =>
  value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

export default async function IaPage() {
  await requireAdmin("/admin/ia");

  const usage = usageBySkill();
  const runs = recentRuns(60);
  const names = accountNames();
  const configured = llmConfigured();
  const quota = Number(process.env.AI_QUOTA_BRL?.trim());

  const total = usage.reduce((sum, row) => sum + row.custoBrl, 0);
  // Ids in the log that the registry does not describe. Not an error — a skill
  // can be removed while its history stays readable — but worth showing, because
  // the other cause is a typo in a `runCompletion()` call that has been silently
  // splitting one skill's spend into two rows.
  const undescribed = unknownSkills(usage.map((row) => row.skill));

  return (
    <main className="mx-auto w-full max-w-[1100px] flex-1 px-5 py-8 md:px-8">
      <p className="text-brand text-xs font-semibold tracking-[0.16em]">
        INFRAESTRUTURA
      </p>
      <h1 className="mt-1.5 text-3xl font-semibold tracking-tight md:text-[34px]">
        IA
      </h1>
      <p className="text-fg-muted mt-2 text-sm">
        Toda chamada a um modelo passa por <code>runSkill()</code> ou{" "}
        <code>runCompletion()</code> e deixa uma linha aqui — inclusive as que
        falharam. O custo é estimado por uma tabela de preços no repositório,
        não pela fatura do provedor.
      </p>

      {!configured && (
        <p className="border-line bg-surface text-fg-muted mt-6 rounded-lg border px-4 py-3 text-sm">
          Nenhum provedor configurado. Defina <code>GROQ_API_KEY</code>,{" "}
          <code>OPENROUTER_API_KEY</code> ou <code>ANTHROPIC_API_KEY</code> —
          sem isso o assistente não responde e a análise de reunião não roda.
        </p>
      )}

      <section className="mt-8">
        <div className="flex items-baseline justify-between gap-4">
          <h2 className="text-lg font-semibold">Por skill, este mês e antes</h2>
          <p className="text-fg-muted text-sm">
            Total {brl(total)}
            {Number.isFinite(quota) && quota > 0
              ? ` · teto por conta ${brl(quota)}/mês`
              : " · sem teto configurado"}
          </p>
        </div>

        {usage.length === 0 ? (
          <p className="text-fg-muted mt-3 text-sm">
            Nenhuma execução registrada ainda.
          </p>
        ) : (
          <div className="border-line mt-3 overflow-x-auto rounded-lg border">
            <table className="w-full min-w-[720px] text-sm">
              <thead className="text-fg-muted border-line border-b text-left text-xs">
                <tr>
                  <th className="px-4 py-2.5 font-medium">Skill</th>
                  <th className="px-4 py-2.5 font-medium">Execuções</th>
                  <th className="px-4 py-2.5 font-medium">Falhas</th>
                  <th className="px-4 py-2.5 font-medium">Latência média</th>
                  <th className="px-4 py-2.5 font-medium">Custo</th>
                </tr>
              </thead>
              <tbody>
                {usage.map((row) => {
                  const info = describeSkill(row.skill);
                  return (
                    <tr
                      key={row.skill}
                      className="border-line border-b last:border-0"
                    >
                      <td className="px-4 py-2.5">
                        <span className="font-medium">{row.skill}</span>
                        <span className="text-fg-muted block text-xs">
                          {info?.purpose ?? "Não descrita no registry."}
                        </span>
                      </td>
                      <td className="px-4 py-2.5">{row.runs}</td>
                      <td
                        className={
                          row.falhas > 0
                            ? "px-4 py-2.5 text-amber-500"
                            : "text-fg-muted px-4 py-2.5"
                        }
                      >
                        {row.falhas}
                      </td>
                      <td className="text-fg-muted px-4 py-2.5">
                        {(row.latenciaMediaMs / 1000).toFixed(1)}s
                      </td>
                      <td className="px-4 py-2.5">{brl(row.custoBrl)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {undescribed.length > 0 && (
          <p className="text-fg-muted mt-3 text-xs">
            Sem descrição no registry: {undescribed.join(", ")}. Ou a skill foi
            removida, ou o id foi digitado errado em algum{" "}
            <code>runCompletion()</code>.
          </p>
        )}
      </section>

      <section className="mt-10">
        <h2 className="text-lg font-semibold">Últimas execuções</h2>
        {runs.length === 0 ? (
          <p className="text-fg-muted mt-3 text-sm">Nada ainda.</p>
        ) : (
          <div className="border-line mt-3 overflow-x-auto rounded-lg border">
            <table className="w-full min-w-[860px] text-sm">
              <thead className="text-fg-muted border-line border-b text-left text-xs">
                <tr>
                  <th className="px-4 py-2.5 font-medium">Quando</th>
                  <th className="px-4 py-2.5 font-medium">Skill</th>
                  <th className="px-4 py-2.5 font-medium">Conta</th>
                  <th className="px-4 py-2.5 font-medium">Assunto</th>
                  <th className="px-4 py-2.5 font-medium">Modelo</th>
                  <th className="px-4 py-2.5 font-medium">Custo</th>
                  <th className="px-4 py-2.5 font-medium">Estado</th>
                </tr>
              </thead>
              <tbody>
                {runs.map((row) => (
                  <tr
                    key={row.id}
                    className="border-line border-b last:border-0"
                  >
                    <td className="text-fg-muted px-4 py-2.5 whitespace-nowrap">
                      {new Date(row.created_at).toLocaleString("pt-BR")}
                    </td>
                    <td className="px-4 py-2.5">{row.skill}</td>
                    <td className="text-fg-muted px-4 py-2.5">
                      {/* NULL is us, not a missing value. Saying "Atlas" is the
                          honest rendering of a column that means exactly that. */}
                      {row.account_id
                        ? (names.get(row.account_id) ?? row.account_id)
                        : "Atlas"}
                    </td>
                    <td className="text-fg-muted px-4 py-2.5">
                      {row.subject ?? "—"}
                    </td>
                    <td className="text-fg-muted px-4 py-2.5">
                      {row.model ?? "—"}
                      {row.model && !priced(row.model) && (
                        <span className="block text-xs">
                          sem preço na tabela
                        </span>
                      )}
                    </td>
                    <td className="text-fg-muted px-4 py-2.5">
                      {row.cost_brl === null ? "—" : brl(row.cost_brl)}
                    </td>
                    <td className={`px-4 py-2.5 ${STATE_TONE[row.state]}`}>
                      {RUN_STATE_LABEL[row.state]}
                      {row.error && (
                        <span className="block max-w-[280px] truncate text-xs">
                          {row.error}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </main>
  );
}
