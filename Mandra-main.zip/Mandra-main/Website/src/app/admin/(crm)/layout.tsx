import { LogOut } from "lucide-react";
import { LogoMark } from "@/components/ui/logo";
import { requireAdmin } from "@/lib/auth/server";
import { AdminNav } from "./nav";

/**
 * The CRM shell: charcoal chrome around a paper work area.
 *
 * Both surfaces are tone blocks (`[data-admin]`, `[data-admin-shell]` in
 * globals.css), so nothing in here names a colour — the sidebar's `bg-surface`
 * and the table's `bg-surface` are the same utility resolving against different
 * tokens. That is the same mechanism `[data-prospector]` uses, and it is what
 * lets a control move between the chrome and the page without being restyled.
 *
 * Grouped as `(crm)` so /admin/login, which renders before there is a session,
 * stays outside it.
 *
 * `requireUser()` here is for the identity chip and the role-aware nav, not for
 * security: a layout doesn't re-run on every client navigation, so each page
 * repeats the check itself.
 */
export default async function CrmLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  const user = await requireAdmin("/admin");

  return (
    <div
      data-admin
      className="bg-bg text-fg flex min-h-screen flex-1 flex-col lg:flex-row"
    >
      <aside
        data-admin-shell
        className="bg-bg text-fg flex shrink-0 flex-col px-4 py-6 lg:w-[264px]"
      >
        <div className="flex items-center gap-3 px-3">
          <span className="text-[22px] font-semibold tracking-[0.08em]">
            MANDRA
          </span>
          <span className="bg-brand text-brand-fg flex size-8 items-center justify-center rounded-xl">
            <LogoMark className="size-5" />
          </span>
        </div>

        <AdminNav role={user.role} permissions={user.permissions} />

        <div className="border-line bg-surface-raised mt-8 hidden rounded-2xl border p-5 lg:mt-auto lg:block">
          <p className="text-brand text-sm font-semibold">Dica Mandra</p>
          {/* The CSV half of the tip only makes sense to someone who has the
              button. Pointing an operator at an export they can't run reads as
              a broken feature rather than as a locked one. */}
          <p className="text-fg-muted mt-2.5 text-sm leading-6">
            {user.permissions.includes("export")
              ? "Quanto mais filtros você usa, mais assertivos são os leads — e o CSV exporta a seleção inteira, não só a página."
              : "Quanto mais filtros você usa, mais assertivos são os leads — e a seleção inteira continua valendo ao mudar de página."}
          </p>
          <div className="bg-brand mt-5 h-1 w-10 rounded-full" />
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header
          data-admin-shell
          className="bg-surface text-fg flex h-16 items-center justify-between gap-4 px-5 md:px-8"
        >
          <p className="text-fg-muted text-sm">CRM comercial</p>
          <div className="flex items-center gap-4">
            <div className="hidden text-right sm:block">
              <p className="text-sm font-medium">{user.displayName}</p>
              <p className="text-fg-subtle text-xs">
                {user.role === "admin" ? "Administrador" : "Operador"}
                {/* The admin's display name is its login name, so repeating it
                    here would print the same word twice. */}
                {user.displayName !== user.username && ` · ${user.username}`}
              </p>
            </div>
            <span className="bg-surface-raised flex size-9 items-center justify-center rounded-xl text-sm font-semibold uppercase">
              {user.displayName.slice(0, 1)}
            </span>
            {/* A plain form, so signing out works without JavaScript and the
                cookie is cleared by the same route that sets it. */}
            <form action="/api/admin/session" method="POST">
              <input type="hidden" name="intent" value="logout" />
              <button
                type="submit"
                title="Sair"
                aria-label="Sair"
                className="text-fg-muted hover:bg-surface-raised hover:text-fg flex size-11 items-center justify-center rounded-xl transition lg:size-9"
              >
                <LogOut className="size-4" />
              </button>
            </form>
          </div>
        </header>

        {children}
      </div>
    </div>
  );
}
