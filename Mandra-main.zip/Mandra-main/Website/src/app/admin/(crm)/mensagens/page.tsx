import { requireAdmin } from "@/lib/auth/server";
import { listTemplates } from "@/lib/prospector/templates-store";
import { OutreachTemplates } from "@/components/admin/outreach-templates";

export const dynamic = "force-dynamic";
export const metadata = { title: "Mensagem de abordagem" };

/**
 * The outreach copy, inside the CRM shell.
 *
 * Mounted twice, like the calling screens: here for the admin and at
 * `/prospector/mensagens` for the operator, who never gets past the `(crm)`
 * layout's `requireAdmin`. Both render the same view — the difference between
 * the two people is one flag, not one screen.
 */
export default async function MensagensPage() {
  const user = await requireAdmin("/admin/mensagens");

  return (
    <main className="mx-auto w-full max-w-[1100px] flex-1 px-5 py-8 md:px-8">
      <OutreachTemplatesView
        isAdmin
        viewerId={user.id}
        viewerName={user.displayName}
      />
    </main>
  );
}

/**
 * The screen itself, so the operator mount is a guard and a wrapper rather than
 * a second copy of this copy. Same arrangement as `CallSessionView`.
 */
export function OutreachTemplatesView({
  isAdmin,
  viewerId,
  viewerName,
}: {
  isAdmin: boolean;
  viewerId: string;
  /** Fills `[meu-nome]` in the preview, exactly as it will fill it on a send. */
  viewerName: string;
}) {
  // Their own rows and the team's, never a colleague's — see `listTemplates`.
  const templates = listTemplates(viewerId);

  return (
    <>
      <p className="text-brand text-xs font-semibold tracking-[0.16em]">
        ABORDAGEM
      </p>
      <h1 className="mt-1.5 text-3xl font-semibold tracking-tight md:text-[34px]">
        Sua mensagem de abordagem
      </h1>
      <p className="text-fg-muted mt-2 max-w-[70ch] text-sm leading-6">
        É o texto que já vem escrito quando você abre o WhatsApp de um lead, no
        prospector, no histórico, no CRM e na fila de ligações. A mensagem é{" "}
        <strong className="text-fg font-semibold">sua</strong>: o que você
        escrever aqui vale nos seus contatos e não muda nada para o resto da
        equipe. Salvou, vale no próximo clique.
      </p>
      <p className="text-fg-muted mt-2 max-w-[70ch] text-sm leading-6">
        Anote embaixo de cada versão o que aconteceu quando ela foi enviada. É a
        única forma de a próxima reescrita ser uma decisão e não um palpite: os
        números dizem quantos responderam, a anotação diz por quê.
      </p>

      <OutreachTemplates
        templates={templates}
        isAdmin={isAdmin}
        viewerId={viewerId}
        viewerName={viewerName}
      />
    </>
  );
}
