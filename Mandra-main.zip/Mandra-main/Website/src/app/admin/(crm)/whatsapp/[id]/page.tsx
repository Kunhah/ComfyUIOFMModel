import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { requireAdmin } from "@/lib/auth/server";
import {
  appointmentsFor,
  conversationById,
  jobsFor,
  recentMessages,
} from "@/lib/whatsapp/db";
import { describeCron, localTime } from "@/lib/whatsapp/scheduler";
import { DEFAULT_TIMEZONE } from "@/lib/whatsapp/agent";
import { WhatsappThread } from "@/components/admin/whatsapp-thread";
import { JobList } from "@/components/admin/whatsapp-jobs";

/**
 * One thread, everything about it.
 *
 * The transcript, what is scheduled off the back of it and what was booked, on
 * one page — because those are the three things an operator picking up a
 * conversation needs at once, and the answer to "why is this client getting
 * messages" is usually in the second list rather than the first.
 */

export const dynamic = "force-dynamic";

/** More than the agent is shown, because a person scrolls back further. */
const TRANSCRIPT_LENGTH = 100;

export default async function ConversationPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  await requireAdmin("/admin/whatsapp");
  const { id } = await params;

  const conversation = conversationById(id);
  if (!conversation) notFound();

  const timezone = conversation.timezone ?? DEFAULT_TIMEZONE;
  const messages = recentMessages(conversation.id, TRANSCRIPT_LENGTH);
  const jobs = jobsFor(conversation.id).filter((job) => job.active);
  const appointments = appointmentsFor(conversation.id);

  const who = conversation.contactName ?? conversation.phone;

  return (
    <main className="mx-auto w-full max-w-[860px] flex-1 px-5 py-8 md:px-8">
      <Link
        href="/admin/whatsapp"
        className="text-fg-muted hover:text-fg inline-flex items-center gap-1.5 text-sm transition"
      >
        <ArrowLeft className="size-4" />
        WhatsApp
      </Link>

      <h1 className="mt-3 text-3xl font-semibold tracking-tight md:text-[34px]">
        {who}
      </h1>
      <p className="text-fg-muted mt-2 text-sm">
        {conversation.phone}
        {conversation.leadId && (
          <>
            {" · "}
            <Link
              href={`/admin/historico?q=${encodeURIComponent(conversation.phone)}`}
              className="hover:underline"
            >
              ver lead no CRM
            </Link>
          </>
        )}
      </p>

      <WhatsappThread
        conversationId={conversation.id}
        autoReply={conversation.autoReply}
        messages={messages.map((message) => ({
          id: message.id,
          direction: message.direction,
          origin: message.origin,
          body: message.body,
          status: message.status,
          error: message.error,
          at: localTime(message.createdAt, timezone),
        }))}
      />

      {appointments.length > 0 && (
        <section className="mt-8">
          <h2 className="text-fg-muted mb-2.5 px-1 text-[11px] font-semibold tracking-[0.14em] uppercase">
            Agendamentos
          </h2>
          <ul className="border-line bg-surface divide-line divide-y overflow-hidden rounded-2xl border">
            {appointments.map((appointment) => (
              <li key={appointment.id} className="px-5 py-3.5">
                <p className="text-sm font-medium">
                  {appointment.title}
                  <span className="text-fg-subtle font-normal">
                    {" · "}
                    {appointment.status}
                  </span>
                </p>
                <p className="text-fg-muted mt-0.5 text-sm">
                  {localTime(appointment.startsAt, appointment.timezone)} ·{" "}
                  {appointment.durationMinutes} min
                </p>
                {appointment.notes && (
                  <p className="text-fg-subtle mt-1 text-sm">
                    {appointment.notes}
                  </p>
                )}
              </li>
            ))}
          </ul>
        </section>
      )}

      {jobs.length > 0 && (
        <section className="mt-8">
          <h2 className="text-fg-muted mb-2.5 px-1 text-[11px] font-semibold tracking-[0.14em] uppercase">
            Programado
          </h2>
          <div className="border-line bg-surface overflow-hidden rounded-2xl border">
            <JobList
              jobs={jobs.map((job) => ({
                id: job.id,
                conversationId: job.conversationId,
                who,
                when:
                  job.kind === "cron" && job.cron
                    ? describeCron(job.cron)
                    : job.nextRunAt
                      ? localTime(job.nextRunAt, job.timezone)
                      : "sem data",
                body: job.body,
                reason: job.reason,
                runs: job.runs,
                maxRuns: job.maxRuns,
                byAgent: job.createdBy === "agent",
                lastError: job.lastError,
              }))}
            />
          </div>
        </section>
      )}
    </main>
  );
}
