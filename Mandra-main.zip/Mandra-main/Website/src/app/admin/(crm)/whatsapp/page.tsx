import Link from "next/link";
import { MessageSquare, CalendarClock, AlarmClock, Bot } from "lucide-react";
import { requireAdmin } from "@/lib/auth/server";
import { llmConfigured } from "@/lib/ai/providers";
import { connectionState } from "@/lib/whatsapp/evolution";
import {
  activeJobs,
  listConversations,
  upcomingAppointments,
} from "@/lib/whatsapp/db";
import { describeCron, localTime } from "@/lib/whatsapp/scheduler";
import { DEFAULT_TIMEZONE } from "@/lib/whatsapp/agent";
import { JobList } from "@/components/admin/whatsapp-jobs";

/**
 * The WhatsApp desk: who is talking to us, what is going out later, what is
 * booked.
 *
 * Three lists rather than one, because they answer different questions and get
 * checked at different times — the conversations are read all day, the schedule
 * is checked when something looks wrong, and the diary is checked in the
 * morning. Folding them into one activity feed would bury the two that matter
 * under the one that moves.
 */

export const dynamic = "force-dynamic";
export const metadata = { title: "WhatsApp" };

export default async function WhatsappPage() {
  await requireAdmin("/admin/whatsapp");

  const [connection, conversations, jobs, diary] = await Promise.all([
    connectionState(),
    Promise.resolve(listConversations()),
    Promise.resolve(activeJobs()),
    Promise.resolve(upcomingAppointments(20)),
  ]);

  const ai = llmConfigured();

  // Resolved once from the list already in hand rather than per job. A lookup
  // inside the render is a query per row, and the schedule is the one list here
  // that can hold several rows per conversation.
  const names = new Map(
    conversations.map((conversation) => [
      conversation.id,
      conversation.contactName ?? conversation.phone,
    ]),
  );

  return (
    <main className="mx-auto w-full max-w-[1100px] flex-1 px-5 py-8 md:px-8">
      <p className="text-brand text-xs font-semibold tracking-[0.16em]">
        ATENDIMENTO
      </p>
      <h1 className="mt-1.5 text-3xl font-semibold tracking-tight md:text-[34px]">
        WhatsApp
      </h1>
      <p className="text-fg-muted mt-2 text-sm">
        O assistente responde quem chama, marca conversa e programa lembretes.
        Ao responder você mesmo, o robô para de responder aquela conversa.
      </p>

      <Status connection={connection} ai={ai} />

      <Section
        icon={<MessageSquare className="size-4" />}
        title="Conversas"
        count={conversations.length}
      >
        {conversations.length === 0 ? (
          <Empty>
            Nenhuma conversa ainda. Elas aparecem aqui assim que alguém mandar
            mensagem para o número conectado.
          </Empty>
        ) : (
          <ul className="divide-line divide-y">
            {conversations.map((conversation) => (
              <li key={conversation.id}>
                <Link
                  href={`/admin/whatsapp/${conversation.id}`}
                  className="hover:bg-surface-raised/60 flex items-center gap-4 px-5 py-3.5 transition"
                >
                  <span className="bg-surface-raised flex size-9 shrink-0 items-center justify-center rounded-xl text-sm font-semibold uppercase">
                    {(conversation.contactName ?? conversation.phone).slice(
                      0,
                      1,
                    )}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-2">
                      <span className="truncate text-sm font-medium">
                        {conversation.contactName ?? conversation.phone}
                      </span>
                      {!conversation.autoReply && (
                        <span className="text-fg-subtle border-line shrink-0 rounded-full border px-2 py-0.5 text-[11px]">
                          atendimento humano
                        </span>
                      )}
                      {conversation.scheduled > 0 && (
                        <span className="text-brand border-brand/30 shrink-0 rounded-full border px-2 py-0.5 text-[11px]">
                          {conversation.scheduled} programado
                          {conversation.scheduled > 1 ? "s" : ""}
                        </span>
                      )}
                    </span>
                    <span className="text-fg-muted mt-0.5 block truncate text-sm">
                      {conversation.lastDirection === "out" && "Você: "}
                      {conversation.lastMessage ?? "—"}
                    </span>
                  </span>
                  <span className="text-fg-subtle hidden shrink-0 text-xs sm:block">
                    {conversation.phone}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </Section>

      <Section
        icon={<AlarmClock className="size-4" />}
        title="Mensagens programadas"
        count={jobs.length}
      >
        {jobs.length === 0 ? (
          <Empty>Nada programado no momento.</Empty>
        ) : (
          <JobList
            jobs={jobs.map((job) => ({
              id: job.id,
              conversationId: job.conversationId,
              who: names.get(job.conversationId) ?? "—",
              when:
                job.kind === "cron" && job.cron
                  ? describeCron(job.cron)
                  : job.nextRunAt
                    ? localTime(job.nextRunAt, job.timezone)
                    : "sem data",
              body: job.body,
              reason: job.reason,
              runs: job.runs,
              maxRuns: job.maxRuns,
              byAgent: job.createdBy === "agent",
              lastError: job.lastError,
            }))}
          />
        )}
      </Section>

      <Section
        icon={<CalendarClock className="size-4" />}
        title="Agenda"
        count={diary.length}
      >
        {diary.length === 0 ? (
          <Empty>Nenhuma conversa marcada.</Empty>
        ) : (
          <ul className="divide-line divide-y">
            {diary.map((appointment) => (
              <li key={appointment.id} className="px-5 py-3.5">
                <Link
                  href={`/admin/whatsapp/${appointment.conversationId}`}
                  className="text-sm font-medium hover:underline"
                >
                  {appointment.title}
                </Link>
                <p className="text-fg-muted mt-0.5 text-sm">
                  {localTime(appointment.startsAt, appointment.timezone)} ·{" "}
                  {appointment.durationMinutes} min
                  {appointment.createdBy === "agent" &&
                    " · marcado pelo assistente"}
                </p>
                {appointment.notes && (
                  <p className="text-fg-subtle mt-1 text-sm">
                    {appointment.notes}
                  </p>
                )}
              </li>
            ))}
          </ul>
        )}
      </Section>
    </main>
  );
}

/**
 * Whether the feature can actually work, stated before any of the lists.
 *
 * An empty conversation list means one of three very different things — nobody
 * has written, the bridge is disconnected, or WhatsApp was never configured —
 * and they are indistinguishable from the list itself. That ambiguity is exactly
 * what made the empty prospector unreadable, and it is worth a row to remove.
 */
function Status({
  connection,
  ai,
}: {
  connection: {
    configured: boolean;
    state: string | null;
    error: string | null;
  };
  ai: boolean;
}) {
  const items: { label: string; ok: boolean; detail: string }[] = [
    {
      label: "Conexão",
      ok: connection.configured && connection.state === "open",
      detail: !connection.configured
        ? "Evolution não configurado (EVOLUTION_API_URL, EVOLUTION_API_KEY, EVOLUTION_INSTANCE)."
        : connection.error
          ? `Não foi possível consultar: ${connection.error}`
          : connection.state === "open"
            ? "Número conectado."
            : `Instância em "${connection.state ?? "desconhecido"}" — leia o QR code no Evolution.`,
    },
    {
      label: "Assistente",
      ok: ai,
      detail: ai
        ? `Responde automaticamente. Fuso das conversas: ${DEFAULT_TIMEZONE}.`
        : "Sem GROQ_API_KEY nem OPENROUTER_API_KEY — as mensagens chegam, mas ninguém responde sozinho.",
    },
  ];

  return (
    <div className="mt-6 grid gap-3 sm:grid-cols-2">
      {items.map((item) => (
        <div
          key={item.label}
          className="border-line bg-surface flex items-start gap-3 rounded-2xl border px-5 py-4"
        >
          <span
            className={`mt-1 size-2.5 shrink-0 rounded-full ${item.ok ? "bg-brand" : "bg-fg-subtle"}`}
            aria-hidden
          />
          <div className="min-w-0">
            <p className="flex items-center gap-2 text-sm font-medium">
              {item.label === "Assistente" && <Bot className="size-4" />}
              {item.label}
            </p>
            <p className="text-fg-muted mt-0.5 text-sm">{item.detail}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

function Section({
  icon,
  title,
  count,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  count: number;
  children: React.ReactNode;
}) {
  return (
    <section className="mt-8">
      <h2 className="text-fg-muted mb-2.5 flex items-center gap-2 px-1 text-[11px] font-semibold tracking-[0.14em] uppercase">
        {icon}
        {title}
        <span className="text-fg-subtle">{count}</span>
      </h2>
      <div className="border-line bg-surface overflow-hidden rounded-2xl border">
        {children}
      </div>
    </section>
  );
}

function Empty({ children }: { children: React.ReactNode }) {
  return <p className="text-fg-muted px-5 py-6 text-sm">{children}</p>;
}
