import { Download, Phone, PhoneCall, Sparkles, Target } from "lucide-react";
import { CallListManager } from "@/components/admin/call-list-manager";
import { DailyQueueButton } from "@/components/admin/daily-queue";
import { can, requireAdmin } from "@/lib/auth/server";
import { dateTime, fmt } from "@/lib/admin/format";
import {
  AUDIENCE_SEEDS,
  AUDIENCE_SEED_HINT,
  AUDIENCE_SEED_LABEL,
  DEFAULT_DAILY_TARGET,
  callLists,
  callStats,
  leadsForAudience,
} from "@/lib/prospector/calls";
import { phonePoolStats } from "@/lib/prospector/phone-quality";
import { isMatchable } from "@/lib/prospector/audience";
import { CALL_OUTCOME_LABEL } from "@/lib/prospector/types";

/**
 * Call lists, and the audiences the calls produce.
 *
 * The two halves are on one screen because they are one loop: the outcomes
 * recorded on the left are exactly what defines the seeds on the right, and
 * splitting them into separate sections of the sidebar hides the fact that
 * qualifying a call well is what makes the ads better. The counts are live, so
 * the value of the work is visible while it is being done.
 *
 * Dynamic: everything here is runtime state in SQLite.
 */
export const dynamic = "force-dynamic";

/**
 * Mounted twice: at /admin/ligacoes for us and at /operador/ligacoes for the
 * people who do the dialling. Same screen, same writers, two differences that
 * the *page* decides rather than this component:
 *
 * - `actorId` scopes the metric row. The team's totals on an operator's screen
 *   would be the same leak the `CallsToday` rule already forbids — the component
 *   renders what it is handed, the page decides whose numbers those are.
 * - `basePath` keeps every link inside the tree it was rendered in. An operator
 *   sent to /admin/ligacoes/12 is an operator bounced back to /operador with
 *   their queue position lost.
 *
 * The call lists themselves are deliberately *not* scoped. A queue is shared
 * work — that is the whole reason its position lives in SQLite rather than in a
 * browser — and hiding a colleague's list is how two people end up phoning the
 * same business.
 */
export async function CallListsView({
  basePath = "/admin/ligacoes",
  actorId,
  canExport,
}: {
  basePath?: string;
  /** Whose call numbers to show. Undefined means everyone's — our view. */
  actorId?: string;
  canExport: boolean;
}) {
  const lists = callLists();
  const stats = callStats(actorId ? { actorId } : {});
  const pool = phonePoolStats();
  const exportable = canExport;

  // Counted here rather than in the export route so the screen can say what a
  // seed is worth *before* someone downloads it — a 12-row lookalike is one the
  // platforms will reject, and finding that out on upload is finding it out late.
  const seeds = AUDIENCE_SEEDS.map((seed) => {
    const leads = leadsForAudience(seed);
    return {
      seed,
      total: leads.length,
      matchable: leads.filter(isMatchable).length,
    };
  });

  return (
    <main className="mx-auto w-full max-w-[1400px] flex-1 px-5 py-8 md:px-8">
      <div className="flex flex-wrap items-start justify-between gap-5">
        <div>
          <p className="text-brand text-xs font-semibold tracking-[0.16em]">
            CRM MANDRA
          </p>
          <h1 className="mt-1.5 text-3xl font-semibold tracking-tight md:text-[34px]">
            Ligações
          </h1>
          <p className="text-fg-muted mt-2 max-w-2xl text-sm">
            Ligue um a um e registre o resultado de cada ligação. O resultado
            move o lead no funil e alimenta os públicos de anúncio abaixo.
          </p>
        </div>
        {/* The automatic path, and the only thing needed to start a day. */}
        <DailyQueueButton
          basePath={basePath}
          target={DEFAULT_DAILY_TARGET}
          available={pool.available}
        />
      </div>

      {/* What the base can actually sustain. Kept next to the button because
          "can I do this again tomorrow" is the question behind a 100-a-day
          operation, and the answer decides whether today is calling or
          prospecting. The excluded counts are shown for the same reason the
          audience export shows its drops: a pool that shrank for a reason is
          very different from one that was always small. */}
      <div className="border-line bg-surface mt-6 flex flex-wrap items-center gap-x-6 gap-y-2 rounded-2xl border px-5 py-4 text-sm">
        <span>
          <strong className="tnum text-base font-semibold">
            {fmt(pool.available)}
          </strong>{" "}
          <span className="text-fg-muted">prontos para ligar agora</span>
        </span>
        <span className="text-fg-muted">
          de {fmt(pool.good)} com telefone confiável, em {fmt(pool.workable)}{" "}
          leads abertos
        </span>
        <span className="text-fg-subtle ml-auto text-xs">
          fora: {fmt(pool.noPhone)} sem telefone · {fmt(pool.shared)} em número
          compartilhado · {fmt(pool.dead)} número inválido
        </span>
      </div>

      {/* The metric row. `reached` next to `total` on purpose: a day of 80 dials
          and 4 conversations is a real day, and a screen that only counts dials
          reports it as a good one. */}
      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Metric label="Ligações hoje" value={stats.today} icon={PhoneCall} />
        <Metric label="Ligações no total" value={stats.total} icon={Phone} />
        <Metric
          label="Atenderam"
          value={stats.reached}
          icon={Target}
          hint={
            stats.total > 0
              ? `${Math.round((stats.reached / stats.total) * 100)}% das tentativas`
              : undefined
          }
        />
        <Metric
          label="Interessados"
          value={
            stats.byOutcome.find((o) => o.outcome === "interessado")?.count ?? 0
          }
          icon={Sparkles}
          hint="semente do lookalike"
        />
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[minmax(0,1fr)_380px]">
        <section>
          <div className="flex flex-wrap items-baseline justify-between gap-3">
            <h2 className="text-lg font-semibold">Suas listas</h2>
            <span className="text-fg-subtle text-sm">
              {lists.length} {lists.length === 1 ? "lista" : "listas"}
            </span>
          </div>

          <CallListManager
            basePath={basePath}
            lists={lists.map((list) => ({
              ...list,
              createdAtLabel: dateTime(list.createdAt),
            }))}
          />
        </section>

        {/* Hidden outright rather than shown as three disabled buttons and an
            apology. For us it is always on (the admin holds every permission);
            for an operator without `export` the ads half is not their job, and
            a panel that only ever says "sem permissão" is furniture. */}
        {exportable && (
          <aside>
            <h2 className="text-lg font-semibold">Públicos para anúncios</h2>
            <p className="text-fg-muted mt-1.5 text-sm">
              Listas de clientes prontas para subir no Meta ou no Google.
              Telefone e e-mail vão com hash SHA-256, como as plataformas
              exigem.
            </p>

            <div className="mt-4 space-y-3">
              {seeds.map(({ seed, total, matchable }) => (
                <div
                  key={seed}
                  className="border-line bg-surface rounded-2xl border px-4 py-4"
                >
                  <div className="flex items-baseline justify-between gap-3">
                    <h3 className="text-sm font-medium">
                      {AUDIENCE_SEED_LABEL[seed]}
                    </h3>
                    <span className="tnum text-fg-muted text-sm">
                      {fmt(matchable)}
                    </span>
                  </div>
                  <p className="text-fg-subtle mt-1.5 text-xs">
                    {AUDIENCE_SEED_HINT[seed]}
                  </p>
                  {/* Said out loud rather than left as a silent difference between
                    two numbers: a lead with no phone and no e-mail cannot be
                    matched by any platform and is dropped from the file. */}
                  {total > matchable && (
                    <p className="text-fg-subtle mt-1.5 text-xs">
                      {total - matchable} de {total} sem telefone ou e-mail —
                      ficam de fora do arquivo.
                    </p>
                  )}

                  {exportable ? (
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {(
                        [
                          ["meta", "Meta"],
                          ["google", "Google"],
                          ["plano", "CSV"],
                        ] as const
                      ).map(([format, label]) => (
                        <a
                          key={format}
                          href={`/api/prospector/calls/export?publico=${seed}&formato=${format}`}
                          aria-disabled={matchable === 0}
                          className={`border-line inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition ${
                            matchable === 0
                              ? "text-fg-subtle pointer-events-none opacity-50"
                              : "hover:border-line-strong"
                          }`}
                        >
                          <Download className="size-3.5" />
                          {label}
                        </a>
                      ))}
                    </div>
                  ) : (
                    // Hidden rather than offered and refused: the route checks the
                    // same permission, so this is only about not showing a dead button.
                    <p className="text-fg-subtle mt-3 text-xs">
                      Sem permissão para exportar.
                    </p>
                  )}
                </div>
              ))}
            </div>

            {stats.total > 0 && (
              <div className="border-line bg-surface mt-4 rounded-2xl border px-4 py-4">
                <h3 className="text-sm font-medium">Resultados registrados</h3>
                <ul className="mt-2.5 space-y-1.5 text-sm">
                  {stats.byOutcome
                    .filter((row) => row.count > 0)
                    .map((row) => (
                      <li
                        key={row.outcome}
                        className="text-fg-muted flex items-baseline justify-between gap-3"
                      >
                        <span>{CALL_OUTCOME_LABEL[row.outcome]}</span>
                        <span className="tnum">{fmt(row.count)}</span>
                      </li>
                    ))}
                </ul>
              </div>
            )}
          </aside>
        )}
      </div>
    </main>
  );
}

/** The admin mount: every list, the team's numbers, the ads panel. */
export default async function CallListsPage() {
  // A layout doesn't re-run on client navigations, so the page checks for itself.
  const user = await requireAdmin("/admin/ligacoes");
  return <CallListsView canExport={can(user, "export")} />;
}

function Metric({
  label,
  value,
  icon: Icon,
  hint,
}: {
  label: string;
  value: number;
  icon: typeof Phone;
  hint?: string;
}) {
  return (
    <div className="border-line bg-surface rounded-2xl border px-4 py-4">
      <div className="text-fg-muted flex items-center gap-2 text-xs font-medium">
        <Icon className="size-4" />
        {label}
      </div>
      <p className="tnum mt-2 text-2xl font-semibold">{fmt(value)}</p>
      {hint && <p className="text-fg-subtle mt-0.5 text-xs">{hint}</p>}
    </div>
  );
}
