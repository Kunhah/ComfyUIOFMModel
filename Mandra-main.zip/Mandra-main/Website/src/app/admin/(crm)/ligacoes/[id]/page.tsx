import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, PhoneOff, RotateCcw } from "lucide-react";
import { CallSession, type CallCard } from "@/components/admin/call-session";
import { TopUpButton } from "@/components/admin/daily-queue";
import { countryLabel } from "@/lib/countries";
import { requireAdmin, requireStaff } from "@/lib/auth/server";
import { dateTime, shortDate } from "@/lib/admin/format";
import { revalidatePath } from "next/cache";
import {
  DEFAULT_DAILY_TARGET,
  blockedInList,
  callList,
  callStats,
  dailyCandidates,
  nextInList,
  resetSkipped,
} from "@/lib/prospector/calls";
import { callActor } from "@/lib/prospector/ownership";
import { phoneQuality } from "@/lib/prospector/phone-quality";
import { recordProspectorActivity } from "@/lib/prospector/db";
import { NICHES } from "@/lib/prospector/niches";
import {
  normalisePhone,
  outreachMessage,
  whatsappUrl,
} from "@/lib/prospector/score";
import { outreachContextFor } from "@/lib/prospector/templates-store";
import {
  CALL_OUTCOME_LABEL,
  FUNNEL_LABEL,
  isClosedStage,
  NEXT_STEP_LABEL,
} from "@/lib/prospector/types";

/**
 * One calling session.
 *
 * The page holds no cursor of its own: it renders whatever `nextInList` hands
 * back, and the client component refreshes the route after each outcome. That is
 * the whole reason the queue's position lives in SQLite — closing the laptop
 * mid-list and picking it up tomorrow is the normal case, not the edge one.
 *
 * Dynamic for the same reason `/prospector/b2b` is: the queue is runtime state
 * and a prerendered page would bake one lead into the build.
 */
export const dynamic = "force-dynamic";

/**
 * Mounted at /admin/ligacoes/[id] and at /operador/ligacoes/[id].
 *
 * `basePath` is not cosmetic: the back links, the top-up button and the server
 * action's revalidate all have to point at the tree the operator is actually
 * in, or finishing a call sends them to a page their role cannot open and the
 * queue position is lost.
 */
export async function CallSessionView({
  listId,
  basePath = "/admin/ligacoes",
}: {
  listId: number;
  basePath?: string;
}) {
  if (!Number.isInteger(listId) || listId <= 0) notFound();

  // Who is dialling decides what the queue may hand back, so the session needs
  // the session — a list is shared and the positions in it are not. The page
  // above already checked; this is the same repetition every other view here
  // does, and here it also carries a value rather than only a guarantee.
  const actor = callActor(await requireStaff(basePath));

  const list = callList(listId);
  if (!list) notFound();

  const item = nextInList(listId, actor);
  const stats = callStats({ listId });
  // Pending positions this operator may not work: another operator owns them, or
  // is on the phone with them right now. Counted so an empty screen over a queue
  // that still says "80 na fila" reads as what it is.
  const blocked = blockedInList(listId, actor);
  // Only asked when the queue has run dry, so an empty screen can offer more
  // work instead of a dead end. Capped at the daily target — the count is a
  // button label, not a report.
  const refill = item
    ? 0
    : dailyCandidates(DEFAULT_DAILY_TARGET, undefined, actor).length;

  const nicheLabel = (slug: string | null): string =>
    NICHES.find((niche) => niche.slug === slug)?.label ?? slug ?? "—";

  return (
    <main className="mx-auto w-full max-w-[1400px] flex-1 px-5 py-8 md:px-8">
      <Link
        href={basePath}
        className="text-fg-muted hover:text-fg inline-flex items-center gap-1.5 text-sm transition"
      >
        <ArrowLeft className="size-4" />
        Listas de ligações
      </Link>

      <div className="mt-4 flex flex-wrap items-start justify-between gap-5">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight md:text-[34px]">
            {list.name}
          </h1>
          <p className="text-fg-muted mt-2 text-sm">
            {list.pending} na fila · {list.done} concluídos
            {list.skipped > 0 ? ` · ${list.skipped} pulados` : ""}
            {blocked > 0 ? ` · ${blocked} com outro operador` : ""} ·{" "}
            {stats.reached} atenderam de {stats.total} tentativas
          </p>
        </div>
      </div>

      <div className="mt-6">
        {item ? (
          <CallSession
            // Keyed on the lead so the next call starts on a clean form. The
            // draft note must survive a refresh that returns the same lead and
            // must not survive one that returns a different one; a key is the
            // difference, and it costs one remount per call.
            key={item.leadId}
            listId={list.id}
            listName={list.name}
            position={list.done + list.skipped + 1}
            done={list.done}
            total={list.total}
            item={toCard(item)}
          />
        ) : (
          <FinishedPanel
            basePath={basePath}
            listId={list.id}
            skipped={list.skipped}
            done={list.done}
            refill={refill}
            blocked={blocked}
          />
        )}
      </div>
    </main>
  );

  /**
   * Flattened here so the niche registry, the scoring module and the phone
   * normalisation stay server-side — the same rule the CRM table follows.
   */
  function toCard(entry: NonNullable<ReturnType<typeof nextInList>>): CallCard {
    const lead = entry.lead;
    const digits = normalisePhone(lead.phone, lead.country);
    const place = [lead.city, lead.uf, countryLabel(lead.country ?? "BR")]
      .filter(Boolean)
      .join(" · ");

    return {
      id: lead.id,
      name: lead.name,
      nicheLabel: nicheLabel(lead.niche),
      niche: lead.niche,
      category: lead.category,
      address: lead.address,
      place: place || "—",
      // Displayed with the plus even though the CSV drops it: this one is read by
      // a person about to dial, not by a spreadsheet.
      phone: digits ? `+${digits}` : null,
      // The dial itself uses the same normalised number, so what is shown and
      // what is dialled cannot differ.
      telUrl: digits ? `tel:+${digits}` : null,
      whatsappUrl: whatsappUrl(
        lead.phone,
        // One lead per screen here, so the read is per card rather than per
        // page — and it has to be the live one: the operator may well have
        // rewritten their opener on the tab next to this one.
        outreachMessage(lead, undefined, outreachContextFor(actor)),
        lead.country,
      ),
      website: lead.website,
      email: lead.email,
      mapUrl: null,
      score: lead.score,
      reasons: lead.reasons,
      contactName: lead.contactName,
      // Computed server-side: it is three correlated subqueries, and the answer
      // is one short sentence the operator reads while the phone rings.
      phoneWarning: phoneQuality(lead.id)?.warning ?? null,
      stageLabel: FUNNEL_LABEL[lead.funnelStage],
      // Resolved here rather than in the component, like every other flattened
      // field on this card: the stage list is server-side knowledge.
      closedStage: isClosedStage(lead.funnelStage)
        ? (lead.funnelStage as "fechado" | "perdido")
        : null,
      notes: lead.notes,
      nextFollowUpAt: lead.nextFollowUpAt
        ? shortDate(lead.nextFollowUpAt)
        : null,
      contactedAt: lead.contactedAt ? dateTime(lead.contactedAt) : null,
      history: entry.history.map((call) => ({
        id: call.id,
        outcomeLabel: CALL_OUTCOME_LABEL[call.outcome],
        stepLabel:
          call.nextStep === "nenhum" ? null : NEXT_STEP_LABEL[call.nextStep],
        notes: call.notes,
        actor: call.actorDisplayName,
        when: dateTime(call.occurredAt),
      })),
    };
  }
}

/**
 * The end of the queue.
 *
 * Says which of the two ends it is: a list worked to the bottom and a list whose
 * remaining leads were all skipped look identical from a counter alone, and only
 * one of them is finished.
 */
function FinishedPanel({
  listId,
  skipped,
  done,
  refill,
  blocked,
  basePath,
}: {
  listId: number;
  skipped: number;
  done: number;
  /** Leads available to top this same list up with, rather than starting another. */
  refill: number;
  /** Pending positions that belong to another operator. */
  blocked: number;
  /** The tree this session is mounted in — /admin or /operador. */
  basePath: string;
}) {
  return (
    <section className="border-line bg-surface rounded-2xl border px-6 py-10 text-center">
      <PhoneOff className="text-fg-subtle mx-auto size-8" />
      <h2 className="mt-4 text-xl font-semibold">Fila vazia</h2>
      <p className="text-fg-muted mx-auto mt-2 max-w-md text-sm">
        {done > 0
          ? `${done} ${done === 1 ? "ligação registrada" : "ligações registradas"} nesta lista.`
          : "Nenhuma ligação foi registrada nesta lista."}
        {skipped > 0
          ? ` Ainda há ${skipped} ${skipped === 1 ? "lead pulado" : "leads pulados"} esperando.`
          : ""}
        {/* The difference between "you are done" and "the rest is not yours".
            Without it a list showing eighty pending and an empty dialer reads as
            a bug, and the operator rebuilds a queue they did not need. */}
        {blocked > 0
          ? ` ${blocked} ${blocked === 1 ? "lead está" : "leads estão"} com outro operador e não ${blocked === 1 ? "aparece" : "aparecem"} para você.`
          : ""}
      </p>
      <div className="mt-5 flex flex-wrap items-start justify-center gap-2.5">
        {refill > 0 && (
          <TopUpButton
            listId={listId}
            amount={Math.min(refill, DEFAULT_DAILY_TARGET)}
          />
        )}
        {skipped > 0 && (
          <RestoreSkipped basePath={basePath} listId={listId} count={skipped} />
        )}
        <Link
          href={basePath}
          className="border-line hover:border-line-strong rounded-xl border px-4 py-2.5 text-sm font-medium transition"
        >
          Voltar às listas
        </Link>
      </div>
    </section>
  );
}

/**
 * A plain form POST rather than a client component: it is one button pressed
 * once at the end of a list, and a server action keeps the page a server
 * component. The route it posts to is the same one the list index uses.
 */
function RestoreSkipped({
  listId,
  count,
  basePath,
}: {
  listId: number;
  count: number;
  basePath: string;
}) {
  async function restore() {
    "use server";
    // A server action is a public endpoint, so it repeats the check rather than
    // trusting the page that rendered the form — the same rule every route here
    // follows, and the reason it is not enough that the page above called it.
    // requireStaff rather than requireAdmin: operators restore their own skips.
    const user = await requireStaff(basePath);
    const restored = resetSkipped(listId);
    recordProspectorActivity({
      actor: user,
      action: "call_list",
      detail: `Lista #${listId} · ${restored} pulados restaurados`,
    });
    revalidatePath(`${basePath}/${listId}`);
  }

  return (
    <form action={restore}>
      <button
        type="submit"
        className="bg-fg text-bg inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition hover:opacity-90"
      >
        <RotateCcw className="size-4" />
        Voltar aos {count} pulados
      </button>
    </form>
  );
}

/** The admin mount. */
export default async function CallSessionPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  // A layout doesn't re-run on client navigations, so the page checks for itself.
  await requireAdmin("/admin/ligacoes");
  return <CallSessionView listId={Number((await params).id)} />;
}
