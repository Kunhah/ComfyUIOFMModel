import type { Metadata } from "next";

/**
 * Everything under /admin, login included.
 *
 * Deliberately just metadata: the CRM chrome lives in `(crm)/layout.tsx` so the
 * login screen — which renders before there is a session to hang a sidebar on —
 * doesn't inherit it.
 */
export const metadata: Metadata = {
  title: { default: "CRM", template: "%s · CRM Mandra" },
  // The proxy bounces anonymous requests to /admin/login, which is a real page
  // and would otherwise be indexable. robots.ts keeps crawlers off the path in
  // the first place; this is the header that holds if one gets here anyway.
  robots: { index: false, follow: false },
};

export default function AdminLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return children;
}
