import type { Metadata } from "next";
import { Inter, Archivo, Geist_Mono } from "next/font/google";
import { site } from "@/content/site";
import "./globals.css";

/**
 * Document shell only.
 *
 * The site chrome (header, footer, motion providers) lives in `(marketing)/`
 * rather than here, because `/prospector` is an internal tool that shares the
 * fonts and the token layer but none of the marketing furniture. Both trees
 * still hang off this one root layout — using two root layouts instead would
 * force a full page reload on every crossing between them.
 */

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

/**
 * The display voice. Archivo is a highway-gothic grotesque — it comes from the
 * same signage tradition as the silkscreened plates bolted to a utility box,
 * which is what the marketing site is built out of. Inter Tight was here
 * before and was the wrong call: Inter set larger is not a display face, it is
 * body copy with the tracking closed up, and it has no character to carry a
 * headline at 6rem.
 */
const archivo = Archivo({
  variable: "--font-display",
  subsets: ["latin"],
  weight: ["500", "600", "700", "800"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: {
    default: `${site.name} — ${site.tagline}`,
    template: `%s · ${site.name}`,
  },
  description: site.description,
  keywords: [
    "desenvolvimento de sites",
    "sistemas web",
    "inteligência artificial",
    "automação de processos",
    "agência digital",
    "Florianópolis",
    "Santa Catarina",
  ],
  authors: [{ name: site.name }],
  openGraph: {
    type: "website",
    locale: "pt_BR",
    url: site.url,
    siteName: site.name,
    title: `${site.name} — ${site.tagline}`,
    description: site.description,
  },
  twitter: {
    card: "summary_large_image",
    title: `${site.name} — ${site.tagline}`,
    description: site.description,
  },
  robots: { index: true, follow: true },
};

/**
 * A Rede — the marketing site's direction contract. See DESIGN.md.
 */
const directionContract = `<!--
THESIS: A business's digital presence is the tangle of cable on the pole
outside — five tools, five logins, nobody's job. Mandra is the junction box
where every line is terminated, numbered and carrying current. Refuses the
five-parallel-feature-cards grid, because five parallel cards ARE the tangle.

OWN-WORLD: Brazilian fiacao aerea read at night. Night ground (#06080b-#171d25),
de-energized conductor in blue-cast steel, and amber ONLY where current is
flowing. Materials: cable sheath with one specular highlight, silkscreened
aluminium plates, hazard hatching, porcelain. Archivo signage caps over Geist
Mono ID fields. The repeating unit is a three-field terminal plate.

STORY: the visitor recognizes their own tangle, watches it get terminated into
one box, sees which lines Mandra actually carries and what is already running
on them, and asks for an orcamento at the terminal where every line lands.

FIRST VIEWPORT: full-bleed WebGL catenary field on night; headline set in the
negative space the cables leave, not in a box; current travels the strands and
converges into a lit terminal block that IS the primary action.

FORM: A Rede, candidate 3 of the grounded list; seed key c3a39aa8.

FINISH: unreviewed and undocumented is unfinished; this build ends with the
finish review, the verdict, and DESIGN.md.
-->`;

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="pt-BR"
      className={`${inter.variable} ${archivo.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="flex min-h-full flex-col">
        {/* The direction contract, emitted as a real HTML comment so it
            survives the production build and can be grepped out of it. A JSX
            comment would be compiled away and audit nothing. */}
        <div hidden dangerouslySetInnerHTML={{ __html: directionContract }} />
        {children}
      </body>
    </html>
  );
}
