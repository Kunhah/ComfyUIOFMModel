import type { MetadataRoute } from "next";
import { site } from "@/content/site";

export default function robots(): MetadataRoute.Robots {
  return {
    // /prospector and /admin are internal and /app is the client portal. Their
    // layouts already send noindex; this keeps crawlers from spending anything
    // on them in the first place. Each needs both: an anonymous crawler is
    // redirected to a login page, which answers 200 and would otherwise be a
    // perfectly indexable page.
    rules: {
      userAgent: "*",
      allow: "/",
      disallow: ["/prospector", "/admin", "/app"],
    },
    sitemap: `${site.url}/sitemap.xml`,
  };
}
