import {
  defaultCountry,
  indexSummary,
  indexedCountries,
} from "@/lib/prospector/cities";
import { NICHES } from "@/lib/prospector/niches";
import { historyCount } from "@/lib/prospector/db";
import { outreachContextFor } from "@/lib/prospector/templates-store";
import { hasCnpjExtract } from "@/lib/prospector/cnpj";
import {
  hasLocalExtract as hasPlacesExtract,
  overtureRelease as placesRelease,
} from "@/lib/prospector/overture";
import { COUNTRIES, EUROPE } from "@/lib/b2b/countries";
import { companyCount, contactableCount } from "@/lib/b2b/db";
import {
  extractCoverageUnknown,
  hasLocalExtract as hasB2bExtract,
  hasUniversalExtract,
  overtureRelease as b2bRelease,
  uncoveredSectors,
} from "@/lib/b2b/overture";
import { discoveryTargets } from "@/lib/b2b/sectors";
import { can, type SessionUser } from "@/lib/auth/server";
import type { InitialSearch } from "@/components/prospector/prospector";
import type {
  B2bPanelProps,
  LocalPanelProps,
} from "@/components/prospector/workspace";
import type { SearchResponse } from "@/lib/prospector/types";

/**
 * Everything the two tools need to render, gathered in one place.
 *
 * It exists because both are now mounted on both routes: `/prospector` and
 * `/prospector/b2b` render the same workspace and differ only in which tab opens
 * first, so switching between them is state rather than a navigation. Two pages
 * assembling those props by hand is the same drift `parseFilters()` and the CSV
 * column lists already warn about — one of them would grow a counter or a
 * warning banner the other never learned about, and both would render fine while
 * disagreeing about what the tool says.
 *
 * Everything here is a local read (SQLite counters, the city index, an
 * `existsSync`), which is why the second panel is affordable on both routes.
 */

export function localPanel({
  initialSearch,
  initialResult,
  initialError,
  canExport,
  viewer,
}: {
  initialSearch: InitialSearch | null;
  initialResult: SearchResponse | null;
  initialError: string | null;
  canExport: boolean;
  /**
   * Who is looking, so the board's WhatsApp links carry their own opener and
   * their own name. Every mount passes the session it already required — a
   * board that guessed would put one operator's message on another's screen.
   */
  viewer: SessionUser | null;
}): LocalPanelProps {
  const reach = indexSummary();
  return {
    niches: NICHES,
    // Only the countries the extract can actually answer for. Offering the whole
    // registry would offer searches that return nothing and read as a broken tool.
    countries: indexedCountries().map(({ country, cities, noSite }) => ({
      code: country.code,
      label: country.label,
      region: country.region,
      cities,
      noSite,
    })),
    defaultCountry: defaultCountry(),
    initialSearch,
    initialResult,
    initialError,
    canExport,
    // Read here rather than in the board: the board is a client component, and
    // the openers live in SQLite. Every route that mounts the workspace gets
    // them from this one place, so no mount can send a stale pitch — or
    // somebody else's.
    outreach: outreachContextFor(viewer),
    release: placesRelease,
    localExtract: hasPlacesExtract(),
    cnpjRegister: hasCnpjExtract(),
    history: historyCount(),
    reach,
  };
}

/** Null when the account was not granted the crawler — the tab is then absent. */
export function b2bPanel(user: SessionUser | null): B2bPanelProps | null {
  if (!can(user, "b2b")) return null;
  return {
    targets: discoveryTargets(),
    countries: COUNTRIES.map((c) => ({ code: c.code, label: c.label })),
    europe: EUROPE,
    storedContactable: contactableCount(),
    // Hiding the button is courtesy, not the control: the export route checks
    // the same permission for itself.
    canExport: can(user, "export"),
    uncovered: uncoveredSectors(),
    coverageUnknown: extractCoverageUnknown(),
    release: b2bRelease,
    localExtract: hasB2bExtract(),
    universalExtract: hasUniversalExtract(),
    companies: companyCount(),
    contactable: contactableCount(),
  };
}
