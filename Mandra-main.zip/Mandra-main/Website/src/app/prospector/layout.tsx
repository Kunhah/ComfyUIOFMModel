import type { Metadata } from "next";

/**
 * Internal tool, mounted inside the marketing site but sharing none of its
 * chrome.
 *
 * `data-prospector` scopes the dashboard palette (see globals.css). The site's
 * semantic tokens — `--surface`, `--fg`, `--line` — are remapped on this
 * subtree, so the tool's dense dark styling comes out of the same
 * `bg-surface` / `text-fg-muted` utilities the marketing components use,
 * without a `dark:` variant anywhere or a second stylesheet.
 */

export const metadata: Metadata = {
  title: "Prospector",
  description: "Prospecção de negócios locais por nicho e cidade.",
  // Internal tool: keep it out of search results even though it's on the
  // public domain. robots.ts disallows the path as well.
  robots: { index: false, follow: false },
};

export default function ProspectorLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <div data-prospector className="bg-bg text-fg flex-1">
      {children}
    </div>
  );
}
