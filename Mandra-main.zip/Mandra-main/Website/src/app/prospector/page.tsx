import { performSearch } from "@/lib/prospector/search";
import { parseInitialSearch } from "@/lib/prospector/search-url";
import { can, requireUser } from "@/lib/auth/server";
import { ProspectorWorkspace } from "@/components/prospector/workspace";
import { b2bPanel, localPanel } from "./panels";

/**
 * Both prospectors, opening on the local one.
 *
 * The B2B tool is mounted here rather than linked to: switching is a state
 * change inside `<ProspectorWorkspace>`, so the route never changes and a crawl
 * streaming into the other panel survives the switch. `/prospector/b2b` renders
 * the same component with the other tab open first, which is what keeps the deep
 * link (and the CRM nav) working.
 */
export default async function Page({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  // The tool is behind the same login as the CRM — it reads and writes the same
  // lead database. The proxy has already turned away anyone without a signed
  // cookie; this is what notices the account was revoked in the meantime.
  const user = await requireUser("/prospector");

  const initialSearch = parseInitialSearch(await searchParams);

  // Run a URL-driven search here rather than from an effect after hydration. A
  // shared link then arrives with its table already rendered — no loading flash,
  // and it works before any JS runs.
  const outcome = initialSearch
    ? await performSearch({ ...initialSearch, limit: 1000 }, user)
    : null;

  return (
    <ProspectorWorkspace
      initialTool="local"
      local={localPanel({
        initialSearch,
        initialResult: outcome?.ok ? outcome.response : null,
        initialError: outcome && !outcome.ok ? outcome.error : null,
        canExport: can(user, "export"),
        viewer: user,
      })}
      b2b={b2bPanel(user)}
    />
  );
}
