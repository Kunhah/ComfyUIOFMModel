import type { Metadata } from "next";
import { ProspectorWorkspace } from "@/components/prospector/workspace";
import { can, requirePermission } from "@/lib/auth/server";
import { b2bPanel, localPanel } from "../panels";

export const metadata: Metadata = {
  title: "Prospector B2B",
  description:
    "Prospecção de empresas B2B por setor e país, com extração de e-mails de contato.",
  robots: { index: false, follow: false },
};

/**
 * Rendered per request, never prerendered.
 *
 * The page has no dynamic input — no searchParams, no cookies — so Next would
 * otherwise treat it as static and bake the counters and the "extract present?"
 * check into the build. The tool would then report zero companies forever, and
 * the build itself would touch `data/`, which is a mounted volume at runtime and
 * absent at build time.
 */
export const dynamic = "force-dynamic";

/**
 * The B2B tool, mounted beside the local-business one.
 *
 * It sits under `/prospector` rather than at its own root so it inherits the
 * tool layout — the `data-prospector` tone block, the noindex, and the
 * `Disallow: /prospector` in robots.ts — without any of them having to learn
 * about a second internal tool.
 *
 * The route survives as a deep link (the CRM nav and `/operador` point at it)
 * but it is no longer a separate screen: it renders the same workspace as
 * `/prospector` with the B2B tab open first, so moving between the two tools is
 * a state change rather than a navigation. Everything after the counters is a
 * client component, because a run is a live stream rather than a page load.
 */
export default async function Page() {
  // Not requireUser: the nav hides this from an operator without the crawler,
  // but only this stops them typing the URL. The routes it calls check again.
  const user = await requirePermission("b2b", "/prospector/b2b");

  return (
    <ProspectorWorkspace
      initialTool="b2b"
      local={localPanel({
        initialSearch: null,
        initialResult: null,
        initialError: null,
        canExport: can(user, "export"),
        viewer: user,
      })}
      b2b={b2bPanel(user)}
    />
  );
}
