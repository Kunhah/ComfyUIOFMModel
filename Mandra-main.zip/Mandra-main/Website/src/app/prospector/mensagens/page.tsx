import { OutreachTemplatesView } from "@/app/admin/(crm)/mensagens/page";
import { requireStaff } from "@/lib/auth/server";

export const dynamic = "force-dynamic";
export const metadata = {
  title: "Mensagem de abordagem",
  robots: { index: false, follow: false },
};

/**
 * The same screen, outside the CRM shell.
 *
 * `requireStaff` rather than `requireOperator`: an admin who follows a link
 * from the prospector should land on the screen, not be bounced to /admin for
 * holding the wrong role. A client never reaches either mount.
 */
export default async function MensagensPage() {
  const user = await requireStaff("/prospector/mensagens");

  return (
    <main className="mx-auto w-full max-w-[1100px] px-5 py-8 md:px-8">
      <OutreachTemplatesView
        isAdmin={user.role === "admin"}
        viewerId={user.id}
        viewerName={user.displayName}
      />
    </main>
  );
}
