import type { MetadataRoute } from "next";
import { site } from "@/content/site";
import { adPages } from "@/content/ads";
import { legalLinks } from "@/content/site";

/**
 * The public map.
 *
 * The ad landing pages are listed at a higher priority than the legal pages
 * and just under the home page: they are the pages written to be found, and
 * one that is not in the sitemap is a page the paid click has to carry alone.
 * `/prospector`, `/admin` and `/app` are internal and stay out — robots.ts
 * disallows them for the same reason.
 */
export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();

  return [
    {
      url: site.url,
      lastModified: now,
      changeFrequency: "monthly",
      priority: 1,
    },
    ...adPages.map((page) => ({
      url: `${site.url}/${page.slug}`,
      lastModified: now,
      changeFrequency: "monthly" as const,
      priority: 0.9,
    })),
    ...legalLinks.map((link) => ({
      url: `${site.url}${link.href}`,
      lastModified: now,
      changeFrequency: "yearly" as const,
      priority: 0.2,
    })),
  ];
}
