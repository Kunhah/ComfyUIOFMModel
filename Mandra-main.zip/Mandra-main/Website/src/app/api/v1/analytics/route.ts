import { callerAddress, rateLimit } from "@/lib/crm/rate-limit";
import { record } from "@/lib/analytics/db";
import { isMeasured } from "@/lib/analytics/pages";
import {
  ALL_SECTIONS,
  DEVICES,
  EVENT_TYPES,
  MAX_EVENTS,
  MAX_NAME,
  SESSION_ID,
  type ClientEvent,
  type Device,
  type Payload,
  type ViewContext,
} from "@/lib/analytics/events";

// node:sqlite, through the analytics writer.
export const runtime = "nodejs";

/**
 * The collector for the landing pages' own analytics.
 *
 * The second route in the app that answers without a session, and it is under
 * `/api/v1/` for exactly the reason the first one is: that prefix falls
 * outside the matcher in `src/proxy.ts`, so the gate never has to grow an
 * exception. The note in AGENTS.md calling `/api/v1/leads` the only such route
 * was true until this shipped.
 *
 * What bounds it, since anyone can post here:
 *
 * - **`page` must be a page we publish and measure.** Without that check the
 *   table is a free-form string store anybody can fill, and the page picker on
 *   the dashboard becomes a list of whatever a bored someone typed. The
 *   allowlist used to be `adPageBySlug` directly; it is now the registry in
 *   `lib/analytics/pages.ts`, which holds the site's own pages as well.
 * - **The rate limit**, generous enough for a reader flushing batches and
 *   useless for a script. Same honest caveat as the intake endpoint: it is an
 *   in-memory window that resets on deploy.
 * - **Every field is rebuilt rather than trusted** — the type must be one we
 *   defined, strings are clamped, numbers are coerced and bounded, and the
 *   referrer is reduced to a hostname before it is stored.
 *
 * It is same-origin only, with no CORS: the landing pages, this route and the
 * dashboard are one container on the VPS with `data/` on its volume.
 *
 * What it deliberately does *not* record: the caller's IP address, any cookie,
 * and the full referring URL. The address is read only to rate-limit on and
 * never reaches the database. A landing page that stores no personal data has
 * nothing to ask LGPD consent for, and that is worth more than the analysis an
 * IP would buy.
 */

/** A reader flushing every few seconds, times a few tabs. A script, no. */
const PER_MINUTE = 60;
const PER_HOUR = 600;

/** Longer than any real visit; anything past it is a clock, not a reader. */
const MAX_T = 6 * 60 * 60 * 1000;

/**
 * The ceiling for an event's `value`, by what the value means.
 *
 * A scroll depth is a percentage and nothing else. Clamping it to the generic
 * ceiling let a client post 9999, which does not throw, does not look wrong in
 * the table, and silently moves that session into the deepest scroll bucket —
 * the failure mode this whole layer is supposed to be immune to.
 */
const MAX_VALUE: Record<string, number> = {
  depth: 100,
  engage: 6 * 60 * 60 * 1000,
  dwell: 6 * 60 * 60 * 1000,
  firstscroll: MAX_T,
  // A burst is a handful of clicks. A client claiming nine hundred is a script
  // or a bug, and either way it must not be able to dominate the column it is
  // summed into.
  rage: 50,
};
const MAX_VALUE_DEFAULT = 10_000_000;

const EVENT_SET = new Set<string>(EVENT_TYPES);
const DEVICE_SET = new Set<string>(DEVICES);

/**
 * The event types whose `name` must be a section we actually publish.
 *
 * These three are grouped on directly by the dashboard, so an unrecognised
 * name is not a harmless extra row — it is a made-up band sitting in the exit
 * table or the dwell list, which anyone who can POST could put there. The
 * types whose name is genuinely free text (a FAQ question, whatever a dead
 * click landed on) are not in this set and stay clamped free text.
 */
const SECTION_NAMED = new Set<string>(["section", "exit", "dwell"]);
const SECTION_SET = new Set<string>(ALL_SECTIONS);

/** Control characters, including the line breaks a pasted value brings along. */
const CONTROL = /[\p{Cc}\p{Cf}]/gu;

/** Identifiers, not prose: control characters out, length clamped. */
function label(value: unknown): string | undefined {
  if (typeof value !== "string") return undefined;
  const cleaned = value.replace(CONTROL, " ").replace(/\s+/g, " ").trim();
  return cleaned.length === 0 ? undefined : cleaned.slice(0, MAX_NAME);
}

function count(value: unknown, max: number): number | undefined {
  if (typeof value !== "number" || !Number.isFinite(value)) return undefined;
  return Math.min(Math.max(Math.round(value), 0), max);
}

/**
 * The referrer, reduced to a host.
 *
 * `new URL()` alone is not the check — it parses `https://lixo!!` and reports
 * `lixo!!` as a hostname, which is the same trap `normaliseOrigin()` exists to
 * avoid on the intake route. A value that is already a bare host is accepted
 * as one; anything that parses to neither is dropped.
 */
const HOSTNAME =
  /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/i;

function referrerHost(value: unknown): string | undefined {
  const raw = label(value);
  if (!raw) return undefined;
  if (HOSTNAME.test(raw)) return raw.toLowerCase().slice(0, 100);
  try {
    const host = new URL(raw).hostname;
    return HOSTNAME.test(host) ? host.toLowerCase().slice(0, 100) : undefined;
  } catch {
    return undefined;
  }
}

/**
 * A campaign tag, or nothing.
 *
 * Google leaves its own placeholder in the URL when a click has no value for
 * that parameter — a display placement has no keyword — so `{keyword}` arrives
 * literally. Storing it would put a fake, very popular keyword at the top of
 * the table. The tracker already drops these; the route does too, because
 * every field here is rebuilt rather than trusted.
 */
function tag(value: unknown): string | undefined {
  const cleaned = label(value);
  return cleaned && !cleaned.startsWith("{") ? cleaned : undefined;
}

function context(raw: unknown): ViewContext | undefined {
  if (!raw || typeof raw !== "object") return undefined;
  const value = raw as Record<string, unknown>;

  const device =
    typeof value.device === "string" && DEVICE_SET.has(value.device)
      ? (value.device as Device)
      : "desktop";

  return {
    device,
    viewport: count(value.viewport, 10_000) ?? 0,
    referrer: referrerHost(value.referrer),
    source: tag(value.source),
    medium: tag(value.medium),
    campaign: tag(value.campaign),
    adgroup: tag(value.adgroup),
    term: tag(value.term),
    matchtype: tag(value.matchtype),
    network: tag(value.network),
    content: tag(value.content),
    gclid: tag(value.gclid),
  };
}

function events(raw: unknown): ClientEvent[] {
  if (!Array.isArray(raw)) return [];

  const out: ClientEvent[] = [];
  for (const item of raw.slice(0, MAX_EVENTS)) {
    if (!item || typeof item !== "object") continue;
    const value = item as Record<string, unknown>;
    if (typeof value.type !== "string" || !EVENT_SET.has(value.type)) continue;

    const name = label(value.name);
    // A section event naming a band we do not publish is dropped whole rather
    // than stored nameless: a row that reached the table having lost the only
    // field that gave it meaning is worse than no row.
    if (SECTION_NAMED.has(value.type) && (!name || !SECTION_SET.has(name))) {
      continue;
    }

    out.push({
      type: value.type as ClientEvent["type"],
      name,
      placement: label(value.placement),
      value: count(value.value, MAX_VALUE[value.type] ?? MAX_VALUE_DEFAULT),
      t: count(value.t, MAX_T) ?? 0,
    });
  }
  return out;
}

export async function POST(request: Request): Promise<Response> {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    // A malformed beacon is not worth an error page; it is worth nothing.
    return new Response(null, { status: 204 });
  }

  if (!body || typeof body !== "object") {
    return new Response(null, { status: 204 });
  }

  const payload = body as Record<string, unknown>;
  const session = typeof payload.session === "string" ? payload.session : "";
  const page = typeof payload.page === "string" ? payload.page : "";

  if (payload.v !== 1 || !SESSION_ID.test(session) || !isMeasured(page)) {
    return new Response(null, { status: 204 });
  }

  const caller = callerAddress(request);
  const perMinute = rateLimit(`analytics:m:${caller}`, PER_MINUTE, 60_000);
  const perHour = rateLimit(`analytics:h:${caller}`, PER_HOUR, 3_600_000);
  if (!perMinute.allowed || !perHour.allowed) {
    return new Response(null, { status: 429 });
  }

  const clean: Payload = {
    v: 1,
    session,
    page,
    context: context(payload.context),
    events: events(payload.events),
  };

  // A batch with no recognisable event still upserts the session's last_at,
  // which is what keeps a long read from looking like a bounce.
  try {
    record(clean, new Date().toISOString());
  } catch {
    // Analytics must never be able to take a page down, and the caller has
    // already navigated away — there is nobody left to tell.
    return new Response(null, { status: 204 });
  }

  return new Response(null, { status: 204 });
}
