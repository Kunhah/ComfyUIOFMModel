import { runTurn, DEFAULT_TIMEZONE } from "@/lib/whatsapp/agent";
import {
  openConversation,
  recordMessage,
  type Conversation,
} from "@/lib/whatsapp/db";
import { parseInbound, webhookTokenValid } from "@/lib/whatsapp/evolution";
import { accountByWaInstance } from "@/lib/crm/accounts";
import { recordProspectorActivity } from "@/lib/prospector/db";
import { callerAddress, rateLimit } from "@/lib/crm/rate-limit";

// node:sqlite, through the conversation writer.
export const runtime = "nodejs";

/**
 * Where WhatsApp messages arrive.
 *
 * Under `/api/v1/` for exactly the reason `/api/v1/leads` is: it answers without
 * a session, and it therefore has to fall *outside* the matcher in
 * `src/proxy.ts`. Putting it under `/api/admin` or `/api/prospector` would mean
 * the session gate grows an exception, which is the edit that quietly opens the
 * others. The `v1` is also a promise — this URL is configured inside the
 * Evolution instance and changing it silently stops every conversation.
 *
 * What protects it, in order:
 *
 * - **The shared secret**, checked in constant time. Unlike the intake endpoint
 *   there is no public key here and no reason for anyone but the bridge to call
 *   it, so this is a real gate rather than an identifier. With no secret
 *   configured *nothing* is accepted — a forgotten variable must not leave an
 *   endpoint open that writes to the lead base and makes the agent talk to
 *   strangers.
 * - **The rate limit**, which bounds a stuck bridge retrying in a loop. It is
 *   generous: a busy number really does produce a burst.
 * - **`parseInbound`**, which drops everything that is not one person's text —
 *   groups, our own echo, receipts, reactions.
 *
 * It answers 200 to almost everything. Evolution retries what it reads as a
 * failure, so a non-2xx on a message we simply do not act on (a photo, a group)
 * buys a retry loop for a decision that will not change.
 */

/**
 * Per address. High because one person typing three messages in a row is three
 * webhooks, and a bridge that reconnects replays a backlog.
 */
const PER_MINUTE = 120;

export async function POST(request: Request): Promise<Response> {
  const presented =
    request.headers.get("x-webhook-token") ??
    // Evolution's webhook configuration cannot always set a header, so the token
    // may travel in the URL instead. Same value, same comparison; a query string
    // is more likely to be written to an access log, which is why the header is
    // the documented option and this is the fallback.
    new URL(request.url).searchParams.get("token");

  if (!webhookTokenValid(presented)) {
    return Response.json({ error: "Não autorizado." }, { status: 401 });
  }

  const verdict = rateLimit(`wa:${callerAddress(request)}`, PER_MINUTE, 60_000);
  if (!verdict.allowed) {
    return Response.json(
      { error: "Muitas requisições." },
      { status: 429, headers: { "retry-after": String(verdict.retryAfter) } },
    );
  }

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const inbound = parseInbound(payload);
  // Not an error: delivery receipts, group traffic and our own echo all land
  // here and all mean "nothing to do".
  if (!inbound) return Response.json({ ok: true, handled: false });

  // Which of our paired numbers was this sent to? One Evolution serves every
  // account, so the instance name is the only thing in the payload that says
  // whose CRM the message belongs in — the sender's number says who wrote,
  // never who they wrote to.
  const routed = routeToAccount(inbound.instance);
  if (!routed.ok) {
    // 200, not an error: the bridge would retry a non-2xx forever, and none of
    // these resolve by being tried again. Logged instead, because an instance
    // that reaches us and matches no account is a real misconfiguration —
    // someone paired a number and never bound it to a client.
    console.error(
      JSON.stringify({
        service: "whatsapp",
        event: "inbound.unrouted",
        instance: inbound.instance,
        reason: routed.reason,
      }),
    );
    return Response.json({ ok: true, handled: false, reason: routed.reason });
  }

  const conversation = openConversation({
    phone: inbound.phone,
    accountId: routed.accountId,
    contactName: inbound.pushName,
    timezone: DEFAULT_TIMEZONE,
  });

  const stored = recordMessage({
    conversationId: conversation.id,
    direction: "in",
    origin: "client",
    body: inbound.text,
    providerId: inbound.providerId,
  });

  // Null means this provider id was already recorded — a retried webhook. The
  // message is in the transcript once and was answered once; answering again is
  // the exact failure the unique constraint exists to prevent.
  if (!stored)
    return Response.json({ ok: true, handled: false, duplicate: true });

  noteInbound(conversation, inbound.text);

  // A thread a person has taken over is not answered. `auto_reply` is the
  // handoff switch; the message is still stored, which is the whole point — the
  // operator reads it in the CRM.
  if (!conversation.autoReply) {
    return Response.json({ ok: true, handled: true, autoReply: false });
  }

  // Awaited rather than backgrounded. A serverless-style host kills work that
  // outlives the response, and on this container the agent takes a couple of
  // seconds — well inside any proxy timeout — so the simple thing is also the
  // correct one. If it ever isn't, the fix is a queue, not a floating promise.
  const turn = await runTurn(conversation.id);

  if (turn.error) {
    console.error(
      JSON.stringify({
        service: "whatsapp",
        event: "turn.failed",
        conversation: conversation.id,
        message: turn.error,
      }),
    );
  }

  if (turn.applied.length > 0) {
    recordProspectorActivity({
      actor: {
        id: "whatsapp:agent",
        username: "whatsapp",
        displayName: "Agente WhatsApp",
      },
      action: "outreach",
      leadId: conversation.leadId ?? undefined,
      detail: turn.applied.join(" · "),
    });
  }

  return Response.json({
    ok: true,
    handled: true,
    replied: turn.sent !== null,
    actions: turn.applied.length,
  });
}

/**
 * Records the inbound message against the lead as an audit line.
 *
 * Only the first message of a thread, and only when we know the lead: an audit
 * with one row per WhatsApp message would drown the screen an operator uses to
 * see what happened to a business. "This lead started talking to us" is the
 * event worth a row; the rest is the transcript's job.
 */
function noteInbound(conversation: Conversation, text: string): void {
  if (!conversation.leadId) return;
  if (conversation.lastInboundAt) return;
  recordProspectorActivity({
    actor: {
      id: "whatsapp:agent",
      username: "whatsapp",
      displayName: "Agente WhatsApp",
    },
    action: "outreach",
    leadId: conversation.leadId,
    detail: `Mensagem recebida no WhatsApp: "${text.slice(0, 120)}"`,
  });
}

/**
 * Turns the instance a message arrived on into the account it belongs to.
 *
 * Three outcomes, kept apart because they are three different mistakes:
 *
 * - **Our own number.** The instance matches `EVOLUTION_INSTANCE`, so this is
 *   Atlas prospecting, and the account is null — the same "null means ours" the
 *   leads table uses.
 * - **A client's number**, bound to an account. The normal case.
 * - **Neither.** A paired instance nobody has bound, or a payload with no
 *   instance at all. Dropped rather than defaulted to ours: filing a stranger's
 *   message into Atlas's pipeline would have the agent answer it with our
 *   persona, on a number that is not ours.
 *
 * A suspended account is also refused. It is the one case where dropping the
 * message is visibly wrong to the person who sent it — but replying on behalf of
 * a business whose account we have turned off is worse, and the message is not
 * lost: it is on the phone the instance is paired to.
 */
function routeToAccount(
  instance: string | null,
): { ok: true; accountId: string | null } | { ok: false; reason: string } {
  if (!instance) return { ok: false, reason: "sem-instancia" };

  const ours = process.env.EVOLUTION_INSTANCE?.trim();
  if (ours && instance === ours) return { ok: true, accountId: null };

  const account = accountByWaInstance(instance);
  if (!account) return { ok: false, reason: "instancia-sem-conta" };
  if (!account.active) return { ok: false, reason: "conta-suspensa" };

  return { ok: true, accountId: account.id };
}
