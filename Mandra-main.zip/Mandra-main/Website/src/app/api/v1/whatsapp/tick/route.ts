import { dispatchDue } from "@/lib/whatsapp/scheduler";
import { webhookTokenValid } from "@/lib/whatsapp/evolution";

export const runtime = "nodejs";

/**
 * The scheduler, pokeable from outside.
 *
 * The in-process timer in `instrumentation.ts` is the normal path and this is
 * not needed in the standard deployment. It exists because that timer has one
 * real weakness — it only runs while a container is up, and a host that scales
 * to zero or restarts on a schedule has windows where nobody is watching the
 * queue. Pointing a system crontab or an uptime pinger at this URL closes that
 * without changing how anything works: the tick is the same function, and it is
 * safe to call at any frequency because everything it decides comes from the row
 * it is holding.
 *
 * Behind the same shared secret as the webhook, and under `/api/v1/` for the
 * same reason — an external caller has no session, so the route must sit outside
 * the proxy's matcher rather than make the gate grow an exception.
 *
 * GET as well as POST: half the things that ping a URL on a schedule only do
 * GET, and this has no side effect an accidental second call could damage.
 */
async function tick(request: Request): Promise<Response> {
  const presented =
    request.headers.get("x-webhook-token") ??
    new URL(request.url).searchParams.get("token");

  if (!webhookTokenValid(presented)) {
    return Response.json({ error: "Não autorizado." }, { status: 401 });
  }

  const result = await dispatchDue();
  return Response.json({ ok: true, ...result });
}

export async function POST(request: Request): Promise<Response> {
  return tick(request);
}

export async function GET(request: Request): Promise<Response> {
  return tick(request);
}
