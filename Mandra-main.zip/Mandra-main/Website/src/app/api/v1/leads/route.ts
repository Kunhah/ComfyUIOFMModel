import { submitLead, type Submission } from "@/lib/crm/intake";
import { siteByKey, type IntakeSite } from "@/lib/crm/sites";
import { callerAddress, rateLimit } from "@/lib/crm/rate-limit";

// node:sqlite, through the intake writer.
export const runtime = "nodejs";

/**
 * The one endpoint a customer's website talks to.
 *
 * It is deliberately outside `/api/prospector` and `/api/admin`, and therefore
 * outside the proxy's matcher in `src/proxy.ts` — this is the only route in the
 * app that answers without a session, and putting it under a path the matcher
 * covers would mean the gate has to grow an exception. A `/api/v1/` prefix also
 * says what it is: the contract a site we shipped depends on, which we cannot
 * rename the way we rename an internal route.
 *
 * What actually protects it:
 *
 * - **The origin allowlist**, which stops another *website* posting into a
 *   customer's CRM from a visitor's browser. It does not stop curl, and cannot:
 *   the key ships in public page source, so anyone who views source has it. That
 *   is a property of an embeddable form, not a flaw to be patched.
 * - **The rate limit**, which is what actually bounds the damage a determined
 *   caller can do — see the honesty note in lib/crm/rate-limit.ts.
 * - **The honeypot**, which catches the bots that fill every field they find.
 *
 * So: every stored value is treated as text a stranger typed. Nothing here is
 * rendered as HTML, nothing is interpolated into SQL, and the lead lands in the
 * CRM as `source = 'formulario'` so an operator can see where it came from.
 */

/** Per address, per site. Generous for a human, useless for a script. */
const PER_MINUTE = 5;
const PER_HOUR = 30;

/**
 * Long enough for a real enquiry, short enough that the notes column stays
 * readable in a table cell. Anything longer is truncated rather than rejected —
 * losing the tail of a genuine message is better than losing the lead.
 */
const MAX_MESSAGE = 4_000;
const MAX_FIELD = 200;
/** Extra fields beyond this are dropped; a form with 25 questions is a bot. */
const MAX_EXTRA_FIELDS = 20;

/** Control characters, including the newlines a pasted spreadsheet cell brings along. */
const CONTROL = /[\u0000-\u001f\u007f]/g;
/** The same set minus the line breaks, for the one field meant to have them. */
const CONTROL_KEEP_BREAKS = /[\u0000-\u0009\u000b\u000c\u000e-\u001f\u007f]/g;

function text(value: unknown, max: number): string | null {
  if (typeof value !== "string") return null;
  const cleaned = value.replace(CONTROL, " ").replace(/\s+/g, " ").trim();
  return cleaned.length === 0 ? null : cleaned.slice(0, max);
}

/**
 * The message field, the only one a person writes in paragraphs.
 *
 * Line breaks survive; runs of three or more collapse to two, so a textarea
 * submitted full of blank lines doesn't push the rest of the note out of view in
 * the CRM's row.
 */
function multiline(value: unknown, max: number): string | null {
  if (typeof value !== "string") return null;
  const cleaned = value
    .replace(/\r\n?/g, "\n")
    .replace(CONTROL_KEEP_BREAKS, " ")
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
  return cleaned.length === 0 ? null : cleaned.slice(0, max);
}

/**
 * Deliberately permissive: one @, a dot in the domain, no spaces. A stricter
 * pattern rejects real addresses (plus tags, new TLDs, non-ASCII locals) and the
 * only thing riding on this is whether we treat the string as a dedupe key, so a
 * false accept costs one duplicate lead and a false reject costs a customer.
 */
function email(value: unknown): string | null {
  const raw = text(value, 254);
  if (!raw) return null;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(raw) ? raw.toLowerCase() : null;
}

/**
 * The origin check.
 *
 * A browser always sends `Origin` on a cross-origin POST, so a present-but-wrong
 * one is a real answer and is refused. An absent one means the caller is not a
 * browser — a server-side integration, a form posted from a backend — which we
 * allow, because refusing it would buy nothing (curl can send any Origin it
 * likes) while breaking the legitimate case.
 */
function originAllowed(site: IntakeSite, origin: string | null): boolean {
  if (!origin || origin === "null") return true;
  return site.origins.includes(origin);
}

/**
 * CORS headers for a permitted origin.
 *
 * `Origin` is echoed rather than answered with `*` because `*` would let every
 * site on the internet read the response, and the response carries the lead id.
 * `Vary: Origin` because the answer differs per caller and a shared cache that
 * missed that would hand one customer's headers to another's visitors.
 */
function cors(origin: string | null): Record<string, string> {
  const headers: Record<string, string> = { Vary: "Origin" };
  if (origin && origin !== "null") {
    headers["Access-Control-Allow-Origin"] = origin;
  }
  headers["Access-Control-Allow-Methods"] = "POST, OPTIONS";
  headers["Access-Control-Allow-Headers"] = "Content-Type";
  headers["Access-Control-Max-Age"] = "86400";
  return headers;
}

/**
 * The preflight.
 *
 * It has to answer before the POST does, and it answers per site — a browser
 * that gets `Access-Control-Allow-Origin` here for an origin the POST will
 * refuse would show the developer a successful preflight and a mystifying 403.
 * The key travels in the query string on this one because a preflight carries no
 * body by definition.
 */
export async function OPTIONS(request: Request): Promise<Response> {
  const origin = request.headers.get("origin");
  const key = new URL(request.url).searchParams.get("key");
  const site = key ? siteByKey(key) : null;

  if (!site || !site.active || !originAllowed(site, origin)) {
    // No CORS headers at all, which is what makes the browser refuse the POST.
    // 204 rather than 403: the preflight itself succeeded, the answer is simply
    // that this origin may not proceed.
    return new Response(null, { status: 204, headers: { Vary: "Origin" } });
  }

  return new Response(null, { status: 204, headers: cors(origin) });
}

export async function POST(request: Request): Promise<Response> {
  const origin = request.headers.get("origin");

  let body: Record<string, unknown>;
  try {
    const parsed = (await request.json()) as unknown;
    if (
      typeof parsed !== "object" ||
      parsed === null ||
      Array.isArray(parsed)
    ) {
      throw new Error("not an object");
    }
    body = parsed as Record<string, unknown>;
  } catch {
    return Response.json(
      { error: "JSON inválido." },
      { status: 400, headers: cors(origin) },
    );
  }

  const key = typeof body.key === "string" ? body.key : "";
  const site = key ? siteByKey(key) : null;
  if (!site) {
    return Response.json(
      { error: "Chave de site inválida." },
      { status: 401, headers: { Vary: "Origin" } },
    );
  }
  if (!site.active) {
    // Told apart from an unknown key on purpose: this one the customer can have
    // fixed by asking, and a form that says "invalid key" sends them looking for
    // a typo that isn't there.
    return Response.json(
      { error: "Este site está desativado." },
      { status: 403, headers: { Vary: "Origin" } },
    );
  }
  if (!originAllowed(site, origin)) {
    return Response.json(
      { error: "Origem não autorizada para este site." },
      { status: 403, headers: { Vary: "Origin" } },
    );
  }

  const address = callerAddress(request);
  const minute = rateLimit(
    `intake:m:${site.id}:${address}`,
    PER_MINUTE,
    60_000,
  );
  const hour = rateLimit(`intake:h:${site.id}:${address}`, PER_HOUR, 3_600_000);
  if (!minute.allowed || !hour.allowed) {
    const retryAfter = !minute.allowed ? minute.retryAfter : hour.retryAfter;
    return Response.json(
      { error: "Muitas tentativas. Tente novamente em instantes." },
      {
        status: 429,
        headers: { ...cors(origin), "Retry-After": String(retryAfter) },
      },
    );
  }

  // The honeypot, answered with success on purpose. A bot told it failed retries
  // with the field cleared; a bot told it succeeded goes away. The field is
  // hidden from people by the snippet's CSS, so a human never fills it.
  const trap = text(body._gotcha, 100);
  if (trap) {
    return Response.json({ ok: true }, { status: 202, headers: cors(origin) });
  }

  const name = text(body.name, 120);
  if (!name) {
    return Response.json(
      { error: "Informe o nome." },
      { status: 400, headers: cors(origin) },
    );
  }

  const mail = email(body.email);
  const phone = text(body.phone, 40);
  if (!mail && !phone) {
    // Without one of the two the lead cannot be answered, and the CRM cannot
    // recognise the person if they write again. Requiring either — rather than
    // e-mail specifically — is what lets a WhatsApp-first customer ask only for
    // a number.
    return Response.json(
      { error: "Informe um e-mail ou um telefone." },
      { status: 400, headers: cors(origin) },
    );
  }

  const submission: Submission = {
    name,
    email: mail,
    phone,
    message: multiline(body.message, MAX_MESSAGE),
    company: text(body.company, 120),
    city: text(body.city, 80),
    uf: text(body.uf, 40),
    pageUrl: pageUrl(body.pageUrl),
    extra: extraFields(body.fields),
  };

  try {
    const result = submitLead(site, submission);
    return Response.json(
      { ok: true, id: result.leadId, created: result.created },
      { status: result.created ? 201 : 200, headers: cors(origin) },
    );
  } catch (error) {
    // The customer's visitor is not the audience for a stack trace, and the
    // customer's form should not show one either.
    console.error("Intake failed", error);
    return Response.json(
      { error: "Não foi possível registrar o contato." },
      { status: 500, headers: cors(origin) },
    );
  }
}

/**
 * The page the form was on, kept only if it parses as an http(s) URL.
 *
 * It is written into the notes an operator reads and, on the admin screens, is
 * shown as text — but it comes from the visitor's browser through a field the
 * caller controls, so a `javascript:` string must not survive to become an
 * href the day someone decides to make it clickable. Same rule the CRM already
 * applies to social URLs.
 */
function pageUrl(value: unknown): string | null {
  const raw = text(value, 500);
  if (!raw) return null;
  try {
    const url = new URL(raw);
    return url.protocol === "https:" || url.protocol === "http:"
      ? url.href
      : null;
  } catch {
    return null;
  }
}

/**
 * Whatever else the customer's form carried.
 *
 * Both the label and the value are the customer's, so both are cleaned and
 * capped. Order is preserved — a form's fields read in the order they were
 * asked, and re-sorting them makes the note harder to read than the form was.
 */
function extraFields(value: unknown): Record<string, string> {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    return {};
  }
  const out: Record<string, string> = {};
  for (const [rawLabel, rawValue] of Object.entries(value)) {
    if (Object.keys(out).length >= MAX_EXTRA_FIELDS) break;
    const label = text(rawLabel, 60);
    const field = text(rawValue, MAX_FIELD);
    if (label && field) out[label] = field;
  }
  return out;
}
