import { headers } from "next/headers";
import { currentUser, forbidden, unauthorized } from "@/lib/auth/server";
import { findAccountBySlug } from "@/lib/crm/accounts";
import { listAccountSites } from "@/lib/crm/sites";
import { clientClaudeMd } from "@/lib/crm/claude-md";

// node:sqlite, through the account and site readers.
export const runtime = "nodejs";

/**
 * The client site's `CLAUDE.md`, as a file to drop into their repository.
 *
 * A download rather than only a copy button because the destination is a file
 * at a repository root with a name that matters — `CLAUDE.md` is what Claude
 * Code reads, and a paste into a file somebody names `claude.md` or
 * `docs/claude.md` is a paste into a file that never gets read.
 *
 * Admin-only and re-checked here. The body carries the site key, which is
 * public in the sense that it ships in page source — but this route also names
 * every allowed origin and the account's slug, and that is a description of a
 * customer's setup rather than a value from it.
 */
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ slug: string }> },
): Promise<Response> {
  // Re-checked here rather than trusted from the matcher, like every other
  // route: the proxy admits any valid session to /api/admin/*, so the role
  // check is what actually decides.
  const user = await currentUser();
  if (!user) return unauthorized();
  if (user.role !== "admin") return forbidden();

  const { slug } = await params;
  const account = findAccountBySlug(slug);
  if (!account) {
    return Response.json({ error: "Conta não encontrada." }, { status: 404 });
  }

  const head = await headers();
  const host = head.get("x-forwarded-host") ?? head.get("host") ?? "";
  const proto = head.get("x-forwarded-proto") ?? "https";

  const body = clientClaudeMd({
    account,
    sites: listAccountSites(account.id),
    crmOrigin: host ? `${proto}://${host}` : "",
  });

  return new Response(body, {
    headers: {
      "content-type": "text/markdown; charset=utf-8",
      // The filename is the point of the download. Quoted because the slug can
      // carry hyphens, and ASCII-only by construction — slugify() strips
      // accents, so there is no need for the filename* encoding here.
      "content-disposition": `attachment; filename="CLAUDE.md"`,
      // It names a live key and a live origin list; a stale copy in a proxy is
      // a copy that installs a form pointing at a domain we have since changed.
      "cache-control": "no-store",
    },
  });
}
