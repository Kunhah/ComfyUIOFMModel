import {
  ACTIVITY_CSV_HEADERS,
  activityCsvRow,
  parseActivityFilters,
} from "@/lib/admin/activity";
import { findAccount } from "@/lib/admin/operators";
import { currentUser, forbidden, unauthorized } from "@/lib/auth/server";
import { allActivity } from "@/lib/prospector/db";
import { textCsvResponse } from "@/lib/prospector/csv";

// node:sqlite is a Node builtin, so this can't run on the edge runtime.
export const runtime = "nodejs";

/**
 * The operator audit trail as a spreadsheet.
 *
 * Admin only, and not behind the "export" permission: that grant is about
 * letting leads out of the building, while this is the record of who did what —
 * an operator holding it must still not be able to download everyone's history.
 *
 * A GET with the page's own query string, so the download link is the view the
 * admin is looking at with a different path. Both sides read the filters through
 * `parseActivityFilters`, which is what stops the file disagreeing with the page.
 */
export async function GET(request: Request): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();
  if (user.role !== "admin") return forbidden();

  const params = Object.fromEntries(new URL(request.url).searchParams);
  const filters = parseActivityFilters(params);
  const events = allActivity(filters);

  const account = filters.actorId ? findAccount(filters.actorId) : null;
  const parts = [
    "atividade",
    account?.username ?? (filters.actorId ? "acesso" : null),
    filters.action,
    filters.from,
    filters.to,
  ].filter(Boolean) as string[];

  return textCsvResponse(
    ACTIVITY_CSV_HEADERS,
    events.map(activityCsvRow),
    parts.join("-"),
  );
}
