import { NextResponse } from "next/server";
import {
  ADMIN_SUBJECT,
  adminAccount,
  authenticateAdmin,
  roleHome,
  type SessionUser,
} from "@/lib/auth/server";
import {
  SESSION_COOKIE,
  SESSION_TTL_SECONDS,
  cookieOptions,
  isRole,
  isSecureRequest,
  sessionConfigured,
  signSession,
  type Role,
} from "@/lib/auth/session";
import { authenticate, recordLogin } from "@/lib/auth/users";
import { findAccount } from "@/lib/crm/accounts";

// node:crypto and node:sqlite both live behind this.
export const runtime = "nodejs";

/**
 * Log in and log out.
 *
 * Two kinds of account arrive at the same form. The administrator's credentials
 * come from the environment and have no database row — there is one of them, it
 * has to exist before anything else does, and the account that hands out access
 * should not be something the database can be edited to grant. Everyone else is
 * a row in `users`, created by the admin and revocable by the admin.
 *
 * A form POST rather than fetch, so the login page needs no JavaScript.
 */

/**
 * Failed attempts per IP. In memory on purpose: this is one container serving
 * one small team, and the alternative is a table written to on every bad
 * password — which is exactly the request an attacker controls the rate of.
 * Restarting the process clears it, which is an acceptable price.
 */
const attempts = new Map<string, { count: number; until: number }>();
const MAX_ATTEMPTS = 10;
const LOCKOUT_MS = 15 * 60 * 1000;

/**
 * A relative Location, which keeps the browser on whichever host and scheme it
 * used to reach us — no guessing at the public origin from behind a reverse
 * proxy. Route handlers may do this; `src/proxy.ts` may not, and says why.
 */
function redirectTo(path: string, status = 303): NextResponse {
  return new NextResponse(null, { status, headers: { Location: path } });
}

function clientKey(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for");
  return (forwarded?.split(",")[0] ?? "local").trim();
}

function throttled(key: string): boolean {
  const entry = attempts.get(key);
  if (!entry) return false;
  if (Date.now() > entry.until) {
    attempts.delete(key);
    return false;
  }
  return entry.count >= MAX_ATTEMPTS;
}

function recordFailure(key: string): void {
  const entry = attempts.get(key);
  if (entry && Date.now() <= entry.until) {
    entry.count += 1;
    return;
  }
  attempts.set(key, { count: 1, until: Date.now() + LOCKOUT_MS });
}

/** Only ever back into the app, never to an absolute URL a form field supplied. */
function safeDestination(next: string): string {
  return next.startsWith("/") && !next.startsWith("//") ? next : "/admin";
}

/**
 * Which login form a portal sends people back to.
 *
 * The client portal lives at /app while its role is `cliente`, so the two can't
 * be the same string the way "admin" and "operador" happen to be. Everything
 * else here keys off the role, which is what line 132's `user.role !== portal`
 * check depends on — the mapping is only for the URL.
 */
const LOGIN_PATH: Record<Role, string> = {
  admin: "/admin/login",
  operador: "/operador/login",
  cliente: "/app/login",
};

function backToLogin(next: string, error: string, portal: Role): Response {
  const params = new URLSearchParams({ error });
  if (next !== roleHome(portal)) params.set("next", next);
  return redirectTo(`${LOGIN_PATH[portal]}?${params.toString()}`);
}

export async function POST(request: Request) {
  const form = await request.formData();
  const submitted = String(form.get("portal") ?? "");
  const portal: Role = isRole(submitted) ? submitted : "admin";
  const next = safeDestination(String(form.get("next") ?? roleHome(portal)));

  if (form.get("intent") === "logout") {
    const response = redirectTo("/admin/login");
    response.cookies.set(
      SESSION_COOKIE,
      "",
      cookieOptions(0, isSecureRequest(request)),
    );
    return response;
  }

  // Without a signing secret no cookie can be issued, so say that rather than
  // rejecting correct credentials as if they were wrong.
  if (!sessionConfigured() || !adminAccount()) {
    return backToLogin(next, "config", portal);
  }

  const key = clientKey(request);
  if (throttled(key)) return backToLogin(next, "throttled", portal);

  const username = String(form.get("username") ?? "");
  const password = String(form.get("password") ?? "");

  let user: SessionUser | null = authenticateAdmin(username, password);
  if (!user) {
    const account = authenticate(username, password);
    if (account) {
      user = {
        id: account.id,
        username: account.username,
        displayName: account.displayName,
        role: account.role,
        accountId: account.accountId,
        // Carried for the caller's benefit only. The cookie never holds them —
        // every request re-reads the row, so a revoked grant bites immediately.
        permissions: account.permissions,
      };
      recordLogin(account.id);
    }
  }

  if (!user || user.role !== portal) {
    recordFailure(key);
    return backToLogin(next, user ? "role" : "1", portal);
  }

  // A suspended account is not a login. Checked here as well as in
  // requireClient() because the two answer different questions: this one stops
  // a cookie being issued, that one stops an issued cookie still working.
  if (user.role === "cliente") {
    const account = user.accountId ? findAccount(user.accountId) : null;
    if (!account || !account.active) {
      recordFailure(key);
      return backToLogin(next, "suspensa", portal);
    }
  }

  attempts.delete(key);

  const token = await signSession({
    sub: user.id === ADMIN_SUBJECT ? ADMIN_SUBJECT : user.id,
    name: user.username,
    role: user.role,
  });
  if (!token) return backToLogin(next, "config", portal);

  const response = redirectTo(next);
  response.cookies.set(
    SESSION_COOKIE,
    token,
    cookieOptions(SESSION_TTL_SECONDS, isSecureRequest(request)),
  );
  return response;
}
