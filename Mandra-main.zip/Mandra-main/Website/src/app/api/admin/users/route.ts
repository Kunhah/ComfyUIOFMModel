import { currentUser, forbidden, unauthorized } from "@/lib/auth/server";
import { createUser, listUsers } from "@/lib/auth/users";
import { findAccount } from "@/lib/crm/accounts";

// node:crypto for the password hash, node:sqlite for the table.
export const runtime = "nodejs";

/**
 * The accounts the admin hands out.
 *
 * Every handler re-checks the role. The proxy knows there is a valid session and
 * the nav hides the link from operators, but neither of those stops an operator
 * from typing the URL — only this does.
 */

export async function GET(): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();
  if (user.role !== "admin") return forbidden();

  return Response.json({ users: listUsers() });
}

export async function POST(request: Request): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();
  if (user.role !== "admin") return forbidden();

  let body: {
    username?: string;
    displayName?: string;
    password?: string;
    role?: string;
    accountId?: string;
  };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  // Only two roles are creatable here, and 'admin' is not one of them —
  // createUser() enforces that as well. A client login must name an account;
  // the account is re-read rather than trusted, so a typo'd id is a 400 now
  // instead of a login that works and shows an empty pipeline forever.
  const cliente = body.role === "cliente";
  if (cliente && !findAccount(String(body.accountId ?? ""))) {
    return Response.json({ error: "Conta não encontrada." }, { status: 400 });
  }

  const result = createUser({
    username: String(body.username ?? ""),
    displayName: String(body.displayName ?? ""),
    password: String(body.password ?? ""),
    createdBy: user.username,
    role: cliente ? "cliente" : "operador",
    accountId: cliente ? String(body.accountId) : null,
  });

  if (!result.ok)
    return Response.json({ error: result.error }, { status: 400 });
  return Response.json({ user: result.user }, { status: 201 });
}
