import { currentUser, forbidden, unauthorized } from "@/lib/auth/server";
import {
  deleteUser,
  findById,
  revokeSessions,
  setActive,
  setPassword,
  setPermissions,
} from "@/lib/auth/users";

export const runtime = "nodejs";

/**
 * Everything the admin does to one account: grant, revoke, reset the password,
 * change what it may do, sign it out, remove it.
 *
 * Revoking and resetting both end the account's open sessions (see
 * `sessions_valid_from` in lib/auth/users.ts). Without that, "revoke" would mean
 * "stop them logging in again", and someone already inside would stay inside for
 * the rest of the day. `signOut` is that same bump on its own — ending a session
 * without taking the access away.
 *
 * Changing permissions deliberately does *not* end sessions: they are re-read
 * from the row on every request, so the change is already live.
 */

async function admin(): Promise<Response | null> {
  const user = await currentUser();
  if (!user) return unauthorized();
  if (user.role !== "admin") return forbidden();
  return null;
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const denied = await admin();
  if (denied) return denied;

  const { id } = await params;
  if (!findById(id)) {
    return Response.json({ error: "Acesso não encontrado." }, { status: 404 });
  }

  let body: {
    active?: boolean;
    password?: string;
    permissions?: unknown;
    signOut?: boolean;
  };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  if (typeof body.active === "boolean" && !setActive(id, body.active)) {
    return Response.json({ error: "Acesso não encontrado." }, { status: 404 });
  }

  if (typeof body.password === "string") {
    const error = setPassword(id, body.password);
    if (error) return Response.json({ error }, { status: 400 });
  }

  // The whole grant, never a single key: two admin tabs editing one account
  // would otherwise silently undo each other. Unknown names are dropped by
  // setPermissions rather than rejected — the client sends what its checkboxes
  // know about, and a stale tab must not 400.
  if (body.permissions !== undefined) {
    if (!Array.isArray(body.permissions)) {
      return Response.json(
        { error: "permissions deve ser uma lista." },
        { status: 400 },
      );
    }
    if (!setPermissions(id, body.permissions)) {
      return Response.json(
        { error: "Acesso não encontrado." },
        { status: 404 },
      );
    }
  }

  // Last, so it also ends the session of an account whose permissions were just
  // narrowed and whose admin wanted them out of the tool immediately.
  if (body.signOut === true && !revokeSessions(id)) {
    return Response.json({ error: "Acesso não encontrado." }, { status: 404 });
  }

  return Response.json({ user: findById(id) });
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const denied = await admin();
  if (denied) return denied;

  const { id } = await params;
  if (!deleteUser(id)) {
    return Response.json({ error: "Acesso não encontrado." }, { status: 404 });
  }
  return Response.json({ ok: true });
}
