import { currentUser, forbidden, unauthorized } from "@/lib/auth/server";
import { setAutoReply } from "@/lib/whatsapp/db";

export const runtime = "nodejs";

/**
 * The handoff switch: whether the agent answers this thread.
 *
 * Its own endpoint rather than a field on the send route, because giving a
 * thread back to the bot is a decision an operator makes on purpose — usually
 * after resolving whatever made them take it — and it must not be a side effect
 * of anything else.
 */
/**
 * WhatsApp is Atlas staff only.
 *
 * The proxy admits any valid session to `/api/admin/*`, and a `cliente` holds
 * one — so without this a client could post a `conversationId` belonging to
 * another account and send from our number into a stranger's thread. Being
 * signed in was never the question here; being one of us is.
 *
 * Clients get their own WhatsApp through their own account's instance, not
 * through this screen.
 */
async function staff() {
  const user = await currentUser();
  if (!user) return { user: null, denied: unauthorized() };
  if (user.role === "cliente") {
    return { user: null, denied: forbidden("Esta área é da equipe Atlas.") };
  }
  return { user, denied: null };
}

export async function POST(request: Request): Promise<Response> {
  // The proxy already turned away unsigned requests; this is the check that
  // knows the account was revoked since. Every route repeats it — a matcher
  // edit must not be able to silently open one.
  const { denied } = await staff();
  if (denied) return denied;

  let body: { conversationId?: string; auto?: unknown };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const id = String(body.conversationId ?? "");
  if (!id)
    return Response.json({ error: "conversationId ausente." }, { status: 400 });

  if (!setAutoReply(id, body.auto === true)) {
    return Response.json(
      { error: "Conversa não encontrada." },
      { status: 404 },
    );
  }

  return Response.json({ ok: true, auto: body.auto === true });
}
