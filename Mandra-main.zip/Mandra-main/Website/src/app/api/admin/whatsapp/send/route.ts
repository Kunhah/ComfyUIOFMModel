import { currentUser, forbidden, unauthorized } from "@/lib/auth/server";
import { normalisePhone } from "@/lib/prospector/score";
import { recordProspectorActivity } from "@/lib/prospector/db";
import { openConversation, setAutoReply } from "@/lib/whatsapp/db";
import { deliver } from "@/lib/whatsapp/sender";
import { DEFAULT_TIMEZONE } from "@/lib/whatsapp/agent";

export const runtime = "nodejs";

/**
 * An operator typing into a thread, and the only way a conversation is started
 * from our side.
 *
 * Sending as a person turns the agent off on that thread. The alternative — a
 * human and a model both answering — produces the company arguing with itself in
 * front of a customer, and it is the single most embarrassing thing this feature
 * could do. Turning it back on is a deliberate click on the same screen.
 */
/**
 * WhatsApp is Atlas staff only.
 *
 * The proxy admits any valid session to `/api/admin/*`, and a `cliente` holds
 * one — so without this a client could post a `conversationId` belonging to
 * another account and send from our number into a stranger's thread. Being
 * signed in was never the question here; being one of us is.
 *
 * Clients get their own WhatsApp through their own account's instance, not
 * through this screen.
 */
async function staff() {
  const user = await currentUser();
  if (!user) return { user: null, denied: unauthorized() };
  if (user.role === "cliente") {
    return { user: null, denied: forbidden("Esta área é da equipe Atlas.") };
  }
  return { user, denied: null };
}

export async function POST(request: Request): Promise<Response> {
  // The proxy already turned away unsigned requests; this is the check that
  // knows the account was revoked since. Every route repeats it — a matcher
  // edit must not be able to silently open one.
  const { user, denied } = await staff();
  if (denied) return denied;

  let body: {
    conversationId?: string;
    phone?: string;
    leadId?: string;
    country?: string;
    text?: string;
  };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const text = String(body.text ?? "").trim();
  if (!text)
    return Response.json({ error: "Mensagem vazia." }, { status: 400 });

  let conversationId = body.conversationId ? String(body.conversationId) : null;

  // Opening a thread from a lead. The phone is re-folded here rather than
  // trusted as sent: it arrives from a browser, and the folded form is the key
  // the conversation table is unique on — a raw one would open a second thread
  // with the same person.
  if (!conversationId) {
    const phone = normalisePhone(
      String(body.phone ?? ""),
      body.country ?? null,
    );
    if (!phone) {
      return Response.json(
        { error: "Informe uma conversa existente ou um telefone válido." },
        { status: 400 },
      );
    }
    conversationId = openConversation({
      phone,
      // Atlas's own outreach. `staff()` above has already refused a client, so
      // there is no account to take this from — and defaulting to one would be
      // the bug, not the omission.
      accountId: null,
      country: body.country ?? null,
      timezone: DEFAULT_TIMEZONE,
    }).id;
  }

  setAutoReply(conversationId, false);

  const delivery = await deliver({
    conversationId,
    text,
    origin: "operator",
  });

  if (!delivery.ok) {
    // 502, not 400: the request was fine and the bridge was not. A 400 would
    // read on screen as "you typed something wrong".
    return Response.json({ error: delivery.error }, { status: 502 });
  }

  if (body.leadId) {
    recordProspectorActivity({
      actor: user,
      action: "outreach",
      leadId: String(body.leadId),
      detail: "Mensagem enviada pelo WhatsApp",
    });
  }

  return Response.json({ ok: true, conversationId });
}
