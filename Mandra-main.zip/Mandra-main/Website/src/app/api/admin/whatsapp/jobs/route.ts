import { currentUser, forbidden, unauthorized } from "@/lib/auth/server";
import { parseAgentReply } from "@/lib/whatsapp/actions";
import {
  activeJobs,
  closeJob,
  conversationById,
  jobById,
} from "@/lib/whatsapp/db";
import { DEFAULT_TIMEZONE } from "@/lib/whatsapp/agent";
import {
  dispatchDue,
  scheduleRecurring,
  scheduleReminder,
} from "@/lib/whatsapp/scheduler";

export const runtime = "nodejs";

/** The schedule, for the admin screen. */
/**
 * WhatsApp is Atlas staff only.
 *
 * The proxy admits any valid session to `/api/admin/*`, and a `cliente` holds
 * one — so without this a client could post a `conversationId` belonging to
 * another account and send from our number into a stranger's thread. Being
 * signed in was never the question here; being one of us is.
 *
 * Clients get their own WhatsApp through their own account's instance, not
 * through this screen.
 */
async function staff() {
  const user = await currentUser();
  if (!user) return { user: null, denied: unauthorized() };
  if (user.role === "cliente") {
    return { user: null, denied: forbidden("Esta área é da equipe Atlas.") };
  }
  return { user, denied: null };
}

export async function GET(): Promise<Response> {
  const { denied } = await staff();
  if (denied) return denied;
  return Response.json({ jobs: activeJobs() });
}

/**
 * Cancelling a scheduled message, adding one by hand, and running the queue now.
 *
 * The hand-written path goes through `parseAgentReply` — the same validator the
 * model's output goes through, fed a synthesised envelope. That looks
 * roundabout and is deliberate: the rules about how often a recurrence may fire
 * and how far ahead anything may be scheduled protect the *number*, not the
 * model, and an operator with a text box can get a WhatsApp account banned
 * exactly as fast as a confused language model can. One validator, one set of
 * limits, no second implementation to drift.
 */
export async function POST(request: Request): Promise<Response> {
  // The proxy already turned away unsigned requests; this is the check that
  // knows the account was revoked since. Every route repeats it — a matcher
  // edit must not be able to silently open one.
  const { user, denied } = await staff();
  if (denied) return denied;

  let body: {
    intent?: string;
    jobId?: string;
    conversationId?: string;
    texto?: string;
    quando?: string;
    cron?: string;
    repeticoes?: number;
  };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const intent = String(body.intent ?? "");

  if (intent === "cancelar") {
    const id = String(body.jobId ?? "");
    if (!jobById(id)) {
      return Response.json(
        { error: "Agendamento não encontrado." },
        { status: 404 },
      );
    }
    // False means it was already closed — by the client asking to stop, or by
    // the scheduler finishing it between the page rendering and the click. Not
    // an error: the operator wanted it gone and it is gone.
    closeJob(id, "cancelado");
    return Response.json({ ok: true });
  }

  if (intent === "rodar") {
    // "Run the queue now", for an operator who has just fixed a disconnected
    // bridge and does not want to wait out the tick.
    return Response.json({ ok: true, ...(await dispatchDue()) });
  }

  if (intent !== "criar") {
    return Response.json({ error: "Intenção desconhecida." }, { status: 400 });
  }

  const conversation = conversationById(String(body.conversationId ?? ""));
  if (!conversation) {
    return Response.json(
      { error: "Conversa não encontrada." },
      { status: 404 },
    );
  }

  const recurring = Boolean(body.cron);
  const reply = parseAgentReply(
    JSON.stringify({
      mensagem: "",
      acoes: [
        recurring
          ? {
              tipo: "lembrete_recorrente",
              cron: body.cron,
              texto: body.texto,
              repeticoes: body.repeticoes,
            }
          : { tipo: "lembrete", quando: body.quando, texto: body.texto },
      ],
    }),
    { timezone: conversation.timezone ?? DEFAULT_TIMEZONE },
  );

  const action = reply.actions[0];
  if (!action) {
    return Response.json(
      { error: reply.rejected[0] ?? "Agendamento inválido." },
      { status: 400 },
    );
  }

  const job =
    action.type === "lembrete_recorrente"
      ? scheduleRecurring({
          conversationId: conversation.id,
          leadId: conversation.leadId,
          action,
          createdBy: user.id,
        })
      : action.type === "lembrete"
        ? scheduleReminder({
            conversationId: conversation.id,
            leadId: conversation.leadId,
            action,
            createdBy: user.id,
          })
        : null;

  if (!job) {
    return Response.json({ error: "Agendamento inválido." }, { status: 400 });
  }

  return Response.json({ job }, { status: 201 });
}
