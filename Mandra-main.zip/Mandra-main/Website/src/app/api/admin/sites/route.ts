import { currentUser, forbidden, unauthorized } from "@/lib/auth/server";
import { createSite, listSites } from "@/lib/crm/sites";
import { findAccount } from "@/lib/crm/accounts";

// node:sqlite, through the site registry.
export const runtime = "nodejs";

/**
 * The sites allowed to post leads into this CRM.
 *
 * Admin-only, and it re-checks the role in every handler rather than trusting
 * the matcher — same rule as `/api/admin/users`, same reason. Handing out an
 * intake key is handing out a write into the lead base, which is closer to
 * creating an account than to editing a lead.
 */

async function admin(): Promise<Response | null> {
  const user = await currentUser();
  if (!user) return unauthorized();
  if (user.role !== "admin") return forbidden();
  return null;
}

export async function GET(): Promise<Response> {
  const denied = await admin();
  if (denied) return denied;

  return Response.json({ sites: listSites() });
}

export async function POST(request: Request): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();
  if (user.role !== "admin") return forbidden();

  let body: {
    name?: string;
    origins?: unknown;
    country?: string;
    accountId?: string;
  };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  // The account is optional — a site of our own has none — but a named one has
  // to exist. This is the field that decides whose pipeline the form fills, so
  // a typo here would quietly send a client's enquiries into our base.
  const accountId = String(body.accountId ?? "").trim();
  if (accountId && !findAccount(accountId)) {
    return Response.json({ error: "Conta não encontrada." }, { status: 400 });
  }

  const result = createSite({
    name: String(body.name ?? ""),
    origins: body.origins,
    country: String(body.country ?? "BR"),
    createdBy: user.username,
    accountId: accountId || null,
  });

  if (!result.ok)
    return Response.json({ error: result.error }, { status: 400 });
  return Response.json({ site: result.site }, { status: 201 });
}
