import { currentUser, forbidden, unauthorized } from "@/lib/auth/server";
import { deleteSite, rotateKey, siteById, updateSite } from "@/lib/crm/sites";

export const runtime = "nodejs";

/**
 * Everything the admin does to one intake site: rename it, change which domains
 * may post, turn it off, rotate its key, remove it.
 *
 * Rotating and deactivating are different actions and both exist on purpose.
 * Deactivating stops submissions while leaving the snippet installed — the right
 * move for a customer who has paused, and reversible without touching their
 * site. Rotating invalidates the key that is embedded in their page, so their
 * form stops working until the tag is updated; it is for a key that has been
 * abused, and nothing else.
 */

async function admin(): Promise<Response | null> {
  const user = await currentUser();
  if (!user) return unauthorized();
  if (user.role !== "admin") return forbidden();
  return null;
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const denied = await admin();
  if (denied) return denied;

  const { id } = await params;
  if (!siteById(id)) {
    return Response.json({ error: "Site não encontrado." }, { status: 404 });
  }

  let body: {
    name?: string;
    origins?: unknown;
    country?: string;
    active?: boolean;
    rotate?: boolean;
  };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  if (body.rotate === true) {
    const rotated = rotateKey(id);
    if (!rotated) {
      return Response.json({ error: "Site não encontrado." }, { status: 404 });
    }
    return Response.json({ site: rotated });
  }

  const result = updateSite(id, {
    name: body.name,
    origins: body.origins,
    country: body.country,
    active: body.active,
  });

  if (!result.ok)
    return Response.json({ error: result.error }, { status: 400 });
  return Response.json({ site: result.site });
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const denied = await admin();
  if (denied) return denied;

  const { id } = await params;
  // The leads this site produced are deliberately left alone — see the note on
  // `deleteSite`. They are the customer's pipeline, not the form's output.
  if (!deleteSite(id)) {
    return Response.json({ error: "Site não encontrado." }, { status: 404 });
  }
  return Response.json({ ok: true });
}
