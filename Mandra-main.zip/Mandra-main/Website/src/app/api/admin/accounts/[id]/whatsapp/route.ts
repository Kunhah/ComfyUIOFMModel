import { currentUser, forbidden, unauthorized } from "@/lib/auth/server";
import {
  findAccount,
  setWhatsappBrief,
  setWhatsappInstance,
  setWhatsappNumber,
} from "@/lib/crm/accounts";
import {
  connectInstance,
  ensureInstance,
  instanceNameFor,
  instanceNumber,
  instanceState,
  removeInstance,
  setInstanceWebhook,
  whatsappConfigured,
} from "@/lib/whatsapp/evolution";

// node:sqlite through the account registry, and a network call to the bridge.
export const runtime = "nodejs";

/**
 * Connecting one client's WhatsApp number.
 *
 * This is the flow that used to be four `curl` commands in a comment in
 * docker-compose.yml, which is fine for our own number — paired once, years ago
 * — and unusable as something to do per customer. The four steps are now one
 * button: name the instance after the account, create it, point it at our
 * webhook, and show the QR code until the phone has read it.
 *
 * Admin-only. Pairing a number decides which WhatsApp account our bridge can
 * send as, which is closer to handing out a login than to editing a lead.
 */

async function admin(): Promise<Response | null> {
  const user = await currentUser();
  if (!user) return unauthorized();
  if (user.role !== "admin") return forbidden();
  return null;
}

/**
 * The webhook URL Evolution should call, built from this request.
 *
 * Taken from the request rather than from an environment variable for the same
 * reason the install snippet is: it has to be right on the VPS, behind a domain
 * and in dev, with nothing to remember when the host changes. A stale webhook
 * URL is the invisible failure here — the number pairs, the screen says
 * connected, and not one message ever arrives.
 */
function webhookUrl(request: Request): string {
  const headers = request.headers;
  const host =
    headers.get("x-forwarded-host") ?? headers.get("host") ?? "localhost:3000";
  const proto =
    headers.get("x-forwarded-proto")?.split(",")[0]?.trim() ??
    (host.startsWith("localhost") ? "http" : "https");
  return `${proto}://${host}/api/v1/whatsapp/webhook`;
}

/** The current picture, for the screen to poll while the QR is on display. */
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const denied = await admin();
  if (denied) return denied;

  const { id } = await params;
  const account = findAccount(id);
  if (!account) {
    return Response.json({ error: "Conta não encontrada." }, { status: 404 });
  }

  if (!account.waInstance) {
    return Response.json({
      configured: whatsappConfigured(),
      instance: null,
      state: "close",
      number: null,
      brief: account.waBrief,
    });
  }

  const state = await instanceState(account.waInstance);

  // The number is only knowable once the phone has actually paired, and it is
  // recorded then rather than asked for every time: the screen is polled every
  // few seconds while a QR is up, and this is a second network call per poll.
  if (state === "open" && !account.waNumber) {
    const number = await instanceNumber(account.waInstance);
    if (number) setWhatsappNumber(id, number);
  }

  return Response.json({
    configured: whatsappConfigured(),
    instance: account.waInstance,
    state,
    number: findAccount(id)?.waNumber ?? null,
    brief: account.waBrief,
  });
}

/**
 * Start (or resume) pairing.
 *
 * Safe to call repeatedly: the instance is created only if missing, the webhook
 * is replaced rather than appended, and an already-paired number simply comes
 * back as connected with no QR. That matters because this is a button on a
 * screen someone will press again when the code expires.
 */
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const denied = await admin();
  if (denied) return denied;

  const { id } = await params;
  const account = findAccount(id);
  if (!account) {
    return Response.json({ error: "Conta não encontrada." }, { status: 404 });
  }
  if (!whatsappConfigured()) {
    return Response.json(
      { error: "A ponte de WhatsApp não está configurada neste servidor." },
      { status: 503 },
    );
  }

  // Named after the account rather than randomly, so re-running this cannot
  // strand a second instance holding a paired session — see `instanceNameFor`.
  const instance = account.waInstance ?? instanceNameFor(account.slug);

  // The row is bound *before* the bridge is touched. An instance that exists in
  // Evolution and belongs to no account is one whose inbound messages are
  // dropped as unroutable, which is a state nothing on any screen would explain.
  const bound = setWhatsappInstance(id, instance);
  if (!bound.ok) return Response.json({ error: bound.error }, { status: 400 });

  try {
    await ensureInstance(instance);
    await setInstanceWebhook(instance, webhookUrl(request));
    const pairing = await connectInstance(instance);

    if (pairing.state === "open") {
      const number = await instanceNumber(instance);
      if (number) setWhatsappNumber(id, number);
    }

    return Response.json({
      instance,
      state: pairing.state,
      qr: pairing.qr,
      pairingCode: pairing.pairingCode,
      number: findAccount(id)?.waNumber ?? null,
    });
  } catch (error) {
    // The binding is left in place deliberately. The instance may well have been
    // created before the failing step, and unbinding here would hide it from the
    // one screen that can finish or remove it.
    const message = error instanceof Error ? error.message : String(error);
    console.error(
      JSON.stringify({
        service: "whatsapp",
        event: "pairing.failed",
        account: id,
        instance,
        message,
      }),
    );
    return Response.json({ error: message }, { status: 502 });
  }
}

/**
 * Sets what the agent says it is on this number.
 *
 * Separate from pairing because they fail independently and are done by
 * different people at different times: we pair the number in a meeting, and the
 * client tells us what their business does afterwards. Until this is set the
 * agent does not answer their threads at all — see `runTurn`.
 */
export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const denied = await admin();
  if (denied) return denied;

  const { id } = await params;
  if (!findAccount(id)) {
    return Response.json({ error: "Conta não encontrada." }, { status: 404 });
  }

  let body: { brief?: unknown };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const brief = typeof body.brief === "string" ? body.brief : null;
  setWhatsappBrief(id, brief);
  return Response.json({ brief: findAccount(id)?.waBrief ?? null });
}

/**
 * Disconnects the number.
 *
 * The conversations stay. They are a record of what was said to real people and
 * they outlive the connection, exactly as a suspended account's leads outlive
 * the arrangement — the client can be reconnected later and read their own
 * history.
 */
export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const denied = await admin();
  if (denied) return denied;

  const { id } = await params;
  const account = findAccount(id);
  if (!account) {
    return Response.json({ error: "Conta não encontrada." }, { status: 404 });
  }

  if (account.waInstance) await removeInstance(account.waInstance);
  // Unbound even if the bridge call failed: the row is what routes inbound
  // messages, and leaving it pointing at an instance we tried to delete is how
  // a client's number keeps answering after we said it stopped.
  setWhatsappInstance(id, null);

  return Response.json({ ok: true });
}
