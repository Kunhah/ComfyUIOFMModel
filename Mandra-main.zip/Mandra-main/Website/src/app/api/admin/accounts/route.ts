import { currentUser, forbidden, unauthorized } from "@/lib/auth/server";
import {
  accountSummaries,
  createAccount,
  findAccount,
  renameAccount,
  setAccountActive,
  setAccountNotes,
} from "@/lib/crm/accounts";

// node:sqlite, through the account registry.
export const runtime = "nodejs";

/**
 * The client accounts — the tenants.
 *
 * Admin-only, re-checked in every handler rather than trusted to the matcher,
 * the same rule `/api/admin/users` and `/api/admin/sites` follow. Creating an
 * account is closer to signing a customer than to editing a row: everything
 * downstream — a login, an intake site, a pipeline — hangs off the id this
 * returns.
 *
 * There is no DELETE. An account is suspended, never removed; see
 * setAccountActive() for why, and note that suspending is the one lever that
 * actually ends a client's access, since requireClient() re-reads the account
 * on every request.
 */

async function admin(): Promise<Response | null> {
  const user = await currentUser();
  if (!user) return unauthorized();
  if (user.role !== "admin") return forbidden();
  return null;
}

export async function GET(): Promise<Response> {
  const denied = await admin();
  if (denied) return denied;

  return Response.json({ accounts: accountSummaries() });
}

export async function POST(request: Request): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();
  if (user.role !== "admin") return forbidden();

  let body: { name?: string; country?: string; notes?: string };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const result = createAccount({
    name: String(body.name ?? ""),
    country: String(body.country ?? "BR"),
    notes: body.notes === undefined ? null : String(body.notes),
    createdBy: user.username,
  });

  if (!result.ok)
    return Response.json({ error: result.error }, { status: 400 });
  return Response.json({ account: result.account }, { status: 201 });
}

/**
 * Renaming, notes and suspension.
 *
 * One handler rather than three routes because they are three fields on one
 * screen, and a partial update lets two open tabs undo each other — the same
 * reasoning behind setPermissions() replacing the whole grant.
 */
export async function PATCH(request: Request): Promise<Response> {
  const denied = await admin();
  if (denied) return denied;

  let body: {
    id?: string;
    name?: string;
    notes?: string | null;
    active?: unknown;
  };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const id = String(body.id ?? "");
  if (!findAccount(id)) {
    return Response.json({ error: "Conta não encontrada." }, { status: 404 });
  }

  if (body.name !== undefined) {
    const result = renameAccount(id, String(body.name));
    if (!result.ok) {
      return Response.json({ error: result.error }, { status: 400 });
    }
  }

  if (body.notes !== undefined) {
    setAccountNotes(id, body.notes === null ? null : String(body.notes));
  }

  if (typeof body.active === "boolean") {
    setAccountActive(id, body.active);
  }

  return Response.json({ account: findAccount(id) });
}
