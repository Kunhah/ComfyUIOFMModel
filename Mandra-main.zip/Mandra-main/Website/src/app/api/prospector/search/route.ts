import { indexedCountries } from "@/lib/prospector/cities";
import { hasExtract } from "@/lib/prospector/overture";
import { performSearch } from "@/lib/prospector/search";
import { historyCount } from "@/lib/prospector/db";
import type { SearchRequest } from "@/lib/prospector/types";
import { currentUser, unauthorized } from "@/lib/auth/server";

// DuckDB is a native module, so this can't run on the edge runtime.
export const runtime = "nodejs";
// A search against the local extract is well under a second, but the S3 fallback
// can take minutes on first use; don't let the platform kill it mid-scan.
export const maxDuration = 300;

export async function POST(request: Request): Promise<Response> {
  // The proxy already turned away unsigned requests; this is the check that
  // knows the account was revoked since. Every route repeats it — a matcher
  // edit must not be able to silently open one.
  const user = await currentUser();
  if (!user) return unauthorized();

  let body: SearchRequest;
  try {
    body = (await request.json()) as SearchRequest;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const outcome = await performSearch(body, user);
  if (!outcome.ok) {
    return Response.json({ error: outcome.error }, { status: outcome.status });
  }
  return Response.json(outcome.response);
}

/** Lets the UI show whether the fast path is available and how much history exists. */
export async function GET(): Promise<Response> {
  // The proxy already turned away unsigned requests; this is the check that
  // knows the account was revoked since. Every route repeats it — a matcher
  // edit must not be able to silently open one.
  if (!(await currentUser())) return unauthorized();

  return Response.json({
    // "is the fast path available", which a hosted extract also satisfies — not
    // "is there a file on this disk". A deploy reading PROSPECTOR_EXTRACT_URL has
    // no local file and is still seconds, not minutes.
    localExtract: hasExtract(),
    history: historyCount(),
    // What the extract can actually reach. A client that offers every country in
    // the registry offers searches that return nothing.
    countries: indexedCountries().map(({ country, cities, noSite }) => ({
      code: country.code,
      label: country.label,
      region: country.region,
      cities,
      noSite,
    })),
  });
}
