import { csvResponse } from "@/lib/prospector/csv";
import type { ScoredLead } from "@/lib/prospector/types";
import { currentUser, denyWithout, unauthorized } from "@/lib/auth/server";

export const runtime = "nodejs";

/**
 * CSV export of whatever is currently on screen.
 *
 * The client posts the rows back rather than the server re-running the search:
 * the export must match exactly what the user is looking at, including any
 * filtering they did in the browser.
 *
 * For exporting more than the visible page, use the history export
 * (`/api/prospector/history/export`), which reads from SQLite and isn't capped.
 *
 * The column definitions live in lib/csv.ts, shared with that route so the two
 * files can't drift apart.
 */
export async function POST(request: Request): Promise<Response> {
  // The proxy already turned away unsigned requests; this is the check that
  // knows the account was revoked since — and, now, whether it may export at
  // all. Every route repeats it; a matcher edit must not silently open one.
  const denied = await denyWithout("export");
  if (denied) return denied;

  let body: { leads?: ScoredLead[]; filename?: string };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  // denyWithout has already established there is a session; this reads it
  // again so the whatsapp_link column carries this person's own opener and
  // signs with their name. See `outreachContextFor`.
  const user = await currentUser();
  if (!user) return unauthorized();

  const leads = Array.isArray(body.leads) ? body.leads : [];
  return csvResponse(leads, body.filename ?? "leads", { viewer: user });
}
