import { setStatus } from "@/lib/prospector/history";
import { recordProspectorActivity } from "@/lib/prospector/db";
import { LEAD_STATUSES, type LeadStatus } from "@/lib/prospector/types";
import { currentUser, denyOutsideScope, unauthorized } from "@/lib/auth/server";

// node:sqlite is a Node builtin, so this can't run on the edge runtime.
export const runtime = "nodejs";

/** Move one lead along the pipeline. Called by the status dropdown. */
export async function POST(request: Request): Promise<Response> {
  // The proxy already turned away unsigned requests; this is the check that
  // knows the account was revoked since. Every route repeats it — a matcher
  // edit must not be able to silently open one.
  const user = await currentUser();
  if (!user) return unauthorized();

  let body: { id?: string; status?: string };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const id = String(body.id ?? "");

  // The id arrives from a browser. For us that is fine — an operator works the
  // whole base. For a client it is the boundary, so it is checked here rather
  // than trusted from whatever the page happened to render.
  const outside = await denyOutsideScope(user, id);
  if (outside) return outside;
  const status = String(body.status ?? "");
  if (!id) return Response.json({ error: "id ausente." }, { status: 400 });
  if (!LEAD_STATUSES.includes(status as LeadStatus)) {
    return Response.json(
      { error: `Situação inválida: ${status}` },
      { status: 400 },
    );
  }

  // False means no row matched — a stale page pointing at a deleted database,
  // which the client should hear about rather than see silently succeed.
  const ok = setStatus(id, status as LeadStatus);
  if (!ok) {
    return Response.json({ error: "Lead não encontrado." }, { status: 404 });
  }
  recordProspectorActivity({
    actor: user,
    action: "status",
    leadId: id,
    detail: `Situação alterada para ${status}`,
  });
  return Response.json({ ok: true });
}
