import {
  deleteLeads,
  deleteMatching,
  idsInScope,
  leadNames,
  parseFilters,
  type HistoryFilters,
} from "@/lib/prospector/history";
import { recordProspectorActivity } from "@/lib/prospector/db";
import {
  currentUser,
  forbidden,
  scopeFor,
  unauthorized,
} from "@/lib/auth/server";

// node:sqlite is a Node builtin, so this can't run on the edge runtime.
export const runtime = "nodejs";

/**
 * Removes leads from the local history — the one destructive operation the tool
 * has, and the counterpart to a database that otherwise only grows.
 *
 * Two shapes, deliberately different in what they demand:
 *
 *   { ids: [...] }                       one or more rows, any signed-in account
 *   { filters: {…}, confirm: true }      everything the filters match, admin only
 *
 * The bulk form is admin-only because it can empty the shared pipeline in one
 * request, and it refuses an *unfiltered* delete unless `everything` is set as
 * well: "apagar tudo" has to be asked for twice, since a filter form that fails
 * to serialise would otherwise arrive here as "delete the entire history".
 *
 * Nothing is tombstoned. A deleted business will be found again by the next
 * search that covers it, and will come back marked "novo" — which is true, since
 * the history no longer knows it. The audit row written here is what survives.
 */
export async function POST(request: Request): Promise<Response> {
  // The proxy already turned away unsigned requests; this is the check that
  // knows the account was revoked since. Every route repeats it — a matcher
  // edit must not be able to silently open one.
  const user = await currentUser();
  if (!user) return unauthorized();

  let body: {
    ids?: unknown;
    filters?: Record<string, string | string[] | undefined>;
    confirm?: unknown;
    everything?: unknown;
  };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  if (Array.isArray(body.ids)) {
    const ids = body.ids
      .map((id) => String(id ?? "").trim())
      .filter((id) => id.length > 0 && id.length <= 200);
    if (ids.length === 0) {
      return Response.json(
        { error: "Nenhum lead informado." },
        { status: 400 },
      );
    }
    // Nothing below this line touches an id the caller may not see. `ids` comes
    // from a browser and is trusted for its *shape* only — the scope is what
    // decides whether these rows are theirs to delete, and it is checked here
    // rather than inside deleteLeads() for the same reason denyWithout() sits
    // in the route: the control belongs where the request arrives.
    const allowed = idsInScope(ids, scopeFor(user));
    if (allowed.length === 0) {
      return Response.json(
        { error: "Nenhum lead informado." },
        { status: 400 },
      );
    }

    // Read the names *before* the rows go: the audit resolves a lead's labels
    // from the table, which no longer holds them once the delete has run.
    const named = leadNames(allowed);
    const removed = deleteLeads(allowed);
    // One audit line for the request, not one per row. Clearing a screenful of
    // 200 leads is a single act, and logging it 200 times buries every other
    // thing that happened that day.
    recordProspectorActivity({
      actor: user,
      action: "delete",
      detail: summarise(
        allowed.map((id) => named.get(id) ?? id),
        removed,
      ),
    });
    return Response.json({ ok: true, removed });
  }

  if (body.confirm !== true) {
    return Response.json({ error: "Confirmação ausente." }, { status: 400 });
  }
  // Emptying the shared pipeline is a different act from tidying a row.
  if (user.role !== "admin") {
    return forbidden("Apagar em massa é restrito ao administrador.");
  }

  const filters = parseFilters(body.filters ?? {}, scopeFor(user));
  if (!narrowed(filters) && body.everything !== true) {
    return Response.json(
      {
        error:
          "Sem filtros isso apagaria o histórico inteiro. Confirme com `everything`.",
      },
      { status: 400 },
    );
  }

  const removed = deleteMatching(filters);
  recordProspectorActivity({
    actor: user,
    action: "delete",
    detail: `${removed} leads removidos do histórico (${describeFilters(filters)})`,
  });
  return Response.json({ ok: true, removed });
}

/** An audit line that names a few of them and counts the rest. */
function summarise(names: string[], removed: number): string {
  if (names.length === 1) return `Removido do histórico: ${names[0]}`;
  const head = names.slice(0, 3).join(", ");
  const rest = names.length > 3 ? ` e mais ${names.length - 3}` : "";
  return `${removed} leads removidos do histórico: ${head}${rest}`;
}

/** Does anything actually narrow this delete, or is it the whole table? */
function narrowed(f: HistoryFilters): boolean {
  return Boolean(
    f.q ||
    f.niche ||
    f.country ||
    f.city ||
    f.uf ||
    f.status ||
    f.stage ||
    f.onlyWhatsapp ||
    f.onlyNoSite ||
    f.onlyDue ||
    f.minScore,
  );
}

function describeFilters(f: HistoryFilters): string {
  const parts = [
    f.q && `busca "${f.q}"`,
    f.niche && `nicho ${f.niche}`,
    f.country && `país ${f.country}`,
    f.city && `cidade ${f.city}`,
    f.uf && `estado ${f.uf}`,
    f.status && `situação ${f.status}`,
    f.stage && `etapa ${f.stage}`,
    f.onlyNoSite && "sem site",
    f.onlyWhatsapp && "com WhatsApp",
    f.onlyDue && "follow-up pendente",
    f.minScore && `score >= ${f.minScore}`,
  ].filter(Boolean);
  return parts.length > 0 ? parts.join(", ") : "sem filtros";
}
