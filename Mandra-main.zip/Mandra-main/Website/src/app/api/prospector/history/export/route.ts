import { csvResponse, safeFilename } from "@/lib/prospector/csv";
import { allMatching, parseFilters } from "@/lib/prospector/history";
import {
  currentUser,
  denyWithout,
  scopeFor,
  unauthorized,
} from "@/lib/auth/server";

// node:sqlite is a Node builtin, so this can't run on the edge runtime.
export const runtime = "nodejs";

/**
 * CSV of the whole filtered history — every matching row, not the page you happen
 * to be looking at. The board's export takes rows posted from the browser because
 * it has to match what's on screen; this one reads from SQLite, so it has no
 * reason to be capped.
 *
 * A GET with the page's own query string, so the download link is just the
 * current view with a different path.
 */
export async function GET(request: Request): Promise<Response> {
  // This one is the whole lead base in a single file, filters or no filters, so
  // it is the sharpest edge of the "export" permission rather than an
  // afterthought behind it.
  const denied = await denyWithout("export");
  if (denied) return denied;

  // denyWithout has already established there is a session; this reads it again
  // for the scope. A client exporting their own pipeline gets their own rows —
  // the permission decides *whether* leads may leave, the scope decides whose.
  const user = await currentUser();
  if (!user) return unauthorized();

  const params = Object.fromEntries(new URL(request.url).searchParams);
  const filters = parseFilters(params, scopeFor(user));
  const leads = allMatching(filters);

  const parts = [
    "historico",
    filters.niche,
    filters.city,
    filters.status,
    filters.onlyNoSite ? "sem-site" : null,
    filters.onlyWhatsapp ? "whatsapp" : null,
  ].filter(Boolean);

  // The viewer decides which opener the whatsapp_link column carries: the
  // file is a work queue somebody opens days later, and it should hand them
  // their own message rather than a colleague's.
  return csvResponse(leads, safeFilename(parts.join("-")), {
    includeHistory: true,
    viewer: user,
  });
}
