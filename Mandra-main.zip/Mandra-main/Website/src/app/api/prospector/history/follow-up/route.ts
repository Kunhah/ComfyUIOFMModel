import { setFollowUp } from "@/lib/prospector/history";
import { recordProspectorActivity } from "@/lib/prospector/db";
import { currentUser, denyOutsideScope, unauthorized } from "@/lib/auth/server";

export const runtime = "nodejs";

/** Sets a local follow-up date. Dates are intentionally date-only (YYYY-MM-DD). */
export async function POST(request: Request): Promise<Response> {
  // The proxy already turned away unsigned requests; this is the check that
  // knows the account was revoked since. Every route repeats it — a matcher
  // edit must not be able to silently open one.
  const user = await currentUser();
  if (!user) return unauthorized();

  let body: { id?: string; date?: string | null };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const id = String(body.id ?? "");

  // The id arrives from a browser. For us that is fine — an operator works the
  // whole base. For a client it is the boundary, so it is checked here rather
  // than trusted from whatever the page happened to render.
  const outside = await denyOutsideScope(user, id);
  if (outside) return outside;
  const date =
    body.date === null || body.date === "" ? null : String(body.date ?? "");
  if (!id) return Response.json({ error: "id ausente." }, { status: 400 });
  if (date && !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return Response.json({ error: "Data inválida." }, { status: 400 });
  }
  if (!setFollowUp(id, date)) {
    return Response.json({ error: "Lead não encontrado." }, { status: 404 });
  }
  recordProspectorActivity({
    actor: user,
    action: "follow_up",
    leadId: id,
    detail: date ? `Follow-up definido para ${date}` : "Follow-up removido",
  });
  return Response.json({ ok: true });
}
