import {
  currentUser,
  denyOutsideScope,
  forbidden,
  unauthorized,
} from "@/lib/auth/server";
import { recordProspectorActivity } from "@/lib/prospector/db";
import {
  setFunnelMembership,
  setFunnelStage,
  setLeadDetails,
} from "@/lib/prospector/history";
import { MAX_TAGS, sanitiseTags } from "@/lib/prospector/tags";
import {
  FUNNEL_STAGES,
  type FunnelStage,
  type SocialLink,
} from "@/lib/prospector/types";

export const runtime = "nodejs";

const MAX_SOCIALS = 12;
const MAX_URL = 500;
const MAX_CONTACT = 120;

/**
 * The hand-maintained half of a lead: funnel stage, who we talk to, and their
 * profiles.
 *
 * Every URL is re-parsed rather than trusted. These end up as `href`s on a page
 * an operator clicks through all day, and a textarea is a fine place to paste a
 * `javascript:` URL by accident or otherwise — so the scheme is checked here,
 * where it can't be skipped, rather than at render time.
 */

/** Recognisable networks get a name; anything else is just a link. */
const PLATFORMS: [RegExp, string][] = [
  [/(^|\.)instagram\.com$/, "instagram"],
  [/(^|\.)facebook\.com$/, "facebook"],
  [/(^|\.)linkedin\.com$/, "linkedin"],
  [/(^|\.)tiktok\.com$/, "tiktok"],
  [/(^|\.)youtube\.com$/, "youtube"],
  [/(^|\.)(x|twitter)\.com$/, "x"],
  [/(^|\.)t\.me$/, "telegram"],
  [/(^|\.)telegram\.me$/, "telegram"],
  [/(^|\.)threads\.net$/, "threads"],
  [/(^|\.)bsky\.app$/, "bluesky"],
  [/(^|\.)pinterest\.[a-z.]+$/, "pinterest"],
  [/(^|\.)snapchat\.com$/, "snapchat"],
  [/(^|\.)discord\.(gg|com)$/, "discord"],
  [/(^|\.)m\.me$/, "messenger"],
  [/(^|\.)wa\.me$/, "whatsapp"],
  [/(^|\.)api\.whatsapp\.com$/, "whatsapp"],
];

function normaliseSocial(raw: unknown): SocialLink | null {
  if (typeof raw !== "string") return null;
  const trimmed = raw.trim();
  if (trimmed.length === 0 || trimmed.length > MAX_URL) return null;

  // A bare "instagram.com/loja" is what people paste; assume https rather than
  // rejecting it, but everything after that has to survive the URL parser.
  const candidate = /^https?:\/\//i.test(trimmed)
    ? trimmed
    : `https://${trimmed}`;

  let url: URL;
  try {
    url = new URL(candidate);
  } catch {
    return null;
  }
  if (url.protocol !== "https:" && url.protocol !== "http:") return null;
  if (!url.hostname.includes(".")) return null;

  const host = url.hostname.toLowerCase().replace(/^www\./, "");
  const platform =
    PLATFORMS.find(([pattern]) => pattern.test(host))?.[1] ?? host;

  return { platform, url: url.toString() };
}

export async function POST(request: Request): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();

  let body: {
    id?: string;
    stage?: string;
    inFunnel?: boolean;
    contactName?: string | null;
    socials?: unknown[];
    tags?: unknown[];
  };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const id = String(body.id ?? "");

  // The id arrives from a browser. For us that is fine — an operator works the
  // whole base. For a client it is the boundary, so it is checked here rather
  // than trusted from whatever the page happened to render.
  const outside = await denyOutsideScope(user, id);
  if (outside) return outside;
  if (!id) return Response.json({ error: "id ausente." }, { status: 400 });

  let touched = false;

  if (body.stage !== undefined) {
    if (!FUNNEL_STAGES.includes(body.stage as FunnelStage)) {
      return Response.json(
        { error: `Etapa inválida: ${body.stage}` },
        { status: 400 },
      );
    }
    if (!setFunnelStage(id, body.stage as FunnelStage)) {
      return Response.json({ error: "Lead não encontrado." }, { status: 404 });
    }
    recordProspectorActivity({
      actor: user,
      action: "funnel",
      leadId: id,
      detail: `Etapa alterada para ${body.stage}`,
    });
    touched = true;
  }

  if (body.inFunnel !== undefined) {
    if (user.role !== "admin") return forbidden();
    if (typeof body.inFunnel !== "boolean") {
      return Response.json({ error: "inFunnel inválido." }, { status: 400 });
    }
    if (!setFunnelMembership(id, body.inFunnel)) {
      return Response.json({ error: "Lead não encontrado." }, { status: 404 });
    }
    recordProspectorActivity({
      actor: user,
      action: "funnel",
      leadId: id,
      detail: body.inFunnel ? "Adicionado ao funil" : "Removido do funil",
    });
    touched = true;
  }

  const details: {
    contactName?: string | null;
    socials?: SocialLink[];
    tags?: string[];
  } = {};

  if (body.contactName !== undefined) {
    const name = String(body.contactName ?? "").slice(0, MAX_CONTACT);
    details.contactName = name.trim().length > 0 ? name : null;
  }

  if (body.socials !== undefined) {
    if (!Array.isArray(body.socials)) {
      return Response.json(
        { error: "socials deve ser uma lista." },
        { status: 400 },
      );
    }
    const links = body.socials
      .slice(0, MAX_SOCIALS)
      .map((entry) =>
        normaliseSocial(
          typeof entry === "string"
            ? entry
            : (entry as { url?: unknown } | null)?.url,
        ),
      );
    if (links.some((link) => link === null)) {
      return Response.json(
        { error: "Um dos links não é um endereço válido." },
        { status: 400 },
      );
    }
    details.socials = links as SocialLink[];
  }

  if (body.tags !== undefined) {
    if (!Array.isArray(body.tags)) {
      return Response.json(
        { error: "tags deve ser uma lista." },
        { status: 400 },
      );
    }
    // Over the cap is refused rather than silently truncated: quietly dropping
    // the thirteenth label would look like the write succeeded.
    if (body.tags.length > MAX_TAGS) {
      return Response.json(
        { error: `Máximo de ${MAX_TAGS} etiquetas por lead.` },
        { status: 400 },
      );
    }
    details.tags = sanitiseTags(body.tags);
  }

  if (Object.keys(details).length > 0) {
    if (!setLeadDetails(id, details)) {
      return Response.json({ error: "Lead não encontrado." }, { status: 404 });
    }
    if (details.contactName !== undefined) {
      recordProspectorActivity({
        actor: user,
        action: "contact",
        leadId: id,
        detail: details.contactName
          ? `Contato definido: ${details.contactName}`
          : "Contato removido",
      });
    }
    if (details.socials !== undefined) {
      recordProspectorActivity({
        actor: user,
        action: "socials",
        leadId: id,
        detail: `${details.socials.length} perfil${details.socials.length === 1 ? "" : "is"} atualizado${details.socials.length === 1 ? "" : "s"}`,
      });
    }
    if (details.tags !== undefined) {
      recordProspectorActivity({
        actor: user,
        action: "tags",
        leadId: id,
        detail:
          details.tags.length > 0
            ? `Etiquetas: ${details.tags.join(", ")}`
            : "Etiquetas removidas",
      });
    }
    touched = true;
  }

  if (!touched) {
    return Response.json({ error: "Nada para atualizar." }, { status: 400 });
  }
  return Response.json({
    ok: true,
    socials: details.socials,
    tags: details.tags,
  });
}
