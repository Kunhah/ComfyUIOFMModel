import { recordOutreach } from "@/lib/prospector/history";
import { recordProspectorActivity } from "@/lib/prospector/db";
import { recordTemplateUse } from "@/lib/prospector/templates-store";
import { currentUser, denyOutsideScope, unauthorized } from "@/lib/auth/server";
import {
  blockFor,
  callActor,
  conflict,
  takeOwnership,
} from "@/lib/prospector/ownership";

export const runtime = "nodejs";

const CHANNEL_LABEL: Record<string, string> = {
  whatsapp: "WhatsApp",
  telegram: "Telegram",
  email: "e-mail",
  phone: "telefone",
  instagram: "Instagram",
  facebook: "Facebook",
  linkedin: "LinkedIn",
  tiktok: "TikTok",
  x: "X",
  threads: "Threads",
  bluesky: "Bluesky",
  pinterest: "Pinterest",
  snapchat: "Snapchat",
  discord: "Discord",
  messenger: "Messenger",
  social: "rede social",
};

/**
 * Records a contact attempt, regardless of the channel the operator used.
 *
 * The other half of the exclusivity rule, and the half that is easy to forget:
 * the calling queue is not the only way to reach a business. Opening a WhatsApp
 * thread with a lead another operator owns is the same duplicate approach as
 * dialling it, so it is refused here on the same terms — and a first contact
 * through any channel is what makes the lead theirs.
 */
export async function POST(request: Request): Promise<Response> {
  // The proxy already turned away unsigned requests; this is the check that
  // knows the account was revoked since. Every route repeats it — a matcher
  // edit must not be able to silently open one.
  const user = await currentUser();
  if (!user) return unauthorized();

  let body: { id?: string; channel?: unknown };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const id = String(body.id ?? "");

  // The id arrives from a browser. For us that is fine — an operator works the
  // whole base. For a client it is the boundary, so it is checked here rather
  // than trusted from whatever the page happened to render.
  const outside = await denyOutsideScope(user, id);
  if (outside) return outside;
  if (!id) return Response.json({ error: "id ausente." }, { status: 400 });
  const channel = String(body.channel ?? "whatsapp").toLowerCase();
  if (!CHANNEL_LABEL[channel]) {
    return Response.json(
      { error: "Canal de contato inválido." },
      { status: 400 },
    );
  }
  const actor = callActor(user);
  // Before the write, not after: `recordOutreach` stamps contacted_at and
  // schedules a follow-up, and a lead that belongs to somebody else must come
  // out of this request exactly as it went in.
  const blocked = blockFor(id, actor);
  if (blocked) return conflict(blocked);

  if (!recordOutreach(id)) {
    return Response.json({ error: "Lead não encontrado." }, { status: 404 });
  }
  const becameOwner = takeOwnership(id, actor);
  // Which opener this went out under, so the variants on /admin/mensagens have
  // numbers next to the notes. Stamped here rather than sent by the button:
  // four screens render a WhatsApp link, and one of them forgetting to pass a
  // template id would be a reading that silently never happens. It reads the
  // variant that is active now, which is the one the link was written from
  // unless somebody switched it in the seconds in between.
  recordTemplateUse({ leadId: id, actorId: user.id, channel });
  recordProspectorActivity({
    actor: user,
    action: "outreach",
    leadId: id,
    detail: [
      `Contato por ${CHANNEL_LABEL[channel]} iniciado`,
      becameOwner ? "lead atribuído a este operador" : null,
    ]
      .filter(Boolean)
      .join(" · "),
  });
  return Response.json({ ok: true, becameOwner });
}
