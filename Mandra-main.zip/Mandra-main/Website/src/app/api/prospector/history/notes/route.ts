import { setNotes } from "@/lib/prospector/history";
import { recordProspectorActivity } from "@/lib/prospector/db";
import { currentUser, denyOutsideScope, unauthorized } from "@/lib/auth/server";

// node:sqlite is a Node builtin, so this can't run on the edge runtime.
export const runtime = "nodejs";

/** Cap on a free-text field that is only ever typed by hand. */
const MAX_LENGTH = 4000;

/** Saves the CRM note for one lead. Called by the note editor in the lead table. */
export async function POST(request: Request): Promise<Response> {
  // The proxy already turned away unsigned requests; this is the check that
  // knows the account was revoked since. Every route repeats it — a matcher
  // edit must not be able to silently open one.
  const user = await currentUser();
  if (!user) return unauthorized();

  let body: { id?: string; notes?: string | null };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const id = String(body.id ?? "");

  // The id arrives from a browser. For us that is fine — an operator works the
  // whole base. For a client it is the boundary, so it is checked here rather
  // than trusted from whatever the page happened to render.
  const outside = await denyOutsideScope(user, id);
  if (outside) return outside;
  if (!id) return Response.json({ error: "id ausente." }, { status: 400 });

  const notes = body.notes === null ? null : String(body.notes ?? "");
  if (notes !== null && notes.length > MAX_LENGTH) {
    return Response.json(
      { error: `Anotação muito longa (máx. ${MAX_LENGTH} caracteres).` },
      { status: 400 },
    );
  }

  // False means no row matched — a stale page pointing at a deleted database,
  // which the client should hear about rather than see silently succeed.
  if (!setNotes(id, notes)) {
    return Response.json({ error: "Lead não encontrado." }, { status: 404 });
  }
  recordProspectorActivity({
    actor: user,
    action: "notes",
    leadId: id,
    detail: notes?.trim() ? "Anotação atualizada" : "Anotação removida",
  });
  return Response.json({ ok: true });
}
