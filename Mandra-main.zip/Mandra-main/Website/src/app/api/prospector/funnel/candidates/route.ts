import { currentUser, forbidden, unauthorized } from "@/lib/auth/server";
import { funnelCandidates } from "@/lib/prospector/funnel";

export const runtime = "nodejs";

export async function GET(request: Request): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();
  if (user.role !== "admin") return forbidden();

  const search = new URL(request.url).searchParams.get("q") ?? "";
  return Response.json({ leads: funnelCandidates(search) });
}
