import { searchCities } from "@/lib/prospector/cities";
import { currentUser, unauthorized } from "@/lib/auth/server";

// The city index is a ~480KB module. Keeping the lookup server-side means the
// browser never downloads it just to autocomplete a text field.
export const runtime = "nodejs";

export async function GET(request: Request): Promise<Response> {
  // The proxy already turned away unsigned requests; this is the check that
  // knows the account was revoked since. Every route repeats it — a matcher
  // edit must not be able to silently open one.
  if (!(await currentUser())) return unauthorized();

  const params = new URL(request.url).searchParams;
  const q = params.get("q") ?? "";
  // Pinned to one country, so "Santiago" offers the Chilean one when Chile is
  // what you are prospecting instead of three continents' worth of homonyms.
  // Unset means search every country the extract holds.
  const country = params.get("country")?.trim() || undefined;
  // Only what the picker renders. The bounding box is a query-planning detail
  // and would roughly double the response for nothing.
  const cities = searchCities(q, 12, country).map((c) => ({
    name: c.name,
    uf: c.uf,
    country: c.country,
    businesses: c.businesses,
    noSite: c.noSite,
  }));
  return Response.json({ cities });
}
