import { companyCount, contactableCount } from "@/lib/b2b/db";
import { normaliseCountries } from "@/lib/b2b/countries";
import {
  discoverCompanies,
  hasLocalExtract,
  hasUniversalExtract,
  parseSeedList,
} from "@/lib/b2b/overture";
import { findDiscoveryTarget } from "@/lib/b2b/sectors";
import type { DiscoverResponse } from "@/lib/b2b/types";
import { denyWithout } from "@/lib/auth/server";

// DuckDB is a native module; it can't run on the edge runtime.
export const runtime = "nodejs";
// Against the local extract this is sub-second. Without one it queries Overture
// over S3, which measured minutes — don't let the platform kill it mid-scan.
export const maxDuration = 300;

type Body = {
  sector?: string;
  countries?: string[];
  city?: string;
  limit?: number;
  minConfidence?: number;
  /** Pasted list mode: when present, discovery is this text and nothing else. */
  seeds?: string;
};

export async function POST(request: Request): Promise<Response> {
  // The proxy already turned away unsigned requests; this is the check that
  // knows the account was revoked since — and whether the account was granted
  // the B2B crawler at all. Every route repeats it; a matcher edit must not be
  // able to silently open one.
  const denied = await denyWithout("b2b");
  if (denied) return denied;

  let body: Body;
  try {
    body = (await request.json()) as Body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const started = Date.now();
  const warnings: string[] = [];

  // --- pasted list ----------------------------------------------------------
  if (body.seeds && body.seeds.trim().length > 0) {
    const { candidates, rejected } = parseSeedList(body.seeds);
    if (rejected.length > 0) {
      warnings.push(
        `${rejected.length} linha${rejected.length === 1 ? "" : "s"} ignorada${
          rejected.length === 1 ? "" : "s"
        } (sem domínio válido): ${rejected.slice(0, 3).join(" · ")}${
          rejected.length > 3 ? "…" : ""
        }`,
      );
    }
    if (candidates.length === 0) {
      return Response.json(
        { error: "Nenhum domínio válido na lista." },
        { status: 400 },
      );
    }
    const response: DiscoverResponse = {
      candidates,
      stats: {
        matched: candidates.length,
        withWebsite: candidates.length,
        uniqueDomains: candidates.length,
        returned: candidates.length,
        elapsedMs: Date.now() - started,
      },
      warnings,
    };
    return Response.json(response);
  }

  // --- Overture -------------------------------------------------------------
  const target = findDiscoveryTarget(String(body.sector ?? ""));
  if (!target) {
    return Response.json(
      { error: "Setor ou campanha desconhecida." },
      { status: 400 },
    );
  }

  const countries = normaliseCountries(body.countries ?? []);
  if (countries.length === 0) {
    return Response.json(
      { error: "Escolha ao menos um país." },
      { status: 400 },
    );
  }

  if (target.categories.length === 0 && !hasUniversalExtract()) {
    return Response.json(
      {
        error:
          "O Radar amplo exige o extrato universal local. Rode `npm run sync:b2b -- --universal` uma vez; ele preserva os filtros por país e evita uma varredura remota planetária.",
      },
      { status: 409 },
    );
  }

  if (!hasLocalExtract()) {
    warnings.push(
      "Consultando o Overture direto no S3 — pode levar vários minutos. " +
        "Rode `npm run sync:b2b` uma vez para baixar o extrato e deixar as buscas instantâneas.",
    );
  }
  if (countries.length > 8 && !hasLocalExtract()) {
    warnings.push(
      "Muitos países numa consulta remota: a caixa que envolve todos eles cobre " +
        "quase todo o continente e o scan fica bem mais lento.",
    );
  }

  const limit = clamp(body.limit ?? 200, 1, 2000);

  let result;
  try {
    result = await discoverCompanies({
      categories: target.categories,
      countries,
      city: body.city?.trim() || undefined,
      minConfidence: clamp(body.minConfidence ?? 0.5, 0, 1),
      limit,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return Response.json(
      { error: `Falha na consulta: ${message}` },
      { status: 502 },
    );
  }

  if (result.totals.withWebsite > result.candidates.length) {
    warnings.push(
      `${result.candidates.length.toLocaleString("pt-BR")} empresas únicas de ` +
        `${result.totals.withWebsite.toLocaleString("pt-BR")} registros com site ` +
        `(matrizes e filiais compartilham domínio).`,
    );
  }

  const response: DiscoverResponse = {
    candidates: result.candidates,
    stats: {
      matched: result.totals.matched,
      withWebsite: result.totals.withWebsite,
      uniqueDomains: result.candidates.length,
      returned: result.candidates.length,
      elapsedMs: result.elapsedMs,
    },
    warnings,
  };
  return Response.json(response);
}

/** Lets the page show whether the fast path exists and how much history there is. */
export async function GET(): Promise<Response> {
  // The proxy already turned away unsigned requests; this is the check that
  // knows the account was revoked since — and whether the account was granted
  // the B2B crawler at all. Every route repeats it; a matcher edit must not be
  // able to silently open one.
  const denied = await denyWithout("b2b");
  if (denied) return denied;

  return Response.json({
    localExtract: hasLocalExtract(),
    universalExtract: hasUniversalExtract(),
    companies: companyCount(),
    contactable: contactableCount(),
  });
}

function clamp(value: number, lo: number, hi: number): number {
  const n = Number(value);
  if (!Number.isFinite(n)) return lo;
  return Math.trunc(Math.min(hi, Math.max(lo, n)));
}
