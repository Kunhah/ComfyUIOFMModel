import { csvResponse } from "@/lib/b2b/csv";
import { queryStored } from "@/lib/b2b/db";
import type { OutreachStatus, Prospect } from "@/lib/b2b/types";
import { denyWithout } from "@/lib/auth/server";

export const runtime = "nodejs";

/**
 * CSV export, two scopes.
 *
 * `board` posts the rows back from the browser, so the file matches exactly what
 * is on screen including any filtering done there. `historico` reads SQLite
 * instead and is not capped by the run — it is how you get every company ever
 * crawled, across every session.
 *
 * The columns live in `lib/b2b/csv.ts` for both, so the two files cannot drift.
 */
export async function POST(request: Request): Promise<Response> {
  // Both scopes leave with company data, so this sits behind the same "export"
  // permission as the prospector's CSV rather than behind the B2B one.
  const denied = await denyWithout("export");
  if (denied) return denied;

  let body: {
    scope?: "board" | "historico";
    prospects?: Prospect[];
    filename?: string;
    sector?: string;
    country?: string;
    outreach?: OutreachStatus;
    minScore?: number;
  };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  if (body.scope === "historico") {
    const stored = queryStored({
      sector: body.sector,
      country: body.country,
      outreach: body.outreach,
      minScore: body.minScore,
      onlyWithEmail: true,
    });
    return csvResponse(stored, body.filename ?? "b2b-historico", {
      includeHistory: true,
    });
  }

  const prospects = Array.isArray(body.prospects) ? body.prospects : [];
  return csvResponse(prospects, body.filename ?? "b2b-leads");
}
