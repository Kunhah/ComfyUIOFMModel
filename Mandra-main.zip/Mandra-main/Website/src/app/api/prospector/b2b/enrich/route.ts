import { domainOf, normaliseWebsite } from "@/lib/b2b/crawl/url";
import { enrich } from "@/lib/b2b/enrich";
import { sectorForCategory } from "@/lib/b2b/sectors";
import type { Candidate, EnrichEvent } from "@/lib/b2b/types";
import { denyWithout } from "@/lib/auth/server";

// SQLite (node:sqlite) and outbound crawling — Node runtime, not edge.
export const runtime = "nodejs";
// A run of 200 sites at eight in flight is several minutes. The response streams
// from the first company, so the client sees progress long before this matters —
// but the platform must not cut the connection underneath it.
export const maxDuration = 900;

type Body = {
  candidates?: unknown;
  concurrency?: number;
  maxPages?: number;
  respectRobots?: boolean;
  skipKnown?: boolean;
};

/**
 * Crawl a batch of candidates, streaming one JSON object per line (NDJSON).
 *
 * Not JSON: a single document can only be parsed once it is complete, and the
 * whole point is that a company appears on the board the moment its crawl ends
 * rather than ten minutes later. NDJSON is the smallest thing that does that —
 * no SSE framing, no WebSocket, and `response.body` in the browser can be read
 * line by line with nothing but a TextDecoder.
 */
export async function POST(request: Request): Promise<Response> {
  // The proxy already turned away unsigned requests; this is the check that
  // knows the account was revoked since — and whether the account was granted
  // the B2B crawler at all. Every route repeats it; a matcher edit must not be
  // able to silently open one.
  const denied = await denyWithout("b2b");
  if (denied) return denied;

  let body: Body;
  try {
    body = (await request.json()) as Body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const candidates = sanitise(body.candidates);
  if (candidates.length === 0) {
    return Response.json(
      { error: "Nenhuma empresa válida para rastrear." },
      { status: 400 },
    );
  }

  const encoder = new TextEncoder();
  // The browser aborting (tab closed, "parar" pressed) has to reach the crawler,
  // or a cancelled run keeps fetching a few hundred sites nobody is waiting for.
  const signal = request.signal;

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const write = (event: EnrichEvent) => {
        controller.enqueue(encoder.encode(`${JSON.stringify(event)}\n`));
      };
      try {
        for await (const event of enrich(candidates, {
          concurrency: clamp(body.concurrency ?? 8, 1, 16),
          maxPages: clamp(body.maxPages ?? 8, 1, 20),
          respectRobots: body.respectRobots !== false,
          skipKnown: body.skipKnown !== false,
          signal,
        })) {
          write(event);
        }
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        // Reported in-band: the status line went out with the first byte, so an
        // HTTP error code is no longer available to say this.
        try {
          write({ type: "error", error: message });
        } catch {
          /* the client is already gone */
        }
      } finally {
        try {
          controller.close();
        } catch {
          /* already closed by the abort */
        }
      }
    },
  });

  return new Response(stream, {
    headers: {
      "content-type": "application/x-ndjson; charset=utf-8",
      "cache-control": "no-store, no-transform",
      // Nginx buffers proxied responses by default, which would hold every line
      // until the run finished and undo the entire point of streaming.
      "x-accel-buffering": "no",
    },
  });
}

/**
 * Rebuild each candidate from scratch.
 *
 * The client posts back what discovery gave it, but it is still a request body:
 * the website is re-normalised (which is what rejects `localhost`, private
 * addresses and non-HTTP schemes — see `normaliseWebsite`) and every other field
 * is either re-derived or coerced to a string. Nothing from the wire reaches the
 * crawler unvalidated.
 */
function sanitise(input: unknown): Candidate[] {
  if (!Array.isArray(input)) return [];
  const out: Candidate[] = [];
  const seen = new Set<string>();

  for (const raw of input.slice(0, 2000)) {
    if (!raw || typeof raw !== "object") continue;
    const value = raw as Record<string, unknown>;
    const website = normaliseWebsite(String(value.website ?? ""));
    if (!website) continue;
    const domain = domainOf(website);
    if (!domain || seen.has(domain)) continue;
    seen.add(domain);

    const category = str(value.category);
    out.push({
      id: str(value.id) ?? domain,
      name: str(value.name) ?? domain,
      website,
      domain,
      country: str(value.country)?.toUpperCase().slice(0, 2) ?? null,
      city: str(value.city),
      region: str(value.region),
      address: str(value.address),
      phone: str(value.phone),
      category,
      // Re-derived rather than trusted, so a stale slug in the payload can't
      // write a sector that no longer exists into the history.
      sector: sectorForCategory(category),
      source: value.source === "lista" ? "lista" : "overture",
    });
  }
  return out;
}

function str(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed.slice(0, 300) : null;
}

function clamp(value: number, lo: number, hi: number): number {
  const n = Number(value);
  if (!Number.isFinite(n)) return lo;
  return Math.trunc(Math.min(hi, Math.max(lo, n)));
}
