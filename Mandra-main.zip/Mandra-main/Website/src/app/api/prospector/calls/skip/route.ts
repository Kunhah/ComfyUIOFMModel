import { currentUser, unauthorized } from "@/lib/auth/server";
import { skipItem } from "@/lib/prospector/calls";

// node:sqlite is a Node builtin, so this can't run on the edge runtime.
export const runtime = "nodejs";

/**
 * Steps past a lead without recording a call against it.
 *
 * Deliberately not an outcome: nothing was dialled, so nothing should reach the
 * call log, the lead's stage or its follow-up date. A "skip" stored as
 * "não atendeu" would inflate every attempt statistic the log exists to answer,
 * and would mark as contacted a business nobody has phoned.
 *
 * No audit event either, for the same reason — the audit records what was done
 * to a lead, and this is the operator deciding not to do anything yet. The queue
 * position remembers it, and `resetSkipped` puts them all back.
 */
export async function POST(request: Request): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();

  let body: { id?: unknown; listId?: unknown };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const id = typeof body.id === "string" ? body.id : "";
  const listId = Number(body.listId);
  if (!id || !Number.isInteger(listId) || listId <= 0) {
    return Response.json({ error: "Lead ou lista ausente." }, { status: 400 });
  }

  // The operator's id releases their reservation on the way past: they have just
  // said they are not calling this one, and nobody else should have to wait out
  // the claim's twenty minutes to find that out.
  if (!skipItem(listId, id, user.id)) {
    // Already done or already skipped — the queue has moved on either way, so
    // the client's next fetch is the answer rather than an error state.
    return Response.json({ ok: false, reason: "posicao-ja-fechada" });
  }
  return Response.json({ ok: true });
}
