import { currentUser, scopeFor, unauthorized } from "@/lib/auth/server";
import {
  MAX_LIST_SIZE,
  createCallList,
  deleteCallList,
  normaliseListName,
  resetSkipped,
} from "@/lib/prospector/calls";
import { recordProspectorActivity } from "@/lib/prospector/db";
import { callActor } from "@/lib/prospector/ownership";
import {
  allMatching,
  filtersToQuery,
  idsInScope,
  parseFilters,
} from "@/lib/prospector/history";
import { runSkill } from "@/lib/ai/run";
import { insightFila } from "@/lib/ai/skills/insight-fila";

// node:sqlite is a Node builtin, so this can't run on the edge runtime.
export const runtime = "nodejs";

/**
 * Building and unbuilding call lists.
 *
 * A list can be built two ways, and the difference matters: from an explicit set
 * of ids (the rows the operator ticked in the CRM) or from the history filters
 * currently on screen. The second reads the ids server-side through the same
 * `parseFilters` every other view uses — posting the whole filtered set from the
 * browser would cap the list at whatever page size happened to be loaded, which
 * is exactly the bug the CSV export was written to avoid.
 */
export async function POST(request: Request): Promise<Response> {
  // The proxy already turned away unsigned requests; this is the check that
  // knows the account was revoked since. Every route repeats it — a matcher
  // edit must not be able to silently open one.
  const user = await currentUser();
  if (!user) return unauthorized();

  let body: {
    name?: unknown;
    ids?: unknown;
    /** The history view to build from, as a query string, when no ids are given. */
    filters?: unknown;
    /** Ask `insight.fila` to choose the order. Opt-in, and only here. */
    priorizar?: unknown;
  };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const name = normaliseListName(body.name);
  if (!name)
    return Response.json({ error: "Dê um nome à lista." }, { status: 400 });

  let ids: string[];
  let sourceQuery: string | null = null;

  if (Array.isArray(body.ids) && body.ids.length > 0) {
    // Same rule as the delete route: ids arrive from a browser, and the scope
    // decides which of them exist as far as this caller is concerned.
    ids = idsInScope(
      body.ids.filter((id): id is string => typeof id === "string"),
      scopeFor(user),
    );
  } else if (typeof body.filters === "string") {
    // The filters are re-parsed and re-run here rather than trusted as a set of
    // ids: the client sends the view, the server decides what is in it.
    const params = Object.fromEntries(
      new URLSearchParams(body.filters.replace(/^\?/, "")),
    );
    const filters = parseFilters(params, scopeFor(user));
    // Order comes from the filters' own sort, so the queue arrives in the order
    // the operator was looking at when they built it.
    ids = allMatching(filters).map((lead) => lead.id);
    sourceQuery = filtersToQuery(filters);
  } else {
    return Response.json(
      { error: "Selecione leads ou informe um filtro." },
      { status: 400 },
    );
  }

  const requested = new Set(ids).size;

  // Ranking happens at creation and nowhere else.
  //
  // `createCallList` writes positions in the order it is handed, so choosing the
  // order here is the one place a model's opinion can shape a queue without
  // touching one. Re-ranking a live list would move work an operator is partway
  // through — they would come back from lunch to a different lead at position
  // twelve, having no way to know why. A new list has no such history.
  //
  // Opt-in, and it fails open: an outage, a ceiling, or a bad answer leaves the
  // list in the operator's own order rather than refusing to build it. A queue
  // in the wrong order is a worse day; no queue at all is no day.
  let ranked: string | null = null;
  if (body.priorizar === true && ids.length > 1) {
    try {
      const result = await runSkill(insightFila, ids, scopeFor(user));
      const order = result.output.ordem.map((entry) => entry.leadId);
      // The skill guarantees every id it was sent comes back; this is the belt
      // to that braces, because a list silently short by one lead is a business
      // nobody ever calls.
      const seen = new Set(order);
      ids = [...order, ...ids.filter((id) => !seen.has(id))];
      ranked = result.output.leitura || "Fila ordenada pela IA.";
    } catch {
      ranked = null;
    }
  }

  const list = createCallList({
    name,
    leadIds: ids,
    actor: callActor(user),
    sourceQuery,
  });
  if (!list) {
    return Response.json(
      { error: "Nenhum lead válido para esta lista." },
      { status: 400 },
    );
  }

  recordProspectorActivity({
    actor: user,
    action: "call_list",
    detail: `"${list.name}" · ${list.total} leads`,
  });

  return Response.json({
    list,
    /** What the ranking made of the batch, or null when it did not run. */
    leitura: ranked,
    // Said plainly rather than hidden. A list silently capped at 500 out of 900
    // is one an operator finishes believing they have called everyone, and a
    // list quietly missing its phoneless leads is one they think they can
    // reconcile against the CRM. `excluded` covers both, plus leads another
    // operator already owns or is dialling, plus anything deleted between the
    // filter running and the list being written, plus closed and lost leads —
    // the conversation is over and `createCallList` no longer builds one in.
    excluded: Math.max(0, requested - list.total),
    limit: MAX_LIST_SIZE,
  });
}

/** Removes a list. The calls recorded through it survive, unattached. */
export async function DELETE(request: Request): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();

  const id = Number(new URL(request.url).searchParams.get("id"));
  if (!Number.isInteger(id) || id <= 0) {
    return Response.json({ error: "id inválido." }, { status: 400 });
  }
  if (!deleteCallList(id)) {
    return Response.json({ error: "Lista não encontrada." }, { status: 404 });
  }
  recordProspectorActivity({
    actor: user,
    action: "call_list",
    detail: `Lista #${id} excluída`,
  });
  return Response.json({ ok: true });
}

/** Puts every skipped position in a list back into the queue. */
export async function PATCH(request: Request): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();

  let body: { id?: unknown; action?: unknown };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const id = Number(body.id);
  if (!Number.isInteger(id) || id <= 0) {
    return Response.json({ error: "id inválido." }, { status: 400 });
  }
  if (body.action !== "restaurar-pulados") {
    return Response.json({ error: "Ação desconhecida." }, { status: 400 });
  }

  const restored = resetSkipped(id);
  recordProspectorActivity({
    actor: user,
    action: "call_list",
    detail: `Lista #${id} · ${restored} pulados restaurados`,
  });
  return Response.json({ restored });
}
