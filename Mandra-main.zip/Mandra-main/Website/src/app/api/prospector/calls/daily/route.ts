import { currentUser, unauthorized } from "@/lib/auth/server";
import {
  DEFAULT_DAILY_TARGET,
  MAX_DAILY_TARGET,
  dailyList,
  topUpList,
} from "@/lib/prospector/calls";
import { recordProspectorActivity } from "@/lib/prospector/db";
import { callActor } from "@/lib/prospector/ownership";

// node:sqlite is a Node builtin, so this can't run on the edge runtime.
export const runtime = "nodejs";

/**
 * "Give me today's calls."
 *
 * The automatic path: no filter to choose, no rows to tick. The selection rules
 * live in `dailyCandidates` and are the interesting part — phone quality, due
 * follow-ups first, a cooldown on leads already dialled, nothing that is sitting
 * in someone else's queue, and nothing another operator owns or is on the phone
 * with right now.
 *
 * Idempotent per operator per day. The button will be pressed twice — a refresh,
 * a second tab, coming back after lunch — and a second hundred leads handed out
 * while the first eighty are still pending is how a day's work doubles silently.
 */
export async function POST(request: Request): Promise<Response> {
  // The proxy already turned away unsigned requests; this is the check that
  // knows the account was revoked since. Every route repeats it.
  const user = await currentUser();
  if (!user) return unauthorized();

  let body: { target?: unknown; topUp?: unknown };
  try {
    body = (await request.json().catch(() => ({}))) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const requested = Number(body.target);
  const target =
    Number.isFinite(requested) && requested > 0
      ? Math.min(Math.trunc(requested), MAX_DAILY_TARGET)
      : DEFAULT_DAILY_TARGET;

  // Topping up an existing list rather than building today's: keeps the progress
  // counters and the campaign in one place instead of scattering a week of work
  // across seven lists.
  const topUp = Number(body.topUp);
  if (Number.isInteger(topUp) && topUp > 0) {
    const { added } = topUpList(topUp, target, callActor(user));
    if (added > 0) {
      recordProspectorActivity({
        actor: user,
        action: "call_list",
        detail: `Lista #${topUp} · ${added} leads adicionados automaticamente`,
      });
    }
    return Response.json({ added, listId: topUp });
  }

  const result = dailyList({ actor: callActor(user), target });
  if (!result) {
    // Not an error: it is the honest answer that the base is worked out for now,
    // and the screen turns it into advice about prospecting more cities.
    return Response.json(
      {
        error:
          "Nenhum lead disponível para ligar agora. Busque mais leads no prospector, ou aguarde os follow-ups vencerem.",
      },
      { status: 409 },
    );
  }

  if (result.created) {
    recordProspectorActivity({
      actor: user,
      action: "call_list",
      detail: `"${result.list.name}" · ${result.list.total} leads (automática)`,
    });
  }

  return Response.json(result);
}
