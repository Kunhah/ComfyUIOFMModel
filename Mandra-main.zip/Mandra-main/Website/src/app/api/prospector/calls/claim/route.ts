import { currentUser, forbidden, unauthorized } from "@/lib/auth/server";
import { recordProspectorActivity } from "@/lib/prospector/db";
import {
  CLAIM_TTL_MINUTES,
  callActor,
  claimLead,
  conflict,
  releaseClaim,
  releaseOwnership,
  sweepClaims,
} from "@/lib/prospector/ownership";

// node:sqlite is a Node builtin, so this can't run on the edge runtime.
export const runtime = "nodejs";

/**
 * Reserving a lead, giving it back, and — for an admin — taking it off somebody.
 *
 * The dialer calls POST when it opens a lead and again on a timer while it stays
 * open, because the reservation expires on purpose (see ownership.ts: the
 * release that matters is the one a closed laptop never sends). A refused claim
 * is a 409 naming who holds it, which is what turns "the queue skipped a lead"
 * into something the operator can understand.
 *
 * DELETE is the polite release when the operator navigates away. It is never
 * relied on — every claim expires regardless — and it is scoped to the holder,
 * so it cannot be used to take a lead off someone mid-call.
 */
export async function POST(request: Request): Promise<Response> {
  // The proxy already turned away unsigned requests; this is the check that
  // knows the account was revoked since. Every route repeats it.
  const user = await currentUser();
  if (!user) return unauthorized();
  // A client's session must never reserve a lead: the queue is our tooling, and
  // a reservation is a lock on somebody else's pipeline.
  if (user.role === "cliente") return forbidden();

  let body: { id?: unknown; listId?: unknown };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const id = typeof body.id === "string" ? body.id : "";
  if (!id) return Response.json({ error: "id ausente." }, { status: 400 });

  const listId =
    typeof body.listId === "number" && Number.isInteger(body.listId)
      ? body.listId
      : null;

  // Opportunistic housekeeping on the one request that is already writing to the
  // table. Every predicate ignores expired rows, so this owes nothing to
  // correctness and does not deserve a timer of its own.
  sweepClaims();

  const result = claimLead({ leadId: id, actor: callActor(user), listId });
  if (!result.ok) return conflict(result.block);

  return Response.json({
    ok: true,
    expiresAt: result.expiresAt,
    // So the dialer can set its own renewal interval from the server's rule
    // rather than hardcoding a copy of it that can drift.
    ttlMinutes: CLAIM_TTL_MINUTES,
  });
}

/** Gives a reservation back. Only ever the caller's own. */
export async function DELETE(request: Request): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();

  const id = new URL(request.url).searchParams.get("id") ?? "";
  if (!id) return Response.json({ error: "id ausente." }, { status: 400 });

  return Response.json({ released: releaseClaim(id, user.id) });
}

/**
 * Hands a lead back to the team. Admin only, and audited.
 *
 * The escape hatch the permanent half of the rule needs: an operator leaves, a
 * territory changes hands, someone opened the wrong row. Without it the first
 * contact would be an irreversible decision made by one click. Audited because
 * it is the one action here that takes something away from another operator.
 */
export async function PATCH(request: Request): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();
  if (user.role !== "admin") return forbidden();

  let body: { id?: unknown };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const id = typeof body.id === "string" ? body.id : "";
  if (!id) return Response.json({ error: "id ausente." }, { status: 400 });

  const previous = releaseOwnership(id);
  recordProspectorActivity({
    actor: user,
    action: "atendimento",
    leadId: id,
    detail: previous
      ? `Atendimento liberado — era de ${previous.name}`
      : "Atendimento liberado",
  });

  return Response.json({ ok: true, previousOwner: previous?.name ?? null });
}
