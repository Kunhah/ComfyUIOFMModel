import { currentUser, unauthorized } from "@/lib/auth/server";
import {
  isCallOutcome,
  isNextStep,
  isRefusal,
  recordCall,
} from "@/lib/prospector/calls";
import { callActor, conflict } from "@/lib/prospector/ownership";
import { recordProspectorActivity } from "@/lib/prospector/db";
import {
  CALL_OUTCOME_LABEL,
  FUNNEL_LABEL,
  NEXT_STEP_LABEL,
} from "@/lib/prospector/types";

// node:sqlite is a Node builtin, so this can't run on the edge runtime.
export const runtime = "nodejs";

/**
 * Records one call and everything it decided.
 *
 * The whole qualification happens here: the outcome, the next step, the note,
 * and the follow-up date all arrive together because they are one decision the
 * operator makes while the call is still in their head. `recordCall` writes them
 * in a single transaction — see the note there on why they must not be four
 * separate requests.
 *
 * It is also the point where a lead stops being anybody's: the first recorded
 * call takes ownership of it, and a call against a lead somebody else already
 * owns or is dialling is refused with 409 rather than logged. See ownership.ts.
 */
export async function POST(request: Request): Promise<Response> {
  // The proxy already turned away unsigned requests; this is the check that
  // knows the account was revoked since. Every route repeats it — a matcher
  // edit must not be able to silently open one.
  const user = await currentUser();
  if (!user) return unauthorized();

  let body: {
    id?: unknown;
    listId?: unknown;
    outcome?: unknown;
    nextStep?: unknown;
    notes?: unknown;
    followUpAt?: unknown;
  };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const id = typeof body.id === "string" ? body.id : "";
  if (!id) return Response.json({ error: "id ausente." }, { status: 400 });

  if (!isCallOutcome(body.outcome)) {
    return Response.json(
      { error: "Resultado de ligação inválido." },
      { status: 400 },
    );
  }
  // An absent next step is "nenhum", which is a real answer; an unrecognised one
  // is a client bug and must not be stored as though it were a decision.
  if (body.nextStep !== undefined && !isNextStep(body.nextStep)) {
    return Response.json({ error: "Próximo passo inválido." }, { status: 400 });
  }

  // The three states of this field are all meaningful: absent means "use the
  // next step's default", null means "no follow-up at all", a date means that
  // date. Collapsing absent and null is how a scheduled callback disappears.
  let followUpAt: string | null | undefined;
  if (body.followUpAt === null || body.followUpAt === "") {
    followUpAt = null;
  } else if (typeof body.followUpAt === "string") {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(body.followUpAt)) {
      return Response.json({ error: "Data inválida." }, { status: 400 });
    }
    followUpAt = body.followUpAt;
  }

  const listId =
    typeof body.listId === "number" && Number.isInteger(body.listId)
      ? body.listId
      : null;

  const result = recordCall({
    leadId: id,
    listId,
    outcome: body.outcome,
    nextStep: isNextStep(body.nextStep) ? body.nextStep : undefined,
    notes: typeof body.notes === "string" ? body.notes : null,
    followUpAt,
    actor: callActor(user),
  });
  if (!result) {
    return Response.json({ error: "Lead não encontrado." }, { status: 404 });
  }
  // 409 rather than 403: nothing is wrong with the operator's access, the lead
  // is simply taken. The dialer turns this into a message naming who has it and
  // moves to the next position rather than dropping the note they just typed.
  if (isRefusal(result)) return conflict(result.blocked);

  const step = isNextStep(body.nextStep) ? body.nextStep : "nenhum";
  recordProspectorActivity({
    actor: user,
    action: "call",
    leadId: id,
    // The detail is what the audit screens print verbatim, so it carries the
    // whole decision rather than just the outcome — "ligou para X" alone makes
    // the audit useless for reconstructing why a lead moved.
    detail: [
      CALL_OUTCOME_LABEL[body.outcome],
      step === "nenhum" ? null : NEXT_STEP_LABEL[step],
      `etapa: ${FUNNEL_LABEL[result.stage]}`,
      result.followUpAt ? `retorno em ${result.followUpAt}` : null,
      // Recorded in the audit because it is the moment the lead stopped being
      // available to the rest of the team — the one thing in this detail line
      // that constrains somebody other than the operator who did it.
      result.becameOwner ? "lead atribuído a este operador" : null,
    ]
      .filter(Boolean)
      .join(" · "),
  });

  return Response.json(result);
}
