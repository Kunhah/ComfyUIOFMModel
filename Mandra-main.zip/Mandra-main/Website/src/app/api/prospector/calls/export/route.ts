import { denyWithout } from "@/lib/auth/server";
import {
  AUDIENCE_SEED_LABEL,
  isAudienceSeed,
  leadsForAudience,
} from "@/lib/prospector/calls";
import { buildAudience, isAudienceFormat } from "@/lib/prospector/audience";
import { safeFilename, textCsvResponse } from "@/lib/prospector/csv";

// node:sqlite is a Node builtin, so this can't run on the edge runtime.
export const runtime = "nodejs";

/**
 * The ads customer list, as a download.
 *
 * Behind the same `export` permission as the history CSV, and for the same
 * reason: hashed or not, this is identifying data leaving the building. The
 * hashing is what the ad platforms require of the upload, not a privacy control
 * — a SHA-256 of a phone number is trivially reversible by anyone holding a list
 * of phone numbers, which is precisely what an ad platform is.
 *
 * A GET so it can be a plain link, with the seed and format in the query string.
 */
export async function GET(request: Request): Promise<Response> {
  const denied = await denyWithout("export");
  if (denied) return denied;

  const params = new URL(request.url).searchParams;
  const seed = params.get("publico");
  const format = params.get("formato");

  if (!isAudienceSeed(seed)) {
    return Response.json({ error: "Público inválido." }, { status: 400 });
  }
  if (!isAudienceFormat(format)) {
    return Response.json({ error: "Formato inválido." }, { status: 400 });
  }

  const { headers, rows } = buildAudience(leadsForAudience(seed), format);

  // The count is in the filename rather than only in a header: these files are
  // downloaded, sat on for a week and then uploaded, and by then "which export
  // was this" is a question the filename is the only thing left to answer.
  const name = safeFilename(
    `publico-${seed}-${format}-${rows.length}-${new Date().toISOString().slice(0, 10)}`,
  );

  // No BOM on the hashed files: the platforms' uploaders read it as part of the
  // first header name. The plain CSV is for a person, and keeps it.
  const response = textCsvResponse(headers, rows, name, {
    bom: format === "plano",
  });
  // Reported out-of-band so the browser download stays a clean CSV. The screen
  // reads these back to say how many leads had nothing matchable on them.
  response.headers.set("x-audience-rows", String(rows.length));
  response.headers.set("x-audience-seed", AUDIENCE_SEED_LABEL[seed]);
  return response;
}
