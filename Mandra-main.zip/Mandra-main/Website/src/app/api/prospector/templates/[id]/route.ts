import { forbidden, staffOrDeny } from "@/lib/auth/server";
import { recordProspectorActivity } from "@/lib/prospector/db";
import {
  activateTemplate,
  deleteTemplate,
  findTemplate,
  invalidBody,
  updateTemplate,
  type OutreachTemplate,
} from "@/lib/prospector/templates-store";
import { INTENT_LABEL, LANGUAGE_LABEL } from "@/lib/prospector/templates";
import type { SessionUser } from "@/lib/auth/server";

export const runtime = "nodejs";

const MAX_NAME = 80;

/**
 * Rewriting one message, renaming it, or putting it in front of prospects.
 *
 * Activation is its own field rather than its own route because the common
 * gesture is both at once: somebody fixes a line and wants that fix to be what
 * the next lead reads. Two requests would leave a window where the edit is
 * saved and the old message is still the one going out.
 */
export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const staff = await staffOrDeny();
  if ("denied" in staff) return staff.denied;
  const { user } = staff;

  const id = Number((await params).id);
  if (!Number.isInteger(id)) {
    return Response.json({ error: "Mensagem inválida." }, { status: 400 });
  }

  let body: { name?: unknown; body?: unknown; activate?: unknown };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  // Scoped to this caller, so somebody else's private copy is not merely
  // refused — it does not exist, the same answer a lead outside your scope
  // gives. Which leaves exactly two kinds of row here: yours, and the team's.
  const before = findTemplate(id, user.id);
  if (!before) {
    return Response.json(
      { error: "Mensagem não encontrada." },
      { status: 404 },
    );
  }
  const denied = denyTeamEdit(before, user);
  if (denied) return denied;

  const fields: { name?: string; body?: string } = {};
  if (body.name !== undefined) {
    const name = String(body.name).trim().slice(0, MAX_NAME);
    if (name.length === 0) {
      return Response.json(
        { error: "Dê um nome à variante." },
        { status: 400 },
      );
    }
    fields.name = name;
  }
  if (body.body !== undefined) {
    const text = String(body.body);
    const wrong = invalidBody(text);
    if (wrong) return Response.json({ error: wrong }, { status: 400 });
    fields.body = text.trim();
  }

  const changed: string[] = [];
  if (Object.keys(fields).length > 0) {
    updateTemplate(id, fields);
    if (fields.body !== undefined) changed.push("texto reescrito");
    if (fields.name !== undefined) changed.push("renomeada");
  }
  if (body.activate === true && !before.active) {
    activateTemplate(id);
    changed.push("ativada");
  }

  // Only the team's copy is audited — see the note in the create route.
  if (changed.length > 0 && before.ownerId === null) {
    recordProspectorActivity({
      actor: user,
      action: "mensagem",
      detail: `Time · ${before.name} (${INTENT_LABEL[before.intent].toLowerCase()} · ${LANGUAGE_LABEL[before.speaks].toLowerCase()}): ${changed.join(", ")}`,
    });
  }

  return Response.json({ ok: true });
}

/**
 * Removing a variant, and with it every note written about it.
 *
 * Your own is yours to throw away. The team's is the admin's, for the same
 * reason they are the only one who may write it: everybody who has not
 * customised their message is sending it.
 */
export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const staff = await staffOrDeny();
  if ("denied" in staff) return staff.denied;
  const { user } = staff;

  const id = Number((await params).id);
  if (!Number.isInteger(id)) {
    return Response.json({ error: "Mensagem inválida." }, { status: 400 });
  }

  const before = findTemplate(id, user.id);
  if (!before) {
    return Response.json(
      { error: "Mensagem não encontrada." },
      { status: 404 },
    );
  }
  const denied = denyTeamEdit(before, user);
  if (denied) return denied;

  const outcome = deleteTemplate(id);
  if (outcome === "ausente") {
    return Response.json(
      { error: "Mensagem não encontrada." },
      { status: 404 },
    );
  }
  if (outcome === "ativa") {
    return Response.json(
      {
        error:
          "Esta é a mensagem que está sendo enviada. Ative outra antes de apagar esta.",
      },
      { status: 409 },
    );
  }

  if (before.ownerId === null) {
    recordProspectorActivity({
      actor: user,
      action: "mensagem",
      detail: `Time · variante apagada: ${before.name}`,
    });
  }
  return Response.json({ ok: true });
}

/** The one rule both verbs share: the team's copy belongs to the admin. */
function denyTeamEdit(
  template: OutreachTemplate,
  user: SessionUser,
): Response | null {
  if (template.ownerId !== null || user.role === "admin") return null;
  return forbidden(
    "Esta é a mensagem padrão do time. Crie a sua com “Escrever a minha” — ela vale só para os seus contatos.",
  );
}
