import { staffOrDeny } from "@/lib/auth/server";
import { releaseSlot } from "@/lib/prospector/templates-store";
import {
  TEMPLATE_LANGUAGES,
  type TemplateLanguage,
} from "@/lib/prospector/templates";
import type { NicheIntent } from "@/lib/prospector/niches";

export const runtime = "nodejs";

/**
 * "Voltar para a mensagem do time."
 *
 * A verb of its own rather than a delete, because the text is worth keeping:
 * somebody who reverts on a Tuesday usually wants their version back on
 * Thursday, and the notes underneath it are the record of why they wrote it in
 * the first place. Deactivating leaves all of that and simply stops resolving
 * — `activeTemplates()` then falls through to the team row, and then to the
 * opener that ships.
 *
 * It only ever touches the caller's own rows. There is no way to spell "put
 * somebody else back on the team message" here, which is the correct set of
 * things this endpoint can do.
 */
export async function POST(request: Request): Promise<Response> {
  const staff = await staffOrDeny();
  if ("denied" in staff) return staff.denied;
  const { user } = staff;

  let body: { intent?: unknown; speaks?: unknown };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const intent = String(body.intent ?? "");
  if (intent !== "cliente" && intent !== "parceiro") {
    return Response.json({ error: "Público inválido." }, { status: 400 });
  }
  const speaks = String(body.speaks ?? "");
  if (!(TEMPLATE_LANGUAGES as string[]).includes(speaks)) {
    return Response.json({ error: "Idioma inválido." }, { status: 400 });
  }

  const released = releaseSlot(
    user.id,
    intent as NicheIntent,
    speaks as TemplateLanguage,
  );
  // False means there was nothing of their own active — already on the team's
  // message. Not an error: it is the state the button asked for.
  return Response.json({ ok: true, released });
}
