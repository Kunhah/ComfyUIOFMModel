import { staffOrDeny } from "@/lib/auth/server";
import { recordProspectorActivity } from "@/lib/prospector/db";
import {
  addTemplateNote,
  deleteTemplateNote,
  findTemplate,
  noteAuthor,
} from "@/lib/prospector/templates-store";

export const runtime = "nodejs";

/** Long enough for what actually happened on a week of replies, short of an essay. */
const MAX_LENGTH = 2000;

/**
 * What this variant did.
 *
 * The counters on the screen say how many people it went out to and how many
 * answered; this is where the reason goes — "as três respostas foram de salão,
 * nenhuma de oficina", "encurtei e pararam de perguntar quem somos". A number
 * with no sentence next to it is what makes a team rewrite a message that was
 * working, and eleven sends is never enough to argue with.
 *
 * Append-only. An observation that turned out to be wrong is worth keeping next
 * to the one that corrected it.
 */
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const staff = await staffOrDeny();
  if ("denied" in staff) return staff.denied;
  const { user } = staff;

  const templateId = Number((await params).id);
  if (!Number.isInteger(templateId)) {
    return Response.json({ error: "Mensagem inválida." }, { status: 400 });
  }

  let body: { body?: unknown };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const text = String(body.body ?? "").trim();
  if (text.length === 0) {
    return Response.json({ error: "Escreva alguma coisa." }, { status: 400 });
  }
  if (text.length > MAX_LENGTH) {
    return Response.json(
      { error: `Anotação muito longa (máx. ${MAX_LENGTH} caracteres).` },
      { status: 400 },
    );
  }

  const note = addTemplateNote(templateId, text, {
    id: user.id,
    displayName: user.displayName,
  });
  if (!note) {
    return Response.json(
      { error: "Mensagem não encontrada." },
      { status: 404 },
    );
  }

  recordProspectorActivity({
    actor: user,
    action: "mensagem",
    detail: `Anotação sobre "${findTemplate(templateId, user.id)?.name ?? templateId}"`,
  });
  return Response.json({ ok: true, note });
}

/**
 * Removing one's own note, or anybody's if you are the admin.
 *
 * The author, because a note is a personal observation and the person who wrote
 * it is the one who knows it was nonsense. Not a colleague's, because a log
 * everyone can edit is a log nobody can rely on.
 */
export async function DELETE(request: Request): Promise<Response> {
  const staff = await staffOrDeny();
  if ("denied" in staff) return staff.denied;
  const { user } = staff;

  let body: { noteId?: unknown };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const noteId = Number(body.noteId);
  if (!Number.isInteger(noteId)) {
    return Response.json({ error: "Anotação inválida." }, { status: 400 });
  }

  const author = noteAuthor(noteId);
  if (author === null) {
    return Response.json(
      { error: "Anotação não encontrada." },
      { status: 404 },
    );
  }
  if (author !== user.id && user.role !== "admin") {
    return Response.json(
      { error: "Esta anotação é de outra pessoa." },
      { status: 403 },
    );
  }

  deleteTemplateNote(noteId);
  return Response.json({ ok: true });
}
