import { staffOrDeny } from "@/lib/auth/server";
import { recordProspectorActivity } from "@/lib/prospector/db";
import { createTemplate, invalidBody } from "@/lib/prospector/templates-store";
import {
  INTENT_LABEL,
  LANGUAGE_LABEL,
  TEMPLATE_LANGUAGES,
  type TemplateLanguage,
} from "@/lib/prospector/templates";
import type { NicheIntent } from "@/lib/prospector/niches";

// node:sqlite is a Node builtin, so this can't run on the edge runtime.
export const runtime = "nodejs";

const MAX_NAME = 80;

/**
 * Writing a message.
 *
 * Open to operators on exactly the same terms as the admin, and that is the
 * whole point rather than a concession: the row is stamped with the caller's
 * own id, so what an operator writes changes the links on their screens and
 * nobody else's. There is nothing here to gate, because there is nothing here
 * that reaches another person.
 *
 * The one exception is `escopo: "time"` — the team's copy, which is what
 * everybody who has not written their own sends. That one is the admin's.
 */
export async function POST(request: Request): Promise<Response> {
  const staff = await staffOrDeny();
  if ("denied" in staff) return staff.denied;
  const { user } = staff;

  let body: {
    intent?: unknown;
    speaks?: unknown;
    name?: unknown;
    body?: unknown;
    activate?: unknown;
    escopo?: unknown;
  };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const intent = String(body.intent ?? "");
  if (intent !== "cliente" && intent !== "parceiro") {
    return Response.json({ error: "Público inválido." }, { status: 400 });
  }
  const speaks = String(body.speaks ?? "");
  if (!(TEMPLATE_LANGUAGES as string[]).includes(speaks)) {
    return Response.json({ error: "Idioma inválido." }, { status: 400 });
  }

  // "minha" is the default, so a client that forgets the field writes the
  // caller's own copy rather than the one everybody reads.
  const team = body.escopo === "time";
  if (team && user.role !== "admin") {
    return Response.json(
      {
        error:
          "Só o administrador muda a mensagem padrão do time. A sua, você muda à vontade.",
      },
      { status: 403 },
    );
  }

  const name = String(body.name ?? "")
    .trim()
    .slice(0, MAX_NAME);
  const text = String(body.body ?? "");
  const wrong = invalidBody(text);
  if (wrong) return Response.json({ error: wrong }, { status: 400 });

  const activate = body.activate === true;

  const id = createTemplate(
    {
      ownerId: team ? null : user.id,
      intent: intent as NicheIntent,
      speaks: speaks as TemplateLanguage,
      // A variant with no name is the common case — somebody pasted a rewrite
      // and wants to try it. Naming it after the day it was written beats a
      // blank cell in a list whose whole job is telling variants apart.
      name: name || `Variante de ${today()}`,
      body: text.trim(),
      activate,
    },
    { id: user.id, displayName: user.displayName },
  );

  // Only the team's copy is worth an audit line. An operator's own message is
  // theirs, and a feed that reported every wording tweak of every operator
  // would bury the lead activity it exists to show.
  if (team) {
    recordProspectorActivity({
      actor: user,
      action: "mensagem",
      detail: [
        `Nova mensagem do time para ${INTENT_LABEL[intent as NicheIntent].toLowerCase()} em ${LANGUAGE_LABEL[speaks as TemplateLanguage].toLowerCase()}`,
        activate ? "ativada" : "salva sem ativar",
      ].join(" · "),
    });
  }

  return Response.json({ ok: true, id });
}

function today(): string {
  return new Date().toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
  });
}
