import { currentUser, scopeFor, unauthorized } from "@/lib/auth/server";
import { cachedOutput } from "@/lib/ai/db";
import { runSkill, SkillError } from "@/lib/ai/run";
import {
  insightObjecao,
  objecaoSubject,
  type ObjectionBrief,
} from "@/lib/ai/skills/insight-objecao";

export const runtime = "nodejs";

/**
 * The objections this niche tends to raise, from our own analysed meetings.
 *
 * Cached far harder than the per-lead insight, and by *segment* rather than by
 * lead or even by niche: a barbershop and a nail studio meet the same
 * objections, so they share one answer. Generating it per lead would pay the
 * expensive chain once per call for a result that only changes when a new
 * meeting is analysed — which is weekly at best.
 */

const nicheOf = (value: string | null): string | null => {
  const trimmed = value?.trim();
  return trimmed ? trimmed : null;
};

export async function GET(request: Request): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();

  const niche = nicheOf(new URL(request.url).searchParams.get("niche"));
  // The same key `context()` will use. Computing it here rather than
  // reproducing the format is the difference between a cache and a cache that
  // silently never hits.
  const cached = cachedOutput<ObjectionBrief>(
    "insight.objecao",
    objecaoSubject(niche),
  );
  return Response.json(
    cached
      ? {
          brief: cached.output,
          runId: cached.runId,
          geradoEm: cached.createdAt,
        }
      : { brief: null },
  );
}

export async function POST(request: Request): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();

  let body: { niche?: unknown };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const niche = nicheOf(typeof body.niche === "string" ? body.niche : null);

  try {
    const result = await runSkill(insightObjecao, { niche }, scopeFor(user));
    return Response.json({
      brief: result.output,
      runId: result.runId,
      geradoEm: new Date().toISOString(),
    });
  } catch (error) {
    if (error instanceof SkillError) {
      return Response.json(
        { error: error.message, estado: error.state },
        { status: error.state === "recusado" ? 429 : 502 },
      );
    }
    // The two ordinary "no" answers — a client session, and no analysed meetings
    // yet — arrive here as plain Errors from context(). Both are 400s with the
    // reason, not 500s: neither is a fault.
    return Response.json(
      {
        error:
          error instanceof Error ? error.message : "Falha ao ler as objeções.",
      },
      { status: 400 },
    );
  }
}
