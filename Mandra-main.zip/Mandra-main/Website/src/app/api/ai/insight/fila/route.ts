import { currentUser, scopeFor, unauthorized } from "@/lib/auth/server";
import { runSkill, SkillError } from "@/lib/ai/run";
import { insightFila } from "@/lib/ai/skills/insight-fila";

export const runtime = "nodejs";

/**
 * Ranks a set of leads by who is worth calling first today.
 *
 * POST only, and uncached: the ranking is about *today*, and a stored one would
 * be handed back after half the leads in it have been called.
 *
 * It also writes nothing, which is deliberate and worth stating.
 * `call_list_items` carries positions an operator has already worked through,
 * and rewriting them from a model's ranking would move work somebody is in the
 * middle of. Whether a ranking should ever reorder a persisted queue is a
 * product decision; this route must not settle it by quietly doing it.
 */
export async function POST(request: Request): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();

  let body: { leads?: unknown };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const leads = Array.isArray(body.leads)
    ? body.leads.filter((id): id is string => typeof id === "string" && !!id)
    : [];
  if (leads.length === 0) {
    return Response.json({ error: "Nenhum lead enviado." }, { status: 400 });
  }

  try {
    const result = await runSkill(insightFila, leads, scopeFor(user));
    return Response.json({
      ordem: result.output.ordem,
      leitura: result.output.leitura,
      runId: result.runId,
    });
  } catch (error) {
    if (error instanceof SkillError) {
      return Response.json(
        { error: error.message, estado: error.state },
        { status: error.state === "recusado" ? 429 : 502 },
      );
    }
    return Response.json(
      {
        error:
          error instanceof Error ? error.message : "Falha ao ordenar a fila.",
      },
      { status: 400 },
    );
  }
}
