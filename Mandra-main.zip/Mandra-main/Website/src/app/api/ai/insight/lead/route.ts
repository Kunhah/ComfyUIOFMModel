import { currentUser, scopeFor, unauthorized } from "@/lib/auth/server";
import { cachedOutput } from "@/lib/ai/db";
import { runSkill, SkillError } from "@/lib/ai/run";
import { insightLead, type Insight } from "@/lib/ai/skills/insight-lead";

// node:sqlite is a Node builtin, so this can't run on the edge runtime.
export const runtime = "nodejs";

/**
 * The insight for one lead, from cache or freshly generated.
 *
 * GET reads what we already have and never spends anything; POST generates. The
 * split is the whole cost design: a call page that generated on load would pay
 * for an insight every time an operator scrolled past a lead, and would show a
 * different one each time — which reads as unserious even when both are good.
 *
 * The scope comes from the session and is passed as the skill's second argument,
 * never read from the body. A `cliente` asking for one of our own prospects gets
 * "não encontrado", which is what `context()` throws for a row outside the
 * scope — 403 would confirm the lead exists.
 */

function leadIdOf(value: unknown): string {
  return typeof value === "string" && value.trim() ? value.trim() : "";
}

export async function GET(request: Request): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();

  const id = leadIdOf(new URL(request.url).searchParams.get("lead"));
  if (!id) return Response.json({ error: "Lead ausente." }, { status: 400 });

  // Reading the cache does not re-check the lead's scope, so it is checked here
  // by the subject: a cached insight is keyed by lead id, and handing one back
  // to a session that could not have generated it is the same leak by a slower
  // route.
  const scope = scopeFor(user);
  const cached = cachedOutput<Insight>("insight.lead", `lead:${id}`);
  if (!cached) return Response.json({ insight: null });

  const { leadInScope } = await import("@/lib/prospector/history");
  if (!leadInScope(id, scope)) {
    return Response.json({ error: "Lead não encontrado." }, { status: 404 });
  }

  return Response.json({
    insight: cached.output,
    runId: cached.runId,
    geradoEm: cached.createdAt,
  });
}

export async function POST(request: Request): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();

  let body: { lead?: unknown };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const id = leadIdOf(body.lead);
  if (!id) return Response.json({ error: "Lead ausente." }, { status: 400 });

  try {
    const result = await runSkill(insightLead, id, scopeFor(user));
    return Response.json({
      insight: result.output,
      runId: result.runId,
      geradoEm: new Date().toISOString(),
    });
  } catch (error) {
    if (error instanceof SkillError) {
      // The states are distinguished for the operator, not just for the log: a
      // ceiling reached is something an admin fixes, a bad answer is something
      // they retry, and an outage is something they wait out.
      const status = error.state === "recusado" ? 429 : 502;
      return Response.json(
        { error: error.message, estado: error.state },
        { status },
      );
    }
    return Response.json(
      {
        error:
          error instanceof Error ? error.message : "Falha ao gerar o insight.",
      },
      { status: 400 },
    );
  }
}
