import { currentUser, unauthorized } from "@/lib/auth/server";
import { markUseful } from "@/lib/ai/db";

export const runtime = "nodejs";

/**
 * An operator marking one run useful or not.
 *
 * The cheapest evaluation we have and the only one that comes from the person
 * whose call it changed. `docs/ai-infra.md` says the zeroes become next month's
 * eval fixtures; this is the button that produces them.
 *
 * No scope check on the run id, deliberately: a staff session can mark any run,
 * and the value written is an opinion, not data anyone reads back as fact.
 */
export async function POST(request: Request): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();

  let body: { runId?: unknown; useful?: unknown };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }

  const runId = Number(body.runId);
  if (!Number.isInteger(runId) || runId <= 0) {
    return Response.json({ error: "Run inválido." }, { status: 400 });
  }

  markUseful(runId, body.useful === true);
  return Response.json({ ok: true });
}
