import { createWriteStream } from "node:fs";
import { mkdir, rm, stat } from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { Readable } from "node:stream";
import { pipeline as streamPipeline } from "node:stream/promises";
import { currentUser, unauthorized } from "@/lib/auth/server";
import {
  createReview,
  isMeetingOutcome,
  listReviews,
  type MeetingOutcome,
} from "@/lib/review/db";
import { audioDir, enqueue } from "@/lib/review/pipeline";
import { readiness } from "@/lib/review/transcribe";

export const runtime = "nodejs";
// The upload is minutes of audio over a domestic connection; the default static
// treatment would also cache a list that changes on every upload.
export const dynamic = "force-dynamic";
export const maxDuration = 300;

/** What we will accept. Everything ffmpeg reads, restricted to what a meeting is. */
const EXTENSIONS: Record<string, string> = {
  "audio/mpeg": ".mp3",
  "audio/mp3": ".mp3",
  "audio/mp4": ".m4a",
  "audio/x-m4a": ".m4a",
  "audio/aac": ".aac",
  "audio/ogg": ".ogg",
  "audio/opus": ".opus",
  "audio/wav": ".wav",
  "audio/x-wav": ".wav",
  "audio/webm": ".webm",
  "video/mp4": ".mp4",
  "video/webm": ".webm",
  "video/quicktime": ".mov",
};

/**
 * Two hours of decent-quality audio, or a screen recording of a video call.
 *
 * A cap is not optional: the body streams straight to disk, so without one a
 * mistaken upload of something enormous fills the volume the lead database also
 * lives on, and SQLite's failure mode on a full disk is not a friendly one.
 */
const MAX_BYTES = 500 * 1024 * 1024;

export async function GET(): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();

  // Admins see every seller's recordings; everyone else sees their own. Passed
  // as the scope argument rather than applied as a filter afterwards, so there
  // is no version of this route that forgets it.
  const scope = user.role === "admin" ? null : user.id;

  return Response.json({
    reviews: listReviews(scope).map((r) => ({
      id: r.id,
      title: r.title,
      status: r.status,
      outcome: r.outcome,
      actorName: r.actorName,
      durationSeconds: r.durationSeconds,
      error: r.error,
      createdAt: r.createdAt,
      // The list only needs the headline number, and shipping every full review
      // to render a table is a megabyte of JSON per page load.
      notaGeral:
        r.analysis && typeof r.analysis === "object"
          ? ((r.analysis as { nota_geral?: number }).nota_geral ?? null)
          : null,
    })),
    readiness: await readiness(),
  });
}

/**
 * The upload.
 *
 * The file is the raw request body and the metadata is in the query string,
 * rather than a multipart form. `request.formData()` buffers the whole upload in
 * memory before a single byte reaches disk, which for a 300 MB recording is 300
 * MB of heap on a 2 GB VPS — and it fails at the end of a five-minute upload,
 * which is the worst possible moment to fail.
 */
export async function POST(request: Request): Promise<Response> {
  const user = await currentUser();
  if (!user) return unauthorized();

  const url = new URL(request.url);
  const title = (url.searchParams.get("title") ?? "").trim();
  const outcomeRaw = url.searchParams.get("outcome") ?? "em_aberto";
  const focus = (url.searchParams.get("focus") ?? "").trim();
  const leadId = (url.searchParams.get("leadId") ?? "").trim();

  if (!title) {
    return Response.json({ error: "Dê um nome à reunião." }, { status: 400 });
  }
  if (!isMeetingOutcome(outcomeRaw)) {
    return Response.json({ error: "Desfecho inválido." }, { status: 400 });
  }
  const outcome: MeetingOutcome = outcomeRaw;

  const type = (request.headers.get("content-type") ?? "").split(";")[0].trim();
  const extension = EXTENSIONS[type];
  if (!extension) {
    return Response.json(
      {
        error: `Formato não aceito (${type || "desconhecido"}). Envie mp3, m4a, wav, ogg, webm ou mp4.`,
      },
      { status: 415 },
    );
  }

  const declared = Number(request.headers.get("content-length") ?? 0);
  if (declared > MAX_BYTES) {
    return Response.json(
      { error: `Arquivo maior que ${Math.round(MAX_BYTES / 1024 / 1024)} MB.` },
      { status: 413 },
    );
  }
  if (!request.body) {
    return Response.json({ error: "Requisição sem arquivo." }, { status: 400 });
  }

  const dir = audioDir();
  await mkdir(dir, { recursive: true });
  // Named by a fresh uuid, never by the uploaded filename: that string comes
  // from a browser and would otherwise be a path traversal into the data volume.
  const file = path.join(dir, `${randomUUID()}${extension}`);

  try {
    let written = 0;
    const source = Readable.fromWeb(
      request.body as Parameters<typeof Readable.fromWeb>[0],
    );
    source.on("data", (chunk: Buffer) => {
      written += chunk.length;
      // content-length is a claim, not a guarantee. Enforced again here so a
      // client that lies cannot write past the cap.
      if (written > MAX_BYTES) source.destroy(new Error("MAX_BYTES"));
    });

    await streamPipeline(source, createWriteStream(file));
    const info = await stat(file);
    if (info.size === 0) throw new Error("EMPTY");

    const review = createReview({
      title,
      actorId: user.id,
      actorName: user.displayName,
      outcome,
      focus: focus || null,
      leadId: leadId || null,
      audioPath: file,
      audioBytes: info.size,
    });

    // Deliberately not awaited: transcription is minutes long and the uploader
    // is watching a progress bar that should end when the upload does.
    enqueue(review);

    return Response.json({ id: review.id }, { status: 201 });
  } catch (error) {
    await rm(file, { force: true }).catch(() => {});
    const message = error instanceof Error ? error.message : String(error);
    if (message === "MAX_BYTES") {
      return Response.json(
        {
          error: `Arquivo maior que ${Math.round(MAX_BYTES / 1024 / 1024)} MB.`,
        },
        { status: 413 },
      );
    }
    if (message === "EMPTY") {
      return Response.json(
        { error: "O arquivo chegou vazio." },
        { status: 400 },
      );
    }
    return Response.json(
      { error: `Falha ao receber o arquivo: ${message}` },
      { status: 500 },
    );
  }
}
