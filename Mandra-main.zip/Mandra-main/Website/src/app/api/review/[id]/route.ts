import { rm } from "node:fs/promises";
import { currentUser, unauthorized } from "@/lib/auth/server";
import type { SessionUser } from "@/lib/auth/server";
import type { ReviewRow } from "@/lib/review/db";
import { deleteReview, reviewById, updateReview } from "@/lib/review/db";
import { enqueue, isRunning } from "@/lib/review/pipeline";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * One review: read it, retry it, delete it.
 *
 * The ownership check is repeated in all three rather than factored into a
 * middleware, because it is the whole security boundary of the feature — a
 * recording is a customer conversation, and the operator who did not make it has
 * no business reading it back. Admins are exempt; that is what the role is for.
 */
const missing = (): Response =>
  Response.json({ error: "Não encontrado." }, { status: 404 });

/**
 * Returns the `Response` to send, or the row to act on. A union of those two
 * rather than a `{ error? }` object because `instanceof Response` narrows where
 * a `in` check on optional fields does not.
 */
async function load(
  id: string,
): Promise<Response | { user: SessionUser; review: ReviewRow }> {
  const user = await currentUser();
  if (!user) return unauthorized();

  const review = reviewById(id);
  // 404 rather than 403 for a foreign row, like the account scoping does: a 403
  // confirms the recording exists, which is itself something to leak.
  if (!review) return missing();
  if (user.role !== "admin" && review.actorId !== user.id) return missing();

  return { user, review };
}

export async function GET(
  _request: Request,
  context: { params: Promise<{ id: string }> },
): Promise<Response> {
  const { id } = await context.params;
  const result = await load(id);
  if (result instanceof Response) return result;

  const { review } = result;
  return Response.json({
    review: {
      id: review.id,
      title: review.title,
      status: review.status,
      outcome: review.outcome,
      focus: review.focus,
      actorName: review.actorName,
      durationSeconds: review.durationSeconds,
      transcript: review.transcript,
      segments: review.segments,
      analysis: review.analysis,
      analysisModel: review.analysisModel,
      error: review.error,
      createdAt: review.createdAt,
      updatedAt: review.updatedAt,
      // Distinguishes "still working" from "the process died holding this row",
      // which look identical from the status column alone.
      working: isRunning(review.id),
    },
  });
}

/** Re-run the pipeline. Cheap when the transcript survives; the analysis is redone. */
export async function POST(
  _request: Request,
  context: { params: Promise<{ id: string }> },
): Promise<Response> {
  const { id } = await context.params;
  const result = await load(id);
  if (result instanceof Response) return result;

  const { review } = result;
  if (isRunning(review.id)) {
    return Response.json({ error: "Já está em andamento." }, { status: 409 });
  }
  if (review.segments.length === 0 && !review.audioPath) {
    return Response.json(
      { error: "Sem áudio e sem transcrição — não há o que reanalisar." },
      { status: 409 },
    );
  }

  updateReview(review.id, { status: "fila", error: null });
  enqueue(review);
  return Response.json({ ok: true });
}

export async function DELETE(
  _request: Request,
  context: { params: Promise<{ id: string }> },
): Promise<Response> {
  const { id } = await context.params;
  const result = await load(id);
  if (result instanceof Response) return result;

  const { review } = result;
  if (isRunning(review.id)) {
    return Response.json(
      { error: "Está sendo processada. Espere terminar para apagar." },
      { status: 409 },
    );
  }

  const removed = deleteReview(review.id);
  // After the row, not before: a deleted file with a surviving row is a review
  // that can never be retried and never explains why.
  if (removed?.audioPath)
    await rm(removed.audioPath, { force: true }).catch(() => {});
  return Response.json({ ok: true });
}
