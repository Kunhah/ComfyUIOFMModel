import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { adPages, adPageBySlug, type AdPage } from "@/content/ads";
import { site } from "@/content/site";
import { Container } from "@/components/ui/container";
import { Bolts, Lamp, Legend, PlateCode } from "@/components/rede/plate";
import { CallAction, CallBar, WhatsappAction } from "@/components/ads/actions";
import { PageTracker } from "@/components/analytics/tracker";

/**
 * The Google Ads landing page.
 *
 * One template, six pages, and the content is entirely in `content/ads.ts` —
 * a seventh ad group is a data entry here, not a new route. See that file for
 * why the copy is written per trade rather than templated.
 *
 * The page is built around one measurement: the number of taps between
 * arriving and a ringing phone. It is one, from any scroll position, on any
 * device — the header action, the hero action, the mid-page action, the
 * closing band and the sticky bar are all the same `tel:` href. There is no
 * form, no modal and no navigation, because a click bought at R$4 is spent the
 * moment the visitor has to look for the number.
 *
 * It is also written to rank. The paid click pays this month; the organic one
 * is what eventually makes the campaign optional, and the two want almost the
 * same page — a specific H1, real answers to real questions, and something
 * worth landing on.
 *
 * The tonal arc is the marketing site's, compressed: night (the situation) →
 * paper (the specification) → muted (the sequence) → light (the questions) →
 * amber (the terminal). No WebGL here on purpose: the hero field is beautiful
 * and it is also the largest contentful paint on the page, which is a thing
 * Google charges for on a landing page.
 */

export const dynamicParams = false;

export function generateStaticParams() {
  return adPages.map((page) => ({ slug: page.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const page = adPageBySlug.get((await params).slug);
  if (!page) return {};

  const url = `${site.url}/${page.slug}`;

  return {
    title: page.metaTitle,
    description: page.metaDescription,
    keywords: [...page.keywords],
    alternates: { canonical: `/${page.slug}` },
    openGraph: {
      type: "website",
      locale: "pt_BR",
      url,
      siteName: site.name,
      title: `${page.metaTitle} · ${site.name}`,
      description: page.metaDescription,
    },
    twitter: {
      card: "summary_large_image",
      title: `${page.metaTitle} · ${site.name}`,
      description: page.metaDescription,
    },
    robots: { index: true, follow: true },
  };
}

/**
 * The structured data.
 *
 * Three things a crawler cannot infer from prose and that pay for themselves
 * on a page like this: that the business is reachable at a phone number and
 * where it works (`ProfessionalService`), what this page is selling
 * (`Service`), and that the questions at the bottom are questions
 * (`FAQPage`, which is what can win the expanded result). Nothing asserted
 * here is a figure we do not have — there is no rating, no review count and no
 * price, which is exactly why there is no `AggregateRating` node.
 */
function structuredData(page: AdPage) {
  const url = `${site.url}/${page.slug}`;
  const businessId = `${site.url}/#organizacao`;

  return {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "ProfessionalService",
        "@id": businessId,
        name: site.name,
        url: site.url,
        description: site.description,
        telephone: site.contact.phoneE164,
        email: site.contact.email,
        address: {
          "@type": "PostalAddress",
          addressLocality: site.contact.region.locality,
          addressRegion: site.contact.region.uf,
          addressCountry: site.contact.region.country,
        },
        areaServed: [
          { "@type": "City", name: "Florianópolis" },
          { "@type": "AdministrativeArea", name: "Santa Catarina" },
          { "@type": "Country", name: "Brasil" },
        ],
        availableLanguage: "pt-BR",
      },
      {
        "@type": "Service",
        name: page.serviceType,
        description: page.metaDescription,
        serviceType: page.serviceType,
        url,
        provider: { "@id": businessId },
        areaServed: { "@type": "Country", name: "Brasil" },
        hasOfferCatalog: {
          "@type": "OfferCatalog",
          name: page.deliverablesHeading,
          itemListElement: page.deliverables.map((item) => ({
            "@type": "Offer",
            itemOffered: {
              "@type": "Service",
              name: item.name,
              description: item.text,
            },
          })),
        },
      },
      {
        "@type": "FAQPage",
        "@id": `${url}#faq`,
        mainEntity: page.faq.map((entry) => ({
          "@type": "Question",
          name: entry.q,
          acceptedAnswer: { "@type": "Answer", text: entry.a },
        })),
      },
      {
        "@type": "BreadcrumbList",
        itemListElement: [
          { "@type": "ListItem", position: 1, name: "Início", item: site.url },
          { "@type": "ListItem", position: 2, name: page.metaTitle, item: url },
        ],
      },
    ],
  };
}

export default async function AdLandingPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const page = adPageBySlug.get((await params).slug);
  if (!page) notFound();

  return (
    <main data-rede className="flex-1 bg-[#06080b]">
      <script
        type="application/ld+json"
        // Static, author-controlled content from content/ads.ts.
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(structuredData(page)),
        }}
      />

      <Hero page={page} />
      <Pains page={page} />
      <Deliverables page={page} />
      <Steps page={page} />
      <Faq page={page} />
      <Closing page={page} />

      <CallBar message={page.whatsappMessage} />
      <PageTracker page={page.slug} />
    </main>
  );
}

/* --------------------------------------------------------------------------
   The bands
   -------------------------------------------------------------------------- */

/**
 * The first screen, and the only one that has to work.
 *
 * Headline, one paragraph, the number, and nothing between them. Everything a
 * visitor needs to decide to call is above the fold on a phone; the plate
 * beside it answers "what do I get out of the call", which is the objection
 * that actually stops the tap.
 */
function Hero({ page }: { page: AdPage }) {
  return (
    <section
      data-tone="night"
      data-section="hero"
      className="bg-surface text-fg relative overflow-hidden"
    >
      {/* The feed coming into the page. */}
      <span
        aria-hidden
        className="hazard absolute inset-x-0 top-0 h-2 opacity-70"
      />

      <Container size="wide" className="relative pt-16 pb-16 sm:pt-24 sm:pb-20">
        <div className="grid gap-12 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)] lg:items-start lg:gap-16">
          <div>
            {/* No identifier above the headline, at any breakpoint — a stacked
                code over a heading is a kicker, which this world does not
                have. The page's code is stamped on the closing plate instead. */}
            <h1 className="font-display text-[clamp(2rem,5.4vw,3.7rem)] leading-[0.99] font-extrabold tracking-[-0.035em]">
              {page.h1[0]}
              <br />
              {page.h1[1]}
            </h1>

            <p className="text-fg-muted mt-6 max-w-[56ch] text-[15px] leading-relaxed sm:text-base">
              {page.deck}
            </p>

            <div
              id="acao"
              className="mt-9 flex flex-col items-start gap-3 sm:flex-row sm:items-stretch sm:gap-4"
            >
              <CallAction placement="primeira-tela" />
              <WhatsappAction
                message={page.whatsappMessage}
                placement="primeira-tela"
              />
            </div>

            {/* The city belongs in a sentence rather than in a mono strip: it
                is the local-relevance signal and it is also the answer to "are
                these people near me", which nobody reads out of a legend. */}
            <p className="text-fg-subtle mt-4 max-w-[52ch] text-[13px] leading-relaxed">
              {site.contact.region.locality} e todo o Brasil · Segunda a sexta,
              8h às 19h. Fora desse horário, mande no WhatsApp — a resposta sai
              antes de você acordar.
            </p>
          </div>

          {/* Three reasons the call is worth making, as terminals under load
              rather than as three cards in a row. */}
          <div className="plate relative rounded-[4px] p-5 sm:p-6">
            <Bolts />
            <p className="font-mono text-[10px] tracking-[0.24em] text-[var(--ink-id-dead)] uppercase">
              O que você leva da ligação
            </p>
            <ul className="recess mt-4 rounded-[3px] px-4 sm:px-5">
              {page.assurances.map((line) => (
                <li
                  key={line}
                  className="flex items-start gap-3.5 border-b border-white/[0.06] py-4 last:border-b-0"
                >
                  <Lamp live className="mt-0.5" />
                  <span className="text-fg text-[14px] leading-snug">
                    {line}
                  </span>
                </li>
              ))}
            </ul>
            <p className="mt-4 font-mono text-[10px] leading-relaxed tracking-[0.14em] text-[var(--ink-id-dead)] uppercase">
              Sem proposta de trinta páginas · Sem reunião para marcar reunião
            </p>
          </div>
        </div>
      </Container>
    </section>
  );
}

/**
 * The situation the visitor arrived in.
 *
 * Unlit, because that is what these are: lines that carry nothing. Rows on
 * hairlines, not a grid of four boxes — four equal boxes side by side are the
 * tangle this whole direction exists to terminate.
 */
function Pains({ page }: { page: AdPage }) {
  return (
    <section
      data-tone="night"
      data-section="dores"
      className="border-line bg-bg text-fg relative border-t py-18 sm:py-24"
    >
      <Container size="wide">
        <div className="max-w-[40rem]">
          <h2 className="font-display text-[clamp(1.75rem,3.6vw,2.8rem)] leading-[1.04] font-extrabold tracking-[-0.03em]">
            {page.painsHeading}
          </h2>
          <p className="text-fg-muted mt-5 max-w-[58ch] text-[15px] leading-relaxed">
            {page.painsDeck}
          </p>
        </div>

        <ul className="mt-10 sm:mt-14">
          {page.pains.map((pain, index) => (
            <li
              key={pain.title}
              className="border-line grid grid-cols-[auto_minmax(0,1fr)] items-start gap-x-5 border-b py-6 last:border-b-0 sm:grid-cols-[auto_minmax(0,18rem)_minmax(0,1fr)] sm:gap-x-10"
            >
              <span className="flex items-center gap-3 pt-1 sm:pt-1.5">
                <Lamp />
                <PlateCode>{`FT-0${index + 1}`}</PlateCode>
              </span>
              <h3 className="font-display text-fg text-[1.05rem] leading-tight font-bold tracking-[-0.02em] sm:text-lg">
                {pain.title}
              </h3>
              <p className="text-fg-muted col-start-2 mt-2 max-w-[62ch] text-sm leading-relaxed sm:col-start-3 sm:mt-0">
                {pain.text}
              </p>
            </li>
          ))}
        </ul>
      </Container>
    </section>
  );
}

/**
 * The specification, in the register a specification belongs in.
 *
 * The page changes light here: this is the same rede drawn on paper rather
 * than running at night. Terminals in a recess, each identified — and the
 * mid-page action at the bottom, because the reader who finished this list is
 * the readiest reader on the page.
 */
function Deliverables({ page }: { page: AdPage }) {
  return (
    <section
      data-tone="light"
      data-section="entregaveis"
      className="bg-surface text-fg relative py-18 sm:py-24"
    >
      <Container size="wide">
        <div className="grid gap-10 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)] lg:gap-16">
          <div className="lg:sticky lg:top-24 lg:self-start">
            <h2 className="font-display text-[clamp(1.75rem,3.6vw,2.8rem)] leading-[1.04] font-extrabold tracking-[-0.03em]">
              {page.deliverablesHeading}
            </h2>
            <p className="text-fg-muted mt-5 max-w-[52ch] text-[15px] leading-relaxed">
              {page.deliverablesDeck}
            </p>

            {page.investimento && (
              <p className="mt-6">
                <Legend>Investimento · {page.investimento}</Legend>
              </p>
            )}

            <div className="mt-8 hidden lg:block">
              <CallAction placement="meio" />
            </div>
          </div>

          <ul className="recess rounded-[3px] px-4 sm:px-6">
            {page.deliverables.map((item) => (
              <li
                key={item.code}
                className="grid grid-cols-[auto_minmax(0,1fr)] items-start gap-x-4 border-b border-[var(--line)] py-5 last:border-b-0 sm:gap-x-6"
              >
                <span className="flex items-center gap-3 pt-0.5">
                  <Lamp live />
                  <PlateCode live className="hidden sm:inline">
                    {item.code}
                  </PlateCode>
                </span>
                <div>
                  <h3 className="font-display text-fg text-[1.02rem] leading-tight font-bold tracking-[-0.02em]">
                    {item.name}
                  </h3>
                  <p className="text-fg-muted mt-1.5 max-w-[60ch] text-sm leading-relaxed">
                    {item.text}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-10 flex flex-col items-start gap-3 sm:flex-row sm:items-stretch sm:gap-4 lg:hidden">
          <CallAction placement="meio" />
          <WhatsappAction message={page.whatsappMessage} placement="meio" />
        </div>
      </Container>
    </section>
  );
}

/** The sequence, on one vertical run with a tap per step. */
function Steps({ page }: { page: AdPage }) {
  return (
    <section
      data-tone="muted"
      data-section="etapas"
      className="bg-surface text-fg relative py-18 sm:py-24"
    >
      <Container size="wide">
        <h2 className="font-display max-w-[38rem] text-[clamp(1.75rem,3.6vw,2.8rem)] leading-[1.04] font-extrabold tracking-[-0.03em]">
          {page.stepsHeading}
        </h2>

        <ol className="relative mt-10 sm:mt-14">
          <span
            aria-hidden
            className="conductor absolute top-3 bottom-3 left-[4px] w-[3px] rounded-full sm:left-[5px]"
          />

          {page.steps.map((step) => (
            <li
              key={step.step}
              className="relative grid grid-cols-[auto_minmax(0,1fr)] items-start gap-x-6 border-b border-[var(--line)] py-6 last:border-b-0 sm:gap-x-10"
            >
              <span
                aria-hidden
                className="bg-brand-500 relative z-10 mt-2 block size-[11px] shrink-0 rounded-full border-[3px] border-[var(--surface)] shadow-[0_0_0_1px_rgb(168_95_9/0.4)] sm:size-[13px]"
              />
              <div className="flex flex-col gap-x-8 gap-y-2 sm:flex-row sm:items-baseline">
                <div className="flex items-baseline gap-4 sm:contents">
                  <PlateCode live className="shrink-0 sm:w-10">
                    {step.step}
                  </PlateCode>
                  <h3 className="font-display text-fg text-lg leading-tight font-bold tracking-[-0.02em] sm:w-48 sm:shrink-0">
                    {step.name}
                  </h3>
                </div>
                <p className="text-fg-muted max-w-[62ch] text-sm leading-relaxed">
                  {step.text}
                </p>
              </div>
            </li>
          ))}
        </ol>
      </Container>
    </section>
  );
}

/**
 * The questions, as questions.
 *
 * Native `<details>` rather than a React accordion: the answers are in the
 * HTML whether or not anything hydrates, which is what the FAQ structured data
 * above is claiming, and it costs the page no JavaScript on the one metric
 * Google prices a landing page by.
 */
function Faq({ page }: { page: AdPage }) {
  return (
    <section
      data-tone="light"
      id="perguntas"
      data-section="perguntas"
      className="bg-surface text-fg relative py-18 sm:py-24"
    >
      <Container size="wide">
        <div className="grid gap-10 lg:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)] lg:gap-16">
          <div>
            <h2 className="font-display text-[clamp(1.75rem,3.6vw,2.8rem)] leading-[1.04] font-extrabold tracking-[-0.03em]">
              Perguntas que sempre aparecem
            </h2>
            <p className="text-fg-muted mt-5 max-w-[46ch] text-[15px] leading-relaxed">
              Se a sua não está aqui, ela cabe numa ligação de quinze minutos —
              e a resposta sai na hora.
            </p>
            <p className="mt-6">
              <a
                href={site.contact.phoneHref}
                data-ads-action="call"
                data-placement="perguntas"
                className="text-[15px] font-semibold text-[var(--ink-accent)] tabular-nums underline underline-offset-4 hover:no-underline"
              >
                {site.contact.phone}
              </a>
            </p>
          </div>

          <div>
            {page.faq.map((entry) => (
              <details
                key={entry.q}
                data-faq={entry.q}
                className="group border-b border-[var(--line)] py-5 last:border-b-0"
              >
                <summary className="flex cursor-pointer list-none items-start gap-4 [&::-webkit-details-marker]:hidden">
                  <span
                    aria-hidden
                    className="mt-[9px] block h-[3px] w-4 shrink-0 rounded-full bg-[var(--ink-accent)] transition-transform duration-200 group-open:rotate-90"
                  />
                  <h3 className="font-display text-fg flex-1 text-[1.02rem] leading-snug font-bold tracking-[-0.02em]">
                    {entry.q}
                  </h3>
                </summary>
                <p className="text-fg-muted mt-3 max-w-[64ch] pl-8 text-sm leading-relaxed">
                  {entry.a}
                </p>
              </details>
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
}

/**
 * The terminal: the one band where amber owns the whole field.
 *
 * The number is set as display type here rather than only living inside the
 * button, so a desktop visitor can read and dial it without clicking anything
 * — which is zero clicks, and the floor this page was aiming at.
 */
function Closing({ page }: { page: AdPage }) {
  return (
    <section
      data-tone="brand"
      id="contato"
      data-section="fechamento"
      className="bg-surface text-fg relative overflow-hidden"
    >
      <span
        aria-hidden
        className="hazard absolute inset-x-0 top-0 h-2.5 [--hazard-color:rgb(22_25_29/0.5)]"
      />

      <Container size="wide" className="relative py-16 sm:py-24">
        <div className="grid gap-12 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)] lg:items-center lg:gap-20">
          <div>
            <h2 className="font-display text-[clamp(1.9rem,4.4vw,3.4rem)] leading-[0.99] font-extrabold tracking-[-0.035em]">
              {page.closing.heading[0]}
              <br />
              {page.closing.heading[1]}
            </h2>
            <p className="mt-6 max-w-[52ch] text-[15px] leading-relaxed text-[rgb(22_25_29/0.78)]">
              {page.closing.text}
            </p>

            <div className="mt-9 flex flex-col items-start gap-3 sm:flex-row sm:items-stretch sm:gap-4">
              <CallAction tone="brand" placement="fechamento" />
              <WhatsappAction
                message={page.whatsappMessage}
                tone="brand"
                placement="fechamento"
              />
            </div>
          </div>

          {/* The number itself, big enough to be read across a desk. */}
          <div
            className="plate relative rounded-[4px] p-6 sm:p-8"
            data-tone="night"
          >
            <Bolts />
            <p className="text-dead-300 font-mono text-[10px] tracking-[0.24em] uppercase">
              Linha direta · {page.code}
            </p>
            <a
              href={site.contact.phoneHref}
              data-ads-action="call"
              data-placement="fechamento"
              className="text-brand-400 hover:text-brand-300 font-display mt-4 block text-[clamp(1.8rem,5vw,2.6rem)] leading-none font-extrabold tracking-[-0.03em] tabular-nums transition-colors"
            >
              {site.contact.phone}
            </a>
            <p className="text-fg-muted mt-4 text-sm leading-relaxed">
              Você fala com quem constrói, não com um atendimento. Se estivermos
              em obra, o WhatsApp é respondido no mesmo dia.
            </p>
            <p className="mt-5">
              <Legend>{site.contact.address}</Legend>
            </p>
          </div>
        </div>
      </Container>
    </section>
  );
}
