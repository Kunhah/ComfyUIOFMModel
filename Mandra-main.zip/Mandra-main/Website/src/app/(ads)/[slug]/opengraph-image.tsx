import { ImageResponse } from "next/og";
import { adPages, adPageBySlug } from "@/content/ads";
import { site } from "@/content/site";

export const size = { width: 1200, height: 630 };
export const contentType = "image/png";
export const alt = `${site.name} — ${site.tagline}`;

export function generateStaticParams() {
  return adPages.map((page) => ({ slug: page.slug }));
}

/**
 * The share card for an ad landing page.
 *
 * It carries the phone number, because the places these links get pasted —
 * a WhatsApp group, a message to a partner — are places where the number being
 * legible in the preview is itself a conversion path.
 *
 * Rendered with the system sans rather than Archivo: `ImageResponse` needs the
 * font as a fetched binary and the one thing an OG image must never do is make
 * the build depend on a network round trip.
 */
export default async function AdOpengraphImage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const page = adPageBySlug.get((await params).slug);
  const headline = page ? `${page.h1[0]} ${page.h1[1]}` : site.tagline;

  return new ImageResponse(
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        padding: 72,
        background:
          "radial-gradient(circle at 78% 22%, #2a2318 0%, #12171d 42%, #06080b 76%)",
        color: "#f4f1ea",
        fontFamily: "sans-serif",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        <svg width="46" height="42" viewBox="0 0 102.27245 89.62957">
          <g transform="translate(-56.464015,-36.797866)">
            <path
              fill="#fda503"
              d="m 56.464015,36.797868 c 1.476697,0.345465 22.323791,14.720874 24.555347,16.236977 l 34.611238,23.52136 c 2.5077,1.728031 6.70233,4.339787 8.85138,6.120978 -1.19927,1.038945 -3.33557,2.428739 -4.68794,3.36094 -2.5474,1.743767 -5.07636,3.512909 -7.58831,5.307002 L 108.29604,94.131094 84.981361,78.117105 C 80.20567,74.867157 74.923764,71.49601 70.272679,68.142152 c -1.277104,0.786474 -2.883647,2.081151 -4.121055,2.97366 -3.192534,2.303001 -6.382518,4.867265 -9.64494,7.048217 0.07726,-13.788675 0.06308,-27.577772 -0.04265,-41.366161 z"
            />
            <path
              fill="#f58a02"
              d="m 158.38485,36.879237 c 0.0836,0.03572 0.28352,0.195626 0.28069,0.246234 -0.0595,1.270295 -0.0553,5.308134 -0.0524,6.247139 -0.0865,11.672366 -0.0454,23.34544 0.12333,35.01681 -4.29953,-3.699317 -8.96479,-6.692118 -13.3522,-10.244717 -3.86008,2.611044 -7.70172,5.248735 -11.52494,7.913083 -2.50628,1.757376 -5.02107,3.637515 -7.57555,5.305014 l -3.40787,-2.316043 -12.90708,-8.854215 c 7.80804,-5.241649 15.82446,-10.969528 23.5758,-16.344147 8.24749,-5.704489 16.52758,-11.360922 24.84027,-16.969158 z"
            />
            <path
              fill="#fdba0c"
              d="m 69.922108,71.241837 c 2.435833,1.307434 6.177251,4.254303 8.568432,5.890614 0.339507,0.232346 0.258851,0.633092 0.265934,1.051562 l -0.02068,31.718667 c -0.529328,0.37793 -1.488179,1.01953 -1.954141,1.41163 -0.546334,0.405 -1.513264,1.07878 -1.976108,1.5256 -0.777398,0.46228 -1.734407,1.25201 -2.472404,1.82599 l -10.469686,7.76763 c -1.726901,1.28788 -3.511494,2.74657 -5.261498,3.95449 -0.14459,-5.73256 -0.03927,-12.01953 -0.03756,-17.7949 l -0.08832,-27.310414 c 1.384125,-1.144557 3.304951,-2.474955 4.800497,-3.580668 2.897111,-2.133038 5.779055,-4.286343 8.645546,-6.460201 z"
            />
            <path
              fill="#f07602"
              d="m 136.51016,77.297032 c 2.34042,-1.435866 6.54214,-4.521518 8.78758,-6.243026 l 13.33236,10.09063 0.01,45.282794 c -1.54091,-0.99897 -3.03788,-2.26799 -4.52776,-3.36265 -3.11584,-2.28967 -6.21184,-4.75372 -9.34327,-7.0115 l -8.27867,-6.24898 c -0.0624,-4.13423 0.10348,-8.84797 -0.0978,-12.920262 0.3062,-6.181928 -0.0127,-13.273239 0.11766,-19.587006 z"
            />
          </g>
        </svg>
        <span style={{ fontSize: 28, fontWeight: 700, letterSpacing: 1 }}>
          MANDRA
        </span>
      </div>

      <div style={{ display: "flex", flexDirection: "column" }}>
        <span
          style={{
            fontSize: headline.length > 58 ? 52 : 60,
            fontWeight: 700,
            lineHeight: 1.08,
            letterSpacing: -1.5,
          }}
        >
          {headline}
        </span>
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
        <span
          style={{
            display: "flex",
            width: 10,
            height: 44,
            backgroundColor: "#f3a33a",
          }}
        />
        <span style={{ fontSize: 40, fontWeight: 700, color: "#f3a33a" }}>
          {site.contact.phone}
        </span>
        <span style={{ fontSize: 24, color: "#9aa6b4" }}>
          ligue ou chame no WhatsApp
        </span>
      </div>
    </div>,
    size,
  );
}
