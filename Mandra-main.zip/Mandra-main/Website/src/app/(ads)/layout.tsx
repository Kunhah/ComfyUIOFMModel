import Link from "next/link";
import { site, legalLinks } from "@/content/site";
import { Logo } from "@/components/ui/logo";
import { HeaderCallAction } from "@/components/ads/actions";
import { GoogleTag } from "@/components/ads/google-tag";

/**
 * The ad landing pages' chrome — deliberately almost none of it.
 *
 * This is a sibling of `(marketing)/`, not a page inside it, and the whole
 * reason is the header. The marketing header carries five navigation links,
 * and every one of them is a way for a click we paid for to leave the page
 * without calling. Here the header holds two things: who we are, and the
 * number. The footer holds the same, plus what the law requires.
 *
 * It is not `noindex`. These pages are written to rank as well as to convert —
 * the paid click is what pays this month and the organic one is what makes the
 * campaign eventually optional.
 */
export default function AdsLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <div
      data-tone="night"
      data-rede
      className="flex min-h-full flex-1 flex-col bg-[#06080b]"
    >
      <GoogleTag />

      <a
        href="#acao"
        className="focus:bg-brand-400 focus:text-ink-950 sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:rounded-[3px] focus:px-4 focus:py-2 focus:text-sm"
      >
        Pular para o contato
      </a>

      <header className="border-line sticky top-0 z-40 w-full border-b bg-[rgb(6_8_11/0.9)] backdrop-blur-md">
        <div className="mx-auto flex h-16 w-full max-w-[1360px] items-center justify-between gap-4 px-5 sm:px-8">
          <Logo />
          <HeaderCallAction />
        </div>
      </header>

      {/* The sticky call bar occupies the bottom of a phone screen, so the
          page reserves its height rather than letting it cover the last line
          of the footer. */}
      <div className="flex flex-1 flex-col pb-[76px] lg:pb-0">{children}</div>

      <footer className="border-line bg-bg text-fg border-t">
        <div className="mx-auto flex w-full max-w-[1360px] flex-col gap-4 px-5 py-10 sm:flex-row sm:items-center sm:justify-between sm:px-8">
          <p className="text-fg-subtle text-xs">
            © {new Date().getFullYear()} {site.name}. {site.contact.address}.
          </p>
          <ul className="flex flex-wrap items-center gap-x-6 gap-y-2">
            <li>
              <a
                href={site.contact.phoneHref}
                data-ads-action="call"
                data-placement="rodape"
                className="text-fg-muted hover:text-brand-300 text-xs tabular-nums transition-colors"
              >
                {site.contact.phone}
              </a>
            </li>
            <li>
              <a
                href={site.contact.emailHref}
                className="text-fg-muted hover:text-brand-300 text-xs transition-colors"
              >
                {site.contact.email}
              </a>
            </li>
            {legalLinks.map((link) => (
              <li key={link.href}>
                <Link
                  href={link.href}
                  className="text-fg-subtle hover:text-fg text-xs transition-colors"
                >
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </footer>
    </div>
  );
}
