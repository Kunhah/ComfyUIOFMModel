import { redirect } from "next/navigation";
import { LockKeyhole } from "lucide-react";
import { currentUser, roleHome } from "@/lib/auth/server";

export const metadata = { title: "Entrar como operador" };
export const dynamic = "force-dynamic";

const ERRORS: Record<string, string> = {
  "1": "Usuário ou senha incorretos.",
  role: "Use a entrada correspondente ao seu tipo de acesso.",
  throttled:
    "Muitas tentativas seguidas. Aguarde 15 minutos antes de tentar de novo.",
  config: "O acesso ainda não foi configurado no servidor.",
};

export default async function OperatorLogin({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; next?: string }>;
}) {
  const params = await searchParams;
  const next =
    params.next?.startsWith("/") && !params.next.startsWith("//")
      ? params.next
      : "/operador";
  const user = await currentUser();
  if (user) redirect(user.role === "operador" ? next : roleHome(user.role));
  const error = params.error ? ERRORS[params.error] : undefined;

  return (
    <main
      data-prospector
      className="bg-bg text-fg flex min-h-screen flex-1 items-center justify-center p-5"
    >
      <form
        action="/api/admin/session"
        method="POST"
        className="border-line bg-surface w-full max-w-sm rounded-3xl border p-8 shadow-2xl"
      >
        <div className="bg-brand/15 text-brand flex size-12 items-center justify-center rounded-2xl">
          <LockKeyhole className="size-5" />
        </div>
        <p className="text-brand mt-7 text-sm font-semibold tracking-[0.18em]">
          MANDRA
        </p>
        <h1 className="mt-2 text-2xl font-semibold">Entrar como operador</h1>
        <p className="text-fg-muted mt-2 text-sm leading-6">
          Use o usuário e a senha criados pelo administrador.
        </p>
        {error && (
          <p className="mt-5 rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-300">
            {error}
          </p>
        )}
        <input type="hidden" name="next" value={next} />
        <input type="hidden" name="portal" value="operador" />
        <label
          className="text-fg-muted mt-6 block text-sm font-medium"
          htmlFor="username"
        >
          Usuário
        </label>
        <input
          id="username"
          name="username"
          type="text"
          required
          autoFocus
          autoComplete="username"
          autoCapitalize="none"
          spellCheck={false}
          className="border-line bg-surface-2 focus:border-brand mt-2 w-full rounded-xl border px-3 py-3 text-sm outline-none"
        />
        <label
          className="text-fg-muted mt-4 block text-sm font-medium"
          htmlFor="password"
        >
          Senha
        </label>
        <input
          id="password"
          name="password"
          type="password"
          required
          autoComplete="current-password"
          className="border-line bg-surface-2 focus:border-brand mt-2 w-full rounded-xl border px-3 py-3 text-sm outline-none"
        />
        <button
          type="submit"
          className="bg-brand text-brand-fg mt-6 w-full rounded-xl px-4 py-3 text-sm font-semibold transition hover:opacity-90"
        >
          Entrar
        </button>
      </form>
    </main>
  );
}
