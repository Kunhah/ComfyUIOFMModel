import Link from "next/link";
import {
  Building2,
  History,
  MessageSquareText,
  Mic,
  PhoneCall,
  Search,
} from "lucide-react";
import { can, requireOperator } from "@/lib/auth/server";
import { CallsToday } from "@/components/admin/calls-today";
import { callsTodayTotal, DEFAULT_DAILY_TARGET } from "@/lib/prospector/calls";

export const dynamic = "force-dynamic";
export const metadata = {
  title: "Área do operador",
  robots: { index: false, follow: false },
};

/** Dedicated starting point for database-backed operator accounts. */
export default async function OperatorPage() {
  const user = await requireOperator("/operador");

  // Scoped to this operator by id, never filtered in the page: an operator's
  // portal shows their own day, and the team-wide view is the admin's.
  const today = callsTodayTotal(user.id);

  const links = [
    // First, and on purpose: the counter above this grid sets a daily call
    // target, and until this screen existed there was no way to reach a queue
    // and move it. The automatic list is one press away on the other side.
    {
      href: "/operador/ligacoes",
      label: "Ligações",
      text: "Monte a fila do dia e registre cada ligação.",
      icon: PhoneCall,
    },
    // Second, next to the queue it reviews: the meetings worth analysing are
    // the ones that came out of those calls.
    {
      href: "/operador/reunioes",
      label: "Reuniões",
      text: "Suba a gravação e veja onde a venda travou.",
      icon: Mic,
    },
    {
      href: "/prospector",
      label: "Buscar leads",
      text: "Encontre negócios por nicho e cidade.",
      icon: Search,
    },
    {
      href: "/prospector/historico",
      label: "Histórico",
      text: "Consulte os leads já encontrados.",
      icon: History,
    },
    // Says "sua" because it is: the message is per person, and an operator
    // who thinks they are about to change the team's will not touch it.
    {
      href: "/prospector/mensagens",
      label: "Sua mensagem",
      text: "Reescreva a sua abordagem e anote o que funcionou.",
      icon: MessageSquareText,
    },
    // Only when they hold the grant. `/prospector/b2b` calls
    // requirePermission("b2b") and would bounce them back here — the route is
    // the control, this is the courtesy of not offering a card that 403s.
    ...(can(user, "b2b")
      ? [
          {
            href: "/prospector/b2b",
            label: "Empresas B2B",
            text: "Prospecção por setor e país.",
            icon: Building2,
          },
        ]
      : []),
  ];

  return (
    <main
      data-prospector
      className="bg-bg text-fg flex min-h-screen flex-1 items-center px-5 py-10"
    >
      <section className="mx-auto w-full max-w-4xl">
        <p className="text-brand text-xs font-semibold tracking-[0.16em]">
          ÁREA DO OPERADOR
        </p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight">
          Olá, {user.displayName}
        </h1>
        <p className="text-fg-muted mt-2">
          Escolha uma ferramenta para começar seu trabalho.
        </p>
        <div className="mt-8">
          <CallsToday
            calls={today.calls}
            reached={today.reached}
            target={DEFAULT_DAILY_TARGET}
            label="Suas ligações hoje"
          />
        </div>
        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {links.map(({ href, label, text, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              className="border-line bg-surface hover:border-brand rounded-2xl border p-5 transition"
            >
              <Icon className="text-brand size-5" />
              <h2 className="mt-5 font-semibold">{label}</h2>
              <p className="text-fg-muted mt-1 text-sm leading-6">{text}</p>
            </Link>
          ))}
        </div>
      </section>
    </main>
  );
}
