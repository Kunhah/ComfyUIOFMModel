import { MeetingsView } from "@/app/admin/(crm)/reunioes/page";
import { requireOperator } from "@/lib/auth/server";

export const dynamic = "force-dynamic";
export const metadata = {
  title: "Análise de reuniões",
  robots: { index: false, follow: false },
};

/**
 * The operator's own meetings.
 *
 * Same screen as /admin/reunioes, mounted here because the whole /admin tree is
 * admin-only and these recordings are the operator's own calls. Scoped to them:
 * the admin's mount passes null and sees everybody's, and a seller reading the
 * team's reviews is a different product from a seller reading their own.
 */
export default async function OperatorMeetingsPage() {
  const user = await requireOperator("/operador/reunioes");

  return (
    <main data-prospector className="bg-bg text-fg flex min-h-screen flex-1">
      <MeetingsView basePath="/operador/reunioes" scope={user.id} />
    </main>
  );
}
