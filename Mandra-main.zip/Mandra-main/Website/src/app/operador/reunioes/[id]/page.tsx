import { MeetingReviewView } from "@/app/admin/(crm)/reunioes/[id]/page";
import { requireOperator } from "@/lib/auth/server";

export const dynamic = "force-dynamic";
export const metadata = {
  title: "Análise da reunião",
  robots: { index: false, follow: false },
};

export default async function OperatorMeetingPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const user = await requireOperator(`/operador/reunioes/${id}`);

  return (
    <main data-prospector className="bg-bg text-fg flex min-h-screen flex-1">
      {/* Never null here: an operator reads their own reviews and nobody else's. */}
      <MeetingReviewView
        id={id}
        basePath="/operador/reunioes"
        viewerId={user.id}
      />
    </main>
  );
}
