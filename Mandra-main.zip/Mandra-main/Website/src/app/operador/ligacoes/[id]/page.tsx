import { CallSessionView } from "@/app/admin/(crm)/ligacoes/[id]/page";
import { requireOperator } from "@/lib/auth/server";

export const dynamic = "force-dynamic";
export const metadata = {
  title: "Sessão de ligações",
  robots: { index: false, follow: false },
};

/**
 * One calling session, for an operator.
 *
 * Deliberately not scoped to lists this operator created: a queue is shared
 * work, and its position lives in SQLite precisely so a list can be picked up
 * by whoever is free. What the queue must not do is hand two people the same
 * business, and `nextInList` already guarantees that.
 */
export default async function OperatorCallSessionPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  await requireOperator("/operador/ligacoes");

  return (
    <main data-prospector className="bg-bg text-fg flex min-h-screen flex-1">
      <CallSessionView
        listId={Number((await params).id)}
        basePath="/operador/ligacoes"
      />
    </main>
  );
}
