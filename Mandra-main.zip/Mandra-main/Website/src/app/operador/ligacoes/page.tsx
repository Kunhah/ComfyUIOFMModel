import { CallListsView } from "@/app/admin/(crm)/ligacoes/page";
import { can, requireOperator } from "@/lib/auth/server";

export const dynamic = "force-dynamic";
export const metadata = {
  title: "Ligações",
  robots: { index: false, follow: false },
};

/**
 * The operator's call queue.
 *
 * The same screen as /admin/ligacoes, mounted here because the people who make
 * the calls are operators and the whole /admin tree is admin-only. Without this
 * the feature was unreachable by the only role that uses it: /operador showed a
 * daily call target with no way to place a call, and the "criar lista" button in
 * the CRM pushed to a URL that redirected them straight back.
 *
 * Two arguments carry the difference, and both are decided here rather than in
 * the view: the metric row is scoped to this operator (the team's totals belong
 * on the admin's screen — same rule as `CallsToday`), and every link stays under
 * /operador.
 */
export default async function OperatorCallsPage() {
  const user = await requireOperator("/operador/ligacoes");

  return (
    <main data-prospector className="bg-bg text-fg flex min-h-screen flex-1">
      <CallListsView
        basePath="/operador/ligacoes"
        actorId={user.id}
        canExport={can(user, "export")}
      />
    </main>
  );
}
