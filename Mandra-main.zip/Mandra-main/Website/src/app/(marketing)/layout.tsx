import { site } from "@/content/site";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Providers } from "@/components/motion/providers";

/**
 * The public site: header, footer and the scroll-motion providers.
 *
 * Everything here is marketing-only. `/prospector` deliberately sits outside
 * this group so the tool doesn't inherit the chrome or the JSON-LD.
 */

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: site.name,
  url: site.url,
  description: site.description,
  email: site.contact.email,
  telephone: site.contact.phoneE164,
  address: {
    "@type": "PostalAddress",
    addressLocality: site.contact.region.locality,
    addressRegion: site.contact.region.uf,
    addressCountry: site.contact.region.country,
  },
  areaServed: [
    { "@type": "AdministrativeArea", name: "Santa Catarina" },
    { "@type": "Country", name: "Brasil" },
  ],
  sameAs: site.social.map((s) => s.href),
};

export default function MarketingLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <>
      <script
        type="application/ld+json"
        // Static, author-controlled content — no user input reaches this.
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <a
        href="#servicos"
        className="focus:rounded-control focus:bg-brand-400 focus:text-ink-950 sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:px-4 focus:py-2 focus:text-sm"
      >
        Pular para o conteúdo
      </a>
      {/* The whole public tree sits on the night ground, so the sticky header
          is transparent over the cable field rather than over the body's cream
          — which is what `body` still paints for the internal tools. */}
      <div
        data-tone="night"
        data-rede
        className="flex min-h-full flex-1 flex-col bg-[#06080b]"
      >
        <Providers>
          <Header />
          {children}
          <Footer />
        </Providers>
      </div>
    </>
  );
}
