import { RedeHero } from "@/components/sections/rede-hero";
import { Emaranhado } from "@/components/sections/emaranhado";
import { Linhas } from "@/components/sections/linhas";
import { Diagrama } from "@/components/sections/diagrama";
import { Rota } from "@/components/sections/rota";
import { Ferramental } from "@/components/sections/ferramental";
import { Carga } from "@/components/sections/carga";
import { Terminal } from "@/components/sections/terminal";
import { PageTracker } from "@/components/analytics/tracker";

/**
 * A Rede.
 *
 * The scroll is one continuous state change rather than a stack of bands, and
 * it runs in three acts of light:
 *
 *   NIGHT  the rede as hardware — the bundle under load, the discharge into
 *          the mark, and the tangle the visitor already owns
 *   PAPER  the rede as a drawing — the five lines, the wiring diagram and the
 *          installation sequence, in the register a schematic belongs in
 *   NIGHT  the rede running again — what it is built from, what is already
 *          carrying load
 *   AMBER  the terminal, the only surface the brand colour owns outright
 *
 * The light bands are not a break from the world. They are the same objects
 * under different light, which is why a plate is a card of stock there and a
 * conductor is a ruled ink line — see the material variables in globals.css.
 */
export default function Home() {
  return (
    <main data-rede className="flex-1 bg-[#06080b]">
      {/* The home page measures itself the same way the landing pages do, and
          for a better reason: nobody buys these clicks, so nothing else in the
          stack can say where this page loses a reader. */}
      <PageTracker page="home" />
      <RedeHero />
      <Emaranhado />

      <Linhas />
      <Diagrama />
      <Rota />

      <Ferramental />
      <Carga />
      <Terminal />
    </main>
  );
}
