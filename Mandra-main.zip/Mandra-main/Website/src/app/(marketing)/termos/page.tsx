import type { Metadata } from "next";
import { LegalPlaceholder } from "@/components/sections/legal-placeholder";
import { PageTracker } from "@/components/analytics/tracker";

export const metadata: Metadata = {
  title: "Termos de Uso",
  description: "Termos de Uso da Mandra — documento em elaboração.",
  robots: { index: false, follow: true },
};

export default function TermosPage() {
  return (
    <>
      {/* Measured with no funnel: there is nothing to convert on a legal page,
          and a chart implying otherwise would mean nothing. What the count is
          for is the rest of the site — a jump in reads here is a signal about
          the pages that link to it. */}
      <PageTracker page="termos" />
      <LegalPlaceholder kind="Documento legal" title="Termos de Uso" />
    </>
  );
}
