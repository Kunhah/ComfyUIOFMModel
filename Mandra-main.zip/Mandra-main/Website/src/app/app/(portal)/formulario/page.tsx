import { headers } from "next/headers";
import { CheckCircle2, CircleAlert } from "lucide-react";
import { requireClient } from "@/lib/auth/server";
import { listAccountSites } from "@/lib/crm/sites";

export const metadata = { title: "Formulário do site" };
export const dynamic = "force-dynamic";

/**
 * The client's own copy of their form snippet.
 *
 * They mostly never need it — we install it when we build the site. It is here
 * for the two cases that actually happen: they moved to a new page and want the
 * form on it, or someone else touches their site and needs the tag. Showing it
 * beats us digging the key out of the admin screen every time.
 *
 * The key is public and is printed in full on purpose. It ships in the page
 * source of their own website; masking it here would only make it impossible
 * for the client to read their own configuration back.
 *
 * Read-only. The origin allowlist is what actually bounds the endpoint, and
 * editing it is our job — a client who types their domain wrong would take
 * their own form offline with nothing on screen to explain why.
 */
async function scriptOrigin(): Promise<string> {
  const head = await headers();
  const host =
    head.get("x-forwarded-host") ?? head.get("host") ?? "localhost:3000";
  const proto =
    head.get("x-forwarded-proto")?.split(",")[0]?.trim() ??
    (host.startsWith("localhost") ? "http" : "https");
  return `${proto}://${host}`;
}

export default async function FormularioPage() {
  const { account } = await requireClient("/app/formulario");
  const sites = listAccountSites(account.id);
  const origin = await scriptOrigin();

  return (
    <main className="bg-bg text-fg min-w-0 flex-1 px-5 py-8 md:px-8">
      <header className="mb-7">
        <h1 className="text-2xl font-semibold">Formulário do site</h1>
        <p className="text-fg-muted mt-1.5 max-w-2xl text-sm leading-6">
          É este trecho que liga o formulário do seu site a esta tela. Ele já
          está instalado — guarde caso precise recriar a página de contato.
        </p>
      </header>

      {sites.length === 0 ? (
        <div className="border-line bg-surface rounded-2xl border p-10 text-center">
          <p className="font-medium">Nenhum site conectado ainda.</p>
          <p className="text-fg-muted mx-auto mt-2 max-w-md text-sm leading-6">
            Assim que seu site estiver no ar, a Atlas conecta o formulário e os
            contatos passam a aparecer aqui.
          </p>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          {sites.map((site) => (
            <section
              key={site.id}
              className="border-line bg-surface rounded-2xl border p-5"
            >
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="font-semibold">{site.name}</h2>
                  <p className="text-fg-subtle mt-0.5 text-xs">
                    {site.origins.join(" · ")}
                  </p>
                </div>
                {/* "Never received anything" is the state worth surfacing: a
                    site with the tag not pasted looks exactly like a quiet
                    week, and neither of us finds out for a month. */}
                {site.leadCount > 0 ? (
                  <span className="text-fg-muted flex items-center gap-1.5 text-sm">
                    <CheckCircle2 className="size-4 text-emerald-600" />
                    {site.leadCount.toLocaleString("pt-BR")} contatos recebidos
                  </span>
                ) : (
                  <span className="text-fg-muted flex items-center gap-1.5 text-sm">
                    <CircleAlert className="size-4 text-amber-600" />
                    Nenhum contato recebido ainda
                  </span>
                )}
              </div>

              <pre className="border-line bg-surface-2 mt-4 overflow-x-auto rounded-xl border p-4 text-xs leading-6">
                <code>{snippet(origin, site.key)}</code>
              </pre>
            </section>
          ))}
        </div>
      )}
    </main>
  );
}

/**
 * Kept identical to the admin screen's version. The two are shown to different
 * people about the same installation, and a client pasting a snippet that
 * differs from the one we installed is a support call about a form that
 * "stopped working".
 */
function snippet(origin: string, key: string): string {
  return [
    `<form data-atlas-crm>`,
    `  <input name="nome" required placeholder="Seu nome">`,
    `  <input name="email" type="email" placeholder="Seu e-mail">`,
    `  <input name="telefone" placeholder="WhatsApp">`,
    `  <textarea name="mensagem" placeholder="Como podemos ajudar?"></textarea>`,
    `  <button type="submit">Enviar</button>`,
    `</form>`,
    ``,
    `<script src="${origin}/atlas-crm.js" data-key="${key}"></script>`,
  ].join("\n");
}
