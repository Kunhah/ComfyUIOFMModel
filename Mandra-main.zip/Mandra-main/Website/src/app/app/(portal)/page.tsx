import { CalendarClock, Inbox, MessageSquareReply } from "lucide-react";
import { LeadTable, type CrmLead } from "@/components/admin/lead-table";
import { requireClient, scopeFor } from "@/lib/auth/server";
import { toCrmRow } from "@/lib/crm/rows";
import { outreachContextFor } from "@/lib/prospector/templates-store";
import {
  filtersToQuery,
  historyFacets,
  parseFilters,
  queryHistory,
} from "@/lib/prospector/history";
import { FUNNEL_LABEL, FUNNEL_STAGES } from "@/lib/prospector/types";

export const dynamic = "force-dynamic";

/**
 * The client's whole product: the people who contacted them, and what happened
 * next.
 *
 * It is the CRM's lead table over the CRM's writers, with one difference that
 * decides everything — `scopeFor(user)` resolves to their account, so every
 * query, count and export on this page is bounded by it. The page never names
 * an account id; it cannot, because it never sees one it did not get from the
 * session.
 *
 * `requireClient()` runs again here rather than trusting the layout: a layout
 * does not re-run on client navigations, which is the same reason every CRM
 * page repeats its own check.
 */
export default async function PortalPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { user, account } = await requireClient("/app");

  const filters = parseFilters(await searchParams, scopeFor(user));
  const facets = historyFacets(filters);
  const page = queryHistory({ ...filters, perPage: 50 });
  // No viewer: operator exclusivity is our internal rule about who on our team
  // approaches a business, and it has nothing to say to a client looking at
  // their own pipeline. Passing `toCrmRow` bare would hand it the array index.
  // The client is not one of us, so they get the team's copy and no sender
  // name — `outreachContextFor` decides that, not this page. Signing our
  // operator's name to a message a customer sends is the one outcome here
  // that would be a real mistake.
  const outreach = outreachContextFor(user);
  const rows: CrmLead[] = page.leads.map((lead) =>
    toCrmRow(lead, undefined, outreach),
  );

  const view = (overrides: Parameters<typeof filtersToQuery>[1]) =>
    `/app${filtersToQuery(filters, { ...overrides, page: 1 })}`;

  const stageCount = (stage: (typeof FUNNEL_STAGES)[number]) =>
    facets.byStage.find((entry) => entry.stage === stage)?.count ?? 0;

  const fmt = (n: number) => n.toLocaleString("pt-BR");

  return (
    <main className="bg-bg text-fg min-w-0 flex-1 px-5 py-8 md:px-8">
      <header className="mb-7">
        <h1 className="text-2xl font-semibold">Meus contatos</h1>
        <p className="text-fg-muted mt-1.5 text-sm">
          Tudo que chegou pelo site da {account.name}.
        </p>
      </header>

      {/* Three numbers, and each is a decision rather than a statistic: how much
          is waiting, how much is promised for today, how much is live. */}
      <div className="mb-7 grid gap-3 sm:grid-cols-3">
        <Metric
          icon={<Inbox className="size-4" />}
          label="Novos hoje"
          value={fmt(facets.addedToday)}
          hint="Chegaram nas últimas horas"
        />
        <Metric
          icon={<CalendarClock className="size-4" />}
          label="Retornos para hoje"
          value={fmt(facets.due)}
          hint={
            facets.overdue > 0
              ? `${fmt(facets.overdue)} já atrasado${facets.overdue === 1 ? "" : "s"}`
              : "Nenhum atrasado"
          }
          href={view({ onlyDue: true })}
        />
        <Metric
          icon={<MessageSquareReply className="size-4" />}
          label="Em conversa"
          value={fmt(
            stageCount("contato") +
              stageCount("qualificado") +
              stageCount("proposta") +
              stageCount("negociacao"),
          )}
          hint="Já respondidos, ainda em aberto"
        />
      </div>

      {/* Every stage, including the empty ones and in funnel order. Sorting by
          count turns a funnel into a bar chart and hides the gap you opened the
          page to find — the same rule the CRM's chips follow. */}
      <div className="mb-6 flex flex-wrap gap-2">
        <Chip
          href="/app"
          label="Todos"
          count={fmt(facets.total)}
          active={!filters.stage}
        />
        {FUNNEL_STAGES.map((stage) => (
          <Chip
            key={stage}
            href={view({ stage })}
            label={FUNNEL_LABEL[stage]}
            count={fmt(stageCount(stage))}
            active={filters.stage === stage}
          />
        ))}
      </div>

      {rows.length === 0 ? (
        <Empty
          filtered={Boolean(filters.stage || filters.onlyDue || filters.q)}
        />
      ) : (
        <div className="border-line bg-surface overflow-hidden rounded-2xl border">
          {/* canCall={false}: the calling queue is our tooling and lives under
              /admin, so offering it here would be a button that dead-ends. */}
          <LeadTable leads={rows} canCall={false} />
        </div>
      )}

      {page.pages > 1 && (
        <p className="text-fg-subtle mt-4 text-sm">
          Página {page.page} de {page.pages} · {fmt(page.total)} contatos
        </p>
      )}
    </main>
  );
}

function Metric({
  icon,
  label,
  value,
  hint,
  href,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  hint: string;
  href?: string;
}) {
  const body = (
    <>
      <span className="text-fg-muted flex items-center gap-2 text-sm">
        {icon}
        {label}
      </span>
      <span className="mt-2 block text-2xl font-semibold tabular-nums">
        {value}
      </span>
      <span className="text-fg-subtle mt-1 block text-xs">{hint}</span>
    </>
  );

  const className =
    "border-line bg-surface block rounded-2xl border p-4 transition";

  return href ? (
    <a href={href} className={`${className} hover:border-brand`}>
      {body}
    </a>
  ) : (
    <div className={className}>{body}</div>
  );
}

function Chip({
  href,
  label,
  count,
  active,
}: {
  href: string;
  label: string;
  count: string;
  active: boolean;
}) {
  return (
    <a
      href={href}
      aria-current={active ? "page" : undefined}
      className={`rounded-full border px-3 py-1.5 text-sm transition ${
        active
          ? "border-brand bg-brand text-brand-fg font-medium"
          : "border-line bg-surface text-fg-muted hover:border-brand"
      }`}
    >
      {label} <span className="tabular-nums opacity-70">{count}</span>
    </a>
  );
}

/**
 * The two empty states are different questions. "Nothing matches this filter"
 * is a dead end you back out of; "nothing has arrived yet" is the state a brand
 * new account is in, where the useful thing to say is where the contacts will
 * come from.
 */
function Empty({ filtered }: { filtered: boolean }) {
  return (
    <div className="border-line bg-surface rounded-2xl border p-10 text-center">
      <p className="font-medium">
        {filtered ? "Nenhum contato com esse filtro." : "Nenhum contato ainda."}
      </p>
      <p className="text-fg-muted mx-auto mt-2 max-w-md text-sm leading-6">
        {filtered ? (
          <a href="/app" className="text-brand underline">
            Ver todos os contatos
          </a>
        ) : (
          <>
            Assim que alguém preencher o formulário do seu site, o contato
            aparece aqui — com telefone, e-mail e o que a pessoa escreveu.
          </>
        )}
      </p>
    </div>
  );
}
