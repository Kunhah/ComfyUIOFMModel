import Link from "next/link";
import { Inbox, LogOut, Code2 } from "lucide-react";
import { LogoMark } from "@/components/ui/logo";
import { requireClient } from "@/lib/auth/server";

/**
 * The client portal's shell.
 *
 * Reuses the CRM's tone blocks (`[data-admin]`, `[data-admin-shell]`) rather
 * than declaring a third one. They are already "charcoal chrome around a paper
 * work area", which is what this is; a `[data-app]` block would have to give a
 * value to every semantic colour again (see the rule in AGENTS.md about new
 * colours needing a value in *every* tone block) to end up looking the same.
 * Give it its own block the day the portal should look like the client's brand
 * rather than like ours.
 *
 * `requireClient()` here is for the chrome and the account name, not for
 * security: a layout does not re-run on client navigations, so each page
 * repeats the check itself — the same rule `(crm)/layout.tsx` follows.
 */
export default async function PortalLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  const { user, account } = await requireClient("/app");

  return (
    <div
      data-admin
      className="bg-bg text-fg flex min-h-screen flex-1 flex-col lg:flex-row"
    >
      <aside
        data-admin-shell
        className="bg-bg text-fg flex shrink-0 flex-col px-4 py-6 lg:w-[264px]"
      >
        <div className="flex items-center gap-3 px-3">
          <span className="text-[22px] font-semibold tracking-[0.08em]">
            ATLAS
          </span>
          <span className="bg-brand text-brand-fg flex size-8 items-center justify-center rounded-xl">
            <LogoMark className="size-5" />
          </span>
        </div>

        {/* Two links, and both go somewhere. The temptation on a portal is to
            list the product we intend to sell them; an unbuilt section routed
            back to the dashboard reads as a broken link, not as a roadmap. */}
        <nav className="mt-8 flex flex-col gap-1">
          <Link
            href="/app"
            className="text-fg-muted hover:bg-surface-raised hover:text-fg flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition"
          >
            <Inbox className="size-4" />
            Meus contatos
          </Link>
          <Link
            href="/app/formulario"
            className="text-fg-muted hover:bg-surface-raised hover:text-fg flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition"
          >
            <Code2 className="size-4" />
            Formulário do site
          </Link>
        </nav>

        <div className="border-line bg-surface-raised mt-8 hidden rounded-2xl border p-5 lg:mt-auto lg:block">
          <p className="text-brand text-sm font-semibold">Como funciona</p>
          <p className="text-fg-muted mt-2.5 text-sm leading-6">
            Todo contato enviado pelo formulário do seu site aparece aqui na
            hora. Marque o que já foi atendido e agende o retorno para não
            perder ninguém.
          </p>
          <div className="bg-brand mt-5 h-1 w-10 rounded-full" />
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header
          data-admin-shell
          className="bg-surface text-fg flex h-16 items-center justify-between gap-4 px-5 md:px-8"
        >
          {/* The account, not the product name. A client signing in wants to
              see their own business at the top of their own screen. */}
          <p className="truncate text-sm font-medium">{account.name}</p>
          <div className="flex items-center gap-4">
            <div className="hidden text-right sm:block">
              <p className="text-sm font-medium">{user.displayName}</p>
              <p className="text-fg-subtle text-xs">{user.username}</p>
            </div>
            <span className="bg-surface-raised flex size-9 items-center justify-center rounded-xl text-sm font-semibold uppercase">
              {user.displayName.slice(0, 1)}
            </span>
            {/* A plain form, so signing out works without JavaScript and the
                cookie is cleared by the same route that sets it. */}
            <form action="/api/admin/session" method="POST">
              <input type="hidden" name="intent" value="logout" />
              <button
                type="submit"
                title="Sair"
                aria-label="Sair"
                className="text-fg-muted hover:bg-surface-raised hover:text-fg flex size-11 items-center justify-center rounded-xl transition lg:size-9"
              >
                <LogOut className="size-4" />
              </button>
            </form>
          </div>
        </header>

        {children}
      </div>
    </div>
  );
}
