import type { Metadata } from "next";

/**
 * Everything under /app — the client portal, login included.
 *
 * Metadata only, exactly like `admin/layout.tsx`: the chrome lives in
 * `(portal)/layout.tsx` so the login screen, which renders before there is a
 * session to hang a sidebar on, does not inherit it.
 *
 * This is the only tree in the app a customer of ours ever signs in to. It sits
 * beside `/admin` rather than inside it because the two answer to different
 * people — a route group under /admin would put a client one guessed URL away
 * from our prospecting, and would make every future `/admin/*` page a question
 * about who can see it.
 */
export const metadata: Metadata = {
  title: { default: "Meus contatos", template: "%s · Atlas" },
  // A real login page on a public host. robots.ts keeps crawlers off the path;
  // this is the header that holds if one arrives anyway.
  robots: { index: false, follow: false },
};

export default function AppLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return children;
}
