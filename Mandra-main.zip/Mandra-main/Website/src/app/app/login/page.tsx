import { redirect } from "next/navigation";
import { LockKeyhole } from "lucide-react";
import { currentUser, roleHome } from "@/lib/auth/server";

export const metadata = { title: "Entrar" };
export const dynamic = "force-dynamic";

/**
 * The client's login.
 *
 * A third form posting to the same `/api/admin/session` route as the other two,
 * distinguished only by its `portal` field — which the route checks against the
 * account's role, so a client cannot sign in at /admin/login and an operator
 * cannot sign in here. Three forms rather than one because the copy is the
 * difference: "Entrar como administrador" is not a sentence to show a dentist.
 */
const ERRORS: Record<string, string> = {
  "1": "Usuário ou senha incorretos.",
  throttled:
    "Muitas tentativas seguidas. Aguarde 15 minutos antes de tentar de novo.",
  config: "O acesso ainda não foi configurado. Fale com a Atlas.",
  role: "Use a entrada correspondente ao seu tipo de acesso.",
  // Deliberately vague about the reason. Why an account was suspended is a
  // conversation to have with the client directly, not a notice from a web app.
  suspensa: "Seu acesso está temporariamente indisponível. Fale com a Atlas.",
};

export default async function ClientLogin({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; next?: string; suspensa?: string }>;
}) {
  const params = await searchParams;
  const next =
    params.next?.startsWith("/app") && !params.next.startsWith("//")
      ? params.next
      : "/app";

  // Already signed in: the form would only be a way to lock yourself out of the
  // page you asked for.
  const user = await currentUser();
  if (user) redirect(user.role === "cliente" ? next : roleHome(user.role));

  const error = params.suspensa
    ? ERRORS.suspensa
    : params.error
      ? ERRORS[params.error]
      : undefined;

  return (
    <main
      data-admin
      className="flex min-h-screen flex-1 items-center justify-center bg-[#101418] p-5"
    >
      <form
        action="/api/admin/session"
        method="POST"
        className="w-full max-w-sm rounded-3xl border border-white/10 bg-[#181d22] p-8 text-white shadow-2xl"
      >
        <div className="mb-7 flex size-12 items-center justify-center rounded-2xl bg-[#f3a33a]/15 text-[#f3a33a]">
          <LockKeyhole className="size-5" />
        </div>
        <p className="text-sm font-semibold tracking-[0.18em] text-[#f3a33a]">
          ATLAS
        </p>
        <h1 className="mt-2 text-2xl font-semibold">Entrar</h1>
        <p className="mt-2 text-sm leading-6 text-slate-400">
          Acompanhe os contatos que chegam pelo seu site.
        </p>

        {error && (
          <p className="mt-5 rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-300">
            {error}
          </p>
        )}

        <input type="hidden" name="next" value={next} />
        <input type="hidden" name="portal" value="cliente" />

        <label
          className="mt-6 block text-sm font-medium text-slate-300"
          htmlFor="username"
        >
          Usuário
        </label>
        <input
          id="username"
          name="username"
          type="text"
          required
          autoFocus
          autoComplete="username"
          autoCapitalize="none"
          spellCheck={false}
          className="mt-2 w-full rounded-xl border border-white/10 bg-[#101418] px-3 py-3 text-sm transition outline-none focus:border-[#f3a33a]"
        />

        <label
          className="mt-4 block text-sm font-medium text-slate-300"
          htmlFor="password"
        >
          Senha
        </label>
        <input
          id="password"
          name="password"
          type="password"
          required
          autoComplete="current-password"
          className="mt-2 w-full rounded-xl border border-white/10 bg-[#101418] px-3 py-3 text-sm transition outline-none focus:border-[#f3a33a]"
        />

        <button
          type="submit"
          className="mt-6 w-full rounded-xl bg-[#f3a33a] px-4 py-3 text-sm font-semibold text-[#16191d] transition hover:bg-[#ffb354]"
        >
          Entrar
        </button>
      </form>
    </main>
  );
}
