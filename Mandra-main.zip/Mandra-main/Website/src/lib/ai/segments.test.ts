import assert from "node:assert/strict";
import { test } from "node:test";

import { NICHES } from "@/lib/prospector/niches";
import {
  BY_GROUP,
  DEFAULT_SEGMENT,
  SEGMENTS,
  segmentBlock,
  segmentCoverage,
  segmentFor,
} from "./segments";

/**
 * The mapping, pinned.
 *
 * The failure this guards against is silent and slow: a niche is added to
 * `niches.ts` under a new group, nothing errors, and every insight for it comes
 * back written for a builder because the default segment caught it. Nobody sees
 * that in a diff — they see it six weeks later in a call that went badly.
 */

test("every niche lands in a real segment", () => {
  for (const { niche, segment } of segmentCoverage()) {
    assert.ok(
      SEGMENTS[segment.id],
      `${niche.slug} caiu num segmento que não existe: ${segment.id}`,
    );
  }
});

test("every group in niches.ts is named in BY_GROUP", () => {
  // Checked against the table rather than against the resolved segment: one
  // group legitimately maps to the same segment as the default, so "it resolved
  // to the default" cannot distinguish a deliberate mapping from a missing one.
  // The table is the thing somebody forgets to edit, so the table is the thing
  // asserted.
  for (const group of new Set(NICHES.map((niche) => niche.group))) {
    assert.ok(
      BY_GROUP[group],
      `o grupo "${group}" não está em BY_GROUP — todo lead dele cai no segmento padrão`,
    );
  }
});

test("every segment named in the tables exists", () => {
  for (const id of Object.values(BY_GROUP)) {
    assert.ok(
      SEGMENTS[id],
      `BY_GROUP aponta para um segmento inexistente: ${id}`,
    );
  }
});

test("intent parceiro wins over the group", () => {
  // The one mistake in this file that ends a conversation in a sentence: an
  // agency pitched as a customer. It must not depend on which group they are in.
  for (const niche of NICHES.filter((n) => n.intent === "parceiro")) {
    assert.equal(segmentFor(niche).id, "parceria", niche.slug);
  }
});

test("the splits inside a group are respected", () => {
  // Same shelf in the dropdown, different sale.
  assert.equal(segmentFor("pet-shops").id, "agenda");
  assert.equal(segmentFor("veterinarios").id, "consulta");
  // Nobody asks an estate agent for three competing quotes.
  assert.equal(segmentFor("engenharia-construcao").id, "orcamento");
  assert.equal(segmentFor("imobiliarias").id, "recorrente");
});

test("a lead with no niche gets the default, not a crash", () => {
  // Most of the history: leads that arrived through a customer's own form.
  assert.equal(segmentFor(null), DEFAULT_SEGMENT);
  assert.equal(segmentFor("um-nicho-que-nao-existe"), DEFAULT_SEGMENT);
});

test("the prompt block carries the question and the prohibitions", () => {
  const block = segmentBlock(SEGMENTS.consulta);
  assert.match(block, /orçamentos que vocês passaram/);
  assert.match(block, /conselho/); // the "don't promise patient volume" rule
  assert.match(block, /paciente/);
  // The vocabulary matters as much as the pain: calling a patient a "lead" is
  // how an operator reads as a stranger in the first ten seconds.
  assert.ok(!segmentBlock(SEGMENTS.agenda).includes("paciente"));
});
