import type { LeadScope } from "@/lib/prospector/history";

/**
 * A skill: the unit every AI product in this application is built from.
 *
 * Not an agent, not a service, not a page. The three features that predate this
 * file — the WhatsApp agent, the meeting review, and the insight this was
 * written for — each independently grew the same four parts, and a skill is
 * those four parts named:
 *
 *   context()   rows in. The only place that touches the database.
 *   system()    who the model is and what it may not do.
 *   user()      the subject, rendered.
 *   validate()  refuses the answer rather than passing it on.
 *
 * The separation that matters is `context()` from the other three. Everything
 * below it is a pure function of rows already fetched, which is what makes a
 * skill testable against a fixture with no database and no network — see
 * `evals/`. A skill that reads inside `system()` cannot be evaluated, and an AI
 * feature nobody can evaluate is one that degrades without anyone noticing.
 */

/**
 * Which chain, and how much of it.
 *
 * `chain` is a choice about *what the answer is for*, not about money. "rapido"
 * is Groq-first: high volume, short outputs, a person waiting — the WhatsApp
 * reply read within seconds of being sent. "caro" is Claude-first: low volume,
 * read carefully, and where a cheap model produces exactly the generic answer a
 * client can get for free elsewhere. `analysisProviders()` already encoded this
 * preference as a function; here it is a field, so a skill declares it once.
 */
export type Budget = {
  chain: "rapido" | "caro";
  temperature?: number;
  maxTokens?: number;
  /** Ask the provider for guaranteed JSON where it supports it. Default true —
   * every skill in this codebase answers with an envelope. */
  json?: boolean;
};

/**
 * The rows a skill reasons over, plus the two labels the run log needs.
 *
 * `subject` is what an operator reading /admin/ia searches for ("lead:8123"),
 * and `accountId` is who pays. Both come from the context rather than from the
 * caller because the caller has the input, and the input is an id — resolving it
 * to an account is a read, and reads live in `context()`.
 */
export type SkillContext = {
  subject: string | null;
  accountId: string | null;
};

export type Skill<Input, Context extends SkillContext, Output> = {
  /** Dotted and stable: "insight.lead", "financas.fluxo". It is a database
   * value in `ai_runs.skill`, so renaming one orphans its history. */
  id: string;
  /** What it is for, in one line, in pt-BR. Shown in /admin/ia. */
  purpose: string;
  budget: Budget;

  /**
   * Rows in, prompt-ready context out. Takes the scope **first and never
   * optionally** — the rule from docs/plataforma.md, which matters more here
   * because a leak through an AI feature is a leak narrated in fluent
   * Portuguese. A skill cannot construct a scope; it receives one from the route,
   * which got it from the session.
   */
  context(input: Input, scope: LeadScope): Promise<Context> | Context;

  system(ctx: Context): string;
  user(ctx: Context): string;

  /**
   * The model's answer, or null if it is not usable.
   *
   * Null rather than a throw: "the envelope parsed and said nothing" is a
   * prompt problem, and `runSkill()` records it as `invalido` — a state distinct
   * from `erro` precisely so that a model quietly getting worse is visible as
   * something other than an outage.
   */
  validate(raw: Record<string, unknown>, ctx: Context): Output | null;
};

/** What `runSkill()` gives back. The ids are so a page can link to the run that
 * produced what it is showing, and so an operator can mark it bad. */
export type SkillRun<Output> = {
  output: Output;
  runId: number;
  provider: string;
  model: string;
  costBrl: number | null;
  latencyMs: number;
};
