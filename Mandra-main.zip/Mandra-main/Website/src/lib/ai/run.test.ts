import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { after, before, describe, it } from "node:test";

import type { LeadScope } from "@/lib/prospector/history";
import type { Skill, SkillContext } from "./types";

/**
 * What `runSkill()` is actually for: every run leaves a row, including the ones
 * that failed.
 *
 * The behaviour worth pinning is not that a good answer comes back — that is the
 * provider's doing — but that a refusal, a malformed envelope and a dead chain
 * each land in `ai_runs` with a state that tells them apart. A skill that fails
 * silently is indistinguishable from a skill nobody used, and the cost report is
 * only worth reading if the expensive failures are in it.
 *
 * PROSPECTOR_DB has to be set before db.ts is imported (see calls.test.ts),
 * hence the dynamic imports. The providers are steered with env vars rather than
 * mocked: `complete()` picks its chain from them, and a chain of zero providers
 * is the "everything is down" case without a network call.
 */

let run: typeof import("./run");
let aidb: typeof import("./db");
let dir: string;

const SCOPE: LeadScope = { kind: "conta", id: "acme" };

type Ctx = SkillContext & { pergunta: string };

/** A skill whose `validate()` accepts anything with a `resposta`. */
const skill: Skill<string, Ctx, { resposta: string }> = {
  id: "teste.eco",
  purpose: "Repete o que recebeu.",
  budget: { chain: "rapido" },
  context: (input) => ({
    subject: `teste:${input}`,
    accountId: "acme",
    pergunta: input,
  }),
  system: () => "Você responde JSON.",
  user: (ctx) => ctx.pergunta,
  validate: (raw) =>
    typeof raw.resposta === "string" ? { resposta: raw.resposta } : null,
};

before(async () => {
  dir = mkdtempSync(path.join(tmpdir(), "ai-run-test-"));
  process.env.PROSPECTOR_DB = path.join(dir, "prospector.db");
  delete process.env.GROQ_API_KEY;
  delete process.env.OPENROUTER_API_KEY;
  delete process.env.ANTHROPIC_API_KEY;
  delete process.env.AI_QUOTA_BRL;
  run = await import("./run");
  aidb = await import("./db");
});

after(() => rmSync(dir, { recursive: true, force: true }));

describe("runSkill", () => {
  it("records a row when no provider answers", async () => {
    await assert.rejects(
      () => run.runSkill(skill, "oi", SCOPE),
      (error: unknown) =>
        error instanceof run.SkillError && error.state === "erro",
    );

    const rows = aidb.recentRuns(10, "acme");
    assert.equal(rows.length, 1);
    assert.equal(rows[0].skill, "teste.eco");
    assert.equal(rows[0].subject, "teste:oi");
    assert.equal(rows[0].state, "erro");
    // No provider answered, so there is nothing to price. Null, not zero — a
    // report that counts an unpriced run as free understates the bill.
    assert.equal(rows[0].cost_brl, null);
    assert.match(rows[0].error ?? "", /provedor/i);
  });

  it("refuses before the call once the ceiling is reached", async () => {
    // A spent month, written directly: the ceiling is checked against what the
    // log says, which is the only thing that survives a restart.
    aidb.recordRun({
      accountId: "acme",
      skill: "teste.eco",
      subject: "teste:antigo",
      provider: "groq",
      model: "llama-3.3-70b-versatile",
      tokensIn: 1000,
      tokensOut: 1000,
      costBrl: 40,
      latencyMs: 10,
      state: "ok",
      error: null,
    });
    process.env.AI_QUOTA_BRL = "10";

    await assert.rejects(
      () => run.runSkill(skill, "oi", SCOPE),
      (error: unknown) =>
        error instanceof run.SkillError && error.state === "recusado",
    );

    const rows = aidb.recentRuns(1, "acme");
    assert.equal(rows[0].state, "recusado");
    // Refused *before* the provider call, so it cost nothing and says so.
    assert.equal(rows[0].provider, null);
    delete process.env.AI_QUOTA_BRL;
  });

  it("keeps one account's spend out of another's ceiling", () => {
    assert.ok(aidb.spentThisMonth("acme") >= 40);
    assert.equal(aidb.spentThisMonth("outra"), 0);
    // Atlas's own runs are account_id IS NULL, not a fake account row.
    assert.equal(aidb.spentThisMonth(null), 0);
  });

  it("counts failures per skill without hiding them in the totals", () => {
    const usage = aidb.usageBySkill("acme");
    const eco = usage.find((u) => u.skill === "teste.eco");
    assert.ok(eco);
    assert.equal(eco.runs, 3);
    assert.equal(eco.falhas, 2);
  });
});
