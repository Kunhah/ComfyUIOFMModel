import type { LeadScope } from "@/lib/prospector/history";
import { costOf } from "./cost";
import { recordRun, spentThisMonth } from "./db";
import { extractJson } from "./envelope";
import {
  analysisProviders,
  complete,
  LlmError,
  providers,
  type ChatMessage,
} from "./providers";
import type { Skill, SkillContext, SkillRun } from "./types";

/**
 * The only path from a skill to a provider.
 *
 * The rule this exists to enforce: **no route calls a provider directly.** The
 * moment a `complete()` appears in `src/app/api/`, the run log has a hole in it
 * and the cost report is a guess — and the hole is invisible, because the
 * feature works fine. Everything a run needs to be accounted for happens here,
 * so that adding a skill is writing four functions and nothing else.
 *
 * It never throws for a model's behaviour. A refusal, a malformed envelope and a
 * dead provider are all *outcomes*, each with a state and a row; the caller gets
 * a discriminated result and decides what the page says. It does throw if the
 * skill's own `context()` throws, because that is our bug and not the model's.
 */

export class SkillError extends Error {
  readonly state: "invalido" | "erro" | "recusado";
  readonly runId: number;

  constructor(
    state: "invalido" | "erro" | "recusado",
    message: string,
    runId: number,
  ) {
    super(message);
    this.state = state;
    this.runId = runId;
  }
}

/**
 * The monthly ceiling per account, in BRL.
 *
 * A ceiling and not a report. Over it, a skill refuses before the call and the
 * page says so — a surprise invoice from an inference provider is a
 * company-ending bug at our size, and every mechanism that only *notices* one
 * notices it after it has been paid.
 *
 * Configured per deployment rather than per account for now, because a
 * per-account override is a column on `accounts` and this is not the change that
 * should add it. Zero or unset means no ceiling, which is the honest default for
 * a deployment that has not thought about it — the ceiling that silently stops a
 * client's inbox from answering is worse than the bill it prevents.
 */
function ceiling(): number {
  const raw = Number(process.env.AI_QUOTA_BRL?.trim());
  return Number.isFinite(raw) && raw > 0 ? raw : 0;
}

export async function runSkill<Input, Context extends SkillContext, Output>(
  skill: Skill<Input, Context, Output>,
  input: Input,
  scope: LeadScope,
): Promise<SkillRun<Output>> {
  // Reads first, and outside the try: a failure here is our query, not the
  // model, and recording it as an AI run would put our bug in the report we use
  // to judge prompts.
  const ctx = await skill.context(input, scope);

  const base = {
    accountId: ctx.accountId,
    skill: skill.id,
    subject: ctx.subject,
  };

  const limit = ceiling();
  if (limit > 0) {
    const spent = spentThisMonth(ctx.accountId);
    if (spent >= limit) {
      const runId = recordRun({
        ...base,
        provider: null,
        model: null,
        tokensIn: null,
        tokensOut: null,
        costBrl: null,
        latencyMs: null,
        state: "recusado",
        error: `Teto mensal de IA atingido (R$ ${spent.toFixed(2)} de R$ ${limit.toFixed(2)}).`,
      });
      throw new SkillError(
        "recusado",
        "O limite mensal de IA desta conta foi atingido.",
        runId,
      );
    }
  }

  const messages: ChatMessage[] = [
    { role: "system", content: skill.system(ctx) },
    { role: "user", content: skill.user(ctx) },
  ];

  const chain =
    skill.budget.chain === "caro" ? analysisProviders() : providers();

  const started = Date.now();
  let answer: Awaited<ReturnType<typeof complete>>;
  try {
    answer = await complete(
      messages,
      {
        json: skill.budget.json ?? true,
        temperature: skill.budget.temperature,
        maxTokens: skill.budget.maxTokens,
      },
      chain,
    );
  } catch (error) {
    const runId = recordRun({
      ...base,
      provider: null,
      model: null,
      tokensIn: null,
      tokensOut: null,
      costBrl: null,
      latencyMs: Date.now() - started,
      state: "erro",
      error: error instanceof Error ? error.message : String(error),
    });
    throw new SkillError(
      "erro",
      error instanceof LlmError
        ? error.message
        : "Falha ao consultar o modelo.",
      runId,
    );
  }

  const latencyMs = Date.now() - started;
  const costBrl = costOf(answer.model, answer.usage);
  const spend = {
    provider: answer.provider,
    model: answer.model,
    tokensIn: answer.usage?.inputTokens ?? null,
    tokensOut: answer.usage?.outputTokens ?? null,
    costBrl,
    latencyMs,
  };

  // The two failures below are charged for. They cost real tokens, and a cost
  // report that only counted the answers we liked would understate the bill by
  // exactly the amount a broken prompt is wasting.
  const parsed = extractJson(answer.text);
  if (!parsed) {
    const runId = recordRun({
      ...base,
      ...spend,
      state: "invalido",
      error: `Resposta não é um objeto JSON: ${answer.text.slice(0, 200)}`,
    });
    throw new SkillError(
      "invalido",
      "O modelo respondeu algo que não é um objeto JSON válido.",
      runId,
    );
  }

  const output = skill.validate(parsed, ctx);
  if (output === null) {
    const runId = recordRun({
      ...base,
      ...spend,
      state: "invalido",
      error: "Envelope válido, conteúdo insuficiente.",
    });
    throw new SkillError(
      "invalido",
      "O modelo respondeu num formato que não dá para usar.",
      runId,
    );
  }

  const runId = recordRun({
    ...base,
    ...spend,
    state: "ok",
    error: null,
    output,
  });
  return {
    output,
    runId,
    provider: answer.provider,
    model: answer.model,
    costBrl,
    latencyMs,
  };
}

/**
 * One accounted completion, for callers that own their own parsing.
 *
 * The escape hatch from `runSkill()`, and a deliberately narrow one. Two
 * features predate the skill shape and should not be forced into it:
 *
 * - **The WhatsApp agent** never throws on a bad answer. `parseAgentReply()`
 *   degrades every failure to something sendable, because the alternative on a
 *   live thread is a customer left on read — the exact opposite of the refusal
 *   `runSkill()` is built to perform. It also takes a second corrective
 *   round-trip, so a turn is one to two completions and not one.
 * - **The meeting review** owns `AnalysisError` and a `validate()` that fills
 *   defaults rather than rejecting, because a thin review is still worth reading.
 *
 * What they do *not* get to opt out of is the accounting. This function is the
 * other half of the rule: a completion that does not pass through here or
 * `runSkill()` is spend nobody can attribute, and the hole it leaves in the cost
 * report is invisible because the feature keeps working.
 *
 * Unlike `runSkill()` it re-throws `LlmError` as it came — its callers already
 * handle that — and it records the run before doing so.
 */
export async function runCompletion(input: {
  skill: string;
  accountId: string | null;
  subject: string | null;
  messages: ChatMessage[];
  chain: "rapido" | "caro";
  json?: boolean;
  temperature?: number;
  maxTokens?: number;
}): Promise<{ text: string; provider: string; runId: number }> {
  const chain = input.chain === "caro" ? analysisProviders() : providers();
  const base = {
    accountId: input.accountId,
    skill: input.skill,
    subject: input.subject,
  };

  const started = Date.now();
  try {
    const answer = await complete(
      input.messages,
      {
        json: input.json ?? true,
        temperature: input.temperature,
        maxTokens: input.maxTokens,
      },
      chain,
    );
    const runId = recordRun({
      ...base,
      provider: answer.provider,
      model: answer.model,
      tokensIn: answer.usage?.inputTokens ?? null,
      tokensOut: answer.usage?.outputTokens ?? null,
      costBrl: costOf(answer.model, answer.usage),
      latencyMs: Date.now() - started,
      state: "ok",
      error: null,
    });
    return { text: answer.text, provider: answer.provider, runId };
  } catch (error) {
    recordRun({
      ...base,
      provider: null,
      model: null,
      tokensIn: null,
      tokensOut: null,
      costBrl: null,
      latencyMs: Date.now() - started,
      state: "erro",
      error: error instanceof Error ? error.message : String(error),
    });
    throw error;
  }
}

/** The account a scope pays from. `tudo` and `atlas` are both us. */
export function accountOf(scope: LeadScope): string | null {
  return scope.kind === "conta" ? scope.id : null;
}
