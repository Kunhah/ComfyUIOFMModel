/**
 * Every skill this application has, and what it is for.
 *
 * A registry of *descriptions*, not of the skill objects themselves. Two
 * reasons, and the second is the real one:
 *
 * - A `Skill<Input, Context, Output>` is generic in three parameters, and a list
 *   of them erases to `any` or to a type nothing is assignable to. Neither is
 *   worth the ceremony for a list whose only job is to be rendered.
 * - Not everything that spends money is a skill. The WhatsApp agent and the
 *   meeting review call `runCompletion()` with their own parse loops (see run.ts
 *   for why), and a registry that only knew about `Skill` objects would leave
 *   the two most expensive things we run missing from the screen that reports
 *   what we spend. The id is the join key with `ai_runs.skill`; whether the code
 *   behind it happens to be a `Skill` is an implementation detail of that id.
 *
 * The consequence to accept: this list is maintained by hand and can drift from
 * the ids the code actually writes. `unknownSkills()` is the check — anything in
 * the log that is not described here shows up as such rather than silently.
 */

export type SkillInfo = {
  id: string;
  /** pt-BR, one line. This is the column header an operator reads. */
  purpose: string;
  /** Which chain it runs on, for the cost screen. */
  chain: "rapido" | "caro";
  /** Whether it goes through `runSkill()` or owns its loop via
   * `runCompletion()`. Shown because the two fail differently: a skill can be
   * `invalido`, a raw completion cannot. */
  shape: "skill" | "proprio";
};

export const SKILLS: SkillInfo[] = [
  {
    id: "atendimento.resposta",
    purpose: "Responde uma mensagem de WhatsApp e agenda o que foi combinado.",
    chain: "rapido",
    shape: "proprio",
  },
  {
    id: "atendimento.correcao",
    purpose:
      "Segunda tentativa quando a ação do turno anterior foi recusada. Não é um turno novo.",
    chain: "rapido",
    shape: "proprio",
  },
  {
    id: "insight.lead",
    purpose:
      "Antes de discar: o ângulo, o encaixe e a frase de abertura para um lead.",
    chain: "rapido",
    shape: "skill",
  },
  {
    id: "insight.fila",
    purpose: "Ordena uma lista de leads por quem vale ligar primeiro hoje.",
    chain: "rapido",
    shape: "skill",
  },
  {
    id: "insight.objecao",
    purpose:
      "As objeções que costumam aparecer neste nicho, e o que funcionou contra elas.",
    chain: "caro",
    shape: "skill",
  },
  {
    id: "reuniao.analise",
    purpose: "Lê a transcrição da reunião e diz o que derrubou a venda.",
    chain: "caro",
    shape: "proprio",
  },
];

const BY_ID = new Map(SKILLS.map((s) => [s.id, s]));

export function describeSkill(id: string): SkillInfo | null {
  return BY_ID.get(id) ?? null;
}

/** Ids present in the run log that nobody described. The drift check. */
export function unknownSkills(logged: string[]): string[] {
  return [...new Set(logged.filter((id) => !BY_ID.has(id)))];
}
