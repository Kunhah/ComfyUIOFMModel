import assert from "node:assert/strict";
import { test } from "node:test";

import { Facts } from "../facts";
import { SEGMENTS } from "../segments";
import { insightLead } from "./insight-lead";

/**
 * That the segment reaches the prompt at all.
 *
 * `segments.ts` can be perfect and still change nothing: the mapping is only
 * worth having if the words come out the other end. This is the assertion that
 * a refactor of the prompt cannot quietly drop it — which is easy to do, because
 * nothing breaks when it happens. The insight just goes back to reading like it
 * was written for a builder.
 */

const ctx = (segment = SEGMENTS.consulta) => ({
  subject: "lead:1",
  accountId: null,
  segment,
  facts: new Facts().add("site", "Não encontramos site próprio."),
  lead: {
    name: "Clínica Sorriso",
    place: "Blumenau/SC",
    nicheLabel: "Odontologia",
    category: null,
  },
});

test("the system prompt carries this segment's pain and question", () => {
  const prompt = insightLead.system(ctx());
  assert.match(prompt, /orçamentos que vocês passaram/);
  assert.match(prompt, /paciente/);
  // And the script it has to stay inside.
  assert.match(prompt, /permission opener/);
});

test("a different segment produces a different prompt", () => {
  // The check that the block is interpolated rather than hard-coded — a
  // constant that happens to mention clinics would pass the test above.
  const clinic = insightLead.system(ctx(SEGMENTS.consulta));
  const salon = insightLead.system(ctx(SEGMENTS.agenda));
  assert.notEqual(clinic, salon);
  assert.match(salon, /chega mensagem/);
  assert.ok(!salon.includes("orçamentos que vocês passaram"));
});

test("the user prompt names the segment and the facts", () => {
  const prompt = insightLead.user(ctx());
  assert.match(prompt, /Clínica Sorriso/);
  assert.match(prompt, /Primeira consulta e orçamento parado/);
  assert.match(prompt, /\[site\]/);
});

test("the facts block never claims a field we did not find", () => {
  // `addAbsence` words a missing column as a search that came up empty, because
  // "website: não informado" is a fact about our database that a model turns
  // into "eles não têm site" about the business.
  const facts = new Facts().addAbsence("site", "site próprio");
  assert.match(facts.render(), /Não encontramos site próprio/);
});
