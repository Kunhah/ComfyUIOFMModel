/**
 * The call script, reduced to the rules a prompt can be held to.
 *
 * The source is `roteiro-ligacao.md` at the repository root — 800 lines, written
 * for a person, and the authority whenever the two disagree. This is not a copy
 * of it and must not become one. Three reasons it is a separate, smaller thing:
 *
 * - **It is outside the Next app.** The file lives above `Website/`, so the
 *   standalone build does not trace it and a container would read it at runtime
 *   from a path that is not there. A skill that works locally and fails in
 *   production is the worst of the available failures.
 * - **The prompt needs constraints, not prose.** What stops a model writing a
 *   bad opener is "termine em pergunta, nunca ofereça preço", not four pages of
 *   worked dialogue it will paraphrase.
 * - **The script changes when selling changes.** Sales edits the markdown; this
 *   is edited deliberately, in a diff someone reviews, because it is what the
 *   model is allowed to say to a stranger on our behalf.
 *
 * When the two drift, the markdown wins and this file is wrong. Say so in the
 * review rather than quietly widening what the model may do.
 */

/** The opener's fixed shape, and what may never move inside it. */
export const ABERTURA = `A abertura é um permission opener e tem uma ordem fixa:
confirmar que é a empresa, admitir na cara que é ligação comercial ("vou ser
sincero"), devolver o controle ("você quer desligar agora ou me dá 30
segundos?"), e parar de falar. O silêncio depois da pergunta é a parte que
funciona.

O motivo da ligação tem que caber em "liguei porque reparei que ...", com algo
verdadeiro e específico daquele negócio. Se não couber, a ligação não acontece —
é por isso que o ângulo abaixo precisa vir de um fato, e não de uma suposição
simpática.`;

/** What the 30 seconds are for, and how they end. */
export const TRINTA_SEGUNDOS = `Os 30 segundos seguintes falam de aproveitar
melhor os contatos que a empresa JÁ recebe — não de trazer mais gente. Terminam
SEMPRE numa pergunta sobre a operação atual, porque é isso que transforma
apresentação em conversa. Qualquer resposta serve: quem responde os contatos, em
quanto tempo, e o que acontece quando ninguém responde.`;

/** The single goal, stated because every failure mode is a different goal. */
export const META = `A meta da ligação é agendar uma reunião de 20 minutos. Não
é vender, não é explicar a solução, não é mandar orçamento. Uma ligação que
termina em "me manda por WhatsApp" é uma ligação perdida, mesmo que tenha sido
simpática.`;

/** The rules that bound anything the model writes for an operator to say. */
export const REGRAS = `- Quem fala mais perde. Na abertura são 30 segundos
  cronometrados.
- Nunca invente preço, prazo, desconto ou condição. Se perguntarem, a resposta é
  a faixa e uma pergunta de volta — nunca um número fechado.
- Objeção: reconheça, não discuta, devolva pergunta. Uma tentativa por objeção.
- Nunca prometa resultado ("vai dobrar seu faturamento"), nunca cite um número
  que não esteja nos fatos, e nunca afirme algo sobre o negócio que a gente não
  tenha observado.
- Português do Brasil falado, tratamento por "você". Frase curta. Nada de
  "prezado", nada de jargão de marketing, nada de markdown — alguém vai ler isso
  em voz alta.`;

/** The whole block, for a prompt that wants all of it. */
export function roteiroBlock(): string {
  return [
    "## O roteiro (resumo operacional)",
    META,
    "",
    "### Abertura",
    ABERTURA,
    "",
    "### Os 30 segundos",
    TRINTA_SEGUNDOS,
    "",
    "### Regras que não se quebram",
    REGRAS,
  ].join("\n");
}
