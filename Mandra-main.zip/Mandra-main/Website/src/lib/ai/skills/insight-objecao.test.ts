import assert from "node:assert/strict";
import { test } from "node:test";

import { SEGMENTS } from "../segments";
import {
  insightObjecao,
  objecaoSimilar,
  objecaoSubject,
} from "./insight-objecao";

/**
 * The objection brief's segment awareness and its cache key.
 *
 * Written after the segment block silently failed to interpolate here — the
 * skill kept working, the prompt was simply generic again, and nothing in the
 * suite or the build noticed. A prompt that loses its context does not throw; it
 * just gets worse quietly, which is the whole reason these assertions exist.
 */

const ctx = (segment = SEGMENTS.agenda) => ({
  subject: objecaoSubject("saloes-beleza"),
  accountId: null,
  segment,
  samples: [
    {
      objecao: "Já temos site",
      resposta: "Ok",
      avaliacao: "ruim" as const,
      melhor: "",
    },
  ],
  reviewCount: 4,
  corpus: "segmento" as const,
});

test("the segment reaches the prompt", () => {
  const prompt = insightObjecao.system(ctx());
  assert.match(prompt, /chega mensagem/);
  assert.notEqual(
    insightObjecao.system(ctx(SEGMENTS.consulta)),
    insightObjecao.system(ctx(SEGMENTS.agenda)),
  );
});

test("the prompt says which corpus it got", () => {
  // A brief built from every segment's meetings must not be presented as being
  // about this kind of business — the model is told to hedge instead.
  const geral = insightObjecao.user({ ...ctx(), corpus: "geral" });
  assert.match(geral, /não invente especificidade/);
  assert.ok(!insightObjecao.user(ctx()).includes("não invente especificidade"));
});

test("niches that sell the same way share one cache key", () => {
  // The whole cost design: one paid run of the expensive chain per segment, not
  // per niche. If these diverge, every salon pays for its own copy.
  assert.equal(objecaoSubject("saloes-beleza"), objecaoSubject("barbearias"));
  assert.notEqual(
    objecaoSubject("saloes-beleza"),
    objecaoSubject("odontologia"),
  );
  assert.equal(objecaoSubject(null), objecaoSubject("um-nicho-inexistente"));
});

test("the same complaint in different words is counted once", () => {
  assert.ok(objecaoSimilar("Já temos site", "A gente já tem um site próprio"));
  assert.ok(!objecaoSimilar("Já temos site", "Não sou eu quem decide"));
});
