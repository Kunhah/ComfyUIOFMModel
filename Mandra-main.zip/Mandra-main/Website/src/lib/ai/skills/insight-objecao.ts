import { getDb } from "@/lib/prospector/db";
import { NICHES } from "@/lib/prospector/niches";
import { reviewDb } from "@/lib/review/db";
import type { Analysis } from "@/lib/review/analyse";
import type { LeadScope } from "@/lib/prospector/history";
import { list, obj, oneOf, str } from "../envelope";
import { segmentBlock, segmentFor, type Segment } from "../segments";
import type { Skill, SkillContext } from "../types";
import { REGRAS } from "./roteiro";

/**
 * Which objection this call is about to meet, from the calls we already lost.
 *
 * The meeting reviews are the only corpus in this company that records what a
 * prospect actually said and whether the answer worked — `objecoes[]` carries
 * the objection, the seller's reply, and a grade on it. That is training data
 * nobody reads, because it is buried one review at a time behind a recording.
 *
 * This skill reads across them for one **segment** and answers the question an
 * operator has before dialling: what is going to come up, and what has worked.
 *
 * Segment, not niche, and that is the whole cost design. "Já temos site" is the
 * same objection in a barbershop and in a nail studio, and generating it twice
 * would pay the expensive chain twice for one answer. Keying on the segment also
 * means the corpus is big enough to be a pattern rather than three anecdotes,
 * which is what the per-niche version kept falling back out of.
 *
 * **Only reviews we own feed it.** The corpus is our own sales calls; a client
 * account has no meeting reviews, and pointing this skill at a scoped session
 * would either return nothing or return ours. It refuses instead — see
 * `context()` — because an empty answer that looks like an answer is worse than
 * a feature that says it does not apply here.
 */

export type ObjectionBrief = {
  provaveis: {
    objecao: string;
    frequencia: "comum" | "ocasional" | "rara";
    /** What has actually worked, from the graded replies. */
    resposta: string;
    /** How many reviews this came from. Filled by us, not by the model. */
    vistoEm: number;
  }[];
  /** The one thing to do differently on this call. */
  atencao: string;
};

type Sample = {
  objecao: string;
  resposta: string;
  avaliacao: "boa" | "razoavel" | "ruim";
  melhor: string;
};

type Ctx = SkillContext & {
  segment: Segment;
  samples: Sample[];
  reviewCount: number;
  /** Whether the reviews read were this segment's, or every review we have. */
  corpus: "segmento" | "geral";
};

/** Reviews to read. Beyond this the prompt is long and the answer is not better;
 * the objections repeat by the twentieth call, which is the point. */
const MAX_REVIEWS = 40;

function buildContext(input: { niche: string | null }, scope: LeadScope): Ctx {
  // Ours only, and said out loud rather than filtered to nothing.
  if (scope.kind === "conta") {
    throw new Error(
      "As objeções vêm das reuniões da Atlas; não há corpus para uma conta de cliente.",
    );
  }

  const segment = segmentFor(input.niche);

  // Every niche that sells the same way. A salon's objections are a barbershop's
  // objections, and pooling them is what turns three anecdotes into a pattern.
  const slugs = NICHES.filter(
    (niche) => segmentFor(niche).id === segment.id,
  ).map((niche) => niche.slug);

  // The reviews live in their own database file. Narrowing by niche means
  // joining to `leads`, which is in another file — so the lead ids are read
  // first and passed in. Two queries rather than a cross-database join, which
  // SQLite can do and nobody can back up correctly.
  const leadIds =
    slugs.length > 0
      ? (
          getDb()
            .prepare(
              `SELECT id FROM leads
                WHERE niche IN (${slugs.map(() => "?").join(",")})
                  AND account_id IS NULL`,
            )
            .all(...slugs) as { id: string }[]
        ).map((row) => row.id)
      : [];

  let corpus: "segmento" | "geral" = "geral";
  const rows = (() => {
    const db = reviewDb();
    if (leadIds.length > 0) {
      const holes = leadIds.map(() => "?").join(",");
      const scoped = db
        .prepare(
          `SELECT analysis FROM meeting_reviews
            WHERE status = 'pronto' AND analysis IS NOT NULL
              AND lead_id IN (${holes})
            ORDER BY created_at DESC LIMIT ?`,
        )
        .all(...leadIds, MAX_REVIEWS) as { analysis: string }[];
      if (scoped.length >= 3) {
        corpus = "segmento";
        return scoped;
      }
    }
    // Fewer than three reviews in this segment is not a pattern, it is three
    // anecdotes. Falling back to every review is the honest degradation — and
    // the prompt is told which corpus it got, so the answer can be hedged rather
    // than presented as being about this kind of business.
    return db
      .prepare(
        `SELECT analysis FROM meeting_reviews
          WHERE status = 'pronto' AND analysis IS NOT NULL
          ORDER BY created_at DESC LIMIT ?`,
      )
      .all(MAX_REVIEWS) as { analysis: string }[];
  })();

  const samples: Sample[] = [];
  for (const row of rows) {
    let analysis: Analysis;
    try {
      analysis = JSON.parse(row.analysis) as Analysis;
    } catch {
      continue;
    }
    for (const objection of analysis.objecoes ?? []) {
      if (!objection?.objecao) continue;
      samples.push({
        objecao: objection.objecao,
        resposta: objection.resposta_do_vendedor ?? "",
        avaliacao: objection.avaliacao ?? "razoavel",
        melhor: objection.melhor_resposta ?? "",
      });
    }
  }

  if (samples.length === 0) {
    throw new Error(
      "Nenhuma reunião analisada ainda — não há objeções para ler.",
    );
  }

  return {
    // Keyed on the segment, so every niche that sells the same way shares one
    // cached answer instead of paying for its own copy of it.
    subject: objecaoSubject(input.niche),
    accountId: null,
    segment,
    samples,
    reviewCount: rows.length,
    corpus,
  };
}

export const insightObjecao: Skill<
  { niche: string | null },
  Ctx,
  ObjectionBrief
> = {
  id: "insight.objecao",
  purpose:
    "As objeções que costumam aparecer neste nicho, e o que funcionou contra elas.",
  // The expensive chain: this reads dozens of graded exchanges and has to notice
  // what repeats across them. A cheap model returns advice true of every sales
  // call ever made, which is the failure the meeting review was built to avoid.
  budget: { chain: "caro", temperature: 0.3, maxTokens: 2500 },

  context: (input, scope) => buildContext(input, scope),

  system: (
    ctx,
  ) => `Você lê objeções reais registradas em reuniões de venda da Atlas
Digital e diz ao vendedor o que esperar na próxima conversa.

${segmentBlock(ctx.segment)}

Cada objeção vem com a resposta que o vendedor deu na hora e uma avaliação dessa
resposta: boa, razoável ou ruim. A avaliação é o sinal mais importante da lista —
uma resposta marcada como ruim é um caminho a NÃO repetir, mesmo que soe bem.

Agrupe objeções que são a mesma coisa dita com outras palavras. Prefira o que
repete: uma objeção que apareceu uma vez é anedota.

${REGRAS}`,

  user: (ctx) => `Segmento: ${ctx.segment.label}
Baseado em ${ctx.reviewCount} reunião(ões) analisada(s)${
    ctx.corpus === "segmento"
      ? " deste segmento"
      : " de todos os segmentos — não temos reuniões suficientes deste, então diga o que for geral e não invente especificidade"
  }.

## Objeções registradas
${ctx.samples
  .map(
    (sample, index) =>
      `${index + 1}. "${sample.objecao}"\n   resposta dada (${sample.avaliacao}): ${sample.resposta || "—"}${sample.melhor ? `\n   melhor resposta sugerida na época: ${sample.melhor}` : ""}`,
  )
  .join("\n")}

## Responda com este JSON, e nada fora dele
{
  "provaveis": [{"objecao": "como o cliente diz", "frequencia": "comum|ocasional|rara", "resposta": "o que responder, falado"}],
  "atencao": "a única coisa a fazer diferente nesta ligação"
}

No máximo cinco objeções, da mais provável para a menos. "resposta" é o que o
vendedor fala, não uma explicação sobre o que fazer.`,

  validate: (raw, ctx) => {
    const provaveis = list(raw.provaveis)
      .map((entry) => {
        const item = obj(entry);
        const objecao = str(item.objecao);
        return {
          objecao,
          frequencia: oneOf(
            item.frequencia,
            ["comum", "ocasional", "rara"] as const,
            "ocasional",
          ),
          resposta: str(item.resposta),
          // Counted here, never taken from the model. A frequency it invented
          // would be a number on a page that nobody can check, which is the one
          // thing this whole layer exists to prevent.
          vistoEm: ctx.samples.filter((sample) =>
            similar(sample.objecao, objecao),
          ).length,
        };
      })
      .filter((item) => item.objecao && item.resposta)
      .slice(0, 5);

    if (provaveis.length === 0) return null;
    return { provaveis, atencao: str(raw.atencao) };
  },
};

/**
 * Whether two objections are the same complaint.
 *
 * Word overlap, not embeddings. "já temos site" and "a gente já tem um site"
 * share enough to match, and that is the whole requirement — this number is a
 * "seen in N reviews" badge, not a clustering algorithm. Anything cleverer would
 * be a dependency and a second thing to be wrong.
 */
function similar(a: string, b: string): boolean {
  const words = (value: string) =>
    new Set(
      value
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .split(/[^a-z0-9]+/)
        .filter((word) => word.length > 3),
    );
  const left = words(a);
  const right = words(b);
  if (left.size === 0 || right.size === 0) return false;
  let shared = 0;
  for (const word of left) if (right.has(word)) shared += 1;
  return shared / Math.min(left.size, right.size) >= 0.5;
}

/**
 * The cache key for a niche's objection brief.
 *
 * Exported because the route reads the cache before `context()` ever runs, and
 * the two must agree on the key or every GET misses and every visit pays for the
 * expensive chain again.
 */
export function objecaoSubject(niche: string | null): string {
  return `objecoes:${segmentFor(niche).id}`;
}

export { buildContext as insightObjecaoContext, similar as objecaoSimilar };
export type { Ctx as InsightObjecaoContext };
