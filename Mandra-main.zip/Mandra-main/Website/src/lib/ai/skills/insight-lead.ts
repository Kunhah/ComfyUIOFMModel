import { getDb } from "@/lib/prospector/db";
import { findNiche } from "@/lib/prospector/niches";
import { phoneQuality } from "@/lib/prospector/phone-quality";
import { scoreLead } from "@/lib/prospector/score";
import {
  toStored,
  type LeadRow,
  type LeadScope,
} from "@/lib/prospector/history";
import { list, num, obj, str } from "../envelope";
import { Facts } from "../facts";
import { segmentBlock, segmentFor, type Segment } from "../segments";
import type { Skill, SkillContext } from "../types";
import { roteiroBlock } from "./roteiro";

/**
 * What to say to this business, and why — read thirty seconds before dialling.
 *
 * The prospector already answers "does this business need a website?" with a
 * score and pt-BR reasons, and `roteiro-ligacao.md` §0 says the operator needs
 * three things on screen before dialling: the reason for the score, the name
 * said correctly, and *one real observation*. The first two are rows. The third
 * is the thirty seconds of Googling that nobody does under pressure, and it is
 * the difference between a specific call and robodialling.
 *
 * So this skill produces exactly that third thing, and is deliberately small:
 * an angle, a fit score with its reason, an opener, two questions, and what not
 * to say. It does not write a script — the script exists — and it does not
 * decide whether to call.
 *
 * **The observation/hypothesis split is the whole design.** `observado` entries
 * must cite a fact id we handed the model, and `validate()` drops the ones that
 * do not; `hipotese` entries carry no citation and the page renders them as
 * guesses. Collapsing the two into one list of confident sentences is how this
 * feature would produce "eles perdem 30% dos leads" — a fabrication with a
 * number on it, delivered to a stranger, in our name.
 */

export type Insight = {
  /** The angle, in one sentence an operator can hold in their head. */
  angulo: string;
  /** Grounded observations. Each carries the id of the fact it came from. */
  observado: { texto: string; fonte: string }[];
  /** Guesses. Worth having, never stated as fact. */
  hipotese: string[];
  /** 0–100 fit with what we sell, and the reason for the number. */
  encaixe: { nota: number; porque: string };
  /** The "liguei porque reparei que ..." line, complete. */
  abertura: string;
  /** Two or three questions about their operation, from the script's shape. */
  perguntas: string[];
  /** What would burn this call. */
  evitar: string[];
};

type Ctx = SkillContext & {
  facts: Facts;
  /**
   * What kind of sale this is, from the niche. The niche itself still reaches
   * the model as a fact so it can be specific about the trade; this is what
   * tells it whether the conversation is about a phone buzzing mid-haircut or
   * about being the third company to answer a quote.
   */
  segment: Segment;
  lead: {
    name: string;
    place: string;
    nicheLabel: string;
    category: string | null;
  };
};

/**
 * The lead, its score reasons, its contact history, and whatever the B2B crawl
 * found — as facts, each with an id the model has to cite.
 *
 * Reads only through the scope. A `cliente` session must never be able to ask
 * for an insight about one of our own prospects, and the check is the query
 * rather than the page: `account_id IS NULL` rows are invisible to a scoped
 * caller, which is the rule from docs/plataforma.md and not a new one.
 */
function buildContext(leadId: string, scope: LeadScope): Ctx {
  const clauses: string[] = ["id = ?"];
  const params: (string | number)[] = [leadId];
  if (scope.kind === "atlas") clauses.push("account_id IS NULL");
  else if (scope.kind === "conta") {
    clauses.push("account_id = ?");
    params.push(scope.id);
  }

  const row = getDb()
    .prepare(`SELECT * FROM leads WHERE ${clauses.join(" AND ")}`)
    .get(...params) as LeadRow | undefined;

  // A lead outside the scope is indistinguishable from one that does not exist,
  // which is the point: 403 confirms the row is there.
  if (!row) throw new Error("Lead não encontrado.");

  const stored = toStored(row);
  const scored = scoreLead(stored);
  const niche = row.niche ? findNiche(row.niche) : undefined;
  const nicheLabel = niche?.label ?? row.category ?? "negócio local";
  const place = [row.city, row.uf].filter(Boolean).join("/") || "—";

  const facts = new Facts();
  facts.add("nome", `A empresa se chama ${row.name}.`);
  facts.add("ramo", `É do ramo: ${nicheLabel}.`);
  facts.add("local", `Fica em ${place}.`);
  facts.add("endereco", row.address ? `Endereço: ${row.address}.` : null);

  // The score's own reasons, verbatim. They are already worded to explain
  // themselves in a table a client could read (see score.ts), which makes them
  // exactly the right sentences to hand a model as claims.
  facts.addIf(
    scored.reasons.length > 0,
    "score",
    `A ficha do prospector marca ${scored.score}/100 pelos motivos: ${scored.reasons.join(", ")}.`,
  );

  if (row.website) facts.add("site", `Tem site: ${row.website}.`);
  else facts.addAbsence("site", "site próprio");

  const socials = [row.social, row.provider_socials]
    .filter(Boolean)
    .join(", ")
    .trim();
  if (socials) facts.add("redes", `Perfis encontrados: ${socials}.`);

  if (row.phone) {
    // The dialer's own warning, not a second opinion: a shared switchboard or a
    // number already marked dead changes the opener, and phone-quality.ts is the
    // one place that decides what "bom" means.
    const warning = phoneQuality(leadId)?.warning ?? null;
    facts.add(
      "tel",
      warning
        ? `Telefone ${row.phone}, com ressalva: ${warning}.`
        : `Telefone ${row.phone}.`,
    );
  } else {
    facts.addAbsence("tel", "telefone");
  }

  facts.add("email", row.email ? `E-mail: ${row.email}.` : null);
  facts.add(
    "contato",
    row.contact_name
      ? `Pessoa de contato conhecida: ${row.contact_name}.`
      : null,
  );
  facts.add("notas", row.notes ? `Anotações do time: ${row.notes}` : null);

  // Contact history matters more than anything else on the list: an opener that
  // treats a third call as a first one is the failure a prospect always notices.
  const calls = getDb()
    .prepare(
      `SELECT outcome, next_step, notes, called_at
         FROM lead_calls WHERE lead_id = ? ORDER BY called_at DESC LIMIT 5`,
    )
    .all(leadId) as {
    outcome: string;
    next_step: string | null;
    notes: string | null;
    called_at: string;
  }[];

  if (calls.length > 0) {
    const lines = calls
      .map(
        (call) =>
          `${call.called_at.slice(0, 10)} — ${call.outcome}${call.notes ? `: ${call.notes}` : ""}`,
      )
      .join(" | ");
    facts.add(
      "ligacoes",
      `Já ligamos ${calls.length === 5 ? "pelo menos 5 vezes" : `${calls.length} vez(es)`}. Últimas: ${lines}.`,
    );
  } else if (row.contacted_at) {
    facts.add(
      "contatado",
      `Já houve contato em ${row.contacted_at.slice(0, 10)}, sem ligação registrada — provavelmente mensagem.`,
    );
  } else {
    facts.add(
      "primeiro",
      "Primeira abordagem: nunca falamos com esta empresa.",
    );
  }

  facts.add(
    "funil",
    row.funnel_stage !== "descoberta"
      ? `No funil está em: ${row.funnel_stage}.`
      : null,
  );

  return {
    segment: segmentFor(row.niche),
    subject: `lead:${leadId}`,
    // Insight about a prospect we found is our own work. A scoped caller's
    // insight belongs to that account and is billed to it.
    accountId: scope.kind === "conta" ? scope.id : null,
    facts,
    lead: { name: row.name, place, nicheLabel, category: row.category },
  };
}

export const insightLead: Skill<string, Ctx, Insight> = {
  id: "insight.lead",
  purpose:
    "Antes de discar: o ângulo, o encaixe e a frase de abertura para um lead.",
  // The fast chain. This is read in the seconds before a call, one lead at a
  // time, and an insight that arrives after the operator has dialled is not an
  // insight. The output is short enough that the cheap models do it well.
  budget: { chain: "rapido", temperature: 0.5, maxTokens: 1200 },

  context: (leadId, scope) => buildContext(leadId, scope),

  system: (ctx) => `Você prepara ligações comerciais para a Atlas Digital, que
vende site, presença no Google e automação de atendimento para negócios locais.
Quem vai ler o que você escrever é um operador com o telefone na mão, trinta
segundos antes de discar.

${roteiroBlock()}

${segmentBlock(ctx.segment)}

## A regra mais importante
Você recebe uma lista de FATOS numerados. Tudo que você afirmar como certo tem
que sair de um desses fatos e citar o id dele. O que você achar que é provável,
mas não está nos fatos, vai em "hipotese" e não vira frase de abertura.

Não existe fato fora da lista. Você não sabe o faturamento, não sabe quantos
funcionários tem, não sabe quantos leads eles perdem, e inventar qualquer um
desses números queima o lead na primeira frase.`,

  user: (ctx) => `Empresa: ${ctx.lead.name}
Ramo: ${ctx.lead.nicheLabel}
Segmento: ${ctx.segment.label}
Onde: ${ctx.lead.place}

## Fatos
${ctx.facts.render()}

## Responda com este JSON, e nada fora dele
{
  "angulo": "uma frase: por onde entrar nesta empresa e por quê",
  "observado": [{"texto": "o que dá para afirmar", "fonte": "id do fato"}],
  "hipotese": ["o que é provável mas não está nos fatos"],
  "encaixe": {"nota": 0, "porque": "por que esta nota"},
  "abertura": "a frase completa que começa com 'liguei porque reparei que ...'",
  "perguntas": ["pergunta sobre a operação atual"],
  "evitar": ["o que não dizer nesta ligação"]
}

"encaixe" é de 0 a 100: o quanto esta empresa parece precisar do que vendemos e
conseguir pagar. Uma empresa sem site, com telefone bom e movimento é encaixe
alto; uma sem telefone, ou que já tem site e operação redonda, é baixo.

"abertura" é uma frase só, falada, que cabe nos primeiros dez segundos e sai de
um fato observado. Se nenhum fato sustenta uma abertura específica, diga isso na
frase em vez de inventar.

"perguntas" saem da pergunta de diagnóstico do segmento, adaptadas a esta
empresa — não repita a pergunta genérica palavra por palavra se um fato permite
deixá-la específica.`,

  validate: (raw, ctx) => {
    const known = ctx.facts.ids;

    // Observations are filtered against the fact list, not trusted. An entry
    // citing a fact we never sent is a hallucination wearing a citation, and it
    // is dropped here rather than rendered next to the real ones.
    const observado = list(raw.observado)
      .map((entry) => {
        const item = obj(entry);
        return { texto: str(item.texto), fonte: str(item.fonte) };
      })
      .filter((item) => item.texto && known.has(item.fonte));

    const angulo = str(raw.angulo);
    const abertura = str(raw.abertura);

    // The two fields the operator actually reads. An envelope that parsed but
    // carries neither is `invalido` — a run that cost tokens and said nothing
    // should look different in the log from one that worked.
    if (!angulo && !abertura) return null;

    const encaixe = obj(raw.encaixe);

    return {
      angulo,
      observado,
      hipotese: list(raw.hipotese)
        .map((entry) => str(entry))
        .filter(Boolean)
        .slice(0, 4),
      encaixe: {
        nota: Math.round(Math.min(100, Math.max(0, num(encaixe.nota)))),
        porque: str(encaixe.porque),
      },
      abertura,
      perguntas: list(raw.perguntas)
        .map((entry) => str(entry))
        .filter(Boolean)
        .slice(0, 3),
      evitar: list(raw.evitar)
        .map((entry) => str(entry))
        .filter(Boolean)
        .slice(0, 3),
    };
  },
};

/** Exported for the eval harness, which needs a context without a database. */
export { buildContext as insightLeadContext };
export type { Ctx as InsightLeadContext };
