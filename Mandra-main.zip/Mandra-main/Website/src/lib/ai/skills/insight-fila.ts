import { getDb } from "@/lib/prospector/db";
import { findNiche } from "@/lib/prospector/niches";
import { GOOD_PHONE_SQL } from "@/lib/prospector/phone-quality";
import type { LeadScope } from "@/lib/prospector/history";
import { list, obj, str } from "../envelope";
import { segmentFor } from "../segments";
import type { Skill, SkillContext } from "../types";

/**
 * Which of these to call first, and why — the queue an operator opens in the
 * morning.
 *
 * The prospector's `score` already orders leads by whether they look like they
 * need a website. What it cannot do is read the rest of the row: a 90 with a
 * switchboard number shared by forty businesses is worse than a 70 with a
 * mobile, and a lead somebody already called twice without reaching anyone is
 * worse than both. Those are three columns and a judgement, which is exactly the
 * shape a model is good at and a SQL ORDER BY is not.
 *
 * **It ranks, it does not filter.** Every lead handed in comes back out with a
 * position, and the operator can still call number twenty. A skill that silently
 * dropped leads would be deciding, on its own, that a business never gets
 * contacted — and it would be doing it invisibly, because nobody counts what is
 * missing from a list.
 */

export type QueueRank = {
  /** Every lead handed in, ordered. Ids are checked against what we sent. */
  ordem: { leadId: string; porque: string }[];
  /** One line on what this batch looks like as a whole. */
  leitura: string;
};

type Row = {
  id: string;
  name: string;
  city: string | null;
  uf: string | null;
  niche: string | null;
  score: number | null;
  website: string | null;
  phone: string | null;
  funnel_stage: string;
  contacted_at: string | null;
  calls: number;
  unanswered: number;
  good_phone: number;
};

type Ctx = SkillContext & { rows: Row[]; ids: Set<string> };

/** No more than this in one run: the prompt has to hold them all, and a ranking
 * of two hundred is not something an operator reads anyway. */
const MAX = 40;

function buildContext(leadIds: string[], scope: LeadScope): Ctx {
  const unique = [...new Set(leadIds)].slice(0, MAX);
  if (unique.length === 0) throw new Error("Nenhum lead para ordenar.");

  const holes = unique.map(() => "?").join(",");
  const scopeClause =
    scope.kind === "atlas"
      ? "AND account_id IS NULL"
      : scope.kind === "conta"
        ? "AND account_id = ?"
        : "";
  const params: (string | number)[] = [...unique];
  if (scope.kind === "conta") params.push(scope.id);

  const rows = getDb()
    .prepare(
      `SELECT id, name, city, uf, niche, score, website, phone, funnel_stage,
              contacted_at,
              (SELECT COUNT(*) FROM lead_calls c WHERE c.lead_id = leads.id) AS calls,
              (SELECT COUNT(*) FROM lead_calls c
                WHERE c.lead_id = leads.id AND c.outcome = 'nao_atendeu') AS unanswered,
              CASE WHEN ${GOOD_PHONE_SQL} THEN 1 ELSE 0 END AS good_phone
         FROM leads
        WHERE id IN (${holes}) ${scopeClause}`,
    )
    .all(...params) as Row[];

  if (rows.length === 0) throw new Error("Nenhum lead encontrado no escopo.");

  return {
    subject: `fila:${rows.length}`,
    accountId: scope.kind === "conta" ? scope.id : null,
    rows,
    ids: new Set(rows.map((row) => row.id)),
  };
}

const line = (row: Row): string => {
  const parts = [
    `[${row.id}] ${row.name}`,
    [row.city, row.uf].filter(Boolean).join("/"),
    row.niche ? (findNiche(row.niche)?.label ?? row.niche) : null,
    // The segment, because a mixed batch is the normal case and the two do not
    // compete on the same terms: a restaurant with no site is a Google problem,
    // a builder with no site is losing a quote race today.
    segmentFor(row.niche).label,
    `score ${row.score ?? 0}`,
    row.website ? "tem site" : "sem site",
    row.good_phone ? "telefone bom" : "telefone ruim ou ausente",
    row.calls > 0
      ? `${row.calls} ligação(ões), ${row.unanswered} sem atender`
      : "nunca ligamos",
    row.contacted_at ? `contatado em ${row.contacted_at.slice(0, 10)}` : null,
    row.funnel_stage !== "descoberta" ? `funil: ${row.funnel_stage}` : null,
  ];
  return parts.filter(Boolean).join(" · ");
};

export const insightFila: Skill<string[], Ctx, QueueRank> = {
  id: "insight.fila",
  purpose: "Ordena uma lista de leads por quem vale ligar primeiro hoje.",
  budget: { chain: "rapido", temperature: 0.3, maxTokens: 2000 },

  context: (leadIds, scope) => buildContext(leadIds, scope),

  system: () => `Você organiza a fila de ligações de uma equipe comercial que
vende site, presença no Google e automação de atendimento para negócios locais.

Recebe uma lista de leads com o que sabemos de cada um e devolve a mesma lista
ordenada por quem vale ligar primeiro HOJE.

O que sobe na fila:
- telefone bom (uma linha que provavelmente chega naquele negócio)
- sinal claro de que falta o que vendemos: sem site, só redes sociais
- nunca contatado, ou contatado há muito tempo sem retorno

O que desce:
- telefone ruim, ausente, ou várias tentativas sem ninguém atender
- já está adiantado no funil (é acompanhamento, não prospecção fria)
- score alto sem nenhuma forma de chegar na empresa

Cada lead traz o segmento a que pertence. Um mesmo sinal não vale o mesmo em
todos: "sem site" numa empresa que vive de orçamento é urgente (o concorrente
responde primeiro hoje), e numa que vive de movimento de rua é menos. Leve isso
em conta em vez de ordenar só por score.

Não invente informação sobre nenhuma empresa. Você só tem o que está na lista, e
"porque" é uma frase curta que se apoia no que está ali.`,

  user: (ctx) => `## Leads
${ctx.rows.map(line).join("\n")}

## Responda com este JSON, e nada fora dele
{
  "ordem": [{"leadId": "id exatamente como veio", "porque": "frase curta"}],
  "leitura": "uma linha sobre o conjunto: o que essa fila tem de bom ou de ruim"
}

Inclua TODOS os ${ctx.rows.length} leads na ordem, do melhor para o pior. Não
remova nenhum, não invente id.`,

  validate: (raw, ctx) => {
    const seen = new Set<string>();
    const ordem = list(raw.ordem)
      .map((entry) => {
        const item = obj(entry);
        return { leadId: str(item.leadId), porque: str(item.porque) };
      })
      // An id we did not send is dropped; a repeat is dropped. Both would put a
      // lead on the screen twice or put a stranger's business in our queue.
      .filter((item) => {
        if (!ctx.ids.has(item.leadId) || seen.has(item.leadId)) return false;
        seen.add(item.leadId);
        return true;
      });

    if (ordem.length === 0) return null;

    // Anything the model forgot is appended in the order the database gave it,
    // rather than lost. The ranking is an opinion about priority; it is not
    // permission to remove a business from the day's work.
    for (const row of ctx.rows) {
      if (!seen.has(row.id)) {
        ordem.push({ leadId: row.id, porque: "Não classificado pelo modelo." });
      }
    }

    return { ordem, leitura: str(raw.leitura) };
  },
};

export { buildContext as insightFilaContext };
export type { Ctx as InsightFilaContext, Row as InsightFilaRow };
