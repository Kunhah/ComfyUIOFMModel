/**
 * The rows a skill is allowed to claim, each with an id the model must cite.
 *
 * This is the "no invented facts" guardrail in the only form that actually
 * holds. Asking a model in the prompt not to make things up reduces how often it
 * does; it does not make the output checkable. A numbered fact list does both:
 * the prompt carries the facts *with* their ids, the envelope asks for a
 * citation per observation, and `citedIds()` drops any observation whose id we
 * did not hand it. A hallucinated claim then arrives with either no citation or
 * an unknown one, and is thrown away before a page can render it.
 *
 * The cost of this design is real and worth naming: an observation the model got
 * *right* but cited badly is also thrown away. That trade is the correct one for
 * a tool an operator reads thirty seconds before dialling a stranger. A missing
 * insight is a worse call; a confident false one is a burnt lead.
 *
 * Facts are pt-BR because everything downstream is, and because a model asked to
 * reason in one language over facts written in another spends accuracy on the
 * translation.
 */

export type Fact = {
  /** Short, stable, and meaningful to a human reading the log: "site", "tel". */
  id: string;
  /** The claim, as a sentence the model may repeat. */
  text: string;
};

/**
 * A fact list under construction.
 *
 * `add()` ignores empty values on purpose. The alternative — "website: não
 * informado" — is a fact about our database masquerading as a fact about the
 * business, and it is exactly the kind of line a model turns into "eles não têm
 * site" when what we know is that we did not find one.
 *
 * Where the *absence* itself is the pitch (no website, no CRM), say so
 * explicitly with `addAbsence()`, which words it as a search that came up empty
 * rather than as a proven negative.
 */
export class Facts {
  private readonly items: Fact[] = [];
  private readonly used = new Set<string>();

  add(id: string, text: string | null | undefined): this {
    const value = typeof text === "string" ? text.trim() : "";
    if (!value) return this;
    // A duplicate id would let two different claims share one citation, which
    // makes the citation meaningless in exactly the case it matters.
    if (this.used.has(id)) throw new Error(`fato duplicado: ${id}`);
    this.used.add(id);
    this.items.push({ id, text: value });
    return this;
  }

  /** A field we looked for and did not find, worded as such. */
  addAbsence(id: string, what: string): this {
    return this.add(id, `Não encontramos ${what} nos dados que temos.`);
  }

  /** `add`, but only when the condition holds. Keeps callers free of ifs. */
  addIf(condition: boolean, id: string, text: string): this {
    return condition ? this.add(id, text) : this;
  }

  get list(): Fact[] {
    return [...this.items];
  }

  get ids(): Set<string> {
    return new Set(this.used);
  }

  /** The block that goes in the prompt. */
  render(): string {
    if (this.items.length === 0) return "(nenhum fato disponível)";
    return this.items.map((f) => `[${f.id}] ${f.text}`).join("\n");
  }
}
