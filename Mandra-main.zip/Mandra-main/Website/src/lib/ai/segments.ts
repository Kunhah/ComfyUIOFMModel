import { findNiche, NICHES, type Niche } from "@/lib/prospector/niches";

/**
 * The sales segment a niche belongs to, and what changes in the pitch because
 * of it.
 *
 * `roteiro-ligacao.md` §11 already says the important part: a salon's pain is a
 * phone buzzing while both hands are in someone's hair, a clinic's is a quote
 * nobody followed up, and a builder's is being the third to answer a request
 * three companies received. Same product, three different first sentences — and
 * none of it was reaching a prompt, which is why an insight for a dentist read
 * like an insight for a bakery with the noun swapped.
 *
 * ## Why segments and not niches
 *
 * There are 43 niches. Writing 43 templates by hand is how you get 43 templates,
 * six of which are current. What actually changes the pitch is not the trade but
 * **how a customer arrives and what one lost customer costs**, and on that axis
 * the 43 collapse to six. A barbershop and a nail studio are the same sale; a
 * dentist and a physio are the same sale; a dentist and a barbershop are not.
 *
 * The niche still reaches the prompt as a fact — "É do ramo: Odontologia" — so
 * the model can be specific about the trade. The segment is what tells it *what
 * kind of conversation this is*.
 *
 * ## Why this maps from `group`
 *
 * Every niche already carries a `group` for the dropdown, and it is nearly the
 * right partition. Mapping from it means a niche added to `niches.ts` is
 * segmented the moment it is added, instead of silently falling to the default
 * until somebody notices. Where a group genuinely splits — a pet shop's bath
 * and groom is an appointment book, its vet next door is a consultation —
 * `OVERRIDES` names the exception, and the test in segments.test.ts asserts
 * every override still points at a niche that exists.
 */

export type Segment = {
  id: string;
  label: string;
  /** How a customer reaches this business. The channel is the pitch. */
  comoChega: string;
  /** The pain, in one line an operator can say out loud. */
  dor: string;
  /** The diagnostic question. Any answer has to be useful — see roteiro §2. */
  pergunta: string;
  /** What one lost lead costs them, for reasoning about fit rather than for
   * quoting: it is a shape ("um tratamento inteiro"), never a number. */
  valorDeUmLead: string;
  /** What this segment says back, in its own words. */
  objecoesTipicas: string[];
  /** What their customers are called. Getting this wrong reads as a stranger. */
  vocabulario: string;
  /** What burns the call in this segment specifically. */
  evitar: string[];
};

export const SEGMENTS: Record<string, Segment> = {
  agenda: {
    id: "agenda",
    label: "Agenda cheia, mão ocupada",
    comoChega:
      "WhatsApp e Instagram, durante o expediente, enquanto o profissional está atendendo alguém.",
    dor: "A mensagem chega no meio do atendimento. Quem responde depois de duas horas já perdeu o horário para o salão da esquina.",
    pergunta:
      "Quando você tá atendendo e chega mensagem, você responde na hora ou depois? E quantas somem nesse meio tempo?",
    valorDeUmLead:
      "Ticket baixo mas recorrente: o que se perde não é um corte, é uma cliente que voltaria todo mês.",
    objecoesTipicas: [
      "Eu mesma respondo, no intervalo",
      "Minha recepcionista dá conta",
      "A gente já tem Instagram",
    ],
    vocabulario: "cliente, horário, agenda, encaixe",
    evitar: [
      "Falar em 'lead' e 'conversão' — aqui é cliente e horário",
      "Ligar no horário de pico do salão (fim de tarde, sábado)",
    ],
  },

  consulta: {
    id: "consulta",
    label: "Primeira consulta e orçamento parado",
    comoChega:
      "Telefone e WhatsApp, muitas vezes por uma recepção que também atende quem está na sala de espera.",
    dor: "O paciente pede orçamento, some, e ninguém retoma. O tratamento inteiro vai embora por falta de um retorno.",
    pergunta:
      "Dos orçamentos que vocês passaram no mês passado, quantos vocês retomaram depois?",
    valorDeUmLead:
      "Ticket alto e demorado: um paciente que fecha o tratamento inteiro vale muitos que só marcaram avaliação.",
    objecoesTipicas: [
      "A gente tem uma recepcionista para isso",
      "Nosso movimento vem de indicação",
      "Já temos site",
    ],
    vocabulario: "paciente, consulta, avaliação, retorno, tratamento",
    evitar: [
      "Prometer volume de pacientes — é publicidade em saúde e é assunto de conselho",
      "Pedir qualquer dado de paciente, em qualquer momento da conversa",
    ],
  },

  orcamento: {
    id: "orcamento",
    label: "Ganha quem responde primeiro",
    comoChega:
      "Pedido de orçamento por formulário, WhatsApp ou telefone — quase sempre enviado para três empresas ao mesmo tempo.",
    dor: "O cliente pediu orçamento para três. Fecha com quem responde primeiro, não com quem cobra melhor.",
    pergunta:
      "Quando alguém pede orçamento, você é o primeiro, o segundo ou o terceiro a responder? Sabe quem responde antes de você?",
    valorDeUmLead:
      "Ticket alto e pontual: um orçamento fechado paga meses de esforço, e um perdido não volta.",
    objecoesTipicas: [
      "Meu movimento é todo indicação",
      "Eu respondo do meu celular mesmo",
      "Já trabalhamos com uma agência",
    ],
    vocabulario: "orçamento, obra, serviço, visita técnica, proposta",
    evitar: [
      "Ligar no meio da manhã, que é quando estão em obra ou em visita",
      "Falar de 'presença digital' em abstrato — aqui a conversa é sobre velocidade de resposta",
    ],
  },

  balcao: {
    id: "balcao",
    label: "Movimento de rua e delivery",
    comoChega:
      "O cliente chega andando, ou procura no Google e no iFood antes de decidir onde comer.",
    dor: "Não existe funil de lead: existe quem acha o lugar no Google com foto, horário e cardápio certos, e quem não acha.",
    pergunta:
      "Quando alguém procura no Google o que vocês fazem, o que aparece? Cardápio atualizado, horário certo, foto boa?",
    valorDeUmLead:
      "Ticket baixo e altíssima repetição: o que está em jogo é movimento constante, não uma venda grande.",
    objecoesTipicas: [
      "A gente já está no iFood",
      "Meu movimento é da vizinhança",
      "Não preciso de site, tenho Instagram",
    ],
    vocabulario: "cliente, movimento, cardápio, pedido, delivery",
    evitar: [
      "Vender automação de atendimento — o gargalo aqui é ser encontrado, não responder",
      "Ligar em horário de almoço ou jantar. Nunca.",
    ],
  },

  recorrente: {
    id: "recorrente",
    label: "Ciclo longo e confiança",
    comoChega:
      "Indicação, busca por nome, e formulário — e a decisão leva semanas, às vezes um ano letivo.",
    dor: "O contato chega, é atendido uma vez, e ninguém sabe dizer o que aconteceu com ele. O follow-up depende de alguém lembrar.",
    pergunta:
      "Quando chega um contato pelo site, ele cai onde? E se a pessoa que atendeu sair de férias, quem sabe que aquilo existe?",
    valorDeUmLead:
      "Contrato ou matrícula que se renova: um cliente vale anos, o que torna cada contato perdido caro de um jeito que não aparece no mês.",
    objecoesTipicas: [
      "Nosso cliente vem por indicação",
      "Isso aqui é relação de confiança, não é marketing",
      "Já temos um sistema",
    ],
    vocabulario: "cliente, aluno, matrícula, contrato, proposta, honorários",
    evitar: [
      "Prometer resultado rápido — o ciclo é longo e todo mundo aqui sabe disso",
      "Tratar como venda de impulso",
    ],
  },

  parceria: {
    id: "parceria",
    label: "Parceria, não venda",
    comoChega:
      "Não se aplica: esta empresa não é cliente. É quem vende a outra metade para o mesmo comércio que a gente atende.",
    dor: "Eles vendem tráfego e anúncio para um comércio que não tem para onde mandar o clique. A gente faz o destino, eles fazem o tráfego.",
    pergunta:
      "Quando você pega um cliente que não tem site nem lugar para o lead cair, você faz o quê hoje?",
    valorDeUmLead:
      "Não é ticket, é recorrência de indicação: um parceiro bom manda cliente todo mês.",
    objecoesTipicas: [
      "A gente já faz site também",
      "Tenho um desenvolvedor de confiança",
      "Como é a divisão?",
    ],
    vocabulario: "parceiro, indicação, comissão, escopo, entrega",
    evitar: [
      "Vender para eles. Eles não são o cliente, e tratar como cliente encerra a conversa",
      "Falar mal do site que eles entregam hoje",
    ],
  },
};

/** Group → segment. Every group in niches.ts is named here on purpose: an
 * unmapped group must read as a mistake, not fall through to a default. */
export const BY_GROUP: Record<string, string> = {
  Beleza: "agenda",
  Fitness: "agenda",
  Pet: "agenda",
  Saúde: "consulta",
  "Casa e construção": "orcamento",
  Automotivo: "orcamento",
  Alimentação: "balcao",
  Educação: "recorrente",
  "Serviços profissionais": "recorrente",
  "Marketing e parcerias": "parceria",
};

/**
 * Niches whose group is right for the dropdown and wrong for the pitch.
 *
 * Each one is a group that genuinely splits, and the split is always the same
 * question: how does the customer arrive?
 */
const OVERRIDES: Record<string, string> = {
  // Next door to the bath-and-groom, and a completely different conversation:
  // the vet sells a consultation with a follow-up, not a standing appointment.
  veterinarios: "consulta",
  // Filed under Casa e construção, but nobody asks an estate agent for three
  // competing quotes — the sale is long and runs on trust.
  imobiliarias: "recorrente",
  // A dealership is a showroom with a long consideration cycle, not a quote race.
  concessionarias: "recorrente",
};

/** The segment used when a lead has no niche at all — most of the history, for
 * leads that came from a customer's own form rather than from a search. */
export const DEFAULT_SEGMENT = SEGMENTS.orcamento;

export function segmentFor(niche: string | Niche | null): Segment {
  const resolved =
    typeof niche === "string" ? (findNiche(niche) ?? null) : niche;
  if (!resolved) return DEFAULT_SEGMENT;

  // Intent wins over everything. A marketing agency filed under any group is
  // still not somebody we sell to, and pitching them as a client is the one
  // mistake in this file that ends the conversation in a sentence.
  if (resolved.intent === "parceiro") return SEGMENTS.parceria;

  const override = OVERRIDES[resolved.slug];
  if (override) return SEGMENTS[override];

  const byGroup = BY_GROUP[resolved.group];
  return byGroup ? SEGMENTS[byGroup] : DEFAULT_SEGMENT;
}

/** The block that goes in a prompt. */
export function segmentBlock(segment: Segment): string {
  return `## O segmento: ${segment.label}
Como o cliente chega: ${segment.comoChega}
A dor: ${segment.dor}
O que vale um contato perdido: ${segment.valorDeUmLead}
Como eles chamam as coisas: ${segment.vocabulario}

A pergunta de diagnóstico deste segmento (use esta, ou uma variação dela):
"${segment.pergunta}"

O que costumam responder: ${segment.objecoesTipicas.map((o) => `"${o}"`).join(", ")}

Nunca, neste segmento:
${segment.evitar.map((e) => `- ${e}`).join("\n")}`;
}

/** Every niche and the segment it lands in — for the test, and for a screen
 * that ever needs to show the mapping. */
export function segmentCoverage(): { niche: Niche; segment: Segment }[] {
  return NICHES.map((niche) => ({ niche, segment: segmentFor(niche) }));
}
