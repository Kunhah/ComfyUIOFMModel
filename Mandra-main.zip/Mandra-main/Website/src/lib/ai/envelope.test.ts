import test from "node:test";
import assert from "node:assert/strict";

import { citedIds, extractJson, num, oneOf, str } from "@/lib/ai/envelope";

test("parses a bare object", () => {
  assert.deepEqual(extractJson('{"a":1}'), { a: 1 });
});

test("digs the object out of fences and preamble", () => {
  const raw = 'Claro!\n```json\n{"mensagem":"oi"}\n```\nEspero ter ajudado.';
  assert.deepEqual(extractJson(raw), { mensagem: "oi" });
});

test("a brace inside a string does not close the object early", () => {
  const raw = '{"mensagem":"mande {seu nome} por favor"}';
  assert.deepEqual(extractJson(raw), {
    mensagem: "mande {seu nome} por favor",
  });
});

test("an escaped quote does not end the string", () => {
  const raw = '{"m":"ele disse \\"oi\\" e saiu"}';
  assert.deepEqual(extractJson(raw), { m: 'ele disse "oi" e saiu' });
});

test("prose with no object is null, and so is an array", () => {
  assert.equal(extractJson("nada aqui"), null);
  // An array is valid JSON and not an envelope. Returning it would hand every
  // caller a value whose `.mensagem` is undefined.
  assert.equal(extractJson("[1,2,3]"), null);
});

test("coercers default rather than throw", () => {
  assert.equal(str(undefined, "—"), "—");
  assert.equal(str("  oi  "), "oi");
  // Models quote numbers often enough that rejecting "8" would throw away a
  // correct answer over its punctuation.
  assert.equal(num("8"), 8);
  assert.equal(num("oito", -1), -1);
  assert.equal(
    oneOf("fechou", ["fechou", "perdeu"] as const, "perdeu"),
    "fechou",
  );
  assert.equal(
    oneOf("talvez", ["fechou", "perdeu"] as const, "perdeu"),
    "perdeu",
  );
});

test("a citation the reader cannot follow is dropped", () => {
  // The guardrail from docs/ai-infra.md in its cheapest form: an id the model
  // invented would otherwise render as a dead link on the lead panel.
  const known = new Set(["lead:1", "lead:2"]);
  assert.deepEqual(citedIds(["lead:1", "lead:9", "lead:1"], known), ["lead:1"]);
  assert.deepEqual(citedIds("lead:1", known), []);
});
