import type { Usage } from "./providers";

/**
 * What a run cost, in BRL.
 *
 * A table in the repository rather than a lookup against a billing API, and the
 * number it produces is an *estimate that is allowed to be a little wrong*. What
 * it is for is the two questions we cannot answer at all today: which skill is
 * expensive, and what one client costs us in a month. Both are answered by a
 * figure within a few percent, and neither is answered by the provider's invoice,
 * which arrives once, in dollars, with no account on it.
 *
 * Prices are per million tokens, in USD, converted at a rate that is also in
 * here. Both drift. The drift is acceptable and the alternative is not: a cost
 * column that is only correct after an integration nobody has built is a column
 * that stays empty for a year, and an empty column is how you find out about
 * spend from a credit card statement.
 *
 * A model missing from the table costs `null`, not zero. `ai_runs.cost_brl` is
 * nullable for exactly this reason — an unpriced run is a known unknown, and
 * summing it as free is the one behaviour that would make the report lie in the
 * dangerous direction.
 */

/** USD per million tokens, input and output. */
type Price = { in: number; out: number };

/**
 * Keyed by the model id we configure, not by family. `GROQ_MODEL` and
 * `OPENROUTER_MODEL` are env vars a deploy can change, and a table keyed on
 * "llama" would keep costing the old price after somebody points it at a new one.
 */
const PRICES: Record<string, Price> = {
  // Anthropic. The expensive chain, used by the review and by the skills whose
  // whole value is being specific — see the budget note in docs/ai-infra.md.
  "claude-opus-5": { in: 5, out: 25 },
  "claude-sonnet-5": { in: 3, out: 15 },
  "claude-haiku-4-5-20251001": { in: 1, out: 5 },

  // Groq. The fast chain the WhatsApp agent runs on.
  "llama-3.3-70b-versatile": { in: 0.59, out: 0.79 },
  "llama-3.1-8b-instant": { in: 0.05, out: 0.08 },

  // OpenRouter. The free tiers really are free, and are still listed rather than
  // omitted: a zero here means "priced at zero", which is a different fact from
  // a model nobody has added, and only one of the two should read as `null`.
  "deepseek/deepseek-chat-v3-0324:free": { in: 0, out: 0 },
};

/**
 * USD → BRL. Deliberately a constant with a date on it rather than a live rate:
 * a cost report that changes retroactively because the currency moved is a
 * report you cannot compare month to month, and the stored `cost_brl` is a
 * historical record of what we estimated at the time.
 */
const USD_BRL = 5.4; // revisado 2026-09

export function costOf(model: string, usage: Usage | null): number | null {
  if (!usage) return null;
  const price = PRICES[model];
  if (!price) return null;

  const usd =
    (usage.inputTokens / 1_000_000) * price.in +
    (usage.outputTokens / 1_000_000) * price.out;
  return usd * USD_BRL;
}

/** Whether we can price this model at all — for /admin/ia to say so out loud. */
export function priced(model: string): boolean {
  return model in PRICES;
}
