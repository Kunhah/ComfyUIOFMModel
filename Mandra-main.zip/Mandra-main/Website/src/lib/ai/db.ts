import type { DatabaseSync } from "node:sqlite";
import { getDb } from "@/lib/prospector/db";

/**
 * The run log, in the same SQLite file as everything else.
 *
 * Same reasoning as `lib/whatsapp/db.ts`: a run is *about* a lead or an account,
 * and a second file means no join and no foreign key. The schema lives here
 * rather than in prospector/db.ts so the two can be read apart, and is applied
 * on first use through `aiDb()` — `getDb()` has already run its own DDL and
 * migrations by then, so this only ever adds tables.
 *
 * Every run writes a row, including the failures. A skill that fails silently is
 * indistinguishable from a skill nobody used, and the difference between those
 * two is the difference between a bug and a feature nobody wanted.
 */

export type RunState = "ok" | "invalido" | "erro" | "recusado";

export const RUN_STATE_LABEL: Record<RunState, string> = {
  ok: "OK",
  invalido: "Resposta inválida",
  erro: "Erro",
  recusado: "Recusado por custo",
};

const SCHEMA = `
  CREATE TABLE IF NOT EXISTS ai_runs (
    id           INTEGER PRIMARY KEY,
    -- NULL means Atlas, exactly as it does on leads and wa_conversations. We are
    -- not a tenant of ourselves. See lib/crm/accounts.ts.
    account_id   TEXT,
    -- The skill id, e.g. "insight.lead". Not a foreign key: the registry is
    -- code, and a run must outlive the skill that produced it — a removed skill
    -- leaves its history readable rather than orphaning it.
    skill        TEXT NOT NULL,
    -- What it was about, as "tipo:id" ("lead:8123", "conta:acme/2026-09"). Free
    -- text on purpose: the subjects are of different kinds and a column per kind
    -- would be six nullable columns and five NULLs per row.
    subject      TEXT,
    -- Who *answered*, not who was asked. Same reason meeting_reviews carries
    -- analysis_model: a thin answer should be explainable rather than doubted.
    provider     TEXT,
    model        TEXT,
    tokens_in    INTEGER,
    tokens_out   INTEGER,
    -- Nullable, and null is not zero: a provider that reported no usage, or a
    -- model missing from the price table in cost.ts, is a known unknown. Summing
    -- it as free is the one error that makes the report lie in the direction
    -- that costs money quietly.
    cost_brl     REAL,
    latency_ms   INTEGER,
    state        TEXT NOT NULL
                 CHECK (state IN ('ok','invalido','erro','recusado')),
    error        TEXT,
    -- The validated output, JSON, exactly as validate() returned it.
    --
    -- The prompt is deliberately *not* stored. Storing it would make debugging
    -- easier and would also put other people's personal data — a client's
    -- client, quoted verbatim — in a table with no retention window. The output
    -- plus the subject is enough to reproduce a run, because context() is a
    -- function of rows that are still there.
    --
    -- It is also what makes an answer cacheable: a page renders the last run
    -- instead of paying for the same insight twice.
    output       TEXT,
    -- Operator feedback, set from whichever page rendered the output. NULL is
    -- "nobody said", 1 useful, 0 not — and the zeroes are where next month's
    -- eval fixtures come from.
    useful       INTEGER,
    created_at   TEXT NOT NULL
                 DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );
`;

/**
 * Applied after the schema, never inside it. Same rule as prospector/db.ts:
 * CREATE INDEX on a column an older file does not have throws, and it takes the
 * whole statement — and the missing column — down with it.
 */
const INDEXES = `
  CREATE INDEX IF NOT EXISTS ai_runs_account_idx ON ai_runs (account_id, created_at DESC);
  CREATE INDEX IF NOT EXISTS ai_runs_skill_idx   ON ai_runs (skill, created_at DESC);
  CREATE INDEX IF NOT EXISTS ai_runs_subject_idx ON ai_runs (subject);
`;

let ready = false;

export function aiDb(): DatabaseSync {
  const handle = getDb();
  if (!ready) {
    handle.exec(SCHEMA);
    addMissingColumns(handle);
    handle.exec(INDEXES);
    ready = true;
  }
  return handle;
}

/**
 * Additive only, same rule as prospector/db.ts: `CREATE TABLE IF NOT EXISTS`
 * does not reach a table that already exists, so a column added after the first
 * deploy has to arrive this way or every insert fails with "no such column"
 * while the feature itself works perfectly.
 */
function addMissingColumns(handle: DatabaseSync): void {
  const existing = new Set(
    (
      handle.prepare("PRAGMA table_info(ai_runs)").all() as { name: string }[]
    ).map((column) => column.name),
  );
  if (!existing.has("output")) {
    handle.exec("ALTER TABLE ai_runs ADD COLUMN output TEXT");
  }
}

export type RunRow = {
  id: number;
  account_id: string | null;
  skill: string;
  subject: string | null;
  provider: string | null;
  model: string | null;
  tokens_in: number | null;
  tokens_out: number | null;
  cost_brl: number | null;
  latency_ms: number | null;
  state: RunState;
  error: string | null;
  output: string | null;
  useful: number | null;
  created_at: string;
};

export function recordRun(input: {
  accountId: string | null;
  skill: string;
  subject: string | null;
  provider: string | null;
  model: string | null;
  tokensIn: number | null;
  tokensOut: number | null;
  costBrl: number | null;
  latencyMs: number | null;
  state: RunState;
  error: string | null;
  /** The validated output. Only ever set on an `ok` run. */
  output?: unknown;
}): number {
  const result = aiDb()
    .prepare(
      `INSERT INTO ai_runs
         (account_id, skill, subject, provider, model,
          tokens_in, tokens_out, cost_brl, latency_ms, state, error, output)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      input.accountId,
      input.skill,
      input.subject,
      input.provider,
      input.model,
      input.tokensIn,
      input.tokensOut,
      input.costBrl,
      input.latencyMs,
      input.state,
      // Truncated: a provider that answers an outage with an HTML error page
      // would otherwise put a kilobyte of markup in every row of the log an
      // operator reads.
      input.error ? input.error.slice(0, 500) : null,
      input.output === undefined ? null : JSON.stringify(input.output),
    );
  return Number(result.lastInsertRowid);
}

/**
 * What an account has spent this calendar month, in BRL.
 *
 * Calendar month rather than a rolling 30 days because that is the unit the
 * quota is stated in and the unit an invoice arrives in. Unpriced runs count as
 * zero here — they are already `NULL` and SUM ignores them — which means the
 * ceiling is reached slightly later than it should be. The alternative is to
 * guess a price for a model we do not have one for, and a guessed ceiling that
 * refuses work is worse than a permissive one that gets reported honestly.
 */
export function spentThisMonth(accountId: string | null): number {
  const row = aiDb()
    .prepare(
      `SELECT COALESCE(SUM(cost_brl), 0) AS total
         FROM ai_runs
        WHERE ${accountId === null ? "account_id IS NULL" : "account_id = ?"}
          AND created_at >= strftime('%Y-%m-01T00:00:00.000Z', 'now')`,
    )
    .get(...(accountId === null ? [] : [accountId])) as { total: number };
  return row.total;
}

/** Mark a run useful or not, from the page that rendered it. */
export function markUseful(runId: number, useful: boolean): void {
  aiDb()
    .prepare("UPDATE ai_runs SET useful = ? WHERE id = ?")
    .run(useful ? 1 : 0, runId);
}

/**
 * The most recent successful run for a subject, with its output parsed.
 *
 * The cache. A page shows what it already has instead of paying for the same
 * insight twice — and an insight that changes every time the page is opened
 * reads as unserious even when both versions are good.
 *
 * Returns null when the stored output no longer parses, which happens when a
 * skill's envelope changes shape. That is the correct degradation: regenerating
 * costs one request, and rendering half a stale envelope costs trust.
 */
export function cachedOutput<T>(
  skill: string,
  subject: string,
): {
  output: T;
  runId: number;
  createdAt: string;
} | null {
  const row = lastRunFor(skill, subject);
  if (!row?.output) return null;
  try {
    return {
      output: JSON.parse(row.output) as T,
      runId: row.id,
      createdAt: row.created_at,
    };
  } catch {
    return null;
  }
}

/** The most recent successful run for a subject. */
export function lastRunFor(skill: string, subject: string): RunRow | null {
  const row = aiDb()
    .prepare(
      `SELECT * FROM ai_runs
        WHERE skill = ? AND subject = ? AND state = 'ok'
        ORDER BY id DESC LIMIT 1`,
    )
    .get(skill, subject) as RunRow | undefined;
  return row ?? null;
}

export type SkillUsage = {
  skill: string;
  runs: number;
  falhas: number;
  custoBrl: number;
  latenciaMediaMs: number;
};

/** Per-skill totals for /admin/ia. Scoped by account, or all of them for us. */
export function usageBySkill(accountId?: string | null): SkillUsage[] {
  const scoped = accountId !== undefined;
  const rows = aiDb()
    .prepare(
      `SELECT skill,
              COUNT(*)                                   AS runs,
              SUM(CASE WHEN state != 'ok' THEN 1 ELSE 0 END) AS falhas,
              COALESCE(SUM(cost_brl), 0)                 AS custo,
              COALESCE(AVG(latency_ms), 0)               AS latencia
         FROM ai_runs
        ${scoped ? (accountId === null ? "WHERE account_id IS NULL" : "WHERE account_id = ?") : ""}
        GROUP BY skill
        ORDER BY custo DESC`,
    )
    .all(...(scoped && accountId !== null ? [accountId] : [])) as {
    skill: string;
    runs: number;
    falhas: number;
    custo: number;
    latencia: number;
  }[];

  return rows.map((r) => ({
    skill: r.skill,
    runs: r.runs,
    falhas: r.falhas,
    custoBrl: r.custo,
    latenciaMediaMs: Math.round(r.latencia),
  }));
}

/** The tail of the log, newest first. */
export function recentRuns(limit = 50, accountId?: string | null): RunRow[] {
  const scoped = accountId !== undefined;
  return aiDb()
    .prepare(
      `SELECT * FROM ai_runs
        ${scoped ? (accountId === null ? "WHERE account_id IS NULL" : "WHERE account_id = ?") : ""}
        ORDER BY id DESC LIMIT ?`,
    )
    .all(
      ...(scoped && accountId !== null ? [accountId, limit] : [limit]),
    ) as RunRow[];
}
