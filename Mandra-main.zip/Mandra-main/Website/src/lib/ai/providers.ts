/**
 * The providers, and what happens when one is down.
 *
 * Ported from the Discord bot in EpochalQuant_Agent (src/llm/, src/core/router.rs):
 * a provider interface, one implementation per host, and a router that tries them
 * in order. That shape is worth keeping — a chat that answers customers cannot be
 * one provider's outage away from silence, and Groq in particular rate-limits a
 * free tier hard enough that a busy afternoon will hit it.
 *
 * What is deliberately *not* ported is that router's keyword routing, which picks
 * a provider when the input contains "llama" or "uncensored". Here the input is a
 * customer's message, so that is a stranger choosing which model answers them by
 * typing a word — harmless in a Discord toy, not in a sales channel.
 *
 * Both chat providers speak the OpenAI chat-completions shape, so there is one
 * client with two configurations rather than two clients. Anthropic does not, and
 * that is exactly what `Provider` is for: the two differences live in one class
 * instead of at every call site.
 *
 * This file lived at `lib/whatsapp/llm.ts` until the review and the insight
 * skills also needed it, which made "the WhatsApp model" the wrong name for the
 * only path this application has to an inference provider. Nothing about it
 * changed in the move except that a completion now reports which model answered
 * and what it consumed — see `Completion`, and `runSkill()` in run.ts, which is
 * the only thing that should be calling `complete()` directly from here on.
 */

import Anthropic from "@anthropic-ai/sdk";

export type ChatMessage = {
  role: "system" | "user" | "assistant";
  content: string;
};

/**
 * What a completion cost, as the provider counted it.
 *
 * Null when the provider did not say. That is a real state and not a zero:
 * `ai_runs` stores the nulls, and a cost report that silently counted an
 * unreported completion as free is a report that understates the bill.
 */
export type Usage = {
  inputTokens: number;
  outputTokens: number;
};

export type Completion = {
  text: string;
  /** The model that actually produced this, as configured — not the family. */
  model: string;
  usage: Usage | null;
};

export interface Provider {
  readonly name: string;
  /** The configured model id. Reported per run, because a changed env var is
   * otherwise indistinguishable from a model that got worse. */
  readonly model: string;
  chat(messages: ChatMessage[], options: ChatOptions): Promise<Completion>;
}

export type ChatOptions = {
  /**
   * Ask the provider to guarantee syntactically valid JSON.
   *
   * The agent's whole contract is a JSON envelope, and without this a model
   * happily wraps it in ```json fences or writes a sentence before it. The
   * parser in agent.ts survives both — it has to, because not every model
   * honours the flag — but a provider that enforces it turns a recurring
   * annoyance into a non-event.
   */
  json?: boolean;
  temperature?: number;
  maxTokens?: number;
};

export class LlmError extends Error {}

/** Wall-clock budget for one completion. */
const TIMEOUT_MS = 30_000;

/**
 * The same budget for Claude, an order of magnitude longer.
 *
 * Thirty seconds is right for a WhatsApp reply and wrong for a review: reading a
 * whole transcript and thinking about it takes minutes, and a timeout there
 * throws away work that was going to succeed.
 */
const ANTHROPIC_TIMEOUT_MS = 10 * 60_000;

class OpenAiCompatible implements Provider {
  // Written out rather than declared as constructor parameter properties: Node's
  // type stripping (`node --test`, which runs this folder's tests) rejects those
  // outright, while the bundler accepts them — so the shorthand compiles in the
  // app and fails only under test, which is the worst place to find out.
  readonly name: string;
  readonly model: string;
  private readonly endpoint: string;
  private readonly apiKey: string;
  /** Sent by OpenRouter's terms of use; ignored elsewhere. */
  private readonly extraHeaders: Record<string, string>;

  constructor(
    name: string,
    endpoint: string,
    apiKey: string,
    model: string,
    extraHeaders: Record<string, string> = {},
  ) {
    this.name = name;
    this.endpoint = endpoint;
    this.apiKey = apiKey;
    this.model = model;
    this.extraHeaders = extraHeaders;
  }

  async chat(
    messages: ChatMessage[],
    options: ChatOptions,
  ): Promise<Completion> {
    const response = await fetch(this.endpoint, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${this.apiKey}`,
        ...this.extraHeaders,
      },
      body: JSON.stringify({
        model: this.model,
        messages,
        // Low by default. This model is booking meetings and quoting nothing;
        // the creativity that makes a Discord persona fun makes a sales agent
        // invent a price.
        temperature: options.temperature ?? 0.4,
        max_tokens: options.maxTokens ?? 800,
        ...(options.json ? { response_format: { type: "json_object" } } : {}),
      }),
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });

    if (!response.ok) {
      const body = (await response.text().catch(() => "")).slice(0, 300);
      throw new LlmError(`${this.name} respondeu ${response.status}: ${body}`);
    }

    const body = (await response.json()) as {
      choices?: { message?: { content?: string } }[];
      usage?: { prompt_tokens?: number; completion_tokens?: number };
    };
    const content = body.choices?.[0]?.message?.content;
    if (typeof content !== "string" || !content.trim()) {
      // An empty completion is a failure, not an answer: returning "" would send
      // the client a blank WhatsApp message and mark the turn as handled.
      throw new LlmError(`${this.name} devolveu uma resposta vazia.`);
    }

    // Both hosts report usage on the OpenAI shape, but a free-tier proxy that
    // omits it is not an error — the run is still a run, it just cannot be
    // costed. `usage` stays null rather than becoming a pair of zeroes.
    const prompt = body.usage?.prompt_tokens;
    const completion = body.usage?.completion_tokens;
    const usage =
      typeof prompt === "number" && typeof completion === "number"
        ? { inputTokens: prompt, outputTokens: completion }
        : null;

    return { text: content, model: this.model, usage };
  }
}

/**
 * Claude, for the work the chat models are not good enough at.
 *
 * Added because the meeting review reads a 40-minute transcript and has to say
 * something specific about it — which of the SPIN stages the seller skipped,
 * which sentence lost the deal. A 70b chat model handed that job returns advice
 * that is true of every sales call ever made, and generic feedback is worse than
 * none: it costs the reader ten minutes and teaches them to ignore the tool.
 *
 * It speaks a different wire protocol from the two above, which is exactly what
 * `Provider` is for — two differences live here instead of at every call site:
 * the system prompt is a top-level field rather than a message with a role, and
 * there is no `response_format`, so `json` becomes an instruction and the
 * tolerant parser in the caller stays load-bearing.
 */
class AnthropicProvider implements Provider {
  readonly name = "anthropic";
  readonly model: string;

  private readonly apiKey: string;

  constructor(apiKey: string, model: string) {
    this.apiKey = apiKey;
    this.model = model;
  }

  async chat(
    messages: ChatMessage[],
    options: ChatOptions,
  ): Promise<Completion> {
    const client = new Anthropic({
      apiKey: this.apiKey,
      timeout: ANTHROPIC_TIMEOUT_MS,
    });

    // Anthropic carries the system prompt outside the turn list. Joining rather
    // than taking the first: agent.ts is free to add a second system message
    // later, and silently dropping it would be a bug nobody could see from here.
    const system = messages
      .filter((m) => m.role === "system")
      .map((m) => m.content)
      .join("\n\n");

    const turns: Anthropic.MessageParam[] = messages
      .filter((m) => m.role !== "system")
      .map((m) => ({
        role: m.role === "assistant" ? "assistant" : "user",
        content: m.content,
      }));

    // A turn list that starts with an assistant message, or is empty, is a 400.
    // Neither should happen; both are cheap to make impossible.
    if (turns.length === 0 || turns[0].role !== "user") {
      turns.unshift({ role: "user", content: "..." });
    }

    try {
      const response = await client.messages.create({
        model: this.model,
        max_tokens: options.maxTokens ?? 16000,
        // Adaptive rather than a fixed budget: the review is one long judgement
        // call and the chat replies are one-liners, and the model is a better
        // judge of which is which than a number set here would be.
        thinking: { type: "adaptive" },
        ...(system
          ? {
              system: options.json
                ? `${system}\n\nResponda **somente** com o objeto JSON pedido. Sem texto antes, sem texto depois, sem cercas de código.`
                : system,
            }
          : {}),
        messages: turns,
      });

      if (response.stop_reason === "refusal") {
        throw new LlmError(
          `Claude recusou a requisição (${response.stop_details?.category ?? "sem categoria"}).`,
        );
      }

      const text = response.content
        .filter((block) => block.type === "text")
        .map((block) => block.text)
        .join("")
        .trim();

      if (!text) throw new LlmError("Claude respondeu vazio.");

      return {
        text,
        model: this.model,
        usage: {
          inputTokens: response.usage.input_tokens,
          outputTokens: response.usage.output_tokens,
        },
      };
    } catch (error) {
      if (error instanceof LlmError) throw error;
      if (error instanceof Anthropic.APIError) {
        throw new LlmError(`Claude ${error.status}: ${error.message}`);
      }
      throw new LlmError(
        error instanceof Error ? error.message : String(error),
      );
    }
  }
}

/**
 * Claude, if a key is configured. Null is a normal state — the WhatsApp agent
 * predates this provider and must keep working without it.
 */
function anthropicProvider(): Provider | null {
  const key = process.env.ANTHROPIC_API_KEY?.trim();
  if (!key) return null;
  return new AnthropicProvider(
    key,
    process.env.ANTHROPIC_MODEL?.trim() || "claude-opus-5",
  );
}

/**
 * The providers that are configured, in the order they should be tried.
 *
 * Groq first because it is an order of magnitude faster and a WhatsApp reply is
 * read within seconds of being sent; OpenRouter second because its free models
 * are a different pool of capacity, so a Groq rate-limit is not also an
 * OpenRouter one. An empty array is a valid state — a deployment with no keys
 * has no agent, and `respond()` in agent.ts says so instead of throwing.
 */
export function providers(): Provider[] {
  const chain: Provider[] = [];

  const groqKey = process.env.GROQ_API_KEY?.trim();
  if (groqKey) {
    chain.push(
      new OpenAiCompatible(
        "groq",
        "https://api.groq.com/openai/v1/chat/completions",
        groqKey,
        process.env.GROQ_MODEL?.trim() || "llama-3.3-70b-versatile",
      ),
    );
  }

  const openRouterKey = process.env.OPENROUTER_API_KEY?.trim();
  if (openRouterKey) {
    chain.push(
      new OpenAiCompatible(
        "openrouter",
        "https://openrouter.ai/api/v1/chat/completions",
        openRouterKey,
        process.env.OPENROUTER_MODEL?.trim() ||
          "deepseek/deepseek-chat-v3-0324:free",
        {
          "HTTP-Referer":
            process.env.OPENROUTER_SITE_URL?.trim() || "https://mandra.com.br",
          "X-Title": "Mandra CRM",
        },
      ),
    );
  }

  // Last, not first. The order in this function is the WhatsApp agent's order,
  // and there the fast cheap model is the right default — Claude is here so a
  // deployment that only has an Anthropic key still has an agent.
  const anthropic = anthropicProvider();
  if (anthropic) chain.push(anthropic);

  return chain;
}

/**
 * The chain for work that is worth paying for, Claude first.
 *
 * Separate from `providers()` rather than a reordering flag because the two
 * orders exist for opposite reasons: that one optimises for a reply arriving
 * while the customer is still looking at the phone, this one for being right
 * about a recording nobody is waiting on. Falling back to the chat models is
 * still better than failing — a generic review beats an error page — so the
 * rest of the chain stays underneath.
 */
export function analysisProviders(): Provider[] {
  const anthropic = anthropicProvider();
  const rest = providers().filter((p) => p.name !== "anthropic");
  return anthropic ? [anthropic, ...rest] : rest;
}

export function llmConfigured(): boolean {
  return providers().length > 0;
}

/**
 * The first provider that answers.
 *
 * Every failure is collected and only reported if *all* of them fail, because a
 * Groq 429 followed by an OpenRouter success is a non-event that should not
 * reach a log an operator reads. The thrown message names each provider and its
 * reason — "all providers failed" alone is the least useful sentence in an
 * outage.
 */
export async function complete(
  messages: ChatMessage[],
  options: ChatOptions = {},
  /** Defaults to the WhatsApp order. Pass `analysisProviders()` for review work. */
  chain: Provider[] = providers(),
): Promise<Completion & { provider: string }> {
  if (chain.length === 0) {
    throw new LlmError(
      "Nenhum provedor de IA configurado (defina GROQ_API_KEY ou OPENROUTER_API_KEY).",
    );
  }

  const failures: string[] = [];
  for (const provider of chain) {
    try {
      const completion = await provider.chat(messages, options);
      return { ...completion, provider: provider.name };
    } catch (error) {
      failures.push(
        `${provider.name}: ${error instanceof Error ? error.message : String(error)}`,
      );
    }
  }

  throw new LlmError(`Todos os provedores falharam — ${failures.join("; ")}`);
}
