import { extractJson } from "../envelope";
import { Facts, type Fact } from "../facts";
import { roteiroBlock } from "../skills/roteiro";

/**
 * The eval: replay a recorded model answer through a skill's `validate()` and
 * assert the parts that can be checked.
 *
 * Deliberately not a model grading a model. Asking an LLM whether the tone is
 * right is a second prompt to maintain and a second thing to be wrong about, and
 * it turns a test suite into a bill. What is checkable without judgement is
 * quite a lot, and it is the half that actually breaks:
 *
 * - the envelope parses at all;
 * - `validate()` accepts it, or rejects it when the fixture says it should;
 * - every citation points at a fact we handed over;
 * - no number appears that we did not supply.
 *
 * The fixtures are recorded answers, not live calls. That makes `npm run eval`
 * free, deterministic and runnable in CI on every prompt change — which is the
 * only way a prompt edit can be prevented from degrading production silently.
 * The cost is that it tests the *parser and the guardrails*, not the model. When
 * a model gets worse, what tells you is the run log and an operator marking runs
 * useless; the zeroes there become the next fixture here.
 */

export type Fixture = {
  nome: string;
  /** The facts the skill would have built. Also the citation whitelist. */
  fatos: Fact[];
  /** The completion, exactly as a provider returned it. */
  resposta: string;
  espera: {
    /** The fixture is a bad answer and `validate()` must refuse it. */
    invalido?: boolean;
    /** Minimum grounded observations that must survive filtering. */
    observadoMin?: number;
    /** Citations in the raw answer that are expected to be dropped. */
    dropaCitacoes?: number;
    /**
     * How many entries must survive in `ordem` — the ranking skills' one hard
     * guarantee. Every lead handed in comes back out, whether the model ranked
     * it, forgot it, or answered with an id nobody sent. A skill that quietly
     * lost a lead would be deciding on its own that a business never gets
     * called, invisibly, because nobody counts what is missing from a list.
     */
    ordemCompleta?: number;
    /**
     * How many fabricated numbers the harness is expected to find.
     *
     * A fixture that records a model inventing a statistic asserts the *check*,
     * not the answer: leaving it unset means "none, and any is a failure".
     */
    numerosInventados?: number;
    /** Substrings that must not appear anywhere in the output. */
    naoPodeConter?: string[];
  };
};

export type EvalResult = {
  fixture: string;
  ok: boolean;
  falhas: string[];
};

/** Numbers we handed the model: the facts, plus the script it was given. */
function allowedNumbers(fatos: Fact[]): Set<string> {
  const found = new Set<string>();
  const collect = (text: string) => {
    for (const match of text.matchAll(/\d+/g)) found.add(match[0]);
  };
  for (const fact of fatos) collect(fact.text);
  collect(roteiroBlock());
  return found;
}

/**
 * Every number in the output's prose that we never supplied.
 *
 * This is the check that catches the failure this whole layer exists for: "eles
 * perdem 30% dos leads" is fluent, plausible, and a fabrication with a number on
 * it. A number the model repeated from a fact or from the script is fine; a new
 * one is not.
 *
 * Two exclusions, both to keep the check quiet enough to stay switched on:
 *
 * - **Only strings are scanned.** A numeric field like `encaixe.nota` is the
 *   model's own bounded judgement, already clamped by `validate()`, and is not a
 *   claim about the business. Counting it would flag every single run.
 * - **Single digits are ignored.** They are almost always ordinary language
 *   ("uma ou duas perguntas") and flagging them would make the check noisy
 *   enough to be turned off, which is worse than the leak it prevents.
 */
export function inventedNumbers(output: unknown, fatos: Fact[]): string[] {
  const allowed = allowedNumbers(fatos);
  const invented: string[] = [];

  const walk = (value: unknown): void => {
    if (typeof value === "string") {
      for (const match of value.matchAll(/\d+/g)) {
        const digits = match[0];
        if (digits.length < 2) continue;
        if (!allowed.has(digits)) invented.push(digits);
      }
      return;
    }
    if (Array.isArray(value)) {
      for (const entry of value) walk(entry);
      return;
    }
    if (value && typeof value === "object") {
      for (const entry of Object.values(value)) walk(entry);
    }
  };

  walk(output);
  return [...new Set(invented)];
}

/**
 * The context a fixture can supply is the fact list and whatever the caller adds.
 *
 * The cast below is the one place this file bends the types, and it is load
 * bearing in a useful direction: a skill whose `validate()` reaches for context
 * a fixture cannot provide is a skill that cannot be evaluated offline, and the
 * right response to that is to move the read into `context()` — not to widen
 * this signature until everything type-checks and nothing is tested.
 */
export function runFixture<C extends { facts: Facts }>(
  skill: { validate: (raw: Record<string, unknown>, ctx: C) => unknown },
  fixture: Fixture,
  extraContext: Partial<C> = {},
): EvalResult {
  const falhas: string[] = [];

  const facts = new Facts();
  for (const fact of fixture.fatos) facts.add(fact.id, fact.text);

  const parsed = extractJson(fixture.resposta);
  if (!parsed) {
    return {
      fixture: fixture.nome,
      ok: fixture.espera.invalido === true,
      falhas: fixture.espera.invalido
        ? []
        : ["a resposta não contém um objeto JSON"],
    };
  }

  const output = skill.validate(parsed, { facts, ...extraContext } as C);

  if (fixture.espera.invalido) {
    return {
      fixture: fixture.nome,
      ok: output === null,
      falhas: output === null ? [] : ["validate() aceitou uma resposta ruim"],
    };
  }

  if (output === null) {
    return {
      fixture: fixture.nome,
      ok: false,
      falhas: ["validate() recusou uma resposta que deveria passar"],
    };
  }

  const record = output as Record<string, unknown>;

  if (typeof fixture.espera.observadoMin === "number") {
    const observado = Array.isArray(record.observado)
      ? record.observado.length
      : 0;
    if (observado < fixture.espera.observadoMin) {
      falhas.push(
        `sobraram ${observado} observações grounded, esperava ao menos ${fixture.espera.observadoMin}`,
      );
    }
  }

  if (typeof fixture.espera.dropaCitacoes === "number") {
    const raw = Array.isArray(parsed.observado) ? parsed.observado.length : 0;
    const kept = Array.isArray(record.observado) ? record.observado.length : 0;
    if (raw - kept !== fixture.espera.dropaCitacoes) {
      falhas.push(
        `dropou ${raw - kept} citações, esperava ${fixture.espera.dropaCitacoes}`,
      );
    }
  }

  if (typeof fixture.espera.ordemCompleta === "number") {
    const ordem = Array.isArray(record.ordem) ? record.ordem.length : 0;
    if (ordem !== fixture.espera.ordemCompleta) {
      falhas.push(
        `a ordem saiu com ${ordem} leads, esperava ${fixture.espera.ordemCompleta}`,
      );
    }
    const ids = new Set(
      (Array.isArray(record.ordem) ? record.ordem : []).map((entry) =>
        typeof entry === "object" && entry !== null
          ? (entry as { leadId?: unknown }).leadId
          : null,
      ),
    );
    if (ids.size !== ordem) falhas.push("a ordem repetiu algum lead");
  }

  const invented = inventedNumbers(output, fixture.fatos);
  const expected = fixture.espera.numerosInventados ?? 0;
  if (invented.length !== expected) {
    falhas.push(
      expected === 0
        ? `números que ninguém forneceu: ${invented.join(", ")}`
        : `achou ${invented.length} número(s) inventado(s), esperava ${expected}`,
    );
  }

  const text = JSON.stringify(output).toLowerCase();
  for (const forbidden of fixture.espera.naoPodeConter ?? []) {
    if (text.includes(forbidden.toLowerCase())) {
      falhas.push(`contém "${forbidden}", que é proibido nesta fixture`);
    }
  }

  return { fixture: fixture.nome, ok: falhas.length === 0, falhas };
}
