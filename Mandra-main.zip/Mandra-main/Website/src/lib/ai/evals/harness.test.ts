import assert from "node:assert/strict";
import { test } from "node:test";

import { inventedNumbers, runFixture, type Fixture } from "./harness";
import { insightLead } from "../skills/insight-lead";

/**
 * The eval checking itself.
 *
 * A guardrail that cannot fail is decoration, and this one is easy to write in a
 * way that passes everything — filter nothing, expect nothing, print a tick. So
 * each check is exercised from both sides here: the good answer must pass, and
 * the specific bad answer it exists to catch must fail.
 */

const fatos = [
  { id: "site", text: "Não encontramos site próprio nos dados que temos." },
  { id: "tel", text: "Telefone +55 47 99123-4567." },
];

const answer = (over: Record<string, unknown> = {}): string =>
  JSON.stringify({
    angulo: "Sem site.",
    observado: [{ texto: "Não tem site", fonte: "site" }],
    hipotese: [],
    encaixe: { nota: 70, porque: "Sem site" },
    abertura: "Liguei porque reparei que vocês não têm site.",
    perguntas: [],
    evitar: [],
    ...over,
  });

test("a citation nobody supplied is dropped", () => {
  const raw = JSON.parse(
    answer({
      observado: [
        { texto: "Não tem site", fonte: "site" },
        { texto: "Tem 200 avaliações no Google", fonte: "avaliacoes" },
      ],
    }),
  );
  const output = insightLead.validate(raw, {
    facts: { ids: new Set(["site", "tel"]) },
  } as never);
  assert.ok(output);
  assert.equal(output.observado.length, 1);
  assert.equal(output.observado[0].fonte, "site");
});

test("a number in the prose that we never supplied is found", () => {
  // The failure this whole layer exists for: fluent, plausible, fabricated.
  assert.deepEqual(
    inventedNumbers({ angulo: "Eles perdem 40% dos leads." }, fatos),
    ["40"],
  );
  // A number we did supply is not a fabrication.
  assert.deepEqual(inventedNumbers({ angulo: "Ligar no 99123." }, fatos), []);
  // The model's own bounded score is a judgement, not a claim about the
  // business — flagging it would fire on every single run.
  assert.deepEqual(inventedNumbers({ encaixe: { nota: 78 } }, fatos), []);
});

test("a fixture whose expectation is wrong fails", () => {
  // The harness must be able to report a failure at all, or `npm run eval` is a
  // green tick that means nothing.
  const wrong: Fixture = {
    nome: "espera errada de propósito",
    fatos,
    resposta: answer(),
    espera: { observadoMin: 5 },
  };
  const result = runFixture(insightLead, wrong);
  assert.equal(result.ok, false);
  assert.match(result.falhas[0], /observações/);
});

test("an answer that says nothing is refused, not rendered", () => {
  const empty: Fixture = {
    nome: "vazia",
    fatos,
    resposta: answer({ angulo: "", abertura: "" }),
    espera: { invalido: true },
  };
  assert.equal(runFixture(insightLead, empty).ok, true);
});
