/**
 * Reading a model's answer as if it were data, which it is not.
 *
 * Two features arrived at the same four moves independently — a prompt built
 * from real rows, a JSON envelope, a tolerant extractor, and a `validate()` that
 * refuses to trust what came back. `lib/review/analyse.ts` was already importing
 * the WhatsApp agent's extractor with a comment saying two implementations would
 * be two sets of edge cases to discover; this file is that comment applied to
 * the coercers as well, which had been written twice.
 *
 * The rule these encode: **a missing or malformed field is a default, never a
 * throw and never a `null` that reaches a page.** A model that omits one key of
 * fifteen has still done useful work, and losing the other fourteen to a
 * `TypeError` is the expensive way to handle a typo. What a skill must *not* do
 * is let a defaulted field masquerade as an answer — that is `validate()`'s job,
 * and why `runSkill()` has a distinct `invalido` state for envelopes that come
 * back well-formed and empty.
 */

/**
 * The JSON object in a completion, however it was wrapped.
 *
 * `response_format: json_object` is requested and mostly honoured, but "mostly"
 * is not a contract: models still emit ```json fences, a preamble, or a trailing
 * apology, and Anthropic has no such flag at all — there the instruction in the
 * system prompt is the only thing asking, which makes this the load-bearing
 * parser rather than a safety net. Brace matching from the first `{` is what the
 * Rust agent does (`extract_json_object` in core/agent.rs) and it survives all
 * three. String awareness is the one thing added here — a brace inside the
 * message text ("mande {seu nome}") would otherwise close the object early.
 */
export function extractJson(raw: string): Record<string, unknown> | null {
  const direct = tryParse(raw);
  if (direct) return direct;

  const start = raw.indexOf("{");
  if (start < 0) return null;

  let depth = 0;
  let inString = false;
  let escaped = false;

  for (let i = start; i < raw.length; i += 1) {
    const ch = raw[i];

    if (inString) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === '"') inString = false;
      continue;
    }

    if (ch === '"') inString = true;
    else if (ch === "{") depth += 1;
    else if (ch === "}") {
      depth -= 1;
      if (depth === 0) return tryParse(raw.slice(start, i + 1));
    }
  }

  return null;
}

function tryParse(value: string): Record<string, unknown> | null {
  try {
    const parsed = JSON.parse(value.trim());
    return parsed && typeof parsed === "object" && !Array.isArray(parsed)
      ? (parsed as Record<string, unknown>)
      : null;
  } catch {
    return null;
  }
}

/** A trimmed string, or the fallback. Never undefined, never untrimmed. */
export const str = (v: unknown, fallback = ""): string =>
  typeof v === "string" ? v.trim() : fallback;

/**
 * A finite number, or the fallback.
 *
 * `Number(v)` rather than a `typeof` check alone because models quote numbers —
 * `"nota": "8"` is common enough that rejecting it would throw away a correct
 * answer over its punctuation.
 */
export const num = (v: unknown, fallback = 0): number => {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : fallback;
};

export const clamp = (n: number, lo: number, hi: number): number =>
  Math.min(hi, Math.max(lo, n));

/** An array, or an empty one. A model that answered with a bare object for a
 * list field has answered wrong, and iterating nothing is the safe reading. */
export const list = (v: unknown): unknown[] => (Array.isArray(v) ? v : []);

/** A value from a closed set, or the fallback. The guard against a model
 * inventing a sixth funnel stage or a status nothing renders. */
export const oneOf = <T extends string>(
  v: unknown,
  allowed: readonly T[],
  fallback: T,
): T => (allowed.includes(v as T) ? (v as T) : fallback);

/** A plain object, or an empty one — for nested envelope fields. */
export const obj = (v: unknown): Record<string, unknown> =>
  v && typeof v === "object" && !Array.isArray(v)
    ? (v as Record<string, unknown>)
    : {};

/**
 * The ids a skill cited, filtered to the ones that actually exist.
 *
 * The guardrail from `docs/ai-infra.md` in its cheapest form: an insight cites
 * the lead or the message it came from, and a citation the reader cannot follow
 * is the failure mode that costs us trust the first time somebody checks. A
 * hallucinated id is dropped here rather than rendered as a dead link.
 */
export function citedIds(v: unknown, known: Set<string>): string[] {
  const seen = new Set<string>();
  for (const entry of list(v)) {
    const id = str(entry);
    if (id && known.has(id)) seen.add(id);
  }
  return [...seen];
}
