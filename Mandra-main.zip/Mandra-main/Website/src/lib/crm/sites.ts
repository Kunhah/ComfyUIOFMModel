import { randomBytes, randomUUID } from "node:crypto";
import type { DatabaseSync } from "node:sqlite";
import { getDb } from "@/lib/prospector/db";
import { isCountryCode } from "@/lib/countries";

/**
 * The customer sites that are allowed to drop leads into the CRM.
 *
 * This is the plug-in point: a site we built gets a row here, embeds
 * `/atlas-crm.js` with the row's key, and its contact form lands in the same
 * `leads` table the prospector writes to. One row per site rather than per
 * customer, because a customer with a landing page and a main site wants to
 * know which one produced the lead — and because the row is what a tenant will
 * hang off when the CRM stops being single-tenant.
 *
 * The key is NOT a secret and is not stored as if it were. It ships in the page
 * source of a public website; hashing it here would be theatre that only makes
 * it impossible to show the customer their own key again. What actually stops a
 * stranger posting into someone's CRM is the origin allowlist below plus the
 * rate limit in the route — the key only says *which* site a submission claims
 * to be from.
 */

export type IntakeSite = {
  id: string;
  /** Public identifier, embedded in the customer's page. */
  key: string;
  name: string;
  /** Exact origins allowed to post, e.g. "https://cliente.com.br". */
  origins: string[];
  /** ISO-3166 alpha-2 the site's visitors dial from — decides the WhatsApp link. */
  country: string;
  /**
   * The client account this site belongs to, or null for one of ours.
   *
   * This is where a lead's account comes from: the form posts a site key, and
   * the site says whose pipeline the submission lands in. A site with no account
   * still works exactly as it did — its leads are Atlas's, which is what every
   * site created before accounts existed was.
   */
  accountId: string | null;
  active: boolean;
  createdAt: string;
  createdBy: string;
  /** When a submission last arrived. Null means the snippet was never installed. */
  lastLeadAt: string | null;
  /** Lifetime accepted submissions, so a silent form is visible from the list. */
  leadCount: number;
};

const SCHEMA = `
  CREATE TABLE IF NOT EXISTS intake_sites (
    id           TEXT PRIMARY KEY,
    -- Public, and unique so a lookup by key can't be ambiguous.
    key          TEXT NOT NULL UNIQUE,
    name         TEXT NOT NULL,
    -- JSON array of exact origins. One column rather than a child table for the
    -- same reason the leads table stores socials as JSON: it is read whole,
    -- never joined, and never queried by element.
    origins      TEXT NOT NULL DEFAULT '[]',
    country      TEXT NOT NULL DEFAULT 'BR',
    account_id   TEXT,
    active       INTEGER NOT NULL DEFAULT 1,
    created_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    created_by   TEXT NOT NULL,
    -- Denormalised from the leads table on purpose: "is this form alive?" is the
    -- first question the list has to answer, and counting leads by site on every
    -- page load is a scan to answer a question the writer already knows.
    last_lead_at TEXT,
    lead_count   INTEGER NOT NULL DEFAULT 0
  );
`;

let ready = false;

function db(): DatabaseSync {
  const handle = getDb();
  if (!ready) {
    handle.exec(SCHEMA);
    addMissingColumns(handle);
    ready = true;
  }
  return handle;
}

type Row = {
  id: string;
  key: string;
  name: string;
  origins: string;
  country: string;
  account_id: string | null;
  active: number;
  created_at: string;
  created_by: string;
  last_lead_at: string | null;
  lead_count: number;
};

/**
 * Long enough that guessing one is not a strategy, prefixed so a key found in a
 * page source or a log is recognisable as ours rather than as a stray token.
 */
function mintKey(): string {
  return `atlas_${randomBytes(18).toString("hex")}`;
}

/**
 * A hostname a browser could actually be on: labels of letters, digits and
 * hyphens, separated by dots.
 *
 * `new URL()` is not this check and cannot be used as one — it happily parses
 * `https://lixo!!` and reports `lixo!!` as the hostname, so a typo'd domain
 * would be stored, would never match a real `Origin` header, and would look
 * configured on the admin screen while the customer's form silently 403s. That
 * is the exact failure this whole allowlist exists to make impossible.
 *
 * IDN is already handled by the time we get here: `URL` punycodes `café.com.br`
 * to `xn--caf-dma.com.br`, which is also the form the browser sends.
 */
const HOSTNAME =
  /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/;

/**
 * Origins are compared by exact string against the browser's `Origin` header,
 * so they have to be stored in exactly the shape a browser sends: scheme, host,
 * optional non-default port, and nothing else. A pasted
 * "cliente.com.br/contato" would never match anything and would look configured,
 * which is the worst of both — so it is normalised here, and rejected when it
 * cannot be.
 *
 * A bare domain is assumed to be https. Typing the scheme is the step people
 * skip, and http is not a guess worth making about a site going live in 2026.
 */
export function normaliseOrigin(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  const trimmed = raw.trim();
  if (!trimmed) return null;

  const withScheme = /^https?:\/\//i.test(trimmed)
    ? trimmed
    : `https://${trimmed}`;

  let url: URL;
  try {
    url = new URL(withScheme);
  } catch {
    return null;
  }

  if (url.protocol !== "https:" && url.protocol !== "http:") return null;
  // Credentials in an origin are always a mistake and `url.origin` drops them
  // silently, so "https://user:pass@site.com" would be stored as "https://site.com"
  // — accepting a string that means something else than what was typed.
  if (url.username || url.password) return null;
  if (!HOSTNAME.test(url.hostname)) return null;
  // A single label is either `localhost` (which a developer testing the snippet
  // genuinely is on) or a domain missing its TLD.
  if (!url.hostname.includes(".") && url.hostname !== "localhost") return null;

  return url.origin;
}

function parseOrigins(raw: string): string[] {
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((o): o is string => typeof o === "string");
  } catch {
    // Same degradation as the leads table's JSON columns: a hand-edited file
    // yields "no origins", which fails closed, rather than a 500 on every post.
    return [];
  }
}

/**
 * Additive catch-up, same rule and same reason as the one in
 * lib/prospector/db.ts: the DDL above is `CREATE TABLE IF NOT EXISTS`, so a
 * database that already has this table never sees a new column, and a SELECT *
 * that expects one turns every form submission into a 500.
 */
function addMissingColumns(handle: DatabaseSync): void {
  const existing = new Set(
    (
      handle.prepare("PRAGMA table_info(intake_sites)").all() as {
        name: string;
      }[]
    ).map((column) => column.name),
  );
  // Null means "one of ours", which is what every site created before client
  // accounts existed was.
  if (!existing.has("account_id")) {
    handle.exec("ALTER TABLE intake_sites ADD COLUMN account_id TEXT");
  }
}

function toSite(row: Row): IntakeSite {
  return {
    id: row.id,
    key: row.key,
    name: row.name,
    origins: parseOrigins(row.origins),
    country: row.country,
    accountId: row.account_id,
    active: row.active === 1,
    createdAt: row.created_at,
    createdBy: row.created_by,
    lastLeadAt: row.last_lead_at,
    leadCount: row.lead_count,
  };
}

/** The forms belonging to one client account, for their own settings screen. */
export function listAccountSites(accountId: string): IntakeSite[] {
  return (
    db()
      .prepare(
        "SELECT * FROM intake_sites WHERE account_id = ? ORDER BY created_at DESC",
      )
      .all(accountId) as Row[]
  ).map(toSite);
}

export function listSites(): IntakeSite[] {
  return (
    db()
      .prepare("SELECT * FROM intake_sites ORDER BY created_at DESC")
      .all() as Row[]
  ).map(toSite);
}

/**
 * The route's lookup. Returns inactive sites too — the caller has to tell "no
 * such key" from "turned off", because only one of those is worth telling the
 * customer about.
 */
export function siteByKey(key: string): IntakeSite | null {
  const row = db()
    .prepare("SELECT * FROM intake_sites WHERE key = ?")
    .get(key) as Row | undefined;
  return row ? toSite(row) : null;
}

export function siteById(id: string): IntakeSite | null {
  const row = db()
    .prepare("SELECT * FROM intake_sites WHERE id = ?")
    .get(id) as Row | undefined;
  return row ? toSite(row) : null;
}

export type CreateResult =
  { ok: true; site: IntakeSite } | { ok: false; error: string };

/**
 * At least one origin is required, deliberately.
 *
 * An empty allowlist would have to mean either "allow everything" or "allow
 * nothing", and both are bad defaults for an endpoint that writes to a CRM: the
 * first hands anyone a form that fills the customer's pipeline with junk, the
 * second ships a site whose form silently fails. Requiring one at creation
 * means the setting is always a decision someone made.
 */
export function createSite(input: {
  name: string;
  origins: unknown;
  country: string;
  createdBy: string;
  /** The client whose pipeline this form fills. Null for one of our own sites. */
  accountId?: string | null;
}): CreateResult {
  const name = input.name.trim().slice(0, 80);
  if (name.length < 2) {
    return { ok: false, error: "Informe o nome do site." };
  }

  const raw = Array.isArray(input.origins) ? input.origins : [];
  const origins = [
    ...new Set(raw.map(normaliseOrigin).filter((o): o is string => o !== null)),
  ];
  if (origins.length === 0) {
    return {
      ok: false,
      error: "Informe ao menos um domínio (ex.: https://cliente.com.br).",
    };
  }

  const country = input.country.toUpperCase();
  if (!isCountryCode(country)) {
    return { ok: false, error: "País inválido." };
  }

  const site: Row = {
    id: randomUUID(),
    key: mintKey(),
    name,
    origins: JSON.stringify(origins),
    country,
    account_id: input.accountId ?? null,
    active: 1,
    created_at: new Date().toISOString(),
    created_by: input.createdBy,
    last_lead_at: null,
    lead_count: 0,
  };

  db()
    .prepare(
      `INSERT INTO intake_sites (id, key, name, origins, country, account_id, active, created_at, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      site.id,
      site.key,
      site.name,
      site.origins,
      site.country,
      site.account_id,
      site.active,
      site.created_at,
      site.created_by,
    );

  return { ok: true, site: toSite(site) };
}

export function updateSite(
  id: string,
  patch: {
    name?: string;
    origins?: unknown;
    country?: string;
    active?: boolean;
  },
): CreateResult {
  const current = siteById(id);
  if (!current) return { ok: false, error: "Site não encontrado." };

  const merged = {
    name: patch.name === undefined ? current.name : patch.name,
    origins: patch.origins === undefined ? current.origins : patch.origins,
    country: patch.country === undefined ? current.country : patch.country,
    createdBy: current.createdBy,
  };

  // Validated through the same path as creation rather than by a second set of
  // checks here — two validators is how an edit comes to accept what a create
  // refuses.
  const name = merged.name.trim().slice(0, 80);
  if (name.length < 2) return { ok: false, error: "Informe o nome do site." };

  const rawOrigins = Array.isArray(merged.origins) ? merged.origins : [];
  const origins = [
    ...new Set(
      rawOrigins.map(normaliseOrigin).filter((o): o is string => o !== null),
    ),
  ];
  if (origins.length === 0) {
    return {
      ok: false,
      error: "Informe ao menos um domínio (ex.: https://cliente.com.br).",
    };
  }

  const country = merged.country.toUpperCase();
  if (!isCountryCode(country)) return { ok: false, error: "País inválido." };

  const active = patch.active === undefined ? current.active : patch.active;

  db()
    .prepare(
      `UPDATE intake_sites SET name = ?, origins = ?, country = ?, active = ? WHERE id = ?`,
    )
    .run(name, JSON.stringify(origins), country, active ? 1 : 0, id);

  const updated = siteById(id);
  return updated
    ? { ok: true, site: updated }
    : { ok: false, error: "Site não encontrado." };
}

/**
 * Deleting the site does not delete its leads. They belong to the customer's
 * pipeline and outlive the form that produced them; the row here only decides
 * whether new submissions are accepted.
 */
export function deleteSite(id: string): boolean {
  const result = db().prepare("DELETE FROM intake_sites WHERE id = ?").run(id);
  return Number(result.changes) > 0;
}

/** Rotates the public key. The old one stops working the moment this returns. */
export function rotateKey(id: string): IntakeSite | null {
  if (!siteById(id)) return null;
  db()
    .prepare("UPDATE intake_sites SET key = ? WHERE id = ?")
    .run(mintKey(), id);
  return siteById(id);
}

/** Called by the intake route once a submission has actually been stored. */
export function recordSiteLead(id: string): void {
  db()
    .prepare(
      `UPDATE intake_sites
          SET lead_count = lead_count + 1,
              last_lead_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
        WHERE id = ?`,
    )
    .run(id);
}
