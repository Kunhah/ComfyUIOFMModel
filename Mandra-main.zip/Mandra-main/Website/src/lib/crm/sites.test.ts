import assert from "node:assert/strict";
import { test } from "node:test";
import { normaliseOrigin } from "./sites";

/**
 * The origin allowlist is the only thing standing between a customer's CRM and
 * every other website on the internet, and every way it fails is silent: a
 * stored value that can never match a real `Origin` header reads as configured
 * on the admin screen while the customer's form 403s for every visitor.
 *
 * So these pin the shape rather than the happy path.
 */

test("a bare domain is completed to https", () => {
  assert.equal(normaliseOrigin("cliente.com.br"), "https://cliente.com.br");
  assert.equal(
    normaliseOrigin("  www.cliente.com.br  "),
    "https://www.cliente.com.br",
  );
});

test("www and the apex are different origins", () => {
  // Not a quirk to smooth over — the browser sends the exact host it is on, and
  // treating these as one would silently authorise an origin nobody listed.
  assert.notEqual(
    normaliseOrigin("cliente.com.br"),
    normaliseOrigin("www.cliente.com.br"),
  );
});

test("a path, query or fragment is dropped, not rejected", () => {
  // People paste the address bar. The origin is what the browser sends.
  assert.equal(
    normaliseOrigin("https://cliente.com.br/contato?utm=x#form"),
    "https://cliente.com.br",
  );
});

test("a non-default port is part of the origin and is kept", () => {
  assert.equal(
    normaliseOrigin("https://cliente.com.br:8443"),
    "https://cliente.com.br:8443",
  );
  // 443 on https is the default, so the browser omits it — and so must we, or
  // the stored value never matches.
  assert.equal(
    normaliseOrigin("https://cliente.com.br:443"),
    "https://cliente.com.br",
  );
  assert.equal(
    normaliseOrigin("http://localhost:3000"),
    "http://localhost:3000",
  );
});

test("http is preserved when it was asked for, but never assumed", () => {
  assert.equal(
    normaliseOrigin("http://cliente.com.br"),
    "http://cliente.com.br",
  );
  assert.equal(normaliseOrigin("cliente.com.br"), "https://cliente.com.br");
});

/**
 * The regression this file exists for. `new URL("https://lixo!!")` parses and
 * reports `lixo!!` as the hostname, so a `URL`-only check stored typo'd domains
 * that could never match anything.
 */
test("a hostname the browser could never send is refused", () => {
  assert.equal(normaliseOrigin("lixo!!"), null);
  assert.equal(normaliseOrigin("https://lixo!!"), null);
  assert.equal(normaliseOrigin("https://cliente com.br"), null);
  assert.equal(normaliseOrigin("https://-cliente.com.br"), null);
  assert.equal(normaliseOrigin("https://cliente..com.br"), null);
});

test("a single label is refused unless it is localhost", () => {
  // "cliente" is a domain someone forgot the TLD on; localhost is where a
  // developer testing the snippet genuinely is.
  assert.equal(normaliseOrigin("cliente"), null);
  assert.equal(normaliseOrigin("http://localhost"), "http://localhost");
});

test("credentials are refused rather than silently stripped", () => {
  // `url.origin` drops them, so accepting this would store something that means
  // one thing and was typed to mean another.
  assert.equal(normaliseOrigin("https://user:pass@cliente.com.br"), null);
});

test("a non-http scheme is refused", () => {
  assert.equal(normaliseOrigin("javascript:alert(1)"), null);
  assert.equal(normaliseOrigin("ftp://cliente.com.br"), null);
  assert.equal(normaliseOrigin("data:text/html,x"), null);
});

test("an accented domain is punycoded, which is what the browser sends", () => {
  assert.equal(
    normaliseOrigin("https://café.com.br"),
    "https://xn--caf-dma.com.br",
  );
});

test("nothing usable yields null rather than throwing", () => {
  assert.equal(normaliseOrigin(""), null);
  assert.equal(normaliseOrigin("   "), null);
  assert.equal(normaliseOrigin(null), null);
  assert.equal(normaliseOrigin(undefined), null);
  assert.equal(normaliseOrigin(42), null);
  assert.equal(normaliseOrigin({}), null);
});
