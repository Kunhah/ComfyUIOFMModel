import { createHash, randomUUID } from "node:crypto";
import { getDb, recordProspectorActivity } from "@/lib/prospector/db";
import { normalise } from "@/lib/prospector/cities";
import {
  isWhatsappCapable,
  normalisePhone,
  scoreLead,
} from "@/lib/prospector/score";
import { recordSiteLead, type IntakeSite } from "./sites";

/**
 * A form submission from a customer's website, turned into a lead.
 *
 * Deliberately not routed through `persistLeads`: that writer is built for a
 * prospector search — it takes a niche, a searched city and a batch, and it
 * overwrites every column on conflict because a re-run of the same search is
 * the freshest truth about a business. None of that holds here. A person filling
 * in a form twice is not a fresher copy of themselves, and clobbering the notes,
 * the funnel stage and the tags an operator has already put on the lead would
 * lose the actual work. So this writer upserts contact fields, *appends* the
 * message, and leaves the pipeline columns alone.
 */

/** What the endpoint accepts, after parsing. Only `name` is required. */
export type Submission = {
  name: string;
  email: string | null;
  phone: string | null;
  message: string | null;
  company: string | null;
  city: string | null;
  uf: string | null;
  /** The page the form was on, so a multi-page site says which one converted. */
  pageUrl: string | null;
  /** Anything else the form carried, label to value. */
  extra: Record<string, string>;
};

export type IntakeResult = {
  leadId: string;
  /** False when this person had already written in — the row was updated. */
  created: boolean;
};

/**
 * Notes are read in a table cell and in an expanded row, not in a document
 * viewer. Twenty thousand characters is dozens of submissions from the same
 * person; past that the column is being used as a log.
 */
const MAX_NOTE_CHARS = 20_000;

/** What joins the person to their company in a lead's name. */
const QUALIFIER = " — ";

/**
 * The dedupe key.
 *
 * E-mail first, then phone: an address is typed the same way every time, while
 * the same phone arrives as "31 99999-8888" and as "+5531999998888" — so the
 * phone is folded through `normalisePhone` before it is hashed, or the two
 * spellings become two leads. A submission with neither gets a fresh id every
 * time, which is the honest answer: there is nothing to recognise them by.
 *
 * Scoped to the site so two customers never collide on one shared visitor —
 * which starts mattering the moment the site id is what a tenant hangs off.
 */
function leadId(site: IntakeSite, submission: Submission): string {
  const email = submission.email?.toLowerCase() ?? null;
  const phone = normalisePhone(submission.phone, site.country);
  const handle = email ?? phone;
  if (!handle) return `web:${site.id}:${randomUUID()}`;
  const digest = createHash("sha256")
    .update(`${site.id} ${handle}`)
    .digest("hex")
    .slice(0, 32);
  return `web:${site.id}:${digest}`;
}

/**
 * The note this submission adds, as the operator will read it.
 *
 * Written as text rather than kept in structured columns because the fields a
 * customer puts on their own contact form are theirs — "quantos funcionários",
 * "qual o orçamento", "como nos conheceu" — and there is no schema that covers
 * them. A column per question would be a migration per customer.
 */
function noteFor(site: IntakeSite, submission: Submission, at: string): string {
  const stamp = `${at.slice(0, 10)} ${at.slice(11, 16)} UTC`;
  const lines = [`[${stamp}] Formulário — ${site.name}`];
  if (submission.message) lines.push(submission.message.trim());
  for (const [label, value] of Object.entries(submission.extra)) {
    lines.push(`${label}: ${value}`);
  }
  if (submission.pageUrl) lines.push(`Página: ${submission.pageUrl}`);
  return lines.join("\n");
}

/**
 * Stores the submission and returns the lead it landed on.
 *
 * Synchronous like every other writer over this database — see the note at the
 * top of lib/prospector/db.ts. The route awaits nothing here.
 */
export function submitLead(
  site: IntakeSite,
  submission: Submission,
): IntakeResult {
  const handle = getDb();
  const id = leadId(site, submission);
  const at = new Date().toISOString();
  const phone =
    normalisePhone(submission.phone, site.country) ?? submission.phone;

  const existing = handle
    .prepare("SELECT id, name, notes FROM leads WHERE id = ?")
    .get(id) as { id: string; name: string; notes: string | null } | undefined;

  const note = noteFor(site, submission, at);
  // Newest last, so the column reads in the order things happened. Trimmed from
  // the front for the same reason: the oldest message is the part you can
  // afford to lose.
  const notes = existing?.notes ? `${existing.notes}\n\n${note}` : note;
  const trimmed =
    notes.length > MAX_NOTE_CHARS
      ? notes.slice(notes.length - MAX_NOTE_CHARS)
      : notes;

  // `name` is the person and the CRM's rows are businesses, so the two are shown
  // together rather than one silently standing for the other. The company has no
  // column of its own on purpose — inventing one would leave every prospector
  // row null in it forever.
  //
  // A second submission that omits the company must not erase it from the name.
  // The plain "quick question" follow-up on a form whose company field is
  // optional is the common case, and turning "Maria Souza — Café Central" back
  // into "Maria Souza" quietly loses the one thing that made the row findable.
  const submitted = submission.company
    ? `${submission.name}${QUALIFIER}${submission.company}`
    : submission.name;
  const displayName =
    !submission.company && existing?.name.includes(QUALIFIER)
      ? existing.name
      : submitted;

  // Scored through the same module the prospector uses, so an inbound lead sorts
  // against found ones on one scale rather than arriving unranked at the bottom.
  const scored = scoreLead({
    id,
    name: displayName,
    category: null,
    address: null,
    city: submission.city,
    uf: submission.uf,
    country: site.country,
    phone,
    website: null,
    social: null,
    email: submission.email,
    lat: null,
    lon: null,
    confidence: 1,
  });

  if (existing) {
    // Only the fields a new submission can legitimately refresh. Status, funnel
    // stage, tags and the follow-up date belong to whoever is working the lead,
    // and a second form fill is not a reason to reset any of them. COALESCE on
    // the contact fields so a shorter second submission cannot blank a value the
    // first one supplied.
    handle
      .prepare(
        `UPDATE leads
            SET name = ?,
                email = COALESCE(?, email),
                phone = COALESCE(?, phone),
                city = COALESCE(?, city),
                uf = COALESCE(?, uf),
                whatsapp = ?,
                score = ?,
                notes = ?,
                search_norm = ?,
                last_seen_at = ?
          WHERE id = ?`,
      )
      .run(
        displayName,
        submission.email,
        phone,
        submission.city,
        submission.uf,
        isWhatsappCapable(phone, site.country) ? 1 : 0,
        scored.score,
        trimmed,
        normalise(displayName),
        at,
        id,
      );
  } else {
    handle
      .prepare(
        // account_id comes from the site, never from the submission — the form
        // is on a public page and everything in the post body is a stranger's
        // typing. This is the line that makes an enquiry land in the client's
        // pipeline instead of ours, and it is the only place a lead is ever
        // stamped with an account.
        `INSERT INTO leads
           (id, source, intake_site, account_id, name, city, uf, country, phone, email,
            confidence, score, whatsapp, search_norm, notes,
            first_seen_at, last_seen_at)
         VALUES (?, 'formulario', ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        id,
        site.id,
        site.accountId,
        displayName,
        submission.city,
        submission.uf,
        site.country,
        phone,
        submission.email,
        scored.score,
        isWhatsappCapable(phone, site.country) ? 1 : 0,
        normalise(displayName),
        trimmed,
        at,
        at,
      );
  }

  recordSiteLead(site.id);

  // The audit table's actor is NOT NULL and there is no operator behind an
  // inbound lead, so the site stands in as one. `site:<uuid>` cannot collide
  // with a user id (also a UUID, but never prefixed) or with the environment
  // admin's `env:admin`, and it means the admin's activity filter can show
  // everything one customer's form produced the way it shows one operator's work.
  recordProspectorActivity({
    actor: {
      id: `site:${site.id}`,
      username: site.key.slice(0, 14),
      displayName: site.name,
    },
    action: "intake",
    leadId: id,
    detail: submission.pageUrl
      ? `Formulário em ${submission.pageUrl}`
      : "Formulário do site",
  });

  return { leadId: id, created: !existing };
}
