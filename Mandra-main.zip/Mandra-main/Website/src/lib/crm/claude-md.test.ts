import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { clientClaudeMd } from "./claude-md";
import type { Account } from "./accounts";
import type { IntakeSite } from "./sites";

/**
 * The generated `CLAUDE.md`.
 *
 * Worth testing because every failure here is silent in the same way the rest
 * of this integration is: a file that reaches a client's repository with a
 * placeholder where the key should be produces a form that looks installed,
 * builds, deploys, and quietly 401s on the first real enquiry.
 */

const ACCOUNT: Account = {
  id: "acc-1",
  name: "Clínica Martins",
  slug: "clinica-martins",
  country: "BR",
  active: true,
  createdAt: "2026-01-01T00:00:00.000Z",
  createdBy: "admin",
  notes: null,
  waInstance: null,
  waNumber: null,
  waBrief: null,
};

function site(over: Partial<IntakeSite> = {}): IntakeSite {
  return {
    id: "site-1",
    key: "atlas_abcdef123456",
    name: "Site principal",
    origins: [
      "https://clinicamartins.com.br",
      "https://www.clinicamartins.com.br",
    ],
    country: "BR",
    accountId: "acc-1",
    active: true,
    createdAt: "2026-01-01T00:00:00.000Z",
    createdBy: "admin",
    lastLeadAt: null,
    leadCount: 0,
    ...over,
  };
}

const CRM = "https://crm.atlas.com.br";

describe("clientClaudeMd", () => {
  it("carries the real key, endpoint and origins", () => {
    const md = clientClaudeMd({
      account: ACCOUNT,
      sites: [site()],
      crmOrigin: CRM,
    });

    assert.ok(md.includes("atlas_abcdef123456"), "key");
    assert.ok(md.includes(`${CRM}/atlas-crm.js`), "script src");
    assert.ok(md.includes(`${CRM}/api/v1/leads`), "endpoint");
    assert.ok(md.includes("https://www.clinicamartins.com.br"), "www origin");
    assert.ok(md.includes("Clínica Martins"), "account name");
  });

  it("never ships a placeholder when a site exists", () => {
    // The failure this whole file exists to prevent: a template pasted verbatim.
    const md = clientClaudeMd({
      account: ACCOUNT,
      sites: [site()],
      crmOrigin: CRM,
    });
    assert.ok(!md.includes("SEU-CRM"), "no SEU-CRM placeholder");
    assert.ok(!md.includes("COLE_A_CHAVE_AQUI"), "no key placeholder");
  });

  it("says so loudly when there is no site yet", () => {
    // Better an obvious placeholder than a plausible wrong key: the first is
    // caught by whoever pastes it, the second is caught by a customer.
    const md = clientClaudeMd({ account: ACCOUNT, sites: [], crmOrigin: CRM });
    assert.ok(md.includes("COLE_A_CHAVE_AQUI"));
    assert.ok(md.includes("nenhum ainda"));
  });

  it("prefers an active site over a disabled one", () => {
    const md = clientClaudeMd({
      account: ACCOUNT,
      sites: [
        site({ id: "old", key: "atlas_desativado", active: false }),
        site({ id: "new", key: "atlas_ativo" }),
      ],
      crmOrigin: CRM,
    });
    assert.ok(md.includes("atlas_ativo"));
    assert.ok(!md.includes("atlas_desativado"));
  });

  it("points at this account's own kit, so a copy is traceable", () => {
    const md = clientClaudeMd({
      account: ACCOUNT,
      sites: [site()],
      crmOrigin: CRM,
    });
    assert.ok(md.includes(`${CRM}/admin/contas/clinica-martins`));
  });

  it("tells the agent the things it would otherwise get wrong", () => {
    const md = clientClaudeMd({
      account: ACCOUNT,
      sites: [site()],
      crmOrigin: CRM,
    });
    // Each of these is a decision an agent makes confidently and wrongly when
    // nothing in the repository contradicts it.
    assert.ok(/não escreva o envio à mão/i.test(md), "no hand-rolled submit");
    assert.ok(/honeypot/i.test(md), "honeypot must survive");
    assert.ok(/não instale serviço de formulário/i.test(md), "no form service");
    assert.ok(/não gere uma chave nova/i.test(md), "no key rotation");
    assert.ok(/403/.test(md), "unlisted domain answers 403");
  });
});
