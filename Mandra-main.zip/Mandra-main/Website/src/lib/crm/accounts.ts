import { randomUUID } from "node:crypto";
import type { DatabaseSync } from "node:sqlite";
import { getDb } from "@/lib/prospector/db";
import { isCountryCode } from "@/lib/countries";

/**
 * A client account — the tenant.
 *
 * One row per client business, not per site: a customer with a landing page and
 * a main site is still one pipeline, one login and one set of numbers.
 * `intake_sites` hangs off this, and so does every table added from here on.
 *
 * We are not reselling to other agencies, so there are exactly two levels:
 * Atlas, and the accounts under it. There is no reseller tier to delegate to,
 * which is why an account has an owner (`created_by`) and no parent.
 *
 * Atlas itself is deliberately **not** a row here. Everything the prospector has
 * ever found is ours, and giving ourselves an account would make our own
 * pipeline a tenant of itself — every existing query would have to learn about
 * accounts on day one, and every historical lead would need a backfill that can
 * only guess. `leads.account_id IS NULL` means "ours" instead. See LeadScope in
 * lib/prospector/history.ts, which is what enforces that at query time.
 */

export type Account = {
  id: string;
  /** The business as the client would write it on an invoice. */
  name: string;
  /** Stable, lowercase, used in admin URLs. Never reused after a rename. */
  slug: string;
  /** ISO-3166 alpha-2. Decides the WhatsApp link and the phone formatting. */
  country: string;
  active: boolean;
  createdAt: string;
  createdBy: string;
  /** Free text for us, never shown to the client. */
  notes: string | null;
  /**
   * The Evolution instance holding this account's paired WhatsApp number, or
   * null while they have not been connected.
   *
   * The *name* only. The server URL and API key stay in the environment because
   * there is one Evolution beside this app serving every account — what differs
   * per client is which paired number a message belongs to, and that is exactly
   * what an instance is. Storing a URL here would invite a per-client bridge,
   * which is a second thing to operate for every customer sold.
   */
  waInstance: string | null;
  /** The paired number, digits only, for display. Evolution reports it after pairing. */
  waNumber: string | null;
  /**
   * Who the agent is when it answers on this account's number: what the business
   * does, in the client's own words.
   *
   * Null is a meaningful state and is the default. The agent's persona is
   * otherwise Atlas's own — imported from `src/content/` so *our* bot cannot
   * offer a service our site does not — and answering a dentist's patients as a
   * digital agency is worse than not answering at all. So a client thread with
   * no brief is handed to a human rather than replied to. See `runTurn`.
   */
  waBrief: string | null;
};

/** An account with the numbers the admin list needs. */
export type AccountSummary = Account & {
  leads: number;
  /** Accounts that can log in. Zero means we set it up and never handed it over. */
  logins: number;
  sites: number;
  lastLeadAt: string | null;
};

const SCHEMA = `
  CREATE TABLE IF NOT EXISTS accounts (
    id         TEXT PRIMARY KEY,
    name       TEXT NOT NULL,
    -- Unique so a lookup by slug can't be ambiguous. Not derived from the name
    -- on read: renaming a business must not change the URL we already sent them.
    slug       TEXT NOT NULL UNIQUE,
    country    TEXT NOT NULL DEFAULT 'BR',
    active     INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    created_by TEXT NOT NULL,
    notes      TEXT,
    -- Unique: two accounts pointing at one Evolution instance would share a
    -- WhatsApp number, and an inbound message could not be attributed to either.
    -- The webhook resolves the account *from* this value, so an ambiguous one is
    -- a message delivered into the wrong client's CRM.
    wa_instance TEXT UNIQUE,
    wa_number   TEXT,
    wa_brief    TEXT
  );
`;

let ready = false;

function db(): DatabaseSync {
  const handle = getDb();
  if (!ready) {
    handle.exec(SCHEMA);
    addMissingColumns(handle);
    ready = true;
  }
  return handle;
}

/**
 * Additive catch-up for an `accounts` table created before WhatsApp was per
 * account — same rule and same reason as the one in lib/prospector/db.ts: the
 * DDL above is `CREATE TABLE IF NOT EXISTS`, so it does nothing at all to a
 * table that already exists, and a column named in a SELECT that the file lacks
 * turns every account screen into a 500.
 *
 * `wa_instance` picks up its UNIQUE index separately, because `ALTER TABLE ADD
 * COLUMN` cannot carry one. A partial index, so the accounts that have no
 * instance yet — which on an existing database is all of them — do not collide
 * with each other on NULL.
 */
function addMissingColumns(handle: DatabaseSync): void {
  const existing = new Set(
    (
      handle.prepare("PRAGMA table_info(accounts)").all() as { name: string }[]
    ).map((column) => column.name),
  );

  const additive: { name: string; ddl: string }[] = [
    {
      name: "wa_instance",
      ddl: "ALTER TABLE accounts ADD COLUMN wa_instance TEXT",
    },
    {
      name: "wa_number",
      ddl: "ALTER TABLE accounts ADD COLUMN wa_number TEXT",
    },
  ];

  for (const column of additive) {
    if (!existing.has(column.name)) handle.exec(column.ddl);
  }

  handle.exec(
    `CREATE UNIQUE INDEX IF NOT EXISTS accounts_wa_instance
       ON accounts (wa_instance) WHERE wa_instance IS NOT NULL`,
  );
}

type Row = {
  id: string;
  name: string;
  slug: string;
  country: string;
  active: number;
  created_at: string;
  created_by: string;
  notes: string | null;
  wa_instance: string | null;
  wa_number: string | null;
  wa_brief: string | null;
};

function toAccount(row: Row): Account {
  return {
    id: row.id,
    name: row.name,
    slug: row.slug,
    country: row.country,
    active: row.active === 1,
    createdAt: row.created_at,
    createdBy: row.created_by,
    notes: row.notes,
    waInstance: row.wa_instance,
    waNumber: row.wa_number,
    waBrief: row.wa_brief,
  };
}

/* -------------------------------------------------------------------------- */
/* Validation                                                                  */
/* -------------------------------------------------------------------------- */

export const MAX_NAME = 120;
const SLUG_RULE = /^[a-z0-9][a-z0-9-]{1,47}$/;

/**
 * A slug from a business name: folded, punctuation dropped, spaces hyphenated.
 *
 * Accents are stripped rather than encoded — the slug goes in a URL we paste
 * into e-mails, and "clínica-são-josé" survives exactly one mail client.
 */
export function slugify(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 48);
}

/** Appends -2, -3 … until the slug is free. Two "Clínica Silva" is not unusual. */
function freeSlug(base: string): string {
  const stem = SLUG_RULE.test(base) ? base : `conta-${base}`.slice(0, 48);
  let candidate = stem;
  let n = 2;
  while (
    db().prepare("SELECT 1 AS hit FROM accounts WHERE slug = ?").get(candidate)
  ) {
    candidate = `${stem.slice(0, 44)}-${n}`;
    n += 1;
  }
  return candidate;
}

/* -------------------------------------------------------------------------- */
/* Reads                                                                       */
/* -------------------------------------------------------------------------- */

export function listAccounts(): Account[] {
  const rows = db()
    .prepare(
      "SELECT * FROM accounts ORDER BY active DESC, name COLLATE NOCASE ASC",
    )
    .all() as Row[];
  return rows.map(toAccount);
}

/**
 * The admin list, with the three numbers that say whether an account is real.
 *
 * Counted in SQL over the whole table rather than in JS over the returned rows,
 * for the same reason the prospector's stats are: a count of what was returned
 * reports the page size back as the total.
 *
 * `logins` is the one worth reading first. An account with leads arriving and
 * no login is one we set up and never handed over — the product exists and the
 * client has never seen it.
 */
export function accountSummaries(): AccountSummary[] {
  const rows = db()
    .prepare(
      `SELECT a.*,
              (SELECT count(*) FROM leads l WHERE l.account_id = a.id)         AS leads,
              (SELECT max(l.first_seen_at) FROM leads l WHERE l.account_id = a.id) AS last_lead_at,
              (SELECT count(*) FROM users u
                WHERE u.account_id = a.id AND u.active = 1)                    AS logins,
              (SELECT count(*) FROM intake_sites s WHERE s.account_id = a.id)  AS sites
         FROM accounts a
        ORDER BY a.active DESC, a.name COLLATE NOCASE ASC`,
    )
    .all() as (Row & {
    leads: number;
    last_lead_at: string | null;
    logins: number;
    sites: number;
  })[];

  return rows.map((row) => ({
    ...toAccount(row),
    leads: Number(row.leads ?? 0),
    lastLeadAt: row.last_lead_at,
    logins: Number(row.logins ?? 0),
    sites: Number(row.sites ?? 0),
  }));
}

export function findAccount(id: string): Account | null {
  const row = db().prepare("SELECT * FROM accounts WHERE id = ?").get(id) as
    Row | undefined;
  return row ? toAccount(row) : null;
}

/**
 * The webhook's lookup: which client does this inbound message belong to?
 *
 * Evolution names the instance in every payload it sends, and that name is the
 * only thing in an inbound webhook that identifies the recipient — the sender's
 * number says who wrote, never who they wrote *to*. So this is the join that
 * keeps one client's conversations out of another's CRM, and it is why
 * `wa_instance` is unique.
 *
 * Returns inactive accounts too. The caller has to tell "no such instance" from
 * "suspended", because only the second is a reason to stop replying to a real
 * person mid-conversation rather than to drop the message as noise.
 */
export function accountByWaInstance(instance: string): Account | null {
  const row = db()
    .prepare("SELECT * FROM accounts WHERE wa_instance = ?")
    .get(instance) as Row | undefined;
  return row ? toAccount(row) : null;
}

/**
 * Binds an Evolution instance to an account, or unbinds it with null.
 *
 * Refuses an instance already bound elsewhere rather than letting the UNIQUE
 * index throw: the caller is an admin screen, and "already in use by Padaria do
 * Zé" is an answer someone can act on where a constraint error is not.
 */
export function setWhatsappInstance(
  id: string,
  instance: string | null,
): { ok: true; account: Account } | { ok: false; error: string } {
  if (!findAccount(id)) return { ok: false, error: "Conta não encontrada." };

  const name = instance?.trim() ?? null;
  if (name !== null && !/^[a-z0-9][a-z0-9_-]{1,47}$/.test(name)) {
    // Evolution puts the instance name straight into its own URLs, so anything
    // needing escaping here becomes a request that silently addresses something
    // else.
    return {
      ok: false,
      error: "Instância inválida: use letras minúsculas, números, - e _.",
    };
  }

  if (name) {
    const holder = accountByWaInstance(name);
    if (holder && holder.id !== id) {
      return { ok: false, error: `A instância já é de ${holder.name}.` };
    }
  }

  // The number is cleared with the instance: a stored number belonging to a
  // connection that no longer exists reads as "connected" on every screen.
  db()
    .prepare(
      `UPDATE accounts
          SET wa_instance = ?, wa_number = CASE WHEN ? IS NULL THEN NULL ELSE wa_number END
        WHERE id = ?`,
    )
    .run(name, name, id);

  const account = findAccount(id);
  return account
    ? { ok: true, account }
    : { ok: false, error: "Conta não encontrada." };
}

/**
 * Sets what the agent says it is on this account's number.
 *
 * Capped rather than rejected when long: it is pasted into a system prompt, and
 * a client who writes three pages about their business should get a working bot
 * with the tail trimmed, not an error message.
 */
export function setWhatsappBrief(id: string, brief: string | null): void {
  const text = brief?.trim().slice(0, 4000) || null;
  db().prepare("UPDATE accounts SET wa_brief = ? WHERE id = ?").run(text, id);
}

/** Records the number Evolution reports once the QR code has been read. */
export function setWhatsappNumber(id: string, number: string | null): void {
  db()
    .prepare("UPDATE accounts SET wa_number = ? WHERE id = ?")
    .run(number, id);
}

export function findAccountBySlug(slug: string): Account | null {
  const row = db()
    .prepare("SELECT * FROM accounts WHERE slug = ?")
    .get(slug) as Row | undefined;
  return row ? toAccount(row) : null;
}

/**
 * Names for ids, for screens that show a lead's account beside it.
 *
 * Returns a Map rather than a lookup per row: the CRM table renders 100 leads
 * and would otherwise ask the same question a hundred times.
 */
export function accountNames(): Map<string, string> {
  const rows = db().prepare("SELECT id, name FROM accounts").all() as {
    id: string;
    name: string;
  }[];
  return new Map(rows.map((row) => [row.id, row.name]));
}

/* -------------------------------------------------------------------------- */
/* Writes                                                                      */
/* -------------------------------------------------------------------------- */

export type AccountResult =
  { ok: true; account: Account } | { ok: false; error: string };

export function createAccount(input: {
  name: string;
  country?: string;
  notes?: string | null;
  createdBy: string;
}): AccountResult {
  const name = input.name.trim().slice(0, MAX_NAME);
  if (name.length < 2) {
    return { ok: false, error: "Informe o nome do cliente." };
  }

  const country = (input.country ?? "BR").toUpperCase();
  if (!isCountryCode(country)) {
    return { ok: false, error: "País desconhecido." };
  }

  const id = randomUUID();
  db()
    .prepare(
      `INSERT INTO accounts (id, name, slug, country, created_by, notes)
       VALUES (?, ?, ?, ?, ?, ?)`,
    )
    .run(
      id,
      name,
      freeSlug(slugify(name)),
      country,
      input.createdBy,
      input.notes?.trim() || null,
    );

  const account = findAccount(id);
  return account
    ? { ok: true, account }
    : { ok: false, error: "Não foi possível criar a conta." };
}

/** The slug deliberately does not follow. A URL we have already sent must keep working. */
export function renameAccount(id: string, name: string): AccountResult {
  const clean = name.trim().slice(0, MAX_NAME);
  if (clean.length < 2)
    return { ok: false, error: "Informe o nome do cliente." };

  db().prepare("UPDATE accounts SET name = ? WHERE id = ?").run(clean, id);
  const account = findAccount(id);
  return account
    ? { ok: true, account }
    : { ok: false, error: "Conta não encontrada." };
}

export function setAccountNotes(id: string, notes: string | null): boolean {
  const result = db()
    .prepare("UPDATE accounts SET notes = ? WHERE id = ?")
    .run(notes?.trim() || null, id);
  return Number(result.changes) > 0;
}

/**
 * Suspending an account, which is as far as this goes — there is no delete.
 *
 * Their leads are theirs and outlive the arrangement; a cascade here would erase
 * a client's pipeline because we stopped invoicing them, and the one time that
 * matters is the month they ask for their data back. Their logins are what stops
 * working: `requireClient()` re-reads the account on every request, so
 * suspending one ends the sessions it owns on the next click.
 */
export function setAccountActive(id: string, active: boolean): boolean {
  const result = db()
    .prepare("UPDATE accounts SET active = ? WHERE id = ?")
    .run(active ? 1 : 0, id);
  return Number(result.changes) > 0;
}
