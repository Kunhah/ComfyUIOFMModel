import { countryLabel } from "@/lib/countries";
import { NICHES } from "@/lib/prospector/niches";
import { outreachMessage, whatsappUrl } from "@/lib/prospector/score";
import type { OutreachContext } from "@/lib/prospector/templates";
import type { StoredLead } from "@/lib/prospector/types";
import type { CrmLead } from "@/components/admin/lead-table";

/**
 * One stored lead, flattened into the row `LeadTable` renders.
 *
 * Extracted from `/admin` the moment a second screen needed it — the client
 * portal at `/app` renders the same table over the same rows. Two copies of
 * this mapping is how the two views start disagreeing about what a lead's
 * WhatsApp link says or which niche label it carries, and the disagreement
 * would be invisible: both screens render fine, they just render differently.
 * Same rule as the CSV columns in `lib/prospector/csv.ts`, same reason.
 *
 * It flattens server-side deliberately. The niche registry and the scoring
 * module are the two heaviest things in the tree, and neither has any business
 * in the client bundle just to print a label and a wa.me URL.
 */
export function toCrmRow(
  lead: StoredLead,
  viewer?: CrmViewer,
  outreach?: OutreachContext,
): CrmLead {
  return {
    id: lead.id,
    name: lead.name,
    category: lead.category,
    nicheLabel: nicheLabel(lead.niche),
    address: lead.address,
    city: lead.city,
    uf: lead.uf,
    country: countryLabel(lead.country ?? "BR"),
    phone: lead.phone,
    whatsappUrl: whatsappUrl(
      lead.phone,
      // The opener *this viewer* has in force, read once by the page and
      // handed down — never looked up here, which would be one SQLite query
      // per row of a fifty-row table. Absent means the built-in opener, which
      // is what a deployment where nobody edited anything should send.
      outreachMessage(lead, undefined, outreach),
      lead.country,
    ),
    website: lead.website,
    social: lead.social,
    email: lead.email,
    mapUrl: mapUrl(lead.lat, lead.lon, lead.name, lead.city),
    score: lead.score,
    reasons: lead.reasons,
    status: lead.status,
    funnelStage: lead.funnelStage,
    socials: lead.socials,
    contactName: lead.contactName,
    tags: lead.tags,
    nextFollowUpAt: lead.nextFollowUpAt,
    notes: lead.notes,
    firstSeenAt: lead.firstSeenAt,
    contactedAt: lead.contactedAt,
    owner: lead.owner,
    // Resolved here rather than in the table, for the same reason the wa.me URL
    // is: the row is flattened server-side and the client component should not
    // have to be told who is looking at it to know what it may offer. An absent
    // viewer — the admin, and the client portal — blocks nothing.
    blockedBy:
      lead.owner && viewer && !viewer.isAdmin && lead.owner.id !== viewer.id
        ? lead.owner.name
        : null,
  };
}

/**
 * The session, as the row mapper needs it. Built with `callActor()` at the page,
 * so "who is exempt" is decided in the one place that decides it everywhere.
 */
export type CrmViewer = { id: string; isAdmin?: boolean };

/**
 * Coordinates when the record has them, a name-and-city text search otherwise —
 * a "?query=" with no coordinates still lands on the right place far more often
 * than dropping the link entirely.
 *
 * Moved here from the CRM page when /app started rendering the same rows.
 */
export function mapUrl(
  lat: number | null,
  lon: number | null,
  name: string,
  city: string | null,
): string | null {
  const query =
    lat !== null && lon !== null
      ? `${lat},${lon}`
      : [name, city].filter(Boolean).join(" ");
  if (!query) return null;
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
}

/** The niche's display label, or the raw slug when the registry has moved on. */
export function nicheLabel(slug: string | null): string {
  return NICHES.find((niche) => niche.slug === slug)?.label ?? slug ?? "—";
}
