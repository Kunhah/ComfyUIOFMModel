import type { Account } from "./accounts";
import type { IntakeSite } from "./sites";

/**
 * The `CLAUDE.md` we drop into a client's site repository.
 *
 * Claude Code reads `CLAUDE.md` from the repository root on every session, so
 * this is the one file guaranteed to be in context while somebody builds that
 * site — which makes it the right place for the handful of rules that cannot be
 * discovered from the code in front of it. The site's repository contains no
 * trace of this CRM: no package, no import, no type. Without this file an agent
 * building a contact form has no way to know the endpoint exists, and will do
 * the reasonable thing instead — write a form that posts to itself, or reach for
 * whatever form service it has seen most often.
 *
 * It is generated per account rather than kept as a static template so the key,
 * the endpoint and the allowed domains are the real ones. A template with
 * `SEU-CRM` in it is a template someone pastes verbatim, and the resulting form
 * fails in the one way this whole design is trying to avoid: silently.
 *
 * Written as instructions, not as prose. The audience is an agent deciding what
 * to build, so every section is a rule with the reason attached — the reason is
 * what stops it being "improved" into something that no longer works.
 */

export function clientClaudeMd(input: {
  account: Account;
  sites: IntakeSite[];
  /** Absolute origin this CRM answers on, e.g. https://crm.atlas.com.br */
  crmOrigin: string;
}): string {
  const { account, sites, crmOrigin } = input;
  const primary = sites.find((site) => site.active) ?? sites[0] ?? null;
  const key = primary?.key ?? "COLE_A_CHAVE_AQUI";
  const origins = primary?.origins ?? [];

  return `# ${account.name} — site

Site institucional de **${account.name}**, mantido pela Atlas Digital.

Este repositório é só o site. Ele não tem banco de dados, não guarda contatos e
não precisa de back-end para o formulário: os contatos vão para o CRM da Atlas
por HTTP. Estas regras existem porque nada disso é descobrível lendo o código
daqui — sem elas, a coisa razoável a fazer é inventar um formulário que não
chega a lugar nenhum.

## O formulário de contato

**Use o script da Atlas. Não escreva o envio à mão.**

\`\`\`html
<script src="${crmOrigin}/atlas-crm.js" data-key="${key}" defer></script>
\`\`\`

E marque o formulário com \`data-atlas-crm\`:

\`\`\`html
<form data-atlas-crm>
  <input name="nome" required placeholder="Seu nome">
  <input name="email" type="email" placeholder="Seu e-mail">
  <input name="telefone" placeholder="WhatsApp">
  <textarea name="mensagem" placeholder="Como podemos ajudar?"></textarea>
  <button type="submit">Enviar</button>
</form>
\`\`\`

O script cuida de envio, estado de carregando, mensagem de erro e honeypot.

- **Não adicione um \`onSubmit\` próprio** ao formulário marcado. Dois handlers no
  mesmo \`submit\` mandam o contato duas vezes ou nenhuma, e as duas falhas só
  aparecem depois, no CRM.
- **Não remova nem torne visível o campo do honeypot.** Ele é injetado pelo
  script e escondido por CSS; deixá-lo à mostra faz uma pessoa preenchê-lo, e um
  envio com ele preenchido é descartado em silêncio (responde 202 de propósito).
- **Os nomes dos campos podem ser em português ou inglês** (\`nome\`/\`name\`,
  \`telefone\`/\`phone\`). Qualquer campo além dos conhecidos vai junto sob o rótulo
  visível e vira uma linha na nota do lead — então um \`<label>\` bem escrito é o
  que o vendedor vai ler.
- **Obrigatório:** nome, e e-mail **ou** telefone. Um contato sem nenhum dos dois
  não tem como ser respondido, e o endpoint recusa com 400.

## Se o envio precisar sair do servidor

Route handler, Server Action, back-end em qualquer linguagem — mesmo endpoint:

\`\`\`
POST ${crmOrigin}/api/v1/leads
content-type: application/json

{
  "key": "${key}",
  "name": "Maria Silva",
  "email": "maria@exemplo.com",
  "phone": "+55 31 98888-7777",
  "message": "Gostaria de um orçamento.",
  "pageUrl": "https://exemplo.com.br/contato",
  "fields": { "Como nos conheceu": "Instagram" }
}
\`\`\`

\`201\` lead novo · \`200\` pessoa já conhecida · \`202\` honeypot · \`400\` faltou nome
ou contato · \`401\` chave inválida · \`403\` site desativado ou domínio não liberado
· \`429\` limite de envios.

Guarde a chave em \`ATLAS_SITE_KEY\` e a URL em \`ATLAS_CRM_URL\` se for por aqui.

## A chave é pública — e mesmo assim não a troque

\`${key}\`

Ela viaja no HTML de um site público: é um identificador, não uma senha. Não
monte proxy, rota intermediária ou "esconderijo" para ela — não protege nada e
quebra a instalação. O que limita o endpoint é a lista de domínios abaixo e o
limite de envios por IP.

E **não gere uma chave nova** para resolver um erro. Trocar a chave é uma ação no
painel da Atlas que derruba o formulário até o trecho aqui ser atualizado. Um 401
quase sempre é chave copiada pela metade.

## Domínios liberados

${
  origins.length > 0
    ? origins.map((origin) => `- \`${origin}\``).join("\n")
    : "- (nenhum ainda — peça à Atlas antes de publicar)"
}

O navegador manda a origem exata da página. **Um domínio que não esteja nesta
lista recebe 403**, e isso inclui o \`www\` quando só o apex está liberado, e o
inverso. Domínio novo, subdomínio novo, domínio de staging, preview de deploy:
todos precisam ser liberados pela Atlas antes. Isso não se resolve neste
repositório — se o formulário der 403, o pedido é para a Atlas, não uma
alteração no código.

## O que não fazer

- **Não instale serviço de formulário** (Formspree, Netlify Forms, HubSpot, um
  webhook do Zapier). O contato tem de cair no CRM onde o cliente atende; em
  qualquer outro lugar ele é um e-mail que ninguém responde.
- **Não crie banco de dados nem tabela de contatos aqui.** Este repositório é
  descartável e pode ser reconstruído; o CRM é o que guarda a relação com o
  cliente.
- **Não renomeie nem faça proxy de \`/api/v1/leads\`.** O caminho é um contrato
  com sites já publicados.
- **Não copie este arquivo para outro cliente.** A chave é deste site. Cada
  cliente tem o próprio kit em \`${crmOrigin}/admin/contas/${account.slug}\`.

## Onde o contato aparece

No portal do cliente, em \`${crmOrigin}/app\`, com o login que a Atlas criou:
contatos, estágio de cada um, notas e data de retorno — só os desta conta.

Para conferir que a instalação funciona: envie o formulário do site publicado e
veja o contato aparecer lá. Sem site publicado o teste não vale — o domínio
liberado é parte do que está sendo testado.
`;
}
