/**
 * A fixed-window counter, in memory.
 *
 * The public intake endpoint is the first thing in this app that anyone on the
 * internet can call, so it needs *a* ceiling. This is the cheap one, and its
 * limits are honest: the window lives in the process, so it resets on deploy and
 * counts separately per container. That is fine for what it is actually for —
 * stopping a stuck retry loop or a bored someone from filling a customer's
 * pipeline with a thousand rows — and it is not a defence against a distributed
 * flood. If the CRM ever runs on more than one instance, this has to move to the
 * database or in front of the app; nothing else here does.
 *
 * Deliberately not a dependency and deliberately not Redis: adding a service to
 * an app whose entire persistence layer is one SQLite file would be the largest
 * operational change in the project, in exchange for a counter.
 */

type Window = { count: number; resetAt: number };

const windows = new Map<string, Window>();

/**
 * Entries are only ever removed when their own key is next seen, so a stream of
 * unique keys (one per IP) would grow the map without bound. Sweeping on write
 * past a threshold keeps it to the set of callers actually active in a window,
 * which is the only thing worth remembering.
 */
const SWEEP_AT = 5_000;

function sweep(now: number): void {
  for (const [key, window] of windows) {
    if (window.resetAt <= now) windows.delete(key);
  }
}

export type RateVerdict = {
  allowed: boolean;
  /** Seconds until the window resets, for the Retry-After header. */
  retryAfter: number;
};

export function rateLimit(
  key: string,
  limit: number,
  windowMs: number,
): RateVerdict {
  const now = Date.now();
  if (windows.size > SWEEP_AT) sweep(now);

  const existing = windows.get(key);
  if (!existing || existing.resetAt <= now) {
    windows.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true, retryAfter: 0 };
  }

  existing.count += 1;
  const retryAfter = Math.max(1, Math.ceil((existing.resetAt - now) / 1000));
  return { allowed: existing.count <= limit, retryAfter };
}

/**
 * The caller's address as the proxy in front of us saw it.
 *
 * `x-forwarded-for` is a list appended to by every hop, and the *first* entry is
 * the client — but it is also entirely client-controlled unless something
 * trustworthy overwrites it, which is exactly what the reverse proxy in front of
 * this app does. Behind no proxy at all there is no header and every caller
 * shares one bucket, which is the safe direction to be wrong in: stricter, not
 * looser.
 */
export function callerAddress(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for");
  if (forwarded) {
    const first = forwarded.split(",")[0]?.trim();
    if (first) return first;
  }
  return request.headers.get("x-real-ip")?.trim() || "desconhecido";
}
