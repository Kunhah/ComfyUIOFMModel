import {
  randomBytes,
  randomUUID,
  scryptSync,
  timingSafeEqual,
} from "node:crypto";
import type { DatabaseSync } from "node:sqlite";
import { getDb } from "@/lib/prospector/db";
import {
  DEFAULT_PERMISSIONS,
  PERMISSIONS,
  isPermission,
  isRole,
  type Permission,
  type Role,
} from "./session";

/**
 * The accounts that aren't the admin.
 *
 * The admin is configured in the environment and has no row here — there is
 * exactly one, it exists before the database does, and an account that can
 * create accounts should not be creatable by the thing it creates. Everyone else
 * lives in this table, where the admin can add them and take them away again.
 *
 * It shares `data/prospector.db` with the leads. The schemas are unrelated, but
 * so is the alternative's cost: a second file to back up, to mount into the
 * container and to lose separately from the data it guards.
 */

export type User = {
  id: string;
  username: string;
  displayName: string;
  role: Role;
  /**
   * The client account this login belongs to. Required for `cliente` and null
   * for everyone at Atlas — an operator is not "an account with all accounts",
   * they are outside the tenancy entirely. See scopeFor() in ./server.ts.
   */
  accountId: string | null;
  active: boolean;
  /** What they may do beyond reading the CRM. See Permission in ./session.ts. */
  permissions: Permission[];
  createdAt: string;
  createdBy: string | null;
  lastLoginAt: string | null;
  /** Sessions issued before this are refused. Revoking and resetting bump it. */
  sessionsValidFrom: string;
};

type Row = {
  id: string;
  username: string;
  display_name: string;
  password_hash: string;
  role: string;
  account_id: string | null;
  active: number;
  permissions: string | null;
  created_at: string;
  created_by: string | null;
  last_login_at: string | null;
  sessions_valid_from: string;
};

const SCHEMA = `
  CREATE TABLE IF NOT EXISTS users (
    id            TEXT PRIMARY KEY,
    -- Case-folded on write, so "Ana" and "ana" cannot both be created and then
    -- race each other at the login form.
    username      TEXT NOT NULL UNIQUE,
    display_name  TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'operador'
                  CHECK (role IN ('operador','admin','cliente')),
    -- Set for a 'cliente' and null for everyone else. Not a foreign key: an
    -- account is suspended rather than deleted, and a login that outlived its
    -- account should fail the account check in requireClient() rather than
    -- disappear from the users table behind the admin's back.
    account_id    TEXT,
    active        INTEGER NOT NULL DEFAULT 1,
    -- A JSON array of Permission, not a column per flag. Same reasoning as the
    -- leads table's socials column: the set of things worth gating changes
    -- faster than the schema should, and an unreadable value degrades to "no
    -- permissions" rather than taking the login page down.
    permissions   TEXT NOT NULL DEFAULT '["b2b"]',
    created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    -- Who added them. A login name rather than an id: the admin has no row to
    -- point a foreign key at.
    created_by    TEXT,
    last_login_at TEXT,
    -- Sessions issued before this are refused; a revoke or a password reset
    -- moves it to now. Millisecond precision, matching the session's iat, so a
    -- login and a revoke in the same second can still be ordered.
    sessions_valid_from TEXT NOT NULL
                  DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );
`;

let ready = false;

function db() {
  const handle = getDb();
  if (!ready) {
    handle.exec(SCHEMA);
    addMissingColumns(handle);
    widenRoleCheck(handle);
    ready = true;
  }
  return handle;
}

/**
 * Additive catch-up for a `users` table created by an older build, for the same
 * reason `addMissingColumns()` exists in lib/prospector/db.ts: the DDL above is
 * `CREATE TABLE IF NOT EXISTS`, so it does nothing at all to a table that is
 * already there, and a column named in a SELECT that the file lacks turns every
 * login into a 500.
 *
 * The default deliberately matches DEFAULT_PERMISSIONS: an operator who existed
 * before this column did keeps the B2B tool and loses the CSV export, which is
 * the change being made rather than an accident of migration order.
 */
function addMissingColumns(handle: DatabaseSync): void {
  const existing = new Set(
    (
      handle.prepare("PRAGMA table_info(users)").all() as { name: string }[]
    ).map((column) => column.name),
  );

  const additive: { name: string; ddl: string }[] = [
    {
      name: "permissions",
      ddl: `ALTER TABLE users ADD COLUMN permissions TEXT NOT NULL DEFAULT '["b2b"]'`,
    },
    { name: "account_id", ddl: "ALTER TABLE users ADD COLUMN account_id TEXT" },
  ];

  for (const column of additive) {
    if (!existing.has(column.name)) handle.exec(column.ddl);
  }
}

/**
 * Widens `role`'s CHECK constraint to admit 'cliente'.
 *
 * This is the one migration in the project that the additive-only rule cannot
 * cover. SQLite has no ALTER for a constraint, and the table DDL above is
 * `CREATE TABLE IF NOT EXISTS`, so an existing `prospector.db` keeps the
 * two-role constraint forever and every attempt to create a client login fails
 * with a CHECK violation — at the INSERT, long after the screen said it worked.
 *
 * So: the documented rebuild. Rename, recreate from the current DDL, copy,
 * drop, inside one transaction so a crash halfway leaves the old table in
 * place rather than no table at all. Guarded on the stored DDL, so it runs at
 * most once per database and never on a fresh one.
 *
 * It must run *after* addMissingColumns(): the copy names every column
 * explicitly, and a database one migration behind would otherwise be asked for
 * a column it does not have yet.
 *
 * Nothing references `users` with a foreign key — the audit deliberately
 * captures actor names rather than pointing at rows — so there are no
 * constraints to re-establish afterwards.
 */
function widenRoleCheck(handle: DatabaseSync): void {
  const row = handle
    .prepare(
      "SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'users'",
    )
    .get() as { sql: string | null } | undefined;

  const ddl = row?.sql ?? "";
  if (ddl.length === 0 || ddl.includes("'cliente'")) return;

  const COPY = `id, username, display_name, password_hash, role, account_id,
                active, permissions, created_at, created_by, last_login_at,
                sessions_valid_from`;

  handle.exec("BEGIN");
  try {
    handle.exec("ALTER TABLE users RENAME TO users_pre_cliente");
    handle.exec(SCHEMA);
    handle.exec(
      `INSERT INTO users (${COPY}) SELECT ${COPY} FROM users_pre_cliente`,
    );
    handle.exec("DROP TABLE users_pre_cliente");
    handle.exec("COMMIT");
  } catch (err) {
    handle.exec("ROLLBACK");
    throw err;
  }
}

const now = () => new Date().toISOString();

/**
 * Tolerant on read: a hand-edited row, a null from the ALTER above, or anything
 * that isn't a list of known permissions reads as "no permissions" rather than
 * throwing. People are told they can keep the `.db` file, so someone will edit
 * it, and the safe direction to fail in is closed.
 */
export function parsePermissions(raw: string | null): Permission[] {
  if (!raw) return [];
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    // Filtered against PERMISSIONS rather than trusted, and de-duplicated, so a
    // stale name left behind by a removed permission can't linger in the UI.
    return PERMISSIONS.filter((permission) => parsed.includes(permission));
  } catch {
    return [];
  }
}

function toUser(row: Row): User {
  return {
    id: row.id,
    username: row.username,
    displayName: row.display_name,
    role: isRole(row.role) ? row.role : "operador",
    accountId: row.account_id,
    active: row.active === 1,
    permissions: parsePermissions(row.permissions),
    createdAt: row.created_at,
    createdBy: row.created_by,
    lastLoginAt: row.last_login_at,
    sessionsValidFrom: row.sessions_valid_from,
  };
}

/* -------------------------------------------------------------------------- */
/* Passwords                                                                   */
/* -------------------------------------------------------------------------- */

// scrypt is in node:crypto, so there is no dependency to add and nothing for
// serverExternalPackages. The cost parameters are the Node defaults' safer
// neighbours: 16384*8*128 is 16MB of memory per hash, which is a rounding error
// on a login and expensive in bulk.
const COST = { N: 16384, r: 8, p: 1, keylen: 64 };

export function hashPassword(password: string): string {
  const salt = randomBytes(16);
  const derived = scryptSync(password, salt, COST.keylen, COST);
  return [
    "scrypt",
    COST.N,
    COST.r,
    COST.p,
    salt.toString("base64"),
    derived.toString("base64"),
  ].join("$");
}

/**
 * Constant-time comparison against a stored hash. Anything it cannot parse is a
 * failed login rather than a thrown error — a corrupted row must not become a
 * 500 that tells the world the row is corrupted.
 */
export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [scheme, n, r, p, salt, hash] = stored.split("$");
    if (scheme !== "scrypt") return false;

    const expected = Buffer.from(hash, "base64");
    const derived = scryptSync(
      password,
      Buffer.from(salt, "base64"),
      expected.length,
      {
        N: Number(n),
        r: Number(r),
        p: Number(p),
      },
    );
    return (
      derived.length === expected.length && timingSafeEqual(derived, expected)
    );
  } catch {
    return false;
  }
}

/* -------------------------------------------------------------------------- */
/* Validation                                                                  */
/* -------------------------------------------------------------------------- */

export const USERNAME_RULE = /^[a-z0-9][a-z0-9._-]{2,31}$/;
export const MIN_PASSWORD_LENGTH = 8;

/** Normalised the same way on create and on login, or an account becomes unreachable. */
export function normaliseUsername(value: string): string {
  return value.trim().toLowerCase();
}

export function validateUsername(value: string): string | null {
  if (!USERNAME_RULE.test(value)) {
    return "Use de 3 a 32 caracteres: letras minúsculas, números, ponto, hífen ou sublinhado.";
  }
  return null;
}

export function validatePassword(value: string): string | null {
  if (value.length < MIN_PASSWORD_LENGTH) {
    return `A senha precisa de pelo menos ${MIN_PASSWORD_LENGTH} caracteres.`;
  }
  return null;
}

/* -------------------------------------------------------------------------- */
/* Reads                                                                       */
/* -------------------------------------------------------------------------- */

export function listUsers(): User[] {
  const rows = db()
    .prepare("SELECT * FROM users ORDER BY active DESC, username ASC")
    .all() as Row[];
  return rows.map(toUser);
}

/** The logins belonging to one client account, for its admin screen. */
export function listAccountUsers(accountId: string): User[] {
  const rows = db()
    .prepare(
      "SELECT * FROM users WHERE account_id = ? ORDER BY active DESC, username ASC",
    )
    .all(accountId) as Row[];
  return rows.map(toUser);
}

export function findById(id: string): User | null {
  const row = db().prepare("SELECT * FROM users WHERE id = ?").get(id) as
    Row | undefined;
  return row ? toUser(row) : null;
}

export function countActive(): number {
  const row = db()
    .prepare("SELECT count(*) AS n FROM users WHERE active = 1")
    .get() as { n: number } | undefined;
  return Number(row?.n ?? 0);
}

/**
 * Checks a login. Returns the user only when the password matches *and* the
 * account is active, so a revoked operator gets the same answer as a wrong
 * password — there is nothing useful in telling them which.
 *
 * The hash is always computed, even when the username doesn't exist, so the
 * response time doesn't reveal which usernames are real.
 */
export function authenticate(username: string, password: string): User | null {
  const row = db()
    .prepare("SELECT * FROM users WHERE username = ?")
    .get(normaliseUsername(username)) as Row | undefined;

  const stored = row?.password_hash ?? DUMMY_HASH;
  const ok = verifyPassword(password, stored);

  if (!row || !ok || row.active !== 1) return null;
  return toUser(row);
}

// Hashed once at module load so a login for an unknown username does the same
// work as one for a known username.
const DUMMY_HASH = hashPassword(randomUUID());

/* -------------------------------------------------------------------------- */
/* Writes                                                                      */
/* -------------------------------------------------------------------------- */

export type CreateResult =
  { ok: true; user: User } | { ok: false; error: string };

export function createUser(input: {
  username: string;
  displayName: string;
  password: string;
  createdBy: string;
  /** Defaults to DEFAULT_PERMISSIONS — B2B yes, CSV export no. */
  permissions?: Permission[];
  /** Defaults to 'operador'. 'admin' is never created here — see adminAccount(). */
  role?: Role;
  /** Required for a 'cliente', refused for anyone else. */
  accountId?: string | null;
}): CreateResult {
  const username = normaliseUsername(input.username);
  const displayName = input.displayName.trim() || username;

  const badName = validateUsername(username);
  if (badName) return { ok: false, error: badName };
  const badPassword = validatePassword(input.password);
  if (badPassword) return { ok: false, error: badPassword };

  // The administrator is configured in the environment and has no row here, so
  // this writer creates operators and clients only. Accepting 'admin' would be
  // a way to grant every permission by writing to the table the permissions
  // guard — exactly the arrangement adminAccount() exists to prevent.
  const role: Role = input.role === "cliente" ? "cliente" : "operador";
  const accountId = role === "cliente" ? (input.accountId ?? null) : null;

  // Enforced here rather than by a CHECK, because the constraint would have to
  // be added to an existing table — the very thing widenRoleCheck() had to
  // rebuild the table to do once already.
  if (role === "cliente" && !accountId) {
    return { ok: false, error: "Escolha a conta do cliente." };
  }

  const taken = db()
    .prepare("SELECT 1 AS hit FROM users WHERE username = ?")
    .get(username);
  if (taken)
    return { ok: false, error: "Já existe um acesso com esse usuário." };

  const id = randomUUID();
  db()
    .prepare(
      `INSERT INTO users (id, username, display_name, password_hash, role, account_id, permissions, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      id,
      username,
      displayName,
      hashPassword(input.password),
      role,
      accountId,
      // Written explicitly rather than left to the column default, so the grant
      // a new account gets is decided in one place (DEFAULT_PERMISSIONS) instead
      // of in a string inside the schema.
      JSON.stringify(input.permissions ?? DEFAULT_PERMISSIONS),
      input.createdBy,
    );

  const user = findById(id);
  return user
    ? { ok: true, user }
    : { ok: false, error: "Não foi possível criar o acesso." };
}

/**
 * Revoking bumps `sessions_valid_from` as well as clearing `active`. Without
 * that, an operator who is already logged in keeps working until their cookie
 * expires — the revoke would take up to eight hours to mean anything.
 */
export function setActive(id: string, active: boolean): boolean {
  const result = db()
    .prepare(
      `UPDATE users
       SET active = ?,
           sessions_valid_from = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
       WHERE id = ?`,
    )
    .run(active ? 1 : 0, id);
  return Number(result.changes) > 0;
}

/**
 * Ends every open session for an account without touching `active` — "sign this
 * person out", as opposed to "take their access away".
 *
 * Worth having as its own action: the reasons to force a logout (they left a
 * laptop unlocked, they are on a machine they shouldn't be) are not reasons to
 * stop them logging back in, and revoking-then-reactivating to achieve it leaves
 * a misleading gap in the account's state.
 */
export function revokeSessions(id: string): boolean {
  const result = db()
    .prepare(
      `UPDATE users
       SET sessions_valid_from = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
       WHERE id = ?`,
    )
    .run(id);
  return Number(result.changes) > 0;
}

/**
 * Replaces the whole grant rather than toggling one key: the admin's screen
 * shows every permission at once, so a partial update would let two open tabs
 * silently undo each other's changes.
 *
 * Sessions are deliberately *not* ended. Permissions are read from this row on
 * every request, so the change is already live on the operator's next click —
 * signing them out would only cost them their place.
 */
export function setPermissions(id: string, permissions: unknown[]): boolean {
  const granted = PERMISSIONS.filter(
    (permission) =>
      permissions.includes(permission) && isPermission(permission),
  );
  const result = db()
    .prepare("UPDATE users SET permissions = ? WHERE id = ?")
    .run(JSON.stringify(granted), id);
  return Number(result.changes) > 0;
}

/** Same reasoning: a new password ends the sessions the old one opened. */
export function setPassword(id: string, password: string): string | null {
  const bad = validatePassword(password);
  if (bad) return bad;

  const result = db()
    .prepare(
      `UPDATE users
       SET password_hash = ?,
           sessions_valid_from = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
       WHERE id = ?`,
    )
    .run(hashPassword(password), id);
  return Number(result.changes) > 0 ? null : "Acesso não encontrado.";
}

export function deleteUser(id: string): boolean {
  const result = db().prepare("DELETE FROM users WHERE id = ?").run(id);
  return Number(result.changes) > 0;
}

export function recordLogin(id: string): void {
  db()
    .prepare("UPDATE users SET last_login_at = ? WHERE id = ?")
    .run(now(), id);
}
