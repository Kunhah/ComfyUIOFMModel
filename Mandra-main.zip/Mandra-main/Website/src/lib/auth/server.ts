import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { findById, hashPassword, verifyPassword, type User } from "./users";
import {
  PERMISSIONS,
  PERMISSION_LABEL,
  SESSION_COOKIE,
  verifySession,
  type Permission,
  type Role,
} from "./session";
import {
  SCOPE_TUDO,
  leadInScope,
  type LeadScope,
} from "@/lib/prospector/history";
import { findAccount, type Account } from "@/lib/crm/accounts";

/**
 * The authorization boundary.
 *
 * The proxy checks the cookie's signature and stops there, because it must run
 * on every request and cannot read the database. This is where the question is
 * actually answered: the signature said "operator #7", and this asks whether
 * operator #7 still exists, is still active, and hasn't been revoked since the
 * cookie was issued. Every page and every route that does something worth
 * protecting calls one of these.
 */

export type SessionUser = {
  id: string;
  username: string;
  displayName: string;
  role: Role;
  /**
   * The client account a `cliente` belongs to; null for us. Read from the row
   * on every request like `permissions`, so moving or suspending an account
   * takes effect on their next click rather than when the cookie expires.
   */
  accountId: string | null;
  /**
   * Read from the user row on every request, never from the cookie — that is
   * what lets a revoked permission take effect on the operator's next click
   * instead of when their session expires. The admin holds all of them.
   */
  permissions: Permission[];
};

/**
 * Which leads this session may see. The one place a scope is derived, so no
 * page has to decide it and none can decide it differently.
 *
 * A `cliente` with no account is scoped to an id that matches nothing rather
 * than to everything. That state should be unreachable — createUser refuses it
 * — but the safe direction to fail in is closed, and an empty pipeline is a
 * visible bug where a full one is an invisible breach.
 */
export function scopeFor(user: SessionUser): LeadScope {
  if (user.role !== "cliente") return SCOPE_TUDO;
  return { kind: "conta", id: user.accountId ?? "sem-conta" };
}

/** The single entry route for each kind of account. */
export function roleHome(role: Role): string {
  if (role === "admin") return "/admin";
  if (role === "cliente") return "/app";
  return "/operador";
}

/** The environment-configured admin, or null when it isn't set up. */
export function adminAccount(): { username: string; password: string } | null {
  const password =
    process.env.MANDRA_ADMIN_PASSWORD ?? process.env.MANDRA_ADMIN_KEY;
  if (!password) return null;
  return {
    // A default so a deployment that only sets a password still has a name to
    // type. The legacy single-key setup had no username at all.
    username: (process.env.MANDRA_ADMIN_USER ?? "admin").trim().toLowerCase(),
    password,
  };
}

export const ADMIN_SUBJECT = "env:admin";

/** Checks a login against the environment admin. */
export function authenticateAdmin(
  username: string,
  password: string,
): SessionUser | null {
  const account = adminAccount();
  if (!account) return null;
  if (username.trim().toLowerCase() !== account.username) return null;

  // The env password is plain text, so this is a comparison rather than a hash
  // check — but it goes through the same constant-time path as everything else.
  if (!verifyPassword(password, hashOf(account.password))) return null;

  return {
    id: ADMIN_SUBJECT,
    username: account.username,
    // The configured login name, not the word "Administrador": the chrome
    // already prints the role underneath, and the two together read as a
    // stutter rather than as an identity.
    displayName: account.username,
    role: "admin",
    accountId: null,
    permissions: PERMISSIONS,
  };
}

// The env password has no stored hash, so one is derived on first use and kept
// for the life of the process: scrypt is deliberately slow, and this runs on
// every admin login attempt. Going through the same hash-and-compare path as a
// database user is what keeps the timing of the two indistinguishable.
let adminHash: { password: string; hash: string } | null = null;
function hashOf(password: string): string {
  if (adminHash?.password !== password) {
    adminHash = { password, hash: hashPassword(password) };
  }
  return adminHash.hash;
}

/**
 * Who is making this request, or null.
 *
 * Never throws: a missing cookie, a revoked account and a database that isn't
 * there yet are all "nobody", and the caller decides whether that is a redirect
 * or a 401.
 */
export async function currentUser(): Promise<SessionUser | null> {
  const store = await cookies();
  const claims = await verifySession(store.get(SESSION_COOKIE)?.value);
  if (!claims) return null;

  if (claims.sub === ADMIN_SUBJECT) {
    const account = adminAccount();
    // The admin was removed from the environment while a session was open.
    if (!account || account.username !== claims.name) return null;
    return {
      id: ADMIN_SUBJECT,
      username: account.username,
      displayName: account.username,
      role: "admin",
      accountId: null,
      // Not stored anywhere and not meant to be: the account that grants
      // permissions holds all of them, so a permission added later is on for the
      // admin and off for every operator without a migration.
      permissions: PERMISSIONS,
    };
  }

  let user: User | null = null;
  try {
    user = findById(claims.sub);
  } catch {
    return null;
  }
  if (!user || !user.active) return null;
  if (!sessionStillValid(user, claims.iat)) return null;

  return {
    id: user.id,
    username: user.username,
    displayName: user.displayName,
    role: user.role,
    accountId: user.accountId,
    permissions: user.permissions,
  };
}

/** Does this account hold a permission? The admin always does. */
export function can(user: SessionUser | null, permission: Permission): boolean {
  if (!user) return false;
  return user.role === "admin" || user.permissions.includes(permission);
}

/**
 * A session is dead if it was issued before the account's cutoff, which a revoke
 * or a password reset moves to the current millisecond.
 *
 * Both sides are epoch milliseconds, which is the whole reason `iat` is stored
 * that way (see SessionClaims). Anything coarser can't order a login and a
 * revoke that happen in the same second, and both ways of breaking that tie are
 * wrong: one lets a session survive the reset that was meant to end it, the
 * other rejects the login that came after.
 */
function sessionStillValid(user: User, issuedAt: number): boolean {
  const cutoff = Date.parse(user.sessionsValidFrom);
  if (Number.isNaN(cutoff)) return true;
  return issuedAt >= cutoff;
}

/** For pages: sends anonymous visitors to the login form and comes back after. */
export async function requireUser(returnTo?: string): Promise<SessionUser> {
  const user = await currentUser();
  // A client is logged in, just not for this: /admin and /prospector are ours.
  // Sending them home rather than to a login form is the same courtesy an
  // operator gets from requireAdmin — being asked to sign in again when you
  // already are reads as a broken session.
  if (user?.role === "cliente") redirect("/app");
  if (user) return user;

  const next = returnTo ? `?next=${encodeURIComponent(returnTo)}` : "";
  redirect(`/admin/login${next}`);
}

/**
 * For admin-only pages. An operator who guesses the URL is sent back to the CRM
 * rather than to the login form — they are logged in, just not for this.
 */
export async function requireAdmin(returnTo?: string): Promise<SessionUser> {
  const user = await currentUser();
  if (!user) {
    const next = returnTo ? `?next=${encodeURIComponent(returnTo)}` : "";
    redirect(`/admin/login${next}`);
  }
  if (user.role !== "admin") redirect(roleHome(user.role));
  return user;
}

/**
 * For the client portal at /app.
 *
 * Checks three things, and the third is the one that matters: the session is a
 * `cliente`, it carries an account, and **that account is still active**. The
 * account is re-read here rather than trusted from the session for the same
 * reason permissions are re-read — suspending a client has to mean something
 * before their cookie expires, and it is the only lever we have when an
 * arrangement ends.
 *
 * A suspended account lands on the login form with their session cleared rather
 * than on a page explaining the suspension. What happened is a conversation to
 * have with them directly, not a notice from a web app.
 */
export async function requireClient(
  returnTo?: string,
): Promise<{ user: SessionUser; account: Account }> {
  const user = await currentUser();
  if (!user) {
    const next = returnTo ? `?next=${encodeURIComponent(returnTo)}` : "";
    redirect(`/app/login${next}`);
  }
  if (user.role !== "cliente") redirect(roleHome(user.role));

  const account = user.accountId ? findAccount(user.accountId) : null;
  if (!account || !account.active) redirect("/app/login?suspensa=1");

  return { user, account };
}

/**
 * For pages both of *our* roles use — the call queue, above all.
 *
 * Admin and operator, never a client. It exists because the calling screens are
 * mounted twice: once under /admin for us and once under /operador for the
 * people who actually dial. `requireAdmin` on the shared view would have made
 * the operator mount redirect to /operador in a loop, and `requireUser` would
 * have let a client at it.
 *
 * The redirect goes to whichever login matches the tree they were trying to
 * reach, which is why the caller passes `returnTo` rather than this guessing.
 */
export async function requireStaff(returnTo?: string): Promise<SessionUser> {
  const user = await currentUser();
  if (!user) {
    const next = returnTo ? `?next=${encodeURIComponent(returnTo)}` : "";
    const form = returnTo?.startsWith("/operador")
      ? "/operador/login"
      : "/admin/login";
    redirect(`${form}${next}`);
  }
  if (user.role === "cliente") redirect("/app");
  return user;
}

/** The operator portal has its own login route and excludes admin accounts. */
export async function requireOperator(returnTo?: string): Promise<SessionUser> {
  const user = await currentUser();
  if (!user) {
    const next = returnTo ? `?next=${encodeURIComponent(returnTo)}` : "";
    redirect(`/operador/login${next}`);
  }
  if (user.role !== "operador") redirect(roleHome(user.role));
  return user;
}

/**
 * For pages behind a permission. Same shape as requireAdmin: someone who is
 * logged in but not allowed goes back to the CRM, not to the login form.
 */
export async function requirePermission(
  permission: Permission,
  returnTo?: string,
): Promise<SessionUser> {
  const user = await requireUser(returnTo);
  if (!can(user, permission)) redirect("/admin");
  return user;
}

/**
 * For route handlers behind a permission. Returns the 403 to send back, or null
 * when the caller may proceed — so a handler reads as
 * `const denied = await denyWithout("export"); if (denied) return denied;`,
 * the same shape the admin routes already use for the role check.
 */
export async function denyWithout(
  permission: Permission,
): Promise<Response | null> {
  const user = await currentUser();
  if (!user) return unauthorized();
  if (!can(user, permission)) return forbidden(permissionMessage(permission));
  return null;
}

function permissionMessage(permission: Permission): string {
  return `Seu acesso não inclui "${PERMISSION_LABEL[permission]}". Peça ao administrador.`;
}

/**
 * For route handlers that mutate one lead: refuses ids outside the caller's
 * scope.
 *
 * Reads as `const outside = await denyOutsideScope(user, id); if (outside)
 * return outside;` — the same shape as denyWithout(), and in the route for the
 * same reason: the control belongs where the request arrives, not buried in a
 * writer that a future caller might sidestep.
 *
 * Answers 404, not 403. A lead that isn't yours should be indistinguishable
 * from a lead that doesn't exist, or the endpoint becomes a way to ask whether
 * a given id is in somebody else's pipeline.
 */
export async function denyOutsideScope(
  user: SessionUser,
  id: string,
): Promise<Response | null> {
  if (user.role !== "cliente") return null;
  if (id.length > 0 && leadInScope(id, scopeFor(user))) return null;
  return Response.json({ error: "Lead não encontrado." }, { status: 404 });
}

/**
 * For route handlers both of *our* roles use: the `requireStaff` rule, answered
 * with a status instead of a redirect.
 *
 * Reads as `const staff = await staffOrDeny(); if ("denied" in staff) return
 * staff.denied;` — the same shape as the two above, and used by the routes
 * behind the outreach copy, where an operator is as entitled as the admin and a
 * client has no business at all.
 */
export async function staffOrDeny(): Promise<
  { user: SessionUser } | { denied: Response }
> {
  const user = await currentUser();
  if (!user) return { denied: unauthorized() };
  if (user.role === "cliente") {
    return { denied: forbidden("Esta área é da equipe comercial.") };
  }
  return { user };
}

/** For route handlers: a 401 body instead of a redirect to an HTML page. */
export function unauthorized(): Response {
  return Response.json({ error: "Não autenticado." }, { status: 401 });
}

export function forbidden(message?: string): Response {
  return Response.json(
    { error: message ?? "Esta ação é restrita ao administrador." },
    { status: 403 },
  );
}
