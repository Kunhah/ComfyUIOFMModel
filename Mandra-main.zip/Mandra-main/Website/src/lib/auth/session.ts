/**
 * The session cookie: a signed statement of who you are.
 *
 * Nothing is looked up here. The cookie carries the user id, the role and an
 * expiry, and an HMAC over all of it; verifying is a hash and a comparison, no
 * database. That is what lets the proxy check every request to the CRM and the
 * prospector without touching SQLite — Next runs the proxy on the Node runtime,
 * but its own guidance is that a proxy is an optimistic check, not the
 * authorization boundary.
 *
 * Which is why this file is only half the story: a signed cookie cannot know
 * that an account was revoked five minutes ago. `requireUser()` in ./server.ts
 * re-checks the account against the database on every page and every route, and
 * that is the check that actually decides. This one just keeps anonymous traffic
 * out cheaply.
 *
 * Uses Web Crypto rather than `node:crypto` so the same module runs unchanged in
 * the proxy, in route handlers and on a host that decides to run proxies at the
 * edge after all.
 */

/**
 * `cliente` is a customer of ours logging in to their own pipeline at /app, and
 * is the only role that is scoped to one account. It is a role rather than a
 * permission on an operator row because it does not *add* anything — it takes
 * everything away except one account's leads, which is not a shape the
 * permission list can express.
 */
export type Role = "admin" | "operador" | "cliente";

export const ROLES: Role[] = ["admin", "operador", "cliente"];

export function isRole(value: unknown): value is Role {
  return typeof value === "string" && (ROLES as string[]).includes(value);
}

/**
 * What an operator is allowed to do beyond reading the CRM.
 *
 * Deliberately *not* in the cookie. A permission that travels in a signed token
 * cannot be taken away until the token expires, and the whole point of these is
 * that the admin can revoke one and have it mean something before tomorrow.
 * They live on the user row and are re-read by `currentUser()` on every request,
 * the same way `active` is — see lib/auth/users.ts.
 *
 * The admin is not on that list and never needs to be: it holds all of them by
 * definition (see `currentUser`), so a new permission is deny-by-default for
 * operators and automatic for the administrator.
 */
export type Permission = "export" | "b2b";

export const PERMISSIONS: Permission[] = ["export", "b2b"];

/**
 * What a *new* operator gets. Exporting is not on it on purpose: a CSV of the
 * history is the entire lead base in one file, and an account that can take it
 * on the way out is a different kind of account from one that can work leads in
 * the CRM. The admin grants it per person, deliberately.
 */
export const DEFAULT_PERMISSIONS: Permission[] = ["b2b"];

export const PERMISSION_LABEL: Record<Permission, string> = {
  export: "Exportar CSV",
  b2b: "Prospector B2B",
};

export const PERMISSION_HINT: Record<Permission, string> = {
  export:
    "Baixar leads em planilha, no prospector e no histórico. Sem isso a pessoa trabalha os leads pelo CRM, mas não leva a base embora.",
  b2b: "Usar o rastreador de empresas B2B.",
};

export function isPermission(value: unknown): value is Permission {
  return typeof value === "string" && PERMISSIONS.includes(value as Permission);
}

export type SessionClaims = {
  /** `env:admin` for the environment-configured admin, otherwise the user id. */
  sub: string;
  /** The login name, for display. */
  name: string;
  role: Role;
  /**
   * Issued-at, epoch **milliseconds**.
   *
   * Milliseconds rather than the usual seconds because this value is compared
   * against `users.sessions_valid_from`, which a revoke writes at the current
   * millisecond. With second-granularity the two can't be ordered inside the
   * same second, and every way of breaking the tie is wrong in one direction:
   * round the cutoff down and a session issued just before a password reset
   * survives it; compare exactly and the login *after* the reset is rejected as
   * older than it. Same unit on both sides removes the tie entirely.
   */
  iat: number;
  /** Expiry, epoch milliseconds. */
  exp: number;
};

export const SESSION_COOKIE = "mandra_session";

/** Eight hours: a working day, after which you log in again. */
export const SESSION_TTL_SECONDS = 60 * 60 * 8;

/**
 * The signing key.
 *
 * `MANDRA_SESSION_SECRET` is the real answer. Falling back to the admin password
 * keeps a one-variable deployment working, and has a useful side effect:
 * changing the admin password invalidates every outstanding session, including
 * the operators'. Returns null when neither is set — the caller turns that into
 * "no one can log in", which is the right failure for a missing secret.
 */
function secret(): string | null {
  const value =
    process.env.MANDRA_SESSION_SECRET ??
    process.env.MANDRA_ADMIN_PASSWORD ??
    process.env.MANDRA_ADMIN_KEY;
  return value && value.length > 0 ? value : null;
}

export function sessionConfigured(): boolean {
  return secret() !== null;
}

const encoder = new TextEncoder();

async function key(material: string): Promise<CryptoKey> {
  return crypto.subtle.importKey(
    "raw",
    encoder.encode(material),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"],
  );
}

/** base64url without padding — cookie-safe with no percent-encoding. */
function encode(bytes: ArrayBuffer | Uint8Array): string {
  const view = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  let binary = "";
  for (const byte of view) binary += String.fromCharCode(byte);
  return btoa(binary)
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

function decode(value: string): Uint8Array | null {
  try {
    const padded = value.replace(/-/g, "+").replace(/_/g, "/");
    const binary = atob(padded.padEnd(Math.ceil(padded.length / 4) * 4, "="));
    return Uint8Array.from(binary, (char) => char.charCodeAt(0));
  } catch {
    return null;
  }
}

/** Issues a cookie value for a user. Returns null when no secret is configured. */
export async function signSession(
  claims: Omit<SessionClaims, "iat" | "exp">,
): Promise<string | null> {
  const material = secret();
  if (!material) return null;

  const now = Date.now();
  const payload: SessionClaims = {
    ...claims,
    iat: now,
    exp: now + SESSION_TTL_SECONDS * 1000,
  };

  const body = encode(encoder.encode(JSON.stringify(payload)));
  const signature = await crypto.subtle.sign(
    "HMAC",
    await key(material),
    encoder.encode(body),
  );
  return `${body}.${encode(signature)}`;
}

/**
 * Verifies signature and expiry. Returns the claims or null — a bad signature,
 * a tampered payload and an expired session are all the same answer, because
 * telling them apart is only useful to someone probing the cookie.
 */
export async function verifySession(
  token: string | undefined,
): Promise<SessionClaims | null> {
  const material = secret();
  if (!material || !token) return null;

  const [body, signature] = token.split(".");
  if (!body || !signature) return null;

  const provided = decode(signature);
  if (!provided) return null;

  const ok = await crypto.subtle.verify(
    "HMAC",
    await key(material),
    // BufferSource: copy into a fresh buffer so a SharedArrayBuffer-backed view
    // can never reach the verifier.
    new Uint8Array(provided).buffer as ArrayBuffer,
    encoder.encode(body),
  );
  if (!ok) return null;

  const raw = decode(body);
  if (!raw) return null;

  try {
    const claims = JSON.parse(new TextDecoder().decode(raw)) as SessionClaims;
    if (typeof claims.exp !== "number" || typeof claims.iat !== "number") {
      return null;
    }
    if (claims.exp <= Date.now()) return null;
    if (!isRole(claims.role)) return null;
    if (typeof claims.sub !== "string" || claims.sub.length === 0) return null;
    return claims;
  } catch {
    return null;
  }
}

/**
 * Did this request arrive over TLS?
 *
 * `x-forwarded-proto` first, because in the real deployment TLS is terminated by
 * the reverse proxy and Next only ever sees plain HTTP behind it. A client can
 * forge the header, but only on its own request — the worst it buys is dropping
 * `Secure` from its own cookie.
 */
export function isSecureRequest(request: Request): boolean {
  const forwarded = request.headers.get("x-forwarded-proto");
  if (forwarded) return forwarded.split(",")[0]?.trim() === "https";
  try {
    return new URL(request.url).protocol === "https:";
  } catch {
    return false;
  }
}

/**
 * Cookie attributes, in one place: the login route sets them, logout clears them.
 *
 * `secure` follows the transport rather than NODE_ENV. A production build served
 * over plain HTTP — the VPS reached by IP and port, before a domain and a
 * certificate are in front of it — would otherwise set a `Secure` cookie that the
 * browser silently discards, and the login would bounce straight back to the form
 * with no error to explain why.
 */
export function cookieOptions(maxAge: number, secure: boolean) {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure,
    // Root path, not /admin: the prospector and its API routes are behind the
    // same session now, and a cookie scoped to /admin is not sent to them.
    path: "/",
    maxAge,
  };
}
