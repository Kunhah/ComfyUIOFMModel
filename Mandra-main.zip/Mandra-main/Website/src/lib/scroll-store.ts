import { createStore } from "zustand/vanilla";

type ScrollState = {
  /** Page scroll offset in px. */
  scrollY: number;
  /** 0 while the hero fills the viewport, 1 once it has fully scrolled past. */
  heroProgress: number;
};

/**
 * A vanilla (non-React) store on purpose. The globe reads it imperatively
 * inside `useFrame` via `scrollStore.getState()`, so scroll updates drive
 * shader uniforms at 60fps without ever re-rendering React.
 */
export const scrollStore = createStore<ScrollState>(() => ({
  scrollY: 0,
  heroProgress: 0,
}));

export const setScroll = (next: Partial<ScrollState>) =>
  scrollStore.setState(next);

export const getScroll = () => scrollStore.getState();
