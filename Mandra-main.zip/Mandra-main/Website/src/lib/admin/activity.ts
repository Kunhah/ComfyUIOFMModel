import {
  ACTIVITY_LABEL,
  isActivityAction,
  type ActivityFilters,
  type ProspectorActivity,
} from "@/lib/prospector/db";

/**
 * One sentence per audit event, in the admin's language.
 *
 * Shared by the two admin screens and the CSV export rather than living inside
 * whichever page needed it first: an export that describes an event differently
 * from the page it was read on is worse than no export, because the difference
 * only shows up when someone is trying to reconstruct what happened.
 */

/* -------------------------------------------------------------------------- */
/* The view lives in the query string                                          */
/* -------------------------------------------------------------------------- */

/**
 * One parser, one builder, for the page and for its CSV link.
 *
 * The lead history learned this the hard way: a second, page-local parser was
 * what let one screen read `noSite` while the rest of the app wrote `nosite`, so
 * the filter silently did nothing. The export here is just this view with a
 * different path, and it can only stay that way if both sides read the same
 * function.
 */
export const ACTIVITY_PAGE_SIZE = 40;

function one(
  params: Record<string, string | string[] | undefined>,
  key: string,
): string | undefined {
  const value = params[key];
  const first = Array.isArray(value) ? value[0] : value;
  const trimmed = first?.trim();
  return trimmed ? trimmed : undefined;
}

/** A date input posts YYYY-MM-DD; anything else is dropped rather than guessed. */
function isoDate(value: string | undefined): string | undefined {
  return value && /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : undefined;
}

export function parseActivityFilters(
  params: Record<string, string | string[] | undefined>,
): ActivityFilters {
  const action = one(params, "acao");
  const page = Number(one(params, "pagina") ?? 1);

  return {
    actorId: one(params, "usuario"),
    action: isActivityAction(action) ? action : undefined,
    from: isoDate(one(params, "de")),
    to: isoDate(one(params, "ate")),
    page: Number.isFinite(page) && page > 0 ? Math.trunc(page) : 1,
    pageSize: ACTIVITY_PAGE_SIZE,
  };
}

export function activityFiltersToQuery(
  filters: ActivityFilters,
  overrides: Partial<ActivityFilters> = {},
): string {
  const merged = { ...filters, ...overrides };
  const params = new URLSearchParams();
  if (merged.actorId) params.set("usuario", merged.actorId);
  if (merged.action) params.set("acao", merged.action);
  if (merged.from) params.set("de", merged.from);
  if (merged.to) params.set("ate", merged.to);
  // Page 1 is the default, so leaving it out keeps a shared URL readable.
  if (merged.page > 1) params.set("pagina", String(merged.page));
  const query = params.toString();
  return query ? `?${query}` : "";
}

export function hasActivityFilters(filters: ActivityFilters): boolean {
  return Boolean(
    filters.actorId || filters.action || filters.from || filters.to,
  );
}

const VERB: Record<ProspectorActivity["action"], string> = {
  search: "Buscou",
  outreach: "Iniciou contato pelo WhatsApp com",
  status: "Alterou a situação de",
  funnel: "Alterou a etapa de",
  contact: "Atualizou o contato de",
  socials: "Atualizou os perfis de",
  tags: "Atualizou as etiquetas de",
  notes: "Atualizou a anotação de",
  follow_up: "Atualizou o follow-up de",
  call: "Ligou para",
  intake: "Recebeu pelo site",
  call_list: "Montou a lista de ligações",
  // No lead follows this one: the detail carries which variant and what
  // changed, because the subject is the message rather than a business.
  mensagem: "Mensagem de abordagem:",
  atendimento: "Liberou o atendimento de",
  delete: "Excluiu",
};

export function leadLabel(event: ProspectorActivity): string {
  if (!event.leadName) return "um lead";
  if (!event.leadCity) return event.leadName;
  // The UF is captured with the event and can legitimately be missing; printing
  // "Cidade/" for those looks like a truncation bug rather than missing data.
  const place = event.leadUf
    ? `${event.leadCity}/${event.leadUf}`
    : event.leadCity;
  return `${event.leadName} · ${place}`;
}

export function activityDescription(event: ProspectorActivity): string {
  // A search has no lead: its detail already reads "nicho em Cidade/UF · N
  // retornados", so pinning "um lead" to it would be wrong twice. Building a
  // call list is the same shape — it is an event about a set, not about a row.
  if (event.action === "search") return `Buscou ${event.detail ?? "leads"}`;
  if (event.action === "call_list") {
    return `${VERB.call_list} ${event.detail ?? "sem detalhes"}`;
  }
  // Nor does editing the opener: it is an event about the message every lead
  // receives from now on, so pinning "um lead" to it would be wrong twice over.
  if (event.action === "mensagem") {
    return `${VERB.mensagem} ${event.detail ?? "sem detalhes"}`;
  }

  const detail = event.detail ? ` · ${event.detail}` : "";
  return `${VERB[event.action]} ${leadLabel(event)}${detail}`;
}

/**
 * The audit's CSV shape, here rather than in the route handler for the same
 * reason the lead columns live in lib/prospector/csv.ts: a column list inside a
 * handler is a column list that drifts from whatever reads the file next.
 */
export const ACTIVITY_CSV_HEADERS = [
  "quando",
  "usuario",
  "nome",
  "acao",
  "descricao",
  "lead",
  "cidade",
  "uf",
  "detalhe",
];

export function activityCsvRow(event: ProspectorActivity): string[] {
  return [
    // Left as stored — ISO-8601 UTC. A spreadsheet can convert it; a pt-BR
    // string that has already lost the timezone cannot be converted back.
    event.occurredAt,
    event.username,
    event.displayName,
    ACTIVITY_LABEL[event.action],
    activityDescription(event),
    event.leadName ?? "",
    event.leadCity ?? "",
    event.leadUf ?? "",
    event.detail ?? "",
  ];
}
