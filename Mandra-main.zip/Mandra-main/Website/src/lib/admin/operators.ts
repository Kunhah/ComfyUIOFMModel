import { adminAccount, ADMIN_SUBJECT } from "@/lib/auth/server";
import { SESSION_TTL_SECONDS, type Permission } from "@/lib/auth/session";
import { listUsers, type User } from "@/lib/auth/users";
import { knownActors } from "@/lib/prospector/db";

/**
 * Who the admin can look at.
 *
 * Three kinds of row and one shape, because the screens that read this care
 * about "an account with a history" rather than about where the account is
 * stored. The environment admin has no database row (see lib/auth/users.ts) and
 * an operator who was deleted still has an audit trail — dropping either from
 * the list would quietly rewrite what the tool was used for.
 */

export type AccountKind = "admin" | "operador" | "removido";

export type OperatorAccount = {
  /** The actor id the audit tables carry: `env:admin`, or the user's uuid. */
  id: string;
  username: string;
  displayName: string;
  active: boolean;
  kind: AccountKind;
  /** Null for the admin (holds everything) and for deleted accounts. */
  permissions: Permission[] | null;
  createdAt: string | null;
  createdBy: string | null;
  lastLoginAt: string | null;
  /** Best-effort; see probablySignedIn. */
  signedIn: boolean;
};

export const KIND_LABEL: Record<AccountKind, string> = {
  admin: "Administrador",
  operador: "Operador",
  removido: "Acesso removido",
};

/**
 * Is this account probably still inside?
 *
 * Inference, not observation: the session cookie is stateless and lives in a
 * browser nothing here can ask. It says they logged in, no revoke or password
 * reset has invalidated that login since, and the eight-hour window has not run
 * out — which is enough to answer the question the admin actually asks, "did the
 * sign-out I just clicked land?". Labelled "sessão aberta", never "online".
 */
export function probablySignedIn(user: User): boolean {
  if (!user.active || !user.lastLoginAt) return false;
  const login = Date.parse(user.lastLoginAt);
  if (Number.isNaN(login)) return false;
  const cutoff = Date.parse(user.sessionsValidFrom);
  if (!Number.isNaN(cutoff) && login < cutoff) return false;
  return Date.now() - login < SESSION_TTL_SECONDS * 1000;
}

function fromUser(user: User): OperatorAccount {
  return {
    id: user.id,
    username: user.username,
    displayName: user.displayName,
    active: user.active,
    kind: user.role === "admin" ? "admin" : "operador",
    permissions: user.permissions,
    createdAt: user.createdAt,
    createdBy: user.createdBy,
    lastLoginAt: user.lastLoginAt,
    signedIn: probablySignedIn(user),
  };
}

/** The accounts that exist right now: the environment admin, then the users. */
export function currentAccounts(): OperatorAccount[] {
  const admin = adminAccount();
  return [
    ...(admin
      ? [
          {
            id: ADMIN_SUBJECT,
            username: admin.username,
            displayName: admin.username,
            active: true,
            kind: "admin" as const,
            permissions: null,
            createdAt: null,
            createdBy: null,
            lastLoginAt: null,
            // The admin's login isn't recorded anywhere — it has no row to
            // record it on — so there is nothing to infer a session from.
            signedIn: false,
          },
        ]
      : []),
    ...listUsers().map(fromUser),
  ];
}

/**
 * Everyone with a history: the accounts above, plus the actors that only exist
 * in the audit because their account was deleted afterwards.
 */
export function accountDirectory(): OperatorAccount[] {
  const current = currentAccounts();
  const live = new Set(current.map((account) => account.id));

  const archived: OperatorAccount[] = knownActors()
    .filter((actor) => !live.has(actor.actorId))
    .map((actor) => ({
      id: actor.actorId,
      username: actor.username,
      displayName: actor.displayName,
      active: false,
      kind: "removido",
      permissions: null,
      createdAt: null,
      createdBy: null,
      lastLoginAt: null,
      signedIn: false,
    }));

  return [...current, ...archived];
}

export function findAccount(id: string): OperatorAccount | null {
  return accountDirectory().find((account) => account.id === id) ?? null;
}
