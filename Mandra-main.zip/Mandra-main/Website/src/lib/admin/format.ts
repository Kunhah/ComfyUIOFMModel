/**
 * Dates and numbers for the admin screens.
 *
 * The timezone is pinned to America/Sao_Paulo rather than left to the server's
 * locale: the audit's timestamps are UTC, the container's clock is whatever the
 * host decided, and "18:40" meaning two different things on two deploys is the
 * kind of bug nobody reports — they just stop trusting the column. The SQL
 * "today" filters fold with `localtime` for the same reason, so the two agree as
 * long as the container is on São Paulo time.
 */

const TIME_ZONE = "America/Sao_Paulo";

export const fmt = (value: number): string => value.toLocaleString("pt-BR");

const dateTimeFormat = new Intl.DateTimeFormat("pt-BR", {
  dateStyle: "short",
  timeStyle: "short",
  timeZone: TIME_ZONE,
});

const dateFormat = new Intl.DateTimeFormat("pt-BR", {
  dateStyle: "short",
  timeZone: TIME_ZONE,
});

export function dateTime(value: string | null, fallback = "—"): string {
  if (!value) return fallback;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? fallback : dateTimeFormat.format(date);
}

export function shortDate(value: string | null, fallback = "—"): string {
  if (!value) return fallback;
  // A bare YYYY-MM-DD (the follow-up column) is a calendar day, not an instant.
  // Parsing it as a Date makes it midnight UTC, which in São Paulo is the day
  // before — so a follow-up set for the 3rd would display as the 2nd.
  const bare = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (bare) return `${bare[3]}/${bare[2]}/${bare[1]}`;

  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? fallback : dateFormat.format(date);
}

/** Whole days between a timestamp and now, floored. Negative reads as 0. */
export function daysSince(value: string | null): number | null {
  if (!value) return null;
  const then = Date.parse(value);
  if (Number.isNaN(then)) return null;
  return Math.max(0, Math.floor((Date.now() - then) / 86_400_000));
}

/** "hoje" / "ontem" / "há 5 dias", for a last-seen column that is read at a glance. */
export function sinceLabel(value: string | null): string {
  const days = daysSince(value);
  if (days === null) return "nunca";
  if (days === 0) return "hoje";
  if (days === 1) return "ontem";
  return `há ${days} dias`;
}
