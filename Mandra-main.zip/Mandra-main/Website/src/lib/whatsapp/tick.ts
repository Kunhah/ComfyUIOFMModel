import { dispatchDue } from "./scheduler";
import { whatsappConfigured } from "./evolution";

/**
 * The heartbeat that makes scheduled messages actually send.
 *
 * A timer rather than a cron container, because the queue is already durable:
 * `wa_jobs` holds the truth, and this only asks "anything due?" every half
 * minute. Losing the timer to a restart therefore costs nothing but the delay —
 * the next container picks up the same rows, including the ones that came due
 * while nobody was running. That is the whole reason the queue is in SQLite and
 * not in `setTimeout` (see scheduler.ts).
 *
 * Thirty seconds because a reminder is promised to the minute and a cron
 * expression has minute resolution; anything longer makes "às 9h" mean "às 9h e
 * pouco", and anything shorter is a query per second against a table that is
 * usually empty for a scheduler that can't act faster than its own granularity.
 */
const INTERVAL_MS = 30_000;

/**
 * Guards against a tick that outlives its interval.
 *
 * `dispatchDue` awaits a network call per job, so a slow or hanging bridge can
 * take longer than 30s with a full batch. Without this the timer starts a second
 * pass over rows the first one has not finished advancing yet, and the client
 * gets the same reminder twice — which is precisely the failure a durable queue
 * was supposed to remove.
 */
let running = false;
let timer: NodeJS.Timeout | null = null;

export function startScheduler(): void {
  // Started twice would double every reminder. Next's instrumentation hook runs
  // once per process, but HMR in dev re-evaluates the module.
  if (timer) return;

  timer = setInterval(() => {
    void tick();
  }, INTERVAL_MS);

  // Node keeps the process alive for a pending timer, which would hold a `next
  // build` or a script open for no reason. The server has its own reason to stay
  // up; this must not be one.
  timer.unref?.();
}

async function tick(): Promise<void> {
  if (running) return;
  // Nothing can be sent without a bridge, and every job would fail and burn its
  // one retry. A deployment with no WhatsApp configured is a supported state.
  if (!whatsappConfigured()) return;

  running = true;
  try {
    const result = await dispatchDue();
    if (result.sent || result.failed || result.skipped) {
      console.log(
        JSON.stringify({ service: "whatsapp", event: "tick", ...result }),
      );
    }
  } catch (error) {
    // Never rethrow: this runs on a timer with no caller, so an exception here
    // is an unhandled rejection that can take the process down — and with it the
    // marketing site, over a reminder.
    console.error(
      JSON.stringify({
        service: "whatsapp",
        event: "tick.failed",
        message: error instanceof Error ? error.message : String(error),
      }),
    );
  } finally {
    running = false;
  }
}
