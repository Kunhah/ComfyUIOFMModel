import assert from "node:assert/strict";
import { test } from "node:test";
import { parseInbound } from "./evolution";

/**
 * `instance` is the only field in an inbound webhook that says which of our
 * paired numbers a message was sent *to* — the sender's number says who wrote,
 * never who they wrote to. The webhook joins it to `accounts.wa_instance` to
 * decide whose CRM the conversation belongs in, so losing it does not fail
 * loudly: it files one client's customer under another's pipeline, and the agent
 * answers holding the wrong company's history.
 *
 * Hence a test for a field that looks like a passthrough.
 */

const message = (extra: Record<string, unknown>) => ({
  event: "messages.upsert",
  ...extra,
  data: {
    key: {
      remoteJid: "5531999998888@s.whatsapp.net",
      fromMe: false,
      id: "ABC",
    },
    pushName: "Maria",
    message: { conversation: "oi" },
  },
});

test("the instance travels with the message", () => {
  const parsed = parseInbound(message({ instance: "padaria-do-ze" }));
  assert.equal(parsed?.instance, "padaria-do-ze");
  assert.equal(parsed?.phone, "5531999998888");
});

test("the v1 spelling is accepted", () => {
  // Still what an older bridge sends, and the difference is invisible until a
  // real client's messages start arriving unrouted.
  const parsed = parseInbound(message({ instanceName: "padaria-do-ze" }));
  assert.equal(parsed?.instance, "padaria-do-ze");
});

test("a payload with no instance parses, and says so", () => {
  // Null rather than a throw or a default: the webhook has to be able to tell
  // "unroutable" apart from "ours", and defaulting either way delivers a
  // stranger's message into the wrong pipeline.
  const parsed = parseInbound(message({}));
  assert.equal(parsed?.instance, null);
});

test("a blank instance is null, not an empty string", () => {
  // "" would match no account and is not a name; treating it as one would put an
  // empty string in the logs where a misconfiguration should be.
  assert.equal(parseInbound(message({ instance: "   " }))?.instance, null);
});

test("what is not a person's message is still dropped, instance or not", () => {
  // The routing field must not accidentally make an unwanted event routable.
  const group = {
    event: "messages.upsert",
    instance: "padaria-do-ze",
    data: {
      key: { remoteJid: "12345@g.us", fromMe: false, id: "X" },
      message: { conversation: "oi" },
    },
  };
  assert.equal(parseInbound(group), null);

  const echo = {
    event: "messages.upsert",
    instance: "padaria-do-ze",
    data: {
      key: { remoteJid: "5531999998888@s.whatsapp.net", fromMe: true, id: "Y" },
      message: { conversation: "nossa resposta" },
    },
  };
  assert.equal(parseInbound(echo), null);
});
