import test from "node:test";
import assert from "node:assert/strict";

import { parseAgentReply } from "@/lib/whatsapp/actions";

const SP = "America/Sao_Paulo";
const NOW = new Date("2026-09-01T12:00:00Z"); // 09:00 in São Paulo
const context = { timezone: SP, now: NOW };

const envelope = (actions: unknown[]): string =>
  JSON.stringify({ mensagem: "Combinado!", acoes: actions });

test("reads the message and no actions from a plain reply", () => {
  const reply = parseAgentReply(
    JSON.stringify({ mensagem: "Bom dia! Como posso ajudar?", acoes: [] }),
    context,
  );
  assert.equal(reply.message, "Bom dia! Como posso ajudar?");
  assert.deepEqual(reply.actions, []);
});

test("still sends the words when the model ignores the envelope", () => {
  // The sentence is usually a perfectly good reply and only the structure is
  // missing; losing the turn entirely leaves a customer on read.
  const reply = parseAgentReply("Claro, podemos conversar amanhã.", context);
  assert.equal(reply.message, "Claro, podemos conversar amanhã.");
  assert.deepEqual(reply.actions, []);
});

test("digs the object out of fences and preamble", () => {
  const raw = 'Claro!\n```json\n{"mensagem":"oi","acoes":[]}\n```';
  assert.equal(parseAgentReply(raw, context).message, "oi");
});

test("a brace inside the message text does not close the object early", () => {
  const raw = '{"mensagem":"mande {seu nome} por favor","acoes":[]}';
  assert.equal(
    parseAgentReply(raw, context).message,
    "mande {seu nome} por favor",
  );
});

test("reads a local wall time in the conversation's timezone", () => {
  // The model is told to write local time precisely so it never has to compute
  // an offset; 14:00 in São Paulo is 17:00Z.
  const reply = parseAgentReply(
    envelope([
      {
        tipo: "agendar",
        titulo: "Call de proposta",
        quando: "2026-09-05T14:00",
      },
    ]),
    context,
  );
  assert.equal(reply.actions.length, 1);
  const action = reply.actions[0];
  assert.equal(action.type, "agendar");
  if (action.type !== "agendar") return;
  assert.equal(action.startsAt, "2026-09-05T17:00:00.000Z");
  assert.equal(action.timezone, SP);
  assert.equal(action.durationMinutes, 30);
});

test("honours a timestamp that carries its own offset", () => {
  const reply = parseAgentReply(
    envelope([{ tipo: "agendar", quando: "2026-09-05T14:00:00-03:00" }]),
    context,
  );
  const action = reply.actions[0];
  assert.equal(
    action?.type === "agendar" && action.startsAt,
    "2026-09-05T17:00:00.000Z",
  );
});

test("refuses a time in the past and says why", () => {
  const reply = parseAgentReply(
    envelope([{ tipo: "agendar", quando: "2026-08-01T14:00" }]),
    context,
  );
  assert.deepEqual(reply.actions, []);
  assert.match(reply.rejected[0], /já passou/);
});

test("refuses a date beyond the horizon", () => {
  const reply = parseAgentReply(
    envelope([{ tipo: "lembrete", quando: "2034-01-01T09:00", texto: "oi" }]),
    context,
  );
  assert.deepEqual(reply.actions, []);
  assert.match(reply.rejected[0], /mais de 365 dias/);
});

test("refuses a recurrence that would message the client every minute", () => {
  // The rule this whole file exists for. `* * * * *` is valid cron and is what a
  // confused model emits for "lembrar sempre".
  const reply = parseAgentReply(
    envelope([{ tipo: "lembrete_recorrente", cron: "* * * * *", texto: "oi" }]),
    context,
  );
  assert.deepEqual(reply.actions, []);
  assert.match(reply.rejected[0], /mínimo/);
});

test("refuses a recurrence whose gap is short only sometimes", () => {
  // 09:00 and 09:30 daily is 30 minutes apart once a day; reading the fields
  // rather than sampling consecutive runs would call this a daily reminder.
  const reply = parseAgentReply(
    envelope([
      { tipo: "lembrete_recorrente", cron: "0,30 9 * * *", texto: "oi" },
    ]),
    context,
  );
  assert.deepEqual(reply.actions, []);
  assert.match(reply.rejected[0], /mínimo/);
});

test("accepts a weekly recurrence and caps the repetitions", () => {
  const reply = parseAgentReply(
    envelope([
      {
        tipo: "lembrete_recorrente",
        cron: "0 9 * * 1",
        texto: "Bom dia! Seguimos com a proposta?",
        repeticoes: 500,
      },
    ]),
    context,
  );
  const action = reply.actions[0];
  assert.equal(action?.type, "lembrete_recorrente");
  if (action?.type !== "lembrete_recorrente") return;
  assert.equal(action.maxRuns, 12);
  assert.equal(action.cron, "0 9 * * 1");
});

test("a recurrence always ends, even when the model asks for none", () => {
  const reply = parseAgentReply(
    envelope([{ tipo: "lembrete_recorrente", cron: "0 9 * * 1", texto: "oi" }]),
    context,
  );
  const action = reply.actions[0];
  assert.equal(action?.type === "lembrete_recorrente" && action.maxRuns, 4);
});

test("refuses a reminder with nothing to say", () => {
  // It would fire on time and send an empty WhatsApp message.
  const reply = parseAgentReply(
    envelope([{ tipo: "lembrete", quando: "2026-09-02T09:00" }]),
    context,
  );
  assert.deepEqual(reply.actions, []);
  assert.match(reply.rejected[0], /sem texto/);
});

test("refuses an unparseable cron and an impossible one", () => {
  const bad = parseAgentReply(
    envelope([
      { tipo: "lembrete_recorrente", cron: "toda segunda", texto: "oi" },
    ]),
    context,
  );
  assert.match(bad.rejected[0], /cron inválida/);

  const never = parseAgentReply(
    envelope([
      { tipo: "lembrete_recorrente", cron: "0 9 30 2 *", texto: "oi" },
    ]),
    context,
  );
  assert.match(never.rejected[0], /nunca acontece/);
});

test("falls back to the conversation's timezone and rejects a bad one", () => {
  const bad = parseAgentReply(
    envelope([
      { tipo: "agendar", quando: "2026-09-05T14:00", fuso: "Marte/Olympus" },
    ]),
    context,
  );
  assert.match(bad.rejected[0], /Fuso horário inválido/);

  const good = parseAgentReply(
    envelope([
      { tipo: "agendar", quando: "2026-09-05T14:00", fuso: "Europe/Lisbon" },
    ]),
    context,
  );
  const action = good.actions[0];
  assert.equal(action?.type === "agendar" && action.timezone, "Europe/Lisbon");
  // 14:00 in Lisbon in September (WEST, UTC+1) is 13:00Z.
  assert.equal(
    action?.type === "agendar" && action.startsAt,
    "2026-09-05T13:00:00.000Z",
  );
});

test("accepts a duration written as a string and clamps an absurd one", () => {
  const reply = parseAgentReply(
    envelope([
      { tipo: "agendar", quando: "2026-09-05T14:00", duracao_min: "45" },
      { tipo: "agendar", quando: "2026-09-06T14:00", duracao_min: 100000 },
    ]),
    context,
  );
  const [first, second] = reply.actions;
  assert.equal(first?.type === "agendar" && first.durationMinutes, 45);
  assert.equal(second?.type === "agendar" && second.durationMinutes, 480);
});

test("caps how many actions one turn may carry", () => {
  const many = Array.from({ length: 9 }, (_, i) => ({
    tipo: "lembrete",
    quando: `2026-09-0${i + 2}T09:00`,
    texto: "oi",
  }));
  const reply = parseAgentReply(envelope(many), context);
  assert.equal(reply.actions.length, 4);
  assert.match(reply.rejected.at(-1)!, /4 primeiras/);
});

test("passes handoff and cancellation through", () => {
  const reply = parseAgentReply(
    envelope([
      { tipo: "transferir", motivo: "cliente pediu falar com humano" },
      { tipo: "cancelar_lembretes" },
      { tipo: "dar_desconto", valor: 90 },
    ]),
    context,
  );
  assert.equal(reply.actions[0]?.type, "transferir");
  assert.equal(reply.actions[1]?.type, "cancelar_lembretes");
  assert.equal(reply.actions.length, 2);
  assert.match(reply.rejected[0], /Ação desconhecida/);
});
