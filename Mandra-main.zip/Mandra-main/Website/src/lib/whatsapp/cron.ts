/**
 * Cron expressions, evaluated in a named timezone.
 *
 * The AI is allowed to hand us a recurrence — "every Monday at 9" — and the only
 * honest way to store that is the expression itself, not a list of pre-computed
 * timestamps: a reminder that runs for a year is 52 rows nobody can edit, and
 * changing the time means finding all of them. So a job keeps its `cron` string
 * and this file answers the one question the scheduler asks: given now, when is
 * the next fire?
 *
 * Timezone is a parameter and not an afterthought. A reminder is a promise made
 * in the client's wall clock — "segunda às 9h" means 9am in São Paulo whatever
 * the container's TZ happens to be — and a container's TZ is UTC in every
 * deployment we have. Computing in UTC and hoping would send every morning
 * reminder at 6am local.
 *
 * No dependency. `croner` and `node-cron` both do this, but both also bring a
 * scheduler we don't want: the jobs live in SQLite and survive restarts, so the
 * runtime half would be dead weight wrapping a parser we can write in a page.
 */

/** Five fields, Vixie order: minute hour day-of-month month day-of-week. */
export type CronFields = {
  minute: number[];
  hour: number[];
  /** 1-31. */
  dayOfMonth: number[];
  /** 1-12. */
  month: number[];
  /** 0-6, Sunday 0. 7 is folded to 0 on parse. */
  dayOfWeek: number[];
  /**
   * Whether each day field was written as `*`. Vixie cron ORs the two day
   * fields when both are restricted ("1st of the month, and every Friday") but
   * ANDs a restricted one with an unrestricted one — which is the only reading
   * that makes `0 9 * * 1` mean Mondays rather than every day.
   */
  domRestricted: boolean;
  dowRestricted: boolean;
};

const MONTHS = [
  "jan",
  "feb",
  "mar",
  "apr",
  "may",
  "jun",
  "jul",
  "aug",
  "sep",
  "oct",
  "nov",
  "dec",
];

const DAYS = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];

/**
 * Shorthands people (and models) write instead of five fields. `@hourly` and
 * friends are in every cron implementation, and a model that has seen crontabs
 * will emit them; rejecting them would fail a reminder for a spelling.
 */
const ALIASES: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

export class CronError extends Error {}

/**
 * Parses an expression, or throws CronError with a message safe to show an
 * operator — these come from a language model, so a bad one is an expected
 * outcome rather than a bug, and the admin screen prints the reason.
 */
export function parseCron(expression: string): CronFields {
  const raw = expression.trim().toLowerCase();
  if (!raw) throw new CronError("Expressão cron vazia.");

  const normalised = ALIASES[raw] ?? raw;
  const parts = normalised.split(/\s+/);
  // Six fields is a seconds-resolution cron. We refuse rather than silently
  // dropping the field: a job that fires 60x more often than asked is the worst
  // possible interpretation, and the scheduler's tick can't do seconds anyway.
  if (parts.length !== 5) {
    throw new CronError(
      `Expressão cron precisa de 5 campos (minuto hora dia mês dia-da-semana), recebi ${parts.length}.`,
    );
  }

  const [min, hr, dom, mon, dow] = parts;
  return {
    minute: field(min, 0, 59, "minuto"),
    hour: field(hr, 0, 23, "hora"),
    dayOfMonth: field(dom, 1, 31, "dia do mês"),
    month: field(mon, 1, 12, "mês", MONTHS, 1),
    dayOfWeek: field(dow, 0, 7, "dia da semana", DAYS, 0).map((d) =>
      d === 7 ? 0 : d,
    ),
    domRestricted: dom !== "*",
    dowRestricted: dow !== "*",
  };
}

/**
 * One field. Accepts a wildcard, a bare value, a range, a stepped wildcard or a
 * stepped range, and comma-separated lists of any of those.
 */
function field(
  spec: string,
  min: number,
  max: number,
  label: string,
  names?: string[],
  nameBase = 0,
): number[] {
  const values = new Set<number>();

  for (const part of spec.split(",")) {
    const [range, stepText] = part.split("/");
    const step = stepText === undefined ? 1 : Number(stepText);
    if (!Number.isInteger(step) || step < 1) {
      throw new CronError(`Passo inválido em "${label}": ${part}`);
    }

    let lo: number;
    let hi: number;
    if (range === "*") {
      lo = min;
      hi = max;
    } else {
      const [from, to] = range.split("-");
      lo = value(from, min, max, label, names, nameBase);
      // `5/2` with no upper bound means "from 5 to the end of the field", which
      // is how every cron reads a step on a bare number.
      hi =
        to === undefined
          ? stepText === undefined
            ? lo
            : max
          : value(to, min, max, label, names, nameBase);
    }

    if (lo > hi)
      throw new CronError(`Intervalo invertido em "${label}": ${part}`);
    for (let v = lo; v <= hi; v += step) values.add(v);
  }

  if (values.size === 0) throw new CronError(`Campo "${label}" vazio.`);
  return [...values].sort((a, b) => a - b);
}

function value(
  token: string,
  min: number,
  max: number,
  label: string,
  names: string[] | undefined,
  nameBase: number,
): number {
  if (names) {
    const index = names.indexOf(token.slice(0, 3));
    if (index >= 0) return index + nameBase;
  }
  const n = Number(token);
  if (!Number.isInteger(n) || n < min || n > max) {
    throw new CronError(`Valor inválido em "${label}": ${token}`);
  }
  return n;
}

/** Wall-clock fields, as read in some timezone. */
type Wall = {
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
};

// Formatters are the expensive part of every conversion and there are only ever
// a handful of timezones in play, so they are built once and kept.
const formatters = new Map<string, Intl.DateTimeFormat>();

function formatter(timeZone: string): Intl.DateTimeFormat {
  let found = formatters.get(timeZone);
  if (!found) {
    try {
      found = new Intl.DateTimeFormat("en-US", {
        timeZone,
        hour12: false,
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      });
    } catch {
      throw new CronError(`Fuso horário desconhecido: ${timeZone}`);
    }
    formatters.set(timeZone, found);
  }
  return found;
}

/** Reads an instant as wall-clock fields in `timeZone`. */
function wallOf(instant: number, timeZone: string): Wall & { second: number } {
  const parts = formatter(timeZone).formatToParts(new Date(instant));
  const get = (type: string): number =>
    Number(parts.find((p) => p.type === type)?.value ?? "0");
  return {
    // `hour12: false` still prints midnight as 24 in some ICU versions, which
    // would put the day one hour into the future when it is folded back.
    year: get("year"),
    month: get("month"),
    day: get("day"),
    hour: get("hour") % 24,
    minute: get("minute"),
    second: get("second"),
  };
}

/** The timezone's offset from UTC at an instant, in minutes (east positive). */
function offsetAt(instant: number, timeZone: string): number {
  const w = wallOf(instant, timeZone);
  const asUtc = Date.UTC(
    w.year,
    w.month - 1,
    w.day,
    w.hour,
    w.minute,
    w.second,
  );
  // Round to the minute: the difference is exact in seconds, and floating a
  // stray millisecond through would make the fixed point below oscillate.
  return Math.round((asUtc - instant) / 60000);
}

/**
 * Turns wall-clock fields in `timeZone` into a real instant.
 *
 * Two passes because the offset depends on the answer: to know whether São Paulo
 * was at -03 you need the instant, and to get the instant you need the offset.
 * Guessing with the offset at the naive timestamp and then re-reading it at the
 * guess converges everywhere outside a DST transition, and inside one it lands
 * on the side the transition moved to — which for a reminder is the right
 * failure: it fires once, an hour off, rather than not at all.
 */
export function wallToInstant(wall: Wall, timeZone: string): number {
  const naive = Date.UTC(
    wall.year,
    wall.month - 1,
    wall.day,
    wall.hour,
    wall.minute,
    0,
  );
  const first = naive - offsetAt(naive, timeZone) * 60000;
  const second = naive - offsetAt(first, timeZone) * 60000;
  return second;
}

/** Days in a month, 1-indexed month. */
function daysInMonth(year: number, month: number): number {
  return new Date(Date.UTC(year, month, 0)).getUTCDate();
}

function dayOfWeek(year: number, month: number, day: number): number {
  return new Date(Date.UTC(year, month - 1, day)).getUTCDay();
}

function dayMatches(fields: CronFields, wall: Wall): boolean {
  const dom = fields.dayOfMonth.includes(wall.day);
  const dow = fields.dayOfWeek.includes(
    dayOfWeek(wall.year, wall.month, wall.day),
  );
  // The Vixie rule. Both restricted → either may satisfy; otherwise the
  // restricted one decides and the `*` one abstains.
  if (fields.domRestricted && fields.dowRestricted) return dom || dow;
  if (fields.domRestricted) return dom;
  if (fields.dowRestricted) return dow;
  return true;
}

/**
 * The next instant at or after `after` that the expression matches, or null when
 * there is none within the horizon.
 *
 * Null is a real answer, not an error: `0 0 30 2 *` — the 30th of February — is
 * a perfectly parseable expression that never happens, and a scheduler that
 * loops forever looking for it is worse than one that reports the job as dead.
 * Four years is past any leap-year cycle a day-of-month/month pair can hide in.
 */
export function nextRun(
  fields: CronFields,
  after: Date | number,
  timeZone: string,
): Date | null {
  const from = typeof after === "number" ? after : after.getTime();
  // Start at the next whole minute. Cron has minute resolution, and matching the
  // current minute would re-fire a job the scheduler just ran.
  const start = Math.floor(from / 60000) * 60000 + 60000;
  const w = wallOf(start, timeZone);

  const cursor: Wall = {
    year: w.year,
    month: w.month,
    day: w.day,
    hour: w.hour,
    minute: w.minute,
  };
  const horizon = cursor.year + 5;

  // Walks the calendar by whole fields rather than minute by minute: a yearly
  // job is ~525.600 minutes away and testing each one takes long enough to
  // notice on a tick that holds the event loop.
  while (cursor.year < horizon) {
    if (!fields.month.includes(cursor.month)) {
      cursor.month += 1;
      if (cursor.month > 12) {
        cursor.month = 1;
        cursor.year += 1;
      }
      cursor.day = 1;
      cursor.hour = 0;
      cursor.minute = 0;
      continue;
    }

    if (cursor.day > daysInMonth(cursor.year, cursor.month)) {
      cursor.month += 1;
      if (cursor.month > 12) {
        cursor.month = 1;
        cursor.year += 1;
      }
      cursor.day = 1;
      cursor.hour = 0;
      cursor.minute = 0;
      continue;
    }

    if (!dayMatches(fields, cursor)) {
      cursor.day += 1;
      cursor.hour = 0;
      cursor.minute = 0;
      continue;
    }

    if (!fields.hour.includes(cursor.hour)) {
      cursor.hour += 1;
      cursor.minute = 0;
      if (cursor.hour > 23) {
        cursor.hour = 0;
        cursor.day += 1;
      }
      continue;
    }

    if (!fields.minute.includes(cursor.minute)) {
      cursor.minute += 1;
      if (cursor.minute > 59) {
        cursor.minute = 0;
        cursor.hour += 1;
        if (cursor.hour > 23) {
          cursor.hour = 0;
          cursor.day += 1;
        }
      }
      continue;
    }

    const instant = wallToInstant(cursor, timeZone);
    // A DST spring-forward can map a matched wall time onto an instant that has
    // already passed (02:30 simply does not exist, and the fold lands before the
    // cursor). Stepping a minute keeps the walk monotonic instead of returning a
    // time in the past, which the scheduler would fire immediately and forever.
    if (instant >= start) return new Date(instant);
    cursor.minute += 1;
    if (cursor.minute > 59) {
      cursor.minute = 0;
      cursor.hour += 1;
      if (cursor.hour > 23) {
        cursor.hour = 0;
        cursor.day += 1;
      }
    }
  }

  return null;
}

/** Parse-and-compute, for callers that hold the string rather than the fields. */
export function nextRunOf(
  expression: string,
  after: Date | number,
  timeZone: string,
): Date | null {
  return nextRun(parseCron(expression), after, timeZone);
}

/** True when the expression parses. For validating what the model sent. */
export function isValidCron(expression: string): boolean {
  try {
    parseCron(expression);
    return true;
  } catch {
    return false;
  }
}

/**
 * A plain-Portuguese rendering, for the admin list and for the confirmation the
 * bot sends back. Only the shapes the agent is told to produce get a sentence;
 * anything else prints the expression, which is honest rather than wrong.
 */
export function describeCron(expression: string): string {
  let fields: CronFields;
  try {
    fields = parseCron(expression);
  } catch {
    return expression;
  }

  // Every sentence below is "<which days> às <time>", so a job that fires more
  // than once a day has no sentence in this vocabulary. Saying "todos os dias"
  // for `*/7 * * * *` would drop the frequency entirely — the one part of that
  // expression an operator needs to see — so those print the expression instead.
  if (fields.hour.length !== 1 || fields.minute.length !== 1) return expression;
  const time = ` às ${String(fields.hour[0]).padStart(2, "0")}:${String(fields.minute[0]).padStart(2, "0")}`;

  const names = [
    "domingo",
    "segunda",
    "terça",
    "quarta",
    "quinta",
    "sexta",
    "sábado",
  ];

  if (!fields.domRestricted && !fields.dowRestricted) {
    return `todos os dias${time}`;
  }
  if (fields.dowRestricted && !fields.domRestricted) {
    const list = fields.dayOfWeek.map((d) => names[d]).join(", ");
    return `toda ${list}${time}`;
  }
  if (
    fields.domRestricted &&
    !fields.dowRestricted &&
    fields.dayOfMonth.length === 1
  ) {
    return `todo dia ${fields.dayOfMonth[0]}${time}`;
  }
  return expression;
}
