import test, { afterEach, before } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";

/**
 * The loop, end to end: a job in the table, a tick, a message on the wire.
 *
 * Everything else in this folder is unit-tested against pure functions. This is
 * the one that would catch the failures those cannot — a job that fires twice, a
 * recurrence that never ends, a send that reports success after the bridge
 * refused it — because those live in the interaction between the queue, the
 * sender and the clock rather than in any of them.
 *
 * The database is a real SQLite file in a temp dir, not a mock. `node:sqlite` is
 * a builtin and a file is free, so a fake would only prove the fake works.
 * `fetch` is the one thing stubbed: it is the network.
 */

// Set before anything imports the database module — `databasePath()` reads this
// on first use, and the modules below open the file as a side effect of the
// first query.
process.env.PROSPECTOR_DB = path.join(
  mkdtempSync(path.join(tmpdir(), "wa-test-")),
  "test.db",
);
process.env.EVOLUTION_API_URL = "http://evolution.test";
process.env.EVOLUTION_API_KEY = "test-key";
process.env.EVOLUTION_INSTANCE = "test";

const {
  activeJobs,
  closeJob,
  conversationById,
  jobById,
  openConversation,
  recentMessages,
  jobsFor,
} = await import("@/lib/whatsapp/db");
const {
  cancelJobs,
  dispatchDue,
  scheduleAppointment,
  scheduleRecurring,
  scheduleReminder,
} = await import("@/lib/whatsapp/scheduler");

/** What the stubbed bridge was asked to send. */
let sent: { number: string; text: string }[] = [];
let failNext = false;

const realFetch = globalThis.fetch;

before(() => {
  globalThis.fetch = (async (
    url: string | URL | Request,
    init?: RequestInit,
  ) => {
    const body = JSON.parse(String(init?.body ?? "{}")) as {
      number?: string;
      text?: string;
    };
    if (failNext) {
      return new Response("instance not connected", { status: 400 });
    }
    sent.push({ number: body.number ?? "", text: body.text ?? "" });
    return Response.json({ key: { id: `srv-${sent.length}` } });
  }) as typeof fetch;
});

afterEach(() => {
  sent = [];
  failNext = false;
  // One database for the whole file, so a job another test left pending is due
  // the moment this one time-travels its tick forward — and the failure lands on
  // whichever test happens to run second. Draining the queue makes each test
  // independent of the order they run in.
  for (const job of activeJobs()) closeJob(job.id, "cancelado");
});

process.on("exit", () => {
  globalThis.fetch = realFetch;
});

let counter = 0;
/** A fresh conversation per test; the phone is the table's unique key. */
function conversation() {
  counter += 1;
  return openConversation({
    accountId: null,
    phone: `5531900000${String(counter).padStart(3, "0")}`,
    contactName: "Teste",
    timezone: "America/Sao_Paulo",
  });
}

test("sends a due reminder once and closes it", async () => {
  const chat = conversation();
  const job = scheduleReminder({
    conversationId: chat.id,
    leadId: null,
    createdBy: "agent",
    action: {
      type: "lembrete",
      runAt: new Date(Date.now() - 1000).toISOString(),
      timezone: "America/Sao_Paulo",
      body: "Oi! Conseguiu ver a proposta?",
      reason: null,
    },
  });

  const first = await dispatchDue();
  assert.equal(first.sent, 1);
  assert.equal(sent[0].text, "Oi! Conseguiu ver a proposta?");

  // The row is closed, so a second tick must find nothing. A job left with its
  // next run in the past is re-sent every 30 seconds forever.
  const after = jobById(job.id)!;
  assert.equal(after.active, false);
  assert.equal(after.closedReason, "concluido");

  const second = await dispatchDue();
  assert.equal(second.sent, 0);
  assert.equal(sent.length, 1);
});

test("does not send a job that is not due yet", async () => {
  const chat = conversation();
  scheduleReminder({
    conversationId: chat.id,
    leadId: null,
    createdBy: "agent",
    action: {
      type: "lembrete",
      runAt: new Date(Date.now() + 3600_000).toISOString(),
      timezone: "America/Sao_Paulo",
      body: "amanhã",
      reason: null,
    },
  });
  const result = await dispatchDue();
  assert.equal(result.sent, 0);
  assert.equal(sent.length, 0);
});

test("skips a job that is too late instead of sending it stale", async () => {
  // "Lembrando da nossa conversa de amanhã" arriving three days late is a
  // message that damages the relationship it was meant to maintain.
  const chat = conversation();
  const job = scheduleReminder({
    conversationId: chat.id,
    leadId: null,
    createdBy: "agent",
    action: {
      type: "lembrete",
      runAt: new Date(Date.now() - 3 * 24 * 3600_000).toISOString(),
      timezone: "America/Sao_Paulo",
      body: "atrasado",
      reason: null,
    },
  });

  const result = await dispatchDue();
  assert.equal(result.skipped, 1);
  assert.equal(sent.length, 0);
  const after = jobById(job.id)!;
  assert.equal(after.active, false);
  assert.equal(after.closedReason, "expirado");
  assert.match(after.lastError!, /Atrasado/);
});

test("a recurrence advances to its next slot and stops at max_runs", async () => {
  const chat = conversation();
  const job = scheduleRecurring({
    conversationId: chat.id,
    leadId: null,
    createdBy: "agent",
    // Every six hours is the tightest the validator allows, which keeps the
    // test's clock arithmetic short.
    action: {
      type: "lembrete_recorrente",
      cron: "0 0,6,12,18 * * *",
      timezone: "America/Sao_Paulo",
      body: "acompanhamento",
      maxRuns: 2,
      reason: null,
    },
    now: new Date(),
  })!;

  // Fire it twice by pretending each slot has arrived, rather than waiting six
  // hours: `dispatchDue` takes the clock as an argument for exactly this.
  const firstDue = new Date(Date.parse(jobById(job.id)!.nextRunAt!));
  await dispatchDue(firstDue);
  const midway = jobById(job.id)!;
  assert.equal(midway.runs, 1);
  assert.equal(midway.active, true, "uma recorrência de 2x continua após a 1ª");

  const secondDue = new Date(Date.parse(midway.nextRunAt!));
  await dispatchDue(secondDue);
  const done = jobById(job.id)!;
  assert.equal(done.runs, 2);
  assert.equal(done.active, false, "e para exatamente no limite");
  assert.equal(sent.length, 2);
});

test("a failed send is recorded, retried once, then given up on", async () => {
  const chat = conversation();
  const job = scheduleReminder({
    conversationId: chat.id,
    leadId: null,
    createdBy: "agent",
    action: {
      type: "lembrete",
      runAt: new Date(Date.now() - 1000).toISOString(),
      timezone: "America/Sao_Paulo",
      body: "vai falhar",
      reason: null,
    },
  });

  failNext = true;
  const first = await dispatchDue();
  assert.equal(first.failed, 1);

  const retrying = jobById(job.id)!;
  assert.equal(retrying.active, true, "uma falha ganha uma segunda tentativa");
  assert.match(retrying.lastError!, /Evolution respondeu 400/);

  // The client never saw it, so it is in the transcript as failed — a gap with
  // no row reads as the agent having said nothing at all.
  const transcript = recentMessages(chat.id);
  assert.equal(transcript.at(-1)!.status, "failed");

  const second = await dispatchDue(new Date(Date.parse(retrying.nextRunAt!)));
  assert.equal(second.failed, 1);
  const dead = jobById(job.id)!;
  assert.equal(dead.active, false);
  assert.equal(dead.closedReason, "erro");
});

test("booking a meeting also books the reminders for it", async () => {
  // An appointment nobody is nudged about is a row in a table; the client's
  // experience of "agendado" is the reminder.
  const chat = conversation();
  const startsAt = new Date(Date.now() + 3 * 24 * 3600_000).toISOString();

  const { appointment, reminders } = scheduleAppointment({
    conversationId: chat.id,
    leadId: null,
    createdBy: "agent",
    action: {
      type: "agendar",
      title: "Conversa sobre o site",
      startsAt,
      timezone: "America/Sao_Paulo",
      durationMinutes: 30,
      notes: null,
    },
  });

  assert.equal(appointment.status, "agendado");
  assert.equal(reminders.length, 2, "um dia antes e uma hora antes");
  for (const reminder of reminders) {
    assert.ok(
      Date.parse(reminder.nextRunAt!) < Date.parse(startsAt),
      "um lembrete depois da reunião não lembra ninguém de nada",
    );
  }
});

test("a meeting booked for later today does not fire a past reminder", async () => {
  const chat = conversation();
  const { reminders } = scheduleAppointment({
    conversationId: chat.id,
    leadId: null,
    createdBy: "agent",
    action: {
      type: "agendar",
      title: "Call rápida",
      // Ninety minutes out: the "tomorrow" nudge would land yesterday.
      startsAt: new Date(Date.now() + 90 * 60_000).toISOString(),
      timezone: "America/Sao_Paulo",
      durationMinutes: 30,
      notes: null,
    },
  });

  assert.equal(reminders.length, 1);
  assert.ok(Date.parse(reminders[0].nextRunAt!) > Date.now());
});

test("cancelling a thread's jobs stops every live one", async () => {
  const chat = conversation();
  for (let i = 0; i < 3; i += 1) {
    scheduleReminder({
      conversationId: chat.id,
      leadId: null,
      createdBy: "agent",
      action: {
        type: "lembrete",
        runAt: new Date(Date.now() + (i + 1) * 3600_000).toISOString(),
        timezone: "America/Sao_Paulo",
        body: `lembrete ${i}`,
        reason: null,
      },
    });
  }

  assert.equal(cancelJobs(chat.id, "cancelado"), 3);
  assert.equal(jobsFor(chat.id).filter((job) => job.active).length, 0);

  const result = await dispatchDue(new Date(Date.now() + 10 * 3600_000));
  assert.equal(result.sent, 0);
});

test("a message is never sent twice for one inbound webhook", async () => {
  // The provider retries a webhook it thinks failed; the unique provider id is
  // the whole idempotency story.
  const { recordMessage } = await import("@/lib/whatsapp/db");
  const chat = conversation();

  const first = recordMessage({
    conversationId: chat.id,
    direction: "in",
    origin: "client",
    body: "oi",
    providerId: "wa-abc-123",
  });
  const replay = recordMessage({
    conversationId: chat.id,
    direction: "in",
    origin: "client",
    body: "oi",
    providerId: "wa-abc-123",
  });

  assert.ok(first);
  assert.equal(
    replay,
    null,
    "o reenvio do webhook não vira uma segunda mensagem",
  );
  assert.equal(conversationById(chat.id)!.lastInboundAt !== null, true);
});
