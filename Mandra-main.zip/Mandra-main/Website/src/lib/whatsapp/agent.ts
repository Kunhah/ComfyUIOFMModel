import { site } from "@/content/site";
import { findAccount, type Account } from "@/lib/crm/accounts";
import { services } from "@/content/services";
import { llmConfigured, type ChatMessage } from "@/lib/ai/providers";
import { runCompletion } from "@/lib/ai/run";
import { parseAgentReply, type AgentAction, type AgentReply } from "./actions";
import {
  conversationById,
  jobsFor,
  recentMessages,
  setAutoReply,
  type Conversation,
} from "./db";
import { waDb } from "./db";
import {
  cancelJobs,
  describeCron,
  localTime,
  scheduleAppointment,
  scheduleRecurring,
  scheduleReminder,
} from "./scheduler";
import { deliver } from "./sender";

/**
 * The assistant that answers the number, and the code that acts on what it says.
 *
 * Ported in shape from EpochalQuant_Agent's `core/agent.rs`: a system prompt
 * assembled from a fixed brief plus per-request context, a provider chain
 * underneath, and a JSON envelope on the way back. What is different is that
 * this one's JSON is load-bearing. The Discord bot parsed an envelope to find a
 * `message` field and threw the rest away; here the rest is the feature — it
 * books meetings and creates jobs that will message a customer next week.
 *
 * The conversational memory is the `wa_messages` table, not a map in the
 * process. Two containers, a deploy mid-conversation and a restart all have to
 * leave the thread intact, and a client who gets a reply that has forgotten the
 * last three messages notices immediately.
 */

/** How much of the thread the model is shown. */
const HISTORY_TURNS = 20;

/**
 * The default wall clock the agent schedules in.
 *
 * Overridden per conversation when we know better. Not read from the container's
 * TZ, which is UTC in every deployment we have: a bot that books "amanhã às 9"
 * three hours off is worse than one that cannot book at all.
 */
export const DEFAULT_TIMEZONE =
  process.env.WHATSAPP_TIMEZONE?.trim() || "America/Sao_Paulo";

/**
 * What the agent is and, more importantly, what it must not do.
 *
 * The service list is imported from `src/content/services.ts` rather than
 * retyped, so the bot cannot end up offering something the website does not —
 * the failure mode of a hand-written prompt is that it goes stale silently and
 * the first person to find out is a customer who was promised it.
 */
function brief(services: string, account: Account | null): string {
  // Whose assistant this is. Atlas's own identity is built from src/content, so
  // our bot cannot offer a service our website does not; a client's is whatever
  // they told us about their business, and nothing is inferred beyond it.
  const identity = account
    ? `Você é o assistente de atendimento da ${account.name} no WhatsApp.

Sobre a empresa, nas palavras dela:
${account.waBrief}`
    : `Você é o assistente de atendimento da ${site.name} (${site.url}) no WhatsApp.
A ${site.name} é uma empresa brasileira de soluções digitais: ${site.description}

O que a empresa faz:
${services}`;

  return `${identity}

## Seu papel
Você atende quem chama no WhatsApp: responde dúvidas sobre os serviços, entende o
que a pessoa precisa e — quando fizer sentido — marca uma conversa com o time e
programa lembretes. Você NÃO fecha contrato, NÃO cobra e NÃO executa projeto.

## Regras que não se quebram
- Nunca invente preço, prazo, desconto ou condição de pagamento. Se perguntarem,
  diga que quem passa valores é o time, e ofereça marcar uma conversa.
- Nunca prometa nada que dependa de outra pessoa sem marcar a conversa.
- Nunca peça senha, dado bancário, cartão ou documento.
- Nunca diga que é humano. Se perguntarem, você é o assistente virtual da
  ${account ? account.name : site.name} — e ofereça chamar alguém do time.
- Se a pessoa pedir para falar com humano, se estiver irritada, se reclamar de
  algo já contratado, ou se o assunto fugir do seu papel: use a ação
  "transferir" e avise que alguém do time assume a conversa.
- Se a pessoa pedir para parar de receber mensagens: use "cancelar_lembretes" e
  confirme que não vai mais chamar.

## Como escrever
- Português do Brasil, tratamento por "você".
- WhatsApp, não e-mail: curto. No máximo 3 ou 4 linhas, sem assinatura, sem
  "Prezado", sem bullet point, sem markdown (o WhatsApp não renderiza).
- Uma pergunta por mensagem. Duas perguntas juntas não são respondidas.
- Emoji no máximo um, e só quando couber naturalmente.`;
}

/**
 * The contract. Written as an instruction *and* as an example, because models
 * follow a demonstrated shape far more reliably than a described one.
 *
 * The keys are Portuguese for the same reason the rest of the prompt is: asking
 * a model to reason in one language and emit keys in another costs accuracy on
 * exactly the fields that matter.
 */
function envelopeContract(now: string, timezone: string): string {
  return `## Formato da resposta (obrigatório)
Responda SEMPRE com um único objeto JSON, sem texto fora dele e sem blocos de
código. O formato é:

{"mensagem": "o que enviar para a pessoa", "acoes": []}

"mensagem" é o texto que a pessoa vai ler no WhatsApp. "acoes" é uma lista, quase
sempre vazia. Só coloque uma ação quando a pessoa tiver concordado — nunca
agende nem programe lembrete por conta própria.

Agora são ${now} (fuso ${timezone}). Use SEMPRE horário local neste formato:
"AAAA-MM-DDTHH:MM". Nunca escreva fuso, "Z" nem offset.

Ações disponíveis:

1) Marcar uma conversa/reunião — só depois da pessoa confirmar dia e hora:
{"tipo":"agendar","titulo":"Conversa sobre o site","quando":"2026-09-05T14:00","duracao_min":30,"observacao":"quer orçamento de landing page"}

2) Um lembrete único, num momento específico:
{"tipo":"lembrete","quando":"2026-09-04T09:00","texto":"Oi! Conseguiu ver a proposta?","motivo":"cliente pediu para chamar quinta"}

3) Um lembrete que se repete, em cron de 5 campos (minuto hora dia mês dia-da-semana):
{"tipo":"lembrete_recorrente","cron":"0 9 * * 1","texto":"Bom dia! Seguimos com a proposta?","repeticoes":4,"motivo":"acompanhamento semanal combinado"}

4) Passar para uma pessoa do time:
{"tipo":"transferir","motivo":"cliente pediu falar com humano"}

5) Parar de mandar lembretes:
{"tipo":"cancelar_lembretes","motivo":"cliente pediu para não chamar mais"}

Limites: no máximo uma repetição a cada 6 horas, no máximo 12 repetições, e nada
a mais de 365 dias. "texto" de lembrete é a mensagem inteira que a pessoa vai
receber sozinha, dias depois — escreva ela completa e sem depender do contexto
desta conversa.`;
}

function serviceList(): string {
  return services
    .map((service) => `- ${service.title}: ${service.items.join(", ")}`)
    .join("\n");
}

/**
 * What the agent knows about who it is talking to.
 *
 * The lead row is the CRM's own record of the business, so the bot opens
 * knowing the company name, the city and how far the deal has come — which is
 * the difference between "Olá! Como posso ajudar?" and picking up where the last
 * call left off. Everything here is already ours; nothing is inferred.
 */
function leadContext(conversation: Conversation): string {
  const lines: string[] = [];
  if (conversation.contactName) {
    lines.push(`Nome no WhatsApp: ${conversation.contactName}`);
  }

  if (conversation.leadId) {
    const lead = waDb()
      .prepare(
        `SELECT name, city, uf, niche, funnel_stage, notes, next_follow_up_at
           FROM leads WHERE id = ?`,
      )
      .get(conversation.leadId) as
      | {
          name: string;
          city: string | null;
          uf: string | null;
          niche: string | null;
          funnel_stage: string;
          notes: string | null;
          next_follow_up_at: string | null;
        }
      | undefined;

    if (lead) {
      lines.push(`Empresa: ${lead.name}`);
      if (lead.city)
        lines.push(`Cidade: ${lead.city}${lead.uf ? `/${lead.uf}` : ""}`);
      if (lead.niche) lines.push(`Ramo: ${lead.niche}`);
      lines.push(`Etapa no funil: ${lead.funnel_stage}`);
      if (lead.next_follow_up_at) {
        lines.push(`Retorno combinado: ${lead.next_follow_up_at}`);
      }
      // Capped: an operator's notes on an old lead can run to paragraphs, and
      // the tail of them is never the part that matters to this message.
      if (lead.notes) {
        lines.push(`Anotações do time: ${lead.notes.slice(0, 600)}`);
      }
    }
  }

  // What is already scheduled, so the agent does not book a second meeting over
  // the first or promise a reminder that already exists.
  const live = jobsFor(conversation.id).filter((job) => job.active);
  if (live.length > 0) {
    lines.push(
      `Já programado para esta pessoa: ${live
        .map((job) =>
          job.kind === "cron" && job.cron
            ? `${describeCron(job.cron)} — "${job.body.slice(0, 60)}"`
            : `${job.nextRunAt ? localTime(job.nextRunAt, job.timezone) : "sem data"} — "${job.body.slice(0, 60)}"`,
        )
        .join("; ")}`,
    );
  }

  if (lines.length === 0) return "Não sabemos nada sobre esta pessoa ainda.";
  return lines.join("\n");
}

export function buildSystemPrompt(
  conversation: Conversation,
  account: Account | null,
): string {
  const timezone = conversation.timezone ?? DEFAULT_TIMEZONE;
  const now = new Intl.DateTimeFormat("pt-BR", {
    timeZone: timezone,
    dateStyle: "full",
    timeStyle: "short",
  }).format(new Date());

  return [
    brief(serviceList(), account),
    `## Quem está do outro lado\n${leadContext(conversation)}`,
    envelopeContract(now, timezone),
  ].join("\n\n");
}

/**
 * The transcript, as the model's own turns.
 *
 * Failed outbound messages are excluded: the client never saw them, so a model
 * that reads them back believes it already said something it did not, and the
 * next reply refers to a message that does not exist on the other phone.
 */
function history(conversationId: string): ChatMessage[] {
  return recentMessages(conversationId, HISTORY_TURNS)
    .filter((message) => message.status === "ok")
    .map((message) => ({
      role:
        message.direction === "in" ? ("user" as const) : ("assistant" as const),
      content: message.body,
    }));
}

export type AgentTurn = {
  /** What was sent, or null when nothing was. */
  sent: string | null;
  reply: AgentReply | null;
  applied: string[];
  error: string | null;
};

/**
 * One turn: read the thread, ask the model, act, answer.
 *
 * The inbound message must already be recorded — the caller does that first, so
 * that a crash in here still leaves the client's words in the transcript and an
 * operator can see what was asked.
 */
export async function runTurn(conversationId: string): Promise<AgentTurn> {
  const conversation = conversationById(conversationId);
  if (!conversation) {
    return {
      sent: null,
      reply: null,
      applied: [],
      error: "Conversa não encontrada.",
    };
  }
  if (!llmConfigured()) {
    return {
      sent: null,
      reply: null,
      applied: [],
      error: "IA não configurada.",
    };
  }

  // Whose number this thread is on decides who the agent says it is. A client
  // account with no brief is deliberately not answered: the fallback persona is
  // Atlas's own, and introducing ourselves to a dentist's patients — offering
  // our services, on the dentist's number — is worse than a silent thread. The
  // message is stored either way, and the handoff puts it in front of a person.
  const account = conversation.accountId
    ? findAccount(conversation.accountId)
    : null;

  if (conversation.accountId && !account?.waBrief) {
    setAutoReply(conversation.id, false);
    return {
      sent: null,
      reply: null,
      applied: [],
      error: account
        ? `${account.name} ainda não tem o texto do assistente configurado.`
        : "Conta não encontrada para esta conversa.",
    };
  }

  const messages: ChatMessage[] = [
    { role: "system", content: buildSystemPrompt(conversation, account) },
    ...history(conversation.id),
  ];

  let raw: string;
  try {
    ({ text: raw } = await runCompletion({
      skill: "atendimento.resposta",
      // Whose number the thread is on is also who pays for the answer. NULL is
      // Atlas's own prospecting, exactly as it is on the conversation row.
      accountId: conversation.accountId,
      subject: `conversa:${conversation.id}`,
      messages,
      chain: "rapido",
      json: true,
    }));
  } catch (error) {
    // No fallback message is sent. A generic "não entendi" would train the
    // client to repeat themselves at a bot that is down, and the thread is
    // better left silent while the handoff below puts it in front of a person.
    setAutoReply(conversation.id, false);
    return {
      sent: null,
      reply: null,
      applied: [],
      error: error instanceof Error ? error.message : String(error),
    };
  }

  const parseContext = { timezone: conversation.timezone ?? DEFAULT_TIMEZONE };
  let reply = parseAgentReply(raw, parseContext);

  // The worst failure this feature has: the model writes "pronto, agendei para
  // amanhã!" and the action behind it was refused, so the client is told
  // something that did not happen and finds out by nobody calling. One
  // corrective round-trip — the model is shown exactly why it was refused and
  // asked again — fixes almost all of these, because the usual cause is a date
  // it read wrong rather than a request that was impossible.
  //
  // Only once, and only when nothing survived: a second failure means the model
  // is not going to get it, and the reply below is then sent without the
  // promise, which is a worse answer but a true one.
  if (reply.rejected.length > 0 && reply.actions.length === 0) {
    try {
      // Logged under its own id rather than as a second `atendimento.resposta`.
      // A turn that needed correcting costs twice and is worth being able to
      // count: the rate of these is the clearest signal the envelope prompt has
      // drifted, and burying them in the ordinary runs hides it.
      const { text: corrected } = await runCompletion({
        skill: "atendimento.correcao",
        accountId: conversation.accountId,
        subject: `conversa:${conversation.id}`,
        messages: [
          ...messages,
          { role: "assistant", content: raw },
          {
            role: "system",
            content:
              `As ações que você mandou foram recusadas: ${reply.rejected.join(" ")} ` +
              "Responda de novo, no mesmo formato JSON. Corrija a ação se der, e " +
              "se não der, NÃO diga que agendou nem que vai lembrar — pergunte o " +
              "que falta para acertar.",
          },
        ],
        chain: "rapido",
        json: true,
      });
      reply = parseAgentReply(corrected, parseContext);
    } catch {
      // The first answer still stands; it just carries no actions.
    }
  }

  const applied = applyActions(conversation, reply.actions);

  let sent: string | null = null;
  if (reply.message) {
    const delivery = await deliver({
      conversationId: conversation.id,
      text: reply.message,
      origin: "agent",
    });
    if (delivery.ok) sent = reply.message;
    else {
      return { sent: null, reply, applied, error: delivery.error };
    }
  }

  return { sent, reply, applied, error: null };
}

/**
 * Carries out what the model asked for, in the order it asked.
 *
 * Returns a human-readable line per action for the audit and the admin screen.
 * Everything here has already been validated by `parseAgentReply`; this function
 * decides nothing about whether an action is reasonable, only how to perform it.
 */
export function applyActions(
  conversation: Conversation,
  actions: AgentAction[],
): string[] {
  const applied: string[] = [];

  for (const action of actions) {
    switch (action.type) {
      case "agendar": {
        const { appointment, reminders } = scheduleAppointment({
          conversationId: conversation.id,
          leadId: conversation.leadId,
          action,
          createdBy: "agent",
        });
        applied.push(
          `${appointment.title} marcado para ${localTime(appointment.startsAt, appointment.timezone)}` +
            (reminders.length
              ? ` (${reminders.length} lembrete${reminders.length > 1 ? "s" : ""} automático${reminders.length > 1 ? "s" : ""})`
              : ""),
        );
        break;
      }

      case "lembrete": {
        const job = scheduleReminder({
          conversationId: conversation.id,
          leadId: conversation.leadId,
          action,
          createdBy: "agent",
        });
        applied.push(
          `Lembrete para ${localTime(job.nextRunAt!, job.timezone)}: "${job.body}"`,
        );
        break;
      }

      case "lembrete_recorrente": {
        const job = scheduleRecurring({
          conversationId: conversation.id,
          leadId: conversation.leadId,
          action,
          createdBy: "agent",
        });
        if (job) {
          applied.push(
            `Lembrete ${describeCron(job.cron!)} (${job.maxRuns}x): "${job.body}"`,
          );
        }
        break;
      }

      case "transferir": {
        // The switch that stops the agent answering. Everything else it can do
        // is additive; this one hands the thread to a person, and it is the
        // reason `auto_reply` exists as a column rather than a setting.
        setAutoReply(conversation.id, false);
        applied.push(
          `Transferido para atendimento humano${action.reason ? ` — ${action.reason}` : ""}`,
        );
        break;
      }

      case "cancelar_lembretes": {
        const closed = cancelJobs(conversation.id, "cancelado");
        applied.push(
          `${closed} lembrete(s) cancelado(s)${action.reason ? ` — ${action.reason}` : ""}`,
        );
        break;
      }
    }
  }

  return applied;
}
