import { extractJson } from "@/lib/ai/envelope";
import { isValidCron, nextRunOf, wallToInstant } from "./cron";

/**
 * The JSON the model is allowed to send, and everything that stops it being
 * believed.
 *
 * The agent does not call functions — it answers with one object containing what
 * to say and, optionally, what to *do*. One envelope rather than a tool-call API
 * because the two providers behind it (Groq, OpenRouter) expose tool calling
 * differently and not every model on either supports it, while `response_format:
 * json_object` works on all of them. The cost is this file: a schema written out
 * by hand and validated as if it came from a stranger.
 *
 * Which it does. A language model is an untrusted input source that happens to
 * be on our side of the network, and every field here reaches something real —
 * a message sent to a customer's phone, a job that keeps sending it for weeks.
 * The rules below are not defensive programming, they are the product: an agent
 * that can be talked into scheduling a message every minute for a year is a
 * worse feature than no agent.
 *
 * Portuguese keys because the prompt, the conversation and the CRM are all in
 * Portuguese. A model asked to reason in one language and emit keys in another
 * gets it wrong often enough to matter.
 */

/** Booked something in the diary. */
export type ScheduleAction = {
  type: "agendar";
  title: string;
  /** ISO-8601 UTC, resolved from the local wall time the model wrote. */
  startsAt: string;
  timezone: string;
  durationMinutes: number;
  notes: string | null;
};

/** One message, at one moment. */
export type ReminderAction = {
  type: "lembrete";
  /** ISO-8601 UTC. */
  runAt: string;
  timezone: string;
  body: string;
  reason: string | null;
};

/** A recurrence, kept as the expression. */
export type RecurringAction = {
  type: "lembrete_recorrente";
  cron: string;
  timezone: string;
  body: string;
  maxRuns: number;
  reason: string | null;
};

/** Stop answering; a person takes the thread. */
export type HandoffAction = {
  type: "transferir";
  reason: string | null;
};

/** The client asked to be left alone. */
export type CancelAction = {
  type: "cancelar_lembretes";
  reason: string | null;
};

export type AgentAction =
  | ScheduleAction
  | ReminderAction
  | RecurringAction
  | HandoffAction
  | CancelAction;

export type AgentReply = {
  /** What to send the client. May be empty when the turn is only an action. */
  message: string;
  actions: AgentAction[];
  /**
   * Actions that were refused, with the reason, in Portuguese.
   *
   * Kept rather than dropped because they are fed back to the model on the next
   * turn ("o horário que você escolheu já passou") so it can correct itself, and
   * because a schedule the client was promised and that silently did not happen
   * is the worst failure this feature has.
   */
  rejected: string[];
};

/**
 * How far ahead anything may be scheduled.
 *
 * A model that misreads "ano que vem" or fumbles a year in an ISO string
 * produces a job sitting in the queue until 2034. Nothing this agent does is
 * legitimately more than a year out, and the ceiling turns a silent absurdity
 * into a rejection the model is told about.
 */
const MAX_HORIZON_DAYS = 365;

/**
 * The floor on how often a recurrence may fire.
 *
 * This is the single most important number in the file. `* * * * *` is a
 * perfectly valid cron expression that messages a customer every minute forever,
 * and it is exactly what a confused model emits when asked to "lembrar sempre".
 * Six hours allows every real reminder — daily, weekly, twice a week — and
 * excludes every shape that would get the number banned.
 */
const MIN_INTERVAL_MINUTES = 6 * 60;

/**
 * The ceiling on repetitions, and why one is mandatory.
 *
 * A recurrence with no end is a subscription the client never agreed to, and
 * nothing in a chat thread cancels it — they simply block the number. Twelve is
 * three months of weekly follow-ups, which is longer than any of ours run.
 */
const MAX_RUNS = 12;
const DEFAULT_MAX_RUNS = 4;

const MAX_MESSAGE_LENGTH = 1200;
const MAX_BODY_LENGTH = 800;

const MAX_DURATION_MINUTES = 8 * 60;

/** Guard against a model that decides to schedule twenty things in one turn. */
const MAX_ACTIONS = 4;

export type ParseContext = {
  /** The conversation's timezone, used for anything the model leaves out. */
  timezone: string;
  /** Injected in tests; the moment "the past" is measured against. */
  now?: Date;
};

/**
 * Turns the model's raw completion into a reply we are willing to act on.
 *
 * Never throws. Every failure — unparseable JSON, a missing message, an action
 * that breaks a rule — degrades to something sendable, because the alternative
 * on a live WhatsApp thread is a customer left on read.
 */
export function parseAgentReply(
  raw: string,
  context: ParseContext,
): AgentReply {
  const parsed = extractJson(raw);

  // A model that ignored the envelope entirely still wrote a sentence. Sending
  // it is better than sending nothing: the words are usually a perfectly good
  // reply and only the structure is missing, so the turn loses its actions
  // rather than its answer.
  if (!parsed) {
    return {
      message: clamp(raw, MAX_MESSAGE_LENGTH),
      actions: [],
      rejected: [],
    };
  }

  const message = clamp(
    typeof parsed.mensagem === "string" ? parsed.mensagem : "",
    MAX_MESSAGE_LENGTH,
  );

  const rejected: string[] = [];
  const actions: AgentAction[] = [];

  const list = Array.isArray(parsed.acoes) ? parsed.acoes : [];
  for (const entry of list.slice(0, MAX_ACTIONS)) {
    const result = parseAction(entry, context);
    if ("error" in result) rejected.push(result.error);
    else actions.push(result.action);
  }
  if (list.length > MAX_ACTIONS) {
    rejected.push(
      `Só as ${MAX_ACTIONS} primeiras ações foram consideradas (vieram ${list.length}).`,
    );
  }

  return { message, actions, rejected };
}

type ActionResult = { action: AgentAction } | { error: string };

function parseAction(entry: unknown, context: ParseContext): ActionResult {
  if (!entry || typeof entry !== "object") {
    return { error: "Ação ignorada: não era um objeto." };
  }
  const a = entry as Record<string, unknown>;
  const type = typeof a.tipo === "string" ? a.tipo.trim().toLowerCase() : "";

  switch (type) {
    case "agendar":
      return parseSchedule(a, context);
    case "lembrete":
      return parseReminder(a, context);
    case "lembrete_recorrente":
      return parseRecurring(a, context);
    case "transferir":
      return {
        action: { type: "transferir", reason: text(a.motivo, 300) },
      };
    case "cancelar_lembretes":
      return {
        action: { type: "cancelar_lembretes", reason: text(a.motivo, 300) },
      };
    default:
      return { error: `Ação desconhecida: "${type || "(sem tipo)"}".` };
  }
}

function parseSchedule(
  a: Record<string, unknown>,
  context: ParseContext,
): ActionResult {
  const timezone = zone(a.fuso, context.timezone);
  if (!timezone) return { error: `Fuso horário inválido: ${String(a.fuso)}.` };

  const when = resolveWhen(a.quando, timezone, context.now);
  if ("error" in when) return { error: `Agendamento recusado — ${when.error}` };

  const title = text(a.titulo, 160) ?? "Reunião";
  const duration = Math.min(
    Math.max(Math.round(number(a.duracao_min) ?? 30), 5),
    MAX_DURATION_MINUTES,
  );

  return {
    action: {
      type: "agendar",
      title,
      startsAt: when.instant.toISOString(),
      timezone,
      durationMinutes: duration,
      notes: text(a.observacao, 500),
    },
  };
}

function parseReminder(
  a: Record<string, unknown>,
  context: ParseContext,
): ActionResult {
  const timezone = zone(a.fuso, context.timezone);
  if (!timezone) return { error: `Fuso horário inválido: ${String(a.fuso)}.` };

  const when = resolveWhen(a.quando, timezone, context.now);
  if ("error" in when) return { error: `Lembrete recusado — ${when.error}` };

  const body = text(a.texto, MAX_BODY_LENGTH);
  // The body is the whole point of the job: a reminder with nothing to say would
  // fire on time and send an empty WhatsApp message.
  if (!body) return { error: "Lembrete recusado — sem texto para enviar." };

  return {
    action: {
      type: "lembrete",
      runAt: when.instant.toISOString(),
      timezone,
      body,
      reason: text(a.motivo, 300),
    },
  };
}

function parseRecurring(
  a: Record<string, unknown>,
  context: ParseContext,
): ActionResult {
  const timezone = zone(a.fuso, context.timezone);
  if (!timezone) return { error: `Fuso horário inválido: ${String(a.fuso)}.` };

  const expression = typeof a.cron === "string" ? a.cron.trim() : "";
  if (!expression || !isValidCron(expression)) {
    return {
      error: `Recorrência recusada — expressão cron inválida: "${expression}".`,
    };
  }

  const body = text(a.texto, MAX_BODY_LENGTH);
  if (!body) return { error: "Recorrência recusada — sem texto para enviar." };

  const now = context.now ?? new Date();

  const first = nextRunOf(expression, now, timezone);
  if (!first) {
    return {
      error: `Recorrência recusada — "${expression}" nunca acontece.`,
    };
  }

  const spacing = minimumInterval(expression, first, timezone);
  if (spacing !== null && spacing < MIN_INTERVAL_MINUTES) {
    return {
      error:
        `Recorrência recusada — "${expression}" dispara a cada ${spacing} min, ` +
        `e o mínimo é ${MIN_INTERVAL_MINUTES / 60}h.`,
    };
  }

  const requested = number(a.repeticoes);
  const maxRuns = Math.min(
    Math.max(Math.round(requested ?? DEFAULT_MAX_RUNS), 1),
    MAX_RUNS,
  );

  return {
    action: {
      type: "lembrete_recorrente",
      cron: expression,
      timezone,
      body,
      maxRuns,
      reason: text(a.motivo, 300),
    },
  };
}

/**
 * The shortest gap between consecutive fires, sampled over the next few runs.
 *
 * Sampling rather than reasoning about the expression: a two-hour list and a
 * half-hourly step are both "sometimes 30 minutes apart", and no amount of
 * reading the fields tells you that as cheaply as computing four of them in a
 * row and taking the smallest gap. Returns null
 * when the expression stops producing runs, which the caller has already
 * handled as its own rejection.
 */
function minimumInterval(
  expression: string,
  first: Date,
  timezone: string,
): number | null {
  let previous = first;
  let smallest: number | null = null;

  for (let i = 0; i < 4; i += 1) {
    const next = nextRunOf(expression, previous, timezone);
    if (!next) break;
    const gap = Math.round((next.getTime() - previous.getTime()) / 60000);
    smallest = smallest === null ? gap : Math.min(smallest, gap);
    previous = next;
  }

  return smallest;
}

type WhenResult = { instant: Date } | { error: string };

/**
 * Resolves the moment the model wrote into a real instant.
 *
 * Accepts a bare local wall time (`2026-09-05T14:00`) and reads it in the
 * conversation's timezone, which is what the model is told to send: asking a
 * language model for a UTC offset is asking it to do arithmetic it is bad at,
 * and a wrong offset books the meeting three hours out with nothing to show for
 * it. A string that carries its own offset or a `Z` is honoured as written —
 * that one is unambiguous.
 */
function resolveWhen(value: unknown, timezone: string, now?: Date): WhenResult {
  if (typeof value !== "string" || !value.trim()) {
    return { error: "sem data e hora." };
  }
  const raw = value.trim();

  const local = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::\d{2})?$/.exec(
    raw,
  );
  let instant: Date;

  if (local) {
    const ms = wallToInstant(
      {
        year: Number(local[1]),
        month: Number(local[2]),
        day: Number(local[3]),
        hour: Number(local[4]),
        minute: Number(local[5]),
      },
      timezone,
    );
    instant = new Date(ms);
  } else {
    const parsed = Date.parse(raw);
    if (Number.isNaN(parsed)) return { error: `data inválida: "${raw}".` };
    instant = new Date(parsed);
  }

  const reference = now ?? new Date();
  // A minute of slack: the model reads "daqui a pouco" as the current minute
  // often enough, and rejecting that is pedantry the client would experience as
  // the bot refusing to book them in.
  if (instant.getTime() < reference.getTime() - 60_000) {
    return { error: `a data ${raw} já passou.` };
  }

  const horizon = reference.getTime() + MAX_HORIZON_DAYS * 86_400_000;
  if (instant.getTime() > horizon) {
    return { error: `a data ${raw} está a mais de ${MAX_HORIZON_DAYS} dias.` };
  }

  return { instant };
}

/** A trimmed, capped string, or null when there was nothing there. */
function text(value: unknown, max: number): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  return trimmed ? clamp(trimmed, max) : null;
}

function clamp(value: string, max: number): string {
  const trimmed = value.trim();
  return trimmed.length > max ? `${trimmed.slice(0, max - 1)}…` : trimmed;
}

function number(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  // Models write "30" as often as 30, and a schema violation this trivial is not
  // worth losing an appointment over.
  if (typeof value === "string" && value.trim()) {
    const n = Number(value.trim());
    if (Number.isFinite(n)) return n;
  }
  return null;
}

/** A valid IANA zone name, or the conversation's, or null if even that is bad. */
function zone(value: unknown, fallback: string): string | null {
  const candidate =
    typeof value === "string" && value.trim() ? value.trim() : fallback;
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: candidate });
    return candidate;
  } catch {
    return null;
  }
}
