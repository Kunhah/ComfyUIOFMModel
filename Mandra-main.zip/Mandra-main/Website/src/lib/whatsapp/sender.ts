import { conversationById, recordMessage, type MessageOrigin } from "./db";
import { EvolutionError, sendText } from "./evolution";
import { findAccount } from "@/lib/crm/accounts";

/**
 * The one place an outbound WhatsApp message is sent from.
 *
 * Both callers — the agent replying and the scheduler firing a job — need the
 * same three things to happen together: send it, write it to the transcript, and
 * record the failure against the row that caused it when it doesn't go. Split
 * across two call sites they drift, and the way they drift is that one of them
 * stops recording failures, which is exactly the case an operator needs to see.
 *
 * Never throws. A send that fails is a fact to store, not an exception to
 * unwind: the webhook has already accepted the client's message, and the tick
 * has forty other jobs to run.
 */

export type DeliveryResult = {
  ok: boolean;
  error: string | null;
};

export async function deliver(input: {
  conversationId: string;
  text: string;
  origin: MessageOrigin;
  jobId?: string | null;
}): Promise<DeliveryResult> {
  const conversation = conversationById(input.conversationId);
  if (!conversation) {
    return { ok: false, error: "Conversa não encontrada." };
  }

  const text = input.text.trim();
  // An empty send is a bug upstream, and WhatsApp would reject it anyway. Saying
  // so beats a provider error that reads as a connectivity problem.
  if (!text) return { ok: false, error: "Mensagem vazia." };

  // Which of our paired numbers to send as. Derived from the thread rather than
  // passed in, because every caller — the agent, the scheduler, an operator —
  // already has the conversation and none of them should be trusted to remember
  // whose number it is. Sending a client's reply from Atlas's number reaches the
  // right person as a stranger, and the thread it belongs to is on another phone.
  const routed = instanceFor(conversation.accountId);
  if (!routed.ok) {
    // Recorded as a failed outbound like any other, so the operator sees the
    // message that did not go and why, rather than a thread that simply stops.
    recordMessage({
      conversationId: conversation.id,
      direction: "out",
      origin: input.origin,
      body: text,
      status: "failed",
      error: routed.error,
      jobId: input.jobId ?? null,
    });
    return { ok: false, error: routed.error };
  }

  try {
    const { providerId } = await sendText({
      phone: conversation.phone,
      text,
      country: conversation.country,
      instance: routed.instance,
    });
    recordMessage({
      conversationId: conversation.id,
      direction: "out",
      origin: input.origin,
      body: text,
      // Storing our own message id is what stops the webhook treating the echo
      // of our send as a new client message on bridges that deliver `fromMe`.
      providerId,
      jobId: input.jobId ?? null,
    });
    return { ok: true, error: null };
  } catch (error) {
    const message =
      error instanceof EvolutionError || error instanceof Error
        ? error.message
        : String(error);
    // The failed text is written to the transcript too. An operator opening the
    // thread has to be able to see what the client *didn't* receive — a gap with
    // no row in it reads as the agent having said nothing at all.
    recordMessage({
      conversationId: conversation.id,
      direction: "out",
      origin: input.origin,
      body: text,
      status: "failed",
      error: message.slice(0, 500),
      jobId: input.jobId ?? null,
    });
    return { ok: false, error: message };
  }
}

/**
 * The Evolution instance a thread sends from.
 *
 * Null account means Atlas's own, and `sendText` falls back to the environment
 * for it — the same "null means ours" the leads table uses. A client account
 * with no instance is a client we have not connected yet, and that is a refusal
 * rather than a fallback: quietly sending from our number would put our
 * WhatsApp in front of their customer.
 */
function instanceFor(
  accountId: string | null,
): { ok: true; instance: string | null } | { ok: false; error: string } {
  if (accountId === null) return { ok: true, instance: null };

  const account = findAccount(accountId);
  if (!account) {
    return { ok: false, error: "Conta não encontrada para esta conversa." };
  }
  if (!account.active) {
    return { ok: false, error: `A conta ${account.name} está suspensa.` };
  }
  if (!account.waInstance) {
    return {
      ok: false,
      error: `${account.name} ainda não tem WhatsApp conectado.`,
    };
  }
  return { ok: true, instance: account.waInstance };
}
