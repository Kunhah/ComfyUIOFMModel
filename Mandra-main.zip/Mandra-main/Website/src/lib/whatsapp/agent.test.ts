import assert from "node:assert/strict";
import { test } from "node:test";
import { buildSystemPrompt } from "./agent";
import type { Account } from "@/lib/crm/accounts";
import type { Conversation } from "./db";

/**
 * Whose assistant the agent says it is.
 *
 * This is the failure that does not look like one: the prompt is well-formed,
 * the model answers fluently, the send succeeds — and a dentist's patient has
 * just been offered web development by a company they never contacted, on their
 * dentist's number. Nothing in the logs says anything went wrong.
 *
 * So the identity half of the prompt is pinned here, in both directions.
 */

const conversation: Conversation = {
  id: "c1",
  accountId: "a1",
  phone: "5531999998888",
  leadId: null,
  contactName: "Maria",
  country: "BR",
  autoReply: true,
  timezone: "America/Sao_Paulo",
  lastInboundAt: null,
  lastOutboundAt: null,
  createdAt: "2026-01-01T00:00:00.000Z",
};

const account: Account = {
  id: "a1",
  name: "Clínica Sorriso",
  slug: "clinica-sorriso",
  country: "BR",
  active: true,
  createdAt: "2026-01-01T00:00:00.000Z",
  createdBy: "admin",
  notes: null,
  waInstance: "clinica-sorriso",
  waNumber: null,
  waBrief: "Clínica odontológica em BH. Limpeza, clareamento e implante.",
};

/** Everything above the shared rules — the part that says who is speaking. */
const identityOf = (prompt: string) =>
  prompt.split("## Como escrever")[0] ?? "";

test("a client's prompt introduces the client, not us", () => {
  const prompt = buildSystemPrompt(conversation, account);
  assert.ok(prompt.includes("Clínica Sorriso"));
  assert.ok(prompt.includes("Limpeza, clareamento e implante."));
});

test("our own name never reaches a client's prompt", () => {
  // The specific regression: `brief()` used to read `site` unconditionally, so
  // every routed conversation introduced itself as us and listed our services.
  const identity = identityOf(buildSystemPrompt(conversation, account));
  assert.ok(
    !/mandra|atlas/i.test(identity),
    `our identity leaked into a client prompt: ${identity.slice(0, 300)}`,
  );
});

test("the never-claim-to-be-human rule names the client's business", () => {
  // It is quoted back to the customer verbatim when they ask, so the wrong name
  // here is the bot telling a patient it works for a company they never called.
  const prompt = buildSystemPrompt(conversation, account);
  assert.ok(prompt.includes("assistente virtual da\n  Clínica Sorriso"));
});

test("with no account it is still our own assistant", () => {
  // Atlas prospecting from our own number is the original behaviour and has to
  // survive: null account means ours, exactly as it does on the leads table.
  const prompt = buildSystemPrompt({ ...conversation, accountId: null }, null);
  assert.ok(/mandra|atlas/i.test(identityOf(prompt)));
});

test("the unbreakable rules are in both prompts", () => {
  // The identity is what varies; the guardrails are not negotiable per client.
  // A client brief that quietly dropped "nunca invente preço" would be a bot
  // quoting prices it made up, on someone else's number.
  for (const prompt of [
    buildSystemPrompt(conversation, account),
    buildSystemPrompt({ ...conversation, accountId: null }, null),
  ]) {
    assert.ok(prompt.includes("Nunca invente preço"));
    assert.ok(prompt.includes("Nunca peça senha"));
    assert.ok(prompt.includes("Nunca diga que é humano"));
  }
});
