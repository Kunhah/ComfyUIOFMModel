import { randomUUID } from "node:crypto";
import type { DatabaseSync } from "node:sqlite";
import { getDb } from "@/lib/prospector/db";

/**
 * The WhatsApp side of the CRM, in the same SQLite file as everything else.
 *
 * Sharing `data/prospector.db` is deliberate. A conversation is *about* a lead —
 * the whole reason to answer a WhatsApp message automatically is that the person
 * on the other end is a row in `leads` with a funnel stage — and a second file
 * would mean either duplicating that row or joining across databases, which
 * SQLite can do and nobody can back up correctly. The schemas are unrelated; the
 * lifecycle is not.
 *
 * The schema lives here rather than in prospector/db.ts so the two can be read
 * apart, and is applied on first use through `waDb()`. `getDb()` has already run
 * its own DDL, its pragmas and its migrations by then, so this only ever adds
 * tables — which is also why `leads` can be referenced by foreign key from here
 * and not the other way round.
 */

/** Where a scheduled send came from, and what it is allowed to do on its own. */
export type JobKind = "once" | "cron";

export type MessageDirection = "in" | "out";

/**
 * Who produced an outbound message. Kept per row because the three are worked
 * differently: an operator's line is a human talking, the agent's is the model,
 * and a job's is a promise made earlier — and when a client complains about
 * "the robot", this column is the only thing that can answer which.
 */
export type MessageOrigin = "agent" | "job" | "operator" | "client";

export type AppointmentStatus =
  "agendado" | "confirmado" | "cancelado" | "concluido";

/**
 * The conversations table, parameterised by name.
 *
 * A function rather than a literal because `dropGlobalPhoneUnique()` has to
 * build the very same table under a scratch name. Writing the DDL twice is how
 * a rebuilt table ends up one column behind the one new databases get, and the
 * difference would only surface on a machine that had the old schema.
 */
const conversationsDdl = (table: string) => `
  CREATE TABLE IF NOT EXISTS ${table} (
    id            TEXT PRIMARY KEY,
    -- Whose conversation this is. NULL means Atlas's own, exactly as it does on
    -- the leads table: we are not a tenant of ourselves. See lib/crm/accounts.ts.
    account_id    TEXT,
    -- Bare E.164 digits, as produced by normalisePhone(). Unique *per account*,
    -- not globally: a second thread with one number inside one account is not a
    -- second conversation, it is a split history that guarantees the agent
    -- answers with half its context missing. Across accounts it is the opposite
    -- — the same person can be a client of two businesses we serve, and merging
    -- those threads would show one client's messages to another.
    --
    -- The uniqueness is a partial index rather than a column constraint (see
    -- INDEXES): SQLite treats every NULL as distinct in a UNIQUE tuple, so
    -- UNIQUE (account_id, phone) would let Atlas's own rows duplicate freely.
    phone         TEXT NOT NULL,
    -- ON DELETE SET NULL, not CASCADE: deleting a lead from the CRM must not
    -- destroy the record of what was said to a real person on WhatsApp.
    lead_id       TEXT REFERENCES leads (id) ON DELETE SET NULL,
    contact_name  TEXT,
    country       TEXT,
    -- The handoff switch. An operator who takes over turns this off and the
    -- agent stops answering — without it, a human and a model reply to the same
    -- message and the client sees the company argue with itself.
    auto_reply    INTEGER NOT NULL DEFAULT 1,
    -- Where the agent's own scheduling lands, per conversation, because a client
    -- in Lisbon and one in Belo Horizonte do not share a morning.
    timezone      TEXT,
    last_inbound_at  TEXT,
    last_outbound_at TEXT,
    created_at    TEXT NOT NULL
                  DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );
`;

const SCHEMA = `
  -- One row per number we have ever talked to. Keyed on the folded phone rather
  -- than on the lead: a person writes from the number they have, and which lead
  -- that is can be unknown at the moment the message arrives (and can be
  -- corrected later without losing the thread).
${conversationsDdl("wa_conversations")}

  -- The transcript. Also the agent's memory: the prompt is built by reading the
  -- last N rows back, so there is no in-process conversation state to lose on a
  -- deploy, and two containers would answer identically.
  CREATE TABLE IF NOT EXISTS wa_messages (
    id              INTEGER PRIMARY KEY,
    conversation_id TEXT NOT NULL
                    REFERENCES wa_conversations (id) ON DELETE CASCADE,
    direction       TEXT NOT NULL CHECK (direction IN ('in','out')),
    origin          TEXT NOT NULL DEFAULT 'client'
                    CHECK (origin IN ('agent','job','operator','client')),
    body            TEXT NOT NULL,
    -- The provider's own message id. UNIQUE and it is the whole idempotency
    -- story: Evolution retries a webhook it thinks failed, and without this the
    -- same client message is answered twice.
    provider_id     TEXT UNIQUE,
    status          TEXT NOT NULL DEFAULT 'ok'
                    CHECK (status IN ('ok','failed')),
    error           TEXT,
    -- Set when a job produced the row, so the admin screen can show which
    -- reminder actually went out rather than just that something did.
    job_id          TEXT REFERENCES wa_jobs (id) ON DELETE SET NULL,
    created_at      TEXT NOT NULL
                    DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  -- The scheduler's queue. A 'once' job is a reminder at a moment; a 'cron' job
  -- is a recurrence, kept as the expression rather than as expanded rows — see
  -- cron.ts for why.
  CREATE TABLE IF NOT EXISTS wa_jobs (
    id              TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL
                    REFERENCES wa_conversations (id) ON DELETE CASCADE,
    lead_id         TEXT REFERENCES leads (id) ON DELETE SET NULL,
    kind            TEXT NOT NULL CHECK (kind IN ('once','cron')),
    -- NULL on a 'once' job. Five Vixie fields, validated on write.
    cron            TEXT,
    -- IANA name. Never an offset: an offset is wrong twice a year in half the
    -- countries the prospector reaches, and a reminder is a wall-clock promise.
    timezone        TEXT NOT NULL,
    -- The literal text to send. Rendered by the agent when the job is created,
    -- not at send time, so what an operator reads on the schedule screen is
    -- exactly what the client will receive.
    body            TEXT NOT NULL,
    -- Why it exists, in the agent's words. Shown to operators; never sent.
    reason          TEXT,
    -- The next fire, ISO-8601 UTC. Denormalised from cron+timezone so the
    -- scheduler's hot query is an indexed range scan over one column instead of
    -- parsing every expression in the table on every tick.
    next_run_at     TEXT,
    active          INTEGER NOT NULL DEFAULT 1,
    runs            INTEGER NOT NULL DEFAULT 0,
    -- A stop condition for recurrences. The agent is required to set one: a
    -- weekly reminder with no end is a subscription the client never asked for,
    -- and nothing in a chat thread ever cancels it.
    max_runs        INTEGER,
    last_run_at     TEXT,
    last_error      TEXT,
    -- 'agent' when the model scheduled it, otherwise the operator's id.
    created_by      TEXT NOT NULL,
    -- What ended it: 'concluido', 'cancelado', 'expirado', 'erro'. NULL while
    -- active. Kept rather than deleting the row, because "why did the client
    -- stop hearing from us" is a question the row is the only answer to.
    closed_reason   TEXT,
    created_at      TEXT NOT NULL
                    DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  -- What the reminders are usually about. Separate from wa_jobs because a
  -- meeting is a fact about the relationship that outlives every message sent
  -- about it — cancelling the reminder must not erase that a call was booked.
  CREATE TABLE IF NOT EXISTS wa_appointments (
    id              TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL
                    REFERENCES wa_conversations (id) ON DELETE CASCADE,
    lead_id         TEXT REFERENCES leads (id) ON DELETE SET NULL,
    title           TEXT NOT NULL,
    -- ISO-8601 UTC. The timezone it was agreed in is kept beside it so the CRM
    -- can print the hour the client actually said out loud.
    starts_at       TEXT NOT NULL,
    timezone        TEXT NOT NULL,
    duration_minutes INTEGER NOT NULL DEFAULT 30,
    notes           TEXT,
    status          TEXT NOT NULL DEFAULT 'agendado'
                    CHECK (status IN ('agendado','confirmado','cancelado','concluido')),
    created_by      TEXT NOT NULL,
    created_at      TEXT NOT NULL
                    DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );
`;

const INDEXES = `
  -- The uniqueness the phone column no longer declares, in two halves because
  -- NULL is not comparable: one index for the accounts, one for our own rows.
  CREATE UNIQUE INDEX IF NOT EXISTS wa_conversations_account_phone
    ON wa_conversations (account_id, phone) WHERE account_id IS NOT NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS wa_conversations_atlas_phone
    ON wa_conversations (phone) WHERE account_id IS NULL;
  CREATE INDEX IF NOT EXISTS wa_conversations_recent
    ON wa_conversations (account_id, last_inbound_at DESC);
  CREATE INDEX IF NOT EXISTS wa_conversations_lead
    ON wa_conversations (lead_id) WHERE lead_id IS NOT NULL;
  CREATE INDEX IF NOT EXISTS wa_messages_thread
    ON wa_messages (conversation_id, created_at DESC);
  -- The scheduler's only query. Partial on active because a table that
  -- accumulates finished jobs forever would otherwise be scanned in full every
  -- tick to find the handful that are still live.
  CREATE INDEX IF NOT EXISTS wa_jobs_due
    ON wa_jobs (next_run_at) WHERE active = 1;
  CREATE INDEX IF NOT EXISTS wa_jobs_thread
    ON wa_jobs (conversation_id, created_at DESC);
  CREATE INDEX IF NOT EXISTS wa_appointments_when
    ON wa_appointments (starts_at);
  CREATE INDEX IF NOT EXISTS wa_appointments_thread
    ON wa_appointments (conversation_id, starts_at DESC);
`;

let ready = false;

/**
 * The shared handle, with the WhatsApp tables guaranteed to exist.
 *
 * Every reader and writer in this folder goes through it rather than `getDb()`,
 * so there is no order in which a route can touch a table before its DDL has
 * run — which is the failure mode of putting the schema in an init function
 * someone has to remember to call.
 */
export function waDb(): DatabaseSync {
  const handle = getDb();
  if (!ready) {
    handle.exec(SCHEMA);
    dropGlobalPhoneUnique(handle);
    handle.exec(INDEXES);
    ready = true;
  }
  return handle;
}

/**
 * Rebuilds `wa_conversations` without the global `phone UNIQUE`.
 *
 * The second migration in the project the additive-only rule cannot cover, and
 * for the same reason as `widenRoleCheck()` in lib/auth/users.ts: SQLite has no
 * ALTER for a constraint, and the DDL above is `CREATE TABLE IF NOT EXISTS`, so
 * an existing database keeps the global uniqueness forever. The symptom is
 * specific and bad — the first time two of our clients talk to the same person,
 * the second one's message hits a UNIQUE violation and is dropped by a webhook
 * that has already answered 200, so nobody finds out.
 *
 * Two things make this harder than the `users` rebuild:
 *
 * - **Three tables carry foreign keys into this one.** SQLite rewrites a child's
 *   `REFERENCES` when the parent is renamed, so the rename-recreate-copy order
 *   used for `users` would silently repoint `wa_messages` at the temporary
 *   table. This uses the order SQLite documents for exactly this case instead:
 *   build the new table under a scratch name, copy, drop the old, rename into
 *   place. The children's DDL still names `wa_conversations` and resolves to the
 *   new table afterwards.
 * - **`PRAGMA foreign_keys` cannot be changed inside a transaction.** It is
 *   turned off before BEGIN and restored after COMMIT, because dropping a table
 *   three others reference is refused while it is on.
 *
 * Guarded on the stored DDL, so it runs at most once per database and never on
 * a fresh one.
 */
function dropGlobalPhoneUnique(handle: DatabaseSync): void {
  const row = handle
    .prepare(
      "SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'wa_conversations'",
    )
    .get() as { sql: string | null } | undefined;

  const ddl = row?.sql ?? "";
  // The fresh DDL above says `phone TEXT NOT NULL` and nothing else; only a
  // table built by an older release carries the column-level UNIQUE.
  if (ddl.length === 0 || !/phone\s+TEXT\s+NOT\s+NULL\s+UNIQUE/i.test(ddl)) {
    return;
  }

  const COPY = `id, phone, lead_id, contact_name, country, auto_reply,
                timezone, last_inbound_at, last_outbound_at, created_at`;

  handle.exec("PRAGMA foreign_keys = OFF");
  handle.exec("BEGIN");
  try {
    handle.exec(conversationsDdl("wa_conversations_rebuilt"));
    handle.exec(
      `INSERT INTO wa_conversations_rebuilt (${COPY})
       SELECT ${COPY} FROM wa_conversations`,
    );
    handle.exec("DROP TABLE wa_conversations");
    handle.exec(
      "ALTER TABLE wa_conversations_rebuilt RENAME TO wa_conversations",
    );
    handle.exec("COMMIT");
  } catch (err) {
    handle.exec("ROLLBACK");
    throw err;
  } finally {
    // Restored even on the failure path: leaving the connection with foreign
    // keys off would silently disable every cascade for the life of the process.
    handle.exec("PRAGMA foreign_keys = ON");
  }
}

export type Conversation = {
  id: string;
  /** The client account this thread belongs to; null for Atlas's own. */
  accountId: string | null;
  phone: string;
  leadId: string | null;
  contactName: string | null;
  country: string | null;
  autoReply: boolean;
  timezone: string | null;
  lastInboundAt: string | null;
  lastOutboundAt: string | null;
  createdAt: string;
};

type ConversationRow = {
  id: string;
  account_id: string | null;
  phone: string;
  lead_id: string | null;
  contact_name: string | null;
  country: string | null;
  auto_reply: number;
  timezone: string | null;
  last_inbound_at: string | null;
  last_outbound_at: string | null;
  created_at: string;
};

function toConversation(row: ConversationRow): Conversation {
  return {
    id: row.id,
    accountId: row.account_id,
    phone: row.phone,
    leadId: row.lead_id,
    contactName: row.contact_name,
    country: row.country,
    autoReply: row.auto_reply === 1,
    timezone: row.timezone,
    lastInboundAt: row.last_inbound_at,
    lastOutboundAt: row.last_outbound_at,
    createdAt: row.created_at,
  };
}

/**
 * The thread for a number *within one account*.
 *
 * `accountId` is required rather than optional, and null is a real value
 * meaning Atlas's own — an optional parameter here would make "I forgot to pass
 * it" and "this is ours" the same call, and the failure is one client reading
 * another's conversation. The `IS` comparison rather than `=` is what makes the
 * null case match at all.
 */
export function findConversation(
  phone: string,
  accountId: string | null,
): Conversation | null {
  const row = waDb()
    .prepare(
      "SELECT * FROM wa_conversations WHERE phone = ? AND account_id IS ?",
    )
    .get(phone, accountId) as ConversationRow | undefined;
  return row ? toConversation(row) : null;
}

export function conversationById(id: string): Conversation | null {
  const row = waDb()
    .prepare("SELECT * FROM wa_conversations WHERE id = ?")
    .get(id) as ConversationRow | undefined;
  return row ? toConversation(row) : null;
}

/**
 * The conversation for a number, created if this is the first message.
 *
 * The lead lookup is by folded phone, which is the same key the CRM already
 * groups numbers on — so a WhatsApp thread attaches itself to the business the
 * prospector found without anyone linking them by hand. When several leads share
 * a number (a switchboard, which `phone_quality` exists to notice) the highest
 * scoring one wins: a wrong guess here is visible and fixable in the CRM, while
 * no guess at all leaves the agent with no idea who it is talking to.
 */
export function openConversation(input: {
  phone: string;
  /**
   * Whose thread this is. Required, and null means Atlas's own — see
   * `findConversation`. Making it optional would let a forgotten argument file a
   * client's conversation under our own pipeline, where the agent would answer
   * it with our persona.
   */
  accountId: string | null;
  contactName?: string | null;
  country?: string | null;
  timezone?: string | null;
}): Conversation {
  const handle = waDb();
  const existing = findConversation(input.phone, input.accountId);
  if (existing) {
    // A pushName can arrive after the row was created by an outbound message,
    // and a contact who sets their name later should stop being "(sem nome)".
    if (input.contactName && !existing.contactName) {
      handle
        .prepare("UPDATE wa_conversations SET contact_name = ? WHERE id = ?")
        .run(input.contactName, existing.id);
      return { ...existing, contactName: input.contactName };
    }
    return existing;
  }

  // The lead is looked up inside the same account, for the same reason the
  // thread is: matching a client's inbound number against *our* lead base would
  // attach their conversation to a business we prospected, and the agent would
  // then answer holding the wrong company's history.
  const lead = handle
    .prepare(
      `SELECT id, contact_name, country FROM leads
        WHERE phone_norm = ? AND account_id IS ?
        ORDER BY score DESC
        LIMIT 1`,
    )
    .get(input.phone, input.accountId) as
    | { id: string; contact_name: string | null; country: string | null }
    | undefined;

  const id = randomUUID();
  handle
    .prepare(
      `INSERT INTO wa_conversations
         (id, account_id, phone, lead_id, contact_name, country, timezone)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      id,
      input.accountId,
      input.phone,
      lead?.id ?? null,
      input.contactName ?? lead?.contact_name ?? null,
      input.country ?? lead?.country ?? null,
      input.timezone ?? null,
    );

  return conversationById(id)!;
}

export function setAutoReply(conversationId: string, on: boolean): boolean {
  const result = waDb()
    .prepare("UPDATE wa_conversations SET auto_reply = ? WHERE id = ?")
    .run(on ? 1 : 0, conversationId);
  return result.changes > 0;
}

/**
 * The conversation list, with the last line of each thread.
 *
 * The preview is a correlated subquery rather than a join on `wa_messages`,
 * because the interesting row is "the newest per conversation" and a plain join
 * returns every message and asks JavaScript to reduce them — which reports the
 * page size as the thread count and reads the whole transcript to render a list.
 * `wa_messages_thread` serves the subquery directly.
 */
export function listConversations(limit = 100): (Conversation & {
  lastMessage: string | null;
  lastDirection: MessageDirection | null;
  /** Live scheduled sends, so the list can show which threads are armed. */
  scheduled: number;
})[] {
  const rows = waDb()
    .prepare(
      `SELECT c.*,
              (SELECT body FROM wa_messages m
                WHERE m.conversation_id = c.id
                ORDER BY m.id DESC LIMIT 1) AS last_message,
              (SELECT direction FROM wa_messages m
                WHERE m.conversation_id = c.id
                ORDER BY m.id DESC LIMIT 1) AS last_direction,
              (SELECT COUNT(*) FROM wa_jobs j
                WHERE j.conversation_id = c.id AND j.active = 1) AS scheduled
         FROM wa_conversations c
        ORDER BY COALESCE(c.last_inbound_at, c.last_outbound_at, c.created_at) DESC
        LIMIT ?`,
    )
    .all(limit) as (ConversationRow & {
    last_message: string | null;
    last_direction: MessageDirection | null;
    scheduled: number;
  })[];

  return rows.map((row) => ({
    ...toConversation(row),
    lastMessage: row.last_message,
    lastDirection: row.last_direction,
    scheduled: row.scheduled,
  }));
}

export type StoredMessage = {
  id: number;
  conversationId: string;
  direction: MessageDirection;
  origin: MessageOrigin;
  body: string;
  providerId: string | null;
  status: "ok" | "failed";
  error: string | null;
  jobId: string | null;
  createdAt: string;
};

type MessageRow = {
  id: number;
  conversation_id: string;
  direction: MessageDirection;
  origin: MessageOrigin;
  body: string;
  provider_id: string | null;
  status: "ok" | "failed";
  error: string | null;
  job_id: string | null;
  created_at: string;
};

function toMessage(row: MessageRow): StoredMessage {
  return {
    id: row.id,
    conversationId: row.conversation_id,
    direction: row.direction,
    origin: row.origin,
    body: row.body,
    providerId: row.provider_id,
    status: row.status,
    error: row.error,
    jobId: row.job_id,
    createdAt: row.created_at,
  };
}

/**
 * Appends a message. Returns null when `providerId` has already been recorded —
 * which is how a retried webhook is dropped, and why the caller must check the
 * return rather than assuming a write happened.
 */
export function recordMessage(input: {
  conversationId: string;
  direction: MessageDirection;
  origin: MessageOrigin;
  body: string;
  providerId?: string | null;
  status?: "ok" | "failed";
  error?: string | null;
  jobId?: string | null;
}): StoredMessage | null {
  const handle = waDb();

  if (input.providerId) {
    const seen = handle
      .prepare("SELECT 1 FROM wa_messages WHERE provider_id = ?")
      .get(input.providerId);
    if (seen) return null;
  }

  const result = handle
    .prepare(
      `INSERT INTO wa_messages
         (conversation_id, direction, origin, body, provider_id, status, error, job_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      input.conversationId,
      input.direction,
      input.origin,
      input.body,
      input.providerId ?? null,
      input.status ?? "ok",
      input.error ?? null,
      input.jobId ?? null,
    );

  const column =
    input.direction === "in" ? "last_inbound_at" : "last_outbound_at";
  handle
    .prepare(
      `UPDATE wa_conversations
          SET ${column} = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
        WHERE id = ?`,
    )
    .run(input.conversationId);

  const row = handle
    .prepare("SELECT * FROM wa_messages WHERE id = ?")
    .get(result.lastInsertRowid as number) as MessageRow;
  return toMessage(row);
}

/**
 * The last `limit` messages, oldest first — the order a chat transcript is read
 * in, and the order the model needs them. The query takes the newest and the
 * caller reverses, because "the last twenty" is not expressible as an ascending
 * LIMIT without counting the table first.
 */
export function recentMessages(
  conversationId: string,
  limit = 20,
): StoredMessage[] {
  const rows = waDb()
    .prepare(
      `SELECT * FROM wa_messages
        WHERE conversation_id = ?
        ORDER BY id DESC
        LIMIT ?`,
    )
    .all(conversationId, limit) as MessageRow[];
  return rows.map(toMessage).reverse();
}

export type Job = {
  id: string;
  conversationId: string;
  leadId: string | null;
  kind: JobKind;
  cron: string | null;
  timezone: string;
  body: string;
  reason: string | null;
  nextRunAt: string | null;
  active: boolean;
  runs: number;
  maxRuns: number | null;
  lastRunAt: string | null;
  lastError: string | null;
  createdBy: string;
  closedReason: string | null;
  createdAt: string;
};

type JobRow = {
  id: string;
  conversation_id: string;
  lead_id: string | null;
  kind: JobKind;
  cron: string | null;
  timezone: string;
  body: string;
  reason: string | null;
  next_run_at: string | null;
  active: number;
  runs: number;
  max_runs: number | null;
  last_run_at: string | null;
  last_error: string | null;
  created_by: string;
  closed_reason: string | null;
  created_at: string;
};

function toJob(row: JobRow): Job {
  return {
    id: row.id,
    conversationId: row.conversation_id,
    leadId: row.lead_id,
    kind: row.kind,
    cron: row.cron,
    timezone: row.timezone,
    body: row.body,
    reason: row.reason,
    nextRunAt: row.next_run_at,
    active: row.active === 1,
    runs: row.runs,
    maxRuns: row.max_runs,
    lastRunAt: row.last_run_at,
    lastError: row.last_error,
    createdBy: row.created_by,
    closedReason: row.closed_reason,
    createdAt: row.created_at,
  };
}

export function insertJob(input: {
  conversationId: string;
  leadId: string | null;
  kind: JobKind;
  cron: string | null;
  timezone: string;
  body: string;
  reason: string | null;
  nextRunAt: string | null;
  maxRuns: number | null;
  createdBy: string;
}): Job {
  const id = randomUUID();
  waDb()
    .prepare(
      `INSERT INTO wa_jobs
         (id, conversation_id, lead_id, kind, cron, timezone, body, reason,
          next_run_at, max_runs, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      id,
      input.conversationId,
      input.leadId,
      input.kind,
      input.cron,
      input.timezone,
      input.body,
      input.reason,
      input.nextRunAt,
      input.maxRuns,
      input.createdBy,
    );
  return jobById(id)!;
}

export function jobById(id: string): Job | null {
  const row = waDb().prepare("SELECT * FROM wa_jobs WHERE id = ?").get(id) as
    JobRow | undefined;
  return row ? toJob(row) : null;
}

/**
 * Jobs whose time has come.
 *
 * `next_run_at <= now` rather than `= now`: a container that was down for an
 * hour must still send what it missed, and a scheduler that only fires on an
 * exact match silently drops every job in the gap.
 */
export function dueJobs(now: Date = new Date(), limit = 50): Job[] {
  const rows = waDb()
    .prepare(
      `SELECT * FROM wa_jobs
        WHERE active = 1 AND next_run_at IS NOT NULL AND next_run_at <= ?
        ORDER BY next_run_at
        LIMIT ?`,
    )
    .all(now.toISOString(), limit) as JobRow[];
  return rows.map(toJob);
}

/** Records a fire and where the job goes next. `nextRunAt` null closes it. */
export function advanceJob(input: {
  id: string;
  nextRunAt: string | null;
  closedReason?: string | null;
  error?: string | null;
}): void {
  waDb()
    .prepare(
      `UPDATE wa_jobs
          SET runs = runs + 1,
              last_run_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now'),
              next_run_at = ?,
              active = ?,
              closed_reason = ?,
              last_error = ?
        WHERE id = ?`,
    )
    .run(
      input.nextRunAt,
      input.nextRunAt ? 1 : 0,
      input.closedReason ?? null,
      input.error ?? null,
      input.id,
    );
}

/**
 * Takes a job out of the queue without pretending it ran.
 *
 * Used both by the cancel button and by the scheduler when an expression stops
 * producing a next run. Deliberately not a DELETE — see `closed_reason`.
 */
export function closeJob(id: string, reason: string): boolean {
  const result = waDb()
    .prepare(
      `UPDATE wa_jobs
          SET active = 0, next_run_at = NULL, closed_reason = ?
        WHERE id = ? AND active = 1`,
    )
    .run(reason, id);
  return result.changes > 0;
}

/** Every job on a thread, live ones first and then by recency. */
export function jobsFor(conversationId: string): Job[] {
  const rows = waDb()
    .prepare(
      `SELECT * FROM wa_jobs
        WHERE conversation_id = ?
        ORDER BY active DESC, next_run_at IS NULL, next_run_at, created_at DESC`,
    )
    .all(conversationId) as JobRow[];
  return rows.map(toJob);
}

export function activeJobs(limit = 200): Job[] {
  const rows = waDb()
    .prepare(
      `SELECT * FROM wa_jobs
        WHERE active = 1
        ORDER BY next_run_at IS NULL, next_run_at
        LIMIT ?`,
    )
    .all(limit) as JobRow[];
  return rows.map(toJob);
}

export type Appointment = {
  id: string;
  conversationId: string;
  leadId: string | null;
  title: string;
  startsAt: string;
  timezone: string;
  durationMinutes: number;
  notes: string | null;
  status: AppointmentStatus;
  createdBy: string;
  createdAt: string;
};

type AppointmentRow = {
  id: string;
  conversation_id: string;
  lead_id: string | null;
  title: string;
  starts_at: string;
  timezone: string;
  duration_minutes: number;
  notes: string | null;
  status: AppointmentStatus;
  created_by: string;
  created_at: string;
};

function toAppointment(row: AppointmentRow): Appointment {
  return {
    id: row.id,
    conversationId: row.conversation_id,
    leadId: row.lead_id,
    title: row.title,
    startsAt: row.starts_at,
    timezone: row.timezone,
    durationMinutes: row.duration_minutes,
    notes: row.notes,
    status: row.status,
    createdBy: row.created_by,
    createdAt: row.created_at,
  };
}

export function insertAppointment(input: {
  conversationId: string;
  leadId: string | null;
  title: string;
  startsAt: string;
  timezone: string;
  durationMinutes: number;
  notes: string | null;
  createdBy: string;
}): Appointment {
  const id = randomUUID();
  waDb()
    .prepare(
      `INSERT INTO wa_appointments
         (id, conversation_id, lead_id, title, starts_at, timezone,
          duration_minutes, notes, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      id,
      input.conversationId,
      input.leadId,
      input.title,
      input.startsAt,
      input.timezone,
      input.durationMinutes,
      input.notes,
      input.createdBy,
    );
  return appointmentById(id)!;
}

export function appointmentById(id: string): Appointment | null {
  const row = waDb()
    .prepare("SELECT * FROM wa_appointments WHERE id = ?")
    .get(id) as AppointmentRow | undefined;
  return row ? toAppointment(row) : null;
}

export function appointmentsFor(conversationId: string): Appointment[] {
  const rows = waDb()
    .prepare(
      `SELECT * FROM wa_appointments
        WHERE conversation_id = ?
        ORDER BY starts_at DESC`,
    )
    .all(conversationId) as AppointmentRow[];
  return rows.map(toAppointment);
}

/** The diary: everything still ahead, soonest first. */
export function upcomingAppointments(limit = 100): Appointment[] {
  const rows = waDb()
    .prepare(
      `SELECT * FROM wa_appointments
        WHERE status IN ('agendado','confirmado')
          AND starts_at >= strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
        ORDER BY starts_at
        LIMIT ?`,
    )
    .all(limit) as AppointmentRow[];
  return rows.map(toAppointment);
}

export function setAppointmentStatus(
  id: string,
  status: AppointmentStatus,
): boolean {
  const result = waDb()
    .prepare("UPDATE wa_appointments SET status = ? WHERE id = ?")
    .run(status, id);
  return result.changes > 0;
}
