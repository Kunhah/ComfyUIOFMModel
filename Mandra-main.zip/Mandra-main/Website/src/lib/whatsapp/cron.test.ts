import test from "node:test";
import assert from "node:assert/strict";

import {
  CronError,
  describeCron,
  isValidCron,
  nextRunOf,
  parseCron,
} from "@/lib/whatsapp/cron";

const SP = "America/Sao_Paulo";

test("parses the five fields", () => {
  const f = parseCron("30 9 * * 1");
  assert.deepEqual(f.minute, [30]);
  assert.deepEqual(f.hour, [9]);
  assert.deepEqual(f.dayOfWeek, [1]);
  assert.equal(f.dowRestricted, true);
  assert.equal(f.domRestricted, false);
});

test("expands lists, ranges and steps", () => {
  assert.deepEqual(parseCron("0,30 * * * *").minute, [0, 30]);
  assert.deepEqual(parseCron("0 9-12 * * *").hour, [9, 10, 11, 12]);
  assert.deepEqual(parseCron("*/15 * * * *").minute, [0, 15, 30, 45]);
  assert.deepEqual(parseCron("0 8-18/4 * * *").hour, [8, 12, 16]);
});

test("accepts month and weekday names, and folds Sunday-7 onto 0", () => {
  assert.deepEqual(parseCron("0 0 1 jan *").month, [1]);
  assert.deepEqual(parseCron("0 9 * * mon,fri").dayOfWeek, [1, 5]);
  assert.deepEqual(parseCron("0 9 * * 7").dayOfWeek, [0]);
});

test("expands @aliases", () => {
  assert.deepEqual(parseCron("@daily").hour, [0]);
  assert.deepEqual(parseCron("@weekly").dayOfWeek, [0]);
});

test("refuses what it cannot honour rather than guessing", () => {
  // Six fields is a seconds-resolution cron; dropping the extra field would run
  // the job sixty times more often than asked.
  assert.throws(() => parseCron("0 0 9 * * 1"), CronError);
  assert.throws(() => parseCron("60 9 * * *"), CronError);
  assert.throws(() => parseCron("0 9 * * 9"), CronError);
  assert.throws(() => parseCron("12-3 9 * * *"), CronError);
  assert.throws(() => parseCron(""), CronError);
  assert.equal(isValidCron("0 9 * * 1"), true);
  assert.equal(isValidCron("nonsense"), false);
});

test("fires at the wall clock of the given timezone, not the container's", () => {
  // 2026-03-02 is a Monday. 09:00 in São Paulo (UTC-3) is 12:00Z — a scheduler
  // that computed in UTC would send this at 06:00 local.
  const next = nextRunOf("0 9 * * 1", Date.parse("2026-03-02T00:00:00Z"), SP);
  assert.equal(next?.toISOString(), "2026-03-02T12:00:00.000Z");
});

test("never returns the minute it was asked from", () => {
  // Called right as a job fires, the answer must be the *next* occurrence or the
  // scheduler re-sends the same message in a loop.
  const at = Date.parse("2026-03-02T12:00:00Z");
  const next = nextRunOf("0 9 * * 1", at, SP);
  assert.equal(next?.toISOString(), "2026-03-09T12:00:00.000Z");
});

test("rolls over the end of a month and a year", () => {
  const next = nextRunOf("0 9 1 * *", Date.parse("2026-12-15T00:00:00Z"), SP);
  assert.equal(next?.toISOString(), "2027-01-01T12:00:00.000Z");
});

test("crosses a DST change in a timezone that still has one", () => {
  // Lisbon springs forward 2026-03-29 at 01:00 UTC. A 09:00 daily reminder is
  // 09:00Z the day before and 08:00Z after, because the wall clock is what was
  // promised.
  const before = nextRunOf(
    "0 9 * * *",
    Date.parse("2026-03-27T12:00:00Z"),
    "Europe/Lisbon",
  );
  assert.equal(before?.toISOString(), "2026-03-28T09:00:00.000Z");
  // 02:00Z on the 29th is already 03:00 local, so the next 09:00 promise falls
  // the same day and is an hour earlier in UTC than it was two days before.
  const after = nextRunOf(
    "0 9 * * *",
    Date.parse("2026-03-29T02:00:00Z"),
    "Europe/Lisbon",
  );
  assert.equal(after?.toISOString(), "2026-03-29T08:00:00.000Z");
});

test("ORs the two day fields only when both are restricted", () => {
  // Vixie's rule: `* * 13 * 5` is the 13th *or* any Friday, while `* * * * 5`
  // is Fridays only. Reading the first as AND is how a job silently never runs.
  const or = nextRunOf("0 9 13 * 5", Date.parse("2026-03-02T12:00:00Z"), SP);
  assert.equal(or?.toISOString(), "2026-03-06T12:00:00.000Z"); // Friday the 6th
  const and = nextRunOf("0 9 * * 5", Date.parse("2026-03-02T12:00:00Z"), SP);
  assert.equal(and?.toISOString(), "2026-03-06T12:00:00.000Z");
});

test("reports an expression that can never match instead of looping", () => {
  assert.equal(nextRunOf("0 0 30 2 *", Date.now(), SP), null);
});

test("describes the shapes the agent is told to produce", () => {
  assert.equal(describeCron("0 9 * * *"), "todos os dias às 09:00");
  assert.equal(describeCron("30 14 * * 1"), "toda segunda às 14:30");
  assert.equal(describeCron("0 9 5 * *"), "todo dia 5 às 09:00");
  // Anything else prints itself rather than a wrong sentence.
  assert.equal(describeCron("*/7 * * * *"), "*/7 * * * *");
});
