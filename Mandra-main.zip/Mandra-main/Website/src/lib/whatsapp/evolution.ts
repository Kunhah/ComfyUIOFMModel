import { timingSafeEqual } from "node:crypto";
import { normalisePhone } from "@/lib/prospector/score";

/**
 * The WhatsApp transport: Evolution API, self-hosted beside this app.
 *
 * Everything WhatsApp-specific is behind this file — the rest of the folder
 * deals in phone numbers and strings. That boundary is the point: Evolution is
 * an unofficial bridge, and the day it has to become Meta's Cloud API (a ban, a
 * client who needs the official one, a volume that justifies the cost) the agent,
 * the scheduler and the CRM must not know. What would leak otherwise is the JID
 * format, which is the only WhatsApp concept the rest of the system would
 * otherwise have to learn.
 *
 * Configured entirely from the environment, and absent configuration is a
 * supported state rather than a crash: a deployment with no WhatsApp still runs
 * the CRM, the prospector and the marketing site, and the admin screen says the
 * integration is off. See `whatsappConfigured()`.
 */

export type EvolutionConfig = {
  /** Base URL of the Evolution instance, no trailing slash. */
  baseUrl: string;
  apiKey: string;
  /** The instance name Evolution knows this connection by. */
  instance: string;
};

/** The bridge itself, without saying which paired number to act as. */
export type EvolutionServer = { baseUrl: string; apiKey: string };

/**
 * There is one Evolution beside this app and it serves every account. The URL
 * and the key are therefore environment, while the *instance* — which paired
 * number a request acts as — is per account and comes from the `accounts` row.
 *
 * Keeping the two apart is what stops a per-client bridge from creeping in: a
 * second URL per customer is a second container to run, pair and monitor for
 * every customer sold.
 */
export function evolutionServer(): EvolutionServer | null {
  const baseUrl = process.env.EVOLUTION_API_URL?.trim().replace(/\/+$/, "");
  const apiKey = process.env.EVOLUTION_API_KEY?.trim();
  if (!baseUrl || !apiKey) return null;
  return { baseUrl, apiKey };
}

/**
 * Atlas's own instance, from the environment.
 *
 * This is the number *we* prospect from, and it is deliberately not an account:
 * Atlas is not a tenant of itself (see the note at the top of lib/crm/accounts.ts).
 * A client's instance comes from their row instead — pass it explicitly.
 */
export function evolutionConfig(
  instance?: string | null,
): EvolutionConfig | null {
  const server = evolutionServer();
  if (!server) return null;
  const name = instance?.trim() || process.env.EVOLUTION_INSTANCE?.trim();
  if (!name) return null;
  return { ...server, instance: name };
}

/**
 * Whether the bridge is usable at all. Asks only about the server, because an
 * account with no instance is a client not yet connected — a normal state that
 * the admin screen reports per account, not a broken deployment.
 */
export function whatsappConfigured(): boolean {
  return evolutionServer() !== null;
}

/** Whether *our own* number is configured, as opposed to a client's. */
export function atlasWhatsappConfigured(): boolean {
  return evolutionConfig() !== null;
}

/**
 * The shared secret the webhook is checked against.
 *
 * Separate from the API key on purpose: the API key is ours and authenticates us
 * *to* Evolution, while this authenticates Evolution *to* us. Reusing one value
 * for both directions means a compromise of the bridge hands over the key that
 * lets anything post fabricated client messages into the CRM.
 */
export function webhookSecret(): string | null {
  const value = process.env.EVOLUTION_WEBHOOK_SECRET?.trim();
  return value && value.length > 0 ? value : null;
}

/**
 * Constant-time comparison of the presented token.
 *
 * Length is compared first and leaks, which is fine — the timing signal worth
 * closing is the per-byte one that lets a token be guessed a character at a
 * time. `timingSafeEqual` throws on unequal lengths, so there is no way to do
 * this without the early return.
 */
export function webhookTokenValid(presented: string | null): boolean {
  const expected = webhookSecret();
  // No secret configured means no webhook is accepted. The alternative default —
  // accept everything — turns a forgotten variable into an open endpoint that
  // writes to the lead base and makes the agent reply to strangers.
  if (!expected) return false;
  if (!presented) return false;
  const a = Buffer.from(presented);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

/**
 * A WhatsApp JID reduced to the bare digits the CRM keys on.
 *
 * Returns null for anything that is not one person's number: groups (`@g.us`),
 * status broadcasts and newsletters. The agent must never answer a group — it
 * would reply to every message in it, in public, on behalf of the company.
 *
 * The `:12` device suffix in `5531999998888:12@s.whatsapp.net` is WhatsApp's
 * multi-device marker and is not part of the number; leaving it on produces a
 * phone that matches no lead and a second conversation row for the same person
 * every time they change handset.
 */
export function jidToPhone(jid: string | null | undefined): string | null {
  if (!jid) return null;
  if (!jid.endsWith("@s.whatsapp.net") && !jid.endsWith("@c.us")) return null;
  const user = jid.split("@")[0]?.split(":")[0] ?? "";
  const digits = user.replace(/\D/g, "");
  if (digits.length < 8) return null;
  return digits;
}

/**
 * The digits Evolution wants to send to.
 *
 * `normalisePhone` is the CRM's own folder and takes the country into account,
 * which matters for a base that is no longer Brazil-only: a number stored
 * nationally would otherwise be sent as typed and reach nobody.
 */
export function phoneToSend(
  phone: string,
  country?: string | null,
): string | null {
  return normalisePhone(phone, country);
}

export class EvolutionError extends Error {
  // Not a constructor parameter property: Node's type stripping rejects those,
  // and this module is reached from the scheduler tests.
  readonly status?: number;

  constructor(message: string, status?: number) {
    super(message);
    this.status = status;
  }
}

/**
 * How long a send may take before we give up.
 *
 * The webhook that triggers a reply is answered by Evolution's own retry logic,
 * so a request that hangs holds the tick or the webhook open behind it. Twenty
 * seconds is past any healthy send and short of the platform timeouts around it.
 */
const SEND_TIMEOUT_MS = 20_000;

async function call<T>(
  config: EvolutionServer,
  path: string,
  init: RequestInit,
): Promise<T> {
  const response = await fetch(`${config.baseUrl}${path}`, {
    ...init,
    headers: {
      "content-type": "application/json",
      apikey: config.apiKey,
      ...(init.headers ?? {}),
    },
    signal: AbortSignal.timeout(SEND_TIMEOUT_MS),
  });

  if (!response.ok) {
    // The body carries Evolution's own reason ("instance not connected", a
    // number that is not on WhatsApp) and it is the only useful half of the
    // failure — a bare status tells an operator nothing about which of the two
    // it was. Capped because an HTML error page from a proxy in front of it
    // would otherwise be stored whole in `wa_messages.error`.
    const detail = (await response.text().catch(() => "")).slice(0, 400);
    throw new EvolutionError(
      `Evolution respondeu ${response.status}${detail ? `: ${detail}` : ""}`,
      response.status,
    );
  }

  return (await response.json()) as T;
}

export type SendResult = {
  /** The provider's message id, stored to recognise our own echo on the webhook. */
  providerId: string | null;
};

/**
 * Sends a text message. Throws EvolutionError on anything but success — the
 * callers all record the failure against the row that caused it, which is what
 * makes a dead reminder visible on the schedule screen instead of silent.
 */
export async function sendText(input: {
  phone: string;
  text: string;
  country?: string | null;
  /**
   * Which paired number to send as. Omitted means Atlas's own, from the
   * environment — never "any instance": a reply that goes out from the wrong
   * number reaches the right person as a stranger, and the thread it belongs to
   * is on another phone entirely.
   */
  instance?: string | null;
}): Promise<SendResult> {
  const config = evolutionConfig(input.instance);
  if (!config) {
    throw new EvolutionError(
      input.instance
        ? `WhatsApp não está configurado para a instância ${input.instance}.`
        : "WhatsApp não está configurado (EVOLUTION_API_URL, EVOLUTION_API_KEY, EVOLUTION_INSTANCE).",
    );
  }

  const number = phoneToSend(input.phone, input.country);
  if (!number) {
    throw new EvolutionError(`Número inválido para envio: ${input.phone}`);
  }

  const body = await call<{ key?: { id?: string } }>(
    config,
    `/message/sendText/${encodeURIComponent(config.instance)}`,
    {
      method: "POST",
      body: JSON.stringify({
        number,
        text: input.text,
        // Evolution's own typing simulation. A reply that lands the instant the
        // client hits send reads as a machine to everyone; a couple of seconds
        // of "digitando…" is the difference between a bot and an assistant, and
        // it costs the tick nothing because the delay happens on the bridge.
        delay: 1200,
        // Shows "digitando…" while the delay above runs, so the pause reads as
        // someone typing rather than as a laggy bot.
        //
        // Note what this does NOT do: nothing here verifies the number is on
        // WhatsApp. Evolution accepts the send and reports success, so a
        // reminder aimed at a landline looks delivered. The defence is upstream
        // — `isWhatsappCapable()` decides which leads get a WhatsApp button at
        // all — and it is a country-pattern guess, not a lookup. On the
        // countries where `mobile` is null (the US and Canada share one format
        // for mobiles and landlines) we genuinely cannot tell.
        options: { presence: "composing" },
      }),
    },
  );

  return { providerId: body.key?.id ?? null };
}

/** Whether the bridge says the instance is paired and online. */
export async function connectionState(): Promise<{
  configured: boolean;
  state: string | null;
  error: string | null;
}> {
  const config = evolutionConfig();
  if (!config) return { configured: false, state: null, error: null };

  try {
    const body = await call<{ instance?: { state?: string }; state?: string }>(
      config,
      `/instance/connectionState/${encodeURIComponent(config.instance)}`,
      { method: "GET" },
    );
    return {
      configured: true,
      state: body.instance?.state ?? body.state ?? null,
      error: null,
    };
  } catch (error) {
    // A status screen must not throw. "We could not ask" is itself the answer an
    // operator needs, and it is the state a bridge that is down produces.
    return {
      configured: true,
      state: null,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

/**
 * What we take from a webhook payload, once it is known to be a real inbound
 * message from a real person.
 */
export type InboundMessage = {
  phone: string;
  /** The contact's WhatsApp display name, when they have one set. */
  pushName: string | null;
  text: string;
  providerId: string | null;
  /**
   * The Evolution instance the message arrived on — that is, which of our
   * paired numbers it was sent *to*.
   *
   * The only field in an inbound webhook that identifies the recipient: `phone`
   * says who wrote, never who they wrote to. It is what the webhook joins to
   * `accounts.wa_instance` to decide whose CRM the conversation belongs in, so
   * a payload without it cannot be attributed and is dropped rather than
   * guessed at.
   */
  instance: string | null;
};

/**
 * Pulls an inbound message out of an Evolution webhook body, or null.
 *
 * Null covers a great deal: delivery receipts, our own outbound echo
 * (`fromMe`), group traffic, reactions, and the media messages we have no
 * transcript for. All of them are ordinary events on a live number rather than
 * errors, so the route answers 200 to each and does nothing — the alternative is
 * a bridge that retries forever because we called a photo a failure.
 *
 * Deliberately defensive about shape. Evolution's payload has changed between
 * minor versions more than once, and a thrown TypeError inside a webhook is a
 * retry loop we would find out about from the client, not from the logs.
 */
export function parseInbound(payload: unknown): InboundMessage | null {
  if (!payload || typeof payload !== "object") return null;
  const body = payload as Record<string, unknown>;

  const event = typeof body.event === "string" ? body.event : "";
  // Evolution writes the event either dotted or underscored depending on the
  // version and on whether webhook-by-events is on.
  if (event.replace(/_/g, ".") !== "messages.upsert") return null;

  const data = body.data as Record<string, unknown> | undefined;
  if (!data || typeof data !== "object") return null;

  const key = data.key as Record<string, unknown> | undefined;
  if (!key) return null;
  if (key.fromMe === true) return null;

  const phone = jidToPhone(
    typeof key.remoteJid === "string" ? key.remoteJid : null,
  );
  if (!phone) return null;

  const text = messageText(data.message);
  if (!text) return null;

  return {
    phone,
    pushName:
      typeof data.pushName === "string" && data.pushName.trim()
        ? data.pushName.trim().slice(0, 120)
        : null,
    text,
    providerId: typeof key.id === "string" ? key.id : null,
    // Evolution puts it at the top level of every webhook body. `instanceName`
    // is the v1 spelling and still turns up behind an older bridge.
    instance:
      (typeof body.instance === "string" && body.instance.trim()) ||
      (typeof body.instanceName === "string" && body.instanceName.trim()) ||
      null,
  };
}

/**
 * The readable text of a message, across the shapes WhatsApp uses for it.
 *
 * A plain message is `conversation`; one with a link preview or a reply becomes
 * `extendedTextMessage`; a photo with a caption carries the words in
 * `imageMessage.caption`. Reading only the first would make the agent ignore
 * every message the client sent as a reply to another, which in practice is most
 * of a real conversation.
 */
function messageText(message: unknown): string | null {
  if (!message || typeof message !== "object") return null;
  const m = message as Record<string, unknown>;

  const candidates = [
    m.conversation,
    (m.extendedTextMessage as Record<string, unknown> | undefined)?.text,
    (m.imageMessage as Record<string, unknown> | undefined)?.caption,
    (m.videoMessage as Record<string, unknown> | undefined)?.caption,
    (m.documentMessage as Record<string, unknown> | undefined)?.caption,
    (m.buttonsResponseMessage as Record<string, unknown> | undefined)
      ?.selectedDisplayText,
    (m.listResponseMessage as Record<string, unknown> | undefined)?.title,
  ];

  for (const candidate of candidates) {
    if (typeof candidate === "string" && candidate.trim()) {
      // WhatsApp accepts 65.536 characters. Nothing downstream benefits from
      // more than a couple of thousand, and the prompt is billed by the token.
      return candidate.trim().slice(0, 4000);
    }
  }
  return null;
}

/* -------------------------------------------------------------------------- */
/* Pairing                                                                     */
/* -------------------------------------------------------------------------- */

/**
 * Creating and pairing an instance — what used to be four `curl` commands in a
 * comment in docker-compose.yml.
 *
 * They live here for the same reason `sendText` does: this is the only file that
 * knows what Evolution's API looks like, so replacing the bridge later touches
 * one file. The admin screen deals in "connect this client's number" and never
 * in instance endpoints.
 *
 * Every one of them is idempotent-ish on purpose, because the screen that calls
 * them is a button someone will press twice: creating an instance that exists
 * answers with an error we read as "already there", and setting a webhook is a
 * replace rather than an append.
 */

/** What the pairing screen needs to render one step of the flow. */
export type PairingState = {
  /** Evolution's own word: "open" is paired and online. */
  state: "open" | "connecting" | "close" | "unknown";
  /** A data: URI for the QR code, while one is being offered. */
  qr: string | null;
  /** The type-in-the-phone alternative to scanning, when the bridge offers one. */
  pairingCode: string | null;
};

/**
 * A deterministic instance name for an account.
 *
 * Derived from the slug rather than random, so the instance in Evolution can be
 * recognised by a person reading `docker exec` output, and so re-running the
 * connect flow for one client cannot leave a second orphaned instance holding a
 * paired session. The slug is already unique and already URL-safe.
 */
export function instanceNameFor(slug: string): string {
  return slug.slice(0, 48);
}

/**
 * Creates the instance if it is not already there.
 *
 * Evolution answers 403 for a name that exists, which is not an error here —
 * the operator pressing "connect" again on a half-finished pairing means "carry
 * on", not "start over". Anything else is re-thrown: a bridge that is down must
 * not read as a successful create followed by a QR that never appears.
 */
export async function ensureInstance(instance: string): Promise<void> {
  const server = evolutionServer();
  if (!server) throw new EvolutionError("WhatsApp não está configurado.");

  try {
    await call(server, "/instance/create", {
      method: "POST",
      body: JSON.stringify({
        instanceName: instance,
        qrcode: true,
        integration: "WHATSAPP-BAILEYS",
      }),
    });
  } catch (error) {
    const already =
      error instanceof EvolutionError &&
      (error.status === 403 ||
        /already in use|already exists/i.test(error.message));
    if (!already) throw error;
  }
}

/**
 * Points the instance at our webhook.
 *
 * Done on every connect rather than only on create, because the URL changes
 * whenever the CRM moves host and a stale one is invisible: the number pairs,
 * the screen says connected, and not one message ever arrives. Only
 * MESSAGES_UPSERT is subscribed — every other event is parsed and dropped by
 * `parseInbound`, so subscribing to them is bandwidth and log noise.
 */
export async function setInstanceWebhook(
  instance: string,
  url: string,
): Promise<void> {
  const server = evolutionServer();
  if (!server) throw new EvolutionError("WhatsApp não está configurado.");

  const secret = webhookSecret();
  if (!secret) {
    // Refused rather than configured without one: the webhook rejects every
    // request when the secret is unset, so this would pair a number whose
    // messages can never be accepted.
    throw new EvolutionError(
      "EVOLUTION_WEBHOOK_SECRET não está definido — o webhook recusaria tudo.",
    );
  }

  await call(server, `/webhook/set/${encodeURIComponent(instance)}`, {
    method: "POST",
    body: JSON.stringify({
      webhook: {
        enabled: true,
        url,
        headers: { "x-webhook-token": secret },
        events: ["MESSAGES_UPSERT"],
      },
    }),
  });
}

/**
 * Asks for the QR code, or reports that the number is already paired.
 *
 * Evolution returns the image as raw base64 without the data: prefix on some
 * versions and with it on others, so the prefix is normalised here rather than
 * in the component — an `<img>` with a bare base64 src renders as a broken
 * image and looks like a pairing failure.
 */
export async function connectInstance(instance: string): Promise<PairingState> {
  const server = evolutionServer();
  if (!server) throw new EvolutionError("WhatsApp não está configurado.");

  const state = await instanceState(instance);
  if (state === "open") return { state, qr: null, pairingCode: null };

  const body = await call<{
    base64?: string;
    code?: string;
    pairingCode?: string;
  }>(server, `/instance/connect/${encodeURIComponent(instance)}`, {
    method: "GET",
  });

  const raw = typeof body.base64 === "string" ? body.base64 : null;
  const qr = raw
    ? raw.startsWith("data:")
      ? raw
      : `data:image/png;base64,${raw}`
    : null;

  return {
    state: qr ? "connecting" : state,
    qr,
    pairingCode:
      typeof body.pairingCode === "string" && body.pairingCode
        ? body.pairingCode
        : null,
  };
}

/** Whether the number is paired and online right now. */
export async function instanceState(
  instance: string,
): Promise<PairingState["state"]> {
  const server = evolutionServer();
  if (!server) return "unknown";

  try {
    const body = await call<{ instance?: { state?: string } }>(
      server,
      `/instance/connectionState/${encodeURIComponent(instance)}`,
      { method: "GET" },
    );
    const state = body.instance?.state;
    return state === "open" || state === "connecting" || state === "close"
      ? state
      : "unknown";
  } catch {
    // An instance that does not exist yet answers 404, which is a normal state
    // for an account nobody has connected — not something to show as an error.
    return "unknown";
  }
}

/**
 * The paired number, once WhatsApp has told the bridge what it is.
 *
 * Shown on the admin screen so an operator can confirm they paired the phone
 * they meant to. Best-effort: a missing owner is a blank line, never a failure —
 * the connection is what matters and it is reported separately.
 */
export async function instanceNumber(instance: string): Promise<string | null> {
  const server = evolutionServer();
  if (!server) return null;

  try {
    const body = await call<
      | { instance?: { owner?: string; ownerJid?: string } }[]
      | {
          instance?: { owner?: string; ownerJid?: string };
        }
    >(
      server,
      `/instance/fetchInstances?instanceName=${encodeURIComponent(instance)}`,
      { method: "GET" },
    );
    const first = Array.isArray(body) ? body[0] : body;
    const jid = first?.instance?.ownerJid ?? first?.instance?.owner ?? null;
    return jidToPhone(jid) ?? (jid ? jid.replace(/\D/g, "") || null : null);
  } catch {
    return null;
  }
}

/**
 * Unpairs and removes the instance.
 *
 * Logout first, then delete: deleting a connected instance leaves the session
 * on the phone's linked-devices list, so the client sees a device they cannot
 * remove from our side. Both are best-effort — the account row is unbound by
 * the caller either way, and an instance that is already gone must not stop us
 * recording that the client is disconnected.
 */
export async function removeInstance(instance: string): Promise<void> {
  const server = evolutionServer();
  if (!server) return;

  for (const step of [
    {
      path: `/instance/logout/${encodeURIComponent(instance)}`,
      method: "DELETE",
    },
    {
      path: `/instance/delete/${encodeURIComponent(instance)}`,
      method: "DELETE",
    },
  ]) {
    try {
      await call(server, step.path, { method: step.method });
    } catch {
      // Deliberately swallowed. See above.
    }
  }
}
