import { describeCron, nextRunOf } from "./cron";
import {
  advanceJob,
  closeJob,
  conversationById,
  dueJobs,
  insertAppointment,
  insertJob,
  jobsFor,
  type Appointment,
  type Job,
} from "./db";
import { deliver } from "./sender";
import { recordProspectorActivity } from "@/lib/prospector/db";
import { setFollowUp } from "@/lib/prospector/history";
import type {
  RecurringAction,
  ReminderAction,
  ScheduleAction,
} from "./actions";

/**
 * The half of the feature that runs when nobody is looking.
 *
 * `dispatchDue()` is the whole scheduler: find the jobs whose time has come,
 * send them, work out where each goes next. It is called on a timer from
 * `instrumentation.ts` and by `/api/v1/whatsapp/tick`, and it is safe to call
 * either way at any frequency — everything it decides is derived from the row
 * it is holding, so an extra call finds nothing due and does nothing.
 *
 * The queue is in SQLite rather than in `setTimeout`, for the same reason the
 * call queue is: a timer is lost on every deploy, and a reminder that silently
 * evaporates when a container restarts is worse than one that never existed,
 * because the client was told it was coming.
 */

/** How many jobs one tick will send. */
const BATCH = 25;

/**
 * How late a job may be and still be sent.
 *
 * A container down for a weekend comes back holding Friday's reminders. Sending
 * them is worse than dropping them — "lembrando da nossa conversa de amanhã"
 * arriving on Monday about a Saturday that has passed is a message that damages
 * the relationship it was meant to maintain. Six hours covers a deploy, a
 * restart and a short outage, and nothing longer.
 */
const MAX_LATENESS_MS = 6 * 60 * 60 * 1000;

export type TickResult = {
  sent: number;
  failed: number;
  skipped: number;
};

export async function dispatchDue(now: Date = new Date()): Promise<TickResult> {
  const result: TickResult = { sent: 0, failed: 0, skipped: 0 };

  for (const job of dueJobs(now, BATCH)) {
    const due = job.nextRunAt ? Date.parse(job.nextRunAt) : now.getTime();

    if (now.getTime() - due > MAX_LATENESS_MS) {
      // Skipped, not sent — and the recurrence still moves on, so a weekly job
      // that missed one Monday resumes on the next instead of dying.
      const following = followingRun(job, now);
      advanceJob({
        id: job.id,
        nextRunAt: following,
        closedReason: following ? null : "expirado",
        error: `Atrasado demais (${Math.round((now.getTime() - due) / 60000)} min); não enviado.`,
      });
      result.skipped += 1;
      continue;
    }

    const conversation = conversationById(job.conversationId);
    if (!conversation) {
      closeJob(job.id, "cancelado");
      result.skipped += 1;
      continue;
    }

    const delivery = await deliver({
      conversationId: job.conversationId,
      text: job.body,
      origin: "job",
      jobId: job.id,
    });

    if (delivery.ok) result.sent += 1;
    else result.failed += 1;

    // A failed send still counts as an attempt and still advances the job. The
    // alternative — leaving `next_run_at` in the past — makes the tick retry it
    // every 30 seconds forever, which against a disconnected bridge is a log
    // full of the same error and against a blocked number is a queue that never
    // drains.
    const following = delivery.ok
      ? followingRun(job, now)
      : failureRun(job, now);
    advanceJob({
      id: job.id,
      nextRunAt: following,
      closedReason: following ? null : delivery.ok ? "concluido" : "erro",
      error: delivery.error,
    });
  }

  return result;
}

/**
 * Where a job goes after a successful fire, or null when it is finished.
 *
 * A `once` job is always finished. A recurrence stops when it has run
 * `max_runs` times — which is mandatory, see actions.ts — or when its expression
 * stops producing runs at all.
 */
function followingRun(job: Job, now: Date): string | null {
  if (job.kind === "once") return null;
  if (!job.cron) return null;

  // `runs` is the count *before* this fire; the row is incremented by the same
  // advanceJob call that stores this value, so the comparison has to include it.
  const completed = job.runs + 1;
  if (job.maxRuns !== null && completed >= job.maxRuns) return null;

  return nextRunOf(job.cron, now, job.timezone)?.toISOString() ?? null;
}

/**
 * Where a job goes after a failed fire.
 *
 * A one-off gets one retry, fifteen minutes out, because the common failure is a
 * bridge that was reconnecting; a second failure closes it. A recurrence just
 * waits for its next slot — retrying a weekly nudge in fifteen minutes turns one
 * missed reminder into two messages in an afternoon.
 */
function failureRun(job: Job, now: Date): string | null {
  if (job.kind === "cron") return followingRun(job, now);
  if (job.runs >= 1) return null;
  return new Date(now.getTime() + 15 * 60_000).toISOString();
}

/**
 * Turns a validated one-off reminder into a row.
 *
 * The action has already been through `parseAgentReply`, so the time is known to
 * be in the future and inside the horizon. Nothing here re-validates it; if that
 * ever stops being true, the fix is in actions.ts and not a second check here
 * that can disagree with the first.
 */
export function scheduleReminder(input: {
  conversationId: string;
  leadId: string | null;
  action: ReminderAction;
  createdBy: string;
}): Job {
  return insertJob({
    conversationId: input.conversationId,
    leadId: input.leadId,
    kind: "once",
    cron: null,
    timezone: input.action.timezone,
    body: input.action.body,
    reason: input.action.reason,
    nextRunAt: input.action.runAt,
    maxRuns: 1,
    createdBy: input.createdBy,
  });
}

export function scheduleRecurring(input: {
  conversationId: string;
  leadId: string | null;
  action: RecurringAction;
  createdBy: string;
  now?: Date;
}): Job | null {
  const first = nextRunOf(
    input.action.cron,
    input.now ?? new Date(),
    input.action.timezone,
  );
  // Already rejected upstream when the expression never matches; belt and braces
  // because a row with no next run is a job that sits active and dead forever.
  if (!first) return null;

  return insertJob({
    conversationId: input.conversationId,
    leadId: input.leadId,
    kind: "cron",
    cron: input.action.cron,
    timezone: input.action.timezone,
    body: input.action.body,
    reason: input.action.reason,
    nextRunAt: first.toISOString(),
    maxRuns: input.action.maxRuns,
    createdBy: input.createdBy,
  });
}

/**
 * How long before a meeting the client is nudged about it.
 *
 * A day out is early enough to rearrange and late enough to be relevant; an hour
 * out is what stops a booked call being forgotten over lunch. Both are skipped
 * when the meeting is nearer than the offset — a call booked for this afternoon
 * must not fire a "tomorrow" reminder into the past.
 */
const APPOINTMENT_REMINDERS: { beforeMs: number; label: string }[] = [
  { beforeMs: 24 * 60 * 60 * 1000, label: "amanhã" },
  { beforeMs: 60 * 60 * 1000, label: "em uma hora" },
];

/**
 * Books a meeting and the reminders that go with it.
 *
 * The reminders are created here rather than left to the model, because the
 * client's experience of "agendado" is the reminder — an appointment nobody is
 * nudged about is a row in a table. Asking the agent to remember to schedule
 * them makes it a coin flip per conversation.
 */
export function scheduleAppointment(input: {
  conversationId: string;
  leadId: string | null;
  action: ScheduleAction;
  createdBy: string;
  now?: Date;
}): { appointment: Appointment; reminders: Job[] } {
  const appointment = insertAppointment({
    conversationId: input.conversationId,
    leadId: input.leadId,
    title: input.action.title,
    startsAt: input.action.startsAt,
    timezone: input.action.timezone,
    durationMinutes: input.action.durationMinutes,
    notes: input.action.notes,
    createdBy: input.createdBy,
  });

  const now = input.now ?? new Date();
  const startsAt = Date.parse(appointment.startsAt);
  const local = localTime(appointment.startsAt, appointment.timezone);
  const reminders: Job[] = [];

  for (const { beforeMs, label } of APPOINTMENT_REMINDERS) {
    const runAt = startsAt - beforeMs;
    if (runAt <= now.getTime()) continue;
    reminders.push(
      insertJob({
        conversationId: input.conversationId,
        leadId: input.leadId,
        kind: "once",
        cron: null,
        timezone: appointment.timezone,
        body:
          `Oi! Passando para lembrar do nosso ${appointment.title.toLowerCase()} ` +
          `${label}, ${local}. Fica bom para você?`,
        reason: `Lembrete automático do agendamento de ${local}`,
        nextRunAt: new Date(runAt).toISOString(),
        maxRuns: 1,
        createdBy: input.createdBy,
      }),
    );
  }

  // The CRM's own follow-up date, so a booked meeting shows up in the operator's
  // work queue and not only in the WhatsApp screen. Date-only on purpose — that
  // column is a human work queue, not a scheduler (see prospector/db.ts).
  if (input.leadId) {
    setFollowUp(
      input.leadId,
      isoDate(appointment.startsAt, appointment.timezone),
    );
    recordProspectorActivity({
      actor: {
        id: "whatsapp:agent",
        username: "whatsapp",
        displayName: "Agente WhatsApp",
      },
      action: "follow_up",
      leadId: input.leadId,
      detail: `${appointment.title} agendado para ${local} pelo agente do WhatsApp`,
    });
  }

  return { appointment, reminders };
}

/** Cancels every live job on a thread. Returns how many were closed. */
export function cancelJobs(conversationId: string, reason: string): number {
  let closed = 0;
  for (const job of jobsFor(conversationId)) {
    if (job.active && closeJob(job.id, reason)) closed += 1;
  }
  return closed;
}

/** "quinta-feira, 05/09 às 14:00" — how a person would say it. */
export function localTime(iso: string, timezone: string): string {
  const formatted = new Intl.DateTimeFormat("pt-BR", {
    timeZone: timezone,
    weekday: "long",
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(new Date(iso));
  // Intl gives "quinta-feira, 05/09, 14:00"; the last comma reads as a list
  // rather than as a time.
  return formatted.replace(/,([^,]*)$/, " às$1").trim();
}

/** The date part in the given zone, as YYYY-MM-DD for the CRM's date columns. */
export function isoDate(iso: string, timezone: string): string {
  // `en-CA` formats as YYYY-MM-DD, which is the one locale that matches the
  // column format without reassembling parts by hand.
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: timezone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date(iso));
}

export { describeCron };
