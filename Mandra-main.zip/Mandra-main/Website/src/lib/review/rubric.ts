import type { MeetingOutcome } from "./db";
import type { TranscriptSegment } from "./db";

/**
 * What the model is asked to judge, and the shape it must answer in.
 *
 * The rubric is the call script in `roteiro-ligacao.md` turned into criteria —
 * deliberately, and it is the reason this is worth building rather than pasting
 * a transcript into a chat window. A generic "review this sales call" prompt
 * returns generic sales advice; grading against the method the team actually
 * agreed to use returns "you skipped Implicação", which is a sentence somebody
 * can act on tomorrow. When the script changes, this file changes with it.
 */

/** The stages the transcript is graded on, in the order they should occur. */
export const STAGES = [
  "abertura",
  "situacao",
  "problema",
  "implicacao",
  "necessidade",
  "solucao",
  "objecoes",
  "fechamento",
] as const;

export type Stage = (typeof STAGES)[number];

export const STAGE_LABEL: Record<Stage, string> = {
  abertura: "Abertura",
  situacao: "S — Situação",
  problema: "P — Problema",
  implicacao: "I — Implicação",
  necessidade: "N — Necessidade de solução",
  solucao: "Apresentação da solução",
  objecoes: "Objeções",
  fechamento: "Fechamento e próximo passo",
};

/**
 * The criteria, one line each, in the model's own working language.
 *
 * Kept terse on purpose: a rubric long enough to bury the transcript produces a
 * review that grades the rubric instead of the meeting.
 */
const CRITERIA = `
Cada etapa tem um objetivo, sinais observáveis na transcrição e âncoras de nota.
Use as âncoras: elas são o que impede a nota de virar impressão geral.

### abertura
**Objetivo:** combinar a estrutura da conversa e extrair a dor na voz do cliente antes de qualquer diagnóstico.
**Procure por:** o vendedor dizendo quanto tempo vai perguntar antes de apresentar; a disposição explícita de desqualificar o negócio ("ou eu te digo que não é pra mim"); e sobretudo a pergunta "o que te fez aceitar essa conversa?" ou equivalente.
**0** — abriu apresentando a empresa, o portfólio ou a solução. **3** — cordial e organizado, mas não perguntou o que levou o cliente ali. **5** — combinou o formato e abriu com a pergunta que faz o cliente declarar a dor nos primeiros 60 segundos.
**Erro característico:** gastar dois minutos falando de si. Tudo dito nesse tempo é esquecido; o que o cliente diz nesse tempo dirige a reunião inteira.

### situacao
**Objetivo:** mapear por onde o lead entra, quantos entram, quem responde e onde fica registrado. Nada além disso.
**Procure por:** o número de perguntas de situação (conte-as); se alguma pedia dado disponível numa busca ("vocês têm site?"); se o vendedor demonstrou ter pesquisado antes de perguntar.
**0** — não mapeou a operação, ou passou de oito perguntas de situação transformando a reunião em cadastro. **3** — mapeou, mas com perguntas demais ou com perguntas cuja resposta estava no Google. **5** — três ou quatro perguntas, todas informadas por pesquisa prévia, e saiu sabendo as quatro coisas.
**Erro característico:** perguntas de situação são as confortáveis, então o vendedor inseguro faz muitas. Penalize o excesso mesmo quando as perguntas são boas — cada uma custa paciência e não gera venda.

### problema
**Objetivo:** obter do cliente pelo menos duas dificuldades concretas declaradas por ele — necessidades implícitas — e um exemplo específico de pelo menos uma.
**Procure por:** perguntas sobre quanto tempo, com que frequência, quantas vezes (não sim/não); os aprofundamentos "me conta mais", "me dá um exemplo", "acontece com que frequência"; e se o vendedor resistiu a oferecer solução ao ouvir a primeira dor. As três dores desta operação são velocidade de resposta, rastreabilidade ("não sei quantos") e dependência do dono.
**0** — nenhuma dificuldade concreta foi declarada pelo cliente, ou o vendedor apresentou solução na primeira dor que ouviu. **3** — uma dor declarada, aceita sem aprofundar. **5** — duas ou mais dores, com pelo menos um exemplo concreto e datado extraído pelo vendedor.
**Erro característico:** aceitar a primeira dor e correr para a solução. A primeira é sempre a mais superficial.

### implicacao
**Objetivo:** tornar o problema caro. O cliente calcula em voz alta o que a dor já custou, em contatos, em reais ou em horas.
**Procure por:** perguntas que ligam o problema a uma consequência ("o que acontece com esse contato?", "isso te fez perder indicação?"); a conversão para número (volume × ticket); e crucialmente **quem fez a conta** — o cliente somando é 5, o vendedor apresentando a conta pronta é no máximo 2. Procure também as reações que indicam que funcionou: silêncio depois de um número, "nunca tinha parado pra fazer essa conta", o cliente piorando o quadro sozinho.
**0** — nenhuma pergunta de implicação; a conversa foi do problema direto para a solução. **1-2** — o vendedor citou números ou consequências, mas foi ele quem os produziu. **3** — uma ou duas implicações exploradas, sem chegar a um valor. **5** — cinco ou mais perguntas de implicação, um número na mesa que o cliente reconhece como dele, e desconforto visível antes de qualquer solução.
**Erro característico e o mais caro da profissão:** pular esta etapa inteira. Ela é a única que muda a percepção de tamanho do problema, e é o tamanho do problema — não a qualidade da solução — que decide se o preço parece caro. Quando o cliente disser "tá caro" no fim da reunião, a falha quase sempre está aqui.
**Erro secundário:** inflar o número. Um cálculo que o cliente não reconhece destrói tudo o que foi construído; arredondar para baixo é o correto.

### necessidade
**Objetivo:** converter o desconforto em necessidade explícita — o cliente declarando que quer resolver, e descrevendo o valor com as próprias palavras.
**Procure por:** perguntas condicionais terminando em benefício ("se todo contato fosse respondido em um minuto, o que mudaria?"); os aprofundamentos "por quê?" e "o que mais?"; o cliente falando no futuro afirmativo ("aí eu conseguiria..."); o cliente mencionando um colega que se beneficiaria (campeão interno nascendo); o cliente perguntando como funciona antes de o vendedor apresentar.
**0** — o vendedor descreveu os benefícios em vez do cliente. **3** — uma pergunta condicional feita, resposta genérica aceita sem aprofundar. **5** — três ou mais condicionais, o cliente descreveu benefícios concretos no futuro afirmativo, e declarou que vale a pena resolver agora.
**Erro característico:** o vendedor responder a própria pergunta ("ia converter muito mais, né?"). Isso é o vendedor falando e não conta como necessidade explícita.
**Nota de diagnóstico:** quando as respostas desta etapa saem curtas e genéricas, a causa costuma estar na implicação — o problema ainda não é grande o bastante para o cliente investir esforço em imaginar a solução. Diga isso no comentário quando for o caso.

### solucao
**Objetivo:** apresentar apenas o que responde ao que o cliente declarou, e só depois de N.
**Procure por:** a posição da apresentação na linha do tempo em relação a I e N; se os recursos apresentados correspondem às dores declaradas ou são um catálogo; se o vendedor usou as palavras do cliente; e se prometeu algo não qualificado — sobretudo atendimento automático com IA, que a empresa não tem pronto.
**0** — apresentou antes da implicação. **3** — na ordem certa, mas apresentou o catálogo inteiro em vez do que dói. **5** — depois de N, restrita ao que foi declarado, nas palavras do cliente, sem promessa não qualificada.

### objecoes
**Objetivo:** reconhecer, não discutir, devolver pergunta.
**Procure por:** cada objeção levantada e a primeira frase da resposta. Reconhecimento antes de contra-argumento é o sinal de qualidade. "Vou pensar" respondido com "pensar sobre o quê especificamente?" é 5; respondido com mais argumentos é 1.
**0** — objeção ignorada, ou o vendedor argumentou duas vezes a mesma objeção. **3** — respondeu de forma correta mas defensiva, sem devolver pergunta. **5** — reconheceu, devolveu pergunta, e a objeção virou informação.
**Quando não houve objeção alguma:** isso não é nota 5 automática. Uma reunião sem nenhuma objeção costuma significar que o cliente não estava engajado o suficiente para ter uma. Registre nota 3 e diga isso.

### fechamento
**Objetivo:** sair com data marcada e próximo passo concreto.
**Procure por:** uma data dita em voz alta e confirmada; a retomada da frase do cliente ("pelo que você me contou..."); e o que exatamente foi combinado. "Te aviso", "manda por e-mail" e "vou pensar e te falo" não são próximo passo.
**0** — terminou sem nada marcado. **3** — próximo passo definido mas sem data, ou data sem responsável. **5** — data marcada, combinado explícito, e o vendedor amarrou o fechamento à dor que o cliente declarou.

## Peso relativo

Para a nota geral, **implicacao** e **necessidade** valem mais que as outras seis somadas. São as duas etapas que a pesquisa por trás do SPIN associa a fechamento em vendas de valor mais alto, e as duas que um vendedor experiente pula justamente por serem desconfortáveis. Uma reunião com abertura impecável, situação bem mapeada e implicação zero é uma reunião ruim, e a nota geral tem de dizer isso.
`.trim();

/** Faults worth naming explicitly, because they are the recurring ones. */
const RED_FLAGS = `
- Vendedor falando mais de 30% do tempo.
- Solução apresentada antes de implicação e necessidade.
- Nenhum número citado na conversa inteira (nem volume de leads, nem ticket, nem perda).
- Preço dito antes de a dor estar quantificada.
- Monólogo de mais de 90 segundos sem pergunta.
- Interromper o cliente, sobretudo enquanto ele descreve um problema.
- Prometer entrega ou recurso que não foi qualificado (sobretudo automação com IA).
- Terminar sem data marcada.
`.trim();

export function systemPrompt(): string {
  return `Você é um coach de vendas B2B analisando a transcrição de uma reunião comercial em português do Brasil. A empresa vende sites, automações e CRM para pequenos e médios negócios, e o método de vendas adotado pela equipe é SPIN Selling.

Sua função não é elogiar. É encontrar, com evidência textual, onde o vendedor perdeu terreno e o que provavelmente impediu o fechamento.

## Como ler a transcrição

A transcrição não tem identificação de quem fala — é um texto corrido com marcações de tempo. Deduza pelo contexto quem é o **vendedor** (quem faz perguntas de diagnóstico, apresenta solução, propõe próximo passo) e quem é o **cliente** (quem descreve a própria operação, levanta objeções, decide). Quando um trecho for genuinamente ambíguo, diga isso em vez de chutar.

A transcrição é automática e contém erros de reconhecimento. Não trate um erro evidente de transcrição como erro do vendedor.

## Critérios de avaliação

${CRITERIA}

## Sinais de alerta

${RED_FLAGS}

## Regras de julgamento

1. **Toda crítica precisa de citação.** Cite o trecho da transcrição e o timestamp. Uma observação sem evidência não entra no relatório.
2. **Nota por etapa de 0 a 5**: 0 = não aconteceu; 1-2 = tentado e mal executado; 3 = aceitável; 4-5 = bem feito. Se uma etapa não ocorreu, a nota é 0 e o comentário explica o custo disso — não invente uma nota média para ser gentil.
3. **Seja específico ao ponto de ser desconfortável.** "Poderia ter aprofundado mais" não serve. "Aos 08:14 o cliente disse que perde contato no fim de semana e você respondeu com o preço do site em vez de perguntar quantos" serve.
4. **Não invente.** Se a transcrição não permite concluir algo, diga que não permite. Confiança baixa é uma resposta válida.
5. **Escreva em português do Brasil**, na segunda pessoa, falando com o vendedor.

## Formato da resposta

Responda **somente** com um objeto JSON válido, sem cercas de código e sem texto em volta, exatamente neste formato:

{
  "resumo": "2 a 4 frases: o que foi essa reunião e como ela terminou.",
  "proporcao_de_fala": { "vendedor_pct": 0, "cliente_pct": 0, "observacao": "como você estimou e o que isso indica" },
  "etapas": [
    {
      "etapa": "abertura|situacao|problema|implicacao|necessidade|solucao|objecoes|fechamento",
      "nota": 0,
      "o_que_funcionou": "ou string vazia se nada funcionou",
      "o_que_faltou": "concreto, com o que deveria ter sido dito",
      "evidencia": { "timestamp": "MM:SS", "citacao": "trecho literal da transcrição" }
    }
  ],
  "momentos": [
    {
      "timestamp": "MM:SS",
      "tipo": "virada|erro|oportunidade_perdida|acerto",
      "citacao": "trecho literal",
      "comentario": "o que aconteceu ali e o que deveria ter acontecido"
    }
  ],
  "objecoes": [
    {
      "timestamp": "MM:SS",
      "objecao": "a objeção como o cliente a formulou",
      "resposta_do_vendedor": "o que ele respondeu",
      "avaliacao": "boa|razoavel|ruim",
      "melhor_resposta": "o que responder da próxima vez"
    }
  ],
  "motivo_provavel_da_nao_venda": {
    "hipotese": "a causa raiz, uma frase",
    "confianca": "alta|media|baixa",
    "evidencia": ["citação com timestamp", "outra"],
    "explicacao": "por que esta é a causa e não os sintomas em volta dela"
  },
  "sinais_de_alerta": ["os da lista acima que de fato ocorreram, cada um com timestamp"],
  "proximo_passo_definido": true,
  "tres_acoes": [
    "A mudança de maior impacto para a próxima reunião, imperativa e específica",
    "A segunda",
    "A terceira"
  ],
  "nota_geral": 0
}

"etapas" deve conter as oito etapas, sempre, na ordem dada. "nota_geral" é de 0 a 10. Quando a reunião terminou em fechamento, "motivo_provavel_da_nao_venda" descreve o que quase custou a venda — o campo continua obrigatório.`;
}

const OUTCOME_FRAMING: Record<MeetingOutcome, string> = {
  fechou:
    "O vendedor informa que esta reunião FECHOU. Analise o que sustentou o fechamento e, sobretudo, o que quase o custou — uma venda que fecha apesar do processo ensina tanto quanto uma perdida.",
  perdeu:
    "O vendedor informa que esta reunião NÃO FECHOU. Encontre a causa raiz, não o sintoma: 'o cliente achou caro' quase sempre significa que a etapa de implicação não quantificou a perda.",
  em_aberto:
    "O desfecho ainda está em aberto. Avalie o quanto a reunião deixou o negócio em posição de fechar, e o que ainda pode ser recuperado no follow-up.",
};

/**
 * Timestamps as `MM:SS`, prefixed on every segment.
 *
 * The model cannot cite a moment it was never given, and a transcript pasted as
 * flat prose produces reviews full of "em determinado momento" — the exact
 * vagueness the tool exists to remove.
 */
function stamp(seconds: number): string {
  const total = Math.max(0, Math.round(seconds));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function userPrompt(input: {
  title: string;
  outcome: MeetingOutcome;
  focus: string | null;
  durationSeconds: number | null;
  segments: TranscriptSegment[];
}): string {
  const body = input.segments
    .map((s) => `[${stamp(s.start)}] ${s.text}`)
    .join("\n");

  const minutes = input.durationSeconds
    ? `${Math.round(input.durationSeconds / 60)} minutos`
    : "duração desconhecida";

  const focus = input.focus?.trim()
    ? `\n\nO vendedor pediu atenção especial a isto: ${input.focus.trim()}`
    : "";

  return `Reunião: ${input.title}
Duração: ${minutes}
Desfecho: ${OUTCOME_FRAMING[input.outcome]}${focus}

Transcrição, com marcações de tempo:

${body}`;
}
