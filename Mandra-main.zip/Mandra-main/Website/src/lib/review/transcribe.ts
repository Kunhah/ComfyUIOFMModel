import { spawn } from "node:child_process";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import type { TranscriptSegment } from "./db";

/**
 * Audio in, timestamped Portuguese out — locally, with two binaries.
 *
 * Local rather than an API because of what the file is. A meeting recording is
 * the customer's voice discussing their own numbers, uploaded by a seller who
 * did not negotiate a data-processing agreement with anybody; shipping it to a
 * third party is a decision that should be taken deliberately and out loud, not
 * inherited from whichever transcription service was easiest to wire up. It is
 * also free per meeting, which matters for a tool meant to run on every call
 * rather than on the interesting ones.
 *
 * The cost is that both binaries have to exist on the host. Neither is a Node
 * dependency and neither can be installed by `npm install`, so `available()`
 * reports what is missing and the UI says so — a silent failure here looks
 * exactly like a broken upload.
 */

/** Where whisper.cpp's CLI lives. `whisper-cli` is what its install target names it. */
function whisperBin(): string {
  return process.env.WHISPER_BIN?.trim() || "whisper-cli";
}

function ffmpegBin(): string {
  return process.env.FFMPEG_BIN?.trim() || "ffmpeg";
}

/**
 * The model file. Large-v3-turbo is the recommendation for this job: it is the
 * smallest model whose Portuguese is good enough that the analysis is arguing
 * with what was said rather than with a mis-transcription, and a review built on
 * a bad transcript is confidently wrong, which is the worst thing this tool
 * could be.
 */
function whisperModel(): string {
  return (
    process.env.WHISPER_MODEL?.trim() ||
    path.join(process.cwd(), "data", "whisper", "ggml-large-v3-turbo.bin")
  );
}

export class TranscriptionError extends Error {}

/** How long one transcription may take before it is treated as hung. */
const TIMEOUT_MS = 60 * 60_000;

/**
 * Runs a binary to completion, capturing stderr for the error message.
 *
 * Not `exec`: whisper writes progress to stderr continuously and a 40-minute
 * recording overflows the default buffer, which fails the run at the point it
 * was about to succeed.
 */
function run(
  bin: string,
  args: string[],
  label: string,
): Promise<{ stdout: string; stderr: string }> {
  return new Promise((resolve, reject) => {
    let child: ReturnType<typeof spawn>;
    try {
      child = spawn(bin, args, { stdio: ["ignore", "pipe", "pipe"] });
    } catch (error) {
      reject(
        new TranscriptionError(
          `Não foi possível executar ${bin}: ${
            error instanceof Error ? error.message : String(error)
          }`,
        ),
      );
      return;
    }

    let stdout = "";
    let stderr = "";
    // Bounded: only the tail is ever shown in an error, and an hour of progress
    // lines is megabytes of memory held for nothing.
    const keepTail = (buffer: string, chunk: string) =>
      (buffer + chunk).slice(-16_000);

    child.stdout?.on("data", (c) => (stdout = keepTail(stdout, String(c))));
    child.stderr?.on("data", (c) => (stderr = keepTail(stderr, String(c))));

    const timer = setTimeout(() => {
      child.kill("SIGKILL");
      reject(
        new TranscriptionError(
          `${label} passou de ${Math.round(TIMEOUT_MS / 60_000)} minutos e foi interrompido.`,
        ),
      );
    }, TIMEOUT_MS);

    child.on("error", (error) => {
      clearTimeout(timer);
      reject(
        new TranscriptionError(
          error.message.includes("ENOENT")
            ? `${bin} não está instalado ou não está no PATH.`
            : `${label}: ${error.message}`,
        ),
      );
    });

    child.on("close", (code) => {
      clearTimeout(timer);
      if (code === 0) resolve({ stdout, stderr });
      else
        reject(
          new TranscriptionError(
            `${label} terminou com código ${code}. ${stderr.trim().slice(-800)}`,
          ),
        );
    });
  });
}

/** Whether a binary answers at all. Used for the setup check, never in the hot path. */
async function present(bin: string, args: string[]): Promise<boolean> {
  try {
    await run(bin, args, bin);
    return true;
  } catch {
    return false;
  }
}

export type Readiness = {
  ready: boolean;
  ffmpeg: boolean;
  whisper: boolean;
  model: boolean;
  modelPath: string;
};

/**
 * What is missing, reported as three separate booleans rather than one.
 *
 * "A transcrição não está configurada" sends someone to read source. Knowing it
 * is the model file and not the binary is the difference between a one-line
 * download and an afternoon.
 */
export async function readiness(): Promise<Readiness> {
  const modelPath = whisperModel();
  const [ffmpeg, whisper, model] = await Promise.all([
    present(ffmpegBin(), ["-version"]),
    present(whisperBin(), ["--help"]),
    readFile(modelPath)
      .then(() => true)
      .catch(() => false),
  ]);
  return {
    ready: ffmpeg && whisper && model,
    ffmpeg,
    whisper,
    model,
    modelPath,
  };
}

/**
 * whisper.cpp reads 16 kHz mono PCM and nothing else — it does not link
 * ffmpeg, so an m4a straight off a phone is rejected rather than converted.
 * This is that conversion, and it is also why ffmpeg is a hard requirement.
 */
async function toWav(source: string, target: string): Promise<void> {
  await run(
    ffmpegBin(),
    [
      "-nostdin",
      "-y",
      "-i",
      source,
      "-ar",
      "16000",
      "-ac",
      "1",
      "-c:a",
      "pcm_s16le",
      target,
    ],
    "A conversão do áudio",
  );
}

type WhisperJson = {
  transcription?: {
    offsets?: { from?: number; to?: number };
    text?: string;
  }[];
};

export type Transcription = {
  text: string;
  segments: TranscriptSegment[];
  durationSeconds: number;
};

/**
 * Transcribe one recording.
 *
 * The output is read from whisper's JSON rather than its stdout because the
 * timestamps are the point: a review that says "you interrupted the client" is
 * an opinion, and one that says "at 14:02 you interrupted the client" is
 * something the seller can go and listen to. Everything downstream — the cited
 * moments, the jump-to-time links — hangs off these offsets.
 *
 * There is no speaker separation. whisper.cpp's diarisation needs a stereo
 * recording with the parties on separate channels, which a phone or a Meet
 * export is not, so the transcript is one voice and the analysis is told to work
 * out who is speaking from context. It gets it right most of the time and not
 * always, which is a limit worth knowing rather than papering over.
 */
export async function transcribe(audioPath: string): Promise<Transcription> {
  const state = await readiness();
  if (!state.ffmpeg) {
    throw new TranscriptionError(
      "ffmpeg não está instalado no servidor. Sem ele o áudio não pode ser convertido.",
    );
  }
  if (!state.whisper) {
    throw new TranscriptionError(
      "whisper-cli não está instalado. Rode `npm run review:setup` no servidor.",
    );
  }
  if (!state.model) {
    throw new TranscriptionError(
      `O modelo de transcrição não está em ${state.modelPath}. Rode \`npm run review:setup\`.`,
    );
  }

  const work = await mkdtemp(path.join(tmpdir(), "mandra-review-"));
  try {
    const wav = path.join(work, "audio.wav");
    await toWav(audioPath, wav);

    const outPrefix = path.join(work, "out");
    await run(
      whisperBin(),
      [
        "-m",
        whisperModel(),
        "-f",
        wav,
        // Portuguese, stated rather than detected. Auto-detection on a call that
        // opens with "alô" has picked Spanish before, and every downstream word
        // is then wrong in a way that reads as a bad transcription model.
        "-l",
        process.env.WHISPER_LANGUAGE?.trim() || "pt",
        "-oj",
        "-of",
        outPrefix,
        "-np",
      ],
      "A transcrição",
    );

    const raw = await readFile(`${outPrefix}.json`, "utf8");
    const parsed = JSON.parse(raw) as WhisperJson;

    const segments: TranscriptSegment[] = (parsed.transcription ?? [])
      .map((s) => ({
        start: Number(s.offsets?.from ?? 0) / 1000,
        end: Number(s.offsets?.to ?? 0) / 1000,
        text: String(s.text ?? "").trim(),
      }))
      .filter((s) => s.text.length > 0);

    if (segments.length === 0) {
      throw new TranscriptionError(
        "A transcrição saiu vazia. O arquivo tem áudio audível?",
      );
    }

    return {
      text: segments.map((s) => s.text).join(" "),
      segments,
      durationSeconds: segments[segments.length - 1].end,
    };
  } finally {
    // The wav is several times the size of the upload it came from. Leaving it
    // in tmp fills a disk over a few dozen meetings, on a host where nothing
    // else writes enough to make that obvious.
    await rm(work, { recursive: true, force: true });
  }
}
