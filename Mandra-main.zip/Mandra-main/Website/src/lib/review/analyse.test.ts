import test from "node:test";
import assert from "node:assert/strict";

import { AnalysisError, validate } from "@/lib/review/analyse";
import { STAGES } from "@/lib/review/rubric";

/**
 * The model's answer is the one input to this feature nobody controls. These
 * pin the two properties the page depends on: every stage is always present, and
 * a shape the renderer cannot use is rejected rather than half-rendered.
 */

const minimal = {
  resumo: "Reunião com a clínica. Não fechou.",
  etapas: [{ etapa: "implicacao", nota: 2, o_que_faltou: "não quantificou" }],
};

test("materialises every stage even when the model omitted most of them", () => {
  const result = validate(minimal);

  assert.deepEqual(
    result.etapas.map((e) => e.etapa),
    [...STAGES],
  );
  // The one the model did answer keeps its content...
  const implicacao = result.etapas.find((e) => e.etapa === "implicacao");
  assert.equal(implicacao?.nota, 2);
  assert.equal(implicacao?.o_que_faltou, "não quantificou");
  // ...and the rest read as unassessed rather than as a clean zero-score report.
  const abertura = result.etapas.find((e) => e.etapa === "abertura");
  assert.equal(abertura?.nota, 0);
  assert.match(abertura?.o_que_faltou ?? "", /não avaliada/i);
});

test("clamps scores a model invented outside the scale", () => {
  const result = validate({
    ...minimal,
    etapas: [{ etapa: "abertura", nota: 9 }],
    nota_geral: 47,
  });

  assert.equal(result.etapas[0].nota, 5);
  assert.equal(result.nota_geral, 10);
});

test("rejects an answer with no resumo, rather than rendering an empty report", () => {
  assert.throws(() => validate({ etapas: [] }), AnalysisError);
  assert.throws(() => validate(null), AnalysisError);
  assert.throws(() => validate("pronto!"), AnalysisError);
});

test("drops entries too incomplete to render and keeps the rest", () => {
  const result = validate({
    ...minimal,
    momentos: [
      {
        timestamp: "04:10",
        tipo: "erro",
        citacao: "e o preço?",
        comentario: "respondeu cedo",
      },
      { timestamp: "09:00", tipo: "erro", citacao: "..." },
    ],
    objecoes: [
      { objecao: "tá caro", avaliacao: "ruim" },
      { resposta_do_vendedor: "sem objeção nenhuma aqui" },
    ],
  });

  assert.equal(result.momentos.length, 1);
  assert.equal(result.objecoes.length, 1);
  assert.equal(result.objecoes[0].objecao, "tá caro");
});

test("an unknown enum value falls back instead of reaching the renderer", () => {
  const result = validate({
    ...minimal,
    momentos: [
      { timestamp: "01:00", tipo: "catastrofe", citacao: "x", comentario: "y" },
    ],
    objecoes: [{ objecao: "cara", avaliacao: "excelente" }],
    motivo_provavel_da_nao_venda: {
      hipotese: "faltou implicação",
      confianca: "altíssima",
    },
  });

  assert.equal(result.momentos[0].tipo, "erro");
  assert.equal(result.objecoes[0].avaliacao, "razoavel");
  assert.equal(result.motivo_provavel_da_nao_venda.confianca, "baixa");
});

test("keeps at most three actions, and only real ones", () => {
  const result = validate({
    ...minimal,
    tres_acoes: ["uma", "", "duas", "três", "quatro"],
  });

  assert.deepEqual(result.tres_acoes, ["uma", "duas", "três"]);
});
