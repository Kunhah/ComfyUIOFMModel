import { extractJson } from "@/lib/ai/envelope";
import { LlmError } from "@/lib/ai/providers";
import { runCompletion } from "@/lib/ai/run";
import type { MeetingOutcome, TranscriptSegment } from "./db";
import { STAGES, systemPrompt, userPrompt, type Stage } from "./rubric";

/**
 * The transcript goes in, the review comes out.
 *
 * Everything hard here is about not trusting the output shape. The prompt asks
 * for bare JSON and says so twice, and a model still fences it, prefaces it, or
 * drops a field — so the parser is tolerant and the validator is not. A review
 * rendered from a half-parsed object is a page of "undefined" next to a real
 * critique, which destroys confidence in the parts that were right.
 */

export type StageScore = {
  etapa: Stage;
  nota: number;
  o_que_funcionou: string;
  o_que_faltou: string;
  evidencia: { timestamp: string; citacao: string } | null;
};

export type Moment = {
  timestamp: string;
  tipo: "virada" | "erro" | "oportunidade_perdida" | "acerto";
  citacao: string;
  comentario: string;
};

export type Objection = {
  timestamp: string;
  objecao: string;
  resposta_do_vendedor: string;
  avaliacao: "boa" | "razoavel" | "ruim";
  melhor_resposta: string;
};

export type Analysis = {
  resumo: string;
  proporcao_de_fala: {
    vendedor_pct: number;
    cliente_pct: number;
    observacao: string;
  };
  etapas: StageScore[];
  momentos: Moment[];
  objecoes: Objection[];
  motivo_provavel_da_nao_venda: {
    hipotese: string;
    confianca: "alta" | "media" | "baixa";
    evidencia: string[];
    explicacao: string;
  };
  sinais_de_alerta: string[];
  proximo_passo_definido: boolean;
  tres_acoes: string[];
  nota_geral: number;
};

export class AnalysisError extends Error {}

const str = (v: unknown, fallback = ""): string =>
  typeof v === "string" ? v.trim() : fallback;

const num = (v: unknown, fallback = 0): number => {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : fallback;
};

const clamp = (n: number, lo: number, hi: number): number =>
  Math.min(hi, Math.max(lo, n));

const list = (v: unknown): unknown[] => (Array.isArray(v) ? v : []);

const oneOf = <T extends string>(
  v: unknown,
  allowed: readonly T[],
  fallback: T,
): T => (allowed.includes(v as T) ? (v as T) : fallback);

/**
 * Coerce the parsed object into `Analysis`, filling what is missing.
 *
 * Every stage is materialised even when the model omitted one, because the UI
 * renders eight rows and a missing stage should read as "não avaliada" rather
 * than as a shorter, tidier report that quietly lost a criterion.
 */
export function validate(parsed: unknown): Analysis {
  if (!parsed || typeof parsed !== "object") {
    throw new AnalysisError("A resposta do modelo não era um objeto.");
  }
  const o = parsed as Record<string, unknown>;

  const byStage = new Map<string, Record<string, unknown>>();
  for (const entry of list(o.etapas)) {
    if (entry && typeof entry === "object") {
      const e = entry as Record<string, unknown>;
      byStage.set(str(e.etapa), e);
    }
  }

  const etapas: StageScore[] = STAGES.map((etapa) => {
    const e = byStage.get(etapa) ?? {};
    const ev = (e.evidencia ?? null) as Record<string, unknown> | null;
    return {
      etapa,
      nota: clamp(num(e.nota), 0, 5),
      o_que_funcionou: str(e.o_que_funcionou),
      o_que_faltou: str(e.o_que_faltou, "Não avaliada pelo modelo."),
      evidencia:
        ev && typeof ev === "object" && str(ev.citacao)
          ? { timestamp: str(ev.timestamp), citacao: str(ev.citacao) }
          : null,
    };
  });

  const fala = (o.proporcao_de_fala ?? {}) as Record<string, unknown>;
  const motivo = (o.motivo_provavel_da_nao_venda ?? {}) as Record<
    string,
    unknown
  >;

  const resumo = str(o.resumo);
  if (!resumo) {
    // The one field whose absence means the model did not do the task at all.
    throw new AnalysisError(
      "A análise voltou sem resumo — resposta inutilizável.",
    );
  }

  return {
    resumo,
    proporcao_de_fala: {
      vendedor_pct: clamp(num(fala.vendedor_pct), 0, 100),
      cliente_pct: clamp(num(fala.cliente_pct), 0, 100),
      observacao: str(fala.observacao),
    },
    etapas,
    momentos: list(o.momentos)
      .filter((m): m is Record<string, unknown> => !!m && typeof m === "object")
      .map((m) => ({
        timestamp: str(m.timestamp),
        tipo: oneOf(
          m.tipo,
          ["virada", "erro", "oportunidade_perdida", "acerto"] as const,
          "erro",
        ),
        citacao: str(m.citacao),
        comentario: str(m.comentario),
      }))
      .filter((m) => m.comentario),
    objecoes: list(o.objecoes)
      .filter((x): x is Record<string, unknown> => !!x && typeof x === "object")
      .map((x) => ({
        timestamp: str(x.timestamp),
        objecao: str(x.objecao),
        resposta_do_vendedor: str(x.resposta_do_vendedor),
        avaliacao: oneOf(
          x.avaliacao,
          ["boa", "razoavel", "ruim"] as const,
          "razoavel",
        ),
        melhor_resposta: str(x.melhor_resposta),
      }))
      .filter((x) => x.objecao),
    motivo_provavel_da_nao_venda: {
      hipotese: str(motivo.hipotese, "O modelo não isolou uma causa."),
      confianca: oneOf(
        motivo.confianca,
        ["alta", "media", "baixa"] as const,
        "baixa",
      ),
      evidencia: list(motivo.evidencia)
        .map((e) => str(e))
        .filter(Boolean),
      explicacao: str(motivo.explicacao),
    },
    sinais_de_alerta: list(o.sinais_de_alerta)
      .map((s) => str(s))
      .filter(Boolean),
    proximo_passo_definido: o.proximo_passo_definido === true,
    tres_acoes: list(o.tres_acoes)
      .map((a) => str(a))
      .filter(Boolean)
      .slice(0, 3),
    nota_geral: clamp(num(o.nota_geral), 0, 10),
  };
}

export async function analyse(input: {
  title: string;
  outcome: MeetingOutcome;
  focus: string | null;
  durationSeconds: number | null;
  segments: TranscriptSegment[];
  /** The meeting this is about, for the run log. Optional so the analyser stays
   * callable from a fixture that has no row behind it. */
  reviewId?: string;
}): Promise<{ analysis: Analysis; provider: string }> {
  let text: string;
  let provider: string;

  try {
    // The "caro" chain puts Claude first. The chat models underneath are a real
    // fallback and a worse review — `analysis_model` on the row records which one
    // answered, so a thin report can be explained rather than doubted, and the
    // same fact now lands in `ai_runs` next to what it cost.
    //
    // Not a `Skill`: `validate()` below fills defaults rather than rejecting,
    // because a thin review is still worth reading, and `runSkill()` exists to
    // refuse exactly that. See the note on `runCompletion()` in lib/ai/run.ts.
    const result = await runCompletion({
      skill: "reuniao.analise",
      // Our own meetings, on our own pipeline: NULL is the honest account.
      accountId: null,
      subject: input.reviewId ? `reuniao:${input.reviewId}` : null,
      messages: [
        { role: "system", content: systemPrompt() },
        { role: "user", content: userPrompt(input) },
      ],
      chain: "caro",
      json: true,
      temperature: 0.2,
      maxTokens: 16000,
    });
    text = result.text;
    provider = result.provider;
  } catch (error) {
    if (error instanceof LlmError) throw new AnalysisError(error.message);
    throw error;
  }

  // The WhatsApp agent's extractor, not a second one: both read a completion
  // that was asked for bare JSON and mostly given it, and two implementations of
  // "dig the object out of the fences" is two sets of edge cases to discover.
  const parsed = extractJson(text);
  if (!parsed) {
    throw new AnalysisError(
      "O modelo respondeu algo que não é um objeto JSON válido.",
    );
  }

  return { analysis: validate(parsed), provider };
}
