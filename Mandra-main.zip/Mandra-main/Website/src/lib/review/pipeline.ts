import { rm } from "node:fs/promises";
import path from "node:path";
import { analyse, AnalysisError } from "./analyse";
import {
  reviewById,
  unfinishedReviews,
  updateReview,
  type ReviewRow,
} from "./db";
import { transcribe, TranscriptionError } from "./transcribe";

/**
 * The slow half, run off the request.
 *
 * Transcribing forty minutes takes minutes and analysing it takes more, so the
 * upload route answers as soon as the file is on disk and this runs after. The
 * status column is the only channel between the two — an in-memory promise would
 * be invisible to the page polling for it, and to the second container if there
 * ever is one.
 *
 * A `Set` of ids, not a queue, is what prevents double work: the resume-on-boot
 * scan and a retry from the UI can both point at the same row, and running the
 * same recording twice would bill twice and write the second answer over the
 * first while somebody is reading it.
 */

const running = new Set<string>();

/** Where uploads live. Gitignored, and on the Docker volume in production. */
export function audioDir(): string {
  return (
    process.env.REVIEW_AUDIO_DIR?.trim() ||
    path.join(process.cwd(), "data", "reunioes")
  );
}

/**
 * Whether to keep the recording after it has been transcribed.
 *
 * Deleting is the default because of what accumulates otherwise: a folder of
 * customer conversations, on a VPS, with no retention policy and no consent
 * beyond the one the seller asked for verbally. The transcript is what every
 * later feature needs — re-running the analysis with a better rubric reads the
 * transcript, not the audio — so keeping the audio buys re-transcription and
 * nothing else. Set REVIEW_KEEP_AUDIO=1 when that trade is worth it.
 */
function keepAudio(): boolean {
  return process.env.REVIEW_KEEP_AUDIO?.trim() === "1";
}

export function isRunning(id: string): boolean {
  return running.has(id);
}

/**
 * Run one recording through transcription and analysis.
 *
 * Never throws: it is called with `void` from a route handler, and an unhandled
 * rejection there takes down the process in Node. Every failure is written to
 * the row instead, which is also the only place the operator can see it.
 */
export async function runReview(id: string): Promise<void> {
  if (running.has(id)) return;
  running.add(id);

  try {
    const row = reviewById(id);
    if (!row) return;

    let segments = row.segments;
    let transcript = row.transcript;
    let duration = row.durationSeconds;

    // Skipped when a retry only needs the analysis redone — the expensive half
    // is already on the row, and re-transcribing to change a prompt is minutes
    // of CPU spent reproducing a file that has not changed.
    if (segments.length === 0) {
      if (!row.audioPath) {
        fail(
          id,
          "O áudio não está mais no servidor e não há transcrição para reanalisar.",
        );
        return;
      }
      updateReview(id, { status: "transcrevendo", error: null });
      const result = await transcribe(row.audioPath);
      segments = result.segments;
      transcript = result.text;
      duration = result.durationSeconds;
      updateReview(id, {
        transcript,
        segments,
        durationSeconds: duration,
      });
    }

    updateReview(id, { status: "analisando", error: null });
    const { analysis, provider } = await analyse({
      title: row.title,
      outcome: row.outcome,
      focus: row.focus,
      durationSeconds: duration,
      segments,
      reviewId: id,
    });

    updateReview(id, {
      status: "pronto",
      analysis,
      analysisModel: provider,
      error: null,
    });

    if (!keepAudio() && row.audioPath) {
      await rm(row.audioPath, { force: true }).catch(() => {});
      updateReview(id, { audioPath: null });
    }
  } catch (error) {
    fail(
      id,
      error instanceof TranscriptionError || error instanceof AnalysisError
        ? error.message
        : `Falha inesperada: ${error instanceof Error ? error.message : String(error)}`,
    );
  } finally {
    running.delete(id);
  }
}

function fail(id: string, message: string): void {
  updateReview(id, { status: "erro", error: message });
  console.warn(
    JSON.stringify({
      service: "review",
      event: "pipeline.failed",
      id,
      message,
    }),
  );
}

/** Queue a row without waiting for it. The one entry point routes should use. */
export function enqueue(row: ReviewRow): void {
  void runReview(row.id);
}

/**
 * Pick up rows that were mid-pipeline when the process stopped.
 *
 * Called from instrumentation, and serialised rather than fanned out: each item
 * pins a CPU for minutes, and starting six of them on boot makes the site
 * unresponsive at exactly the moment somebody is checking whether the deploy
 * worked.
 */
export async function resumePending(): Promise<number> {
  const pending = unfinishedReviews();
  if (pending.length === 0) return 0;

  void (async () => {
    for (const row of pending) {
      await runReview(row.id);
    }
  })();

  return pending.length;
}
