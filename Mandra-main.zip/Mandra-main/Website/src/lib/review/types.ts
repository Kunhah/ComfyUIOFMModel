/**
 * The parts of a review that the browser is allowed to know about.
 *
 * Split out of `db.ts` because that module imports `node:sqlite`, and a client
 * component importing one label from it drags the whole database layer into the
 * browser bundle — which fails the build rather than shipping, so the split is
 * load-bearing and not tidiness. Same shape as the prospector's `types.ts`.
 */

/**
 * Where a recording is in the pipeline.
 *
 * Stored rather than derived because the two slow steps are minutes long and
 * run in a background task: without a column, a page load during transcription
 * is indistinguishable from a crash, and the honest answer to "is it stuck" is
 * the one thing the operator wants.
 */
export type ReviewStatus =
  "fila" | "transcrevendo" | "analisando" | "pronto" | "erro";

export const REVIEW_STATUS_LABEL: Record<ReviewStatus, string> = {
  fila: "Na fila",
  transcrevendo: "Transcrevendo",
  analisando: "Analisando",
  pronto: "Pronto",
  erro: "Falhou",
};

/** The three states that are still working, shared by both screens' polling. */
export const PENDING_STATUS: ReviewStatus[] = [
  "fila",
  "transcrevendo",
  "analisando",
];

export function isReviewStatus(value: unknown): value is ReviewStatus {
  return (
    value === "fila" ||
    value === "transcrevendo" ||
    value === "analisando" ||
    value === "pronto" ||
    value === "erro"
  );
}

/** How the meeting ended, as the seller reports it. */
export type MeetingOutcome = "fechou" | "perdeu" | "em_aberto";

export const OUTCOME_LABEL: Record<MeetingOutcome, string> = {
  fechou: "Fechou",
  perdeu: "Não fechou",
  em_aberto: "Em aberto",
};

export function isMeetingOutcome(value: unknown): value is MeetingOutcome {
  return value === "fechou" || value === "perdeu" || value === "em_aberto";
}

export type TranscriptSegment = {
  /** Seconds from the start of the recording. */
  start: number;
  end: number;
  text: string;
};
