import { randomUUID } from "node:crypto";
import type { DatabaseSync } from "node:sqlite";
import { getDb } from "@/lib/prospector/db";
import {
  isMeetingOutcome,
  isReviewStatus,
  type MeetingOutcome,
  type ReviewStatus,
  type TranscriptSegment,
} from "./types";

/**
 * Recorded meetings, their transcripts and what the model made of them.
 *
 * In `data/prospector.db` with everything else, and for the same reason the
 * WhatsApp tables are: a review is *about* a deal. The question the tool exists
 * to answer — "why did this one not close" — is only answerable next to the
 * lead's funnel stage and its call history, and a second file would put a join
 * nobody can write between the two halves of one answer.
 *
 * The schema lives here rather than in prospector/db.ts so the two read apart,
 * and is applied lazily by `reviewDb()`. `getDb()` has run its own DDL and
 * migrations by then, which is what lets `leads` be referenced by foreign key
 * from here and not the other way round.
 */

// The browser-safe half — statuses, outcomes, their labels and the segment
// shape — lives in ./types so a client component can import a label without
// dragging node:sqlite into the bundle. Re-exported here because every server
// caller wants both halves from one place.
export * from "./types";

const SCHEMA = `
  -- One row per recording. The audio file itself is not in here: SQLite would
  -- hold it fine and then every backup of the lead base would be gigabytes of
  -- other people's voices. The path is a pointer that is allowed to dangle,
  -- because the audio is deleted after a successful transcription by default.
  CREATE TABLE IF NOT EXISTS meeting_reviews (
    id             TEXT PRIMARY KEY,
    -- ON DELETE SET NULL, not CASCADE. Deleting a lead from the CRM must not
    -- destroy the record of a conversation that actually happened, and the
    -- review is still worth reading as training material without it.
    lead_id        TEXT REFERENCES leads (id) ON DELETE SET NULL,
    -- Free text, because most recordings are uploaded before anyone decides
    -- which row in the CRM they belong to — and requiring the link first is how
    -- you get a tool nobody uploads to.
    title          TEXT NOT NULL,
    -- Who uploaded it, captured by value like everywhere else in this database:
    -- accounts get deleted and a review whose owner became NULL is unreadable.
    actor_id       TEXT NOT NULL,
    actor_name     TEXT NOT NULL,
    status         TEXT NOT NULL DEFAULT 'fila',
    -- Set by the seller at upload, never inferred. The model is told the outcome
    -- because "find what went wrong" and "find what went right" are different
    -- readings of the same transcript, and guessing which one to do from the
    -- words alone is exactly the guess it is worst at.
    outcome        TEXT NOT NULL DEFAULT 'em_aberto',
    -- What the seller wants looked at. Optional, and the whole reason the tool
    -- is not just a fixed rubric.
    focus          TEXT,
    audio_path     TEXT,
    audio_bytes    INTEGER,
    duration_s     REAL,
    -- The transcript, kept after the audio is gone. It is the artefact worth
    -- keeping: re-running the analysis with a better prompt costs a request,
    -- re-transcribing costs the recording nobody has any more.
    transcript     TEXT,
    -- The segment list with timestamps, JSON. Separate from the flat transcript
    -- because the flat one is what goes in the prompt and this is what the UI
    -- needs to jump to a moment the review cites.
    segments       TEXT,
    -- The model's answer, JSON, exactly as parsed. Stored whole rather than
    -- spread across columns: the rubric will change, and a column per field
    -- means a migration every time it does.
    analysis       TEXT,
    -- Which provider actually answered, for when two reviews disagree in tone
    -- and somebody needs to know one was the fallback.
    analysis_model TEXT,
    error          TEXT,
    created_at     TEXT NOT NULL
                   DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at     TEXT NOT NULL
                   DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );
`;

const INDEXES = `
  CREATE INDEX IF NOT EXISTS meeting_reviews_time
    ON meeting_reviews (created_at DESC);
  -- The operator's own list, which is the default view for anyone who is not an
  -- admin and therefore the one query that has to be fast.
  CREATE INDEX IF NOT EXISTS meeting_reviews_actor_time
    ON meeting_reviews (actor_id, created_at DESC);
  -- The resume-on-boot scan. Partial, because the rows it wants are the few that
  -- are unfinished and the table is mostly finished ones.
  CREATE INDEX IF NOT EXISTS meeting_reviews_pending
    ON meeting_reviews (status)
    WHERE status IN ('fila', 'transcrevendo', 'analisando');
  CREATE INDEX IF NOT EXISTS meeting_reviews_lead
    ON meeting_reviews (lead_id) WHERE lead_id IS NOT NULL;
`;

let ready = false;

/**
 * The shared handle with the review tables guaranteed to exist. Every reader and
 * writer in this folder goes through it, so no route can reach a table before
 * its DDL has run.
 */
export function reviewDb(): DatabaseSync {
  const handle = getDb();
  if (!ready) {
    handle.exec(SCHEMA);
    handle.exec(INDEXES);
    ready = true;
  }
  return handle;
}

export type ReviewRow = {
  id: string;
  leadId: string | null;
  title: string;
  actorId: string;
  actorName: string;
  status: ReviewStatus;
  outcome: MeetingOutcome;
  focus: string | null;
  audioPath: string | null;
  audioBytes: number | null;
  durationSeconds: number | null;
  transcript: string | null;
  segments: TranscriptSegment[];
  analysis: unknown | null;
  analysisModel: string | null;
  error: string | null;
  createdAt: string;
  updatedAt: string;
};

type Raw = Record<string, unknown>;

function parseJson<T>(raw: unknown, fallback: T): T {
  if (typeof raw !== "string" || !raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function hydrate(row: Raw): ReviewRow {
  const status = String(row.status ?? "fila");
  return {
    id: String(row.id),
    leadId: row.lead_id === null ? null : String(row.lead_id),
    title: String(row.title ?? ""),
    actorId: String(row.actor_id ?? ""),
    actorName: String(row.actor_name ?? ""),
    status: isReviewStatus(status) ? status : "erro",
    outcome: isMeetingOutcome(row.outcome) ? row.outcome : "em_aberto",
    focus: row.focus === null ? null : String(row.focus),
    audioPath: row.audio_path === null ? null : String(row.audio_path),
    audioBytes: row.audio_bytes === null ? null : Number(row.audio_bytes),
    durationSeconds: row.duration_s === null ? null : Number(row.duration_s),
    transcript: row.transcript === null ? null : String(row.transcript),
    segments: parseJson<TranscriptSegment[]>(row.segments, []),
    analysis: parseJson<unknown>(row.analysis, null),
    analysisModel:
      row.analysis_model === null ? null : String(row.analysis_model),
    error: row.error === null ? null : String(row.error),
    createdAt: String(row.created_at ?? ""),
    updatedAt: String(row.updated_at ?? ""),
  };
}

export function createReview(input: {
  title: string;
  actorId: string;
  actorName: string;
  outcome: MeetingOutcome;
  focus?: string | null;
  leadId?: string | null;
  audioPath: string;
  audioBytes: number;
}): ReviewRow {
  const db = reviewDb();
  const id = randomUUID();

  db.prepare(
    `INSERT INTO meeting_reviews
       (id, lead_id, title, actor_id, actor_name, status, outcome, focus,
        audio_path, audio_bytes)
     VALUES (?, ?, ?, ?, ?, 'fila', ?, ?, ?, ?)`,
  ).run(
    id,
    input.leadId ?? null,
    input.title,
    input.actorId,
    input.actorName,
    input.outcome,
    input.focus?.trim() || null,
    input.audioPath,
    input.audioBytes,
  );

  const row = reviewById(id);
  if (!row) throw new Error("Falha ao gravar a reunião.");
  return row;
}

export function reviewById(id: string): ReviewRow | null {
  const row = reviewDb()
    .prepare("SELECT * FROM meeting_reviews WHERE id = ?")
    .get(id) as Raw | undefined;
  return row ? hydrate(row) : null;
}

/**
 * The list, scoped.
 *
 * `actorId` null means "everything", which is the admin's view. Passing the id
 * is not a filter a caller remembers to add — it is the first argument, so a
 * route that forgets it does not compile.
 */
export function listReviews(actorId: string | null, limit = 100): ReviewRow[] {
  const db = reviewDb();
  const rows = (
    actorId === null
      ? db
          .prepare(
            "SELECT * FROM meeting_reviews ORDER BY created_at DESC LIMIT ?",
          )
          .all(limit)
      : db
          .prepare(
            `SELECT * FROM meeting_reviews WHERE actor_id = ?
             ORDER BY created_at DESC LIMIT ?`,
          )
          .all(actorId, limit)
  ) as Raw[];
  return rows.map(hydrate);
}

export function updateReview(
  id: string,
  patch: {
    status?: ReviewStatus;
    transcript?: string;
    segments?: TranscriptSegment[];
    durationSeconds?: number;
    analysis?: unknown;
    analysisModel?: string;
    audioPath?: string | null;
    error?: string | null;
  },
): boolean {
  const sets: string[] = [];
  const values: (string | number | null)[] = [];

  if (patch.status !== undefined) {
    sets.push("status = ?");
    values.push(patch.status);
  }
  if (patch.transcript !== undefined) {
    sets.push("transcript = ?");
    values.push(patch.transcript);
  }
  if (patch.segments !== undefined) {
    sets.push("segments = ?");
    values.push(JSON.stringify(patch.segments));
  }
  if (patch.durationSeconds !== undefined) {
    sets.push("duration_s = ?");
    values.push(patch.durationSeconds);
  }
  if (patch.analysis !== undefined) {
    sets.push("analysis = ?");
    values.push(JSON.stringify(patch.analysis));
  }
  if (patch.analysisModel !== undefined) {
    sets.push("analysis_model = ?");
    values.push(patch.analysisModel);
  }
  if (patch.audioPath !== undefined) {
    sets.push("audio_path = ?");
    values.push(patch.audioPath);
  }
  if (patch.error !== undefined) {
    sets.push("error = ?");
    values.push(patch.error);
  }

  if (sets.length === 0) return false;
  sets.push("updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')");
  values.push(id);

  const result = reviewDb()
    .prepare(`UPDATE meeting_reviews SET ${sets.join(", ")} WHERE id = ?`)
    .run(...values);
  return Number(result.changes) > 0;
}

export function deleteReview(id: string): ReviewRow | null {
  const row = reviewById(id);
  if (!row) return null;
  reviewDb().prepare("DELETE FROM meeting_reviews WHERE id = ?").run(id);
  return row;
}

/**
 * Rows that were mid-pipeline when the process stopped.
 *
 * The two slow steps run in a background task, not in SQLite, so a deploy in the
 * middle of one leaves a row claiming to be transcribing with nothing
 * transcribing it. Boot re-queues them; an operator staring at "Transcrevendo"
 * forever is the failure this exists to prevent.
 */
export function unfinishedReviews(): ReviewRow[] {
  const rows = reviewDb()
    .prepare(
      `SELECT * FROM meeting_reviews
       WHERE status IN ('fila', 'transcrevendo', 'analisando')
       ORDER BY created_at ASC`,
    )
    .all() as Raw[];
  return rows.map(hydrate);
}
