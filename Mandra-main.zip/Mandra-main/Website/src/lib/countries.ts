/**
 * Every country the tools can prospect in, with the geography, the telephony and
 * the language rules the pipelines need, in one table.
 *
 * This started life inside `b2b/countries.ts` as a European list, because the
 * B2B half only ever crawled Europe. The local-business prospector then needed
 * the same facts — a bounding box to prune the Overture scan with, a dial code
 * to read a phone number with — for the rest of the world, and two tables would
 * have drifted the first time a border moved. So the table lives here and both
 * halves import it; `b2b/countries.ts` re-exports it plus its own crawl helpers.
 *
 * The bounding box is the load-bearing field. Overture places is one
 * unpartitioned set of Parquet files, so the *only* thing that stops a query
 * scanning the planet is a bbox predicate that row-group statistics can prune
 * on. Every box is a rectangle and every one of them spills over a border, which
 * is why `addresses[1].country` is what actually makes the result correct.
 */

/** How the picker groups the world. Order here is the order they are offered in. */
export const WORLD_REGIONS = [
  "América do Sul",
  "América do Norte e Central",
  "Europa Ocidental",
  "Europa Central e Oriental",
  "Nórdicos",
  "Oriente Médio",
  "Ásia e Pacífico",
  "África",
] as const;

export type WorldRegion = (typeof WORLD_REGIONS)[number];

export type Country = {
  /** ISO-3166 alpha-2, as Overture stores it. */
  code: string;
  label: string;
  /** Which part of the world the picker files it under. */
  region: WorldRegion;
  bbox: { xmin: number; xmax: number; ymin: number; ymax: number };
  /** E.164 prefix, no plus. Used to recognise and to rebuild phone numbers. */
  dial: string;
  /**
   * Regex over the *national* number — what is left after the dial code and any
   * trunk zero — that identifies a mobile line, or null where the numbering plan
   * doesn't separate them (US/CA) or we simply haven't verified it.
   *
   * `null` is not a small thing: it is what decides whether a lead gets a
   * WhatsApp button. A wa.me link to a landline opens a dead chat, so a country
   * we can't classify shows the plain number instead of guessing.
   *
   * Kept as a string rather than a RegExp because DuckDB has to run the same
   * pattern: the WhatsApp totals in overture.ts are counted in SQL over every
   * match, not in JS over the returned page. Both engines take these unchanged —
   * no lookaround, no backreferences, so RE2 is happy.
   */
  mobile: string | null;
  /** ccTLDs that imply this country when a page never says. */
  tlds: string[];
  /**
   * VAT id prefix, where one exists. EU ids start with it (Greece uses EL, not
   * GR); Switzerland's CHE is not EU but has the same shape.
   */
  vat: string | null;
  /** Language to open the conversation in. */
  language: string;
  /** Which outreach template to write in. See outreachMessage() in score.ts. */
  speaks: "pt" | "es" | "en";
};

// One country per line on purpose — this is a table, and Prettier's expansion of
// it into one field per row makes a typo in a bounding box impossible to spot
// next to its neighbours.
// prettier-ignore
export const COUNTRIES: Country[] = [
  // --- América do Sul ---------------------------------------------------------
  { code: "BR", label: "Brasil", region: "América do Sul", bbox: { xmin: -74.0, xmax: -34.0, ymin: -34.0, ymax: 5.5 }, dial: "55", mobile: "^[1-9][1-9]9[0-9]{8}$", tlds: [".br", ".com.br"], vat: null, language: "Português", speaks: "pt" },
  { code: "AR", label: "Argentina", region: "América do Sul", bbox: { xmin: -73.6, xmax: -53.6, ymin: -55.1, ymax: -21.8 }, dial: "54", mobile: "^9[0-9]{10}$", tlds: [".ar", ".com.ar"], vat: null, language: "Espanhol", speaks: "es" },
  { code: "CL", label: "Chile", region: "América do Sul", bbox: { xmin: -75.7, xmax: -66.4, ymin: -55.9, ymax: -17.5 }, dial: "56", mobile: "^9[0-9]{8}$", tlds: [".cl"], vat: null, language: "Espanhol", speaks: "es" },
  { code: "CO", label: "Colômbia", region: "América do Sul", bbox: { xmin: -79.0, xmax: -66.9, ymin: -4.3, ymax: 12.5 }, dial: "57", mobile: "^3[0-9]{9}$", tlds: [".co", ".com.co"], vat: null, language: "Espanhol", speaks: "es" },
  { code: "PE", label: "Peru", region: "América do Sul", bbox: { xmin: -81.4, xmax: -68.7, ymin: -18.4, ymax: -0.0 }, dial: "51", mobile: "^9[0-9]{8}$", tlds: [".pe", ".com.pe"], vat: null, language: "Espanhol", speaks: "es" },
  { code: "UY", label: "Uruguai", region: "América do Sul", bbox: { xmin: -58.5, xmax: -53.1, ymin: -35.0, ymax: -30.1 }, dial: "598", mobile: "^9[0-9]{7}$", tlds: [".uy", ".com.uy"], vat: null, language: "Espanhol", speaks: "es" },
  { code: "PY", label: "Paraguai", region: "América do Sul", bbox: { xmin: -62.7, xmax: -54.2, ymin: -27.6, ymax: -19.3 }, dial: "595", mobile: "^9[0-9]{8}$", tlds: [".py", ".com.py"], vat: null, language: "Espanhol", speaks: "es" },
  { code: "BO", label: "Bolívia", region: "América do Sul", bbox: { xmin: -69.7, xmax: -57.5, ymin: -22.9, ymax: -9.7 }, dial: "591", mobile: "^[67][0-9]{7}$", tlds: [".bo", ".com.bo"], vat: null, language: "Espanhol", speaks: "es" },
  { code: "EC", label: "Equador", region: "América do Sul", bbox: { xmin: -81.1, xmax: -75.2, ymin: -5.0, ymax: 1.5 }, dial: "593", mobile: "^9[0-9]{8}$", tlds: [".ec", ".com.ec"], vat: null, language: "Espanhol", speaks: "es" },

  // --- América do Norte e Central ---------------------------------------------
  // Mainland only. Alaska and Hawaii would widen the box across the Pacific and
  // pull the whole planet's row groups back into the scan.
  { code: "US", label: "Estados Unidos", region: "América do Norte e Central", bbox: { xmin: -125.0, xmax: -66.9, ymin: 24.4, ymax: 49.4 }, dial: "1", mobile: null, tlds: [".us"], vat: null, language: "Inglês", speaks: "en" },
  { code: "CA", label: "Canadá", region: "América do Norte e Central", bbox: { xmin: -141.0, xmax: -52.6, ymin: 41.6, ymax: 70.0 }, dial: "1", mobile: null, tlds: [".ca"], vat: null, language: "Inglês / Francês", speaks: "en" },
  { code: "MX", label: "México", region: "América do Norte e Central", bbox: { xmin: -118.5, xmax: -86.7, ymin: 14.5, ymax: 32.8 }, dial: "52", mobile: "^[1-9][0-9]{9}$", tlds: [".mx", ".com.mx"], vat: null, language: "Espanhol", speaks: "es" },
  { code: "CR", label: "Costa Rica", region: "América do Norte e Central", bbox: { xmin: -86.0, xmax: -82.5, ymin: 8.0, ymax: 11.3 }, dial: "506", mobile: "^[678][0-9]{7}$", tlds: [".cr", ".co.cr"], vat: null, language: "Espanhol", speaks: "es" },
  { code: "PA", label: "Panamá", region: "América do Norte e Central", bbox: { xmin: -83.1, xmax: -77.1, ymin: 7.1, ymax: 9.7 }, dial: "507", mobile: "^6[0-9]{7}$", tlds: [".pa", ".com.pa"], vat: null, language: "Espanhol", speaks: "es" },
  { code: "DO", label: "República Dominicana", region: "América do Norte e Central", bbox: { xmin: -72.1, xmax: -68.3, ymin: 17.5, ymax: 20.0 }, dial: "1", mobile: null, tlds: [".do", ".com.do"], vat: null, language: "Espanhol", speaks: "es" },

  // --- Europa Ocidental -------------------------------------------------------
  { code: "PT", label: "Portugal", region: "Europa Ocidental", bbox: { xmin: -9.6, xmax: -6.1, ymin: 36.9, ymax: 42.2 }, dial: "351", mobile: "^9[1236][0-9]{7}$", tlds: [".pt"], vat: "PT", language: "Português", speaks: "pt" },
  // Mainland plus the Balearics. The Canaries sit 1.800 km southwest and would
  // widen the box across the Atlantic for a rounding error's worth of business.
  { code: "ES", label: "Espanha", region: "Europa Ocidental", bbox: { xmin: -9.4, xmax: 4.4, ymin: 35.9, ymax: 43.9 }, dial: "34", mobile: "^[67][0-9]{8}$", tlds: [".es"], vat: "ES", language: "Espanhol", speaks: "es" },
  { code: "DE", label: "Alemanha", region: "Europa Ocidental", bbox: { xmin: 5.8, xmax: 15.1, ymin: 47.2, ymax: 55.1 }, dial: "49", mobile: "^1[5-7][0-9]{7,9}$", tlds: [".de"], vat: "DE", language: "Alemão", speaks: "en" },
  { code: "AT", label: "Áustria", region: "Europa Ocidental", bbox: { xmin: 9.5, xmax: 17.2, ymin: 46.3, ymax: 49.1 }, dial: "43", mobile: "^6[0-9]{8,11}$", tlds: [".at"], vat: "ATU", language: "Alemão", speaks: "en" },
  { code: "CH", label: "Suíça", region: "Europa Ocidental", bbox: { xmin: 5.9, xmax: 10.5, ymin: 45.8, ymax: 47.9 }, dial: "41", mobile: "^7[5-9][0-9]{7}$", tlds: [".ch"], vat: "CHE", language: "Alemão / Francês", speaks: "en" },
  { code: "FR", label: "França", region: "Europa Ocidental", bbox: { xmin: -5.2, xmax: 9.6, ymin: 41.3, ymax: 51.2 }, dial: "33", mobile: "^[67][0-9]{8}$", tlds: [".fr"], vat: "FR", language: "Francês", speaks: "en" },
  { code: "IT", label: "Itália", region: "Europa Ocidental", bbox: { xmin: 6.6, xmax: 18.6, ymin: 35.4, ymax: 47.1 }, dial: "39", mobile: "^3[0-9]{8,9}$", tlds: [".it"], vat: "IT", language: "Italiano", speaks: "en" },
  { code: "NL", label: "Países Baixos", region: "Europa Ocidental", bbox: { xmin: 3.3, xmax: 7.3, ymin: 50.7, ymax: 53.6 }, dial: "31", mobile: "^6[0-9]{8}$", tlds: [".nl"], vat: "NL", language: "Holandês / Inglês", speaks: "en" },
  { code: "BE", label: "Bélgica", region: "Europa Ocidental", bbox: { xmin: 2.5, xmax: 6.5, ymin: 49.4, ymax: 51.6 }, dial: "32", mobile: "^4[5-9][0-9]{7}$", tlds: [".be"], vat: "BE", language: "Holandês / Francês", speaks: "en" },
  { code: "LU", label: "Luxemburgo", region: "Europa Ocidental", bbox: { xmin: 5.7, xmax: 6.6, ymin: 49.4, ymax: 50.2 }, dial: "352", mobile: "^6[0-9]{8}$", tlds: [".lu"], vat: "LU", language: "Francês / Alemão", speaks: "en" },
  { code: "GB", label: "Reino Unido", region: "Europa Ocidental", bbox: { xmin: -8.7, xmax: 1.8, ymin: 49.8, ymax: 60.9 }, dial: "44", mobile: "^7[1-9][0-9]{8}$", tlds: [".uk", ".co.uk"], vat: "GB", language: "Inglês", speaks: "en" },
  { code: "IE", label: "Irlanda", region: "Europa Ocidental", bbox: { xmin: -10.6, xmax: -5.9, ymin: 51.4, ymax: 55.5 }, dial: "353", mobile: "^8[35-9][0-9]{7}$", tlds: [".ie"], vat: "IE", language: "Inglês", speaks: "en" },

  // --- Nórdicos ---------------------------------------------------------------
  // Denmark's plan has no fixed/mobile split, so every eight-digit number is
  // treated as reachable; the alternative is losing the whole country's buttons.
  { code: "DK", label: "Dinamarca", region: "Nórdicos", bbox: { xmin: 8.0, xmax: 15.2, ymin: 54.5, ymax: 57.8 }, dial: "45", mobile: "^[2-9][0-9]{7}$", tlds: [".dk"], vat: "DK", language: "Dinamarquês / Inglês", speaks: "en" },
  { code: "SE", label: "Suécia", region: "Nórdicos", bbox: { xmin: 10.9, xmax: 24.2, ymin: 55.3, ymax: 69.1 }, dial: "46", mobile: "^7[0236][0-9]{7}$", tlds: [".se"], vat: "SE", language: "Sueco / Inglês", speaks: "en" },
  { code: "NO", label: "Noruega", region: "Nórdicos", bbox: { xmin: 4.5, xmax: 31.1, ymin: 57.9, ymax: 71.2 }, dial: "47", mobile: "^[49][0-9]{7}$", tlds: [".no"], vat: null, language: "Norueguês / Inglês", speaks: "en" },
  { code: "FI", label: "Finlândia", region: "Nórdicos", bbox: { xmin: 20.5, xmax: 31.6, ymin: 59.7, ymax: 70.1 }, dial: "358", mobile: "^(4|50)[0-9]{6,8}$", tlds: [".fi"], vat: "FI", language: "Finlandês / Inglês", speaks: "en" },
  { code: "IS", label: "Islândia", region: "Nórdicos", bbox: { xmin: -24.6, xmax: -13.5, ymin: 63.3, ymax: 66.6 }, dial: "354", mobile: "^[678][0-9]{6}$", tlds: [".is"], vat: null, language: "Islandês / Inglês", speaks: "en" },

  // --- Europa Central e Oriental ----------------------------------------------
  { code: "PL", label: "Polônia", region: "Europa Central e Oriental", bbox: { xmin: 14.1, xmax: 24.2, ymin: 49.0, ymax: 54.9 }, dial: "48", mobile: "^[5-8][0-9]{8}$", tlds: [".pl"], vat: "PL", language: "Polonês / Inglês", speaks: "en" },
  { code: "CZ", label: "Tchéquia", region: "Europa Central e Oriental", bbox: { xmin: 12.0, xmax: 18.9, ymin: 48.5, ymax: 51.1 }, dial: "420", mobile: "^[67][0-9]{8}$", tlds: [".cz"], vat: "CZ", language: "Tcheco / Inglês", speaks: "en" },
  { code: "SK", label: "Eslováquia", region: "Europa Central e Oriental", bbox: { xmin: 16.8, xmax: 22.6, ymin: 47.7, ymax: 49.6 }, dial: "421", mobile: "^9[0-9]{8}$", tlds: [".sk"], vat: "SK", language: "Eslovaco / Inglês", speaks: "en" },
  { code: "HU", label: "Hungria", region: "Europa Central e Oriental", bbox: { xmin: 16.1, xmax: 22.9, ymin: 45.7, ymax: 48.6 }, dial: "36", mobile: "^[237]0[0-9]{7}$", tlds: [".hu"], vat: "HU", language: "Húngaro / Inglês", speaks: "en" },
  { code: "RO", label: "Romênia", region: "Europa Central e Oriental", bbox: { xmin: 20.2, xmax: 29.7, ymin: 43.6, ymax: 48.3 }, dial: "40", mobile: "^7[0-9]{8}$", tlds: [".ro"], vat: "RO", language: "Romeno / Inglês", speaks: "en" },
  { code: "SI", label: "Eslovênia", region: "Europa Central e Oriental", bbox: { xmin: 13.3, xmax: 16.6, ymin: 45.4, ymax: 46.9 }, dial: "386", mobile: "^[36][0-9]{7}$", tlds: [".si"], vat: "SI", language: "Esloveno / Inglês", speaks: "en" },
  { code: "HR", label: "Croácia", region: "Europa Central e Oriental", bbox: { xmin: 13.4, xmax: 19.5, ymin: 42.3, ymax: 46.6 }, dial: "385", mobile: "^9[0-9]{7,8}$", tlds: [".hr"], vat: "HR", language: "Croata / Inglês", speaks: "en" },
  { code: "EE", label: "Estônia", region: "Europa Central e Oriental", bbox: { xmin: 21.7, xmax: 28.2, ymin: 57.5, ymax: 59.7 }, dial: "372", mobile: "^5[0-9]{6,7}$", tlds: [".ee"], vat: "EE", language: "Inglês", speaks: "en" },
  { code: "LV", label: "Letônia", region: "Europa Central e Oriental", bbox: { xmin: 20.9, xmax: 28.3, ymin: 55.6, ymax: 58.1 }, dial: "371", mobile: "^2[0-9]{7}$", tlds: [".lv"], vat: "LV", language: "Inglês", speaks: "en" },
  { code: "LT", label: "Lituânia", region: "Europa Central e Oriental", bbox: { xmin: 20.9, xmax: 26.9, ymin: 53.8, ymax: 56.5 }, dial: "370", mobile: "^6[0-9]{7}$", tlds: [".lt"], vat: "LT", language: "Inglês", speaks: "en" },
  { code: "GR", label: "Grécia", region: "Europa Central e Oriental", bbox: { xmin: 19.3, xmax: 29.7, ymin: 34.8, ymax: 41.8 }, dial: "30", mobile: "^69[0-9]{8}$", tlds: [".gr"], vat: "EL", language: "Grego / Inglês", speaks: "en" },
  { code: "BG", label: "Bulgária", region: "Europa Central e Oriental", bbox: { xmin: 22.3, xmax: 28.7, ymin: 41.2, ymax: 44.3 }, dial: "359", mobile: "^8[7-9][0-9]{7}$", tlds: [".bg"], vat: "BG", language: "Búlgaro / Inglês", speaks: "en" },
  { code: "TR", label: "Turquia", region: "Europa Central e Oriental", bbox: { xmin: 25.6, xmax: 44.9, ymin: 35.8, ymax: 42.2 }, dial: "90", mobile: "^5[0-9]{9}$", tlds: [".tr", ".com.tr"], vat: null, language: "Turco / Inglês", speaks: "en" },

  // --- Oriente Médio ----------------------------------------------------------
  { code: "AE", label: "Emirados Árabes", region: "Oriente Médio", bbox: { xmin: 51.5, xmax: 56.4, ymin: 22.6, ymax: 26.1 }, dial: "971", mobile: "^5[0-9]{8}$", tlds: [".ae"], vat: null, language: "Inglês", speaks: "en" },
  { code: "SA", label: "Arábia Saudita", region: "Oriente Médio", bbox: { xmin: 34.5, xmax: 55.7, ymin: 16.3, ymax: 32.2 }, dial: "966", mobile: "^5[0-9]{8}$", tlds: [".sa", ".com.sa"], vat: null, language: "Inglês", speaks: "en" },
  { code: "QA", label: "Catar", region: "Oriente Médio", bbox: { xmin: 50.7, xmax: 51.7, ymin: 24.5, ymax: 26.2 }, dial: "974", mobile: "^[3567][0-9]{7}$", tlds: [".qa"], vat: null, language: "Inglês", speaks: "en" },
  { code: "IL", label: "Israel", region: "Oriente Médio", bbox: { xmin: 34.2, xmax: 35.9, ymin: 29.4, ymax: 33.4 }, dial: "972", mobile: "^5[0-9]{8}$", tlds: [".il", ".co.il"], vat: null, language: "Inglês", speaks: "en" },

  // --- Ásia e Pacífico --------------------------------------------------------
  { code: "IN", label: "Índia", region: "Ásia e Pacífico", bbox: { xmin: 68.1, xmax: 97.4, ymin: 6.7, ymax: 35.5 }, dial: "91", mobile: "^[6-9][0-9]{9}$", tlds: [".in", ".co.in"], vat: null, language: "Inglês", speaks: "en" },
  { code: "ID", label: "Indonésia", region: "Ásia e Pacífico", bbox: { xmin: 95.0, xmax: 141.0, ymin: -11.0, ymax: 6.1 }, dial: "62", mobile: "^8[0-9]{8,11}$", tlds: [".id", ".co.id"], vat: null, language: "Inglês", speaks: "en" },
  { code: "MY", label: "Malásia", region: "Ásia e Pacífico", bbox: { xmin: 99.6, xmax: 119.3, ymin: 0.8, ymax: 7.4 }, dial: "60", mobile: "^1[0-9]{8,9}$", tlds: [".my", ".com.my"], vat: null, language: "Inglês", speaks: "en" },
  { code: "TH", label: "Tailândia", region: "Ásia e Pacífico", bbox: { xmin: 97.3, xmax: 105.7, ymin: 5.6, ymax: 20.5 }, dial: "66", mobile: "^[689][0-9]{8}$", tlds: [".th", ".co.th"], vat: null, language: "Inglês", speaks: "en" },
  { code: "PH", label: "Filipinas", region: "Ásia e Pacífico", bbox: { xmin: 116.9, xmax: 126.6, ymin: 4.6, ymax: 21.1 }, dial: "63", mobile: "^9[0-9]{9}$", tlds: [".ph", ".com.ph"], vat: null, language: "Inglês", speaks: "en" },
  { code: "SG", label: "Singapura", region: "Ásia e Pacífico", bbox: { xmin: 103.6, xmax: 104.1, ymin: 1.2, ymax: 1.5 }, dial: "65", mobile: "^[89][0-9]{7}$", tlds: [".sg", ".com.sg"], vat: null, language: "Inglês", speaks: "en" },
  { code: "JP", label: "Japão", region: "Ásia e Pacífico", bbox: { xmin: 129.0, xmax: 146.0, ymin: 30.9, ymax: 45.6 }, dial: "81", mobile: "^[789]0[0-9]{8}$", tlds: [".jp", ".co.jp"], vat: null, language: "Inglês", speaks: "en" },
  { code: "KR", label: "Coreia do Sul", region: "Ásia e Pacífico", bbox: { xmin: 125.9, xmax: 129.6, ymin: 33.1, ymax: 38.6 }, dial: "82", mobile: "^1[0-9]{9}$", tlds: [".kr", ".co.kr"], vat: null, language: "Inglês", speaks: "en" },
  { code: "AU", label: "Austrália", region: "Ásia e Pacífico", bbox: { xmin: 112.9, xmax: 154.0, ymin: -43.7, ymax: -10.0 }, dial: "61", mobile: "^4[0-9]{8}$", tlds: [".au", ".com.au"], vat: null, language: "Inglês", speaks: "en" },
  { code: "NZ", label: "Nova Zelândia", region: "Ásia e Pacífico", bbox: { xmin: 166.4, xmax: 178.6, ymin: -47.3, ymax: -34.4 }, dial: "64", mobile: "^2[0-9]{7,9}$", tlds: [".nz", ".co.nz"], vat: null, language: "Inglês", speaks: "en" },

  // --- África -----------------------------------------------------------------
  { code: "ZA", label: "África do Sul", region: "África", bbox: { xmin: 16.4, xmax: 32.9, ymin: -34.9, ymax: -22.1 }, dial: "27", mobile: "^[678][0-9]{8}$", tlds: [".za", ".co.za"], vat: null, language: "Inglês", speaks: "en" },
  { code: "NG", label: "Nigéria", region: "África", bbox: { xmin: 2.7, xmax: 14.7, ymin: 4.2, ymax: 13.9 }, dial: "234", mobile: "^[789][01][0-9]{8}$", tlds: [".ng", ".com.ng"], vat: null, language: "Inglês", speaks: "en" },
  { code: "KE", label: "Quênia", region: "África", bbox: { xmin: 33.9, xmax: 41.9, ymin: -4.7, ymax: 5.0 }, dial: "254", mobile: "^[17][0-9]{8}$", tlds: [".ke", ".co.ke"], vat: null, language: "Inglês", speaks: "en" },
  { code: "EG", label: "Egito", region: "África", bbox: { xmin: 24.7, xmax: 36.9, ymin: 22.0, ymax: 31.7 }, dial: "20", mobile: "^1[0-9]{9}$", tlds: [".eg", ".com.eg"], vat: null, language: "Inglês", speaks: "en" },
  { code: "MA", label: "Marrocos", region: "África", bbox: { xmin: -13.2, xmax: -1.0, ymin: 27.7, ymax: 35.9 }, dial: "212", mobile: "^[67][0-9]{8}$", tlds: [".ma"], vat: null, language: "Francês / Inglês", speaks: "en" },
  { code: "AO", label: "Angola", region: "África", bbox: { xmin: 11.7, xmax: 24.1, ymin: -18.0, ymax: -4.4 }, dial: "244", mobile: "^9[0-9]{8}$", tlds: [".ao"], vat: null, language: "Português", speaks: "pt" },
  { code: "MZ", label: "Moçambique", region: "África", bbox: { xmin: 30.2, xmax: 40.8, ymin: -26.9, ymax: -10.5 }, dial: "258", mobile: "^8[2-7][0-9]{7}$", tlds: [".mz", ".co.mz"], vat: null, language: "Português", speaks: "pt" },
];

const BY_CODE = new Map(COUNTRIES.map((c) => [c.code, c]));

export function findCountry(code: string | null | undefined): Country | null {
  if (!code) return null;
  return BY_CODE.get(code.toUpperCase()) ?? null;
}

export function countryLabel(code: string | null): string {
  if (!code) return "—";
  return BY_CODE.get(code.toUpperCase())?.label ?? code.toUpperCase();
}

export function isCountryCode(value: unknown): boolean {
  return typeof value === "string" && BY_CODE.has(value.toUpperCase());
}

/** Only codes we know, uppercased and deduped. Unknown codes are dropped, not guessed. */
export function normaliseCountries(codes: string[]): string[] {
  const out: string[] = [];
  for (const raw of codes) {
    const code = String(raw ?? "").toUpperCase();
    if (BY_CODE.has(code) && !out.includes(code)) out.push(code);
  }
  return out;
}

/** The table grouped for an `<optgroup>` picker, in WORLD_REGIONS order. */
export function countriesByRegion(
  codes?: string[],
): { region: WorldRegion; countries: Country[] }[] {
  const allowed = codes ? new Set(normaliseCountries(codes)) : null;
  return WORLD_REGIONS.map((region) => ({
    region,
    countries: COUNTRIES.filter(
      (c) => c.region === region && (!allowed || allowed.has(c.code)),
    ),
  })).filter((g) => g.countries.length > 0);
}

/** Every country of a part of the world, as codes. */
export function countriesInRegion(region: string): string[] {
  return COUNTRIES.filter((c) => c.region === region).map((c) => c.code);
}

/** The box that contains every selected country — one predicate for the scan. */
export function unionBbox(codes: string[]): {
  xmin: number;
  xmax: number;
  ymin: number;
  ymax: number;
} {
  const boxes = codes
    .map((c) => BY_CODE.get(c.toUpperCase())?.bbox)
    .filter(Boolean) as {
    xmin: number;
    xmax: number;
    ymin: number;
    ymax: number;
  }[];
  if (boxes.length === 0) return { xmin: -180, xmax: 180, ymin: -90, ymax: 90 };
  return {
    xmin: Math.min(...boxes.map((b) => b.xmin)),
    xmax: Math.max(...boxes.map((b) => b.xmax)),
    ymin: Math.min(...boxes.map((b) => b.ymin)),
    ymax: Math.max(...boxes.map((b) => b.ymax)),
  };
}
