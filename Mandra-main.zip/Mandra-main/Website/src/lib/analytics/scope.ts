import type { Scope } from "./db";
import { pageBySlug, type Template } from "./pages";

/**
 * Turning the query string into a `Scope`, in one place.
 *
 * There are six screens under `/admin/analytics` and they all take the same
 * four filters. Parsed separately on each, they would drift — and the drift is
 * invisible, because each screen looks internally consistent while describing
 * a different set of sessions from the tab next to it. The same argument as
 * the prospector's `parseFilters` and the single `scopeSql()` builder in
 * `db.ts`: one reader, one writer, one meaning.
 */

export const PERIODS = [
  { days: 7, label: "7 dias" },
  { days: 30, label: "30 dias" },
  { days: 90, label: "90 dias" },
  { days: 0, label: "Tudo" },
] as const;

const DEFAULT_DAYS = 30;

export type Params = Record<string, string | string[] | undefined>;

export type ParsedScope = {
  scope: Scope;
  days: number;
  page?: string;
  template?: Template;
  paidOnly: boolean;
  /** Builds a link to the same screen with some filters changed. */
  href: (path: string, next?: Record<string, string | undefined>) => string;
};

export function parseScope(params: Params, fallback?: Template): ParsedScope {
  const one = (key: string): string | undefined => {
    const value = params[key];
    return Array.isArray(value) ? value[0] : value;
  };

  const raw = one("dias");
  const days = PERIODS.some((period) => String(period.days) === raw)
    ? Number(raw)
    : DEFAULT_DAYS;

  // Checked against the registry rather than taken as given: the slug reaches
  // a SQL parameter, and more importantly an unknown one produces a screen of
  // zeroes that looks exactly like a page nobody visited.
  const pageParam = one("pagina");
  const page = pageParam && pageBySlug.has(pageParam) ? pageParam : undefined;

  // A page pins its own template down, so an explicit one alongside it could
  // only contradict it.
  const templateParam = one("tipo");
  const template = page
    ? pageBySlug.get(page)?.template
    : isTemplate(templateParam)
      ? templateParam
      : fallback;

  const paidOnly = one("pago") === "1";

  const href = (
    path: string,
    next: Record<string, string | undefined> = {},
  ): string => {
    const query = new URLSearchParams();
    query.set("dias", String(days));
    if (page) query.set("pagina", page);
    else if (template) query.set("tipo", template);
    if (paidOnly) query.set("pago", "1");

    for (const [key, value] of Object.entries(next)) {
      if (value === undefined || value === "") query.delete(key);
      else query.set(key, value);
    }
    // Selecting a page and a template at once is contradictory, and the last
    // one the caller set is the one they meant.
    if (next.pagina) query.delete("tipo");
    if (next.tipo) query.delete("pagina");

    return `${path}?${query.toString()}`;
  };

  return {
    scope: { page, template, days, paidOnly },
    days,
    page,
    template,
    paidOnly,
    href,
  };
}

function isTemplate(value: string | undefined): value is Template {
  return value === "ads" || value === "site" || value === "legal";
}
