import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { measuredPages, pageBySlug, funnelFor, slugsOf } from "./pages";
import { ADS_FUNNEL, SITE_FUNNEL, ALL_SECTIONS } from "./events";

/**
 * The registry, which is also the collector's allowlist.
 *
 * Two of these guard a collision rather than a calculation. The site's pages
 * are keyed by bare slugs in the same namespace as the ad pages, which is the
 * legible choice and the one with a sharp edge: an ad group named `home` would
 * silently take over the home page's row, its funnel and its history, and
 * nothing about that reports itself. It is a one-line test and a very
 * unpleasant afternoon otherwise.
 */
describe("the measured-page registry", () => {
  it("has no two pages under the same slug", () => {
    const slugs = measuredPages.map((page) => page.slug);
    assert.equal(
      new Set(slugs).size,
      slugs.length,
      "an ad slug has collided with one of the site's pages",
    );
  });

  it("keeps the map in step with the list", () => {
    assert.equal(pageBySlug.size, measuredPages.length);
  });

  it("gives each template the funnel its pages actually render", () => {
    assert.deepEqual(funnelFor("home"), SITE_FUNNEL);
    assert.deepEqual(funnelFor("criacao-de-sites"), ADS_FUNNEL);
  });

  it("gives the legal pages no funnel at all", () => {
    // Nothing converts on them; a funnel would be a chart that means nothing.
    assert.deepEqual(funnelFor("privacidade"), []);
  });

  it("returns nothing for a page it does not publish", () => {
    assert.deepEqual(funnelFor("nao-existe"), []);
  });

  it("lists the site's pages separately from the ads'", () => {
    const site = slugsOf("site");
    const ads = slugsOf("ads");
    assert.deepEqual(site, ["home"]);
    assert.ok(ads.length > 1);
    assert.ok(!ads.includes("home"));
  });

  it("only uses section names the collector will accept", () => {
    // A funnel step the collector drops reads on the dashboard as a band
    // nobody reached, which is indistinguishable from a real finding.
    const allowed = new Set<string>(ALL_SECTIONS);
    for (const page of measuredPages) {
      for (const section of page.funnel) {
        assert.ok(
          allowed.has(section),
          `${page.slug} lists a section the collector would drop: ${section}`,
        );
      }
    }
  });
});
