/**
 * Ad URL tagging — what it is, and the one line that turns it on.
 *
 * When someone clicks an ad, Google sends them to the landing page. The URL
 * can carry, in its query string, *which* ad and *which keyword* produced that
 * visit. Google does not add any of that by itself: the only thing it appends
 * automatically is `gclid`, which says "this click was paid for" and nothing
 * about what was searched.
 *
 * The difference that makes:
 *
 *   without tagging  "the page converts at 8%"
 *   with tagging     "[criação de sites] converts at 15%; [site profissional]
 *                     has spent R$300 and converted nobody — pause it"
 *
 * It is one paste, once, at account level, and every campaign inherits it. The
 * string lives here rather than in a document so the dashboard can show the
 * exact text to paste and the two can never drift.
 *
 * The `{...}` pieces are Google's ValueTrack parameters; Google substitutes
 * them per click. `{campaignid}` and `{adgroupid}` come back as numbers rather
 * than names — Google offers no name variant — which is fine for comparing
 * rows, and a campaign can override `utm_campaign` with a readable name in its
 * own suffix if you prefer.
 */
export const FINAL_URL_SUFFIX = [
  "utm_source=google",
  "utm_medium=cpc",
  "utm_campaign={campaignid}",
  "utm_adgroup={adgroupid}",
  "utm_term={keyword}",
  "utm_matchtype={matchtype}",
  "utm_network={network}",
  "utm_content={creative}",
].join("&");

/** Where to paste it, so the dashboard can say so without a screenshot. */
export const FINAL_URL_SUFFIX_PATH =
  "Google Ads → Configurações da conta → Acompanhamento → Sufixo do URL final";

/**
 * The query parameters the tracker reads, mapped to the column they fill.
 *
 * `keyword` is accepted alongside `utm_term` because several tutorials — and
 * Google's own older examples — tag with it, and a visit whose keyword landed
 * under the other spelling is exactly as useful.
 */
export const AD_PARAMS: Record<string, string[]> = {
  source: ["utm_source"],
  medium: ["utm_medium"],
  campaign: ["utm_campaign"],
  adgroup: ["utm_adgroup", "utm_adgroupid"],
  term: ["utm_term", "keyword", "kw"],
  matchtype: ["utm_matchtype", "matchtype"],
  network: ["utm_network", "network"],
  content: ["utm_content"],
  /** Google appends these itself; any of the three means the click was paid. */
  gclid: ["gclid", "wbraid", "gbraid"],
};

/**
 * Google writes the match type as a single letter. Nobody reads `e` as
 * "exact", and the whole value of this column is being able to see at a glance
 * that broad match is where the money went.
 */
export const MATCH_TYPE_LABEL: Record<string, string> = {
  e: "Exata",
  p: "Frase",
  b: "Ampla",
  exact: "Exata",
  phrase: "Frase",
  broad: "Ampla",
};

export function matchTypeLabel(value: string): string {
  return MATCH_TYPE_LABEL[value.toLowerCase()] ?? value;
}
