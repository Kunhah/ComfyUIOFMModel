/**
 * The contract between the tracker in the browser and the collector route.
 *
 * It is written once and imported by both halves on purpose: the client
 * decides what an event means and the server decides whether to believe it,
 * and the two drifting is how an analytics screen starts reporting confidently
 * about a funnel step nobody is sending any more. Same rule as the prospector's
 * `parseFilters` and the CSV column lists.
 *
 * Everything here is deliberately anonymous. There is no cookie, no
 * cross-site identifier and no IP stored anywhere — the session id lives in
 * `sessionStorage`, so it dies with the tab and never follows anyone to
 * another site. That is not only courtesy: an IP is personal data under the
 * LGPD, and a landing page that collects none has nothing to ask consent for.
 */

/**
 * The funnels, one per page template, each in the order the bands appear.
 *
 * There were not always two. The list below called `ADS_FUNNEL` was once the
 * only one, named `SECTIONS`, and `deepest` was an index into it — which was
 * correct exactly as long as the landing pages were the only thing measured.
 * The moment the home page started reporting bands, a single global list would
 * have scored `emaranhado` against the landing-page funnel, found nothing,
 * and filed a reader who saw the whole page at index 0: a bounce. A funnel
 * belongs to a template, so it is looked up per page in `pages.ts`.
 */
export const ADS_FUNNEL = [
  "hero",
  "dores",
  "entregaveis",
  "etapas",
  "perguntas",
  "fechamento",
] as const;

/**
 * The home page, band by band, in scroll order.
 *
 * This is the three acts of light in `(marketing)/page.tsx` and not a longer
 * version of the landing pages' funnel. Nobody arrives here having searched
 * for one trade, so the question is "which act loses them" — and the answer
 * has a different shape: a drop at `linhas` is the paper act failing to hold
 * someone the night act had already convinced.
 */
export const SITE_FUNNEL = [
  "hero",
  "emaranhado",
  "linhas",
  "diagrama",
  "rota",
  "ferramental",
  "carga",
  "terminal",
] as const;

export type Section =
  (typeof ADS_FUNNEL)[number] | (typeof SITE_FUNNEL)[number];

export const SECTION_LABEL: Record<Section, string> = {
  hero: "Primeira tela",
  dores: "O que trava hoje",
  entregaveis: "O que entra",
  etapas: "Como funciona",
  perguntas: "Perguntas",
  fechamento: "Fechamento",
  emaranhado: "O emaranhado",
  linhas: "As linhas",
  diagrama: "O diagrama",
  rota: "A rota",
  ferramental: "O ferramental",
  carga: "O que já carrega",
  terminal: "Terminal (contato)",
};

/** Every section name the collector will accept, across every template. */
export const ALL_SECTIONS: readonly Section[] = [...ADS_FUNNEL, ...SITE_FUNNEL];

/** Where on the page an action was taken. Which CTA earns its place. */
export const PLACEMENTS = [
  "cabecalho",
  "primeira-tela",
  "meio",
  "perguntas",
  "fechamento",
  "barra-fixa",
  "rodape",
] as const;
export type Placement = (typeof PLACEMENTS)[number];

export const PLACEMENT_LABEL: Record<Placement, string> = {
  cabecalho: "Cabeçalho",
  "primeira-tela": "Primeira tela",
  meio: "Meio da página",
  perguntas: "Junto às perguntas",
  fechamento: "Faixa final",
  "barra-fixa": "Barra fixa (celular)",
  rodape: "Rodapé",
};

export const EVENT_TYPES = [
  /** One per session, carrying the context. */
  "view",
  /** A section became visible. `name` is the section. */
  "section",
  /** A tap on the phone or WhatsApp. `name` is which, `placement` is where. */
  "cta",
  /** A FAQ entry was opened. `name` is the question. */
  "faq",
  /** Max scroll depth so far, as a percentage in `value`. */
  "depth",
  /** Visible time so far, in milliseconds in `value`. */
  "engage",
  /**
   * The section on screen when the reader left. `name` is the section.
   *
   * Not the same question as `deepest`, and the difference is the useful part:
   * `deepest` says how far someone got, this says where they were standing
   * when they gave up. A reader who reaches the closing band, scrolls back to
   * the price and *then* leaves is a full-funnel session whose real exit is
   * the price — invisible to every other measure on this screen.
   */
  "exit",
  /**
   * A click on something that does nothing. `name` is a coarse description of
   * what was clicked.
   *
   * The single highest-value signal for "what to improve" that a funnel cannot
   * produce: it is someone trying to use the page in a way the page does not
   * support. A heading that looks like a button, a card that looks tappable,
   * a phone number rendered as text. Every one of those is a reader who wanted
   * to go further and was told no by nothing at all.
   */
  "dead",
  /**
   * Repeated clicks in the same spot in quick succession — the reader is
   * either stuck or annoyed. `value` is how many.
   */
  "rage",
  /** Visible time for one section, in `value`, `name` is the section. */
  "dwell",
  /** Milliseconds to the first scroll, in `value`. How fast the hero lands. */
  "firstscroll",
] as const;
export type EventType = (typeof EVENT_TYPES)[number];

export const DEVICES = ["celular", "tablet", "desktop"] as const;
export type Device = (typeof DEVICES)[number];

export type ClientEvent = {
  type: EventType;
  /** Section id, cta kind, or the FAQ question. Free text, clamped server-side. */
  name?: string;
  placement?: string;
  /** Percent for `depth`, milliseconds for `engage`. */
  value?: number;
  /** Milliseconds since the page loaded, which is what the timings are of. */
  t: number;
};

export type ViewContext = {
  device: Device;
  viewport: number;
  /** Host only, never the full referring URL. */
  referrer?: string;
  source?: string;
  medium?: string;
  campaign?: string;
  adgroup?: string;
  term?: string;
  /** Google's single-letter match type: e, p or b. See `tagging.ts`. */
  matchtype?: string;
  network?: string;
  content?: string;
  /** Present when Google Ads sent the click. This is what "paid" means here. */
  gclid?: string;
};

export type Payload = {
  v: 1;
  session: string;
  page: string;
  context?: ViewContext;
  events: ClientEvent[];
};

/** A batch bigger than this is a bug or a script, not a reader. */
export const MAX_EVENTS = 60;
/** Strings are identifiers, not prose. Anything longer is truncated. */
export const MAX_NAME = 120;
/** A session id the client made up. Shape-checked, never trusted for anything. */
export const SESSION_ID = /^[A-Za-z0-9_-]{8,64}$/;
