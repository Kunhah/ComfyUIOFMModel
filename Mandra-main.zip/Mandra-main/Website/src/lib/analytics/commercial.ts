import { getDb } from "@/lib/prospector/db";
import {
  CALL_OUTCOMES,
  FUNNEL_STAGES,
  OUTCOME_REACHED,
  type CallOutcome,
  type FunnelStage,
} from "@/lib/prospector/types";

/**
 * The commercial funnel, measured the same way the pages are.
 *
 * This reads `prospector.db`, not `analytics.db`, and that is the point rather
 * than an inconsistency: the two databases answer two halves of one question.
 * The page analytics end at "somebody tapped the phone number", which is the
 * last event a browser can witness — and the whole business happens after it.
 * A landing page converting at 9% into calls that nobody ever reaches is a
 * worse outcome than one converting at 4% into calls that close, and no screen
 * in this app could previously say so.
 *
 * Nothing here writes. It is a reporting view over tables the CRM owns, and
 * every query is scoped by a date window computed the same way the page
 * screens compute theirs, so "30 dias" means one thing across the section.
 */

export type CommercialScope = {
  /** Rolling window in days. 0 means everything ever recorded. */
  days: number;
};

type Bind = string | number;

/**
 * The window clause, against whichever column carries the row's date.
 *
 * Passed in rather than assumed because the tables disagree about the name:
 * a lead is dated by `first_seen_at`, a call by `occurred_at`, a search by
 * `searched_at`. A single hard-coded column here would silently return
 * everything for two of the three.
 */
function window(
  scope: CommercialScope,
  column: string,
): {
  sql: string;
  values: Bind[];
} {
  if (scope.days <= 0) return { sql: "", values: [] };
  return {
    sql: `WHERE ${column} >= datetime('now', ?)`,
    values: [`-${scope.days} days`],
  };
}

export type CommercialOverview = {
  /** Leads discovered by the prospector in the window. */
  found: number;
  /** Leads with at least one call logged in the window. */
  called: number;
  /** Leads where somebody actually spoke to a human. */
  reached: number;
  /** Leads that reached an interested or better stage. */
  interested: number;
  won: number;
  lost: number;
  /** Dials logged. Higher than `called`: a lead is often dialled twice. */
  dials: number;
  /** Searches run against the provider. */
  searches: number;
};

export function commercialOverview(scope: CommercialScope): CommercialOverview {
  const db = getDb();

  const reachedList = CALL_OUTCOMES.filter(
    (outcome) => OUTCOME_REACHED[outcome],
  )
    .map((outcome) => `'${outcome}'`)
    .join(",");

  const leads = window(scope, "first_seen_at");
  const found = (
    db
      .prepare(`SELECT count(*) AS n FROM leads ${leads.sql}`)
      .get(...leads.values) as { n: number }
  ).n;

  const calls = window(scope, "occurred_at");
  const dialled = db
    .prepare(
      `SELECT count(*) AS dials,
              count(DISTINCT lead_id) AS leads,
              count(DISTINCT CASE WHEN outcome IN (${reachedList})
                                  THEN lead_id END) AS reached,
              count(DISTINCT CASE WHEN outcome IN ('interessado', 'fechado')
                                  THEN lead_id END) AS interested,
              count(DISTINCT CASE WHEN outcome = 'fechado'
                                  THEN lead_id END) AS closed_on_call
         FROM lead_calls ${calls.sql}`,
    )
    .get(...calls.values) as Record<string, number>;

  // Won and lost are read from the lead's stage rather than from the call log:
  // most deals are not closed on the phone, and counting only `fechado` calls
  // would report a fraction of the wins as the whole.
  const stage = window(scope, "first_seen_at");
  const outcome = db
    .prepare(
      `SELECT coalesce(sum(CASE WHEN funnel_stage = 'fechado' THEN 1 ELSE 0 END), 0) AS won,
              coalesce(sum(CASE WHEN funnel_stage = 'perdido' THEN 1 ELSE 0 END), 0) AS lost
         FROM leads ${stage.sql}`,
    )
    .get(...stage.values) as Record<string, number>;

  const searches = window(scope, "searched_at");
  const searchCount = (
    db
      .prepare(`SELECT count(*) AS n FROM prospector_searches ${searches.sql}`)
      .get(...searches.values) as { n: number }
  ).n;

  return {
    found,
    called: dialled.leads,
    reached: dialled.reached,
    interested: dialled.interested,
    won: outcome.won,
    lost: outcome.lost,
    dials: dialled.dials,
    searches: searchCount,
  };
}

export type StageRow = { stage: FunnelStage; leads: number; share: number };

/**
 * Leads by funnel stage, right now.
 *
 * A standing snapshot rather than a window, deliberately: a lead found four
 * months ago and still in `negociacao` is part of today's pipeline, and
 * filtering it out by discovery date would describe a pipeline nobody has.
 */
export function byStage(): StageRow[] {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT funnel_stage AS stage, count(*) AS leads
         FROM leads GROUP BY funnel_stage`,
    )
    .all() as { stage: string; leads: number }[];

  const found = new Map(rows.map((row) => [row.stage, row.leads]));
  const total = rows.reduce((sum, row) => sum + row.leads, 0);

  return FUNNEL_STAGES.map((stage) => {
    const leads = found.get(stage) ?? 0;
    return { stage, leads, share: total ? (leads / total) * 100 : 0 };
  });
}

export type OutcomeRow = {
  outcome: CallOutcome;
  calls: number;
  share: number;
  reached: boolean;
};

/** What happens when you dial, over the window. */
export function callOutcomes(scope: CommercialScope): OutcomeRow[] {
  const db = getDb();
  const { sql, values } = window(scope, "occurred_at");

  const rows = db
    .prepare(
      `SELECT outcome, count(*) AS calls FROM lead_calls ${sql}
        GROUP BY outcome`,
    )
    .all(...values) as { outcome: string; calls: number }[];

  const found = new Map(rows.map((row) => [row.outcome, row.calls]));
  const total = rows.reduce((sum, row) => sum + row.calls, 0);

  return CALL_OUTCOMES.map((outcome) => ({
    outcome,
    calls: found.get(outcome) ?? 0,
    share: total ? ((found.get(outcome) ?? 0) / total) * 100 : 0,
    reached: OUTCOME_REACHED[outcome],
  }));
}

export type NicheRow = {
  niche: string;
  leads: number;
  called: number;
  reached: number;
  won: number;
};

/**
 * By niche, which is the decision this screen exists to inform.
 *
 * The prospector can search any trade in any city; the only thing that says
 * which trade is worth the next afternoon of calls is what the last afternoon
 * produced. A niche with ninety leads, sixty dials and no conversation is a
 * list that should stop being built.
 */
export function byNiche(scope: CommercialScope, limit = 25): NicheRow[] {
  const db = getDb();
  const reachedList = CALL_OUTCOMES.filter(
    (outcome) => OUTCOME_REACHED[outcome],
  )
    .map((outcome) => `'${outcome}'`)
    .join(",");

  const { sql, values } = window(scope, "l.first_seen_at");

  return db
    .prepare(
      `SELECT coalesce(nullif(l.niche, ''), '(sem nicho)') AS niche,
              count(DISTINCT l.id) AS leads,
              count(DISTINCT c.lead_id) AS called,
              count(DISTINCT CASE WHEN c.outcome IN (${reachedList})
                                  THEN c.lead_id END) AS reached,
              count(DISTINCT CASE WHEN l.funnel_stage = 'fechado'
                                  THEN l.id END) AS won
         FROM leads l
         LEFT JOIN lead_calls c ON c.lead_id = l.id
        ${sql}
        GROUP BY niche
        ORDER BY leads DESC
        LIMIT ${limit}`,
    )
    .all(...values) as NicheRow[];
}

export type DayRow = { day: string; leads: number; calls: number };

/** Leads found and calls made per day — the activity behind the pipeline. */
export function commercialDaily(scope: CommercialScope): DayRow[] {
  const db = getDb();
  const leads = window(scope, "first_seen_at");
  const calls = window(scope, "occurred_at");

  const foundRows = db
    .prepare(
      `SELECT date(first_seen_at) AS day, count(*) AS n FROM leads ${leads.sql}
        GROUP BY day`,
    )
    .all(...leads.values) as { day: string; n: number }[];

  const callRows = db
    .prepare(
      `SELECT date(occurred_at) AS day, count(*) AS n FROM lead_calls ${calls.sql}
        GROUP BY day`,
    )
    .all(...calls.values) as { day: string; n: number }[];

  const byDay = new Map<string, DayRow>();
  for (const row of foundRows) {
    byDay.set(row.day, { day: row.day, leads: row.n, calls: 0 });
  }
  for (const row of callRows) {
    const existing = byDay.get(row.day);
    if (existing) existing.calls = row.n;
    else byDay.set(row.day, { day: row.day, leads: 0, calls: row.n });
  }

  return Array.from(byDay.values()).sort((a, b) => a.day.localeCompare(b.day));
}

export type CommercialHealth = { ok: boolean; reason?: string };

/**
 * Can this process read the CRM's database?
 *
 * Same rule as the page analytics' `health()`, and for the same reason: a
 * pipeline screen full of zeroes because the volume is not mounted looks
 * exactly like a pipeline screen full of zeroes because nobody has called
 * anyone. Only one of those is worth waiting out.
 */
export function commercialHealth(): CommercialHealth {
  try {
    getDb().prepare("SELECT count(*) FROM leads").get();
    return { ok: true };
  } catch (error) {
    return {
      ok: false,
      reason: error instanceof Error ? error.message : String(error),
    };
  }
}
