import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { after, before, describe, it } from "node:test";
import type { ClientEvent, ViewContext } from "./events";

/**
 * The analytics rollups, exercised against a real database file.
 *
 * The queries themselves are the easy half. What breaks — and breaks silently,
 * which is the whole problem with an analytics screen — is the arithmetic:
 * a beacon that arrives twice double-counting a tap, a funnel step counting a
 * scroll-up as a second reader, a NULL keyword quietly dropping rows so the
 * table under the headline adds up to less than the headline. None of those
 * throw. They just make the number on the screen wrong, and a wrong number is
 * worse than no number because somebody will spend against it.
 *
 * ANALYTICS_DB has to be set before db.ts is imported — it reads it when the
 * connection is first opened — hence the dynamic import inside `before`.
 */

let db: typeof import("./db");
let dir: string;

let clock = 0;
/** Distinct, ordered timestamps so the day-window filter has something to cut. */
function at(offsetDays = 0): string {
  clock += 1000;
  return new Date(Date.now() - offsetDays * 86_400_000 + clock).toISOString();
}

function send(
  session: string,
  events: ClientEvent[],
  options: {
    page?: string;
    context?: Partial<ViewContext>;
    days?: number;
  } = {},
): void {
  db.record(
    {
      v: 1,
      session,
      page: options.page ?? "criacao-de-sites",
      context: options.context
        ? ({
            device: "celular",
            viewport: 390,
            ...options.context,
          } as ViewContext)
        : undefined,
      events,
    },
    at(options.days ?? 0),
  );
}

const view: ClientEvent = { type: "view", t: 0 };
const section = (name: string, t = 1000): ClientEvent => ({
  type: "section",
  name,
  t,
});
const cta = (
  name: string,
  t: number,
  placement = "primeira-tela",
): ClientEvent => ({
  type: "cta",
  name,
  placement,
  t,
});

before(async () => {
  dir = mkdtempSync(path.join(tmpdir(), "analytics-test-"));
  process.env.ANALYTICS_DB = path.join(dir, "analytics.db");
  db = await import("./db");
});

after(() => {
  rmSync(dir, { recursive: true, force: true });
});

const scope = { days: 0 };

describe("landing page analytics", () => {
  it("records a session and its context from the first batch", () => {
    send("s-context", [view], {
      context: { device: "celular", term: "criação de sites", gclid: "abc123" },
    });

    const row = db
      .getDb()
      .prepare("SELECT device, term, gclid, paid FROM sessions WHERE id = ?")
      .get("s-context") as Record<string, unknown>;

    assert.equal(row.device, "celular");
    assert.equal(row.term, "criação de sites");
    assert.equal(row.paid, 1, "a gclid is what 'paid' means here");
  });

  it("fills context forward when the first batch carried none", () => {
    send("s-late", [view]);
    send("s-late", [section("dores")], { context: { term: "oficina" } });

    const row = db
      .getDb()
      .prepare("SELECT term FROM sessions WHERE id = ?")
      .get("s-late") as { term: string | null };

    assert.equal(row.term, "oficina");
  });

  it("never lets a repeated batch inflate depth or time", () => {
    const depth: ClientEvent[] = [{ type: "depth", value: 80, t: 4000 }];
    const engage: ClientEvent[] = [{ type: "engage", value: 30_000, t: 4000 }];

    send("s-repeat", [view, ...depth, ...engage]);
    send("s-repeat", [...depth, ...engage]);
    // A later, smaller reading must not walk the rollup backwards either.
    send("s-repeat", [{ type: "depth", value: 10, t: 9000 }]);

    const row = db
      .getDb()
      .prepare("SELECT max_depth, engaged_ms FROM sessions WHERE id = ?")
      .get("s-repeat") as { max_depth: number; engaged_ms: number };

    assert.equal(row.max_depth, 80);
    assert.equal(row.engaged_ms, 30_000);
  });

  it("keeps the earliest tap as the time to first action", () => {
    send("s-first", [view, cta("call", 12_000)]);
    send("s-first", [cta("whatsapp", 40_000)]);

    const row = db
      .getDb()
      .prepare(
        "SELECT first_action_ms, call_clicks, whatsapp_clicks FROM sessions WHERE id = ?",
      )
      .get("s-first") as Record<string, number>;

    assert.equal(row.first_action_ms, 12_000);
    assert.equal(row.call_clicks, 1);
    assert.equal(row.whatsapp_clicks, 1);
  });

  it("counts a session once per funnel step, however often it scrolls back", () => {
    send("s-scroll", [
      view,
      section("hero"),
      section("dores"),
      // The tracker dedupes, but a duplicate must not survive a retry either.
      section("dores", 9000),
    ]);

    const steps = db.funnel({ days: 0, page: "criacao-de-sites" });
    const dores = steps.find((step) => step.section === "dores");

    assert.ok(dores);
    assert.equal(
      dores.sessions,
      2,
      "s-late and s-scroll reached it; s-scroll counts once",
    );
  });

  it("treats a WhatsApp tap as a conversion, not only a call", () => {
    send("s-wa", [view, cta("whatsapp", 5000, "barra-fixa")]);

    const stats = db.overview({ days: 0, page: "criacao-de-sites" });
    assert.ok(stats.converted >= 1);
    assert.ok(stats.whatsappClicks >= 1);
  });

  it("counts a session that saw nothing past the fold as a bounce", () => {
    send("s-bounce", [view], { page: "sites-energia-solar" });

    const stats = db.overview({ days: 0, page: "sites-energia-solar" });
    assert.equal(stats.sessions, 1);
    assert.equal(stats.bounced, 1);
    assert.equal(stats.readAllNoCall, 0);
  });

  it("separates 'read everything and left' from a bounce", () => {
    send("s-read", [view, section("fechamento")], {
      page: "sites-oficina-mecanica",
    });
    send("s-read-call", [view, section("fechamento"), cta("call", 20_000)], {
      page: "sites-oficina-mecanica",
    });

    const stats = db.overview({ days: 0, page: "sites-oficina-mecanica" });
    assert.equal(stats.sessions, 2);
    assert.equal(stats.bounced, 0);
    assert.equal(
      stats.readAllNoCall,
      1,
      "the one that reached the end without tapping anything",
    );
  });

  it("labels a missing keyword instead of dropping the row", () => {
    // Otherwise the breakdown silently adds up to less than the headline, which
    // is the exact failure that makes people stop trusting the screen.
    const rows = db.byTerm({ days: 0 });
    const total = rows.reduce((sum, row) => sum + row.sessions, 0);
    const all = db.overview({ days: 0 }).sessions;

    assert.equal(total, all);
    assert.ok(rows.some((row) => row.label === "(sem termo)"));
  });

  it("honours the rolling window", () => {
    send("s-old", [view, cta("call", 1000)], {
      page: "automacao-whatsapp",
      days: 120,
    });

    const recent = db.overview({ days: 30, page: "automacao-whatsapp" });
    const ever = db.overview({ days: 0, page: "automacao-whatsapp" });

    assert.equal(recent.sessions, 0);
    assert.equal(ever.sessions, 1);
  });

  it("reports paid sessions that arrived with no keyword", () => {
    // This is the "is the account tagged" probe. An untagged account produces
    // a dashboard that looks healthy and cannot answer the one question worth
    // asking of it, so the screen has to be able to say so.
    send("s-untagged", [view], {
      page: "sites-arquitetura",
      context: { gclid: "Cj0KC" },
    });
    send("s-tagged", [view], {
      page: "sites-arquitetura",
      context: { gclid: "Cj0KD", term: "site para arquiteto", matchtype: "e" },
    });
    // Organic traffic has no keyword either and must not be counted as a gap.
    send("s-organic", [view], { page: "sites-arquitetura" });

    assert.equal(db.untaggedPaid({ days: 0, page: "sites-arquitetura" }), 1);
  });

  it("keeps the match type so broad spend is visible", () => {
    const rows = db.byMatchType({ days: 0, page: "sites-arquitetura" });
    const exact = rows.find((row) => row.label === "e");

    assert.ok(exact, "o tipo de correspondência precisa chegar ao painel");
    assert.equal(exact.sessions, 1);
  });

  it("attributes taps to the placement that produced them", () => {
    const rows = db.byPlacement(scope);
    const bar = rows.find((row) => row.placement === "barra-fixa");

    assert.ok(bar, "the sticky bar has to be distinguishable from the hero");
    assert.equal(bar.whatsapp, 1);
  });
});
