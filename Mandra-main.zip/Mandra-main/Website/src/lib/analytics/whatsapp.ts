import { waDb } from "@/lib/whatsapp/db";

/**
 * What the WhatsApp agent is actually doing, in numbers.
 *
 * `/admin/whatsapp` shows the connection, the queue and the individual
 * threads — it answers "is it running" and "what did it say to this person".
 * Neither of those is "is it working", and the difference is a screen: an
 * agent that replies to everything within four seconds and never produces an
 * appointment is a very responsive dead end, and the thread view makes that
 * invisible one conversation at a time.
 *
 * Read-only, over `wa_*` in the CRM's database. The reply-time figure is a
 * median for the same reason every duration on the page screens is: one
 * conversation that sat overnight because the provider was down moves a mean
 * by hours and a median not at all.
 */

export type WhatsappScope = { days: number };

type Bind = string | number;

function window(
  scope: WhatsappScope,
  column: string,
): {
  sql: string;
  values: Bind[];
} {
  if (scope.days <= 0) return { sql: "", values: [] };
  return {
    sql: `WHERE ${column} >= datetime('now', ?)`,
    values: [`-${scope.days} days`],
  };
}

export type WhatsappOverview = {
  conversations: number;
  /** Conversations that received at least one inbound message in the window. */
  active: number;
  inbound: number;
  outbound: number;
  /** Replies the model produced, as opposed to an operator or a job. */
  fromAgent: number;
  fromOperator: number;
  fromJob: number;
  /** Outbound rows the provider refused. Silent failure is the risk here. */
  failed: number;
  /** Conversations an operator took over, so the agent stopped answering. */
  handedOff: number;
  appointments: number;
  /** Appointments that were confirmed or completed rather than left pending. */
  appointmentsKept: number;
  activeJobs: number;
};

export function whatsappOverview(scope: WhatsappScope): WhatsappOverview {
  const db = waDb();

  const messages = window(scope, "created_at");
  const counts = db
    .prepare(
      `SELECT coalesce(sum(CASE WHEN direction = 'in' THEN 1 ELSE 0 END), 0) AS inbound,
              coalesce(sum(CASE WHEN direction = 'out' THEN 1 ELSE 0 END), 0) AS outbound,
              coalesce(sum(CASE WHEN origin = 'agent' THEN 1 ELSE 0 END), 0) AS from_agent,
              coalesce(sum(CASE WHEN origin = 'operator' THEN 1 ELSE 0 END), 0) AS from_operator,
              coalesce(sum(CASE WHEN origin = 'job' THEN 1 ELSE 0 END), 0) AS from_job,
              coalesce(sum(CASE WHEN status = 'failed' THEN 1 ELSE 0 END), 0) AS failed,
              count(DISTINCT CASE WHEN direction = 'in' THEN conversation_id END) AS active
         FROM wa_messages ${messages.sql}`,
    )
    .get(...messages.values) as Record<string, number>;

  const created = window(scope, "created_at");
  const conversations = (
    db
      .prepare(`SELECT count(*) AS n FROM wa_conversations ${created.sql}`)
      .get(...created.values) as { n: number }
  ).n;

  // A snapshot, not a window: what matters is how many threads a human is
  // currently holding, not how many were taken over last month.
  const handedOff = (
    db
      .prepare(
        "SELECT count(*) AS n FROM wa_conversations WHERE auto_reply = 0",
      )
      .get() as { n: number }
  ).n;

  const appts = window(scope, "created_at");
  const appointments = db
    .prepare(
      `SELECT count(*) AS total,
              coalesce(sum(CASE WHEN status IN ('confirmado','concluido') THEN 1 ELSE 0 END), 0) AS kept
         FROM wa_appointments ${appts.sql}`,
    )
    .get(...appts.values) as Record<string, number>;

  const activeJobs = (
    db.prepare("SELECT count(*) AS n FROM wa_jobs WHERE active = 1").get() as {
      n: number;
    }
  ).n;

  return {
    conversations,
    active: counts.active,
    inbound: counts.inbound,
    outbound: counts.outbound,
    fromAgent: counts.from_agent,
    fromOperator: counts.from_operator,
    fromJob: counts.from_job,
    failed: counts.failed,
    handedOff,
    appointments: appointments.total,
    appointmentsKept: appointments.kept,
    activeJobs,
  };
}

export type ReplyTime = {
  /** Median seconds from a client's message to the next outbound one. */
  medianSeconds: number | null;
  /** How many inbound messages got any reply at all, and how many did not. */
  answered: number;
  unanswered: number;
};

/**
 * How long a client waits, and how often nobody answers at all.
 *
 * `unanswered` is the number this exists for. A median reply time looks
 * excellent when the only messages that got timed are the ones that were
 * answered, and a thread the agent silently dropped contributes nothing to it
 * — the failure is invisible in exactly the statistic meant to catch it.
 *
 * Pairing is done in TypeScript over one ordered scan rather than with a
 * correlated subquery per message: the table is a transcript, and the
 * per-row subquery form of this question is the shape that stops returning
 * before anyone notices it has become slow.
 */
export function replyTime(scope: WhatsappScope): ReplyTime {
  const db = waDb();
  const { sql, values } = window(scope, "created_at");

  const rows = db
    .prepare(
      `SELECT conversation_id, direction, created_at
         FROM wa_messages ${sql}
        ORDER BY conversation_id, created_at`,
    )
    .all(...values) as {
    conversation_id: string;
    direction: string;
    created_at: string;
  }[];

  const gaps: number[] = [];
  let answered = 0;
  let unanswered = 0;

  let conversation = "";
  let pendingAt: number | null = null;

  const close = () => {
    // A question left open when the transcript ends is unanswered, which is
    // the whole point of tracking it.
    if (pendingAt !== null) unanswered += 1;
    pendingAt = null;
  };

  for (const row of rows) {
    if (row.conversation_id !== conversation) {
      close();
      conversation = row.conversation_id;
    }

    const at = Date.parse(row.created_at);
    if (Number.isNaN(at)) continue;

    if (row.direction === "in") {
      // Consecutive client messages are one question, timed from the first:
      // somebody who sends three lines in a row has been waiting since line one.
      if (pendingAt === null) pendingAt = at;
    } else if (pendingAt !== null) {
      gaps.push(Math.max(0, Math.round((at - pendingAt) / 1000)));
      answered += 1;
      pendingAt = null;
    }
  }
  close();

  gaps.sort((a, b) => a - b);
  return {
    medianSeconds: gaps.length
      ? (gaps[Math.floor(gaps.length / 2)] ?? null)
      : null,
    answered,
    unanswered,
  };
}

export type WaDayRow = { day: string; inbound: number; outbound: number };

export function whatsappDaily(scope: WhatsappScope): WaDayRow[] {
  const db = waDb();
  const { sql, values } = window(scope, "created_at");

  return db
    .prepare(
      `SELECT date(created_at) AS day,
              coalesce(sum(CASE WHEN direction = 'in' THEN 1 ELSE 0 END), 0) AS inbound,
              coalesce(sum(CASE WHEN direction = 'out' THEN 1 ELSE 0 END), 0) AS outbound
         FROM wa_messages ${sql}
        GROUP BY day
        ORDER BY day`,
    )
    .all(...values) as WaDayRow[];
}

export type HourRow = { hour: number; messages: number };

/**
 * When clients write.
 *
 * The agent answers at every hour, which is most of the point of having one —
 * but it also says when a human should be reachable for the threads the agent
 * hands over, and whether the reminders are firing into the middle of the
 * night.
 */
export function inboundByHour(scope: WhatsappScope): HourRow[] {
  const db = waDb();
  const { sql, values } = window(scope, "created_at");
  const where = sql ? `${sql} AND direction = 'in'` : "WHERE direction = 'in'";

  const rows = db
    .prepare(
      `SELECT cast(strftime('%H', created_at, 'localtime') AS INTEGER) AS hour,
              count(*) AS messages
         FROM wa_messages ${where}
        GROUP BY hour`,
    )
    .all(...values) as HourRow[];

  const found = new Map(rows.map((row) => [row.hour, row.messages]));
  return Array.from({ length: 24 }, (_, hour) => ({
    hour,
    messages: found.get(hour) ?? 0,
  }));
}

export type WhatsappHealth = { ok: boolean; reason?: string };

export function whatsappHealth(): WhatsappHealth {
  try {
    waDb().prepare("SELECT count(*) FROM wa_conversations").get();
    return { ok: true };
  } catch (error) {
    return {
      ok: false,
      reason: error instanceof Error ? error.message : String(error),
    };
  }
}
