import { mkdirSync } from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { type Payload, type Section } from "./events";
import { funnelFor, slugsOf, type Template } from "./pages";

/**
 * Landing-page analytics, in its own SQLite file.
 *
 * `data/analytics.db`, not extra tables in `prospector.db`, for the same
 * reason `b2b.db` is separate: unrelated schemas, unrelated lifecycles, and a
 * write pattern that has nothing in common with the CRM's. This table is
 * append-heavy and completely disposable — every row can be thrown away and
 * the only loss is history, whereas losing a row of `leads` loses a customer.
 * Bolting it onto the CRM's file would also put a per-pageview write in the
 * same WAL as the pipeline the business runs on.
 *
 * Why first-party at all, with Google Analytics sitting right there: GA
 * answers "how many" and is very bad at "why fewer". The question this exists
 * for is *where on the page people stop*, which needs a per-section funnel
 * over sessions we can join to the ad that paid for them — and once you are
 * defining custom events and a custom funnel in GA anyway, the data may as
 * well be in a file we own, queryable in SQL, with no sampling and no consent
 * banner. The Google tag stays for the thing only Google can do, which is bid.
 *
 * Nothing here is personal data. No IP is stored, no cookie is set, the
 * session id dies with the browser tab and the referrer is reduced to a host.
 */

const SCHEMA = `
  CREATE TABLE IF NOT EXISTS sessions (
    -- Generated in the browser and shape-checked on arrival. It identifies one
    -- tab's visit and nothing else: it is not stable across tabs, across
    -- visits or across sites, which is exactly the property that keeps this
    -- file out of the LGPD's way.
    id              TEXT PRIMARY KEY,
    page            TEXT NOT NULL,
    started_at      TEXT NOT NULL,
    last_at         TEXT NOT NULL,
    device          TEXT,
    viewport        INTEGER,
    -- Host only. The full referring URL is somebody else's page and can carry
    -- their query string, which is not ours to keep.
    referrer        TEXT,
    source          TEXT,
    medium          TEXT,
    campaign        TEXT,
    -- utm_term is where Google writes the matched keyword, which is the single
    -- most useful column in this table: it is what turns "the page converts at
    -- 8%" into "this keyword converts at 0%".
    term            TEXT,
    -- The ad group and the match type, both from the same one-line account
    -- suffix as the keyword above. Match type is the column that shows broad
    -- match spending the budget on searches nobody chose.
    -- (No backticks in here: one would end the template literal, and the parse
    -- error points at the SQL rather than at the quote.)
    adgroup         TEXT,
    matchtype       TEXT,
    network         TEXT,
    content         TEXT,
    gclid           TEXT,
    paid            INTEGER NOT NULL DEFAULT 0,
    -- Rollups, kept on the session so the dashboard is one scan of this table
    -- rather than a group-by over every event ever recorded.
    max_depth       INTEGER NOT NULL DEFAULT 0,
    engaged_ms      INTEGER NOT NULL DEFAULT 0,
    call_clicks     INTEGER NOT NULL DEFAULT 0,
    whatsapp_clicks INTEGER NOT NULL DEFAULT 0,
    -- Milliseconds from page load to the first tap on a phone or WhatsApp
    -- action. NULL means it never happened, which is most sessions.
    first_action_ms INTEGER,
    -- Index into *this page's* funnel of the furthest section actually seen.
    -- The funnel is derived from the section events; this is here so "did they
    -- get past the fold" is a cheap predicate.
    deepest         INTEGER NOT NULL DEFAULT 0,
    -- Did the session reach the last band of its own funnel?
    --
    -- Stored rather than compared against a length, because the lengths now
    -- differ: the landing pages have six bands and the home page eight. Asking
    -- deepest >= 5 across a mixed scope quietly reclassifies every home-page
    -- reader who stopped at the sixth band as having read everything, which is
    -- the kind of wrong that looks completely plausible on a dashboard.
    reached_end     INTEGER NOT NULL DEFAULT 0,
    -- Where the reader was standing when they left, which is not the same
    -- question as how far they got. See the exit event.
    exit_section    TEXT,
    -- Clicks on things that do nothing, and bursts of clicks in one spot.
    -- These are the counters that say what to *fix*, as opposed to what to
    -- rewrite: a dead click is a reader asking for something the page does not
    -- offer, in the one moment they were willing to act.
    dead_clicks     INTEGER NOT NULL DEFAULT 0,
    rage_clicks     INTEGER NOT NULL DEFAULT 0,
    -- Milliseconds to the first scroll. A hero that is read takes a couple of
    -- seconds; one that is skipped is scrolled past in a few hundred
    -- milliseconds, and the two are indistinguishable by any other column.
    first_scroll_ms INTEGER
  );

  CREATE TABLE IF NOT EXISTS events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id  TEXT NOT NULL,
    page        TEXT NOT NULL,
    type        TEXT NOT NULL,
    name        TEXT,
    placement   TEXT,
    value       INTEGER,
    -- Milliseconds since the page loaded. This is the browser's clock and the
    -- only thing it is used for is durations within one visit.
    t           INTEGER NOT NULL,
    -- Server receipt time. The client's wall clock is not to be trusted for
    -- anything that ends up on an axis.
    at          TEXT NOT NULL
  );
`;

const INDEXES = `
  CREATE INDEX IF NOT EXISTS idx_sessions_page ON sessions(page, started_at);
  CREATE INDEX IF NOT EXISTS idx_sessions_started ON sessions(started_at);
  CREATE INDEX IF NOT EXISTS idx_events_session ON events(session_id);
  CREATE INDEX IF NOT EXISTS idx_events_page_type ON events(page, type, at);
`;

function databasePath(): string {
  return (
    process.env.ANALYTICS_DB ?? path.join(process.cwd(), "data", "analytics.db")
  );
}

let db: DatabaseSync | null = null;

export function getDb(): DatabaseSync {
  if (db) return db;

  const file = databasePath();
  mkdirSync(path.dirname(file), { recursive: true });
  const handle = new DatabaseSync(file);
  handle.exec("PRAGMA journal_mode = WAL");
  handle.exec("PRAGMA synchronous = NORMAL");
  handle.exec(SCHEMA);
  addMissingColumns(handle);
  handle.exec(INDEXES);

  db = handle;
  return db;
}

/**
 * Additive schema catch-up, same mechanism and same rule as the prospector's.
 *
 * `CREATE TABLE IF NOT EXISTS` does nothing to a table that already exists, so
 * a column added to SCHEMA leaves existing files behind — and because the
 * column is in the INSERT list, *every* write then fails with "no such
 * column". This database is disposable, but a collector that silently stops
 * recording the day a column is added is the failure mode this whole layer is
 * written to avoid. Additive only: renames and type changes mean deleting the
 * file, which here costs nothing but history.
 */
function addMissingColumns(handle: DatabaseSync): void {
  const present = new Set(
    (
      handle.prepare("PRAGMA table_info(sessions)").all() as { name: string }[]
    ).map((column) => column.name),
  );

  const expected: Record<string, string> = {
    adgroup: "TEXT",
    matchtype: "TEXT",
    network: "TEXT",
    // SQLite will not add a NOT NULL column without a default, and these two
    // carry one for the same reason the schema does: an existing row predates
    // the signal and 0 is the honest value for "we were not measuring this".
    reached_end: "INTEGER NOT NULL DEFAULT 0",
    exit_section: "TEXT",
    dead_clicks: "INTEGER NOT NULL DEFAULT 0",
    rage_clicks: "INTEGER NOT NULL DEFAULT 0",
    first_scroll_ms: "INTEGER",
  };

  for (const [name, type] of Object.entries(expected)) {
    if (!present.has(name)) {
      handle.exec(`ALTER TABLE sessions ADD COLUMN ${name} ${type}`);
    }
  }
}

/* --------------------------------------------------------------------------
   Writing
   -------------------------------------------------------------------------- */

/**
 * A section's position in its own page's funnel, and whether it is the last.
 *
 * Resolved per page rather than from one global list. The landing pages have
 * six bands and the home page eight, and scoring one against the other's list
 * produces a reader who saw everything filed at index 0.
 */
function positionIn(
  page: string,
  section: string,
): { index: number; last: boolean } | undefined {
  const funnel = funnelFor(page);
  const index = funnel.indexOf(section as Section);
  if (index < 0) return undefined;
  return { index, last: index === funnel.length - 1 };
}

/**
 * Record one batch.
 *
 * The whole batch is one transaction, so a page that flushes six events on
 * unload either lands completely or not at all — a half-written session is a
 * funnel step that silently under-reports.
 *
 * The session row is upserted rather than inserted: the first batch creates it
 * with the context, and every later batch only moves the rollups forward.
 * `max()` on each of them is what makes a retried or duplicated beacon
 * harmless, which matters because `sendBeacon` offers no delivery guarantee in
 * either direction.
 */
export function record(payload: Payload, at: string): void {
  const handle = getDb();
  const context = payload.context;

  handle.exec("BEGIN");
  try {
    handle
      .prepare(
        `INSERT INTO sessions (
           id, page, started_at, last_at, device, viewport, referrer,
           source, medium, campaign, adgroup, term, matchtype, network,
           content, gclid, paid
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET
           last_at  = excluded.last_at,
           -- Context rides on the first batch only, but that batch is the one
           -- most likely to be lost (a reader who leaves in four seconds). Each
           -- column is filled by whichever batch first carried it and never
           -- overwritten, so a late context is better than none and a repeated
           -- one changes nothing.
           device   = coalesce(sessions.device, excluded.device),
           viewport = coalesce(sessions.viewport, excluded.viewport),
           referrer = coalesce(sessions.referrer, excluded.referrer),
           source   = coalesce(sessions.source, excluded.source),
           medium   = coalesce(sessions.medium, excluded.medium),
           campaign = coalesce(sessions.campaign, excluded.campaign),
           adgroup  = coalesce(sessions.adgroup, excluded.adgroup),
           term     = coalesce(sessions.term, excluded.term),
           matchtype = coalesce(sessions.matchtype, excluded.matchtype),
           network  = coalesce(sessions.network, excluded.network),
           content  = coalesce(sessions.content, excluded.content),
           gclid    = coalesce(sessions.gclid, excluded.gclid),
           paid     = max(sessions.paid, excluded.paid)`,
      )
      .run(
        payload.session,
        payload.page,
        at,
        at,
        context?.device ?? null,
        context?.viewport ?? null,
        context?.referrer ?? null,
        context?.source ?? null,
        context?.medium ?? null,
        context?.campaign ?? null,
        context?.adgroup ?? null,
        context?.term ?? null,
        context?.matchtype ?? null,
        context?.network ?? null,
        context?.content ?? null,
        context?.gclid ?? null,
        context?.gclid ? 1 : 0,
      );

    const insert = handle.prepare(
      `INSERT INTO events (session_id, page, type, name, placement, value, t, at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    );

    for (const event of payload.events) {
      insert.run(
        payload.session,
        payload.page,
        event.type,
        event.name ?? null,
        event.placement ?? null,
        event.value ?? null,
        event.t,
        at,
      );

      if (event.type === "depth" && typeof event.value === "number") {
        handle
          .prepare(
            "UPDATE sessions SET max_depth = max(max_depth, ?) WHERE id = ?",
          )
          .run(event.value, payload.session);
      }

      if (event.type === "engage" && typeof event.value === "number") {
        handle
          .prepare(
            "UPDATE sessions SET engaged_ms = max(engaged_ms, ?) WHERE id = ?",
          )
          .run(event.value, payload.session);
      }

      if (event.type === "section") {
        const at = positionIn(payload.page, event.name ?? "");
        if (at) {
          handle
            .prepare(
              `UPDATE sessions
                  SET deepest     = max(deepest, ?),
                      reached_end = max(reached_end, ?)
                WHERE id = ?`,
            )
            .run(at.index, at.last ? 1 : 0, payload.session);
        }
      }

      // Where they were standing when they left. Last one wins rather than
      // max(): a reader who scrolls back up to the price and leaves there has
      // exited at the price, and that is the whole point of the signal.
      if (event.type === "exit" && event.name) {
        handle
          .prepare("UPDATE sessions SET exit_section = ? WHERE id = ?")
          .run(event.name, payload.session);
      }

      // Counted, not max()'d, for the same reason the CTA counters are: a
      // second dead click is a second dead click. A duplicated beacon can
      // therefore double-count these — which is the right trade here, since
      // these are read as "does this happen at all, and where", never as a
      // rate that has to be exact.
      if (event.type === "dead" || event.type === "rage") {
        const column = event.type === "dead" ? "dead_clicks" : "rage_clicks";
        handle
          .prepare(`UPDATE sessions SET ${column} = ${column} + ? WHERE id = ?`)
          .run(event.type === "rage" ? (event.value ?? 1) : 1, payload.session);
      }

      if (event.type === "firstscroll" && typeof event.value === "number") {
        handle
          .prepare(
            `UPDATE sessions
                SET first_scroll_ms = min(coalesce(first_scroll_ms, ?), ?)
              WHERE id = ?`,
          )
          .run(event.value, event.value, payload.session);
      }

      if (event.type === "cta") {
        const column =
          event.name === "whatsapp" ? "whatsapp_clicks" : "call_clicks";
        handle
          .prepare(
            `UPDATE sessions
                SET ${column} = ${column} + 1,
                    first_action_ms = min(coalesce(first_action_ms, ?), ?)
              WHERE id = ?`,
          )
          .run(event.t, event.t, payload.session);
      }
    }

    handle.exec("COMMIT");
  } catch (error) {
    handle.exec("ROLLBACK");
    throw error;
  }
}

/* --------------------------------------------------------------------------
   Reading
   -------------------------------------------------------------------------- */

export type Scope = {
  /** One measured page's slug, or undefined for every page in the template. */
  page?: string;
  /**
   * Restrict to one template's pages — the ad landing pages, or the site's own.
   *
   * Every screen that shows a funnel must set this, because a funnel over a
   * mixed scope is a chart of two different page structures added together.
   * The filter is by slug rather than by a column: the template is a property
   * of the page as we publish it today, not of the visit that happened, so
   * storing it on the row would freeze a past answer to a question the
   * registry already answers.
   */
  template?: Template;
  /** Rolling window in days. 0 means everything ever recorded. */
  days: number;
  /** Only sessions Google Ads paid for. */
  paidOnly?: boolean;
};

/**
 * The WHERE clause every query on this screen shares.
 *
 * One builder, like the CRM's `where()`, because a second hand-written
 * predicate is how the funnel starts describing a different set of sessions
 * than the headline number above it.
 */
type Bind = string | number;

function scopeSql(scope: Scope, alias = "s"): { sql: string; values: Bind[] } {
  const clauses: string[] = [];
  const values: Bind[] = [];

  if (scope.days > 0) {
    clauses.push(`${alias}.started_at >= datetime('now', ?)`);
    values.push(`-${scope.days} days`);
  }
  if (scope.page) {
    clauses.push(`${alias}.page = ?`);
    values.push(scope.page);
  } else if (scope.template) {
    const slugs = slugsOf(scope.template);
    // An empty template would produce `IN ()`, which is a syntax error rather
    // than an empty result. There is no such template today; there will be the
    // first time someone adds one to the registry before adding its pages.
    clauses.push(
      slugs.length
        ? `${alias}.page IN (${slugs.map(() => "?").join(", ")})`
        : "0 = 1",
    );
    values.push(...slugs);
  }
  if (scope.paidOnly) clauses.push(`${alias}.paid = 1`);

  return {
    sql: clauses.length ? `WHERE ${clauses.join(" AND ")}` : "",
    values,
  };
}

export type Overview = {
  sessions: number;
  paid: number;
  converted: number;
  callClicks: number;
  whatsappClicks: number;
  /** Sessions that never saw anything past the first screen. */
  bounced: number;
  /** Reached the closing band and still did not tap anything. */
  readAllNoCall: number;
  /** Sessions containing at least one click on something that does nothing. */
  withDeadClicks: number;
  /** Sessions containing a burst of clicks in one spot. */
  withRageClicks: number;
  /** Median milliseconds from load to the first tap, over converting sessions. */
  medianFirstActionMs: number | null;
  medianEngagedMs: number | null;
  medianDepth: number | null;
  /** Median milliseconds to the first scroll. How fast the hero is skipped. */
  medianFirstScrollMs: number | null;
};

export function overview(scope: Scope): Overview {
  const handle = getDb();
  const { sql, values } = scopeSql(scope);

  const row = handle
    .prepare(
      `SELECT count(*) AS sessions,
              coalesce(sum(paid), 0) AS paid,
              coalesce(sum(CASE WHEN call_clicks + whatsapp_clicks > 0 THEN 1 ELSE 0 END), 0) AS converted,
              coalesce(sum(call_clicks), 0) AS call_clicks,
              coalesce(sum(whatsapp_clicks), 0) AS whatsapp_clicks,
              coalesce(sum(CASE WHEN deepest = 0 THEN 1 ELSE 0 END), 0) AS bounced,
              -- reached_end, not a comparison against a length: the funnels are no
              -- longer all the same length, and the comparison would count
              -- every home-page reader who stopped two bands early as having
              -- read the whole thing.
              coalesce(sum(CASE WHEN reached_end = 1 AND call_clicks + whatsapp_clicks = 0 THEN 1 ELSE 0 END), 0) AS read_all_no_call,
              coalesce(sum(CASE WHEN dead_clicks > 0 THEN 1 ELSE 0 END), 0) AS with_dead,
              coalesce(sum(CASE WHEN rage_clicks > 0 THEN 1 ELSE 0 END), 0) AS with_rage
         FROM sessions s ${sql}`,
    )
    .get(...values) as Record<string, number>;

  return {
    sessions: row.sessions,
    paid: row.paid,
    converted: row.converted,
    callClicks: row.call_clicks,
    whatsappClicks: row.whatsapp_clicks,
    bounced: row.bounced,
    readAllNoCall: row.read_all_no_call,
    withDeadClicks: row.with_dead,
    withRageClicks: row.with_rage,
    medianFirstScrollMs: median(
      scope,
      "first_scroll_ms",
      "first_scroll_ms IS NOT NULL",
    ),
    medianFirstActionMs: median(
      scope,
      "first_action_ms",
      "first_action_ms IS NOT NULL",
    ),
    medianEngagedMs: median(scope, "engaged_ms", "engaged_ms > 0"),
    medianDepth: median(scope, "max_depth", "max_depth > 0"),
  };
}

/**
 * The median, in SQL.
 *
 * An average is the wrong statistic for every column on this screen: one
 * person who left the tab open over lunch moves the mean time-on-page by
 * minutes and the median not at all.
 */
function median(scope: Scope, column: string, extra: string): number | null {
  const handle = getDb();
  const { sql, values } = scopeSql(scope);
  const where = sql ? `${sql} AND ${extra}` : `WHERE ${extra}`;

  const row = handle
    .prepare(
      `SELECT ${column} AS value FROM sessions s ${where}
        ORDER BY ${column}
        LIMIT 1
       OFFSET (SELECT count(*) FROM sessions s ${where}) / 2`,
    )
    .get(...values, ...values) as { value: number } | undefined;

  return row?.value ?? null;
}

export type FunnelStep = {
  section: Section;
  sessions: number;
  /** Share of all sessions in scope that got this far. */
  share: number;
  /** Percentage points lost between the previous step and this one. */
  drop: number;
};

/**
 * The per-section funnel — the reason this whole layer exists.
 *
 * "Conversion is down" is not actionable; "two thirds of the people who read
 * the deliverables never reach the closing band" is. Counted over distinct
 * sessions that fired the section event, so a reader who scrolls up and back
 * down is one person, not three.
 *
 * The steps come from the scope's own funnel — the page's when one page is
 * selected, the template's otherwise. A scope that pins down neither has no
 * single page structure to draw, and returns nothing rather than a chart
 * adding two different pages' bands together.
 */
export function funnel(scope: Scope): FunnelStep[] {
  const steps = scopeFunnel(scope);
  if (steps.length === 0) return [];
  return funnelOver(scope, steps);
}

/**
 * Which funnel a scope describes, if it describes one at all.
 *
 * A page filter names it outright. A template filter names it because every
 * page of a template shares a funnel — that is what makes it a template. With
 * neither, there is no honest answer, and an empty list is the honest one.
 */
function scopeFunnel(scope: Scope): readonly Section[] {
  if (scope.page) return funnelFor(scope.page);
  if (scope.template) {
    const first = slugsOf(scope.template)[0];
    return first ? funnelFor(first) : [];
  }
  return [];
}

function funnelOver(scope: Scope, sections: readonly Section[]): FunnelStep[] {
  const handle = getDb();
  const { sql, values } = scopeSql(scope);

  const total = (
    handle
      .prepare(`SELECT count(*) AS n FROM sessions s ${sql}`)
      .get(...values) as { n: number }
  ).n;

  const rows = handle
    .prepare(
      `SELECT e.name AS section, count(DISTINCT e.session_id) AS n
         FROM events e
         JOIN sessions s ON s.id = e.session_id
        ${sql ? `${sql} AND` : "WHERE"} e.type = 'section'
        GROUP BY e.name`,
    )
    .all(...values) as { section: string; n: number }[];

  const counts = new Map(rows.map((row) => [row.section, row.n]));

  let previous = total;
  return sections.map((section) => {
    const sessions = counts.get(section) ?? 0;
    const step: FunnelStep = {
      section,
      sessions,
      share: total ? (sessions / total) * 100 : 0,
      drop: previous ? ((previous - sessions) / (total || 1)) * 100 : 0,
    };
    previous = sessions;
    return step;
  });
}

export type Breakdown = {
  label: string;
  sessions: number;
  converted: number;
  rate: number;
};

function breakdown(
  scope: Scope,
  column: string,
  fallback: string,
): Breakdown[] {
  const handle = getDb();
  const { sql, values } = scopeSql(scope);

  const rows = handle
    .prepare(
      `SELECT coalesce(nullif(${column}, ''), ?) AS label,
              count(*) AS sessions,
              coalesce(sum(CASE WHEN call_clicks + whatsapp_clicks > 0 THEN 1 ELSE 0 END), 0) AS converted
         FROM sessions s ${sql}
        GROUP BY label
        ORDER BY sessions DESC
        LIMIT 30`,
    )
    .all(fallback, ...values) as {
    label: string;
    sessions: number;
    converted: number;
  }[];

  return rows.map((row) => ({
    ...row,
    rate: row.sessions ? (row.converted / row.sessions) * 100 : 0,
  }));
}

export const byDevice = (scope: Scope) =>
  breakdown(scope, "device", "desconhecido");

/** The matched keyword, which is where a campaign's money actually goes. */
export const byTerm = (scope: Scope) => breakdown(scope, "term", "(sem termo)");

export const byCampaign = (scope: Scope) =>
  breakdown(scope, "campaign", "(sem campanha)");

export const bySource = (scope: Scope) =>
  breakdown(scope, "source", "direto / orgânico");

export const byPage = (scope: Scope) => breakdown(scope, "page", "—");

export const byAdGroup = (scope: Scope) =>
  breakdown(scope, "adgroup", "(sem grupo)");

/** Exact, phrase or broad. Where broad match spends without being chosen. */
export const byMatchType = (scope: Scope) =>
  breakdown(scope, "matchtype", "(sem tipo)");

/**
 * How many paid sessions arrived with no keyword on the URL.
 *
 * This is the "is the account tagged" question, and it is asked rather than
 * assumed because an untagged account produces a dashboard that looks healthy
 * and cannot answer the one question worth asking of it.
 */
export function untaggedPaid(scope: Scope): number {
  const handle = getDb();
  const { sql, values } = scopeSql(scope);
  const where = sql ? `${sql} AND` : "WHERE";

  const row = handle
    .prepare(
      `SELECT count(*) AS n FROM sessions s
        ${where} s.paid = 1 AND (s.term IS NULL OR s.term = '')`,
    )
    .get(...values) as { n: number };

  return row.n;
}

export type PlacementRow = {
  placement: string;
  call: number;
  whatsapp: number;
};

/**
 * Which CTA earns its place.
 *
 * A placement with no taps is not automatically dead weight — the sticky bar
 * being visible is part of why the hero action gets tapped — but a placement
 * that never fires on any page is one to reconsider, and this is the only way
 * to know.
 */
export function byPlacement(scope: Scope): PlacementRow[] {
  const handle = getDb();
  const { sql, values } = scopeSql(scope);

  const rows = handle
    .prepare(
      `SELECT coalesce(e.placement, '—') AS placement,
              coalesce(sum(CASE WHEN e.name = 'call' THEN 1 ELSE 0 END), 0) AS call_clicks,
              coalesce(sum(CASE WHEN e.name = 'whatsapp' THEN 1 ELSE 0 END), 0) AS whatsapp_clicks
         FROM events e
         JOIN sessions s ON s.id = e.session_id
        ${sql ? `${sql} AND` : "WHERE"} e.type = 'cta'
        GROUP BY placement
        ORDER BY call_clicks + whatsapp_clicks DESC`,
    )
    .all(...values) as {
    placement: string;
    call_clicks: number;
    whatsapp_clicks: number;
  }[];

  return rows.map((row) => ({
    placement: row.placement,
    call: row.call_clicks,
    whatsapp: row.whatsapp_clicks,
  }));
}

export type FaqRow = { question: string; opens: number; sessions: number };

/**
 * Which question people open.
 *
 * An FAQ entry opened by a third of the readers is the objection the page has
 * not answered above it — it belongs higher up, in the body copy, not at the
 * bottom behind a disclosure triangle.
 */
export function faqOpens(scope: Scope): FaqRow[] {
  const handle = getDb();
  const { sql, values } = scopeSql(scope);

  return handle
    .prepare(
      `SELECT e.name AS question,
              count(*) AS opens,
              count(DISTINCT e.session_id) AS sessions
         FROM events e
         JOIN sessions s ON s.id = e.session_id
        ${sql ? `${sql} AND` : "WHERE"} e.type = 'faq' AND e.name IS NOT NULL
        GROUP BY e.name
        ORDER BY sessions DESC
        LIMIT 20`,
    )
    .all(...values) as FaqRow[];
}

export type DepthBucket = { label: string; sessions: number };

/** Where the scroll actually stops, in tenths. */
export function depthBuckets(scope: Scope): DepthBucket[] {
  const handle = getDb();
  const { sql, values } = scopeSql(scope);

  const rows = handle
    .prepare(
      `SELECT min(max_depth / 25, 3) AS bucket, count(*) AS sessions
         FROM sessions s ${sql}
        GROUP BY bucket
        ORDER BY bucket`,
    )
    .all(...values) as { bucket: number; sessions: number }[];

  const labels = ["0–25%", "25–50%", "50–75%", "75–100%"];
  return labels.map((label, index) => ({
    label,
    sessions: rows.find((row) => row.bucket === index)?.sessions ?? 0,
  }));
}

export type Health = { writable: boolean; path: string; reason?: string };

/**
 * Can this process actually write the database?
 *
 * It usually can: the app is one container on the VPS with `data/` on a Docker
 * volume, beside the prospector's extract and the lead history. The case that
 * matters is the volume not being mounted — the collector then opens nothing,
 * writes nothing, and, because a beacon has nobody left to tell, reports
 * nothing. The dashboard would show an empty screen indistinguishable from
 * "the ads are not running yet", which is the worst failure this codebase
 * knows how to produce, and the same one the prospector's empty-extract checks
 * exist to prevent.
 *
 * So the screen asks, and says which file it was looking at.
 */
export function health(): Health {
  const file = databasePath();
  try {
    getDb().prepare("SELECT count(*) FROM sessions").get();
    return { writable: true, path: file };
  } catch (error) {
    return {
      writable: false,
      path: file,
      reason: error instanceof Error ? error.message : String(error),
    };
  }
}

/** Every page that has any data, for the picker. */
export function recordedPages(): string[] {
  const rows = getDb()
    .prepare("SELECT DISTINCT page FROM sessions ORDER BY page")
    .all() as { page: string }[];
  return rows.map((row) => row.page);
}

/* --------------------------------------------------------------------------
   What changed, and what to fix
   -------------------------------------------------------------------------- */

export type DayRow = {
  /** `YYYY-MM-DD`, in the server's local day. */
  day: string;
  sessions: number;
  converted: number;
  paid: number;
};

/**
 * Sessions and contacts per day.
 *
 * The screen was missing the one thing that turns measurement into
 * improvement: a before and an after. Every other block here describes a
 * period as a single number, which tells you the page converts at 6% and never
 * tells you whether last Tuesday's rewrite is why. A rate with no trend behind
 * it can only be compared to a feeling.
 *
 * Days with no traffic are filled in as zeroes by the caller rather than
 * skipped, because a gap drawn as a straight line between two points is a
 * quiet lie about a weekend.
 */
export function daily(scope: Scope): DayRow[] {
  const handle = getDb();
  const { sql, values } = scopeSql(scope);

  return handle
    .prepare(
      `SELECT date(started_at) AS day,
              count(*) AS sessions,
              coalesce(sum(CASE WHEN call_clicks + whatsapp_clicks > 0 THEN 1 ELSE 0 END), 0) AS converted,
              coalesce(sum(paid), 0) AS paid
         FROM sessions s ${sql}
        GROUP BY day
        ORDER BY day`,
    )
    .all(...values) as DayRow[];
}

/**
 * The same series with the empty days present.
 *
 * `days = 0` means "everything ever recorded", which has no fixed start, so
 * that scope is returned as-is — there is nothing to pad against.
 */
export function dailySeries(scope: Scope): DayRow[] {
  const rows = daily(scope);
  if (scope.days <= 0) return rows;

  const found = new Map(rows.map((row) => [row.day, row]));
  const out: DayRow[] = [];
  const today = new Date();

  for (let back = scope.days - 1; back >= 0; back--) {
    const date = new Date(today);
    date.setDate(date.getDate() - back);
    const day = date.toISOString().slice(0, 10);
    out.push(found.get(day) ?? { day, sessions: 0, converted: 0, paid: 0 });
  }
  return out;
}

export type HourRow = { hour: number; sessions: number; converted: number };

/**
 * By hour of day, in the server's timezone.
 *
 * Two uses, and the second is the one that pays: an ad schedule is set in
 * hours, and so is the decision about when somebody should be sitting by the
 * phone. A landing page whose only conversion is a `tel:` link converts far
 * worse at 22:00 than at 10:00 for a reason that has nothing to do with the
 * page, and reading that drop as a copy problem is a real risk this table
 * removes.
 */
export function byHour(scope: Scope): HourRow[] {
  const handle = getDb();
  const { sql, values } = scopeSql(scope);

  const rows = handle
    .prepare(
      `SELECT cast(strftime('%H', started_at, 'localtime') AS INTEGER) AS hour,
              count(*) AS sessions,
              coalesce(sum(CASE WHEN call_clicks + whatsapp_clicks > 0 THEN 1 ELSE 0 END), 0) AS converted
         FROM sessions s ${sql}
        GROUP BY hour`,
    )
    .all(...values) as HourRow[];

  const found = new Map(rows.map((row) => [row.hour, row]));
  return Array.from({ length: 24 }, (_, hour) => ({
    hour,
    sessions: found.get(hour)?.sessions ?? 0,
    converted: found.get(hour)?.converted ?? 0,
  }));
}

export type WeekdayRow = {
  weekday: number;
  sessions: number;
  converted: number;
};

/** By day of week, 0 = Sunday, for the same reason as `byHour`. */
export function byWeekday(scope: Scope): WeekdayRow[] {
  const handle = getDb();
  const { sql, values } = scopeSql(scope);

  const rows = handle
    .prepare(
      `SELECT cast(strftime('%w', started_at, 'localtime') AS INTEGER) AS weekday,
              count(*) AS sessions,
              coalesce(sum(CASE WHEN call_clicks + whatsapp_clicks > 0 THEN 1 ELSE 0 END), 0) AS converted
         FROM sessions s ${sql}
        GROUP BY weekday`,
    )
    .all(...values) as WeekdayRow[];

  const found = new Map(rows.map((row) => [row.weekday, row]));
  return Array.from({ length: 7 }, (_, weekday) => ({
    weekday,
    sessions: found.get(weekday)?.sessions ?? 0,
    converted: found.get(weekday)?.converted ?? 0,
  }));
}

export type ExitRow = { section: string; sessions: number; share: number };

/**
 * Where readers were standing when they left.
 *
 * The funnel says how far people got; this says where they stopped caring,
 * and the two disagree more often than they agree. A session that reaches the
 * closing band, scrolls back to the deliverables and leaves there is a
 * complete funnel by every other measure on this screen and an abandonment at
 * the deliverables in fact. That reader is the most valuable one we have: they
 * read the whole argument, went back to one specific part of it, and that part
 * is where they decided no.
 */
export function exitPoints(scope: Scope): ExitRow[] {
  const handle = getDb();
  const { sql, values } = scopeSql(scope);
  const where = sql
    ? `${sql} AND exit_section IS NOT NULL`
    : "WHERE exit_section IS NOT NULL";

  const rows = handle
    .prepare(
      `SELECT exit_section AS section, count(*) AS sessions
         FROM sessions s ${where}
        GROUP BY section
        ORDER BY sessions DESC`,
    )
    .all(...values) as { section: string; sessions: number }[];

  const total = rows.reduce((sum, row) => sum + row.sessions, 0);
  return rows.map((row) => ({
    ...row,
    share: total ? (row.sessions / total) * 100 : 0,
  }));
}

export type DeadClickRow = {
  target: string;
  clicks: number;
  sessions: number;
  rage: number;
};

/**
 * What people click that does nothing.
 *
 * The most directly actionable table on the whole screen, and the only one
 * whose rows convert into a change without any interpretation: every row is
 * someone who wanted to go further, tried, and was answered by nothing. A
 * heading styled like a button, a card that looks tappable, a phone number
 * rendered as text on a page whose entire job is phone calls.
 *
 * The `rage` column counts the bursts — the same spot clicked several times in
 * a couple of seconds, which is the difference between a reader who brushed
 * something and a reader who was sure it should work.
 */
export function deadClicks(scope: Scope): DeadClickRow[] {
  const handle = getDb();
  const { sql, values } = scopeSql(scope);

  return handle
    .prepare(
      `SELECT coalesce(e.name, '(sem alvo)') AS target,
              count(*) AS clicks,
              count(DISTINCT e.session_id) AS sessions,
              coalesce(sum(CASE WHEN e.type = 'rage' THEN 1 ELSE 0 END), 0) AS rage
         FROM events e
         JOIN sessions s ON s.id = e.session_id
        ${sql ? `${sql} AND` : "WHERE"} e.type IN ('dead', 'rage')
        GROUP BY target
        ORDER BY clicks DESC
        LIMIT 25`,
    )
    .all(...values) as DeadClickRow[];
}

export type DwellRow = {
  section: string;
  sessions: number;
  /** Median visible milliseconds, over sessions that saw the section at all. */
  medianMs: number;
};

/**
 * How long each band actually held someone.
 *
 * The funnel counts a band as seen when a third of it crosses the viewport,
 * which is the right threshold for "did they reach it" and says nothing about
 * "did they read it". A band that every reader reaches and nobody spends four
 * seconds on is a band being scrolled past, and it reads on the funnel as a
 * step with no drop — a success.
 *
 * The median is computed here in TypeScript rather than in SQL because the
 * window functions that would do it per group are the one part of SQLite's
 * surface this file cannot assume across the versions `node:sqlite` ships.
 * The row count is bounded by the number of sections, so the cost is nothing.
 */
export function dwell(scope: Scope): DwellRow[] {
  const handle = getDb();
  const { sql, values } = scopeSql(scope);

  const rows = handle
    .prepare(
      `SELECT e.name AS section, e.session_id AS session, max(e.value) AS ms
         FROM events e
         JOIN sessions s ON s.id = e.session_id
        ${sql ? `${sql} AND` : "WHERE"} e.type = 'dwell' AND e.name IS NOT NULL
        GROUP BY e.name, e.session_id`,
    )
    .all(...values) as { section: string; session: string; ms: number }[];

  const bySection = new Map<string, number[]>();
  for (const row of rows) {
    const list = bySection.get(row.section) ?? [];
    list.push(row.ms ?? 0);
    bySection.set(row.section, list);
  }

  return Array.from(bySection.entries())
    .map(([section, list]) => {
      list.sort((a, b) => a - b);
      return {
        section,
        sessions: list.length,
        medianMs: list[Math.floor(list.length / 2)] ?? 0,
      };
    })
    .sort((a, b) => b.sessions - a.sessions);
}

/**
 * The referring host, for the half of the traffic Google Ads does not send.
 *
 * Only meaningful now that the site's own pages are measured: a landing page
 * is reached from an ad and its referrer table is a list of one. The home page
 * is reached from search, from a directory listing, from somebody's WhatsApp,
 * and knowing which is what tells you where the unpaid half of the business
 * actually comes from.
 */
export const byReferrer = (scope: Scope) =>
  breakdown(scope, "referrer", "direto / sem origem");

export type ViewportRow = {
  label: string;
  sessions: number;
  converted: number;
};

/**
 * Conversion by screen width, in the breakpoints the CSS actually uses.
 *
 * "Celular converte pior" is where most device analysis stops, and it is not a
 * change anyone can make. Which width it breaks at is: a page that converts
 * fine at 390px and badly at 360px has a layout problem at one breakpoint, not
 * a copy problem on phones.
 */
export function byViewport(scope: Scope): ViewportRow[] {
  const handle = getDb();
  const { sql, values } = scopeSql(scope);

  const rows = handle
    .prepare(
      `SELECT CASE
                WHEN viewport IS NULL OR viewport = 0 THEN 'desconhecido'
                WHEN viewport < 360  THEN 'até 359px'
                WHEN viewport < 400  THEN '360–399px'
                WHEN viewport < 640  THEN '400–639px'
                WHEN viewport < 1024 THEN '640–1023px'
                WHEN viewport < 1440 THEN '1024–1439px'
                ELSE '1440px+'
              END AS label,
              count(*) AS sessions,
              coalesce(sum(CASE WHEN call_clicks + whatsapp_clicks > 0 THEN 1 ELSE 0 END), 0) AS converted
         FROM sessions s ${sql}
        GROUP BY label
        ORDER BY sessions DESC`,
    )
    .all(...values) as ViewportRow[];

  return rows;
}
