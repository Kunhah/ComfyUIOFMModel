import { adPages } from "@/content/ads";
import { ADS_FUNNEL, SITE_FUNNEL, type Section } from "./events";

/**
 * Every page that is allowed to measure itself, and the funnel each one has.
 *
 * The collector refuses any `page` that is not in here, for the reason it
 * always refused one that was not an ad slug: without the check the table is a
 * free-form string store anybody on the internet can fill, and the dashboard's
 * page picker becomes a list of whatever a bored someone typed.
 *
 * What changed is only the size of the list. Until this file existed the
 * allowlist *was* `adPageBySlug`, which meant the pages we buy clicks
 * for were measured and the site those clicks are supposed to build authority
 * for was not measured at all — the home page, the one surface every organic
 * visitor and every person who types the name lands on, produced no data
 * whatsoever. "Where do we lose them" was answerable for the paid half of the
 * business and unanswerable for the other half.
 *
 * A page belongs here when it has something to lose a reader in. The two legal
 * pages are measured because a spike in reads of `privacidade` is a real
 * signal about the rest of the site, and deliberately carry no funnel: there
 * is nothing to convert on them and a funnel implying otherwise would be a
 * chart that means nothing.
 */

export type Template = "ads" | "site" | "legal";

export type MeasuredPage = {
  /**
   * What the tracker sends and the collector checks. It is not the URL path:
   * the ad pages were recorded under their bare slug long before this file
   * existed, and renaming them would orphan the history for no gain.
   */
  slug: string;
  label: string;
  /** For the link out of the dashboard, so a row is one click from the page. */
  path: string;
  template: Template;
  /** Ordered. This list *is* the funnel; an empty one means the page has none. */
  funnel: readonly Section[];
};

/**
 * The site's own pages.
 *
 * The home page's funnel is the scroll of `(marketing)/page.tsx` in order —
 * the three acts of light, band by band. It is a genuinely different funnel
 * from the landing pages' and not a longer version of it: nobody arrives on
 * the home page having searched for one trade, so the question it answers is
 * "which act loses them", not "which argument failed".
 */
const SITE_PAGES: MeasuredPage[] = [
  {
    slug: "home",
    label: "Home",
    path: "/",
    template: "site",
    funnel: SITE_FUNNEL,
  },
  {
    slug: "privacidade",
    label: "Privacidade",
    path: "/privacidade",
    template: "legal",
    funnel: [],
  },
  {
    slug: "termos",
    label: "Termos",
    path: "/termos",
    template: "legal",
    funnel: [],
  },
];

/**
 * The ad landing pages, which all share one template and one funnel.
 *
 * Derived from `adPages` rather than counted here: a number written into a
 * comment is wrong the first time somebody adds an ad group.
 *
 * Derived from `adPages` rather than listed again: a twentieth ad group is an
 * entry in `content/ads.ts` and nothing else, and a landing page that shipped
 * without anyone remembering to add it here would serve traffic while
 * silently recording nothing.
 */
const AD_MEASURED: MeasuredPage[] = adPages.map((page) => ({
  slug: page.slug,
  label: page.slug,
  path: `/${page.slug}`,
  template: "ads",
  funnel: ADS_FUNNEL,
}));

export const measuredPages: MeasuredPage[] = [...SITE_PAGES, ...AD_MEASURED];

export const pageBySlug = new Map(
  measuredPages.map((page) => [page.slug, page]),
);

export function isMeasured(slug: string): boolean {
  return pageBySlug.has(slug);
}

/**
 * The funnel a page's sections are counted against.
 *
 * Asked per page rather than held as one global list, which is the whole
 * reason this file exists: `deepest` used to be an index into a single
 * hard-coded `SECTIONS`, so a home-page band would have been scored against
 * the landing pages' funnel and landed at index 0 — a reader who saw the
 * entire page, filed as a bounce.
 */
export function funnelFor(slug: string): readonly Section[] {
  return pageBySlug.get(slug)?.funnel ?? [];
}

export function templateFor(slug: string): Template | undefined {
  return pageBySlug.get(slug)?.template;
}

/** The slugs of one template, for the screens that only describe one. */
export function slugsOf(template: Template): string[] {
  return measuredPages
    .filter((page) => page.template === template)
    .map((page) => page.slug);
}

export const pageLabel = (slug: string): string =>
  pageBySlug.get(slug)?.label ?? slug;
