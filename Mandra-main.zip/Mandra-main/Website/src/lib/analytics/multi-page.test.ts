import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { after, before, describe, it } from "node:test";
import type { ClientEvent } from "./events";

/**
 * The measurement of more than one page shape, and the signals that say what
 * to fix.
 *
 * Kept apart from `db.test.ts` because it pins a different class of mistake.
 * That file guards the arithmetic of one funnel; this one guards the moment
 * the layer stopped having exactly one funnel — which is the change most able
 * to produce a screen that is confidently, plausibly wrong.
 *
 * The specific failure it exists for: `deepest` used to be an index into a
 * single global section list, and `readAllNoCall` compared it against that
 * list's length. With two page structures of different lengths, both of those
 * silently describe the wrong thing — a home-page reader who saw every band
 * scores 0 against the landing pages' list and is filed as a bounce, and a
 * landing-page reader who stopped two bands early clears an eight-band
 * threshold and is filed as having read everything. Neither throws.
 */

let db: typeof import("./db");
let dir: string;

let clock = 0;
function at(): string {
  clock += 1000;
  return new Date(Date.now() + clock).toISOString();
}

function send(session: string, page: string, events: ClientEvent[]): void {
  db.record({ v: 1, session, page, events }, at());
}

const view: ClientEvent = { type: "view", t: 0 };
const section = (name: string, t = 1000): ClientEvent => ({
  type: "section",
  name,
  t,
});

before(async () => {
  dir = mkdtempSync(path.join(tmpdir(), "analytics-multi-"));
  process.env.ANALYTICS_DB = path.join(dir, "analytics.db");
  db = await import("./db");
});

after(() => {
  rmSync(dir, { recursive: true, force: true });
});

describe("more than one page shape", () => {
  it("scores a home-page band against the home funnel, not the ads one", () => {
    // 'carga' exists only in the site funnel. Against the landing pages' list
    // it is unknown, which would leave `deepest` at 0 — a full read filed as
    // a bounce.
    send("home-deep", "home", [view, section("hero"), section("carga", 9000)]);

    const stats = db.overview({ page: "home", days: 0 });
    assert.equal(stats.sessions, 1);
    assert.equal(stats.bounced, 0);
  });

  it("marks the end of the funnel per page, not by a shared length", () => {
    // The last band of the site funnel. Six bands in, it would clear no
    // threshold derived from the landing pages' six-item list either.
    send("home-end", "home", [view, section("hero"), section("terminal", 9000)]);
    // The sixth band of the site funnel is NOT its end, though it would be the
    // end of a six-item ads funnel.
    send("home-mid", "home", [view, section("hero"), section("ferramental", 9000)]);

    const stats = db.overview({ page: "home", days: 0 });
    // Three home sessions exist by now and only one of them reached the last
    // band. 'carga' and 'ferramental' are the seventh and sixth — deep, and a
    // length-based check against a six-item list would have passed both.
    assert.equal(stats.readAllNoCall, 1);
  });

  it("draws each template its own funnel", () => {
    send("ad-1", "criacao-de-sites", [view, section("hero"), section("dores")]);

    const siteSteps = db.funnel({ template: "site", days: 0 });
    const adSteps = db.funnel({ template: "ads", days: 0 });

    assert.equal(siteSteps.length, 8);
    assert.equal(adSteps.length, 6);
    assert.equal(siteSteps[0]?.section, "hero");
    assert.equal(adSteps[1]?.section, "dores");
  });

  it("refuses to draw a funnel over a scope with no single shape", () => {
    // Two page structures added together would produce steps that exist on
    // neither page. An empty list is the honest answer, and the screen says so.
    assert.deepEqual(db.funnel({ days: 0 }), []);
  });

  it("keeps a template's sessions out of the other template's totals", () => {
    const site = db.overview({ template: "site", days: 0 });
    const ads = db.overview({ template: "ads", days: 0 });

    assert.equal(site.sessions, 3);
    assert.equal(ads.sessions, 1);
  });
});

describe("what to fix", () => {
  it("counts dead clicks per session and totals them per target", () => {
    send("rage-1", "home", [
      view,
      { type: "dead", name: "hero: Fale com a gente", t: 1200 },
      { type: "dead", name: "hero: Fale com a gente", t: 1500 },
      { type: "rage", name: "hero: Fale com a gente", value: 3, t: 1800 },
    ]);

    const rows = db.deadClicks({ page: "home", days: 0 });
    const row = rows.find((r) => r.target === "hero: Fale com a gente");

    assert.ok(row);
    // Two dead rows plus the rage row, all against one target.
    assert.equal(row.clicks, 3);
    assert.equal(row.sessions, 1);
    assert.equal(row.rage, 1);

    const stats = db.overview({ page: "home", days: 0 });
    assert.equal(stats.withDeadClicks, 1);
    assert.equal(stats.withRageClicks, 1);
  });

  it("takes the last exit reported, not the furthest", () => {
    // Someone who reaches the end, scrolls back to an earlier band and leaves
    // there has a complete funnel and an abandonment at that earlier band.
    send("exit-1", "home", [
      view,
      section("hero"),
      section("terminal", 8000),
      { type: "exit", name: "terminal", t: 8500 },
    ]);
    send("exit-1", "home", [{ type: "exit", name: "carga", t: 12000 }]);

    const exits = db.exitPoints({ page: "home", days: 0 });
    const carga = exits.find((row) => row.section === "carga");
    const terminal = exits.find((row) => row.section === "terminal");

    assert.equal(carga?.sessions, 1);
    assert.equal(terminal, undefined, "the earlier exit replaced the later one");
  });

  it("keeps the earliest first scroll when a beacon repeats", () => {
    send("scroll-1", "home", [
      view,
      { type: "firstscroll", value: 900, t: 900 },
    ]);
    // A duplicated beacon, arriving with a later reading. min() must hold.
    send("scroll-1", "home", [{ type: "firstscroll", value: 4000, t: 4000 }]);

    const stats = db.overview({ page: "home", days: 0 });
    assert.equal(stats.medianFirstScrollMs, 900);
  });

  it("reports dwell per section as a median over sessions", () => {
    send("dwell-1", "home", [
      view,
      { type: "dwell", name: "linhas", value: 2000, t: 2000 },
    ]);
    send("dwell-2", "home", [
      view,
      { type: "dwell", name: "linhas", value: 6000, t: 6000 },
    ]);
    send("dwell-3", "home", [
      view,
      { type: "dwell", name: "linhas", value: 8000, t: 8000 },
    ]);

    const rows = db.dwell({ page: "home", days: 0 });
    const linhas = rows.find((row) => row.section === "linhas");

    assert.equal(linhas?.sessions, 3);
    assert.equal(linhas?.medianMs, 6000);
  });

  it("takes the largest dwell a session reported, never the sum", () => {
    // The tracker re-sends a running total on every flush. Summing them would
    // report a reader who flushed four times as having stayed four times as
    // long.
    send("dwell-x", "home", [
      view,
      { type: "dwell", name: "rota", value: 3000, t: 3000 },
    ]);
    send("dwell-x", "home", [{ type: "dwell", name: "rota", value: 5000, t: 5000 }]);

    const rows = db.dwell({ page: "home", days: 0 });
    assert.equal(rows.find((row) => row.section === "rota")?.medianMs, 5000);
  });
});

describe("the trend", () => {
  it("fills the days nobody visited rather than skipping them", () => {
    // A gap drawn as a straight line between two points is a quiet lie about
    // a weekend.
    const series = db.dailySeries({ page: "home", days: 7 });
    assert.equal(series.length, 7);
    assert.ok(series.every((row) => typeof row.sessions === "number"));
  });

  it("returns what exists when the window is unbounded", () => {
    const series = db.dailySeries({ page: "home", days: 0 });
    assert.ok(series.length >= 1);
  });
});
