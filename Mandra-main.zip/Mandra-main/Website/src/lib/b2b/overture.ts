import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { DuckDBInstance, type DuckDBConnection } from "@duckdb/node-api";
import { duckdbConfig } from "../prospector/overture";
import { unionBbox } from "./countries";
import type { Candidate } from "./types";
import { discoveryTargets, sectorForCategory } from "./sectors";
import { domainOf, normaliseWebsite } from "./crawl/url";

/**
 * Discovery: which companies to crawl.
 *
 * Same source and the same two modes as the prospector — Overture Maps places
 * over DuckDB, from a local extract when one exists and straight off S3 when it
 * doesn't — but pointed the other way. There the query asks for businesses with
 * *no* website; here a website is the entry point for everything downstream, so
 * a record without one is not a candidate at all.
 *
 * The extract is a different file (`data/b2b-companies.parquet`), built by
 * `npm run sync:b2b`, because the two have almost nothing in common: this one is
 * multi-country, filtered to industrial and wholesale categories, and keeps the
 * country and postcode columns the Brazilian extract has no use for.
 */

export const overtureRelease = process.env.OVERTURE_RELEASE ?? "2026-07-22.0";

const REMOTE_PLACES = `s3://overturemaps-us-west-2/release/${overtureRelease}/theme=places/type=place/*`;

export function localExtractPath(): string {
  return path.join(process.cwd(), "data", "b2b-companies.parquet");
}

export function hasLocalExtract(): boolean {
  return existsSync(localExtractPath());
}

/**
 * What `npm run sync:b2b` recorded about the file it built.
 *
 * `categoryList` is written by newer syncs only; an older manifest has just a
 * count, which cannot answer "is this sector in the file?" — see
 * `uncoveredSectors()` for what that costs.
 */
type ExtractManifest = {
  release?: string;
  countries?: string[];
  rows?: number;
  categories?: number;
  categoryList?: string[];
  scope?: "sectors" | "universal";
  builtAt?: string;
};

function extractManifest(): ExtractManifest | null {
  if (!hasLocalExtract()) return null;
  try {
    return JSON.parse(
      readFileSync(
        path.join(process.cwd(), "data", "extract-b2b.json"),
        "utf8",
      ),
    ) as ExtractManifest;
  } catch {
    return null;
  }
}

/** Whether the local extract contains every website-bearing place, not only our
 * curated sector categories. Older extracts deliberately return false. */
export function hasUniversalExtract(): boolean {
  return extractManifest()?.scope === "universal";
}

/**
 * The sectors and campaigns the local extract physically cannot answer for.
 *
 * This is the tool's worst failure mode made visible. The extract is filtered to
 * the categories that were in `sectors.ts` when it was built, so every sector
 * added since matches nothing — and a query matching nothing is indistinguishable
 * from "there are no machine shops in Austria". The registry has grown from 38
 * sectors to 85, so this stopped being a hypothetical.
 *
 * Returns slugs, so the picker can mark them and the page can say how many. An
 * empty array means either full coverage or a question we cannot answer:
 *
 *   - no local extract   → every search goes to S3 against the live vocabulary,
 *                          so nothing is out of reach, only slow;
 *   - universal scope    → no category filter was applied at all;
 *   - manifest with no   → an extract built before this field existed. We refuse
 *     `categoryList`       to guess: claiming coverage we cannot verify is the
 *                          same silent lie in the other direction, and the page
 *                          reports the unknown separately.
 */
export function uncoveredSectors(): string[] {
  const manifest = extractManifest();
  if (!manifest || manifest.scope === "universal") return [];
  const covered = manifest.categoryList;
  if (!Array.isArray(covered) || covered.length === 0) return [];

  const known = new Set(covered);
  return discoveryTargets()
    .filter(
      (target) =>
        // The universal campaign carries no categories and is gated separately.
        target.categories.length > 0 &&
        // A campaign spans several sectors and stays usable while *any* of them
        // is in the file: it would still return companies, just fewer than its
        // label promises. Only a target with nothing at all in the extract is
        // reported, because that is the one that answers zero and lies.
        target.categories.every((category) => !known.has(category)),
    )
    .map((target) => target.slug);
}

/** True when the extract predates `categoryList` and coverage is unknowable. */
export function extractCoverageUnknown(): boolean {
  const manifest = extractManifest();
  if (!manifest || manifest.scope === "universal") return false;
  return (
    !Array.isArray(manifest.categoryList) || manifest.categoryList.length === 0
  );
}

let connectionPromise: Promise<DuckDBConnection> | null = null;
let remoteReady = false;

async function getConnection(): Promise<DuckDBConnection> {
  if (!connectionPromise) {
    connectionPromise = (async () => {
      // Same empty-HOME problem as the prospector's; see duckdbConfig() there
      // for why an unset HOME breaks INSTALL before the query runs.
      const instance = await DuckDBInstance.create(":memory:", duckdbConfig());
      try {
        return await instance.connect();
      } catch (err) {
        // See prospector/overture.ts: the instance holds a thread per core from
        // create() onwards, and the retry below would otherwise leak one pool
        // per call for as long as connecting keeps failing.
        instance.closeSync();
        throw err;
      }
    })().catch((err) => {
      connectionPromise = null;
      throw err;
    });
  }
  return connectionPromise;
}

async function ensureRemote(connection: DuckDBConnection): Promise<void> {
  if (remoteReady) return;
  await connection.run("INSTALL httpfs");
  await connection.run("LOAD httpfs");
  await connection.run("SET s3_region='us-west-2'");
  // Public bucket: blank the credentials or DuckDB signs with ambient AWS env
  // vars and gets a 403.
  await connection.run("SET s3_access_key_id=''");
  await connection.run("SET s3_secret_access_key=''");
  remoteReady = true;
}

/**
 * Case, accents and punctuation folded away, for matching a typed city against
 * whatever the record says. The SQL twin is `nrm()` below and the two must fold
 * identically — same rule as the prospector's, and the reason both live in this
 * one file is so they cannot drift apart across modules.
 */
export function fold(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function nrm(expr: string): string {
  return `trim(regexp_replace(lower(strip_accents(${expr})), '[^a-z0-9]+', ' ', 'g'))`;
}

/** Categories come from our registry, never user input; this guards that. */
function quoteList(values: string[], what: string): string {
  for (const value of values) {
    if (!/^[A-Za-z0-9_]+$/.test(value)) {
      throw new Error(`${what} inválido: ${JSON.stringify(value)}`);
    }
  }
  return values.map((v) => `'${v}'`).join(", ");
}

export type DiscoverQuery = {
  /** Empty deliberately means the universal local extract: no category filter. */
  categories: string[];
  /** ISO-3166 alpha-2, already validated against the registry. */
  countries: string[];
  city?: string;
  minConfidence: number;
  limit: number;
};

export type DiscoverResult = {
  candidates: Candidate[];
  totals: { matched: number; withWebsite: number };
  elapsedMs: number;
  mode: "local" | "remote";
};

export async function discoverCompanies(
  query: DiscoverQuery,
): Promise<DiscoverResult> {
  const connection = await getConnection();
  const local = hasLocalExtract();

  const source = local
    ? `read_parquet('${localExtractPath().replace(/'/g, "''")}')`
    : `read_parquet('${REMOTE_PLACES}', hive_partitioning = 1)`;
  if (!local) await ensureRemote(connection);

  // The sync flattens the nested Overture shape; the raw dataset hasn't been.
  const cols = local
    ? `id, name, category, address, city, region, country, postcode, phone, website, confidence`
    : `id,
       names.primary            AS name,
       categories.primary       AS category,
       addresses[1].freeform    AS address,
       addresses[1].locality    AS city,
       addresses[1].region      AS region,
       addresses[1].country     AS country,
       addresses[1].postcode    AS postcode,
       phones[1]                AS phone,
       websites[1]              AS website,
       confidence`;

  const categoryExpr = local ? "category" : "categories.primary";
  const countryExpr = local ? "country" : "addresses[1].country";
  const cityExpr = local ? "city" : "addresses[1].locality";
  // The bbox is what makes the remote scan finish at all — row-group statistics
  // can prune on it. It is a rectangle around every selected country, so it
  // always over-selects; the country equality below is what makes it correct.
  const bbox = unionBbox(query.countries);
  const bboxFilter = local
    ? `lon BETWEEN $xmin AND $xmax AND lat BETWEEN $ymin AND $ymax`
    : `bbox.xmin BETWEEN $xmin AND $xmax AND bbox.ymin BETWEEN $ymin AND $ymax`;

  const cityFilter = query.city ? `AND ${nrm(cityExpr)} LIKE $city` : "";

  const categoryFilter =
    query.categories.length > 0
      ? `AND ${categoryExpr} IN (${quoteList(query.categories, "Categoria")})`
      : "";
  // Universal discovery must not spend its first crawl batch on restaurants,
  // shops and landmarks merely because their map records have high confidence.
  // This is a *ranking* hint, never an exclusion: an unexpectedly categorised
  // specialised company remains discoverable, while categories that usually
  // describe a commercial operation rise to the first batch for the site's
  // own facts and contactability to decide.
  const businessFirst =
    query.categories.length === 0
      ? `CASE WHEN regexp_matches(lower(coalesce(${categoryExpr}, '')),
          '(manufactur|industrial|engineering|laboratory|technology|utility|logistic|equipment|contractor|agricultur|distribution|business|medical|chemical|metal|machine|construction|energy|telecommunications|supplier|wholesale|services|company)')
          THEN 1 ELSE 0 END DESC,`
      : "";

  const sql = `
    WITH matched AS (
      SELECT ${cols} FROM ${source}
      WHERE ${bboxFilter}
        ${categoryFilter}
        AND upper(coalesce(${countryExpr}, '')) IN (${quoteList(query.countries, "País")})
        AND confidence >= $minConf
        ${cityFilter}
    ),
    flagged AS (
      SELECT *, (website IS NOT NULL AND website <> '') AS has_site FROM matched
    ),
    counted AS (
      SELECT *,
             count(*) OVER ()                                    AS total_matched,
             sum(CASE WHEN has_site THEN 1 ELSE 0 END) OVER ()   AS total_with_site
      FROM flagged
    )
    SELECT * FROM counted
    WHERE has_site
    -- Confidence first: the crawl is the expensive step, so it should be spent
    -- on the records most likely to be a real, current company.
    ORDER BY ${businessFirst} confidence DESC
    LIMIT ${Math.max(1, Math.min(5000, Math.trunc(query.limit * 3)))}
  `;

  const params: Record<string, string | number> = {
    xmin: bbox.xmin,
    xmax: bbox.xmax,
    ymin: bbox.ymin,
    ymax: bbox.ymax,
    minConf: query.minConfidence,
  };
  // Substring rather than equality: outside Brazil we have no curated city
  // index to resolve against, so "munich" has to find "Munich" and "München"
  // (folded to "munchen") has to find itself without an exact spelling.
  if (query.city) params.city = `%${fold(query.city)}%`;

  const started = Date.now();
  const reader = await connection.runAndReadAll(sql, params);
  const rows = reader.getRowObjectsJS() as Record<string, unknown>[];
  const elapsedMs = Date.now() - started;

  const str = (v: unknown): string | null => {
    if (v === null || v === undefined) return null;
    const s = String(v).trim();
    return s.length > 0 ? s : null;
  };

  // One company, one crawl. Overture lists each plant, depot and sales office as
  // its own place, and a group with eleven sites has one website — crawling it
  // eleven times would burn the budget and write eleven identical rows.
  const byDomain = new Map<string, Candidate>();
  for (const row of rows) {
    const website = normaliseWebsite(String(row.website ?? ""));
    if (!website) continue;
    const domain = domainOf(website);
    if (!domain) continue;
    if (byDomain.has(domain)) continue;

    const category = str(row.category);
    byDomain.set(domain, {
      id: String(row.id),
      name: str(row.name) ?? domain,
      website,
      domain,
      country: str(row.country)?.toUpperCase() ?? null,
      city: str(row.city),
      region: str(row.region),
      address:
        [str(row.address), str(row.postcode)].filter(Boolean).join(", ") ||
        null,
      phone: str(row.phone),
      category,
      sector: sectorForCategory(category),
      source: "overture",
    });
    if (byDomain.size >= query.limit) break;
  }

  const first = rows[0];
  const agg = (key: string): number =>
    first === undefined ? 0 : Number(first[key] ?? 0);

  return {
    candidates: [...byDomain.values()],
    totals: {
      matched: agg("total_matched"),
      withWebsite: agg("total_with_site"),
    },
    elapsedMs,
    mode: local ? "local" : "remote",
  };
}

/**
 * The other discovery mode: a list somebody already has.
 *
 * Trade-fair exhibitor lists, an association's member directory, a competitor's
 * customer page — all of them are a column of domains, and all of them find
 * companies Overture has never heard of. Accepts one entry per line, with an
 * optional name before a comma, tab or semicolon: "Müller GmbH, mueller.de".
 */
export function parseSeedList(input: string): {
  candidates: Candidate[];
  rejected: string[];
} {
  const candidates: Candidate[] = [];
  const rejected: string[] = [];
  const seen = new Set<string>();

  for (const raw of String(input ?? "").split(/[\r\n]+/)) {
    const line = raw.trim();
    if (!line || line.startsWith("#")) continue;

    // The URL is whichever field looks like one; the rest is the name.
    const fields = line
      .split(/[;,\t]|\s{2,}/)
      .map((f) => f.trim())
      .filter(Boolean);
    const urlField =
      fields.find((f) => /^https?:\/\//i.test(f)) ??
      fields.find((f) => /^[\w-]+(\.[\w-]+)+(\/|$)/.test(f)) ??
      fields[fields.length - 1];
    const website = normaliseWebsite(urlField ?? line);
    const domain = website ? domainOf(website) : null;

    if (!website || !domain) {
      rejected.push(line.slice(0, 120));
      continue;
    }
    if (seen.has(domain)) continue;
    seen.add(domain);

    const name = fields.find((f) => f !== urlField && !/^https?:\/\//i.test(f));
    candidates.push({
      // The domain doubles as the id, which is what makes a pasted list and an
      // Overture result dedupe against each other in the history.
      id: domain,
      name: name ?? domain,
      website,
      domain,
      country: null,
      city: null,
      region: null,
      address: null,
      phone: null,
      category: null,
      sector: null,
      source: "lista",
    });
  }

  return { candidates, rejected };
}
