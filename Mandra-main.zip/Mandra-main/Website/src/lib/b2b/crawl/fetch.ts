/**
 * One HTTP fetch, made survivable.
 *
 * The reference design for this pipeline runs `httpx` first and falls back to a
 * headless browser when that fails. We do the first half and deliberately not
 * the second: Playwright would add ~300 MB to an image that currently ships a
 * Next server and DuckDB, and the pages we need — contact, impressum, about —
 * are almost universally server-rendered even on sites whose homepage is a SPA.
 * A site that renders its address only in JavaScript is reported as reached with
 * nothing found, which is honest and costs one row, rather than being the reason
 * the whole tool needs a browser.
 *
 * Everything here is about not hanging: a timeout, a byte cap, a retry budget
 * and a hard stop on non-HTML bodies. A crawl of 200 industrial sites will
 * always contain a handful that accept the connection and then never send a
 * byte, and without a ceiling those decide how long the run takes.
 */

export type CrawledPage = {
  /** Path as requested, relative to the site root — "/", "/kontakt". */
  path: string;
  url: string;
  status: number;
  html: string;
  /** Lowercased response headers we actually use (server, x-powered-by, …). */
  headers: Record<string, string>;
};

export type FetchOptions = {
  timeoutMs?: number;
  maxBytes?: number;
  /** Total attempts, including the first. */
  attempts?: number;
  signal?: AbortSignal;
};

const DEFAULT_TIMEOUT = 12_000;
/** Enough for any contact page; a 40 MB "catalogue as one HTML file" is not one. */
const DEFAULT_MAX_BYTES = 2_000_000;
const DEFAULT_ATTEMPTS = 2;

/**
 * Identifies the crawler honestly and points at a page explaining it. A
 * webmaster who sees this in their logs can tell what it is and block it, which
 * is the deal that makes crawling other people's sites acceptable at all.
 *
 * **ASCII only.** HTTP header values are Latin-1 at best, and a single accented
 * character here is not a cosmetic problem: it made hoffmann-group.com answer
 * `400 Bad Request` to every request while curl with an ASCII agent got a 301.
 * The whole company read as unreachable because of one cedilla, and the same
 * would silently happen to whatever fraction of a run's sites validate headers
 * strictly. `sanitiseAgent` enforces it for the env override too.
 */
export const USER_AGENT = sanitiseAgent(
  process.env.B2B_USER_AGENT ??
    "MandraProspectorBot/1.0 (+https://mandra.com.br; B2B prospecting)",
);

function sanitiseAgent(value: string): string {
  const ascii = value.replace(/[^\x20-\x7e]/g, "");
  return ascii.trim().length > 0 ? ascii : "MandraProspectorBot/1.0";
}

export type FetchResult =
  | { ok: true; page: CrawledPage }
  | { ok: false; status: number; error: string };

export async function fetchPage(
  url: string,
  options: FetchOptions = {},
): Promise<FetchResult> {
  const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT;
  const maxBytes = options.maxBytes ?? DEFAULT_MAX_BYTES;
  const attempts = Math.max(1, options.attempts ?? DEFAULT_ATTEMPTS);

  let last: { status: number; error: string } = {
    status: 0,
    error: "não tentado",
  };

  for (let attempt = 0; attempt < attempts; attempt++) {
    if (options.signal?.aborted) {
      return { ok: false, status: 0, error: "cancelado" };
    }
    // Linear, not exponential: with a 12s timeout a second attempt already sits
    // 12s behind, and this runs across hundreds of hosts.
    if (attempt > 0) await sleep(400 * attempt);

    const result = await attemptFetch(url, timeoutMs, maxBytes, options.signal);
    if (result.ok) return result;
    last = { status: result.status, error: result.error };

    // 4xx is an answer, not a failure — retrying a 404 or a 403 just wastes the
    // budget. Only transport errors and server-side wobbles are worth a second go.
    if (result.status >= 400 && result.status < 500 && result.status !== 429) {
      break;
    }
  }

  return { ok: false, ...last };
}

async function attemptFetch(
  url: string,
  timeoutMs: number,
  maxBytes: number,
  external?: AbortSignal,
): Promise<FetchResult> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const onAbort = () => controller.abort();
  external?.addEventListener("abort", onAbort, { once: true });

  try {
    const response = await fetch(url, {
      redirect: "follow",
      signal: controller.signal,
      headers: {
        "user-agent": USER_AGENT,
        // Ask for HTML explicitly; some servers content-negotiate their way into
        // JSON or an RSS feed when the client says it accepts anything.
        accept: "text/html,application/xhtml+xml;q=0.9,*/*;q=0.5",
        // A European site that offers a language switch will honour this and hand
        // back the English variant, which is both easier to extract from and the
        // language the outreach will be written in anyway.
        //
        // Portuguese is deliberately absent. With `pt` in the list, Beckhoff
        // served its /pt-br branch: the crawl came back with a São Paulo phone
        // number, `info@beckhoff.com.br`, and the company filed under Brazil —
        // when the prospect is the head office in Verl. We want the company's
        // own country, not its Brazilian subsidiary.
        "accept-language": "en;q=0.9,de;q=0.8,fr;q=0.7,it;q=0.6,es;q=0.5",
      },
    });

    if (!response.ok) {
      return {
        ok: false,
        status: response.status,
        error: `HTTP ${response.status}`,
      };
    }

    const contentType = (
      response.headers.get("content-type") ?? ""
    ).toLowerCase();
    if (contentType && !/(text\/html|xhtml|text\/plain)/.test(contentType)) {
      // A PDF or a ZIP behind an innocent-looking URL. Reading it would spend the
      // byte budget on something no extractor here can use.
      return {
        ok: false,
        status: response.status,
        error: `tipo não-HTML (${contentType.split(";")[0]})`,
      };
    }

    const html = await readCapped(response, maxBytes);

    return {
      ok: true,
      page: {
        path: pathOf(url),
        url: response.url || url,
        status: response.status,
        html,
        headers: pickHeaders(response.headers),
      },
    };
  } catch (err) {
    const message =
      err instanceof Error
        ? err.name === "AbortError" || err.name === "TimeoutError"
          ? `timeout após ${Math.round(timeoutMs / 1000)}s`
          : err.message
        : String(err);
    return { ok: false, status: 0, error: message };
  } finally {
    clearTimeout(timer);
    external?.removeEventListener("abort", onAbort);
  }
}

/**
 * Read the body but stop at `maxBytes`.
 *
 * `response.text()` would buffer whatever the server sends, and "whatever the
 * server sends" has no upper bound — an endless stream from a misconfigured
 * host would hold the whole run hostage. Cutting mid-document is safe here:
 * every extractor works on fragments.
 */
async function readCapped(
  response: Response,
  maxBytes: number,
): Promise<string> {
  const body = response.body;
  if (!body) return await response.text();

  const reader = body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!value) continue;
      chunks.push(value);
      total += value.byteLength;
      if (total >= maxBytes) {
        await reader.cancel().catch(() => {});
        break;
      }
    }
  } finally {
    reader.releaseLock?.();
  }

  const buffer = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    buffer.set(chunk, offset);
    offset += chunk.byteLength;
  }

  // Legacy German and Italian sites are still served as ISO-8859-1 more often
  // than you would believe. Decoded as UTF-8 their umlauts become U+FFFD, which
  // corrupts company names and street addresses — but never the ASCII of an
  // email address, so a wrong guess costs cosmetics, not contacts.
  const charset = /charset=["']?([\w-]+)/i.exec(
    response.headers.get("content-type") ?? "",
  )?.[1];
  return decode(buffer, charset);
}

function decode(buffer: Uint8Array, charset?: string): string {
  const label = (charset ?? "utf-8").toLowerCase();
  try {
    return new TextDecoder(label, { fatal: false }).decode(buffer);
  } catch {
    return new TextDecoder("utf-8", { fatal: false }).decode(buffer);
  }
}

const KEPT_HEADERS = [
  "server",
  "x-powered-by",
  "content-type",
  "x-generator",
  "cf-ray",
  "x-shopify-stage",
];

function pickHeaders(headers: Headers): Record<string, string> {
  const out: Record<string, string> = {};
  for (const key of KEPT_HEADERS) {
    const value = headers.get(key);
    if (value) out[key] = value;
  }
  return out;
}

export function pathOf(url: string): string {
  try {
    return new URL(url).pathname || "/";
  } catch {
    return url;
  }
}

export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
