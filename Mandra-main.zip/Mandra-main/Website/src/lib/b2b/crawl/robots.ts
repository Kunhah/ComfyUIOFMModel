import { USER_AGENT, fetchPage } from "./fetch";

/**
 * robots.txt, honoured.
 *
 * Not required by law anywhere we prospect, and skipping it would find a few
 * more addresses. It is here for two reasons that both outrank that. The first
 * is that we are about to email these companies and introduce ourselves — being
 * the crawler that ignored their stated wishes is a bad opening move that they
 * can check. The second is practical: `Disallow` on an industrial site almost
 * always points at `/search`, `/cart`, `/wp-admin` and session-parameter URLs,
 * i.e. exactly the infinite spaces that would otherwise eat the page budget
 * before the crawler ever reaches `/kontakt`.
 *
 * Parsing is the classic REP subset: group by `User-agent`, longest matching
 * rule wins, `*` and `$` supported in paths. A missing or broken file means
 * "allowed", which is what every real crawler does.
 */

export type RobotsRules = {
  /** Allow/Disallow in declaration order; longest match wins at check time. */
  rules: { allow: boolean; pattern: string }[];
  /** Seconds between requests, if the site asked. Clamped when applied. */
  crawlDelay: number | null;
  /** Sitemap URLs, which are a much better page list than guessing paths. */
  sitemaps: string[];
};

const ALLOW_ALL: RobotsRules = { rules: [], crawlDelay: null, sitemaps: [] };

/** One robots.txt per host per process. A crawl hits the same host ~10 times. */
const cache = new Map<string, Promise<RobotsRules>>();

/** The token our User-Agent matches on, lowercased. */
const SELF = USER_AGENT.split("/")[0].toLowerCase();

export function robotsFor(origin: string): Promise<RobotsRules> {
  const cached = cache.get(origin);
  if (cached) return cached;

  const promise = (async () => {
    const result = await fetchPage(`${origin}/robots.txt`, {
      timeoutMs: 6000,
      maxBytes: 200_000,
      attempts: 1,
    });
    // Missing, 404, timed out, or served as HTML by a catch-all router — all of
    // them mean "nobody told us not to".
    if (!result.ok) return ALLOW_ALL;
    if (/<html/i.test(result.page.html.slice(0, 400))) return ALLOW_ALL;
    return parseRobots(result.page.html);
  })().catch(() => ALLOW_ALL);

  cache.set(origin, promise);
  return promise;
}

export function parseRobots(text: string): RobotsRules {
  const groups: {
    agents: string[];
    rules: RobotsRules["rules"];
    delay: number | null;
  }[] = [];
  const sitemaps: string[] = [];

  let current: (typeof groups)[number] | null = null;
  // Consecutive `User-agent` lines share one rule block; the first directive
  // after them ends the header and starts a new group on the next agent line.
  let expectingAgents = false;

  for (const raw of text.split(/\r?\n/)) {
    const line = raw.split("#")[0].trim();
    if (!line) continue;
    const separator = line.indexOf(":");
    if (separator === -1) continue;
    const field = line.slice(0, separator).trim().toLowerCase();
    const value = line.slice(separator + 1).trim();

    if (field === "user-agent") {
      if (!expectingAgents || !current) {
        current = { agents: [], rules: [], delay: null };
        groups.push(current);
        expectingAgents = true;
      }
      current.agents.push(value.toLowerCase());
      continue;
    }

    if (field === "sitemap") {
      sitemaps.push(value);
      continue;
    }

    if (!current) continue;
    expectingAgents = false;

    if (field === "disallow" || field === "allow") {
      // "Disallow:" with an empty value means allow everything — it is not a
      // rule matching every path, and treating it as one blocks the whole site.
      if (field === "disallow" && value === "") continue;
      current.rules.push({ allow: field === "allow", pattern: value });
    } else if (field === "crawl-delay") {
      const seconds = Number(value.replace(",", "."));
      if (Number.isFinite(seconds) && seconds > 0) current.delay = seconds;
    }
  }

  // Our own name beats the wildcard; nothing else applies to us.
  const named = groups.find((g) =>
    g.agents.some((a) => SELF.includes(a) && a !== "*"),
  );
  const wildcard = groups.find((g) => g.agents.includes("*"));
  const group = named ?? wildcard;

  return {
    rules: group?.rules ?? [],
    crawlDelay: group?.delay ?? null,
    sitemaps,
  };
}

/**
 * Longest matching pattern wins, and Allow wins ties — the behaviour every
 * major crawler settled on, so a site tuned against Googlebot behaves here the
 * way its author expected.
 */
export function isAllowed(rules: RobotsRules, pathname: string): boolean {
  let best: { allow: boolean; length: number } | null = null;
  for (const rule of rules.rules) {
    if (!matches(rule.pattern, pathname)) continue;
    const length = rule.pattern.length;
    if (
      !best ||
      length > best.length ||
      (length === best.length && rule.allow)
    ) {
      best = { allow: rule.allow, length };
    }
  }
  return best ? best.allow : true;
}

function matches(pattern: string, pathname: string): boolean {
  if (pattern === "") return false;
  const anchored = pattern.endsWith("$");
  const body = anchored ? pattern.slice(0, -1) : pattern;
  const source =
    "^" +
    body
      .split("*")
      .map((part) => part.replace(/[.+?^${}()|[\]\\]/g, "\\$&"))
      .join(".*") +
    (anchored ? "$" : "");
  try {
    return new RegExp(source).test(pathname);
  } catch {
    return false;
  }
}
