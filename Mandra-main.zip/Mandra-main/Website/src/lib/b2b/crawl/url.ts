/**
 * URL handling for the crawler: what a site *is*, what counts as inside it, and
 * which of its links are worth spending a request on.
 */

/** Never fetched: binaries the extractors can't read, and archives that are huge. */
const BAD_EXTENSIONS =
  /\.(pdf|zip|rar|7z|tar|gz|jpe?g|png|gif|webp|avif|svg|ico|bmp|tiff?|mp4|avi|mov|wmv|mp3|wav|doc|docx|xls|xlsx|ppt|pptx|dwg|dxf|step|stp|iges|igs|exe|dmg|apk|css|js|json|xml|rss|woff2?|ttf|eot)$/i;

/**
 * Paths that a site with no useful navigation might still answer on.
 *
 * Only probed when link discovery came up empty (see the crawler) — blind
 * probing eleven paths on every site would triple the request count to find
 * pages that are, on any competently built site, simply linked from the
 * homepage. The list is multilingual because a German company's contact page
 * is at `/kontakt` and its legally-mandated one at `/impressum`, which is also
 * where the address, the VAT id and the managing director's name live.
 */
export const IMPORTANT_PATHS = [
  "/kontakt",
  "/contact",
  "/impressum",
  "/contact-us",
  "/contatti",
  "/contacto",
  "/contato",
  "/about",
  "/ueber-uns",
  "/unternehmen",
  "/legal-notice",
  "/mentions-legales",
];

/**
 * What makes a link worth following, by keyword, in the languages this tool
 * prospects in. Higher is fetched first.
 *
 * `impressum` outranks everything because it is a legal requirement in
 * Germany, Austria and Switzerland: the page must carry the company's full
 * name, postal address, phone, email, VAT id and the name of whoever runs it.
 * There is no other single page in European B2B that is that dense.
 */
const LINK_KEYWORDS: [RegExp, number][] = [
  [/impressum|imprint|legal-?notice|mentions-?legales|aviso-?legal/i, 100],
  [/kontakt|contact|contatti|contacto|contato|contactez/i, 90],
  [/ansprechpartner|team|management|leitung|direzione|equipe|equipo/i, 70],
  [
    /ueber-?uns|uber-?uns|about|unternehmen|company|chi-?siamo|sobre|empresa|qui-?sommes/i,
    60,
  ],
  [/vertrieb|sales|verkauf|commercial|comercial|ventas|vendite/i, 55],
  [/standort|location|niederlassung|filiale|sedi|sucursal|office/i, 45],
  [/datenschutz|privacy|privacidad|privacidade|termini|terms/i, 25],
];

/** Paths that are always a dead end for contact data, and often infinite. */
const NOISE =
  /(\/wp-(admin|login|json|content|includes)|\/cart|\/checkout|\/basket|\/warenkorb|\/search|\/suche|\/login|\/signin|\/register|\/account|\/feed|\/tag\/|\/category\/|\/product\/|\/produkt\/|\/shop\/|\/download|\/print|\/share|\.php\?|sessionid|utm_)/i;

/**
 * Turn whatever the source called a website into something fetchable, or null.
 *
 * Overture's `websites[0]` is usually clean; a pasted list is anything from
 * "empresa.de" to "www.empresa.de/index.html?lang=de" to a full LinkedIn URL.
 */
export function normaliseWebsite(raw: string): string | null {
  let value = String(raw ?? "").trim();
  if (!value) return null;
  // Strip anything a spreadsheet paste drags along.
  value = value.replace(/^[<("'\s]+|[>)"'\s,;]+$/g, "");
  if (!/^https?:\/\//i.test(value)) {
    if (/^\/\//.test(value)) value = `https:${value}`;
    else value = `https://${value}`;
  }

  let url: URL;
  try {
    url = new URL(value);
  } catch {
    return null;
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") return null;
  if (!url.hostname.includes(".")) return null;
  if (isPrivateHost(url.hostname)) return null;
  // A domain is the entry point, not whatever deep page someone had open when
  // they copied the link — the crawler discovers the rest itself.
  url.hash = "";
  url.search = "";
  if (url.pathname !== "/" && BAD_EXTENSIONS.test(url.pathname))
    url.pathname = "/";
  return url.toString();
}

/** Host without `www.`, lowercased. The dedupe key and the "is this us" test. */
export function domainOf(input: string): string | null {
  try {
    const host = new URL(input).hostname.toLowerCase();
    return host.replace(/^www\./, "") || null;
  } catch {
    return null;
  }
}

/**
 * Refuses to crawl anything on the machine or the private network.
 *
 * Domains reach this from a textarea, so without it "http://localhost:3000" or
 * "http://169.254.169.254/" pasted into the seed list would make the server
 * fetch itself or a cloud metadata endpoint on the operator's behalf.
 */
export function isPrivateHost(hostname: string): boolean {
  const host = hostname.toLowerCase();
  if (
    host === "localhost" ||
    host.endsWith(".localhost") ||
    host.endsWith(".local")
  ) {
    return true;
  }
  if (host === "0.0.0.0" || host === "::1" || host === "[::1]") return true;
  const ipv4 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host);
  if (!ipv4) return false;
  const [a, b] = [Number(ipv4[1]), Number(ipv4[2])];
  return (
    a === 10 ||
    a === 127 ||
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) ||
    (a === 169 && b === 254) ||
    a === 0
  );
}

/** Same company's site: identical domain, or one is a subdomain of the other. */
export function sameSite(domain: string, candidate: string): boolean {
  return (
    domain === candidate ||
    candidate.endsWith(`.${domain}`) ||
    domain.endsWith(`.${candidate}`)
  );
}

export type Link = { url: string; score: number };

/**
 * Internal links worth following, best first.
 *
 * Scoring rather than filtering is what keeps the page budget honest: with a
 * cap of eight pages we want the eight *best* candidates, and on a site whose
 * navigation has sixty entries a filter would hand back the first eight in
 * document order — which is the language switcher and the product categories.
 */
export function rankLinks(
  html: string,
  baseUrl: string,
  domain: string,
): Link[] {
  const seen = new Map<string, number>();
  const anchor = /<a\b([^>]*)>([\s\S]{0,300}?)<\/a\s*>/gi;
  let m: RegExpExecArray | null;

  while ((m = anchor.exec(html))) {
    const href = /href\s*=\s*("([^"]*)"|'([^']*)'|([^\s"'=<>`]+))/i.exec(m[1]);
    if (!href) continue;
    const raw = (href[2] ?? href[3] ?? href[4] ?? "").trim();
    if (!raw || /^(#|mailto:|tel:|javascript:|data:)/i.test(raw)) continue;

    let url: URL;
    try {
      url = new URL(raw, baseUrl);
    } catch {
      continue;
    }
    if (url.protocol !== "http:" && url.protocol !== "https:") continue;

    const host = url.hostname.toLowerCase().replace(/^www\./, "");
    if (!sameSite(domain, host)) continue;
    if (BAD_EXTENSIONS.test(url.pathname)) continue;
    if (NOISE.test(url.pathname + url.search)) continue;

    url.hash = "";
    // Query strings on a contact page are almost always tracking or a language
    // switch; dropping them collapses a dozen near-duplicates into one request.
    url.search = "";
    const normalised = url.toString().replace(/\/$/, "") || url.toString();

    // The anchor's own text carries as much signal as the path — plenty of sites
    // route everything through `/index.php?id=42` and label it "Kontakt".
    const text = m[2].replace(/<[^>]+>/g, " ");
    const score = keywordScore(url.pathname) + keywordScore(text) / 2;
    if (score <= 0) continue;
    // Short paths are the real section pages; long ones are articles about them.
    const depth = url.pathname.split("/").filter(Boolean).length;
    const adjusted = score - depth * 4;

    const previous = seen.get(normalised);
    if (previous === undefined || adjusted > previous) {
      seen.set(normalised, adjusted);
    }
  }

  return [...seen.entries()]
    .map(([url, score]) => ({ url, score }))
    .sort((a, b) => b.score - a.score);
}

function keywordScore(value: string): number {
  let best = 0;
  for (const [re, weight] of LINK_KEYWORDS) {
    if (weight > best && re.test(value)) best = weight;
  }
  return best;
}

export function isBadExtension(pathname: string): boolean {
  return BAD_EXTENSIONS.test(pathname);
}
