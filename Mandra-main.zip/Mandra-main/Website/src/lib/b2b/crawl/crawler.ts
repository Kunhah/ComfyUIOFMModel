import { type CrawledPage, fetchPage, pathOf, sleep } from "./fetch";
import { isAllowed, robotsFor } from "./robots";
import { IMPORTANT_PATHS, domainOf, rankLinks, sameSite } from "./url";

/**
 * One site, crawled.
 *
 * The shape of the crawl is the whole design, and it is deliberately small: a
 * homepage, then the two to seven pages most likely to carry contact details,
 * then stop. An industrial site can have 30.000 product pages and 500 PDFs;
 * none of them contain an address the homepage's footer and the impressum
 * don't. Crawling breadth-first from the root would spend the entire budget in
 * the catalogue and come back with `info@`.
 *
 * So links are *ranked* (see `rankLinks`) and the budget is spent best-first,
 * with a hard ceiling on pages, on wall-clock, and on depth. That is what makes
 * 200 companies a coffee break instead of an afternoon.
 */

export type CrawlOptions = {
  /** Hard ceiling on fetched pages, homepage included. */
  maxPages?: number;
  /** Wall-clock per site, across every request. */
  siteBudgetMs?: number;
  timeoutMs?: number;
  /** Ignoring robots is possible but not the default; see robots.ts. */
  respectRobots?: boolean;
  signal?: AbortSignal;
};

export type CrawlOutcome = {
  pages: CrawledPage[];
  /** robots.txt told us not to. Reported separately from a failure — it is one. */
  blocked: boolean;
  /** Why nothing was fetched, when nothing was. */
  error: string | null;
  elapsedMs: number;
  /** Where we actually ended up, after redirects. Sites move domain. */
  finalDomain: string | null;
};

const DEFAULTS = {
  maxPages: 8,
  siteBudgetMs: 35_000,
  timeoutMs: 12_000,
  respectRobots: true,
};

/** Politeness floor between two requests to the same host. */
const MIN_DELAY_MS = 250;
/** Ceiling on an honoured Crawl-delay. Some sites declare 30s; we'd rather skip. */
const MAX_DELAY_MS = 2000;

export async function crawlSite(
  website: string,
  domain: string,
  options: CrawlOptions = {},
): Promise<CrawlOutcome> {
  const config = { ...DEFAULTS, ...options };
  const started = Date.now();
  const left = () => config.siteBudgetMs - (Date.now() - started);

  const entry = await fetchEntry(website, config.timeoutMs, options.signal);
  if (!entry.ok) {
    return {
      pages: [],
      blocked: false,
      error: entry.error,
      elapsedMs: Date.now() - started,
      finalDomain: null,
    };
  }

  const home = entry.page;
  const finalDomain = domainOf(home.url) ?? domain;
  const origin = new URL(home.url).origin;

  const robots = config.respectRobots
    ? await robotsFor(origin)
    : { rules: [], crawlDelay: null, sitemaps: [] };
  const delay = Math.min(
    MAX_DELAY_MS,
    Math.max(MIN_DELAY_MS, (robots.crawlDelay ?? 0) * 1000),
  );

  // Checked after the fetch rather than before it: the homepage is one request,
  // it is what tells us the final domain and origin, and a site that disallows
  // its own root is nearly always a misconfiguration rather than an objection.
  // Everything *after* this point is gated.
  if (config.respectRobots && !isAllowed(robots, "/")) {
    return {
      pages: [home],
      blocked: true,
      error: "robots.txt bloqueia o crawler",
      elapsedMs: Date.now() - started,
      finalDomain,
    };
  }

  const pages: CrawledPage[] = [home];
  const visited = new Set([canonical(home.url)]);
  const queue = rankLinks(home.html, home.url, finalDomain).filter(
    (link) => !visited.has(canonical(link.url)),
  );

  // Nothing on the homepage looked like a contact page. Either the navigation is
  // an image map, it is rendered in JavaScript, or the links are behind a menu
  // script — all common on sites built in 2011. Guessing a handful of standard
  // paths is the cheap fallback, and it is only paid for by the sites that need it.
  if (!queue.some((link) => link.score >= 55)) {
    for (const path of IMPORTANT_PATHS.slice(0, 6)) {
      const url = `${origin}${path}`;
      if (!visited.has(canonical(url))) queue.push({ url, score: 50 });
    }
  }

  let previousRequestAt = Date.now();

  while (pages.length < config.maxPages && queue.length > 0) {
    if (options.signal?.aborted) break;
    if (left() < config.timeoutMs) break;

    queue.sort((a, b) => b.score - a.score);
    const next = queue.shift();
    if (!next) break;

    const key = canonical(next.url);
    if (visited.has(key)) continue;
    visited.add(key);

    const pathname = pathOf(next.url);
    if (config.respectRobots && !isAllowed(robots, pathname)) continue;

    const wait = delay - (Date.now() - previousRequestAt);
    if (wait > 0) await sleep(wait);
    previousRequestAt = Date.now();

    const result = await fetchPage(next.url, {
      timeoutMs: config.timeoutMs,
      attempts: 1, // the homepage already proved the host answers
      signal: options.signal,
    });
    if (!result.ok) continue;

    // A redirect off-site (to a group parent, a marketplace, a parked domain)
    // is not this company's page and must not contribute its emails.
    const landed = domainOf(result.page.url);
    if (!landed || !sameSite(finalDomain, landed)) continue;

    pages.push(result.page);

    // Depth 2, and only from a page that was itself a strong candidate. This is
    // how `/impressum` gets found when it is linked only from `/kontakt`, without
    // opening the door to walking the whole site.
    if (next.score >= 55 && pages.length < config.maxPages) {
      for (const link of rankLinks(
        result.page.html,
        result.page.url,
        finalDomain,
      )) {
        if (visited.has(canonical(link.url))) continue;
        // Discounted so a second-hop link never outranks a first-hop one of the
        // same kind — breadth first among equals.
        queue.push({ url: link.url, score: link.score * 0.6 });
      }
    }
  }

  return {
    pages,
    blocked: false,
    error: null,
    elapsedMs: Date.now() - started,
    finalDomain,
  };
}

/**
 * Get *some* page for this company.
 *
 * Overture's website field and a pasted list are both full of URLs that were
 * correct years ago: `http://` on a host that now only answers HTTPS, or the
 * apex on a host that only serves `www`. Each variant is one cheap request and
 * recovers a company that would otherwise be reported unreachable.
 */
async function fetchEntry(
  website: string,
  timeoutMs: number,
  signal?: AbortSignal,
): Promise<{ ok: true; page: CrawledPage } | { ok: false; error: string }> {
  const variants: string[] = [];
  const push = (url: string) => {
    if (!variants.includes(url)) variants.push(url);
  };

  push(website);
  try {
    const url = new URL(website);
    const host = url.hostname;
    const toggled = host.startsWith("www.") ? host.slice(4) : `www.${host}`;
    push(`${url.protocol}//${toggled}${url.pathname}`);
    if (url.protocol === "https:") {
      push(`http://${host}${url.pathname}`);
    }
  } catch {
    /* `website` was validated upstream; a parse failure here just means no variants */
  }

  let error = "sem resposta";
  for (const variant of variants) {
    if (signal?.aborted) return { ok: false, error: "cancelado" };
    const result = await fetchPage(variant, { timeoutMs, attempts: 2, signal });
    if (result.ok) return { ok: true, page: result.page };
    error = result.error;
    // A 404 on the apex still proves the host is alive and serving; trying the
    // www variant is pointless once we have an HTTP answer of any kind.
    if (result.status >= 400 && result.status < 500) break;
  }
  return { ok: false, error };
}

/** Same page, one entry: scheme-, case- and trailing-slash-insensitive. */
function canonical(url: string): string {
  try {
    const parsed = new URL(url);
    const path = parsed.pathname.replace(/\/+$/, "") || "/";
    return `${parsed.hostname.toLowerCase().replace(/^www\./, "")}${path}`;
  } catch {
    return url;
  }
}
