/**
 * The B2B half's view of the country table.
 *
 * The table itself moved to `src/lib/countries.ts` when the local-business
 * prospector started prospecting outside Brazil and needed the same bounding
 * boxes and dial codes. Two copies would have drifted the first time one was
 * corrected, and a wrong bbox is a silent bug: the scan simply returns fewer
 * companies. What stays here is what only the crawler cares about — recognising
 * a company's country from a bare domain or a phone number found on its page.
 */
import {
  COUNTRIES,
  type Country,
  findCountry,
  countryLabel,
  normaliseCountries,
  unionBbox,
} from "../countries";

export { COUNTRIES, findCountry, countryLabel, normaliseCountries, unionBbox };
export type { Country };

/** The default selection: the industrial core of Europe. */
export const EUROPE = COUNTRIES.filter((c) =>
  [
    "DE",
    "AT",
    "CH",
    "NL",
    "BE",
    "LU",
    "FR",
    "IT",
    "ES",
    "PT",
    "GB",
    "IE",
    "DK",
    "SE",
    "NO",
    "FI",
    "PL",
    "CZ",
    "SK",
    "HU",
    "RO",
    "SI",
    "HR",
    "EE",
    "LV",
    "LT",
    "GR",
    "BG",
    "TR",
  ].includes(c.code),
).map((c) => c.code);

/**
 * Best guess at the country of a site we only know by domain — the seed-list
 * path, where nobody told us. ccTLD only; a .com says nothing and stays null
 * rather than becoming a wrong flag on the row.
 */
export function countryFromDomain(domain: string): string | null {
  const host = domain.toLowerCase();
  let best: Country | null = null;
  let bestLen = 0;
  for (const country of COUNTRIES) {
    for (const tld of country.tlds) {
      if (host.endsWith(tld) && tld.length > bestLen) {
        best = country;
        bestLen = tld.length;
      }
    }
  }
  return best?.code ?? null;
}

/** Country of an international phone number, longest prefix wins (`+1` vs `+351`). */
export function countryFromPhone(phone: string): string | null {
  const digits = phone.replace(/\D/g, "");
  let best: Country | null = null;
  let bestLen = 0;
  for (const country of COUNTRIES) {
    if (digits.startsWith(country.dial) && country.dial.length > bestLen) {
      best = country;
      bestLen = country.dial.length;
    }
  }
  return best?.code ?? null;
}
