import { ticketForSector } from "./sectors";
import type { FoundEmail, Prospect } from "./types";

/**
 * How good a prospect this company is, 0–100.
 *
 * The prospector's score answers "does this business need a website?" — one
 * question with one obvious signal. This one answers a harder one: *can I start
 * a conversation, and is there anything worth selling at the end of it?* Those
 * are separate axes and the score is their sum:
 *
 *   contato    — is there a route to a human who can say yes. A named person or
 *                a director outranks `sales@`, which outranks `info@`, which
 *                outranks nothing. This dominates, because a company with no
 *                reachable address is not a lead at any deal size.
 *   evidência  — VAT id, register entry, head-count, LinkedIn. Proof the company
 *                is real, trading and big enough to buy something.
 *   oportunidade — what the site says about the gap. No analytics and no CRM
 *                means the commercial operation runs on an inbox; a stack from
 *                2012 means nobody has looked at it in a decade. Both are the
 *                actual pitch.
 *   ticket     — a prior from the sector, which only breaks ties. It is the
 *                widest of the four bands (-10 to +10) because the registry now
 *                spans a print shop and a hospital group, and two prospects that
 *                are otherwise identical are not worth the same call.
 *
 * The reasons are pt-BR and go straight onto the row, so the number is never
 * something you have to take on faith.
 */

const MARKETING_STACK = [
  "Google Analytics",
  "Google Tag Manager",
  "Matomo",
  "HubSpot",
  "Salesforce Pardot",
  "Facebook Pixel",
  "LinkedIn Insight",
  "Mailchimp",
  "Intercom",
  "Zendesk",
];

const LEGACY_STACK = [
  "jQuery",
  "ASP.NET",
  "TYPO3",
  "Joomla",
  "Contao",
  "Wix",
  "Jimdo",
];
const MODERN_STACK = [
  "Next.js",
  "React",
  "Vue",
  "Angular",
  "Webflow",
  "Shopify",
];

/** Contact value of the best address found, by who it reaches. */
const CATEGORY_POINTS: Record<FoundEmail["category"], number> = {
  pessoal: 34,
  diretoria: 32,
  vendas: 26,
  compras: 24,
  engenharia: 24,
  marketing: 18,
  geral: 16,
  suporte: 10,
  rh: 6,
};

type Scorable = Omit<Prospect, "score" | "reasons">;

export function scoreProspect(prospect: Scorable): {
  score: number;
  reasons: string[];
} {
  const reasons: string[] = [];
  let score = 0;

  // --- contato --------------------------------------------------------------
  const best = prospect.emails[0];
  if (best) {
    score += CATEGORY_POINTS[best.category];
    reasons.push(labelForCategory(best.category));
    if (prospect.emails.length >= 3) {
      score += 6;
      reasons.push(`${prospect.emails.length} e-mails`);
    } else if (prospect.emails.length === 2) {
      score += 3;
    }
    // A named human anywhere in the list, even when a role address scored
    // higher, is worth flagging: it is the address you personalise.
    if (
      best.category !== "pessoal" &&
      prospect.emails.some((e) => e.category === "pessoal")
    ) {
      score += 5;
      reasons.push("contato nominal");
    }
  } else {
    reasons.push("sem e-mail");
  }

  if (prospect.phones.length > 0) score += 7;
  if (prospect.socials.linkedin) {
    score += 7;
    reasons.push("LinkedIn");
  } else if (prospect.socials.xing) {
    // Worth less than LinkedIn and worth more than nothing: in DACH — where most
    // of this registry's companies are — Xing is the network the older
    // industrial firms actually kept, and a profile there is still a named human
    // and a confirmation the company is staffed.
    score += 4;
    reasons.push("Xing");
  }

  // --- evidência ------------------------------------------------------------
  if (prospect.vat || prospect.registration) {
    score += 8;
    reasons.push("registro fiscal");
  }
  if (prospect.employees) {
    score += 5;
    reasons.push(`${prospect.employees} func.`);
  }
  if (prospect.address) score += 4;
  if (prospect.languages.length >= 3) {
    // A site in three languages is a company that already sells across borders,
    // which is both a bigger operation and one used to buying from abroad.
    score += 5;
    reasons.push("site multilíngue");
  }

  // --- oportunidade ---------------------------------------------------------
  const technologies = prospect.technologies;
  const hasMarketing = technologies.some((t) => MARKETING_STACK.includes(t));
  const legacy = technologies.some((t) => LEGACY_STACK.includes(t));
  const modern = technologies.some((t) => MODERN_STACK.includes(t));

  if (technologies.length > 0 && !hasMarketing) {
    score += 10;
    reasons.push("sem rastreamento/CRM");
  }
  if (legacy && !modern) {
    score += 8;
    reasons.push("site legado");
  }
  if (!prospect.website.startsWith("https://")) {
    score += 4;
    reasons.push("sem HTTPS");
  }

  // --- ticket ---------------------------------------------------------------
  // Centred on 3, the middle of the 1–5 scale, so a mid-ticket sector neither
  // pays nor costs and only the ends move a row.
  const ticket = ticketForSector(prospect.sector);
  score += (ticket - 3) * 5;
  // Said out loud on the row, because "why is this metal fabricator above a
  // software house with the same director's address" is otherwise a mystery the
  // operator has to take on faith — the one thing the reasons exist to prevent.
  if (ticket >= 5) reasons.push("setor de ticket máximo");
  else if (ticket === 4) reasons.push("setor de ticket alto");

  return { score: Math.max(0, Math.min(100, Math.round(score))), reasons };
}

function labelForCategory(category: FoundEmail["category"]): string {
  switch (category) {
    case "pessoal":
      return "e-mail pessoal";
    case "diretoria":
      return "e-mail da diretoria";
    case "vendas":
      return "e-mail comercial";
    case "compras":
      return "e-mail de compras";
    case "engenharia":
      return "e-mail de engenharia";
    case "marketing":
      return "e-mail de marketing";
    case "suporte":
      return "e-mail de suporte";
    case "rh":
      return "e-mail de RH";
    default:
      return "e-mail geral";
  }
}

export function sortProspects(prospects: Prospect[]): Prospect[] {
  return [...prospects].sort(
    (a, b) =>
      b.score - a.score ||
      // Ties are common at the top (a director's address on a registered
      // company with a legacy site tops out fast), so the tiebreak decides what
      // you actually work first: more contacts means more ways in.
      b.emails.length - a.emails.length ||
      a.name.localeCompare(b.name),
  );
}

/**
 * The opening line for a cold email, in the language of the country.
 *
 * Deliberately short and specific: it names what we saw on their site, which is
 * the only thing that separates this from the twenty other agency mails that
 * company gets a week. The user edits it before sending — this is a starting
 * point, not an autopilot.
 */
export function outreachSubject(prospect: Prospect, language: string): string {
  const name = prospect.name;
  switch (language) {
    case "de":
      return `Kurze Frage zur Website von ${name}`;
    case "fr":
      return `Question rapide sur le site de ${name}`;
    case "it":
      return `Una domanda sul sito di ${name}`;
    case "es":
      return `Una pregunta sobre la web de ${name}`;
    case "pt":
      return `Uma pergunta sobre o site da ${name}`;
    default:
      return `Quick question about ${name}'s website`;
  }
}
