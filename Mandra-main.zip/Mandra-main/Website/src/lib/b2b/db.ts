import { mkdirSync } from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { fold } from "./overture";
import { sectorFingerprint, sectorForCategory } from "./sectors";
import type {
  FoundEmail,
  OutreachStatus,
  Prospect,
  ProspectStatus,
  Socials,
  StoredProspect,
} from "./types";

/**
 * The B2B history, in its own SQLite file.
 *
 * `node:sqlite` for the same reasons as the prospector's history — it ships
 * with Node, so there is no dependency, no native build and nothing for
 * `serverExternalPackages` — but a *separate* file (`data/b2b.db`), not extra
 * tables in `prospector.db`. The two share no columns, no id space and no
 * lifecycle, and the prospector's database re-derives every row's niche on open;
 * bolting an unrelated schema onto that means one tool's migration can break the
 * other's startup.
 *
 * Why a history matters more here than there: a crawl is expensive. Re-running
 * a sector over a country would otherwise re-fetch a few hundred sites to
 * rediscover addresses we already had. `knownDomains()` is what lets a run skip
 * them, and it is the single biggest saving in the whole pipeline.
 */

const SCHEMA = `
  CREATE TABLE IF NOT EXISTS companies (
    -- The domain, not a provider id: the same company arrives from Overture with
    -- a GERS id and from a pasted list with nothing, and both must collapse onto
    -- one row. Its website is the only identity both paths share.
    domain          TEXT PRIMARY KEY,
    place_id        TEXT,
    name            TEXT NOT NULL,
    website         TEXT NOT NULL,
    sector          TEXT,
    category        TEXT,
    country         TEXT,
    city            TEXT,
    region          TEXT,
    address         TEXT,
    postal_code     TEXT,
    phone           TEXT,
    vat             TEXT,
    registration    TEXT,
    employees       TEXT,
    -- Comma-separated. These are display lists, never joined or filtered on, so
    -- a child table would be three more queries for no gained ability.
    languages       TEXT,
    technologies    TEXT,
    linkedin        TEXT,
    xing            TEXT,
    facebook        TEXT,
    instagram       TEXT,
    youtube         TEXT,
    twitter         TEXT,
    -- Denormalised from the emails table so the board can sort and filter without
    -- a join per row. The emails table stays the source of truth.
    email_count     INTEGER NOT NULL DEFAULT 0,
    best_email      TEXT,
    best_category   TEXT,
    score           INTEGER NOT NULL DEFAULT 0,
    reasons         TEXT,
    pages           INTEGER NOT NULL DEFAULT 0,
    crawl_ms        INTEGER,
    status          TEXT NOT NULL DEFAULT 'pendente',
    error           TEXT,
    outreach        TEXT NOT NULL DEFAULT 'novo'
                    CHECK (outreach IN ('novo','contatado','respondeu','cliente','descartado')),
    notes           TEXT,
    contacted_at    TEXT,
    -- Name, city and domain folded by the same fold() the discovery query uses,
    -- so free-text search matches "muenchen" against "München".
    search_norm     TEXT,
    -- ISO-8601 UTC with milliseconds. datetime('now') resolves to whole seconds
    -- and prints no zone marker, which makes two runs in the same second
    -- indistinguishable.
    first_seen_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    last_seen_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  CREATE TABLE IF NOT EXISTS emails (
    domain          TEXT NOT NULL,
    address         TEXT NOT NULL,
    score           INTEGER NOT NULL DEFAULT 0,
    category        TEXT,
    source          TEXT,
    page            TEXT,
    first_seen_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    PRIMARY KEY (domain, address),
    FOREIGN KEY (domain) REFERENCES companies(domain) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
`;

/**
 * Applied after `addMissingColumns()`, never with the table — an index on a
 * column an older file doesn't have throws, and that kills the whole schema
 * statement before the column can be added. That failure mode leaves the table
 * permanently one migration behind, which is the prospector's hardest-won lesson.
 */
const INDEXES = `
  CREATE INDEX IF NOT EXISTS companies_score ON companies (score DESC);
  CREATE INDEX IF NOT EXISTS companies_sector ON companies (sector, country);
  CREATE INDEX IF NOT EXISTS companies_outreach ON companies (outreach);
  CREATE INDEX IF NOT EXISTS companies_search ON companies (search_norm);
  CREATE INDEX IF NOT EXISTS emails_domain ON emails (domain, score DESC);
`;

export function databasePath(): string {
  return process.env.B2B_DB ?? path.join(process.cwd(), "data", "b2b.db");
}

let db: DatabaseSync | null = null;

export function getDb(): DatabaseSync {
  if (db) return db;

  const file = databasePath();
  mkdirSync(path.dirname(file), { recursive: true });
  const handle = new DatabaseSync(file);

  handle.exec("PRAGMA journal_mode = WAL");
  handle.exec("PRAGMA synchronous = NORMAL");
  handle.exec("PRAGMA foreign_keys = ON");
  handle.exec(SCHEMA);
  addMissingColumns(handle);
  handle.exec(INDEXES);
  resector(handle);

  db = handle;
  return db;
}

/**
 * Additive catch-up for a file created by an older build. Additive only: no
 * renames, no type changes, no drops. People are told they can keep this file,
 * so a new column must never be a reason to delete it.
 */
function addMissingColumns(handle: DatabaseSync): void {
  const existing = new Set(
    (
      handle.prepare("PRAGMA table_info(companies)").all() as { name: string }[]
    ).map((c) => c.name),
  );
  const additive: { name: string; ddl: string }[] = [
    {
      name: "crawl_ms",
      ddl: "ALTER TABLE companies ADD COLUMN crawl_ms INTEGER",
    },
  ];
  for (const column of additive) {
    if (!existing.has(column.name)) handle.exec(column.ddl);
  }
}

/**
 * Re-derives every stored sector from the company's category when the registry
 * has changed. Without it, renaming or splitting a sector leaves the history
 * full of slugs that no longer exist, and a sector you have hundreds of
 * companies in reads as empty. Same mechanism as `reniche()` on the prospector.
 */
function resector(handle: DatabaseSync): void {
  const KEY = "sector_fingerprint";
  const current = sectorFingerprint();
  const stored = handle
    .prepare("SELECT value FROM meta WHERE key = ?")
    .get(KEY) as { value: string } | undefined;
  if (stored?.value === current) return;

  const categories = handle
    .prepare(
      "SELECT DISTINCT category FROM companies WHERE category IS NOT NULL",
    )
    .all() as { category: string }[];

  handle.exec("BEGIN");
  try {
    const update = handle.prepare(
      "UPDATE companies SET sector = ? WHERE category = ? AND sector IS NOT ?",
    );
    for (const { category } of categories) {
      const slug = sectorForCategory(category);
      if (slug) update.run(slug, category, slug);
    }
    handle
      .prepare(
        "INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
      )
      .run(KEY, current);
    handle.exec("COMMIT");
  } catch (err) {
    handle.exec("ROLLBACK");
    throw err;
  }
}

export type PersistResult = {
  inserted: number;
  alreadyKnown: number;
  /** Domains not previously stored, so the board can mark them. */
  newDomains: string[];
};

/**
 * Upsert a batch of crawled companies and their addresses.
 *
 * `first_seen_at` is never overwritten — it is the whole point of the file.
 * Emails are inserted, never deleted: an address that disappeared from the site
 * after a redesign is still an address that worked, and losing it because a
 * later crawl was blocked would be the worst possible failure here.
 *
 * Returns null on failure rather than throwing. A database problem should cost
 * the new/known badges, not the twenty minutes of crawling you just did.
 */
export function persistProspects(prospects: Prospect[]): {
  result: PersistResult | null;
  warning?: string;
} {
  if (prospects.length === 0) {
    return { result: { inserted: 0, alreadyKnown: 0, newDomains: [] } };
  }

  try {
    const handle = getDb();

    // Read the existing keys before writing; the upsert erases the distinction.
    // Chunked to stay under SQLite's 999-variable default.
    const known = new Set<string>();
    for (let i = 0; i < prospects.length; i += 400) {
      const chunk = prospects.slice(i, i + 400);
      const holes = chunk.map(() => "?").join(",");
      const rows = handle
        .prepare(`SELECT domain FROM companies WHERE domain IN (${holes})`)
        .all(...chunk.map((p) => p.domain)) as { domain: string }[];
      for (const row of rows) known.add(row.domain);
    }

    const upsert = handle.prepare(`
      INSERT INTO companies (
        domain, place_id, name, website, sector, category, country, city, region,
        address, postal_code, phone, vat, registration, employees, languages,
        technologies, linkedin, xing, facebook, instagram, youtube, twitter,
        email_count, best_email, best_category, score, reasons, pages, crawl_ms,
        status, error, search_norm
      ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
      )
      ON CONFLICT(domain) DO UPDATE SET
        place_id = coalesce(excluded.place_id, companies.place_id),
        name = excluded.name,
        website = excluded.website,
        sector = coalesce(excluded.sector, companies.sector),
        category = coalesce(excluded.category, companies.category),
        country = coalesce(excluded.country, companies.country),
        city = coalesce(excluded.city, companies.city),
        region = coalesce(excluded.region, companies.region),
        address = coalesce(excluded.address, companies.address),
        postal_code = coalesce(excluded.postal_code, companies.postal_code),
        phone = coalesce(excluded.phone, companies.phone),
        vat = coalesce(excluded.vat, companies.vat),
        registration = coalesce(excluded.registration, companies.registration),
        employees = coalesce(excluded.employees, companies.employees),
        languages = excluded.languages,
        technologies = excluded.technologies,
        linkedin = coalesce(excluded.linkedin, companies.linkedin),
        xing = coalesce(excluded.xing, companies.xing),
        facebook = coalesce(excluded.facebook, companies.facebook),
        instagram = coalesce(excluded.instagram, companies.instagram),
        youtube = coalesce(excluded.youtube, companies.youtube),
        twitter = coalesce(excluded.twitter, companies.twitter),
        email_count = excluded.email_count,
        best_email = coalesce(excluded.best_email, companies.best_email),
        best_category = coalesce(excluded.best_category, companies.best_category),
        score = excluded.score,
        reasons = excluded.reasons,
        pages = excluded.pages,
        crawl_ms = excluded.crawl_ms,
        -- A crawl that failed this time must not erase what a successful one
        -- found before: the row keeps its old status unless the new one is better.
        status = CASE WHEN excluded.email_count > 0 OR companies.email_count = 0
                      THEN excluded.status ELSE companies.status END,
        error = excluded.error,
        search_norm = excluded.search_norm,
        last_seen_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
    `);

    const insertEmail = handle.prepare(`
      INSERT INTO emails (domain, address, score, category, source, page)
      VALUES (?, ?, ?, ?, ?, ?)
      ON CONFLICT(domain, address) DO UPDATE SET
        score = max(excluded.score, emails.score),
        category = excluded.category,
        source = excluded.source,
        page = excluded.page
    `);

    handle.exec("BEGIN");
    try {
      for (const p of prospects) {
        const best = p.emails[0] ?? null;
        upsert.run(
          p.domain,
          p.source === "overture" ? p.id : null,
          p.name,
          p.website,
          p.sector,
          p.category,
          p.country,
          p.city,
          p.region,
          p.address,
          p.postalCode,
          p.phones[0] ?? p.phone,
          p.vat,
          p.registration,
          p.employees,
          p.languages.join(","),
          p.technologies.join(","),
          p.socials.linkedin,
          p.socials.xing,
          p.socials.facebook,
          p.socials.instagram,
          p.socials.youtube,
          p.socials.twitter,
          p.emails.length,
          best?.address ?? null,
          best?.category ?? null,
          p.score,
          p.reasons.join("; "),
          p.pages,
          p.crawlMs,
          p.status,
          p.error,
          fold(`${p.name} ${p.city ?? ""} ${p.domain}`),
        );
        for (const email of p.emails) {
          insertEmail.run(
            p.domain,
            email.address,
            email.score,
            email.category,
            email.source,
            email.page,
          );
        }
      }
      handle.exec("COMMIT");
    } catch (err) {
      handle.exec("ROLLBACK");
      throw err;
    }

    const newDomains = prospects
      .map((p) => p.domain)
      .filter((domain) => !known.has(domain));
    return {
      result: {
        inserted: newDomains.length,
        alreadyKnown: known.size,
        newDomains,
      },
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return {
      result: null,
      warning: `Não foi possível salvar o histórico: ${message}`,
    };
  }
}

/** How many companies have been crawled, for the header. */
export function companyCount(): number {
  try {
    const row = getDb().prepare("SELECT count(*) AS n FROM companies").get() as
      { n: number } | undefined;
    return Number(row?.n ?? 0);
  } catch {
    return 0;
  }
}

/** Companies with at least one address — the part of the history worth exporting. */
export function contactableCount(): number {
  try {
    const row = getDb()
      .prepare("SELECT count(*) AS n FROM companies WHERE email_count > 0")
      .get() as { n: number } | undefined;
    return Number(row?.n ?? 0);
  } catch {
    return 0;
  }
}

/**
 * Domains the history already has, for two different questions.
 *
 * `withEmailOnly` is what a run skips: a company that was unreachable last week
 * may well answer today and a re-crawl costs one request, while one that already
 * gave us four addresses has nothing left to give. The full set answers the
 * other question — "is this row new?" — which has to be asked before the run
 * writes anything, or every row looks new.
 */
export function knownDomains(withEmailOnly = true): Set<string> {
  try {
    const rows = getDb()
      .prepare(
        `SELECT domain FROM companies${withEmailOnly ? " WHERE email_count > 0" : ""}`,
      )
      .all() as { domain: string }[];
    return new Set(rows.map((r) => r.domain));
  } catch {
    return new Set();
  }
}

export type StoredFilters = {
  q?: string;
  sector?: string;
  country?: string;
  outreach?: OutreachStatus;
  minScore?: number;
  onlyWithEmail?: boolean;
  limit?: number;
};

type CompanyRow = {
  domain: string;
  place_id: string | null;
  name: string;
  website: string;
  sector: string | null;
  category: string | null;
  country: string | null;
  city: string | null;
  region: string | null;
  address: string | null;
  postal_code: string | null;
  phone: string | null;
  vat: string | null;
  registration: string | null;
  employees: string | null;
  languages: string | null;
  technologies: string | null;
  linkedin: string | null;
  xing: string | null;
  facebook: string | null;
  instagram: string | null;
  youtube: string | null;
  twitter: string | null;
  score: number;
  reasons: string | null;
  pages: number;
  crawl_ms: number | null;
  status: string;
  error: string | null;
  outreach: string;
  first_seen_at: string;
  last_seen_at: string;
};

/** Read the history back, best first. Used by the "export everything" path. */
export function queryStored(filters: StoredFilters = {}): StoredProspect[] {
  const clauses: string[] = [];
  const params: (string | number)[] = [];

  const needle = fold(filters.q ?? "");
  if (needle) {
    clauses.push("instr(search_norm, ?) > 0");
    params.push(needle);
  }
  if (filters.sector) {
    clauses.push("sector = ?");
    params.push(filters.sector);
  }
  if (filters.country) {
    clauses.push("country = ?");
    params.push(filters.country.toUpperCase());
  }
  if (filters.outreach) {
    clauses.push("outreach = ?");
    params.push(filters.outreach);
  }
  if (typeof filters.minScore === "number") {
    clauses.push("score >= ?");
    params.push(filters.minScore);
  }
  if (filters.onlyWithEmail !== false) clauses.push("email_count > 0");

  const where = clauses.length > 0 ? `WHERE ${clauses.join(" AND ")}` : "";
  const limit = Math.max(
    1,
    Math.min(50_000, Math.trunc(filters.limit ?? 10_000)),
  );

  const handle = getDb();
  const rows = handle
    .prepare(
      `SELECT * FROM companies ${where} ORDER BY score DESC, name LIMIT ${limit}`,
    )
    .all(...params) as unknown as CompanyRow[];
  if (rows.length === 0) return [];

  // One query for every address, grouped in JS. Per-company queries would be a
  // round trip each; there is no join because the board needs them nested anyway.
  const emails = new Map<string, FoundEmail[]>();
  for (let i = 0; i < rows.length; i += 400) {
    const chunk = rows.slice(i, i + 400);
    const holes = chunk.map(() => "?").join(",");
    const found = handle
      .prepare(
        `SELECT domain, address, score, category, source, page FROM emails
         WHERE domain IN (${holes}) ORDER BY score DESC`,
      )
      .all(...chunk.map((r) => r.domain)) as unknown as ({
      domain: string;
    } & FoundEmail)[];
    for (const row of found) {
      const list = emails.get(row.domain) ?? [];
      list.push({
        address: row.address,
        score: row.score,
        category: row.category,
        source: row.source,
        page: row.page,
      });
      emails.set(row.domain, list);
    }
  }

  return rows.map((row) => toStored(row, emails.get(row.domain) ?? []));
}

function toStored(row: CompanyRow, emails: FoundEmail[]): StoredProspect {
  const socials: Socials = {
    linkedin: row.linkedin,
    xing: row.xing,
    facebook: row.facebook,
    instagram: row.instagram,
    youtube: row.youtube,
    twitter: row.twitter,
  };
  return {
    id: row.place_id ?? row.domain,
    name: row.name,
    website: row.website,
    domain: row.domain,
    country: row.country,
    city: row.city,
    region: row.region,
    address: row.address,
    postalCode: row.postal_code,
    phone: row.phone,
    category: row.category,
    sector: row.sector,
    source: row.place_id ? "overture" : "lista",
    emails,
    phones: row.phone ? [row.phone] : [],
    socials,
    vat: row.vat,
    registration: row.registration,
    employees: row.employees,
    languages: split(row.languages),
    technologies: split(row.technologies),
    score: row.score,
    reasons: row.reasons ? row.reasons.split("; ").filter(Boolean) : [],
    pages: row.pages,
    crawlMs: row.crawl_ms ?? 0,
    status: row.status as ProspectStatus,
    error: row.error,
    outreach: row.outreach as OutreachStatus,
    firstSeenAt: row.first_seen_at,
    lastSeenAt: row.last_seen_at,
  };
}

function split(value: string | null): string[] {
  return value ? value.split(",").filter(Boolean) : [];
}

/** Move a company along the pipeline. */
export function setOutreach(domain: string, outreach: OutreachStatus): boolean {
  try {
    const handle = getDb();
    const result = handle
      .prepare(
        `UPDATE companies SET outreach = ?,
           contacted_at = CASE WHEN ? = 'contatado' AND contacted_at IS NULL
                               THEN strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
                               ELSE contacted_at END
         WHERE domain = ?`,
      )
      .run(outreach, outreach, domain);
    return Number(result.changes) > 0;
  } catch {
    return false;
  }
}
