/**
 * The B2B side of the tool, in one vocabulary.
 *
 * The prospector's `Lead` is a *place*: a business with an address and a phone,
 * scored on whether it lacks a website. This is the inverse — a company we can
 * only reach because it *has* a website, scored on whether that site puts a
 * human being's inbox in front of us. Sharing the Lead type would have meant a
 * dozen nullable fields that mean nothing on either side, so the two stay apart
 * and only the plumbing (SQLite, CSV, the tone block) is shared.
 */

/** Who an address most likely reaches. Drives the ordering of the contact list. */
export type EmailCategory =
  | "diretoria"
  | "vendas"
  | "compras"
  | "engenharia"
  | "marketing"
  | "suporte"
  | "rh"
  | "geral"
  | "pessoal";

/**
 * Where in the page the address was found. Kept because it is evidence of
 * quality, not trivia: an address behind `mailto:` on /contact was put there for
 * strangers to use, one scraped out of a minified bundle very often was not.
 */
export type EmailSource =
  | "mailto"
  | "jsonld"
  | "desofuscado"
  | "cloudflare"
  | "meta"
  | "script"
  | "comentario"
  | "texto";

export type FoundEmail = {
  /** Lowercased, deduped. */
  address: string;
  /** 0–100. See `scoreEmail` — the top one is the address you actually write to. */
  score: number;
  category: EmailCategory;
  source: EmailSource;
  /** Path it was found on, e.g. "/impressum". Relative to the site root. */
  page: string;
};

/**
 * A company before we have looked at its site: name, domain and whatever the
 * discovery source knew. Both discovery modes normalise to this, so the crawler
 * never learns where its work came from.
 */
export type Candidate = {
  /**
   * Stable identity. Overture's GERS id when discovery found it, otherwise the
   * domain — which is also the dedupe key across both modes, since the same
   * company found twice must not be crawled twice.
   */
  id: string;
  name: string;
  /** Absolute, with scheme. The crawler's entry point. */
  website: string;
  /** Registrable-ish host, lowercased, `www.` stripped. The dedupe key. */
  domain: string;
  /** ISO-3166 alpha-2, when known. */
  country: string | null;
  city: string | null;
  /** State/province/Bundesland, free text as the source gave it. */
  region: string | null;
  address: string | null;
  phone: string | null;
  /** Overture `categories.primary`, when discovery was Overture. */
  category: string | null;
  /** Our sector registry slug. */
  sector: string | null;
  source: "overture" | "lista";
};

/** Outcome of a crawl, so the board can separate "no emails" from "never loaded". */
export type ProspectStatus =
  "ok" | "sem_email" | "inacessivel" | "bloqueado" | "pendente";

export type Socials = {
  linkedin: string | null;
  xing: string | null;
  facebook: string | null;
  instagram: string | null;
  youtube: string | null;
  twitter: string | null;
};

/** A candidate after the crawler and the extractors have run over it. */
export type Prospect = Candidate & {
  /** Best first. The first row is the address to write to. */
  emails: FoundEmail[];
  phones: string[];
  socials: Socials;
  /** EU VAT id, e.g. "DE123456789". Strong evidence the company is real and trading. */
  vat: string | null;
  /** Commercial register entry, e.g. "HRB 123456". */
  registration: string | null;
  postalCode: string | null;
  /** Head-count as the site states it, e.g. "120" or "51-200". Never inferred. */
  employees: string | null;
  /** Languages the site offers, from `lang`/`hreflang`. Tells you how to open. */
  languages: string[];
  /** Fingerprinted from the markup — WordPress, HubSpot, Shopify… */
  technologies: string[];
  /** 0–100. How good a prospect this is for Mandra; see `scoreProspect`. */
  score: number;
  /** Short pt-BR phrases behind the score, shown on the row. */
  reasons: string[];
  /** Pages actually fetched. Two or three is normal; one means the site fought back. */
  pages: number;
  crawlMs: number;
  status: ProspectStatus;
  /** Populated when `status` is not "ok"/"sem_email". */
  error: string | null;
  /** Absent when the history write failed, so the board can say "don't know". */
  isNew?: boolean;
};

/** A prospect read back out of SQLite, with the bookkeeping a fresh crawl can't know. */
export type StoredProspect = Prospect & {
  outreach: OutreachStatus;
  firstSeenAt: string;
  lastSeenAt: string;
};

/** Outreach state. Mirrors the CHECK constraint on `companies.outreach`. */
export type OutreachStatus =
  "novo" | "contatado" | "respondeu" | "cliente" | "descartado";

export const OUTREACH_STATUSES: OutreachStatus[] = [
  "novo",
  "contatado",
  "respondeu",
  "cliente",
  "descartado",
];

export type DiscoverRequest = {
  sector: string;
  /** ISO-3166 alpha-2 codes. Empty means every country in the registry. */
  countries: string[];
  /** Free text matched against the locality, folded the same way both sides. */
  city?: string;
  limit?: number;
};

export type DiscoverResponse = {
  candidates: Candidate[];
  stats: {
    /** Companies matching sector+country before the "has a website" filter. */
    matched: number;
    withWebsite: number;
    /** After collapsing duplicate domains — several plants share one site. */
    uniqueDomains: number;
    returned: number;
    elapsedMs: number;
  };
  warnings: string[];
};

/** One line of the enrich stream. NDJSON, so a long crawl reports as it goes. */
export type EnrichEvent =
  | { type: "start"; total: number }
  | { type: "prospect"; prospect: Prospect; done: number; total: number }
  | {
      type: "done";
      total: number;
      withEmail: number;
      unreachable: number;
      elapsedMs: number;
      persisted: { inserted: number; alreadyKnown: number } | null;
      warnings: string[];
    }
  | { type: "error"; error: string };
