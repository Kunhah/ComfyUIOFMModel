import { crawlSite } from "./crawl/crawler";
import { knownDomains, persistProspects } from "./db";
import { extractCompany } from "./extract/company";
import { extractEmails, mergeEmails } from "./extract/emails";
import { scoreProspect } from "./score";
import type { Candidate, EnrichEvent, Prospect } from "./types";

/**
 * The pipeline: candidates in, scored prospects out, one at a time.
 *
 * It is a generator rather than a function returning an array for one reason,
 * and it is the reason the tool is usable at all: crawling 200 sites takes
 * minutes, and a request that answers only at the end looks identical to a
 * request that has hung. Yielding each company as it finishes lets the route
 * stream NDJSON and the board fill in live — you can start writing to the first
 * good lead while the rest is still running.
 *
 * Concurrency is across *companies*, never within one. Eight sites in flight
 * with one request each is polite to every host involved; eight requests into
 * one small industrial server is not, and the crawler already paces itself
 * per host on top of this.
 */

export type EnrichOptions = {
  /** Sites in flight at once. */
  concurrency?: number;
  maxPages?: number;
  respectRobots?: boolean;
  /** Skip domains the history already has addresses for. On by default. */
  skipKnown?: boolean;
  signal?: AbortSignal;
};

const DEFAULTS = {
  concurrency: 8,
  maxPages: 8,
  respectRobots: true,
  skipKnown: true,
};

/** More than this per company is a directory page, not a contact list. */
const MAX_EMAILS_PER_COMPANY = 12;

export async function* enrich(
  candidates: Candidate[],
  options: EnrichOptions = {},
): AsyncGenerator<EnrichEvent> {
  const config = { ...DEFAULTS, ...options };
  const started = Date.now();
  const warnings: string[] = [];

  // Read before anything is written: "new" means "was not in the database when
  // this run started", and persistence happens at the end, so asking afterwards
  // would mark every single row as new.
  const alreadyStored = knownDomains(false);

  let queue = candidates;
  if (config.skipKnown) {
    const contactable = knownDomains(true);
    const before = queue.length;
    queue = queue.filter((c) => !contactable.has(c.domain));
    const skipped = before - queue.length;
    if (skipped > 0) {
      warnings.push(
        `${skipped} empresa${skipped === 1 ? "" : "s"} já no histórico com e-mail — ` +
          `puladas. Desmarque "pular conhecidas" para rastrear de novo.`,
      );
    }
  }

  yield { type: "start", total: queue.length };
  if (queue.length === 0) {
    yield {
      type: "done",
      total: 0,
      withEmail: 0,
      unreachable: 0,
      elapsedMs: Date.now() - started,
      persisted: { inserted: 0, alreadyKnown: 0 },
      warnings,
    };
    return;
  }

  const finished: Prospect[] = [];
  let done = 0;

  for await (const prospect of pooled(queue, config.concurrency, (candidate) =>
    enrichOne(candidate, config),
  )) {
    prospect.isNew = !alreadyStored.has(prospect.domain);
    finished.push(prospect);
    done++;
    yield { type: "prospect", prospect, done, total: queue.length };
    if (config.signal?.aborted) break;
  }

  // Persisted in one transaction at the end rather than per company: a crawl of
  // 200 sites is 200 tiny writes, and committing each would fsync 200 times for
  // a file that is rebuilt by re-running the crawl anyway. The cost of the
  // trade is losing the run if the process dies mid-crawl — which the streamed
  // board has already shown you, and which a re-run recovers.
  const { result, warning } = persistProspects(finished);
  if (warning) warnings.push(warning);

  yield {
    type: "done",
    total: finished.length,
    withEmail: finished.filter((p) => p.emails.length > 0).length,
    unreachable: finished.filter((p) => p.status === "inacessivel").length,
    elapsedMs: Date.now() - started,
    persisted: result && {
      inserted: result.inserted,
      alreadyKnown: result.alreadyKnown,
    },
    warnings,
  };
}

async function enrichOne(
  candidate: Candidate,
  config: Required<Omit<EnrichOptions, "signal">> & { signal?: AbortSignal },
): Promise<Prospect> {
  const outcome = await crawlSite(candidate.website, candidate.domain, {
    maxPages: config.maxPages,
    respectRobots: config.respectRobots,
    signal: config.signal,
  });

  const domain = outcome.finalDomain ?? candidate.domain;
  const emails = mergeEmails(
    outcome.pages.map((page) => extractEmails(page.html, page.path, domain)),
  ).slice(0, MAX_EMAILS_PER_COMPANY);

  const facts =
    outcome.pages.length > 0 ? extractCompany(outcome.pages, domain) : null;

  const status: Prospect["status"] =
    outcome.pages.length === 0
      ? "inacessivel"
      : outcome.blocked
        ? "bloqueado"
        : emails.length === 0
          ? "sem_email"
          : "ok";

  const base: Omit<Prospect, "score" | "reasons"> = {
    ...candidate,
    name: bestName(candidate.name, facts?.name ?? null, domain),
    domain,
    emails,
    phones: dedupe([
      ...(facts?.phones ?? []),
      ...(candidate.phone ? [candidate.phone] : []),
    ]).slice(0, 4),
    socials: facts?.socials ?? {
      linkedin: null,
      xing: null,
      facebook: null,
      instagram: null,
      youtube: null,
      twitter: null,
    },
    vat: facts?.vat ?? null,
    registration: facts?.registration ?? null,
    // Discovery's address is a postal address that was verified by a mapping
    // provider; the crawled one came out of prose. Prefer the former.
    address: candidate.address ?? facts?.address ?? null,
    postalCode: facts?.postalCode ?? null,
    city: candidate.city ?? facts?.city ?? null,
    country: candidate.country ?? facts?.country ?? null,
    employees: facts?.employees ?? null,
    languages: facts?.languages ?? [],
    technologies: facts?.technologies ?? [],
    pages: outcome.pages.length,
    crawlMs: outcome.elapsedMs,
    status,
    error: outcome.error,
  };

  const { score, reasons } = scoreProspect(base);
  return { ...base, score, reasons };
}

/**
 * Which name to show.
 *
 * Overture's is curated and usually right; the site's is the *legal* one, which
 * is what a formal European B2B email should be addressed to. So the site wins
 * when it carries a legal form ("… GmbH", "… S.p.A.") and otherwise the
 * discovery name stands, because a title-derived name is often a slogan.
 */
function bestName(
  discovered: string,
  extracted: string | null,
  domain: string,
): string {
  const LEGAL =
    /\b(GmbH|AG|KG|OHG|UG|BV|NV|S\.?A\.?|SARL|SRL|SpA|Ltd|LLC|Inc|PLC|Oy|AB|A\/S|ApS|Kft|S\.?L\.?|Lda|Ltda)\b/i;
  if (extracted && LEGAL.test(extracted) && !LEGAL.test(discovered))
    return extracted;
  if (discovered && discovered !== domain) return discovered;
  return extracted ?? discovered ?? domain;
}

function dedupe(values: string[]): string[] {
  return [...new Set(values.filter(Boolean))];
}

/**
 * Run `worker` over `items` with at most `limit` in flight, yielding each
 * result the moment it lands.
 *
 * Deliberately not `Promise.all` over chunks of `limit`: a chunk finishes at the
 * speed of its slowest member, so one site that sits on the 35-second budget
 * stalls seven others that finished in two. Refilling a slot as soon as it frees
 * measured roughly twice the throughput on a mixed list.
 */
async function* pooled<T, R>(
  items: T[],
  limit: number,
  worker: (item: T) => Promise<R>,
): AsyncGenerator<R> {
  const inFlight = new Set<Promise<void>>();
  const ready: R[] = [];
  let wake: (() => void) | null = null;
  let index = 0;

  const fill = () => {
    while (inFlight.size < Math.max(1, limit) && index < items.length) {
      const item = items[index++];
      const promise = worker(item)
        .then((result) => {
          ready.push(result);
        })
        .catch(() => {
          // enrichOne never rejects; this is the belt to that braces, so one
          // unexpected throw can't take down a run that is minutes in.
        })
        .finally(() => {
          inFlight.delete(promise);
          wake?.();
          wake = null;
        });
      inFlight.add(promise);
    }
  };

  fill();
  while (ready.length > 0 || inFlight.size > 0 || index < items.length) {
    if (ready.length === 0) {
      await new Promise<void>((resolve) => {
        wake = resolve;
      });
      continue;
    }
    yield ready.shift() as R;
    fill();
  }
}
