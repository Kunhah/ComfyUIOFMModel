/**
 * A very small HTML reader, built on regular expressions.
 *
 * That is a deliberate choice, not a shortcut avoided. The reference design for
 * this pipeline reaches for `selectolax`; the Node equivalents (cheerio,
 * parse5, jsdom) all build a full DOM, which is 50–100× the cost of what we
 * actually do here — we never traverse a tree, never query by CSS, and never
 * render. We scan a page for eight or nine specific shapes (`mailto:` hrefs,
 * `<script type="application/ld+json">`, `og:` meta, comments) and throw the
 * document away. Regexes are the right tool for that, and they keep this side
 * of the app dependency-free.
 *
 * The trade is real and bounded: broken nesting, `<a>` inside `<a>`, or an
 * attribute containing an unescaped `>` can confuse these. For contact-page
 * scraping that costs an occasional missed link, never a wrong email — every
 * address is re-validated by the extractor regardless of where it came from.
 */

/** Entities that actually show up in obfuscated contact details. */
const NAMED_ENTITIES: Record<string, string> = {
  amp: "&",
  lt: "<",
  gt: ">",
  quot: '"',
  apos: "'",
  nbsp: " ",
  commat: "@", // the entity name for "@" — used precisely to hide addresses
  period: ".",
  bull: "•",
  ndash: "–",
  mdash: "—",
  hellip: "…",
  auml: "ä",
  ouml: "ö",
  uuml: "ü",
  szlig: "ß",
  eacute: "é",
  egrave: "è",
  agrave: "à",
  ccedil: "ç",
  ntilde: "ñ",
  oslash: "ø",
  aring: "å",
};

/**
 * `&#64;` and `&#x40;` are the single most common email obfuscation on European
 * industrial sites — the address is plain text to a browser and invisible to a
 * naive regex. Decoding first is what turns them back into something matchable.
 */
export function decodeEntities(input: string): string {
  return input
    .replace(/&#x([0-9a-f]+);/gi, (_, hex: string) =>
      safeFromCodePoint(parseInt(hex, 16)),
    )
    .replace(/&#(\d+);/g, (_, dec: string) =>
      safeFromCodePoint(parseInt(dec, 10)),
    )
    .replace(/&([a-z]+);/gi, (match, name: string) => {
      const value = NAMED_ENTITIES[name.toLowerCase()];
      return value ?? match;
    });
}

function safeFromCodePoint(code: number): string {
  if (!Number.isFinite(code) || code < 0 || code > 0x10ffff) return "";
  try {
    return String.fromCodePoint(code);
  } catch {
    return "";
  }
}

const SCRIPT_OR_STYLE = /<(script|style)\b[^>]*>[\s\S]*?<\/\1\s*>/gi;
const COMMENT = /<!--([\s\S]*?)-->/g;

/** Visible text: scripts, styles, comments and tags removed, whitespace collapsed. */
export function textOf(html: string): string {
  return decodeEntities(
    html
      .replace(SCRIPT_OR_STYLE, " ")
      .replace(COMMENT, " ")
      .replace(/<[^>]+>/g, " "),
  )
    .replace(/\s+/g, " ")
    .trim();
}

/** Contents of every `<script>`, where inlined config objects hide contact data. */
export function scriptSources(html: string): string[] {
  const out: string[] = [];
  const re = /<script\b[^>]*>([\s\S]*?)<\/script\s*>/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) out.push(m[1]);
  return out;
}

export function styleSources(html: string): string[] {
  const out: string[] = [];
  const re = /<style\b[^>]*>([\s\S]*?)<\/style\s*>/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) out.push(m[1]);
  return out;
}

/** HTML comments. Developers leave real addresses in them constantly. */
export function commentSources(html: string): string[] {
  const out: string[] = [];
  let m: RegExpExecArray | null;
  COMMENT.lastIndex = 0;
  while ((m = COMMENT.exec(html))) out.push(m[1]);
  return out;
}

export type Tag = {
  name: string;
  attrs: Record<string, string>;
  /** Raw inner HTML for paired tags; empty for void elements. */
  inner: string;
};

/**
 * Every occurrence of one tag. `inner` is filled by finding the next matching
 * close tag — not nesting-aware, which is fine for `<a>`, `<title>` and
 * `<script>` and is why this is never used for `<div>`.
 */
export function tags(html: string, name: string): Tag[] {
  const out: Tag[] = [];
  const open = new RegExp(`<${name}\\b([^>]*)>`, "gi");
  const close = new RegExp(`</${name}\\s*>`, "i");
  let m: RegExpExecArray | null;
  while ((m = open.exec(html))) {
    const rest = html.slice(m.index + m[0].length);
    const end = rest.search(close);
    out.push({
      name,
      attrs: parseAttrs(m[1]),
      inner: end === -1 ? "" : rest.slice(0, end),
    });
  }
  return out;
}

const ATTR =
  /([a-zA-Z_:][-a-zA-Z0-9_:.]*)\s*=\s*("([^"]*)"|'([^']*)'|([^\s"'=<>`]+))/g;

export function parseAttrs(source: string): Record<string, string> {
  const out: Record<string, string> = {};
  let m: RegExpExecArray | null;
  ATTR.lastIndex = 0;
  while ((m = ATTR.exec(source))) {
    const value = m[3] ?? m[4] ?? m[5] ?? "";
    out[m[1].toLowerCase()] = decodeEntities(value);
  }
  return out;
}

/** All `<meta>` as `{name|property|itemprop} → content`, lowercased keys. */
export function metaMap(html: string): Record<string, string> {
  const out: Record<string, string> = {};
  const re = /<meta\b([^>]*)>/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const a = parseAttrs(m[1]);
    const key = (a.property ?? a.name ?? a.itemprop ?? "").toLowerCase();
    if (key && a.content) out[key] = a.content;
  }
  return out;
}

export function titleOf(html: string): string | null {
  const t = tags(html, "title")[0];
  if (!t) return null;
  const text = decodeEntities(t.inner.replace(/<[^>]+>/g, " "))
    .replace(/\s+/g, " ")
    .trim();
  return text.length > 0 ? text : null;
}

/**
 * Parsed `application/ld+json` blocks, flattened.
 *
 * Flattening matters: sites emit `{"@graph":[…]}`, or a bare array, or one
 * object per script tag, and the Organization node we want can be at any depth
 * of that. Anything unparseable is skipped — half of these blocks in the wild
 * have a trailing comma or a raw newline in a string.
 */
export function jsonLd(html: string): Record<string, unknown>[] {
  const out: Record<string, unknown>[] = [];
  for (const tag of tags(html, "script")) {
    const type = (tag.attrs.type ?? "").toLowerCase();
    if (!type.includes("ld+json")) continue;
    let parsed: unknown;
    try {
      parsed = JSON.parse(decodeEntities(tag.inner.trim()));
    } catch {
      continue;
    }
    collect(parsed, out, 0);
  }
  return out;
}

function collect(
  node: unknown,
  out: Record<string, unknown>[],
  depth: number,
): void {
  if (depth > 6 || node === null || typeof node !== "object") return;
  if (Array.isArray(node)) {
    for (const child of node) collect(child, out, depth + 1);
    return;
  }
  const record = node as Record<string, unknown>;
  out.push(record);
  for (const value of Object.values(record)) {
    if (value && typeof value === "object") collect(value, out, depth + 1);
  }
}

/** `<html lang>`, normalised to a bare language code. */
export function documentLanguage(html: string): string | null {
  const m = /<html\b([^>]*)>/i.exec(html);
  if (!m) return null;
  const lang = parseAttrs(m[1]).lang;
  return lang ? lang.split(/[-_]/)[0].toLowerCase() : null;
}

/** Languages offered via `<link rel="alternate" hreflang>`. */
export function alternateLanguages(html: string): string[] {
  const out = new Set<string>();
  const re = /<link\b([^>]*)>/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const a = parseAttrs(m[1]);
    if (!a.hreflang) continue;
    const code = a.hreflang.split(/[-_]/)[0].toLowerCase();
    if (/^[a-z]{2}$/.test(code) && code !== "x") out.add(code);
  }
  return [...out];
}

/**
 * Cloudflare's email obfuscation, decoded.
 *
 * Their "Email Address Obfuscation" feature rewrites every address on the page
 * into `<a href="/cdn-cgi/l/email-protection#<hex>">` and restores it with
 * JavaScript. It is on by default on the free plan, so a plain fetch of a
 * Cloudflare-fronted contact page finds *zero* addresses while a browser shows
 * several — which is exactly the gap that makes people conclude a scraper
 * "doesn't work". The encoding is XOR with the first byte as the key.
 */
export function decodeCloudflareEmail(hex: string): string | null {
  if (!/^[0-9a-f]{6,}$/i.test(hex) || hex.length % 2 !== 0) return null;
  const key = parseInt(hex.slice(0, 2), 16);
  let out = "";
  for (let i = 2; i < hex.length; i += 2) {
    const code = parseInt(hex.slice(i, i + 2), 16) ^ key;
    // Printable ASCII only. XOR will "decode" any hex string into *something*,
    // so without this a stray hex blob elsewhere on the page can produce a
    // plausible-looking address that was never on the site.
    if (!Number.isFinite(code) || code < 33 || code > 126) return null;
    out += String.fromCharCode(code);
  }
  return out.includes("@") ? out : null;
}

/** Every Cloudflare-protected address on the page, decoded. */
export function cloudflareEmails(html: string): string[] {
  const out = new Set<string>();
  // Two carriers: the href fragment on the rewritten link, and the
  // `data-cfemail` attribute Cloudflare puts on inline spans.
  const patterns = [
    /\/cdn-cgi\/l\/email-protection#([0-9a-f]+)/gi,
    /data-cfemail\s*=\s*["']([0-9a-f]+)["']/gi,
  ];
  for (const re of patterns) {
    let m: RegExpExecArray | null;
    while ((m = re.exec(html))) {
      const decoded = decodeCloudflareEmail(m[1]);
      if (decoded) out.add(decoded);
    }
  }
  return [...out];
}
