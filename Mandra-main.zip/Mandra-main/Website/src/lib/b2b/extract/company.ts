import type { CrawledPage } from "../crawl/fetch";
import { countryFromDomain, countryFromPhone, findCountry } from "../countries";
import type { Socials } from "../types";
import {
  alternateLanguages,
  decodeEntities,
  documentLanguage,
  jsonLd,
  metaMap,
  parseAttrs,
  tags,
  textOf,
  titleOf,
} from "./html";

/**
 * Everything about the company that isn't an email address.
 *
 * The email is what lets you write; this is what lets you write something worth
 * reading. A VAT id and a commercial register entry say the company is real and
 * trading. A head-count says whether this is a two-person workshop or a
 * 300-person plant. The technology fingerprint says what they'd be buying: a
 * site on WordPress with jQuery, no analytics and no CRM is a company whose
 * commercial operation is running on email and spreadsheets.
 *
 * Every field follows the same rule: prefer the machine-readable source
 * (JSON-LD, then meta tags), fall back to the page text, and leave the field
 * null rather than guessing. A wrong address on a lead row is worse than an
 * empty one — you find out it was wrong in the reply.
 */

export type CompanyFacts = {
  name: string | null;
  address: string | null;
  postalCode: string | null;
  city: string | null;
  country: string | null;
  phones: string[];
  socials: Socials;
  vat: string | null;
  registration: string | null;
  employees: string | null;
  languages: string[];
  technologies: string[];
};

const EMPTY_SOCIALS: Socials = {
  linkedin: null,
  xing: null,
  facebook: null,
  instagram: null,
  youtube: null,
  twitter: null,
};

export function extractCompany(
  pages: CrawledPage[],
  domain: string,
): CompanyFacts {
  // The impressum, then the contact page, then the homepage. Sorting once here
  // means every extractor below can just take the first hit and be reading the
  // densest page that actually has the field.
  const ordered = [...pages].sort((a, b) => pageWeight(b) - pageWeight(a));
  const home = pages[0] ?? ordered[0];

  const nodes = ordered.flatMap((page) => jsonLd(page.html));
  const texts = ordered.map((page) => textOf(page.html));
  const allText = texts.join("\n");

  const postal = addressFromJsonLd(nodes) ?? addressFromText(texts);
  const phones = extractPhones(ordered, allText);
  const country =
    normaliseCountryCode(postal?.country) ??
    countryFromDomain(domain) ??
    countryFromPhones(phones);

  return {
    name: extractName(nodes, home, domain),
    address: postal?.street ?? null,
    postalCode: postal?.postalCode ?? null,
    city: postal?.city ?? null,
    country,
    // Four is already more than anyone dials; past that it is a branch list.
    phones: phones.slice(0, 4),
    socials: extractSocials(ordered),
    vat: extractVat(allText),
    registration: extractRegistration(allText),
    employees: extractEmployees(allText),
    languages: extractLanguages(ordered),
    technologies: detectTechnologies(ordered),
  };
}

function pageWeight(page: CrawledPage): number {
  const path = page.path.toLowerCase();
  if (/impressum|imprint|legal|mentions/.test(path)) return 100;
  if (/kontakt|contact|contatti|contacto|contato/.test(path)) return 90;
  if (/about|ueber|unternehmen|company|sobre|empresa|chi-siamo/.test(path))
    return 60;
  if (path === "/" || path === "") return 50;
  return 10;
}

// --- name -------------------------------------------------------------------

/** Legal forms, which is how you tell a company name from a tagline. */
const LEGAL_FORMS =
  /\b(GmbH|mbH|AG|KG|OHG|UG|e\.K\.|GbR|S\.?A\.?S?|S\.?A\.?R\.?L\.?|SARL|SRL|S\.?R\.?L\.?|SpA|S\.?p\.?A\.?|B\.?V\.?|N\.?V\.?|Ltd\.?|Limited|LLC|Inc\.?|PLC|Oy|Oyj|AB|A\/S|ApS|AS|Sp\.\s?z\s?o\.?o\.?|s\.r\.o\.|d\.o\.o\.|Kft\.?|S\.?L\.?|Lda\.?|LDA|SA|Ltda\.?|EIRELI)\b/i;

/** Words a title uses around the company name, never as the name itself. */
const TITLE_NOISE =
  /^(home|homepage|start|startseite|willkommen|welcome|bienvenue|benvenuti|bienvenidos|bem[- ]vindo|official website|site officiel|inicio|início|index|accueil|hem|forside)$/i;

function extractName(
  nodes: Record<string, unknown>[],
  page: CrawledPage | undefined,
  domain: string,
): string | null {
  // 1. JSON-LD, and legalName over name — "Müller Präzisionstechnik GmbH" is
  //    what you address a letter to; "Müller Präzision" is the brand.
  for (const key of ["legalName", "name"]) {
    for (const node of nodes) {
      if (!isOrganisation(node)) continue;
      const value = node[key];
      if (typeof value === "string" && value.trim().length > 1) {
        return clean(value);
      }
    }
  }

  if (!page) return null;

  // 2. og:site_name, which is set by the author for exactly this purpose.
  const meta = metaMap(page.html);
  for (const key of [
    "og:site_name",
    "application-name",
    "apple-mobile-web-app-title",
  ]) {
    const value = meta[key];
    if (value && !TITLE_NOISE.test(value.trim())) return clean(value);
  }

  // 3. The title, split on its separators. The segment carrying a legal form is
  //    the company; failing that the shortest non-noise segment, because the
  //    other one is the tagline ("Industrial Automation Since 1974").
  const title = titleOf(page.html);
  if (title) {
    const parts = title
      .split(/\s+[|·•—–]\s+|\s+[-:]\s+/)
      .map((p) => p.trim())
      .filter((p) => p.length > 1 && !TITLE_NOISE.test(p));
    const legal = parts.find((p) => LEGAL_FORMS.test(p));
    if (legal) return clean(legal);
    if (parts.length > 0) {
      return clean(parts.reduce((a, b) => (a.length <= b.length ? a : b)));
    }
  }

  // 4. The first heading, if it reads like a name rather than a sentence.
  const h1 = tags(page.html, "h1")[0];
  if (h1) {
    const text = clean(h1.inner.replace(/<[^>]+>/g, " "));
    if (text && text.length <= 60 && text.split(/\s+/).length <= 7) return text;
  }

  // 5. The domain. Never empty on the board — a row with no name reads as a bug.
  return domain
    .split(".")[0]
    .replace(/[-_]+/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

function isOrganisation(node: Record<string, unknown>): boolean {
  const type = node["@type"];
  const types = Array.isArray(type) ? type : [type];
  return types.some(
    (t) =>
      typeof t === "string" &&
      /(Organization|Corporation|LocalBusiness|Store|Manufacturer|WebSite)/i.test(
        t,
      ),
  );
}

function clean(value: string): string {
  return decodeEntities(value).replace(/\s+/g, " ").trim().slice(0, 120);
}

// --- address ----------------------------------------------------------------

type PostalParts = {
  street: string | null;
  postalCode: string | null;
  city: string | null;
  country: string | null;
};

function addressFromJsonLd(
  nodes: Record<string, unknown>[],
): PostalParts | null {
  for (const node of nodes) {
    const type = node["@type"];
    const isAddress =
      (typeof type === "string" && /PostalAddress/i.test(type)) ||
      ("streetAddress" in node && "addressLocality" in node);
    if (!isAddress) continue;

    const street = str(node.streetAddress);
    const city = str(node.addressLocality);
    if (!street && !city) continue;

    return {
      street,
      postalCode: str(node.postalCode),
      city,
      country: str(node.addressCountry) ?? countryOf(node.addressCountry),
    };
  }
  return null;
}

function countryOf(value: unknown): string | null {
  if (value && typeof value === "object") {
    const record = value as Record<string, unknown>;
    return str(record.name) ?? str(record.identifier);
  }
  return null;
}

/**
 * Street, postcode and town out of prose.
 *
 * European postal formats differ enough that one regex can't cover them, so the
 * common shapes are listed separately and the first that hits on the densest
 * page wins: "12345 Stadt" (DE/FR/IT/ES), "1234 AB Stad" (NL), "12-345 Miasto"
 * (PL), "1234-567 Cidade" (PT), "1234 Ort" (AT/CH/BE/DK/NO/HU).
 */
const POSTAL_PATTERNS: RegExp[] = [
  /\b(\d{4}\s?[A-Z]{2})\s+([A-ZÀ-Þ][\p{L}.'-]+(?:[ -][A-ZÀ-Þ][\p{L}.'-]+){0,2})/gu,
  /\b(\d{2}-\d{3})\s+([A-ZÀ-Þ][\p{L}.'-]+(?:[ -][A-ZÀ-Þ][\p{L}.'-]+){0,2})/gu,
  /\b(\d{4}-\d{3})\s+([A-ZÀ-Þ][\p{L}.'-]+(?:[ -][A-ZÀ-Þ][\p{L}.'-]+){0,2})/gu,
  /\b(?:[A-Z]{1,2}-)?(\d{4,5})\s+([A-ZÀ-Þ][\p{L}.'-]+(?:[ -][A-ZÀ-Þ][\p{L}.'-]+){0,2})/gu,
];

/**
 * "12025 Waterfront Drive" has the exact shape of "12025 Musterstadt" — a house
 * number that happens to be five digits, followed by a capitalised word. Without
 * this guard the street ends up in the city column, which is wrong in a way that
 * looks right until you post something.
 */
const STREET_SUFFIX =
  /(?:stra(?:ß|ss)e|str|weg|allee|platz|gasse|ring|damm|street|road|avenue|drive|lane|way|boulevard|rue|via|viale|corso|calle|avenida|rua|straat|laan|vej|gatan|utca)\.?$/i;

/**
 * Words that follow a postcode but are not the town: the country, or the label
 * of whatever comes next ("70565 Stuttgart Telefon: …"). A capitalised word
 * after a five-digit number is a weak signal, so the shape has to be defended
 * from both ends.
 */
const NOT_A_CITY =
  /^(impressum|datenschutz|kontakt|cookies|sitemap|agb|karriere|jobs|presse|newsletter|login|home|menu|service|downloads|produkte|unternehmen|hinweisgebersystem|privacy|imprint|legal|copyright|all|rights|reserved|version|since|inc|llc|ltd|gmbh|usa|uk|eu|tel|telefon|telefono|telephone|phone|fon|fax|e|email|mail|web|www|url|postfach|po|box|suite|floor|apt|vat|ust|mwst|hrb|hra|amtsgericht|deutschland|germany|österreich|osterreich|austria|schweiz|switzerland|france|frankreich|italia|italy|italien|españa|espana|spain|portugal|nederland|netherlands|belgië|belgie|belgique|belgium|polska|poland|brasil|brazil)$/i;

const STREET_PATTERN =
  /([A-ZÀ-Þ][\p{L}.'-]*(?:[ -][\p{L}.'-]+){0,3}\s?(?:stra(?:ß|ss)e|str\.|weg|allee|platz|gasse|ring|damm|ufer|chaussee|street|road|avenue|lane|drive|rue|boulevard|via|viale|corso|piazza|calle|avenida|carrer|rua|travessa|estrada|straat|laan|dreef|vej|gatan|utca)\s*\.?\s*\d{1,4}\s?[a-zA-Z]?)/u;

/** How far from the street a postcode may sit and still belong to it. */
const NEAR_STREET = 160;

function addressFromText(texts: string[]): PostalParts | null {
  for (const text of texts) {
    // Only the first 6.000 characters: the address on a contact or impressum
    // page is near the top, and further down are the customer references, which
    // are other companies' addresses.
    const window = text.slice(0, 6000);

    // The street is the anchor. "Industriestraße 42" is unambiguous in a way a
    // number never is, so it is found first and everything else is judged by
    // how close it sits to it.
    const streetMatch = STREET_PATTERN.exec(window);
    const street = streetMatch?.[1]?.trim() ?? null;
    const anchor = streetMatch?.index ?? -1;

    let postalCode: string | null = null;
    let city: string | null = null;
    outer: for (const pattern of POSTAL_PATTERNS) {
      // Every occurrence, not just the first: the first four-digit number on a
      // page is usually a year and the first five-digit one a house number.
      pattern.lastIndex = 0;
      for (const m of window.matchAll(pattern)) {
        const index = m.index ?? 0;
        // "© 1997-2026 SPI and others" has the shape of a four-digit postcode
        // followed by a town, and every site in Europe has one in its footer.
        // Both halves of a year range have to be defended against, since the ©
        // itself can be a dozen characters upstream.
        const before = window.slice(Math.max(0, index - 24), index);
        if (/(©|\(c\)|copyright|&copy;)/i.test(before)) continue;
        if (/\d{4}\s*[-–—]\s*$/.test(before)) continue;

        const candidate = trimToCity(m[2].trim());
        if (!candidate || STREET_SUFFIX.test(candidate)) continue;

        // A bare four-digit code (AT, CH, BE, DK, HU…) is indistinguishable from
        // a year, an article number or a machine model, all of which litter an
        // industrial site. It is only believed next to a street. The formats
        // that carry letters or a hyphen — "1234 AB", "12-345", "1234-567" —
        // and five-digit codes stand on their own.
        const ambiguous = /^\d{4}$/.test(m[1].trim());
        if (
          ambiguous &&
          (anchor < 0 || Math.abs(index - anchor) > NEAR_STREET)
        ) {
          continue;
        }

        postalCode = m[1].trim();
        city = candidate;
        break outer;
      }
    }

    if (street || (postalCode && city)) {
      return { street: tidyStreet(street), postalCode, city, country: null };
    }
  }
  return null;
}

/**
 * Drops a legal-form tail that the street pattern swallowed from the line above
 * it — "Beckhoff Automation GmbH & Co. KG Hülshorstweg 20" is two fields run
 * together by a line break that `textOf` turned into a space.
 */
function tidyStreet(street: string | null): string | null {
  if (!street) return null;
  const cleaned = street
    .replace(
      /^(?:.*?\b(?:GmbH|AG|KG|OHG|UG|BV|NV|SA|SRL|SpA|Ltd|LLC|Inc|Oy|AB|Kft|Lda|Ltda)\b[\s&.]*)+/i,
      "",
    )
    .trim();
  return cleaned.length >= 4 ? cleaned : street;
}

/** Cuts a candidate town at the first word that can't be part of one. */
function trimToCity(candidate: string): string | null {
  const words: string[] = [];
  for (const word of candidate.split(/[\s-]+/)) {
    if (NOT_A_CITY.test(word.replace(/[.,:]$/, ""))) break;
    words.push(word);
  }
  const city = words
    .join(" ")
    .replace(/[.,:]$/, "")
    .trim();
  return city.length >= 2 ? city : null;
}

/** "DE", "Deutschland", "Germany" → "DE". Anything unrecognised stays null. */
function normaliseCountryCode(value: string | null | undefined): string | null {
  if (!value) return null;
  const raw = value.trim();
  if (/^[A-Za-z]{2}$/.test(raw) && findCountry(raw)) return raw.toUpperCase();
  const names: Record<string, string> = {
    deutschland: "DE",
    germany: "DE",
    allemagne: "DE",
    alemanha: "DE",
    österreich: "AT",
    osterreich: "AT",
    austria: "AT",
    schweiz: "CH",
    switzerland: "CH",
    suisse: "CH",
    svizzera: "CH",
    nederland: "NL",
    netherlands: "NL",
    holanda: "NL",
    belgië: "BE",
    belgie: "BE",
    belgium: "BE",
    belgique: "BE",
    france: "FR",
    frankreich: "FR",
    frança: "FR",
    italia: "IT",
    italy: "IT",
    italien: "IT",
    itália: "IT",
    españa: "ES",
    espana: "ES",
    spain: "ES",
    spanien: "ES",
    espanha: "ES",
    portugal: "PT",
    polska: "PL",
    poland: "PL",
    polen: "PL",
    "united kingdom": "GB",
    uk: "GB",
    england: "GB",
    "great britain": "GB",
    ireland: "IE",
    irland: "IE",
    danmark: "DK",
    denmark: "DK",
    sverige: "SE",
    sweden: "SE",
    norge: "NO",
    norway: "NO",
    suomi: "FI",
    finland: "FI",
    česko: "CZ",
    "czech republic": "CZ",
    czechia: "CZ",
    slovensko: "SK",
    slovakia: "SK",
    magyarország: "HU",
    hungary: "HU",
    românia: "RO",
    romania: "RO",
    slovenija: "SI",
    slovenia: "SI",
    hrvatska: "HR",
    croatia: "HR",
    türkiye: "TR",
    turkey: "TR",
    brasil: "BR",
    brazil: "BR",
    "united states": "US",
    usa: "US",
  };
  return names[raw.toLowerCase()] ?? null;
}

// --- phones -----------------------------------------------------------------

const PHONE_PATTERN = /\+\d[\d\s\-./()]{6,22}\d/g;

function extractPhones(pages: CrawledPage[], text: string): string[] {
  const found: string[] = [];

  // `tel:` first: it is unambiguous and already the number the site intends.
  for (const page of pages) {
    for (const a of tags(page.html, "a")) {
      const href = a.attrs.href ?? "";
      if (!/^tel:/i.test(href)) continue;
      const value = tidyPhone(decodeURIComponent(href.slice(4)));
      if (value) found.push(value);
    }
  }

  for (const m of text.matchAll(PHONE_PATTERN)) {
    const value = tidyPhone(m[0]);
    if (value) found.push(value);
  }

  // Returned uncapped — the caller shows the first few and votes on all of them
  // for the country. Capping here would have the country decided by four numbers
  // out of a branch list of forty.
  const unique: string[] = [];
  for (const phone of found) {
    if (!unique.includes(phone)) unique.push(phone);
    if (unique.length >= 60) break;
  }
  return unique;
}

/**
 * The country most of the numbers point at, not the first one.
 *
 * A `.com` with no JSON-LD falls back to its phone numbers, and taking the first
 * filed Beckhoff — head office in Verl, 5.000 people — under **Brazil**, because
 * the page that happened to sort first carried its São Paulo subsidiary's
 * number. A vote over every number found is both cheap and much harder to fool;
 * ties keep the earliest, which is the one on the densest page.
 */
function countryFromPhones(phones: string[]): string | null {
  const votes = new Map<string, number>();
  // Weighted by position, not a flat count. The list starts on the densest page
  // — impressum or contact — so the numbers at the top are the head office's,
  // and the tail is the worldwide branch list. Counting flatly hands the
  // decision to whoever has the most subsidiaries: Elesa (Monza, Italy) filed as
  // US off its own global contact page, even though its first two numbers are
  // +39. With 1/(i+1) the two Italian numbers outweigh five American ones.
  phones.slice(0, 12).forEach((phone, index) => {
    const code = countryFromPhone(phone);
    if (code) votes.set(code, (votes.get(code) ?? 0) + 1 / (index + 1));
  });
  let best: string | null = null;
  let bestCount = 0;
  for (const [code, count] of votes) {
    if (count > bestCount) {
      best = code;
      bestCount = count;
    }
  }
  return best;
}

/** E.164-ish: a plus and 8–15 digits, or nothing. */
function tidyPhone(raw: string): string | null {
  const digits = raw.replace(/[^\d+]/g, "");
  if (!digits.startsWith("+")) return null;
  const body = digits.slice(1).replace(/\D/g, "");
  if (body.length < 8 || body.length > 15) return null;
  return `+${body}`;
}

// --- socials ----------------------------------------------------------------

const SOCIAL_PATTERNS: [keyof Socials, RegExp][] = [
  [
    "linkedin",
    /^https?:\/\/([a-z]{2,3}\.)?linkedin\.com\/(company|showcase|school)\/[^/?#]+/i,
  ],
  ["xing", /^https?:\/\/(www\.)?xing\.com\/(companies|pages)\/[^/?#]+/i],
  [
    "facebook",
    /^https?:\/\/([a-z-]{2,6}\.)?facebook\.com\/(?!sharer|share\.php|plugins|tr\?)[^/?#]+/i,
  ],
  [
    "instagram",
    /^https?:\/\/(www\.)?instagram\.com\/(?!p\/|reel\/|explore)[^/?#]+/i,
  ],
  [
    "youtube",
    /^https?:\/\/(www\.)?youtube\.com\/(c\/|channel\/|user\/|@)[^/?#]+/i,
  ],
  [
    "twitter",
    /^https?:\/\/(www\.)?(twitter|x)\.com\/(?!intent|share|home)[^/?#]+/i,
  ],
];

function extractSocials(pages: CrawledPage[]): Socials {
  const out: Socials = { ...EMPTY_SOCIALS };
  for (const page of pages) {
    const re = /<a\b([^>]*)>/gi;
    let m: RegExpExecArray | null;
    while ((m = re.exec(page.html))) {
      const href = parseAttrs(m[1]).href;
      if (!href) continue;
      for (const [key, pattern] of SOCIAL_PATTERNS) {
        // First wins: the header/footer profile links come before the "share
        // this page" widgets, and are the company's own accounts.
        if (!out[key] && pattern.test(href)) out[key] = href.split(/[?#]/)[0];
      }
    }
  }
  return out;
}

// --- tax and registry ids ---------------------------------------------------

/**
 * Per-country VAT shapes, so a match is a real id rather than any run of
 * capitals and digits. A loose pattern here fills the column with product codes
 * ("EN10204", "DIN12345") — which look exactly like a VAT id and are all over
 * an industrial site.
 */
const VAT_SHAPES: [string, RegExp][] = [
  ["ATU", /^ATU\d{8}$/],
  ["CHE", /^CHE\d{9}$/],
  ["DE", /^DE\d{9}$/],
  ["NL", /^NL\d{9}B\d{2}$/],
  ["BE", /^BE0?\d{9}$/],
  ["FR", /^FR[0-9A-Z]{2}\d{9}$/],
  ["IT", /^IT\d{11}$/],
  ["ES", /^ES[0-9A-Z]\d{7}[0-9A-Z]$/],
  ["PT", /^PT\d{9}$/],
  ["IE", /^IE\d[0-9A-Z]\d{5}[A-W]{1,2}$/],
  ["DK", /^DK\d{8}$/],
  ["SE", /^SE\d{12}$/],
  ["FI", /^FI\d{8}$/],
  ["PL", /^PL\d{10}$/],
  ["CZ", /^CZ\d{8,10}$/],
  ["SK", /^SK\d{10}$/],
  ["HU", /^HU\d{8}$/],
  ["RO", /^RO\d{2,10}$/],
  ["SI", /^SI\d{8}$/],
  ["HR", /^HR\d{11}$/],
  ["EE", /^EE\d{9}$/],
  ["LV", /^LV\d{11}$/],
  ["LT", /^LT(\d{9}|\d{12})$/],
  ["EL", /^EL\d{9}$/],
  ["BG", /^BG\d{9,10}$/],
  ["LU", /^LU\d{8}$/],
  ["GB", /^GB(\d{9}|\d{12})$/],
];

function extractVat(text: string): string | null {
  // Candidates are "two or three letters followed by 6–15 digit-ish characters,
  // ignoring the spaces, dots and hyphens people write them with".
  const re = /\b([A-Z]{2,3})[\s.\-/]?((?:\d[\s.\-/]?){6,14}[0-9A-Z])/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    const compact = (m[1] + m[2]).replace(/[\s.\-/]/g, "").toUpperCase();
    for (const [prefix, shape] of VAT_SHAPES) {
      if (compact.startsWith(prefix) && shape.test(compact)) return compact;
    }
  }
  // Written as a bare number after its label, which is how half of Germany does
  // it: "USt-IdNr.: 123456789".
  const labelled =
    /(?:USt[-\s.]?IdNr|Umsatzsteuer[-\s]?Identifikationsnummer|VAT(?:\s*(?:ID|No|Number|Reg))?|MwSt|BTW|TVA|IVA|NIF|CIF|NIP|Partita\s+IVA)[^0-9A-Z]{0,12}([A-Z]{0,3}[\s.\-]?(?:\d[\s.\-]?){8,12})/i.exec(
      text,
    );
  if (labelled) {
    const compact = labelled[1].replace(/[\s.\-]/g, "").toUpperCase();
    if (/^\d{8,12}$/.test(compact)) return compact;
  }
  return null;
}

function extractRegistration(text: string): string | null {
  const patterns: RegExp[] = [
    /\b(HR[AB]\s?\d{1,7})\b/, // Germany
    /\bFN\s?(\d{1,6}\s?[a-z])\b/i, // Austria (Firmenbuchnummer)
    /\bKvK[-\s]?(?:nummer)?\s*:?\s*(\d{8})\b/i, // Netherlands
    /\b(SIRET)\s*:?\s*(\d{3}\s?\d{3}\s?\d{3}\s?\d{5})\b/i, // France
    /\bREA\s*:?\s*([A-Z]{2}[\s-]?\d{5,7})\b/i, // Italy
    /\bCompany\s*(?:No|Number|Reg(?:istration)?(?:\s*No)?)\.?\s*:?\s*(\d{6,8})\b/i, // UK
    /\bCNPJ\s*:?\s*(\d{2}\.?\d{3}\.?\d{3}\/?\d{4}-?\d{2})\b/i, // Brazil
  ];
  for (const pattern of patterns) {
    const m = pattern.exec(text);
    if (m) return (m[2] ?? m[1]).replace(/\s+/g, " ").trim();
  }
  return null;
}

// --- size -------------------------------------------------------------------

const EMPLOYEE_WORDS =
  "employees|employe(?:e|é)s|mitarbeiter(?:innen)?|besch(?:ä|ae)ftigte|angestellte|dipendenti|empleados|funcion(?:á|a)rios|colaboradores|medewerkers|anst(?:ä|a)llda|pracownik(?:ów|ow)|staff|collaborateurs";
const APPROX =
  "more than|over|about|around|approx\\.?|circa|ca\\.|rund|(?:ü|ue)ber|mehr als|etwa|env\\.|plus de|m(?:á|a)s de|mais de|oltre|quase";

function extractEmployees(text: string): string | null {
  const before = new RegExp(
    `(?:(${APPROX})\\s*)?(\\d{1,3}(?:[.,]\\d{3})?)\\s*\\+?\\s*(?:${EMPLOYEE_WORDS})`,
    "i",
  ).exec(text);
  if (before) {
    const count = before[2].replace(/[.,]/g, "");
    // "~220", not "around 220": the site's own hedge word lands in a pt-BR
    // column next to "func.", and a tilde says the same thing in every language.
    return before[1] ? `~${count}` : count;
  }
  // "Mitarbeiter: 120" — the label first, the number after.
  const after = new RegExp(
    `(?:${EMPLOYEE_WORDS})\\s*[:\\-–]?\\s*(?:(${APPROX})\\s*)?(\\d{1,3}(?:[.,]\\d{3})?)\\b`,
    "i",
  ).exec(text);
  if (after) {
    const count = after[2].replace(/[.,]/g, "");
    return after[1] ? `~${count}` : count;
  }
  return null;
}

// --- languages --------------------------------------------------------------

function extractLanguages(pages: CrawledPage[]): string[] {
  const out = new Set<string>();
  for (const page of pages) {
    const lang = documentLanguage(page.html);
    if (lang) out.add(lang);
    for (const alternate of alternateLanguages(page.html)) out.add(alternate);
  }
  return [...out].slice(0, 8);
}

// --- technologies -----------------------------------------------------------

/**
 * What the site is built and run on.
 *
 * This is the opportunity signal, not trivia. The combination is what reads:
 * WordPress + jQuery + no analytics + no CRM is a company whose website is a
 * brochure someone's nephew built, whose lead flow is an inbox, and for whom a
 * portal or an automation is a first purchase rather than a replacement. The
 * absence of a marketing stack is scored in `score.ts` for exactly that reason.
 */
const FINGERPRINTS: [string, RegExp][] = [
  [
    "WordPress",
    /wp-content|wp-includes|wp-json|<meta name="generator" content="WordPress/i,
  ],
  ["WooCommerce", /woocommerce/i],
  ["TYPO3", /typo3(?:conf|temp)|content="TYPO3/i],
  ["Joomla", /\/media\/jui\/|content="Joomla/i],
  ["Drupal", /\/sites\/default\/files|Drupal\.settings|content="Drupal/i],
  ["Contao", /\/files\/|contao\/|content="Contao/i],
  ["Shopware", /shopware|\/widgets\/emotion/i],
  ["Shopify", /cdn\.shopify\.com|shopify\.theme/i],
  ["Wix", /static\.parastorage\.com|wixstatic/i],
  ["Squarespace", /squarespace|static1\.squarespace\.com/i],
  ["Webflow", /webflow\.(com|io)|data-wf-page/i],
  ["Jimdo", /jimdo|jimstatic/i],
  ["Next.js", /\/_next\/static|__NEXT_DATA__/i],
  ["React", /data-reactroot|react-dom|__REACT_DEVTOOLS/i],
  ["Vue", /data-v-[0-9a-f]{8}|vue(?:\.runtime)?\.min\.js/i],
  ["Angular", /ng-version=|angular\.min\.js/i],
  ["jQuery", /jquery[.-][\d.]+(?:\.min)?\.js|jquery\.min\.js/i],
  ["Bootstrap", /bootstrap(?:\.bundle)?(?:\.min)?\.(js|css)/i],
  ["ASP.NET", /__VIEWSTATE|aspnetForm|\.aspx/i],
  [
    "Google Analytics",
    /google-analytics\.com|gtag\/js|googletagmanager\.com\/gtag/i,
  ],
  ["Google Tag Manager", /googletagmanager\.com\/(gtm|ns)/i],
  ["Matomo", /matomo\.js|piwik\.js/i],
  ["HubSpot", /hs-scripts\.com|hubspot|hsforms/i],
  ["Salesforce Pardot", /pardot\.com|pi\.pardot/i],
  ["Mailchimp", /mailchimp|list-manage\.com/i],
  ["Facebook Pixel", /connect\.facebook\.net\/[^"']*fbevents/i],
  ["LinkedIn Insight", /snap\.licdn\.com/i],
  ["Cloudflare", /cdn-cgi\/|cloudflare/i],
  ["reCAPTCHA", /recaptcha\/api\.js|gstatic\.com\/recaptcha/i],
  ["Cookiebot", /cookiebot|consent\.cookiebot\.com/i],
  ["Usercentrics", /usercentrics/i],
  ["Calendly", /calendly\.com/i],
  ["Typeform", /typeform\.com/i],
  ["Intercom", /intercom\.io|intercomcdn/i],
  ["Zendesk", /zendesk|zdassets\.com/i],
  ["Tawk.to", /tawk\.to/i],
];

/** Server software, which the fingerprints above can't see. */
const HEADER_FINGERPRINTS: [string, RegExp][] = [
  ["PHP", /php/i],
  ["Nginx", /nginx/i],
  ["Apache", /apache/i],
  ["IIS", /iis|microsoft-httpapi/i],
];

export function detectTechnologies(pages: CrawledPage[]): string[] {
  // Only the first two pages: fingerprints repeat, and concatenating eight
  // documents to regex them 40 times is the most expensive thing in the
  // extraction path for no additional finding.
  const html = pages
    .slice(0, 2)
    .map((p) => p.html)
    .join("\n");
  const found = new Set<string>();
  for (const [name, pattern] of FINGERPRINTS) {
    if (pattern.test(html)) found.add(name);
  }
  const headers = pages
    .flatMap((p) => Object.entries(p.headers).map(([k, v]) => `${k}: ${v}`))
    .join("\n");
  for (const [name, pattern] of HEADER_FINGERPRINTS) {
    if (pattern.test(headers)) found.add(name);
  }
  return [...found];
}

function str(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const trimmed = decodeEntities(value).replace(/\s+/g, " ").trim();
  return trimmed.length > 0 ? trimmed.slice(0, 200) : null;
}
