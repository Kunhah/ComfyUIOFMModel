import type { EmailCategory, EmailSource, FoundEmail } from "../types";
import {
  cloudflareEmails,
  commentSources,
  decodeEntities,
  jsonLd,
  metaMap,
  scriptSources,
  styleSources,
  tags,
  textOf,
} from "./html";

/**
 * Finding the addresses.
 *
 * The naive version of this module is one line — `html.match(EMAIL_REGEX)` —
 * and on European industrial sites it finds roughly nothing, because those
 * sites have spent twenty years hiding from spambots. The addresses are behind
 * `&#64;` entities, behind `(at)`, inside JSON-LD, inside a JavaScript config
 * object, or rewritten by Cloudflare into hex. Every path below exists because
 * it was the only one that worked on some real category of site:
 *
 *   mailto        — the honest case, and the highest-confidence one: an address
 *                   put behind a link is meant for strangers to use.
 *   cloudflare    — free-plan obfuscation, on by default. Without decoding it a
 *                   fetched contact page shows zero addresses where a browser
 *                   shows four.
 *   jsonld        — schema.org Organization/ContactPoint. Increasingly common
 *                   and always accurate, because it is written for machines.
 *   meta          — `<meta name="contact" content="…">` on older CMS templates.
 *   desofuscado   — "(at)", "[dot]", " arroba ", entity-encoded, spaced out.
 *   script        — inlined `email: "…"` in a config object or form handler.
 *   comentario    — left behind in HTML comments, constantly.
 *   texto         — plain text in the page body, incl. CSS `url(mailto:…)`.
 *
 * Every candidate then goes through the same validation, so a wider net never
 * means dirtier output — only more of it.
 */

/**
 * Deliberately conservative on the local part: no quoted strings, no unicode.
 * Anything exotic enough to need them is not an address a stranger can write to.
 */
const EMAIL_RE = /[a-zA-Z0-9._%+-]{1,64}@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+/g;

/**
 * The obfuscations, undone before matching.
 *
 * Order matters: the bracketed forms are replaced before the bare-word ones, so
 * "name (at) company (dot) com" doesn't half-resolve. The bare " at " rule is
 * restricted to a context with no spaces around the neighbours precisely
 * because the unrestricted version rewrites ordinary prose ("look at company")
 * into garbage that then matches the email regex.
 */
const DEOBFUSCATIONS: [RegExp, string][] = [
  [/\s*[([{<]\s*(?:at|arroba|ät|apestaartje|chiocciola)\s*[)\]}>]\s*/gi, "@"],
  [/\s*[([{<]\s*(?:dot|punkt|punto|ponto|dt)\s*[)\]}>]\s*/gi, "."],
  [/\s+(?:at|arroba)\s+(?=[a-z0-9-]+\s*(?:\.|\s+dot\s+))/gi, "@"],
  [/\s+(?:dot|punkt|punto|ponto)\s+/gi, "."],
  // Spaced-out addresses: "info @ company . de". Only collapsed around an
  // existing @ or dot, never introduced.
  [/([a-z0-9._%+-])\s*@\s*([a-z0-9-])/gi, "$1@$2"],
  // The right-hand side is capped at a TLD-length run of letters with nothing
  // after it. Unbounded, this rule turned "presse@murrelektronik.de . Sponsoring"
  // (a bulleted contact list) into "presse@murrelektronik.de.Sponsoring", and
  // that address went out in a CSV looking perfectly plausible.
  [/([a-z0-9-])\s+\.\s*([a-z]{2,6})(?![a-z])/gi, "$1.$2"],
];

/** Never worth a row: automated senders, template leftovers, vendor noise. */
const BAD_LOCALS = new Set([
  "noreply",
  "no-reply",
  "donotreply",
  "do-not-reply",
  "newsletter",
  "mailer-daemon",
  "postmaster",
  "hostmaster",
  "abuse",
  "wordpress",
  "example",
  "test",
  "user",
  "username",
  "youremail",
  "your-email",
  "email",
  "name",
  "firstname",
  "lastname",
  "sentry",
]);

/** Domains that only ever appear as placeholders or vendor telemetry. */
const BAD_DOMAINS = [
  // Every German and Austrian imprint links the EU's online dispute-resolution
  // platform, by law. It is on thousands of sites and is never a lead.
  "ec.europa.eu",
  "europa.eu",
  "example.com",
  "example.org",
  "example.net",
  "domain.com",
  "yourdomain.com",
  "yoursite.com",
  "email.com",
  "mysite.com",
  "sentry.io",
  "sentry-next.wixpress.com",
  "wixpress.com",
  "wix.com",
  "godaddy.com",
  "w3.org",
  "schema.org",
  "squarespace.com",
  "adobe.com",
  "jquery.com",
];

/** File names that look like addresses once a path separator is lost. */
const FILE_EXTENSIONS =
  /\.(png|jpe?g|gif|svg|webp|avif|ico|css|js|mjs|json|xml|woff2?|ttf|eot|mp4|webm|pdf|zip)$/i;

/**
 * Role → how much the address is worth, and who it reaches.
 *
 * Ordered by specificity when matched: `sales_de` must be tested before `de`
 * would ever match, so lookup walks the longest key first. The weighting is the
 * point of the whole module — `ceo@` and `info@` are not the same lead, and a
 * CSV sorted by "found first" buries the one you wanted under the one every
 * scraper finds.
 */
const ROLES: { keys: string[]; category: EmailCategory; weight: number }[] = [
  {
    category: "diretoria",
    weight: 45,
    keys: [
      "ceo",
      "founder",
      "owner",
      "president",
      "praesident",
      "direktor",
      "director",
      "directeur",
      "direccion",
      "direzione",
      "direction",
      "geschaeftsfuehrung",
      "geschaeftsfuehrer",
      "gf",
      "vorstand",
      "management",
      "md",
      "inhaber",
      "diretoria",
      "diretor",
    ],
  },
  {
    category: "vendas",
    weight: 40,
    keys: [
      "sales",
      "vertrieb",
      "verkauf",
      "verkoop",
      "vendas",
      "ventas",
      "vendite",
      "commerciale",
      "commercial",
      "comercial",
      "export",
      "exportation",
      "business",
      "bd",
      "newbusiness",
      "anfrage",
      "angebot",
      "offerte",
      "quote",
      "rfq",
    ],
  },
  {
    category: "compras",
    weight: 30,
    keys: [
      "einkauf",
      "purchasing",
      "procurement",
      "compras",
      "achat",
      "acquisti",
      "inkoop",
      "supplier",
      "lieferanten",
    ],
  },
  {
    category: "engenharia",
    weight: 32,
    keys: [
      "engineering",
      "engenharia",
      "technik",
      "technical",
      "tecnico",
      "konstruktion",
      "projekt",
      "projects",
      "rnd",
      "development",
      "entwicklung",
      "it",
      "edv",
      "digital",
    ],
  },
  {
    category: "marketing",
    weight: 28,
    keys: [
      "marketing",
      "presse",
      "press",
      "media",
      "pr",
      "comunicacao",
      "communication",
      "kommunikation",
    ],
  },
  {
    category: "suporte",
    weight: 18,
    keys: [
      "support",
      "service",
      "kundenservice",
      "helpdesk",
      "assistenza",
      "soporte",
      "suporte",
      "servicio",
      "aftersales",
    ],
  },
  {
    category: "rh",
    weight: 8,
    keys: [
      "hr",
      "jobs",
      "job",
      "career",
      "careers",
      "karriere",
      "bewerbung",
      "recruiting",
      "recruitment",
      "personal",
      "rh",
      "empleo",
      "lavoro",
    ],
  },
  {
    category: "geral",
    weight: 20,
    keys: [
      "info",
      "information",
      "office",
      "buero",
      "bureau",
      "kontakt",
      "contact",
      "contacto",
      "contatto",
      "contato",
      "mail",
      "email",
      "hello",
      "hallo",
      "hola",
      "ciao",
      "welcome",
      "empresa",
      "firma",
      "zentrale",
      "central",
      "reception",
      "admin",
      "administration",
      "verwaltung",
      "webmaster",
    ],
  },
];

const ROLE_LOOKUP = new Map<
  string,
  { category: EmailCategory; weight: number }
>();
for (const role of ROLES) {
  for (const key of role.keys) {
    // First writer wins, so an earlier (higher-value) group keeps a shared word.
    if (!ROLE_LOOKUP.has(key)) {
      ROLE_LOOKUP.set(key, { category: role.category, weight: role.weight });
    }
  }
}

/** How much trust the discovery path itself earns. */
const SOURCE_BONUS: Record<EmailSource, number> = {
  mailto: 20,
  jsonld: 18,
  cloudflare: 16,
  meta: 12,
  desofuscado: 14,
  comentario: 6,
  script: 4,
  texto: 10,
};

/** Higher-numbered sources overwrite lower ones for the same address. */
const SOURCE_RANK: Record<EmailSource, number> = {
  mailto: 8,
  jsonld: 7,
  cloudflare: 6,
  desofuscado: 5,
  meta: 4,
  texto: 3,
  comentario: 2,
  script: 1,
};

/** A page whose whole purpose is contact details is evidence about its addresses. */
function pageBonus(page: string): number {
  const p = page.toLowerCase();
  if (/(impressum|contact|kontakt|contato|contacto|contatti)/.test(p))
    return 25;
  if (/(team|about|ueber|sobre|chi-siamo|equipe|management|leitung)/.test(p)) {
    return 18;
  }
  if (/(legal|privacy|datenschutz|mentions|aviso|termos)/.test(p)) return 10;
  if (p === "/" || p === "") return 8;
  return 4;
}

type Hit = { address: string; source: EmailSource };

/**
 * Every address on one page, already validated, categorised and scored.
 * `siteDomain` is what an address is checked against to see if it is the
 * company's own — a Gmail address on a German industrial site is real and
 * useful; a `@mailchimp.com` one is not the company at all.
 */
export function extractEmails(
  html: string,
  page: string,
  siteDomain: string,
): FoundEmail[] {
  const hits: Hit[] = [];

  // 1. mailto: — the address someone deliberately published.
  for (const a of tags(html, "a")) {
    const href = a.attrs.href ?? "";
    if (!/^mailto:/i.test(href.trim())) continue;
    // Strip the ?subject=… tail and any comma-separated extras.
    const raw = decodeURIComponentSafe(href.trim().slice(7).split("?")[0]);
    for (const part of raw.split(",")) push(hits, part, "mailto");
  }

  // 2. Cloudflare's obfuscation, undone.
  for (const address of cloudflareEmails(html))
    push(hits, address, "cloudflare");

  // 3. JSON-LD — any `email` field, at any depth, on any node type.
  for (const node of jsonLd(html)) {
    for (const [key, value] of Object.entries(node)) {
      if (!/email/i.test(key)) continue;
      if (typeof value === "string") push(hits, value, "jsonld");
      else if (Array.isArray(value)) {
        for (const v of value) {
          if (typeof v === "string") push(hits, v, "jsonld");
        }
      }
    }
  }

  // 4. Meta tags.
  for (const value of Object.values(metaMap(html))) {
    for (const m of value.matchAll(EMAIL_RE)) push(hits, m[0], "meta");
  }

  // 5. Inline scripts and stylesheets. `background:url(mailto:…)` is rare and
  //    real; inlined `email: "sales@…"` in a form config is common.
  for (const source of [...scriptSources(html), ...styleSources(html)]) {
    for (const m of source.matchAll(EMAIL_RE)) push(hits, m[0], "script");
  }

  // 6. Comments.
  for (const comment of commentSources(html)) {
    for (const m of decodeEntities(comment).matchAll(EMAIL_RE)) {
      push(hits, m[0], "comentario");
    }
  }

  // 7. Visible text, twice: as written, then deobfuscated. Running both is what
  //    lets the source say whether the address was hidden — and a hidden one is
  //    still worth as much, because the human behind it reads that inbox.
  const text = textOf(html);
  const plain = new Set<string>();
  for (const m of text.matchAll(EMAIL_RE)) {
    plain.add(m[0].toLowerCase());
    push(hits, m[0], "texto");
  }
  for (const m of deobfuscate(text).matchAll(EMAIL_RE)) {
    const candidate = m[0].toLowerCase();
    if (plain.has(candidate)) continue;
    // A "hidden" address that is just a visible one with something glued onto
    // the end is not a discovery, it is this pass having run two neighbouring
    // words together. The visible one is already in the list.
    if ([...plain].some((known) => candidate.startsWith(`${known}.`))) continue;
    push(hits, m[0], "desofuscado");
  }

  // Best source wins per address, then score once.
  const best = new Map<string, Hit>();
  for (const hit of hits) {
    const current = best.get(hit.address);
    if (!current || SOURCE_RANK[hit.source] > SOURCE_RANK[current.source]) {
      best.set(hit.address, hit);
    }
  }

  return [...best.values()].map((hit) =>
    scoreEmail(hit.address, hit.source, page, siteDomain),
  );
}

function decodeURIComponentSafe(value: string): string {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

export function deobfuscate(input: string): string {
  let out = decodeEntities(input);
  for (const [re, replacement] of DEOBFUSCATIONS)
    out = out.replace(re, replacement);
  return out;
}

function push(hits: Hit[], raw: string, source: EmailSource): void {
  const address = cleanAddress(raw);
  if (address) hits.push({ address, source });
}

/**
 * Normalise and validate, or return null.
 *
 * The rejections are all things that were observed producing junk rows: image
 * sprites (`logo@2x.png`), version strings, minified-bundle fragments, and the
 * placeholder addresses every CMS theme ships with.
 */
export function cleanAddress(raw: string): string | null {
  if (!raw) return null;
  let value = decodeEntities(String(raw)).trim().toLowerCase();
  // Trailing punctuation is picked up constantly from prose: "escreva para
  // info@empresa.de." — the sentence's full stop is not part of the domain.
  value = value.replace(/^[<("'\s]+/, "").replace(/[>)"'.,;:!?\s]+$/, "");
  value = value.replace(/^mailto:/, "");

  const match = /^[a-z0-9._%+-]{1,64}@[a-z0-9-]+(?:\.[a-z0-9-]+)+$/.exec(value);
  if (!match) return null;
  if (FILE_EXTENSIONS.test(value)) return null;

  const [local, domain] = value.split("@");
  if (local.startsWith(".") || local.endsWith(".") || local.includes("..")) {
    return null;
  }
  if (BAD_LOCALS.has(local)) return null;
  if (BAD_DOMAINS.some((d) => domain === d || domain.endsWith(`.${d}`))) {
    return null;
  }
  const tld = domain.slice(domain.lastIndexOf(".") + 1);
  if (!/^[a-z]{2,24}$/.test(tld)) return null;
  // 32-hex local parts are cache-busting hashes in bundles, never inboxes.
  if (/^[0-9a-f]{16,}$/.test(local)) return null;
  if (local.length > 40) return null;

  return value;
}

/** The `local@` role, if any: the longest keyword the local part starts with. */
function roleOf(
  local: string,
): { category: EmailCategory; weight: number } | null {
  const parts = local.split(/[._-]/).filter(Boolean);
  // Whole local part first ("verkauf"), then its segments ("verkauf.nord").
  const candidates = [local.replace(/[^a-z]/g, ""), ...parts];
  for (const candidate of candidates) {
    const role = ROLE_LOOKUP.get(candidate);
    if (role) return role;
  }
  return null;
}

/** `firstname.lastname@` and friends — a named human, not a shared mailbox. */
function looksPersonal(local: string): boolean {
  return (
    /^[a-z]{2,}[._-][a-z]{2,}$/.test(local) || /^[a-z]\.[a-z]{2,}$/.test(local)
  );
}

export function scoreEmail(
  address: string,
  source: EmailSource,
  page: string,
  siteDomain: string,
): FoundEmail {
  const [local, domain] = address.split("@");
  const role = roleOf(local);
  const personal = !role && looksPersonal(local);

  let score = 20; // found at all
  let category: EmailCategory = "geral";

  if (role) {
    score += role.weight;
    category = role.category;
  } else if (personal) {
    // A named person outranks every shared mailbox except the director's: a
    // reply from a human is the entire objective of the outreach.
    score += 38;
    category = "pessoal";
  } else {
    score += 10;
  }

  score += SOURCE_BONUS[source];
  score += pageBonus(page);

  // On the company's own domain, or a subdomain of it. A free-mail address on a
  // small manufacturer's site is genuine and often the owner's; one on someone
  // *else's* corporate domain is an agency, a supplier or a stray.
  const own = domain === siteDomain || domain.endsWith(`.${siteDomain}`);
  const free = FREE_MAIL.has(domain);
  if (own) score += 15;
  else if (free) score += 5;
  else score -= 20;

  return {
    address,
    score: Math.max(0, Math.min(100, Math.round(score))),
    category,
    source,
    page,
  };
}

const FREE_MAIL = new Set([
  "gmail.com",
  "googlemail.com",
  "outlook.com",
  "hotmail.com",
  "hotmail.de",
  "live.com",
  "yahoo.com",
  "yahoo.de",
  "gmx.de",
  "gmx.net",
  "gmx.at",
  "web.de",
  "t-online.de",
  "aol.com",
  "icloud.com",
  "protonmail.com",
  "proton.me",
  "orange.fr",
  "wanadoo.fr",
  "free.fr",
  "libero.it",
  "alice.it",
  "virgilio.it",
  "terra.com.br",
  "uol.com.br",
  "bol.com.br",
]);

/**
 * Merge the per-page results for one site into one ordered contact list.
 *
 * Same address on two pages is one contact, scored by its best appearance —
 * the `/impressum` sighting of `info@` beats the footer one, and the row should
 * reflect that rather than whichever page happened to be crawled last.
 */
export function mergeEmails(pages: FoundEmail[][]): FoundEmail[] {
  const best = new Map<string, FoundEmail>();
  for (const list of pages) {
    for (const email of list) {
      const current = best.get(email.address);
      if (!current || email.score > current.score)
        best.set(email.address, email);
    }
  }
  return [...best.values()].sort(
    (a, b) => b.score - a.score || a.address.localeCompare(b.address),
  );
}
