import { safeFilename } from "@/lib/prospector/csv";
import { countryLabel } from "./countries";
import { findSector } from "./sectors";
import type { Prospect, StoredProspect } from "./types";

/**
 * The export, in one place.
 *
 * Same rule as the prospector's `csv.ts`: both export paths — the board, whose
 * rows are posted back from the browser, and the history, read straight out of
 * SQLite — go through this column list, so the two files cannot drift. Adding a
 * column in a route handler is how they drifted last time.
 *
 * Row order is the sales order: who the company is, then the one address to
 * write to, then the rest of the contacts, then the qualifying evidence. The
 * first six columns are all a person needs to send the email.
 */

type ExportProspect = Prospect & Partial<Omit<StoredProspect, keyof Prospect>>;

type Column = {
  header: string;
  kind: "text" | "number";
  get: (p: ExportProspect) => string;
};

const COLUMNS: Column[] = [
  { header: "empresa", kind: "text", get: (p) => p.name },
  {
    header: "email",
    kind: "text",
    get: (p) => p.emails[0]?.address ?? "",
  },
  {
    header: "email_tipo",
    kind: "text",
    get: (p) => p.emails[0]?.category ?? "",
  },
  { header: "site", kind: "text", get: (p) => p.website },
  { header: "pais", kind: "text", get: (p) => countryLabel(p.country) },
  { header: "cidade", kind: "text", get: (p) => p.city ?? "" },
  { header: "score", kind: "number", get: (p) => String(p.score) },
  {
    header: "setor",
    kind: "text",
    get: (p) => (p.sector ? (findSector(p.sector)?.label ?? p.sector) : ""),
  },
  {
    // Everything else found, so a bounced primary address doesn't cost the lead.
    header: "outros_emails",
    kind: "text",
    get: (p) =>
      p.emails
        .slice(1)
        .map((e) => e.address)
        .join("; "),
  },
  {
    header: "qtd_emails",
    kind: "number",
    get: (p) => String(p.emails.length),
  },
  {
    // E.164 digits with the plus dropped, the same call the prospector's export
    // makes: Excel reads a leading "+" as a formula, and the apostrophe that
    // escapes it stays visible in every other tool. The country code is still
    // there, so the number remains unambiguous and pastes into a dialer.
    header: "telefone",
    kind: "text",
    get: (p) => (p.phones[0] ?? p.phone ?? "").replace(/^\+/, ""),
  },
  { header: "linkedin", kind: "text", get: (p) => p.socials.linkedin ?? "" },
  { header: "endereco", kind: "text", get: (p) => p.address ?? "" },
  { header: "cep", kind: "text", get: (p) => p.postalCode ?? "" },
  { header: "vat", kind: "text", get: (p) => p.vat ?? "" },
  { header: "registro", kind: "text", get: (p) => p.registration ?? "" },
  { header: "funcionarios", kind: "text", get: (p) => p.employees ?? "" },
  { header: "idiomas", kind: "text", get: (p) => p.languages.join("; ") },
  {
    header: "tecnologias",
    kind: "text",
    get: (p) => p.technologies.join("; "),
  },
  { header: "sinais", kind: "text", get: (p) => p.reasons.join("; ") },
  { header: "status", kind: "text", get: (p) => p.status },
  { header: "paginas", kind: "number", get: (p) => String(p.pages) },
  { header: "dominio", kind: "text", get: (p) => p.domain },
  { header: "fonte", kind: "text", get: (p) => p.source },
];

/** Only exist for rows that came out of SQLite. */
const HISTORY_COLUMNS: Column[] = [
  { header: "pipeline", kind: "text", get: (p) => p.outreach ?? "" },
  { header: "primeiro_visto", kind: "text", get: (p) => p.firstSeenAt ?? "" },
  { header: "ultimo_visto", kind: "text", get: (p) => p.lastSeenAt ?? "" },
];

export function buildCsv(
  prospects: ExportProspect[],
  options: { includeHistory?: boolean } = {},
): string {
  const columns = options.includeHistory
    ? [...COLUMNS, ...HISTORY_COLUMNS]
    : COLUMNS;

  const lines = [
    columns.map((c) => quote(c.header)).join(","),
    ...prospects.map((prospect) =>
      columns
        .map((column) => {
          const value = column.get(prospect) ?? "";
          // Numbers are ours, never scraped text — emitted bare so spreadsheets
          // type them as numbers and can sort on them.
          return column.kind === "number" ? value : quote(guard(value));
        })
        .join(","),
    ),
  ];

  // Excel in a pt-BR locale won't detect UTF-8 without a BOM, and every German
  // company name in the file would arrive mangled.
  return "\ufeff" + lines.join("\r\n");
}

export function csvResponse(
  prospects: ExportProspect[],
  filename: string,
  options: { includeHistory?: boolean } = {},
): Response {
  return new Response(buildCsv(prospects, options), {
    headers: {
      "content-type": "text/csv; charset=utf-8",
      "content-disposition": `attachment; filename="${safeFilename(filename)}.csv"`,
    },
  });
}

/**
 * A leading =, +, - or @ makes Excel and Sheets evaluate the cell. Every phone
 * number here starts with a plus and every email column could start with an @,
 * so this is not theoretical.
 */
function guard(value: string): string {
  return /^[=+\-@\t\r]/.test(value) ? `'${value}` : value;
}

function quote(value: string): string {
  return `"${value.replace(/"/g, '""')}"`;
}
