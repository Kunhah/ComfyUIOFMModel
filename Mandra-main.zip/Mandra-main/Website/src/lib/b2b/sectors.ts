/**
 * B2B sector → Overture `categories.primary`.
 *
 * Same contract as `niches.ts` on the prospector side, and the same two rules:
 * the category strings are copied from the live vocabulary in
 * `src/data/prospector/overture-categories.csv` (an invented one matches nothing
 * and fails silently), and **a category belongs to exactly one sector** —
 * enforced by the assertion at the bottom, because a category in two sectors
 * makes every per-sector count fiction.
 *
 * What is *not* the same is the selection. The prospector goes after businesses
 * with no website at all, which is a consumer-facing, low-ticket pool. Here we
 * deliberately want the opposite end: companies whose commercial operation is
 * complex enough that software is a capital purchase rather than a brochure —
 * manufacturers, machine shops, chemical plants, laboratories, hospitals,
 * insurers, asset managers, universities, ISPs, logistics operators. They all
 * have a site, that site is usually a decade old, and one automation, portal or
 * integration project for them is worth dozens of salon websites.
 *
 * They are also, in the client's words, the *less obvious* companies. Nobody is
 * cold-mailing a lift-maintenance firm in Graz or an industrial packaging
 * converter in Westphalia, which is exactly why the reply rate there is what it
 * is. That is the whole selection criterion for what got added: high contract
 * value *and* low competitive pressure in the inbox. Categories that are
 * high-value but already saturated with agency mail (marketing agencies, web
 * designers) live on the prospector side as partnership targets, not here.
 */

export type Sector = {
  slug: string;
  label: string;
  /** Coarse family, used to group the dropdown. */
  group: string;
  /**
   * Rough deal size for the kind of work Mandra sells, 1–5. It is a prior, not a
   * measurement — it breaks ties between two otherwise equal prospects and
   * nothing more, so a hospital group with a reachable director outranks a print
   * shop with the same. The scale is deliberately wide because the registry now
   * spans two orders of magnitude of contract value:
   *
   *   1 — site institucional, compra única e barata
   *   2 — PME comum, um projeto pequeno por vez
   *   3 — bom ticket: portal, catálogo técnico, integração pontual
   *   4 — ticket alto: plataforma, automação de processo, contrato recorrente
   *   5 — ticket máximo: operação crítica, compliance, vários sistemas ligados
   */
  ticket: 1 | 2 | 3 | 4 | 5;
  /**
   * One line, pt-BR, on *what there is to sell here*. Rendered on the picker, so
   * whoever runs the search is choosing a pitch rather than a noun — and so a
   * sector nobody recognises ("Elevadores e sistemas de acesso") still explains
   * itself without anyone having to open this file.
   */
  note?: string;
  categories: string[];
};

/**
 * A buying-oriented search profile. Unlike a sector, a profile may span
 * several sectors: the companies that sell standard parts, for example, are
 * classified by Overture as metal suppliers, industrial equipment or B2B
 * electronics. Keeping this separate preserves the one-category/one-sector
 * invariant used by history and scoring.
 */
export type DiscoveryCampaign = {
  slug: string;
  label: string;
  group: "Campanhas de alto valor";
  note?: string;
  /** Sector slugs, rather than a second copy of category names. */
  sectors: string[];
  /**
   * Instead of naming sectors, take every sector at or above this ticket. It is
   * a *derived* membership on purpose: retuning one sector's ticket has to move
   * it in and out of the high-value campaign, or the campaign slowly stops
   * meaning what its label says.
   */
  minTicket?: 1 | 2 | 3 | 4 | 5;
  /** No category constraint: requires an extract built with `--universal`. */
  universal?: boolean;
};

export type DiscoveryTarget = Pick<
  Sector,
  "slug" | "label" | "group" | "note" | "categories"
> & {
  kind: "sector" | "campaign";
  /** For a campaign, the highest ticket among its members. */
  ticket: 1 | 2 | 3 | 4 | 5;
};

export const SECTORS: Sector[] = [
  // --- Indústria e manufatura -----------------------------------------------
  {
    slug: "metalurgia",
    label: "Metalurgia e siderurgia",
    group: "Indústria",
    ticket: 4,
    note: "Catálogo de perfis e ligas, cotação por peso, portal de pedidos.",
    categories: [
      "metal_fabricator",
      "iron_and_steel_industry",
      "metal_supplier",
      "metals",
      "metal_plating_service",
    ],
  },
  {
    slug: "usinagem",
    label: "Usinagem e CNC",
    group: "Indústria",
    ticket: 4,
    note: "Orçamento a partir de desenho, acompanhamento de ordem de produção.",
    categories: ["machine_shop"],
  },
  {
    slug: "maquinas-industriais",
    label: "Máquinas e equipamentos industriais",
    group: "Indústria",
    ticket: 5,
    note: "Configurador de máquina, pós-venda, peças de reposição e manuais.",
    categories: ["industrial_equipment", "business_manufacturing_and_supply"],
  },
  {
    slug: "industria-geral",
    label: "Indústria em geral",
    group: "Indústria",
    ticket: 4,
    categories: ["industrial_company", "commercial_industrial"],
  },
  {
    slug: "plasticos",
    label: "Plásticos e borracha",
    group: "Indústria",
    ticket: 4,
    note: "Ficha técnica por material, ferramental, rastreio de lote.",
    categories: [
      "plastic_manufacturer",
      "plastic_fabrication_company",
      "plastic_company",
    ],
  },
  {
    slug: "quimica",
    label: "Química",
    group: "Indústria",
    ticket: 5,
    note: "FISPQ, controle de lote e documentação regulatória — puro processo.",
    categories: ["chemical_plant"],
  },
  {
    slug: "vidro-pedra",
    label: "Vidro, pedra e cerâmica",
    group: "Indústria",
    ticket: 3,
    categories: [
      "glass_manufacturer",
      "granite_supplier",
      "glass_and_mirror_sales_service",
    ],
  },
  {
    slug: "eletronica",
    label: "Eletrônica e hardware",
    group: "Indústria",
    ticket: 4,
    note: "Datasheet, matriz de compatibilidade, integração com distribuidores.",
    categories: [
      "b2b_electronic_equipment",
      "electronics",
      "computer_hardware_company",
    ],
  },
  {
    slug: "embalagens",
    label: "Embalagens e acondicionamento",
    group: "Indústria",
    ticket: 4,
    note: "Convertedores vendem por tiragem e arte — cotação e prova online.",
    categories: ["packing_supply"],
  },
  {
    slug: "bens-consumo",
    label: "Manufatura de bens de consumo",
    group: "Indústria",
    ticket: 3,
    categories: [
      "appliance_manufacturer",
      "mattress_manufacturing",
      "jewelry_and_watches_manufacturer",
      "bags_luggage_company",
      "clothing_company",
    ],
  },
  {
    slug: "bebidas-industria",
    label: "Cervejarias e vinícolas",
    group: "Indústria",
    ticket: 3,
    note: "Produção própria com distribuição, clube de assinatura e exportação.",
    categories: ["brewery", "winery"],
  },
  {
    slug: "automotivo",
    label: "Automotivo e autopeças",
    group: "Indústria",
    ticket: 4,
    note: "Catálogo por aplicação (marca/modelo/ano) — o clássico projeto grande.",
    categories: [
      "auto_manufacturers_and_distributors",
      "auto_company",
      "automotive_parts_and_accessories",
    ],
  },

  // --- Engenharia -----------------------------------------------------------
  {
    slug: "automacao",
    label: "Automação industrial",
    group: "Engenharia",
    ticket: 5,
    note: "Já compram software; a venda é integração, não site.",
    categories: ["automation_services"],
  },
  {
    slug: "engenharia",
    label: "Engenharia e projetos",
    group: "Engenharia",
    ticket: 4,
    categories: ["engineering_services", "structural_engineer"],
  },
  {
    slug: "arquitetura",
    label: "Arquitetura e projeto",
    group: "Engenharia",
    ticket: 3,
    note: "Portfólio pesado, aprovação de projeto com cliente, gestão de revisões.",
    categories: ["architectural_designer", "architect"],
  },
  {
    slug: "design-produto",
    label: "Design de produto",
    group: "Engenharia",
    ticket: 3,
    categories: ["product_design"],
  },
  {
    slug: "construcao-industrial",
    label: "Construção e empreiteiras",
    group: "Engenharia",
    ticket: 3,
    categories: ["construction_services", "contractor"],
  },
  {
    slug: "construcao-pesada",
    label: "Construção pesada e fundações",
    group: "Engenharia",
    ticket: 4,
    note: "Concreto, sondagem e poços: medição de obra e diário eletrônico.",
    categories: ["masonry_concrete", "well_drilling"],
  },
  {
    slug: "materiais-construcao",
    label: "Materiais de construção e madeireiras",
    group: "Engenharia",
    ticket: 3,
    note: "Depósito com preço por praça — e-commerce B2B com tabela por cliente.",
    categories: ["building_supply_store", "lumber_store"],
  },
  {
    slug: "climatizacao",
    label: "Climatização e refrigeração",
    group: "Engenharia",
    ticket: 3,
    categories: ["hvac_services", "commercial_refrigeration"],
  },
  {
    slug: "elevadores",
    label: "Elevadores e sistemas de acesso",
    group: "Engenharia",
    ticket: 4,
    note: "Base instalada + contrato de manutenção: agenda, chamado, laudo.",
    categories: ["elevator_service"],
  },
  {
    slug: "seguranca-patrimonial",
    label: "Segurança patrimonial e incêndio",
    group: "Engenharia",
    ticket: 4,
    note: "Ronda, alarme monitorado e inspeção periódica — tudo em planilha hoje.",
    categories: [
      "fire_protection_service",
      "security_systems",
      "security_services",
      "home_security",
    ],
  },

  // --- Energia e ambiente ---------------------------------------------------
  {
    slug: "energia",
    label: "Energia e utilities",
    group: "Energia e ambiente",
    ticket: 5,
    categories: [
      "energy_company",
      "energy_equipment_and_solution",
      "electric_utility_provider",
      "public_utility_company",
    ],
  },
  {
    slug: "solar",
    label: "Solar e renováveis",
    group: "Energia e ambiente",
    ticket: 3,
    categories: ["solar_installation"],
  },
  {
    slug: "agua",
    label: "Água e saneamento",
    group: "Energia e ambiente",
    ticket: 4,
    categories: ["water_treatment_equipment_and_services", "water_supplier"],
  },
  {
    slug: "residuos",
    label: "Resíduos, reciclagem e desmanche",
    group: "Energia e ambiente",
    ticket: 4,
    note: "Coleta com rota, pesagem e MTR: logística e compliance ambiental.",
    categories: ["recycling_center", "garbage_collection_service", "junkyard"],
  },
  {
    slug: "ambiental",
    label: "Serviços ambientais",
    group: "Energia e ambiente",
    ticket: 3,
    categories: ["environmental_and_ecological_services_for_businesses"],
  },
  {
    slug: "mineracao",
    label: "Mineração e geologia",
    group: "Energia e ambiente",
    ticket: 5,
    categories: ["mining", "geological_services"],
  },

  // --- Saúde e ciências da vida ---------------------------------------------
  {
    slug: "hospitais",
    label: "Hospitais e centros médicos",
    group: "Saúde e ciências da vida",
    ticket: 5,
    note: "Agendamento, portal do paciente, convênios. Ticket alto, site antigo.",
    categories: [
      "hospital",
      "medical_center",
      "surgical_center",
      "emergency_room",
    ],
  },
  {
    slug: "redes-clinicas",
    label: "Redes de clínicas e diagnóstico",
    group: "Saúde e ciências da vida",
    ticket: 4,
    note: "Laudo online, agenda multiunidade, integração com laboratório.",
    categories: [
      "medical_service_organizations",
      "diagnostic_services",
      "dialysis_clinic",
      "womens_health_clinic",
    ],
  },
  {
    slug: "longa-permanencia",
    label: "Longa permanência e home care",
    group: "Saúde e ciências da vida",
    ticket: 4,
    note: "Escala de cuidador, prontuário e comunicação com a família.",
    categories: [
      "retirement_home",
      "hospice",
      "home_health_care",
      "maternity_centers",
    ],
  },
  {
    slug: "laboratorios",
    label: "Laboratórios e ensaios",
    group: "Saúde e ciências da vida",
    ticket: 4,
    note: "Ensaio com prazo e certificado: portal de resultados é a venda óbvia.",
    categories: ["laboratory_testing", "laboratory"],
  },
  {
    slug: "farmaceutica",
    label: "Farmacêutica",
    group: "Saúde e ciências da vida",
    ticket: 5,
    categories: ["pharmaceutical_companies"],
  },
  {
    slug: "biotecnologia",
    label: "Biotecnologia e ciência",
    group: "Saúde e ciências da vida",
    ticket: 5,
    categories: ["biotechnology_company", "b2b_science_and_technology"],
  },
  {
    slug: "pesquisa",
    label: "Pesquisa e desenvolvimento",
    group: "Saúde e ciências da vida",
    ticket: 5,
    note: "Institutos de P&D: financiados por projeto e sem ninguém prospectando.",
    categories: [
      "medical_research_and_development",
      "educational_research_institute",
    ],
  },
  {
    slug: "dispositivos-medicos",
    label: "Dispositivos médicos e órteses",
    group: "Saúde e ciências da vida",
    ticket: 4,
    note: "Produto regulado com prescrição e rastreio — catálogo técnico sério.",
    categories: ["surgical_appliances_and_supplies", "prosthetics"],
  },
  {
    slug: "suprimentos-medicos",
    label: "Suprimentos médicos",
    group: "Saúde e ciências da vida",
    ticket: 4,
    categories: ["medical_supply"],
  },
  {
    slug: "saude-ocupacional",
    label: "Saúde e segurança do trabalho",
    group: "Saúde e ciências da vida",
    ticket: 4,
    note: "Exame periódico, laudo e treinamento por empresa cliente. Recorrente.",
    categories: ["occupational_safety"],
  },

  // --- Serviços financeiros -------------------------------------------------
  {
    slug: "seguros",
    label: "Seguros e corretoras",
    group: "Serviços financeiros",
    ticket: 5,
    note: "Cotação, apólice e sinistro. Processo inteiro, quase sempre manual.",
    categories: ["insurance_agency"],
  },
  {
    slug: "bancos",
    label: "Bancos e cooperativas de crédito",
    group: "Serviços financeiros",
    ticket: 5,
    note: "Cooperativas regionais compram como banco e têm site de 2011.",
    categories: ["banks", "bank_credit_union", "credit_union"],
  },
  {
    slug: "gestao-ativos",
    label: "Gestão de ativos e investimentos",
    group: "Serviços financeiros",
    ticket: 5,
    note: "Área do investidor, relatório periódico, onboarding com KYC.",
    categories: ["investing", "brokers", "trusts", "financial_advising"],
  },
  {
    slug: "credito-cobranca",
    label: "Crédito, cobrança e pagamentos",
    group: "Serviços financeiros",
    ticket: 4,
    note: "Régua de cobrança, portal de negociação, conciliação.",
    categories: [
      "installment_loans",
      "collection_agencies",
      "mortgage_broker",
      "credit_and_debt_counseling",
      "money_transfer_services",
      "currency_exchange",
      "atms",
    ],
  },
  {
    slug: "servicos-financeiros",
    label: "Serviços financeiros em geral",
    group: "Serviços financeiros",
    ticket: 4,
    categories: ["financial_service"],
  },

  // --- Imobiliário e ativos -------------------------------------------------
  {
    slug: "imobiliario-corporativo",
    label: "Imobiliário corporativo e industrial",
    group: "Imobiliário e ativos",
    ticket: 5,
    note: "Galpão e laje: ficha de ativo, proposta e due diligence. Não é corretor.",
    categories: ["commercial_real_estate", "real_estate_investment"],
  },
  {
    slug: "incorporacao",
    label: "Incorporação e loteamento",
    group: "Imobiliário e ativos",
    ticket: 5,
    note: "Lançamento com tabela de unidades, reserva online e repasse.",
    categories: ["home_developer"],
  },
  {
    slug: "administracao-predial",
    label: "Administração predial e condomínios",
    group: "Imobiliário e ativos",
    ticket: 4,
    note: "Boleto, assembleia, chamado de manutenção — recorrência por unidade.",
    categories: ["property_management", "condominium", "housing_authorities"],
  },
  {
    slug: "leiloes",
    label: "Leilões e comércio de ativos",
    group: "Imobiliário e ativos",
    ticket: 3,
    note: "Lote, lance e habilitação: plataforma inteira, quase nunca própria.",
    categories: ["auction_house"],
  },

  // --- Atacado e distribuição -----------------------------------------------
  {
    slug: "atacado",
    label: "Atacado e serviços B2B",
    group: "Atacado",
    ticket: 3,
    categories: ["wholesale_store", "business_to_business_services"],
  },
  {
    slug: "distribuicao-alimentos",
    label: "Distribuição de alimentos e bebidas",
    group: "Atacado",
    ticket: 3,
    categories: [
      "food_beverage_service_distribution",
      "wholesale_grocer",
      "meat_wholesaler",
      "bottled_water_company",
    ],
  },
  {
    slug: "textil",
    label: "Têxtil e vestuário B2B",
    group: "Atacado",
    ticket: 3,
    categories: ["b2b_textiles", "b2b_apparel"],
  },
  {
    slug: "joias-b2b",
    label: "Joias B2B",
    group: "Atacado",
    ticket: 2,
    categories: ["b2b_jewelers"],
  },
  {
    slug: "equipamentos-comerciais",
    label: "Equipamentos comerciais",
    group: "Atacado",
    ticket: 3,
    categories: [
      "office_equipment",
      "restaurant_equipment_and_supply",
      "hotel_supply_service",
      "vending_machine_supplier",
      "beauty_product_supplier",
    ],
  },
  {
    slug: "suprimentos-corporativos",
    label: "Suprimentos corporativos e uniformes",
    group: "Atacado",
    ticket: 3,
    note: "Compra recorrente por contrato: catálogo fechado por cliente.",
    categories: [
      "business_office_supplies_and_stationery",
      "uniform_store",
      "merchandising_service",
    ],
  },
  {
    slug: "ti-atacado",
    label: "Distribuição de TI",
    group: "Atacado",
    ticket: 3,
    categories: ["computer_wholesaler"],
  },
  {
    slug: "editorial",
    label: "Editorial e mídia impressa",
    group: "Atacado",
    ticket: 2,
    categories: ["book_magazine_distribution"],
  },

  // --- Logística e frota ----------------------------------------------------
  {
    slug: "logistica",
    label: "Logística e transporte de carga",
    group: "Logística e frota",
    ticket: 4,
    note: "Cotação de frete, rastreio e canhoto: o portal que ninguém tem.",
    categories: ["freight_and_cargo_service", "shipping_center", "warehouses"],
  },
  {
    slug: "armazenagem",
    label: "Armazenagem e última milha",
    group: "Logística e frota",
    ticket: 4,
    note: "Ocupação de posição-palete, entrada/saída e entrega final.",
    categories: [
      "storage_facility",
      "self_storage_facility",
      "courier_and_delivery_services",
    ],
  },
  {
    slug: "veiculos-pesados",
    label: "Veículos pesados e frotas",
    group: "Logística e frota",
    ticket: 4,
    note: "Concessionária de caminhão: estoque, oficina e plano de manutenção.",
    categories: ["truck_dealer", "commercial_vehicle_dealer", "truck_repair"],
  },
  {
    slug: "locacao-equipamentos",
    label: "Locação de equipamentos e frota",
    group: "Logística e frota",
    ticket: 4,
    note: "Disponibilidade por período e contrato — puro sistema de reserva.",
    categories: ["rental_service", "rental_services", "car_rental_agency"],
  },
  {
    slug: "aviacao-nautica",
    label: "Aviação e náutica",
    group: "Logística e frota",
    ticket: 5,
    note: "Táxi aéreo, hangar e estaleiro: poucos players, contrato altíssimo.",
    categories: [
      "airline",
      "airlines",
      "heliports",
      "flight_school",
      "boat_dealer",
    ],
  },

  // --- Serviços profissionais -----------------------------------------------
  {
    slug: "juridico-empresarial",
    label: "Jurídico empresarial",
    group: "Serviços profissionais",
    ticket: 4,
    note: "Bancas de tributário, trabalhista e PI — não o criminalista de bairro.",
    categories: [
      "legal_services",
      "employment_law",
      "tax_law",
      "ip_and_internet_law",
      "real_estate_law",
      "medical_law",
      "immigration_law",
    ],
  },
  {
    slug: "contabilidade",
    label: "Contabilidade, auditoria e cartórios",
    group: "Serviços profissionais",
    ticket: 4,
    note: "Carteira de clientes com entrega mensal: portal do cliente vende só.",
    categories: ["accountant", "notary_public"],
  },
  {
    slug: "consultoria",
    label: "Consultoria e gestão empresarial",
    group: "Serviços profissionais",
    ticket: 4,
    categories: [
      "business_consulting",
      "business_management_services",
      "appraisal_services",
    ],
  },
  {
    slug: "recrutamento",
    label: "Recrutamento e gestão de pessoas",
    group: "Serviços profissionais",
    ticket: 4,
    note: "Vaga, triagem e banco de talentos — fluxo inteiro, hoje em e-mail.",
    categories: ["employment_agencies", "career_counseling"],
  },
  {
    slug: "traducao",
    label: "Tradução e localização",
    group: "Serviços profissionais",
    ticket: 3,
    note: "Orçamento por lauda e entrega de arquivo: nicho pequeno e fiel.",
    categories: ["translating_and_interpreting_services"],
  },

  // --- Serviços corporativos ------------------------------------------------
  {
    slug: "escritorios-corporativos",
    label: "Sedes e escritórios corporativos",
    group: "Serviços corporativos",
    ticket: 5,
    note: "O curinga: empresas grandes que o Overture só sabe classificar assim.",
    categories: ["corporate_office", "business_to_business"],
  },
  {
    slug: "contact-center",
    label: "Contact center e televendas",
    group: "Serviços corporativos",
    ticket: 4,
    note: "Operação por posição de atendimento — integração e discador.",
    categories: ["telemarketing_services"],
  },
  {
    slug: "facilities",
    label: "Facilities e limpeza corporativa",
    group: "Serviços corporativos",
    ticket: 3,
    note: "Posto de trabalho por contrato: escala, ponto e medição.",
    categories: ["janitorial_services"],
  },
  {
    slug: "coworking",
    label: "Coworking e espaços de trabalho",
    group: "Serviços corporativos",
    ticket: 3,
    categories: ["coworking_space"],
  },

  // --- Educação -------------------------------------------------------------
  {
    slug: "ensino-superior",
    label: "Ensino superior e pesquisa aplicada",
    group: "Educação",
    ticket: 5,
    note: "Captação, matrícula e portal do aluno. Orçamento anual, compra lenta.",
    categories: ["college_university", "medical_school"],
  },
  {
    slug: "educacao-basica",
    label: "Escolas privadas",
    group: "Educação",
    ticket: 4,
    note: "Matrícula, mensalidade e comunicação com os pais. Recorrência real.",
    categories: ["private_school"],
  },
  {
    slug: "educacao-corporativa",
    label: "Educação técnica e corporativa",
    group: "Educação",
    ticket: 3,
    categories: [
      "vocational_and_technical_school",
      "educational_services",
      "language_school",
    ],
  },

  // --- Hospitalidade --------------------------------------------------------
  {
    slug: "hotelaria",
    label: "Hotelaria e resorts",
    group: "Hospitalidade",
    ticket: 4,
    note: "Reserva direta em vez de OTA — a economia paga o projeto sozinha.",
    categories: ["hotel", "resort", "accommodation", "service_apartments"],
  },
  {
    slug: "eventos-corporativos",
    label: "Eventos corporativos e espaços",
    group: "Hospitalidade",
    ticket: 3,
    categories: ["venue_and_event_space", "auditorium"],
  },

  // --- Tecnologia e telecom -------------------------------------------------
  {
    slug: "provedores",
    label: "Provedores de internet e TV",
    group: "Tecnologia",
    ticket: 5,
    note: "ISP regional: viabilidade, contrato, segunda via e chamado técnico.",
    categories: [
      "internet_service_provider",
      "telecommunications",
      "television_service_providers",
    ],
  },
  {
    slug: "telecom",
    label: "Telecomunicações",
    group: "Tecnologia",
    ticket: 5,
    categories: ["telecommunications_company"],
  },
  {
    slug: "software",
    label: "Software e TI",
    group: "Tecnologia",
    ticket: 3,
    categories: ["software_development", "information_technology_company"],
  },
  {
    slug: "ti-servicos",
    label: "Serviços de TI",
    group: "Tecnologia",
    ticket: 2,
    categories: ["it_service_and_computer_repair", "it_support_and_service"],
  },
  {
    slug: "ecommerce-operacao",
    label: "E-commerce e operação digital",
    group: "Tecnologia",
    ticket: 3,
    categories: ["e_commerce_service", "online_shop"],
  },
  {
    slug: "grafica",
    label: "Gráfica e sinalização",
    group: "Tecnologia",
    ticket: 2,
    categories: [
      "printing_services",
      "screen_printing_t_shirt_printing",
      "sign_making",
    ],
  },

  // --- Mídia e produção -----------------------------------------------------
  {
    slug: "producao-audiovisual",
    label: "Produção audiovisual",
    group: "Mídia e produção",
    ticket: 3,
    categories: [
      "movie_television_studio",
      "broadcasting_media_production",
      "animation_studio",
      "theatrical_productions",
    ],
  },
  {
    slug: "veiculos-imprensa",
    label: "Veículos de imprensa e publishing",
    group: "Mídia e produção",
    ticket: 3,
    note: "Assinatura, paywall e mídia kit — receita que hoje passa por fora.",
    categories: [
      "media_news_company",
      "mass_media",
      "print_media",
      "topic_publisher",
      "radio_station",
    ],
  },
  {
    slug: "musica-audio",
    label: "Música e áudio",
    group: "Mídia e produção",
    ticket: 2,
    categories: [
      "music_production",
      "record_label",
      "recording_and_rehearsal_studio",
    ],
  },

  // --- Agro -----------------------------------------------------------------
  {
    slug: "agro",
    label: "Agronegócio",
    group: "Agro",
    ticket: 3,
    note: "Cooperativas: cotação de insumo, entrega de safra, área do cooperado.",
    categories: [
      "agriculture",
      "agricultural_service",
      "agricultural_cooperatives",
      "farm",
    ],
  },
  {
    slug: "madeira",
    label: "Madeira e florestal",
    group: "Agro",
    ticket: 3,
    categories: ["logging_services"],
  },
];

/** category → sector slug. Also the proof that no category is claimed twice. */
const BY_CATEGORY = new Map<string, string>();
for (const sector of SECTORS) {
  for (const category of sector.categories) {
    const owner = BY_CATEGORY.get(category);
    if (owner) {
      // Thrown at import on purpose, exactly like niches.ts: an overlapping
      // category silently splits a sector's leads between two slugs, and you
      // only notice months later when the counts refuse to add up.
      throw new Error(
        `Categoria "${category}" está em dois setores: "${owner}" e "${sector.slug}".`,
      );
    }
    BY_CATEGORY.set(category, sector.slug);
  }
}

const BY_SLUG = new Map(SECTORS.map((s) => [s.slug, s]));

/**
 * Curated combinations for the less obvious, higher-ticket businesses. They
 * intentionally favour firms that sell technical products or operate a complex
 * commercial process — a much better fit for a portal, quoting workflow or
 * integration than a generic local-service search.
 */
export const DISCOVERY_CAMPAIGNS: DiscoveryCampaign[] = [
  {
    slug: "campanha-ticket-maximo",
    label: "Ticket máximo — toda a faixa 5",
    group: "Campanhas de alto valor",
    note: "Operações críticas: hospital, seguradora, ISP, química, mineração.",
    sectors: [],
    minTicket: 5,
  },
  {
    slug: "campanha-alto-valor",
    label: "Alto valor — faixa 4 e acima",
    group: "Campanhas de alto valor",
    note: "A varredura padrão quando você quer volume sem descer de ticket.",
    sectors: [],
    minTicket: 4,
  },
  {
    slug: "campanha-radar-amplo",
    label: "Radar amplo — empresas B2B escondidas",
    group: "Campanhas de alto valor",
    note: "Sem filtro de categoria: acha o que o Overture classificou torto.",
    sectors: [],
    universal: true,
  },
  {
    slug: "campanha-fabricas",
    label: "Fábricas e plantas industriais",
    group: "Campanhas de alto valor",
    note: "Quem produz: metalurgia, usinagem, química, plástico, embalagem, autopeças.",
    sectors: [
      "industria-geral",
      "metalurgia",
      "usinagem",
      "maquinas-industriais",
      "plasticos",
      "quimica",
      "eletronica",
      "embalagens",
      "automotivo",
      "bens-consumo",
      "vidro-pedra",
    ],
  },
  {
    slug: "campanha-componentes-industriais",
    label: "Componentes industriais e peças normalizadas",
    group: "Campanhas de alto valor",
    sectors: ["metalurgia", "maquinas-industriais", "eletronica", "automotivo"],
  },
  {
    slug: "campanha-fabrica-conectada",
    label: "Fábrica conectada e engenharia de produção",
    group: "Campanhas de alto valor",
    sectors: ["usinagem", "automacao", "engenharia", "maquinas-industriais"],
  },
  {
    slug: "campanha-processos-regulados",
    label: "Processos regulados: química, laboratório e saúde",
    group: "Campanhas de alto valor",
    sectors: [
      "quimica",
      "laboratorios",
      "farmaceutica",
      "biotecnologia",
      "suprimentos-medicos",
      "dispositivos-medicos",
    ],
  },
  {
    slug: "campanha-saude-privada",
    label: "Saúde privada: hospitais, clínicas e cuidado",
    group: "Campanhas de alto valor",
    note: "Agenda, prontuário e convênio — compra grande e pouco disputada.",
    sectors: [
      "hospitais",
      "redes-clinicas",
      "longa-permanencia",
      "saude-ocupacional",
    ],
  },
  {
    slug: "campanha-financeiro",
    label: "Financeiro: seguro, crédito e gestão de ativos",
    group: "Campanhas de alto valor",
    note: "Processo regulado de ponta a ponta, quase sempre fora de sistema.",
    sectors: [
      "seguros",
      "bancos",
      "gestao-ativos",
      "credito-cobranca",
      "servicos-financeiros",
    ],
  },
  {
    slug: "campanha-ativos-imobiliarios",
    label: "Ativos imobiliários: incorporação e administração",
    group: "Campanhas de alto valor",
    sectors: [
      "imobiliario-corporativo",
      "incorporacao",
      "administracao-predial",
      "construcao-pesada",
    ],
  },
  {
    slug: "campanha-infraestrutura-industrial",
    label: "Infraestrutura industrial: energia, água e climatização",
    group: "Campanhas de alto valor",
    sectors: ["energia", "agua", "climatizacao", "ambiental", "residuos"],
  },
  {
    slug: "campanha-infra-critica",
    label: "Infraestrutura crítica: telecom, provedores e utilities",
    group: "Campanhas de alto valor",
    sectors: ["provedores", "telecom", "energia", "agua"],
  },
  {
    slug: "campanha-cadeia-b2b",
    label: "Cadeia B2B: distribuição técnica e logística",
    group: "Campanhas de alto valor",
    sectors: [
      "atacado",
      "equipamentos-comerciais",
      "suprimentos-corporativos",
      "ti-atacado",
      "logistica",
      "armazenagem",
    ],
  },
  {
    slug: "campanha-frota-mobilidade",
    label: "Frota e mobilidade: pesados, locação e aviação",
    group: "Campanhas de alto valor",
    sectors: [
      "veiculos-pesados",
      "locacao-equipamentos",
      "aviacao-nautica",
      "armazenagem",
    ],
  },
  {
    slug: "campanha-servicos-profissionais",
    label: "Serviços profissionais com carteira recorrente",
    group: "Campanhas de alto valor",
    note: "Contabilidade, banca e RH: entregam todo mês e não têm portal.",
    sectors: [
      "juridico-empresarial",
      "contabilidade",
      "consultoria",
      "recrutamento",
    ],
  },
  {
    slug: "campanha-educacao-hospitalidade",
    label: "Educação e hospitalidade com receita recorrente",
    group: "Campanhas de alto valor",
    sectors: [
      "ensino-superior",
      "educacao-basica",
      "hotelaria",
      "eventos-corporativos",
    ],
  },
];

const CAMPAIGN_BY_SLUG = new Map(
  DISCOVERY_CAMPAIGNS.map((campaign) => [campaign.slug, campaign]),
);

export function findSector(slug: string): Sector | null {
  return BY_SLUG.get(slug) ?? null;
}

/** The sectors a campaign actually covers, whether named or derived by ticket. */
function campaignSectors(campaign: DiscoveryCampaign): Sector[] {
  if (campaign.minTicket !== undefined) {
    const floor = campaign.minTicket;
    return SECTORS.filter((sector) => sector.ticket >= floor);
  }
  return campaign.sectors.map((slug) => {
    const member = BY_SLUG.get(slug);
    if (!member) {
      throw new Error(
        `Campanha "${campaign.slug}" referencia setor inexistente: "${slug}".`,
      );
    }
    return member;
  });
}

/** A sector or a curated high-value campaign, ready for an Overture query. */
export function findDiscoveryTarget(slug: string): DiscoveryTarget | null {
  const sector = findSector(slug);
  if (sector) return { ...sector, kind: "sector" };

  const campaign = CAMPAIGN_BY_SLUG.get(slug);
  if (!campaign) return null;

  const members = campaignSectors(campaign);
  return {
    slug: campaign.slug,
    label: campaign.label,
    group: campaign.group,
    note: campaign.note,
    categories: [...new Set(members.flatMap((m) => m.categories))],
    // The campaign is worth what its best member is worth: it is a tiebreak
    // prior, and a campaign that spans tickets 3–5 should not be discounted to
    // the weakest sector it happens to include.
    ticket: (members.reduce<number>((max, m) => Math.max(max, m.ticket), 2) ||
      2) as 1 | 2 | 3 | 4 | 5,
    kind: "campaign",
  };
}

/** What the discovery picker renders, campaigns first and then individual sectors. */
export function discoveryTargets(): DiscoveryTarget[] {
  return [
    ...DISCOVERY_CAMPAIGNS.map((campaign) => {
      const target = findDiscoveryTarget(campaign.slug);
      if (!target) throw new Error(`Campanha inexistente: "${campaign.slug}".`);
      return target;
    }),
    ...SECTORS.map((sector) => ({ ...sector, kind: "sector" as const })),
  ];
}

export function sectorForCategory(category: string | null): string | null {
  return category ? (BY_CATEGORY.get(category) ?? null) : null;
}

export function ticketForSector(slug: string | null): 1 | 2 | 3 | 4 | 5 {
  return slug ? (BY_SLUG.get(slug)?.ticket ?? 3) : 3;
}

/** Every category across every sector — what the sync script extracts. */
export function allSectorCategories(): string[] {
  return [...BY_CATEGORY.keys()].sort();
}

/**
 * Changes to the registry have to invalidate stored sector slugs, the same way
 * `nicheFingerprint()` does on the prospector side — otherwise renaming a sector
 * leaves the history filtering on a slug nothing carries any more.
 */
export function sectorFingerprint(): string {
  return SECTORS.map((s) => `${s.slug}:${s.categories.join("+")}`).join("|");
}
