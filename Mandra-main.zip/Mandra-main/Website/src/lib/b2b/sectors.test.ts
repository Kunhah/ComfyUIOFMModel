import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";
import test from "node:test";
import {
  DISCOVERY_CAMPAIGNS,
  SECTORS,
  allSectorCategories,
  discoveryTargets,
  findDiscoveryTarget,
  sectorForCategory,
  ticketForSector,
} from "./sectors";

/**
 * The registry is 85 sectors and 200-odd hand-typed category strings, and every
 * way it can be wrong is silent: an invented category matches nothing, a
 * category claimed twice splits a sector's history between two slugs, and a
 * campaign naming a renamed sector throws only when somebody picks it. The sync
 * script warns about the first of those *after* you have decided to spend twenty
 * minutes downloading Parquet. These are the same checks, before the commit.
 */

const vocabulary = new Set(
  readFileSync(
    path.join(
      process.cwd(),
      "src",
      "data",
      "prospector",
      "overture-categories.csv",
    ),
    "utf8",
  )
    .split(/\r?\n/)
    .slice(1)
    .map((line) => line.split(",")[0]?.trim())
    .filter((value): value is string => Boolean(value)),
);

test("every category exists in the Overture vocabulary", () => {
  const invented = allSectorCategories().filter((c) => !vocabulary.has(c));
  assert.deepEqual(
    invented,
    [],
    `categorias inexistentes casam com zero empresas e leem como "setor vazio": ${invented.join(", ")}`,
  );
});

test("a category belongs to exactly one sector", () => {
  const seen = new Map<string, string>();
  for (const sector of SECTORS) {
    for (const category of sector.categories) {
      const owner = seen.get(category);
      assert.equal(
        owner,
        undefined,
        `"${category}" está em "${owner}" e em "${sector.slug}"`,
      );
      seen.set(category, sector.slug);
      // The reverse lookup is what stamps a crawled company's sector, so a
      // category the map cannot answer for silently produces sector-less rows.
      assert.equal(sectorForCategory(category), sector.slug);
    }
  }
});

test("slugs are unique across sectors and campaigns", () => {
  const slugs = [
    ...SECTORS.map((s) => s.slug),
    ...DISCOVERY_CAMPAIGNS.map((c) => c.slug),
  ];
  assert.equal(
    new Set(slugs).size,
    slugs.length,
    "um slug duplicado faz findDiscoveryTarget devolver o primeiro e ignorar o outro",
  );
});

test("every sector has at least one category and a ticket in range", () => {
  for (const sector of SECTORS) {
    assert.ok(sector.categories.length > 0, `"${sector.slug}" não busca nada`);
    assert.ok(
      sector.ticket >= 1 && sector.ticket <= 5,
      `"${sector.slug}" tem ticket fora da escala`,
    );
    assert.equal(ticketForSector(sector.slug), sector.ticket);
  }
});

test("a campaign resolves to the categories of real sectors", () => {
  for (const campaign of DISCOVERY_CAMPAIGNS) {
    const target = findDiscoveryTarget(campaign.slug);
    assert.ok(target, `campanha "${campaign.slug}" não resolve`);
    if (campaign.universal) {
      // The universal one is the deliberate exception: no category filter at
      // all, which the discover route gates on the universal extract.
      assert.equal(target.categories.length, 0);
      continue;
    }
    assert.ok(
      target.categories.length > 0,
      `campanha "${campaign.slug}" busca zero categorias`,
    );
    for (const category of target.categories) {
      assert.ok(vocabulary.has(category));
    }
  }
});

test("a ticket-derived campaign follows the sectors, not a copied list", () => {
  const target = findDiscoveryTarget("campanha-ticket-maximo");
  assert.ok(target);
  const expected = new Set(
    SECTORS.filter((s) => s.ticket === 5).flatMap((s) => s.categories),
  );
  assert.deepEqual(new Set(target.categories), expected);
  assert.equal(target.ticket, 5);
});

test("the picker offers campaigns first and every sector after", () => {
  const targets = discoveryTargets();
  const campaigns = targets.filter((t) => t.kind === "campaign");
  assert.equal(campaigns.length, DISCOVERY_CAMPAIGNS.length);
  // Grouped rendering walks the list in order and starts a new group whenever
  // the label changes, so a sector filed out of order silently splits its group
  // into two headings with the same name.
  assert.deepEqual(
    targets.slice(0, campaigns.length).map((t) => t.slug),
    DISCOVERY_CAMPAIGNS.map((c) => c.slug),
  );
  const groups = targets.map((t) => t.group);
  assert.equal(
    new Set(groups).size,
    groups.filter((g, i) => g !== groups[i - 1]).length,
    "um grupo aparece duas vezes na lista — os setores dele não estão juntos",
  );
});
