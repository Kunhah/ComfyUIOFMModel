/**
 * Google Ads conversion reporting.
 *
 * A call is the conversion these pages exist to produce, and Google cannot see
 * it: a `tel:` link leaves the browser without a page view, so unless the tap
 * is reported the campaign optimises towards clicks and never towards
 * customers. That is the difference between the R$1.800 and the R$300 cost per
 * client — the bidding needs the signal.
 *
 * Everything here is inert until the three env vars are set, which is why the
 * pages can ship before the Ads account exists:
 *
 *   NEXT_PUBLIC_GOOGLE_ADS_ID              AW-XXXXXXXXXX
 *   NEXT_PUBLIC_GOOGLE_ADS_CALL_LABEL      the "Ligar" conversion's label
 *   NEXT_PUBLIC_GOOGLE_ADS_WHATSAPP_LABEL  the "WhatsApp" conversion's label
 *
 * They must be referenced as whole `process.env.NEXT_PUBLIC_*` expressions —
 * Next inlines them literally at build time, so a computed lookup resolves to
 * undefined in the browser.
 */

export const GOOGLE_ADS_ID = process.env.NEXT_PUBLIC_GOOGLE_ADS_ID ?? "";
const CALL_LABEL = process.env.NEXT_PUBLIC_GOOGLE_ADS_CALL_LABEL ?? "";
const WHATSAPP_LABEL = process.env.NEXT_PUBLIC_GOOGLE_ADS_WHATSAPP_LABEL ?? "";

export type ConversionKind = "call" | "whatsapp";

type Gtag = (...args: unknown[]) => void;

declare global {
  interface Window {
    gtag?: Gtag;
    dataLayer?: unknown[];
  }
}

/**
 * Report a tap on the phone or WhatsApp action.
 *
 * Deliberately fire-and-forget rather than holding the navigation open behind
 * an `event_callback`: on a phone the dialer takes over immediately and a
 * callback that never runs would either delay the call or do nothing. A
 * dropped beacon costs one unattributed conversion; a delayed dialer costs the
 * customer.
 */
export function reportConversion(kind: ConversionKind) {
  if (typeof window === "undefined" || !window.gtag || !GOOGLE_ADS_ID) return;

  const label = kind === "call" ? CALL_LABEL : WHATSAPP_LABEL;
  if (!label) return;

  window.gtag("event", "conversion", {
    send_to: `${GOOGLE_ADS_ID}/${label}`,
  });
}
