import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { describe, it } from "node:test";
import { buildAudience, isMatchable } from "./audience";
import type { StoredLead } from "./types";

/**
 * The ad-platform files, pinned.
 *
 * Worth testing precisely because nothing here can fail loudly: a wrongly
 * normalised phone or a hashed field that Google wanted in the clear produces a
 * file that uploads without complaint and matches nobody. The only way to find
 * that out in production is a lookalike audience that quietly underperforms for
 * a month, so the rules are asserted against known-good digests here instead.
 */

const sha = (v: string) => createHash("sha256").update(v, "utf8").digest("hex");

function lead(over: Partial<StoredLead> = {}): StoredLead {
  return {
    id: "l1",
    accountId: null,
    name: "Padaria São Jorge",
    category: "bakery",
    address: null,
    city: "Belo Horizonte",
    uf: "MG",
    country: "BR",
    phone: "(31) 98791-1222",
    website: null,
    social: null,
    email: "Contato@Padaria.com.BR",
    lat: null,
    lon: null,
    confidence: 0.9,
    owner: null,
    score: 80,
    reasons: [],
    whatsapp: true,
    status: "cliente",
    niche: "padarias",
    searchedCity: "Belo Horizonte",
    searchedUf: "MG",
    firstSeenAt: "2026-01-01T00:00:00.000Z",
    lastSeenAt: "2026-01-01T00:00:00.000Z",
    nextFollowUpAt: null,
    contactedAt: "2026-01-02T00:00:00.000Z",
    notes: null,
    funnelStage: "fechado",
    socials: [],
    contactName: "Maria da Silva Souza",
    tags: [],
    ...over,
  };
}

describe("meta customer list", () => {
  it("hashes every column, with the phone in full E.164", () => {
    const { headers, rows } = buildAudience([lead()], "meta");
    assert.deepEqual(headers, [
      "email",
      "phone",
      "fn",
      "ln",
      "ct",
      "st",
      "country",
    ]);

    const [email, phone, fn, ln, ct, st, country] = rows[0];
    assert.equal(email, sha("contato@padaria.com.br"));
    // The plus is required here and deliberately absent from the CSV export.
    assert.equal(phone, sha("+5531987911222"));
    // First and last of the *contact*, never of the business.
    assert.equal(fn, sha("maria"));
    assert.equal(ln, sha("souza"));
    // City folded past its accents and spaces: "Belo Horizonte" → "belohorizonte".
    assert.equal(ct, sha("belohorizonte"));
    assert.equal(st, sha("mg"));
    assert.equal(country, sha("br"));
  });

  it("leaves a missing field empty rather than hashing the empty string", () => {
    // A column of e3b0c442… is a column of identical fake identities, and both
    // platforms score the upload down for it.
    const { rows } = buildAudience(
      [lead({ email: null, contactName: null })],
      "meta",
    );
    assert.equal(rows[0][0], "");
    assert.equal(rows[0][2], "");
    assert.equal(rows[0][3], "");
    assert.notEqual(rows[0][1], "");
  });

  it("drops a region that isn't a two-letter code", () => {
    // Outside Brazil the region is normalised free text; a full state name in a
    // column specified as a code matches nothing.
    const { rows } = buildAudience(
      [lead({ country: "PT", uf: "Área Metropolitana de Lisboa" })],
      "meta",
    );
    assert.equal(rows[0][5], "");
  });
});

describe("google customer match", () => {
  it("hashes the identifiers and leaves country in the clear", () => {
    const { headers, rows } = buildAudience([lead()], "google");
    assert.deepEqual(headers, [
      "Email",
      "Phone",
      "First Name",
      "Last Name",
      "Country",
      "Zip",
    ]);
    assert.equal(rows[0][0], sha("contato@padaria.com.br"));
    assert.equal(rows[0][1], sha("+5531987911222"));
    // The asymmetry that is easiest to get wrong: Google rejects a hashed country.
    assert.equal(rows[0][4], "BR");
  });
});

describe("matchability", () => {
  it("drops leads with neither a phone nor an e-mail, and counts them", () => {
    const usable = lead();
    const unusable = lead({ id: "l2", phone: null, email: null });
    const { rows, dropped } = buildAudience([usable, unusable], "meta");
    assert.equal(rows.length, 1);
    assert.equal(dropped, 1);
    assert.equal(isMatchable(unusable), false);
  });

  it("does not accept a phone that isn't a real number", () => {
    // "12345" is a fragment, not a number; normalisePhone rejects it and the
    // lead has nothing else to match on.
    assert.equal(isMatchable(lead({ phone: "12345", email: null })), false);
  });

  it("does not accept a malformed e-mail as an identifier", () => {
    assert.equal(
      isMatchable(lead({ phone: null, email: "sem-arroba-nenhuma" })),
      false,
    );
  });
});

describe("plain csv", () => {
  it("exports the identifiers in the clear for a manual upload", () => {
    const { rows } = buildAudience([lead()], "plano");
    assert.deepEqual(rows[0], [
      "Padaria São Jorge",
      "Maria da Silva Souza",
      "+5531987911222",
      "Contato@Padaria.com.BR",
      "Belo Horizonte",
      "MG",
      "BR",
      "fechado",
      "padarias",
    ]);
  });
});
