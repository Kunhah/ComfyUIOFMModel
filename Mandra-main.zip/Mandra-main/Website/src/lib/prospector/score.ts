import { findCountry } from "@/lib/countries";
import { intentForCategory, type NicheIntent } from "./niches";
import {
  bodyFor,
  render,
  slotOf,
  type OutreachContext,
  type TemplateLanguage,
} from "./templates";
import type { Lead, ScoredLead } from "./types";

/** Rows saved before the tool left Brazil carry no country; they are Brazilian. */
function countryOf(value: string | null | undefined) {
  return findCountry(value ?? "BR") ?? findCountry("BR")!;
}

/**
 * Digits only, in full E.164 form (no plus) for the lead's own country.
 * Returns null when the number can't be read as a line in that country's plan.
 *
 * The country matters more than it looks. "3112345678" is a complete São Paulo
 * landline and an incomplete German mobile, and the same string prefixed with
 * the wrong dial code produces a wa.me link that opens a stranger's chat — so a
 * number that doesn't fit its country's lengths is dropped rather than padded.
 */
export function normalisePhone(
  phone: string | null,
  country?: string | null,
): string | null {
  if (!phone) return null;
  const c = countryOf(country);
  const national = nationalNumber(phone, c.dial);
  if (national === null) return null;
  return `${c.dial}${national}`;
}

/**
 * The number without its country code or trunk prefix — what the numbering
 * plan's own rules are written against.
 *
 * Locally-formatted numbers arrive without the dial code and often with a trunk
 * zero ("(031) 9…", "07911 123456"); international ones arrive with the dial
 * code and never with the zero. Both have to end up as the same string or the
 * mobile patterns in the country table match neither.
 */
function nationalNumber(phone: string, dial: string): string | null {
  let d = phone.replace(/\D/g, "");
  if (d.length === 0) return null;
  // Only strip the dial code when what remains is still a plausible number;
  // "5535..." is a Minas Gerais number, not country 55 followed by nothing.
  if (d.startsWith(dial) && d.length - dial.length >= 6) {
    d = d.slice(dial.length);
  }
  d = d.replace(/^0+/, "");
  // Wide on purpose: national numbers run from 7 digits (Iceland) to 11 (Brazil
  // mobiles, Argentina with its 9). Anything outside that is a fragment or an
  // extension glued on, and guessing at it is how you dial the wrong business.
  if (d.length < 6 || d.length > 12) return null;
  return d;
}

/**
 * True when the number is a mobile in its own country's plan. This remains a
 * qualification signal; it does not decide whether the operator may try a
 * WhatsApp conversation.
 *
 * Countries whose plan doesn't separate mobiles from fixed lines (the US and
 * Canada share the format entirely) carry `mobile: null` in the registry and
 * therefore receive no WhatsApp qualification bonus.
 */
export function isWhatsappCapable(
  phone: string | null,
  country?: string | null,
): boolean {
  const c = countryOf(country);
  if (!c.mobile || !phone) return false;
  const national = nationalNumber(phone, c.dial);
  if (national === null) return false;
  return new RegExp(c.mobile).test(national);
}

export function whatsappUrl(
  phone: string | null,
  message: string,
  country?: string | null,
): string | null {
  const d = normalisePhone(phone, country);
  if (!d) return null;
  return `https://wa.me/${d}?text=${encodeURIComponent(message)}`;
}

/**
 * The opener for one lead, in the language the business is likely to answer in.
 *
 * Three templates rather than one per country: the registry's `speaks` field
 * says which, and a German machine shop reading an English opener is a normal
 * cold e-mail while one reading Portuguese is spam. Countries we have no
 * template for fall back to English, never to Portuguese.
 *
 * `context` carries the bodies in force *for the person sending it* and that
 * person's name, read from SQLite by the server that renders the link — see
 * `outreachContextFor()` in templates-store.ts. It is a parameter rather than a
 * lookup because this module is imported by client components, and it is
 * optional because the built-in openers are a complete answer on their own: a
 * deployment where nobody ever opened the editor sends exactly what ships.
 */
export function outreachMessage(
  lead: OutreachLead,
  intent: NicheIntent = intentForCategory(lead.category),
  context?: OutreachContext,
): string {
  const speaks: TemplateLanguage = countryOf(lead.country).speaks;
  return render(
    bodyFor(slotOf(intent, speaks), context?.templates),
    { ...lead, senderName: context?.senderName },
    speaks,
  );
}

/**
 * A lead as the opener needs it.
 *
 * `contactName` only exists on a `StoredLead`, and most callers hand in a
 * search result that has never been near the CRM. Declaring it optional here is
 * what lets `[nome]` be filled for the leads somebody has actually worked and
 * quietly close up for the rest, without every caller learning the difference.
 */
export type OutreachLead = Lead & { contactName?: string | null };

/**
 * 0–100 qualification score, highest = best prospect for a web agency.
 *
 * The weighting is opinionated on purpose: "no website" is the thing Mandra
 * actually sells against, so it dominates. Everything else is either evidence
 * the business is real and active (confidence, address) or evidence we can
 * actually start a conversation today (phone, WhatsApp). A business with a
 * website can still be a redesign lead, so it scores low rather than zero.
 */
export function scoreLead(
  lead: Lead,
  intent: NicheIntent = intentForCategory(lead.category),
): ScoredLead {
  if (intent === "parceiro") return scorePartner(lead);

  const reasons: string[] = [];
  let score = 0;

  const hasWebsite = Boolean(lead.website);
  const hasSocial = Boolean(lead.social);
  const whatsapp = isWhatsappCapable(lead.phone, lead.country);

  if (!hasWebsite) {
    score += 45;
    reasons.push("sem site");
  } else {
    score += 5;
    reasons.push("já tem site");
  }

  // Presence on social with no site is the strongest warm signal there is: the
  // owner already believes in being findable, they just never got a site built.
  if (!hasWebsite && hasSocial) {
    score += 15;
    reasons.push("só redes sociais");
  }

  if (lead.phone) {
    score += 15;
    if (whatsapp) {
      score += 10;
      reasons.push("WhatsApp");
    } else {
      reasons.push("telefone fixo");
    }
  } else {
    reasons.push("sem telefone");
  }

  // An inbox is a direct, asynchronous contact path — particularly useful for
  // businesses with a landline or no WhatsApp-capable mobile.
  if (lead.email) {
    score += 10;
    reasons.push("e-mail disponível");
  }

  if (lead.confidence >= 0.8) {
    score += 10;
    reasons.push("cadastro confiável");
  } else if (lead.confidence >= 0.6) {
    score += 6;
  } else if (lead.confidence >= 0.4) {
    score += 2;
  } else {
    reasons.push("cadastro duvidoso");
  }

  if (lead.address) score += 5;

  return { ...lead, score: Math.min(100, score), reasons, whatsapp };
}

/**
 * Whether this lead's source has a website field at all.
 *
 * Only the Receita's register does not. Everything else here is a business
 * directory, where a blank `website` is a statement about the business; there
 * it is a statement about the schema.
 */
const KNOWS_WEBSITE = (lead: Lead): boolean => lead.source !== "cnpj";

/**
 * The same 0–100 scale read the other way round, for a partner.
 *
 * Every weight here is the mirror of the one above, and it is not a stylistic
 * choice: "sem site" is the top signal for a client and close to a
 * disqualification for a partner. A marketing agency with no website, no
 * Instagram and a landline is either dormant or one person moonlighting, and
 * either way it is not somebody to hand a client to. What the ranking wants at
 * the top is a firm that is visibly operating — a site and a social presence —
 * and reachable today.
 *
 * The reasons are worded so a row explains itself in the same table as a client
 * row does. "já tem site" is a shrug on a client and the point on a partner, so
 * it gets its own phrasing rather than being reused.
 */
function scorePartner(lead: Lead): ScoredLead {
  const reasons: string[] = [];
  let score = 0;

  const whatsapp = isWhatsappCapable(lead.phone, lead.country);

  if (KNOWS_WEBSITE(lead)) {
    if (lead.website) {
      score += 25;
      reasons.push("site próprio");
    } else {
      reasons.push("sem site próprio");
    }

    // For a client this is "só redes sociais", a gap. For a marketing
    // professional it is the shop window — an agency that doesn't run its own
    // social is advertising the fact.
    if (lead.social) {
      score += 20;
      reasons.push("presença em redes");
    }
  } else {
    // A legal register carries no website and no social column, so a blank one
    // here means "never asked" and must not be read as "hasn't got one" — the
    // distinction this codebase already makes for `isNew`. Scoring it as an
    // absence would put every registered gestor de tráfego below every mapped
    // agency for a fact about the Receita's schema.
    //
    // What it does say instead is worth about as much: an active CNPJ under an
    // advertising CNAE is a firm someone maintains a registration for, which is
    // the same "this is really operating" evidence a website is. It is worth
    // less than the pair it replaces, and deliberately so — an agency with a
    // site, an Instagram and a mobile is better qualified than one we know only
    // from a register.
    score += 30;
    reasons.push("registro ativo");
  }

  if (lead.phone) {
    score += 15;
    if (whatsapp) {
      score += 10;
      reasons.push("WhatsApp");
    } else {
      reasons.push("telefone fixo");
    }
  } else {
    reasons.push("sem telefone");
  }

  // Weighted above the client's 10: a partnership is opened by proposal far
  // more often than by cold call, and an agency's inbox is answered.
  if (lead.email) {
    score += 15;
    reasons.push("e-mail disponível");
  }

  if (lead.confidence >= 0.8) {
    score += 10;
    reasons.push("cadastro confiável");
  } else if (lead.confidence >= 0.6) {
    score += 6;
  } else if (lead.confidence >= 0.4) {
    score += 2;
  } else {
    reasons.push("cadastro duvidoso");
  }

  if (lead.address) score += 5;

  return { ...lead, score: Math.min(100, score), reasons, whatsapp };
}

export function scoreAndSort(
  leads: Lead[],
  intent?: NicheIntent,
): ScoredLead[] {
  // No intent means "ask each lead's own category", which is what every caller
  // outside a search has to do — the CRM and the history hold both kinds.
  return leads
    .map((lead) => scoreLead(lead, intent))
    .sort(
      (a, b) =>
        b.score - a.score ||
        // Scores bunch hard at the ceiling — any no-site business with a mobile
        // and a good record scores 100 — so the tiebreak carries real weight.
        // Confidence surfaces the most trustworthy of those; sorting by name
        // would just front-load the alphabet.
        b.confidence - a.confidence ||
        a.name.localeCompare(b.name, "pt-BR"),
    );
}
