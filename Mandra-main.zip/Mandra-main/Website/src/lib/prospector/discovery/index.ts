/**
 * Discovery helpers ported from the Mandra Sniper fork.
 *
 * Pure functions only — no providers, no persistence, no network. The fork's
 * orchestrator wired these to Google Places and an in-memory store; both were
 * left behind (see the port notes in the commit that added this directory).
 */
export { diceSimilarity } from "./similarity";
export { generateGeoGrid, type BoundingBox, type GridCell } from "./geo-grid";
export {
  dedupeLeads,
  type DedupeResult,
  type DuplicateHit,
  type DuplicateReason,
} from "./dedup";
export {
  validateCity,
  parseAddressComponents,
  type AddressParts,
  type CityMatch,
  type CityValidation,
} from "./city-validation";
export {
  validateNiche,
  type NicheTier,
  type NicheValidation,
} from "./niche-validation";
