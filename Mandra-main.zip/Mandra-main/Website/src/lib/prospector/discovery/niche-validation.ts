import { normalise } from "../cities";
import type { Niche } from "../niches";
import type { Lead } from "../types";

export type NicheTier =
  /** The record carries a category this niche owns. Not a guess. */
  | "exact"
  /** The business name says what it is, and it agrees with the niche. */
  | "strong"
  /** Nothing contradicts the niche, nothing confirms it. */
  | "possible";

export type NicheValidation = {
  tier: NicheTier;
  /** 0–100, for ranking within a tier. */
  score: number;
  /** pt-BR, for the warnings list and the row tooltip. */
  signals: string[];
};

/**
 * How well a candidate matches the niche that was searched.
 *
 * Overture rows don't need this — `queryOverture` filters on
 * `categories.primary`, so they match the niche by construction. The
 * supplementary sources do: OpenStreetMap and Geoapify are queried by free
 * text, so a search for "barbearias" returns beauty salons, tattoo studios and
 * the occasional hardware shop.
 *
 * This deliberately never reports "reject". The fork's version had a REJECT
 * tier that nothing could reach — its floor was 50 and its baseline was 50 —
 * so the tier was dead code pretending to be a filter. Rather than resurrect a
 * silent dropper, this grades and lets the caller decide; the cost of hiding a
 * real lead is higher than the cost of showing a doubtful one.
 */
export function validateNiche(
  lead: Lead,
  niche: Niche,
  /** Extra pt-BR synonyms the label doesn't cover, e.g. "odontologia". */
  aliases: string[] = [],
): NicheValidation {
  const signals: string[] = [];

  if (lead.category && niche.categories.includes(lead.category)) {
    return {
      tier: "exact",
      score: 100,
      signals: [`Categoria '${lead.category}' pertence a ${niche.label}`],
    };
  }

  const name = normalise(lead.name);
  const terms = new Set<string>();
  for (const term of [niche.label, ...aliases]) {
    for (const token of normalise(term).split(" ")) {
      if (token.length >= 4 && !STOPWORDS.has(token)) terms.add(token);
    }
  }

  let score = 50;
  for (const term of terms) {
    if (!hasWord(name, term)) continue;
    signals.push(`Nome contém '${term}'`);
    score += 30;
    break;
  }

  // A category from a different niche is a hint, not a verdict: the source's
  // taxonomy may simply be coarser than ours.
  if (lead.category && !niche.categories.includes(lead.category)) {
    signals.push(`Categoria de origem: '${lead.category}'`);
    score -= 10;
  }

  score = Math.min(100, Math.max(0, score));
  return {
    tier: score >= 70 ? "strong" : "possible",
    score,
    signals: signals.length > 0 ? signals : ["Sem sinais no nome ou categoria"],
  };
}

/**
 * Whole-word containment against a `normalise`d string.
 *
 * Substring matching was the fork's approach and it over-matches badly in
 * pt-BR: "bar" hits "Barbearia", "Barraca" and "Bartolomeu", so a search for
 * bars qualified every barbershop in the city.
 */
function hasWord(haystack: string, word: string): boolean {
  return ` ${haystack} `.includes(` ${word} `);
}

/** pt-BR filler that carries no niche signal. */
const STOPWORDS = new Set(["de", "da", "do", "das", "dos", "e", "em", "para"]);
