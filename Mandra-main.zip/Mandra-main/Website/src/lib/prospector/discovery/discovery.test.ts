import test from "node:test";
import assert from "node:assert/strict";

import { diceSimilarity } from "@/lib/prospector/discovery/similarity";
import { dedupeLeads } from "@/lib/prospector/discovery/dedup";
import {
  validateCity,
  parseAddressComponents,
} from "@/lib/prospector/discovery/city-validation";
import { validateNiche } from "@/lib/prospector/discovery/niche-validation";
import { generateGeoGrid } from "@/lib/prospector/discovery/geo-grid";
import type { Lead } from "@/lib/prospector/types";
import type { City } from "@/lib/prospector/cities";
import type { Niche } from "@/lib/prospector/niches";

/** The fork's similarity function, kept here only to demonstrate the defect. */
function forkSimilarity(a: string, b: string): number {
  if (a === b) return 1.0;
  if (!a || !b) return 0;
  const setA = new Set(a.split(""));
  const setB = new Set(b.split(""));
  const inter = new Set([...setA].filter((x) => setB.has(x)));
  return (2 * inter.size) / (setA.size + setB.size);
}

const lead = (over: Partial<Lead>): Lead => ({
  id: "x", name: "N", category: null, address: null, city: "Jundiai",
  uf: "SP", phone: null, website: null, social: null, email: null,
  lat: null, lon: null, confidence: 0.8, ...over,
});

const JUNDIAI: City = {
  name: "Jundiaí", uf: "SP", country: "BR",
  bbox: { xmin: -47.12, xmax: -46.79, ymin: -23.29, ymax: -23.11 },
  businesses: 12000, noSite: 7000,
};

// ---------------------------------------------------------------- similarity

test("dice similarity separates anagrams the fork's set measure could not", () => {
  const a = "salao mari", b = "salao rima";
  assert.equal(forkSimilarity(a, b), 1.0);          // the bug
  assert.ok(diceSimilarity(a, b) < 0.88);           // the fix
});

test("dice similarity still matches real spelling variants", () => {
  // Spacing variants across directories are the common real case.
  assert.ok(diceSimilarity("clinica odonto vida", "clinica odontovida") > 0.88);
  // Same naming template, different business: must stay well clear.
  assert.ok(diceSimilarity("padaria sol", "padaria lua") < 0.88);
  assert.equal(diceSimilarity("padaria sol", "padaria sol"), 1);
  assert.equal(diceSimilarity("a", "b"), 0);
});

test("a trailing legal form does not split one business in two", () => {
  const r = dedupeLeads([
    lead({ id: "a", name: "Barbearia do João", address: "Rua C, 1" }),
    lead({ id: "b", name: "Barbearia do Joao LTDA ME", address: "Rua C, 1" }),
  ]);
  assert.equal(r.leads.length, 1);
  assert.equal(r.hits[0].reason, "name-address");
});

test("branch markers are not stripped, so two units stay separate", () => {
  const r = dedupeLeads([
    lead({ id: "a", name: "Padaria Sol Unidade Centro", address: "Rua D, 2" }),
    lead({ id: "b", name: "Padaria Sol Unidade Jardim", address: "Rua D, 2" }),
  ]);
  assert.equal(r.leads.length, 2);
});

// --------------------------------------------------------------------- dedup

test("collapses one business that two sources spell differently", () => {
  const r = dedupeLeads([
    lead({ id: "ov-1", name: "Barbearia do João", phone: "+551199990000",
           source: "overture", address: "Rua A, 10" }),
    lead({ id: "osm-9", name: "Barbearia do Joao LTDA", phone: "+55 11 9999-0000",
           source: "openstreetmap", email: "j@x.com" }),
  ]);
  assert.equal(r.leads.length, 1);
  assert.equal(r.hits[0].reason, "phone");
  assert.equal(r.leads[0].id, "ov-1");        // Overture identity survives
  assert.equal(r.leads[0].email, "j@x.com");  // OSM's contact is absorbed
});

test("keeps branches of a chain that share a central phone line", () => {
  const r = dedupeLeads([
    lead({ id: "a", name: "Rede Sabor", phone: "+551140040000", city: "Jundiai" }),
    lead({ id: "b", name: "Rede Sabor", phone: "+551140040000", city: "Campinas" }),
  ]);
  assert.equal(r.leads.length, 2);
});

// Every pair below is real, taken from 862 leads in the tool's own history.
// The fork's phone-only rule merged all four; none of them is one business.
test("a shared salon line does not merge two professionals", () => {
  const r = dedupeLeads([
    lead({ id: "a", name: "Rose Cabeleireira", phone: "551140191381", address: "Rua Mairinque, 4" }),
    lead({ id: "b", name: "Fran Manicure", phone: "551140191381", address: "Rua Mairinque, 4" }),
  ]);
  assert.equal(r.leads.length, 2);
});

test("neighbouring shops on one line stay separate", () => {
  const r = dedupeLeads([
    lead({ id: "a", name: "Barbearia Yvonicov", phone: "5511972950408", address: "Av. Samuel Martins, 1400" }),
    lead({ id: "b", name: "Roberto Alexandrino", phone: "5511972950408", address: "Avenida Samuel Martins, 1395" }),
  ]);
  assert.equal(r.leads.length, 2);
});

test("one owner's two venues stay separate", () => {
  const r = dedupeLeads([
    lead({ id: "a", name: "Vila dos Cactos Eventos", phone: "5511940345515" }),
    lead({ id: "b", name: "Rancho dos Cactos Restaurante", phone: "5511940345515" }),
  ]);
  assert.equal(r.leads.length, 2);
});

test("does not treat a shared instagram profile as one business", () => {
  const r = dedupeLeads([
    lead({ id: "a", name: "Estetica Ana", website: "https://instagram.com/ana" }),
    lead({ id: "b", name: "Estetica Bia", website: "https://instagram.com/bia" }),
  ]);
  assert.equal(r.leads.length, 2);
});

test("collapses on a genuine shared domain", () => {
  const r = dedupeLeads([
    lead({ id: "a", name: "Padaria Sol", website: "https://padariasol.com.br" }),
    lead({ id: "b", name: "Padaria Sol Matriz", website: "http://www.padariasol.com.br/" }),
  ]);
  assert.equal(r.leads.length, 1);
  assert.equal(r.hits[0].reason, "domain");
});

test("anagram names at one address stay separate (regression on the fork)", () => {
  const r = dedupeLeads([
    lead({ id: "a", name: "Salao Mari", address: "Rua B, 5" }),
    lead({ id: "b", name: "Salao Rima", address: "Rua B, 5" }),
  ]);
  assert.equal(r.leads.length, 2);
});

test("dedupe does not mutate the caller's leads", () => {
  const original = lead({ id: "a", name: "X", phone: "+551199990000" });
  const dup = lead({ id: "b", name: "X", phone: "+551199990000", email: "e@e.com" });
  dedupeLeads([original, dup]);
  assert.equal(original.email, null);
});

// ----------------------------------------------------------- city validation

test("parses the city out of a Google-shaped Brazilian address", () => {
  const p = parseAddressComponents(
    "Av. Jundiaí, 1000 - Anhangabaú, Jundiaí - SP, 13208-051, Brasil",
  );
  assert.equal(p.city, "Jundiaí");   // the fork returned "1000"
  assert.equal(p.uf, "SP");
  assert.equal(p.neighborhood, "Anhangabaú");
});

test("keeps hyphenated municipality names intact", () => {
  const p = parseAddressComponents("Rua X, 12 - Centro, São João del-Rei - MG");
  assert.equal(p.city, "São João del-Rei");
  assert.equal(p.uf, "MG");
});

test("coordinates inside the index bbox confirm the city", () => {
  const v = validateCity(lead({ lat: -23.19, lon: -46.9 }), JUNDIAI);
  assert.equal(v.match, "exact");
  assert.equal(v.confidence, "high");
});

test("a São Paulo record is rejected from a Jundiaí search", () => {
  const v = validateCity(
    lead({ lat: -23.55, lon: -46.63, city: "São Paulo" }), JUNDIAI,
  );
  assert.equal(v.match, "outside");
});

test("same city name in the wrong state is rejected", () => {
  const v = validateCity(lead({ city: "Jundiaí", uf: "RN" }), JUNDIAI);
  assert.equal(v.match, "outside");
});

test("an address with no city is flagged, not dropped", () => {
  assert.equal(validateCity(lead({ city: null }), JUNDIAI).match, "unverified");
});

// ---------------------------------------------------------- niche validation

const BARBEARIAS: Niche = {
  slug: "barbearias", label: "Barbearias", group: "Beleza", categories: ["barber"],
};
const BARES: Niche = {
  slug: "bares", label: "Bares", group: "Alimentação", categories: ["bar"],
};

test("an Overture category owned by the niche is an exact match", () => {
  const v = validateNiche(lead({ name: "Qualquer", category: "barber" }), BARBEARIAS);
  assert.equal(v.tier, "exact");
  assert.equal(v.score, 100);
});

test("'Bares' no longer qualifies every barbershop in town", () => {
  // The fork's substring test matched "bar" inside "barbearia".
  const v = validateNiche(lead({ name: "Barbearia do Joao" }), BARES);
  assert.notEqual(v.tier, "strong");
});

test("the niche label found as a whole word in the name is a strong match", () => {
  const v = validateNiche(lead({ name: "Barbearias Central" }), BARBEARIAS);
  assert.equal(v.tier, "strong");
});

// ------------------------------------------------------------------ geo grid

test("a 3x3 grid tiles the bbox without gaps", () => {
  const cells = generateGeoGrid(JUNDIAI.bbox, 3);
  assert.equal(cells.length, 9);
  assert.ok(Math.abs(Math.min(...cells.map((c) => c.bbox.xmin)) - JUNDIAI.bbox.xmin) < 1e-9);
  assert.ok(Math.abs(Math.max(...cells.map((c) => c.bbox.ymax)) - JUNDIAI.bbox.ymax) < 1e-9);
  for (const c of cells) {
    assert.ok(c.center.lat > c.bbox.ymin && c.center.lat < c.bbox.ymax);
  }
});

test("cell radius follows the real size of the city, not a constant", () => {
  const big = generateGeoGrid(
    { xmin: -46.83, xmax: -46.36, ymin: -24.0, ymax: -23.35 }, 3,
  )[0].radiusKm;
  const small = generateGeoGrid(
    { xmin: -46.9, xmax: -46.85, ymin: -23.2, ymax: -23.15 }, 3,
  )[0].radiusKm;
  assert.ok(big > small * 5);
});
