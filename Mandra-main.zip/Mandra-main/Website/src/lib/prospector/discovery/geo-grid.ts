import type { City } from "../cities";

export type BoundingBox = City["bbox"];

export type GridCell = {
  /** Stable within one grid, e.g. "3x3-r1c2". Useful as a log/label key. */
  id: string;
  index: number;
  bbox: BoundingBox;
  center: { lat: number; lon: number };
  /**
   * Half the cell's diagonal, in km — the smallest radius that still covers the
   * cell's corners. Sized for providers whose API takes a centre plus a radius
   * (Places, Overpass `around`) rather than a box.
   */
  radiusKm: number;
};

/** Mean km per degree of latitude. Longitude shrinks by cos(lat). */
const KM_PER_DEGREE = 111.32;

/**
 * Split a city's bounding box into a gridSize × gridSize mesh.
 *
 * Why this exists: every provider caps a single response (Places returns 20 per
 * page, Overpass times out on large areas). One query against a whole
 * municipality therefore returns the same first page no matter how many
 * businesses are really there — the cap reads as exhaustion. Querying each cell
 * separately raises the ceiling to cells × cap and, because each cell is its own
 * ranking context, surfaces businesses that lost the city-wide ranking.
 *
 * The local Overture extract needs none of this — it is a full scan with real
 * aggregates — so this is for the supplementary live sources only.
 */
export function generateGeoGrid(bbox: BoundingBox, gridSize = 3): GridCell[] {
  const size = Math.max(1, Math.trunc(gridSize));

  const lonStep = (bbox.xmax - bbox.xmin) / size;
  const latStep = (bbox.ymax - bbox.ymin) / size;

  const cells: GridCell[] = [];
  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size; col++) {
      const xmin = bbox.xmin + col * lonStep;
      const ymin = bbox.ymin + row * latStep;
      const cell: BoundingBox = {
        xmin,
        xmax: xmin + lonStep,
        ymin,
        ymax: ymin + latStep,
      };
      const center = {
        lat: (cell.ymin + cell.ymax) / 2,
        lon: (cell.xmin + cell.xmax) / 2,
      };

      // Derived from the cell's own size rather than a constant. The fork used
      // `max(3, round(15 / gridSize))`, which hands the same 5km radius to a
      // cell of São Paulo and a cell of a 4.000-person town — over-fetching
      // neighbours in one and missing the corners of the other.
      const heightKm = (cell.ymax - cell.ymin) * KM_PER_DEGREE;
      const widthKm =
        (cell.xmax - cell.xmin) *
        KM_PER_DEGREE *
        Math.cos((center.lat * Math.PI) / 180);

      cells.push({
        id: `${size}x${size}-r${row + 1}c${col + 1}`,
        index: cells.length,
        bbox: cell,
        center,
        radiusKm: Math.hypot(widthKm, heightKm) / 2,
      });
    }
  }

  return cells;
}
