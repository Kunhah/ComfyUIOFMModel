import { normalise, type City } from "../cities";
import type { Lead } from "../types";

export type CityMatch =
  /** Confirmed inside the municipality that was searched. */
  | "exact"
  /** Confirmed to be somewhere else. Safe to drop. */
  | "outside"
  /** Nothing in the record says either way. Keep, but flag. */
  | "unverified";

export type CityValidation = {
  match: CityMatch;
  confidence: "high" | "medium" | "low";
  /** What the record itself claims, when it claims anything. */
  detectedCity: string | null;
  detectedUf: string | null;
  /** pt-BR, for the warnings list. */
  detail: string;
};

export type AddressParts = {
  city: string | null;
  uf: string | null;
  neighborhood: string | null;
};

/** How far outside the index's bbox still counts as "possibly this city". */
const EDGE_TOLERANCE_DEGREES = 0.01; // ~1.1 km

/**
 * Pull city, UF and neighbourhood out of a one-line Brazilian address.
 *
 * The shape is stable enough to parse: the city and state always arrive as
 * "<city> - <UF>" in their own comma-separated field.
 *
 *     Av. Jundiaí, 1000 - Anhangabaú, Jundiaí - SP, 13208-051, Brasil
 *                                     ^^^^^^^^^^^^
 *
 * The fork split the whole string on `/[-–,]+/` at once, which destroys that
 * structure — "Sao Joao del-Rei" becomes two fields — and then took whichever
 * field happened to sit at index 1 as the city, so the example above resolved
 * to "1000". Splitting on commas first and looking for the UF keeps the pairing
 * intact.
 */
export function parseAddressComponents(
  address: string | null | undefined,
): AddressParts {
  const empty: AddressParts = { city: null, uf: null, neighborhood: null };
  if (!address || address.trim().length === 0) return empty;

  const fields = address
    .split(",")
    .map((f) => f.trim())
    .filter(Boolean);

  for (let i = fields.length - 1; i >= 0; i--) {
    // "Jundiaí - SP", tolerating the en dash sources sometimes emit.
    const paired = /^(.+?)\s*[-–]\s*([A-Za-z]{2})$/.exec(fields[i]);
    if (paired && isUf(paired[2])) {
      return {
        city: paired[1].trim(),
        uf: paired[2].toUpperCase(),
        // The neighbourhood rides on the tail of the previous field:
        // "1000 - Anhangabaú".
        neighborhood: tailAfterDash(fields[i - 1]),
      };
    }

    // A field that is nothing but the state code: the city is the field before.
    if (isUf(fields[i]) && i > 0) {
      return {
        city: fields[i - 1].trim() || null,
        uf: fields[i].toUpperCase(),
        neighborhood: tailAfterDash(fields[i - 2]),
      };
    }
  }

  return empty;
}

/**
 * Decide whether a lead really sits in the city that was searched.
 *
 * Only worth running on the supplementary live sources. Overture rows are
 * already constrained by the bbox predicate and the city-name filter in
 * `overture.ts`, whereas OpenStreetMap and Geoapify are queried by name and
 * happily answer with the wrong municipality — which is how a São Paulo studio
 * ends up in a Jundiaí campaign.
 */
export function validateCity(lead: Lead, target: City): CityValidation {
  const declared = lead.city ?? parseAddressComponents(lead.address).city;
  const declaredUf =
    lead.uf ?? parseAddressComponents(lead.address).uf ?? null;
  const targetName = normalise(target.name);

  // Coordinates first: they are the only claim a directory can't get wrong by
  // spelling. The index's bbox is the tight hull of the businesses that give
  // this city as their address, so falling outside it is real evidence.
  if (lead.lat !== null && lead.lon !== null) {
    const inside =
      lead.lat >= target.bbox.ymin &&
      lead.lat <= target.bbox.ymax &&
      lead.lon >= target.bbox.xmin &&
      lead.lon <= target.bbox.xmax;

    if (inside) {
      return {
        match: "exact",
        confidence: "high",
        detectedCity: declared ?? target.name,
        detectedUf: declaredUf ?? target.uf,
        detail: `Coordenadas dentro de ${target.name}/${target.uf}`,
      };
    }

    const nearEdge =
      lead.lat >= target.bbox.ymin - EDGE_TOLERANCE_DEGREES &&
      lead.lat <= target.bbox.ymax + EDGE_TOLERANCE_DEGREES &&
      lead.lon >= target.bbox.xmin - EDGE_TOLERANCE_DEGREES &&
      lead.lon <= target.bbox.xmax + EDGE_TOLERANCE_DEGREES;

    if (!nearEdge) {
      return {
        match: "outside",
        confidence: "high",
        detectedCity: declared,
        detectedUf: declaredUf,
        detail: `Coordenadas fora de ${target.name}/${target.uf}`,
      };
    }
    // Just past the edge: fall through and let the name decide.
  }

  if (!declared) {
    return {
      match: "unverified",
      confidence: "low",
      detectedCity: null,
      detectedUf: declaredUf,
      detail: "Endereço sem cidade identificável",
    };
  }

  // A wrong state settles it even when the city name coincides — there is a
  // Jundiaí in SP and a Jundiá in RN.
  if (declaredUf && declaredUf.toUpperCase() !== target.uf) {
    return {
      match: "outside",
      confidence: "high",
      detectedCity: declared,
      detectedUf: declaredUf.toUpperCase(),
      detail: `Registro em ${declared}/${declaredUf.toUpperCase()}`,
    };
  }

  if (normalise(declared) === targetName) {
    return {
      match: "exact",
      confidence: "medium",
      detectedCity: declared,
      detectedUf: declaredUf ?? target.uf,
      detail: `Cidade declarada confere com ${target.name}`,
    };
  }

  return {
    match: "outside",
    confidence: "medium",
    detectedCity: declared,
    detectedUf: declaredUf,
    detail: `Registro em ${declared}, não em ${target.name}`,
  };
}

function tailAfterDash(field: string | undefined): string | null {
  if (!field) return null;
  const m = /[-–]\s*(.+)$/.exec(field);
  return m ? m[1].trim() : null;
}

const UFS = new Set([
  "AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MG", "MS",
  "MT", "PA", "PB", "PE", "PI", "PR", "RJ", "RN", "RO", "RR", "RS", "SC",
  "SE", "SP", "TO",
]);

function isUf(value: string): boolean {
  return UFS.has(value.trim().toUpperCase());
}
