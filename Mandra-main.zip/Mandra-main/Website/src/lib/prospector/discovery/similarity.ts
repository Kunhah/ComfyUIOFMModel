/**
 * Bigram Dice coefficient, 0–1, for comparing business names.
 *
 * Ported from the Mandra Sniper fork with its similarity measure replaced. The
 * original compared *sets of characters*:
 *
 *     const setA = new Set(a.split("")); …
 *     (2 * intersection.size) / (setA.size + setB.size)
 *
 * which scores any anagram as a perfect 1.0 and ignores repeats entirely, so
 * "salao mari" and "salao rima" came back identical. Paired with the fork's
 * 0.88 duplicate threshold that silently collapsed distinct businesses whose
 * names happen to share an alphabet — which in pt-BR, where names are built
 * from the same short stock of words ("salao", "barbearia", "clinica"), is not
 * a rare accident.
 *
 * Bigrams fix it because they carry order: "mari" and "rima" share no adjacent
 * pair. Counting is multiset-aware (each bigram in `a` is consumed at most
 * once) so repeated syllables can't inflate the score past 1.
 */
export function diceSimilarity(a: string, b: string): number {
  if (!a || !b) return 0;
  if (a === b) return 1;
  // Single characters have no bigrams; without this they'd divide by zero.
  if (a.length < 2 || b.length < 2) return 0;

  const pool = new Map<string, number>();
  for (let i = 0; i < a.length - 1; i++) {
    const gram = a.slice(i, i + 2);
    pool.set(gram, (pool.get(gram) ?? 0) + 1);
  }

  let hits = 0;
  for (let i = 0; i < b.length - 1; i++) {
    const gram = b.slice(i, i + 2);
    const left = pool.get(gram) ?? 0;
    if (left > 0) {
      pool.set(gram, left - 1);
      hits++;
    }
  }

  return (2 * hits) / (a.length - 1 + (b.length - 1));
}
