import { normalise } from "../cities";
import type { Lead, SocialLink } from "../types";
import { diceSimilarity } from "./similarity";

export type DuplicateReason =
  | "id"
  | "phone"
  | "domain"
  | "name-address"
  | "name-proximity";

export type DuplicateHit = {
  dropped: string;
  keptAs: string;
  reason: DuplicateReason;
  /** pt-BR, ready to show in the search warnings. */
  detail: string;
};

export type DedupeResult = {
  leads: Lead[];
  removed: number;
  hits: DuplicateHit[];
};

/**
 * Cross-source duplicate collapse.
 *
 * `search.ts` already reconciles each supplementary source against the Overture
 * result via `mergeSupplementary`, but that match requires the normalised names
 * to be *exactly* equal before it will look at phone, address or coordinates.
 * Directories disagree on names constantly — "Barbearia do Joao",
 * "Barbearia do João LTDA", "Barbearia do Joao - Unidade Centro" — so a business
 * carrying an identical phone number in two sources still came back twice.
 *
 * This pass keys on the identifying facts first and treats the name as the weak
 * signal it is.
 *
 * Deliberately *not* collapsed: two branches of one business. They share a name
 * and often a landline, so name alone, and phone alone across different cities,
 * are both refused as evidence.
 */
export function dedupeLeads(candidates: Lead[]): DedupeResult {
  const kept: Lead[] = [];
  const hits: DuplicateHit[] = [];

  for (const candidate of candidates) {
    let absorbed = false;
    for (const existing of kept) {
      const match = matchOf(existing, candidate);
      if (!match) continue;
      hits.push({
        dropped: candidate.name,
        keptAs: existing.name,
        reason: match.kind,
        detail: match.detail,
      });
      absorb(existing, candidate);
      absorbed = true;
      break;
    }
    // Copied, not referenced: `absorb` mutates the survivor, and the caller's
    // array (the live search result) must not change under it.
    if (!absorbed) kept.push({ ...candidate });
  }

  return { leads: kept, removed: candidates.length - kept.length, hits };
}

type Match = { kind: DuplicateReason; detail: string };

function matchOf(a: Lead, b: Lead): Match | undefined {
  if (a.id === b.id) {
    return { kind: "id", detail: `Mesmo identificador de origem (${a.id})` };
  }

  const sameCity = normalise(a.city ?? "") === normalise(b.city ?? "");
  if (!sameCity) return undefined;

  const similarity = diceSimilarity(canonicalName(a.name), canonicalName(b.name));

  // A shared phone corroborates, but it cannot carry a merge on its own — which
  // is what the fork's rule did. Checked against 862 real leads from the tool's
  // own history, phone-alone produced four merges and every one was wrong:
  //
  //   Rose Cabeleireira    ⇢ Fran Manicure         same salon, two professionals
  //   Barbearia Yvonicov   ⇢ Roberto Alexandrino   neighbours, nos. 1400 / 1395
  //   Vila dos Cactos      ⇢ Rancho dos Cactos     one owner, two venues
  //   Restaurante UAI      ⇢ Restaurante Uai       two addresses, one line
  //
  // Sharing a landline is normal here: rented chairs, family businesses and
  // multi-venue owners all do it. So the phone only *lowers* the name bar from
  // 0.88 to 0.70 — the highest of those four pairs scored 0.64.
  const phoneA = digits(a.phone);
  const phoneB = digits(b.phone);
  if (phoneA.length >= 10 && phoneA === phoneB && similarity >= 0.7) {
    return {
      kind: "phone",
      detail: `Telefone idêntico (${phoneA}) e nome ${pct(similarity)} similar`,
    };
  }

  // Two records pointing at one site are one business. Social and link-in-bio
  // hosts are excluded — thousands of businesses share instagram.com — and the
  // same-city guard above keeps two branches off one corporate domain.
  const domainA = domainOf(a.website);
  const domainB = domainOf(b.website);
  if (domainA && domainA === domainB && !isSharedHost(domainA)) {
    return { kind: "domain", detail: `Mesmo domínio (${domainA})` };
  }

  if (similarity < 0.88) return undefined;

  const addressA = normalise(a.address ?? "");
  const addressB = normalise(b.address ?? "");
  if (addressA && addressA === addressB) {
    return {
      kind: "name-address",
      detail: `Nome ${pct(similarity)} similar no mesmo endereço`,
    };
  }

  // Same name, same spot, addresses written differently ("Av. Brasil 100" vs
  // "Avenida Brasil, 100"). 0.0007° is roughly 80m, matching the tolerance
  // `search.ts` already uses for its own proximity check.
  if (withinMetres(a, b)) {
    return {
      kind: "name-proximity",
      detail: `Nome ${pct(similarity)} similar a menos de 80m`,
    };
  }

  return undefined;
}

/**
 * Fold the loser's facts into the survivor.
 *
 * Dropping the duplicate outright would lose contact details, which is the one
 * thing a second source is actually good for — Overture has the stable id and
 * the address, OpenStreetMap often has the phone Overture lacks.
 */
function absorb(keeper: Lead, other: Lead): void {
  keeper.phone ??= other.phone;
  keeper.email ??= other.email;
  keeper.website ??= other.website;
  keeper.address ??= other.address;
  keeper.category ??= other.category;
  keeper.lat ??= other.lat;
  keeper.lon ??= other.lon;

  const links: SocialLink[] = [
    ...(keeper.socialLinks ?? []),
    ...(other.socialLinks ?? []),
  ];
  if (links.length > 0) {
    keeper.socialLinks = [...new Map(links.map((l) => [l.url, l])).values()];
  }
  keeper.social ??= keeper.socialLinks?.[0]?.url ?? other.social;

  // Confidence is the provider's own belief that the record is real. Two
  // directories carrying the same business is corroboration, so keep the
  // stronger claim rather than averaging it away.
  keeper.confidence = Math.max(keeper.confidence, other.confidence);
}

/**
 * Normalised name with the legal form stripped off the end.
 *
 * One directory registers "Barbearia do João", the next carries the CNPJ name
 * "Barbearia do João LTDA". That suffix costs enough bigram similarity (0.86)
 * to fall under the 0.88 threshold, so the two stayed separate. Removing it is
 * better than lowering the bar, which would have started merging genuinely
 * different businesses that share a street.
 *
 * Only legal forms are stripped. Branch markers — "matriz", "filial",
 * "unidade 2" — are left alone on purpose: they are exactly the words that
 * distinguish two locations we must keep apart.
 */
function canonicalName(name: string): string {
  let out = normalise(name);
  // Looped: "…joao ltda me" sheds one suffix per pass.
  for (;;) {
    const next = out.replace(/\s+(ltda|me|epp|eireli|mei|s a|sa|cia)$/, "").trim();
    if (next === out || next.length === 0) return out;
    out = next;
  }
}

function digits(value: string | null | undefined): string {
  return value?.replace(/\D/g, "") ?? "";
}

function domainOf(url: string | null | undefined): string | null {
  if (!url) return null;
  try {
    const parsed = new URL(/^https?:\/\//i.test(url) ? url : `https://${url}`);
    return parsed.hostname.replace(/^www\./, "").toLowerCase();
  } catch {
    return null;
  }
}

const SHARED_HOSTS = [
  "instagram.com",
  "facebook.com",
  "linktr.ee",
  "wa.me",
  "api.whatsapp.com",
  "linkedin.com",
  "x.com",
  "twitter.com",
  "tiktok.com",
  "youtube.com",
  "beacons.ai",
  "bio.link",
  "google.com",
  "sites.google.com",
  "negocio.site",
  "business.site",
];

function isSharedHost(domain: string): boolean {
  return SHARED_HOSTS.some(
    (host) => domain === host || domain.endsWith(`.${host}`),
  );
}

function withinMetres(a: Lead, b: Lead): boolean {
  if (a.lat === null || a.lon === null || b.lat === null || b.lon === null) {
    return false;
  }
  return Math.hypot(a.lat - b.lat, a.lon - b.lon) <= 0.0007;
}

function pct(ratio: number): string {
  return `${Math.round(ratio * 100)}%`;
}
