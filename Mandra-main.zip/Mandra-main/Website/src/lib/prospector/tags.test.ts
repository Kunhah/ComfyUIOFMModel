import test from "node:test";
import assert from "node:assert/strict";

import {
  MAX_TAGS,
  MAX_TAG_LENGTH,
  normaliseTag,
  parseTags,
  sanitiseTags,
  tagKey,
  tagNeedle,
} from "@/lib/prospector/tags";

test("keeps the spelling the operator typed", () => {
  assert.equal(normaliseTag("Indicação do Marcelo"), "Indicação do Marcelo");
});

test("collapses whitespace and strips pasted newlines", () => {
  assert.equal(normaliseTag("  orçamento\n\tenviado  "), "orçamento enviado");
});

test("rejects what cannot be a label", () => {
  assert.equal(normaliseTag("   "), null);
  assert.equal(normaliseTag(""), null);
  assert.equal(normaliseTag(42), null);
  assert.equal(normaliseTag(null), null);
});

test("caps an over-long label instead of dropping it", () => {
  const tag = normaliseTag("x".repeat(200));
  assert.equal(tag?.length, MAX_TAG_LENGTH);
});

test("folds case, accents and punctuation into one key", () => {
  assert.equal(tagKey("Follow-up"), tagKey("follow up"));
  assert.equal(tagKey("Indicação"), tagKey("INDICACAO"));
  assert.notEqual(tagKey("vip"), tagKey("vip plus"));
});

test("deduplicates across spellings, keeping the first", () => {
  assert.deepEqual(
    sanitiseTags(["Follow-up", "follow up", "FOLLOW UP"]),
    ["Follow-up"],
  );
});

test("drops unusable entries without failing the whole list", () => {
  assert.deepEqual(sanitiseTags(["vip", "  ", null, 7, "novo"]), [
    "vip",
    "novo",
  ]);
});

test("caps the number of labels", () => {
  const many = Array.from({ length: 40 }, (_, i) => `etiqueta ${i}`);
  assert.equal(sanitiseTags(many).length, MAX_TAGS);
});

test("a non-list is an empty list, never a crash", () => {
  assert.deepEqual(sanitiseTags("vip"), []);
  assert.deepEqual(sanitiseTags(undefined), []);
});

test("reads the column back, and survives a hand-edited value", () => {
  assert.deepEqual(parseTags('["vip","novo"]'), ["vip", "novo"]);
  assert.deepEqual(parseTags(null), []);
  assert.deepEqual(parseTags("not json"), []);
  assert.deepEqual(parseTags('{"vip":1}'), []);
});

test("the search needle cannot match a longer label that starts the same", () => {
  const stored = JSON.stringify(["vip-plus", "novo"]);
  assert.ok(!stored.includes(tagNeedle("vip")));
  assert.ok(stored.includes(tagNeedle("vip-plus")));
});

test("the needle escapes a label containing a quote", () => {
  const stored = JSON.stringify(sanitiseTags(['diz "urgente"']));
  assert.ok(stored.includes(tagNeedle('diz "urgente"')));
});
