import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { after, before, beforeEach, describe, it } from "node:test";

/**
 * Who may contact a lead, exercised against a real database file.
 *
 * The rule this feature exists for is not expressible as a pure function: it is
 * "two operators asking at the same time get different answers", and the thing
 * that decides is a SQLite conflict clause. So every test here drives the actual
 * statements, in the order two dialers would.
 *
 * PROSPECTOR_DB has to be set before db.ts is imported — it reads it when the
 * connection is first opened — hence the dynamic imports inside `before`.
 */

let own: typeof import("./ownership");
let calls: typeof import("./calls");
let db: typeof import("./db");
let dir: string;

const ANA = { id: "u1", displayName: "Ana" };
const BRUNO = { id: "u2", displayName: "Bruno" };
const CHEFE = { id: "env:admin", displayName: "admin", isAdmin: true };

function seed(id: string, name: string, phone: string | null): void {
  db.getDb()
    .prepare(
      `INSERT INTO leads (id, name, phone, phone_norm, country, city, uf, confidence, score, search_norm)
       VALUES (?, ?, ?, ?, 'BR', 'Belo Horizonte', 'MG', 0.9, 70, ?)`,
    )
    .run(
      id,
      name,
      phone,
      phone?.replace(/\D/g, "") ?? null,
      name.toLowerCase(),
    );
}

before(async () => {
  dir = mkdtempSync(path.join(tmpdir(), "ownership-test-"));
  process.env.PROSPECTOR_DB = path.join(dir, "prospector.db");
  db = await import("./db");
  own = await import("./ownership");
  calls = await import("./calls");
});

after(() => rmSync(dir, { recursive: true, force: true }));

beforeEach(() => {
  // A clean base per test: these are all about two people racing for one lead,
  // and a claim left over from the previous test is a false pass or a false
  // failure depending on which one ran first.
  const handle = db.getDb();
  handle.exec("DELETE FROM lead_claims");
  handle.exec("DELETE FROM lead_calls");
  handle.exec("DELETE FROM call_list_items");
  handle.exec("DELETE FROM call_lists");
  handle.exec("DELETE FROM leads");
  seed("l1", "Padaria Sao Jorge", "+5531987911222");
  seed("l2", "Bar do Ze", "+5531987911333");
  seed("l3", "Salao Bela", "+5531987911444");
});

describe("claims", () => {
  it("gives the lead to exactly one of two operators", () => {
    const first = own.claimLead({ leadId: "l1", actor: ANA });
    const second = own.claimLead({ leadId: "l1", actor: BRUNO });

    assert.equal(first.ok, true);
    assert.equal(second.ok, false);
    if (!second.ok) {
      assert.equal(second.block.reason, "reservado");
      assert.equal(second.block.by, "Ana");
    }
  });

  it("lets the holder renew its own claim", () => {
    assert.equal(own.claimLead({ leadId: "l1", actor: ANA }).ok, true);
    // The dialer does this every ten minutes while it is open. A renewal that
    // conflicted with itself would drop the operator's own lead mid-call.
    assert.equal(own.claimLead({ leadId: "l1", actor: ANA }).ok, true);
  });

  it("hands the lead on once the claim has lapsed", () => {
    own.claimLead({ leadId: "l1", actor: ANA });
    // The closed laptop. Expiry is the entire reason the claim is a row with a
    // date rather than a flag — without it this lead is Ana's forever.
    db.getDb()
      .prepare(
        "UPDATE lead_claims SET expires_at = '2020-01-01T00:00:00.000Z' WHERE lead_id = ?",
      )
      .run("l1");

    assert.equal(own.blockFor("l1", BRUNO), null);
    assert.equal(own.claimLead({ leadId: "l1", actor: BRUNO }).ok, true);
  });

  it("releases only the holder's own claim", () => {
    own.claimLead({ leadId: "l1", actor: ANA });
    // Bruno must not be able to take a lead off Ana while she is on the phone.
    assert.equal(own.releaseClaim("l1", BRUNO.id), false);
    assert.equal(own.blockFor("l1", BRUNO)?.reason, "reservado");
    assert.equal(own.releaseClaim("l1", ANA.id), true);
    assert.equal(own.blockFor("l1", BRUNO), null);
  });

  it("never blocks an admin", () => {
    own.claimLead({ leadId: "l1", actor: ANA });
    assert.equal(own.blockFor("l1", CHEFE), null);
  });
});

describe("ownership", () => {
  it("is taken by the first recorded call and refuses the second operator", () => {
    const result = calls.recordCall({
      leadId: "l1",
      outcome: "interessado",
      actor: ANA,
    })!;
    assert.ok(!calls.isRefusal(result));
    assert.equal(result.becameOwner, true);

    const refused = calls.recordCall({
      leadId: "l1",
      outcome: "nao_atendeu",
      actor: BRUNO,
    })!;
    assert.ok(calls.isRefusal(refused));
    assert.equal(refused.blocked.reason, "dono");
    assert.equal(refused.blocked.by, "Ana");

    // And the refusal wrote nothing: one call in the log, not two.
    assert.equal(calls.callHistory("l1").length, 1);
  });

  it("does not change hands on the owner's later calls", () => {
    calls.recordCall({ leadId: "l1", outcome: "nao_atendeu", actor: ANA });
    const again = calls.recordCall({
      leadId: "l1",
      outcome: "retornar",
      actor: ANA,
    })!;
    assert.ok(!calls.isRefusal(again));
    // False the second time: `becameOwner` is "this call is the one that took
    // it", which is what the audit line and the screen both say.
    assert.equal(again.becameOwner, false);
    assert.equal(own.ownerOf("l1")?.name, "Ana");
  });

  it("outlives the claim, which the call releases", () => {
    own.claimLead({ leadId: "l1", actor: ANA });
    calls.recordCall({ leadId: "l1", outcome: "interessado", actor: ANA });

    // The reservation is gone — Ana can pick the lead up from another machine —
    // and the ownership is what keeps Bruno out.
    assert.equal(own.blockFor("l1", ANA), null);
    assert.equal(own.blockFor("l1", BRUNO)?.reason, "dono");
  });

  it("is handed back by an admin release", () => {
    calls.recordCall({ leadId: "l1", outcome: "interessado", actor: ANA });
    own.claimLead({ leadId: "l1", actor: ANA });

    const previous = own.releaseOwnership("l1");
    assert.equal(previous?.name, "Ana");
    // The claim goes with it: a lead free of an owner and still reserved for
    // the person who had it is not free.
    assert.equal(own.blockFor("l1", BRUNO), null);
    assert.equal(own.ownerOf("l1"), null);
  });

  it("moves outright on a reassignment", () => {
    calls.recordCall({ leadId: "l1", outcome: "interessado", actor: ANA });
    own.claimLead({ leadId: "l1", actor: ANA });

    assert.equal(own.assignOwnership("l1", BRUNO), true);
    assert.equal(own.ownerOf("l1")?.id, BRUNO.id);
    // Ana's leftover reservation must not block the person it was just given to.
    assert.equal(own.blockFor("l1", BRUNO), null);
    assert.equal(own.blockFor("l1", ANA)?.reason, "dono");
  });
});

describe("the queue", () => {
  it("steps over positions that belong to somebody else", () => {
    const list = calls.createCallList({
      name: "Fila",
      leadIds: ["l1", "l2", "l3"],
      actor: ANA,
    })!;
    // l1 is Bruno's, l2 is on Bruno's screen right now. Both are still pending
    // positions in this list — they are skipped for Ana, not deleted.
    calls.recordCall({ leadId: "l1", outcome: "interessado", actor: BRUNO });
    own.claimLead({ leadId: "l2", actor: BRUNO });

    assert.equal(calls.nextInList(list.id, ANA)?.leadId, "l3");
    assert.equal(calls.blockedInList(list.id, ANA), 2);
    // Bruno's own two are not blocked for Bruno, so nothing has been lost. l1
    // is still position zero and still pending — the call against it was logged
    // from the CRM, with no list, so it closed no queue position.
    assert.equal(calls.nextInList(list.id, BRUNO)?.leadId, "l1");
    assert.equal(calls.blockedInList(list.id, BRUNO), 0);
  });

  it("does not build a list out of another operator's leads", () => {
    calls.recordCall({ leadId: "l1", outcome: "interessado", actor: BRUNO });
    own.claimLead({ leadId: "l2", actor: BRUNO });

    const list = calls.createCallList({
      name: "Minha",
      leadIds: ["l1", "l2", "l3"],
      actor: ANA,
    })!;
    // One of three survives, and the route reports the difference as `excluded`
    // rather than handing back a list that looks like three calls of work.
    assert.equal(list.total, 1);
    assert.equal(calls.nextInList(list.id, ANA)?.leadId, "l3");
  });

  it("keeps the automatic queue off leads that are taken", () => {
    calls.recordCall({ leadId: "l1", outcome: "interessado", actor: BRUNO });
    own.claimLead({ leadId: "l2", actor: BRUNO });

    assert.deepEqual(calls.dailyCandidates(10, undefined, ANA), ["l3"]);
    // The admin's preview is the whole pool: no actor, nothing excluded on
    // ownership grounds. l1 is out for a different reason — it was just called,
    // so the recall cooldown holds it.
    assert.deepEqual(calls.dailyCandidates(10).sort(), ["l2", "l3"]);
  });

  it("gives the lead back when the operator skips it", () => {
    const list = calls.createCallList({
      name: "Fila",
      leadIds: ["l1", "l2"],
      actor: ANA,
    })!;
    own.claimLead({ leadId: "l1", actor: ANA, listId: list.id });
    calls.skipItem(list.id, "l1", ANA.id);

    // Ana said she is not calling this one. Bruno should not have to wait out
    // her reservation to find that out.
    assert.equal(own.blockFor("l1", BRUNO), null);
  });
});
