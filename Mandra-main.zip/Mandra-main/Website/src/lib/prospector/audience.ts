import { createHash } from "node:crypto";
import { findCountry } from "@/lib/countries";
import { normalisePhone } from "./score";
import type { StoredLead } from "./types";

/**
 * Customer lists for the ad platforms, built from the leads that actually
 * converted on the phone.
 *
 * This is the second half of what the call outcomes are for. A lookalike is only
 * as good as its seed, and the seed a CRM can produce that nothing else can is
 * "the businesses that said yes on a call" — a far stronger signal than "every
 * business we ever found in this niche", which is what an unfiltered export is.
 *
 * Both platforms want the same thing and disagree about every detail of it:
 * column names, which fields may be hashed, how a phone is written before it is
 * hashed. Getting that wrong doesn't error — it produces a file that uploads
 * cleanly and matches nobody, which is the worst failure mode available. So the
 * normalisation rules are written out per platform rather than shared.
 *
 * Nothing here is sent anywhere: it produces a file the operator uploads. That
 * is deliberate — an API integration would need long-lived ad-account tokens in
 * this container for a job that runs once a month.
 */

/**
 * SHA-256 of an already-normalised value, lowercase hex. Both platforms specify
 * exactly this, and both specify that an empty field stays empty rather than
 * becoming the hash of an empty string — a column full of
 * e3b0c442… is a column of identical fake identities.
 */
function sha256(value: string): string {
  return value.length === 0
    ? ""
    : createHash("sha256").update(value, "utf8").digest("hex");
}

/**
 * An e-mail as both platforms want it before hashing: trimmed, lowercased.
 *
 * Deliberately *not* doing the gmail dot-and-plus stripping some guides suggest.
 * Meta and Google both normalise their own side; pre-stripping ours means the
 * two sides fold differently and the match rate drops.
 */
function normaliseEmail(raw: string | null): string {
  const email = raw?.trim().toLowerCase() ?? "";
  // A cell that isn't an address at all is worse than an empty one: it counts
  // against the file's quality score on upload while matching nothing.
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? email : "";
}

/**
 * E.164 with a leading "+" — what both platforms specify for the phone column,
 * and the one place this codebase wants the plus back. `normalisePhone` drops it
 * for the CSV export because Excel reads +55… as a formula; an upload file is
 * never opened in Excel and the platforms match on the full international form.
 */
function e164(lead: StoredLead): string {
  const digits = normalisePhone(lead.phone, lead.country);
  return digits ? `+${digits}` : "";
}

/** ISO-3166 alpha-2, lowercased. Rows with no country are Brazilian. */
function countryCode(lead: StoredLead): string {
  return (lead.country ?? "BR").toLowerCase();
}

/**
 * The contact's first and last name, where one was typed into the CRM.
 *
 * `contact_name` is a person; the lead's `name` is a business and must never be
 * used here. "Padaria São Jorge" as a first name is not a near miss — it is a
 * row that will never match and drags the file's quality down with it.
 */
function nameParts(lead: StoredLead): { first: string; last: string } {
  const parts = (lead.contactName ?? "")
    .trim()
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean);
  if (parts.length === 0) return { first: "", last: "" };
  if (parts.length === 1) return { first: parts[0], last: "" };
  return { first: parts[0], last: parts[parts.length - 1] };
}

/** City as both platforms want it: lowercase, no spaces, no punctuation. */
function normaliseCity(lead: StoredLead): string {
  return (lead.city ?? "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z]/g, "");
}

/**
 * State as Meta wants it: the two-letter code, lowercased, no country prefix.
 * Empty outside the countries where we hold one — the region is free text there
 * and a full state name in a column specified as a code matches nothing.
 */
function normaliseRegion(lead: StoredLead): string {
  const uf = (lead.uf ?? "").trim();
  return /^[A-Za-z]{2}$/.test(uf) ? uf.toLowerCase() : "";
}

export type AudienceFormat = "meta" | "google" | "plano";

export const AUDIENCE_FORMAT_LABEL: Record<AudienceFormat, string> = {
  meta: "Meta Ads (público personalizado)",
  google: "Google Ads (Customer Match)",
  plano: "CSV simples (sem hash)",
};

export function isAudienceFormat(value: unknown): value is AudienceFormat {
  return value === "meta" || value === "google" || value === "plano";
}

/**
 * Meta's customer-list columns, in Meta's own header names.
 *
 * The headers are the API's field keys (`phone`, `email`, `fn`, `ln`, `ct`,
 * `st`, `country`) rather than friendly labels, because Meta's uploader
 * auto-maps them when they match exactly and asks the operator to map twenty
 * columns by hand when they don't.
 */
const META_HEADERS = ["email", "phone", "fn", "ln", "ct", "st", "country"];

function metaRow(lead: StoredLead): string[] {
  const { first, last } = nameParts(lead);
  return [
    sha256(normaliseEmail(lead.email)),
    sha256(e164(lead)),
    sha256(first),
    sha256(last),
    sha256(normaliseCity(lead)),
    sha256(normaliseRegion(lead)),
    // Country is hashed like everything else in Meta's spec, despite being the
    // one field with no identifying power on its own.
    sha256(countryCode(lead)),
  ];
}

/**
 * Google's Customer Match columns.
 *
 * Google names its headers "Email"/"Phone" and accepts them hashed, but requires
 * that a row carry at least one of the two — a row with only a city is rejected
 * rather than partially matched, which is why `audienceRows` drops them.
 */
const GOOGLE_HEADERS = [
  "Email",
  "Phone",
  "First Name",
  "Last Name",
  "Country",
  "Zip",
];

function googleRow(lead: StoredLead): string[] {
  const { first, last } = nameParts(lead);
  return [
    sha256(normaliseEmail(lead.email)),
    sha256(e164(lead)),
    sha256(first),
    sha256(last),
    // Google takes country and zip unhashed, and rejects the file if they are
    // hashed. This asymmetry is the single easiest thing to get wrong here.
    countryCode(lead).toUpperCase(),
    "",
  ];
}

/**
 * The unhashed file, for anyone who wants to transform it themselves or feed a
 * platform neither of the above covers. Same identifying fields, in the clear —
 * which is why the route behind it needs the same export permission.
 */
const PLAIN_HEADERS = [
  "nome",
  "contato",
  "telefone",
  "email",
  "cidade",
  "uf",
  "pais",
  "etapa_funil",
  "nicho",
];

function plainRow(lead: StoredLead): string[] {
  return [
    lead.name,
    lead.contactName ?? "",
    e164(lead),
    lead.email ?? "",
    lead.city ?? "",
    lead.uf ?? "",
    (lead.country ?? "BR").toUpperCase(),
    lead.funnelStage,
    lead.niche ?? "",
  ];
}

export const AUDIENCE_HEADERS: Record<AudienceFormat, string[]> = {
  meta: META_HEADERS,
  google: GOOGLE_HEADERS,
  plano: PLAIN_HEADERS,
};

/**
 * True when a lead carries at least one identifier the platforms can match on.
 *
 * Rows without one are dropped rather than exported empty. Both platforms score
 * an upload on its match rate, and a file padded with unmatchable rows reports
 * as a worse audience than the same leads without them — so a silent drop here
 * is the honest behaviour, and the route reports how many were dropped.
 */
export function isMatchable(lead: StoredLead): boolean {
  return normaliseEmail(lead.email).length > 0 || e164(lead).length > 0;
}

export type AudienceFile = {
  headers: string[];
  rows: string[][];
  /** Leads that carried no phone and no e-mail, so could not be uploaded. */
  dropped: number;
};

export function buildAudience(
  leads: StoredLead[],
  format: AudienceFormat,
): AudienceFile {
  const matchable = leads.filter(isMatchable);
  const row =
    format === "meta" ? metaRow : format === "google" ? googleRow : plainRow;

  return {
    headers: AUDIENCE_HEADERS[format],
    rows: matchable.map(row),
    dropped: leads.length - matchable.length,
  };
}

/**
 * Countries whose numbering plan we know, so a lead's phone can be written in
 * E.164 at all. Exported for the export screen's warning: a country missing from
 * `src/lib/countries.ts` produces rows with an empty phone column and no error.
 */
export function hasKnownDialCode(lead: StoredLead): boolean {
  return (findCountry(lead.country ?? "BR")?.dial ?? "").length > 0;
}
