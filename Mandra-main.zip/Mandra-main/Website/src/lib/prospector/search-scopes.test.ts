import assert from "node:assert/strict";
import test from "node:test";
import { resolveSearchArea } from "./scopes";

test("old requests still resolve as city searches", () => {
  const area = resolveSearchArea({
    niche: "energia-solar",
    city: "São Paulo",
    uf: "SP",
    country: "BR",
  });
  assert.equal(area?.scope, "city");
  assert.equal(area?.name, "São Paulo");
  assert.ok(area?.city);
});

test("resolves Brazilian states, macro-regions and the whole country", () => {
  const state = resolveSearchArea({
    niche: "energia-solar",
    scope: "state",
    uf: "mg",
    country: "BR",
  });
  assert.deepEqual(
    { scope: state?.scope, name: state?.name, ufs: state?.ufs },
    { scope: "state", name: "Minas Gerais", ufs: ["MG"] },
  );

  const region = resolveSearchArea({
    niche: "energia-solar",
    scope: "region",
    region: "sudeste",
    country: "BR",
  });
  assert.deepEqual(region?.ufs, ["ES", "MG", "RJ", "SP"]);

  const country = resolveSearchArea({
    niche: "energia-solar",
    scope: "country",
    country: "BR",
  });
  assert.equal(country?.name, "Brasil");
  assert.deepEqual(country?.ufs, []);
});

test("rejects invalid and unsupported broad areas", () => {
  assert.equal(
    resolveSearchArea({
      niche: "energia-solar",
      scope: "region",
      region: "atlántico",
      country: "BR",
    }),
    undefined,
  );
  assert.equal(
    resolveSearchArea({
      niche: "energia-solar",
      scope: "state",
      uf: "CA",
      country: "US",
    }),
    undefined,
  );
});
