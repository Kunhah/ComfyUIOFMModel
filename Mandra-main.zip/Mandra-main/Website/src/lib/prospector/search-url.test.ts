import assert from "node:assert/strict";
import test from "node:test";
import { parseInitialSearch } from "./search-url";

test("a broad search survives a reload, which is what the copy got wrong", () => {
  // This is the regression. `/admin/prospector` carried its own parser, written
  // before broad searches existed, so it demanded a city. Running a state-wide
  // search there put ?scope=state&uf=MG in the address bar and pressing reload
  // emptied the screen — the URL describing a search the page refused to read.
  const state = parseInitialSearch({
    niche: "gestores-trafego",
    scope: "state",
    uf: "mg",
  });
  assert.equal(state?.scope, "state");
  assert.equal(state?.uf, "MG");

  const region = parseInitialSearch({
    niche: "agencias-marketing",
    scope: "region",
    region: "sudeste",
  });
  assert.equal(region?.scope, "region");
  assert.equal(region?.region, "sudeste");

  const country = parseInitialSearch({ niche: "design-criacao", scope: "country" });
  assert.equal(country?.scope, "country");
});

test("it is the counterpart of what runSearch writes", () => {
  // runSearch omits `city` for a broad search and writes `all=1` / `save=0`
  // only when they are off. Reading a key it never writes, or failing on one it
  // does, is how the two halves drift.
  const s = parseInitialSearch({
    niche: "barbearias",
    scope: "city",
    city: "Belo Horizonte",
    uf: "MG",
    country: "BR",
    conf: "0.7",
    all: "1",
    save: "0",
  });
  assert.equal(s?.city, "Belo Horizonte");
  assert.equal(s?.minConfidence, 0.7);
  assert.equal(s?.onlyWithoutWebsite, false);
  assert.equal(s?.save, false);

  // Defaults, when the link carries none of the optional keys.
  const bare = parseInitialSearch({ niche: "barbearias", city: "Manaus" });
  assert.equal(bare?.scope, "city");
  assert.equal(bare?.country, "BR");
  assert.equal(bare?.onlyWithoutWebsite, true);
  assert.equal(bare?.save, true);
  assert.equal(bare?.minConfidence, 0.5);
});

test("a link that cannot resolve returns null rather than a wrong search", () => {
  // An unknown niche would search zero categories and read as an empty city.
  assert.equal(parseInitialSearch({ niche: "nao-existe", city: "Manaus" }), null);
  assert.equal(parseInitialSearch({ city: "Manaus" }), null);
  // Each scope has its own required field.
  assert.equal(parseInitialSearch({ niche: "barbearias", scope: "city" }), null);
  assert.equal(parseInitialSearch({ niche: "barbearias", scope: "state" }), null);
  assert.equal(parseInitialSearch({ niche: "barbearias", scope: "region" }), null);
  // A country not in the index would resolve to no city at all; fall back to BR.
  assert.equal(
    parseInitialSearch({ niche: "barbearias", city: "Manaus", country: "ZZ" })?.country,
    "BR",
  );
});
