import { mkdirSync } from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { normalise } from "./cities";
import { nicheFingerprint, nicheForCategory } from "./niches";
import { normalisePhone } from "./score";
import type { Lead, ScoredLead } from "./types";

/**
 * Local lead history, in SQLite.
 *
 * The search itself needs no database — Overture plus the local extract is the
 * whole engine. This adds the one thing a search can't tell you: whether you have
 * seen a business before. Without it, running the same city twice looks identical
 * both times and there is no way to spot the businesses that appeared since.
 *
 * `node:sqlite` ships with Node, so there is no dependency, no native build step
 * and nothing to keep out of the bundler. Its API is synchronous, which for a
 * single-user tool on localhost is a feature: a search writes ~1.000 rows in one
 * transaction in single-digit milliseconds, and there is no connection pool, no
 * network hop and no service to be down.
 *
 * The file sits next to the extract in `data/`, and is gitignored for the same
 * reason — it is local state, not source.
 */

const COLUMNS = [
  "id",
  "source",
  "name",
  "category",
  "address",
  "city",
  "uf",
  "country",
  "phone",
  "phone_norm",
  "website",
  "social",
  "provider_socials",
  "email",
  "lat",
  "lon",
  "confidence",
  "score",
  "whatsapp",
  "niche",
  "searched_city",
  "searched_uf",
  "search_norm",
] as const;

/**
 * Created on open rather than through migration tooling. This is a local
 * single-user database that can be deleted and rebuilt by re-running a search,
 * so versioned migrations would be ceremony with nothing to protect.
 */
const SCHEMA = `
  CREATE TABLE IF NOT EXISTS leads (
    -- Overture GERS id. Stable across releases, which is what makes dedupe work
    -- at all once the extract is re-synced.
    id            TEXT PRIMARY KEY,
    source        TEXT NOT NULL DEFAULT 'overture',
    -- The intake_sites row that produced this lead, when a customer's form did.
    -- NULL on everything the prospector found, which is most of the table — this
    -- is the column that says "the lead came to us" rather than the reverse.
    intake_site   TEXT,
    -- The client account this lead belongs to. NULL means Atlas's own: every
    -- lead the prospector has ever found is ours, and giving ourselves a row in
    -- the accounts table would make our pipeline a tenant of itself. A client's
    -- session can only ever see its own id here — see LeadScope in history.ts,
    -- which is the one place that predicate is written.
    --
    -- A value, not a foreign key, for the same reason intake_site is one:
    -- suspending or unwinding an account must never cascade into a pipeline the
    -- client is entitled to take with them.
    account_id    TEXT,
    name          TEXT NOT NULL,
    category      TEXT,
    address       TEXT,
    city          TEXT,
    uf            TEXT,
    -- ISO-3166 alpha-2. NULL on rows written before the prospector left Brazil,
    -- and every reader treats NULL as 'BR' — which is what those rows are.
    country       TEXT,
    phone         TEXT,
    -- The phone reduced to bare E.164 digits by normalisePhone(), so numbers
    -- can be grouped. The raw column keeps whatever the source wrote, and
    -- "(31) 98791-1222" and "+55 31 98791 1222" are the same line — without a
    -- folded key there is no way to notice that forty businesses list one
    -- switchboard, which is the main reason a lead's phone is not its own.
    phone_norm    TEXT,
    website       TEXT,
    social        TEXT,
    provider_socials TEXT,
    email         TEXT,
    lat           REAL,
    lon           REAL,
    confidence    REAL,
    score         INTEGER,
    whatsapp      INTEGER NOT NULL DEFAULT 0,
    -- Which search surfaced it, so a lead can be traced back to a niche/city.
    niche         TEXT,
    searched_city TEXT,
    searched_uf   TEXT,
    -- Name and address, accent- and punctuation-folded by the same normalise()
    -- the city index uses. SQLite has no strip_accents, so free-text search would
    -- otherwise miss "Estudio" for "Estúdio" — folding once on write is cheaper
    -- than failing to find the lead later.
    search_norm   TEXT,
    -- Outreach fields. Nothing writes these yet; they exist so adding a pipeline
    -- view later doesn't need a schema change.
    status        TEXT NOT NULL DEFAULT 'novo'
                  CHECK (status IN ('novo','contatado','respondeu','cliente','descartado')),
    -- Where the deal sits, as opposed to what happened to the outreach. Kept in
    -- step with status by the writers in history.ts; see FunnelStage in types.ts.
    funnel_stage  TEXT NOT NULL DEFAULT 'descoberta',
    -- Explicit board membership. Contact activity and funnel membership are
    -- separate decisions: an admin adds or removes a lead from the board.
    in_funnel     INTEGER NOT NULL DEFAULT 0,
    -- JSON array of {platform, url}, typed in the CRM. The provider's single
    -- find stays in the social column, so a hand-added profile can't overwrite it.
    socials       TEXT,
    -- JSON array of free-text labels the operator groups by. Free text, not a
    -- registry: see tags.ts for why, and for the rules the writers enforce.
    tags          TEXT,
    -- The person at the business, not the business.
    contact_name  TEXT,
    notes         TEXT,
    contacted_at  TEXT,
    -- A date rather than a timestamp: this is a human work queue, not a job
    -- scheduler, and "follow up Friday" must not shift with time zones.
    next_follow_up_at TEXT,
    -- The operator this lead now belongs to, stamped by the first person to
    -- actually contact it — a logged call or an outreach action, never a search
    -- or a note. From then on nobody else may contact it: two operators phoning
    -- the same business a day apart is the one mistake a prospect always
    -- notices, and the queue's "already in someone's list" rule only ever
    -- covered leads still waiting in a queue, not ones already spoken to.
    --
    -- A value, not a foreign key, and captured with a display name for the same
    -- reason every audit row here captures one: a deleted account must not erase
    -- who owns the relationship. Admins are exempt from the block and can hand a
    -- lead back with releaseOwnership() — see ownership.ts, which is the only
    -- module that writes these three.
    owner_id      TEXT,
    owner_name    TEXT,
    owned_at      TEXT,
    -- ISO-8601 UTC with milliseconds. datetime('now') was the obvious choice and
    -- is wrong twice over: it resolves to whole seconds, so two searches in the
    -- same second are indistinguishable, and it prints no timezone marker
    -- despite being UTC.
    first_seen_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    last_seen_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

`;

/**
 * Indexes are applied separately, and only after addMissingColumns() has run.
 * They have to be: CREATE INDEX on a column an older database doesn't have yet
 * throws, which killed the whole schema statement before the column could be
 * added — leaving the table permanently one migration behind and every search
 * failing with "no such column".
 */
const META = `
  CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  -- Search activity is deliberately separate from leads: the same business can
  -- appear in many searches, while the administrator needs to see each use of
  -- the tool and who made it.
  CREATE TABLE IF NOT EXISTS prospector_searches (
    id                 INTEGER PRIMARY KEY,
    actor_id           TEXT NOT NULL,
    actor_username     TEXT NOT NULL,
    actor_display_name TEXT NOT NULL,
    niche              TEXT NOT NULL,
    city               TEXT NOT NULL,
    uf                 TEXT NOT NULL,
    country            TEXT,
    matched            INTEGER NOT NULL,
    returned           INTEGER NOT NULL,
    inserted           INTEGER NOT NULL DEFAULT 0,
    searched_at        TEXT NOT NULL
                       DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  -- An immutable operator audit. Lead fields may be edited or a user may be
  -- removed later, so the useful labels are captured with the action itself.
  CREATE TABLE IF NOT EXISTS prospector_activity (
    id                 INTEGER PRIMARY KEY,
    actor_id           TEXT NOT NULL,
    actor_username     TEXT NOT NULL,
    actor_display_name TEXT NOT NULL,
    action             TEXT NOT NULL,
    lead_id            TEXT,
    lead_name          TEXT,
    lead_city          TEXT,
    lead_uf            TEXT,
    detail             TEXT,
    occurred_at        TEXT NOT NULL
                       DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  -- A named, ordered queue of leads to phone. Separate from the leads table because the
  -- same business belongs to as many lists as it has campaigns, and a list
  -- outlives the filter it was built from — rebuilding from source_query
  -- later would silently pick up leads found since, which is a different list.
  CREATE TABLE IF NOT EXISTS call_lists (
    id                 INTEGER PRIMARY KEY,
    name               TEXT NOT NULL,
    created_by_id      TEXT NOT NULL,
    created_by_name    TEXT NOT NULL,
    -- The history filter query the list was built from, kept for display only.
    source_query       TEXT,
    created_at         TEXT NOT NULL
                       DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  -- The order is the whole point: "in order" is what makes a call session
  -- resumable across days and across operators without anyone tracking where
  -- they were. ON DELETE CASCADE on both sides — a deleted lead must not leave
  -- a queue position pointing at nothing, and the CRM's delete is the one
  -- destructive path we already have.
  CREATE TABLE IF NOT EXISTS call_list_items (
    list_id            INTEGER NOT NULL
                       REFERENCES call_lists (id) ON DELETE CASCADE,
    lead_id            TEXT NOT NULL
                       REFERENCES leads (id) ON DELETE CASCADE,
    position           INTEGER NOT NULL,
    state              TEXT NOT NULL DEFAULT 'pendente'
                       CHECK (state IN ('pendente','concluido','pulado')),
    PRIMARY KEY (list_id, lead_id)
  );

  -- One row per dial. Deliberately not a column on the leads table: the
  -- questions worth asking of cold calling — dials per contact, which operator
  -- converts, which niche answers the phone — are questions about attempts,
  -- and a column only ever remembers the last one. The actor's name is captured with the row for
  -- the same reason prospector_activity captures it: accounts get deleted.
  CREATE TABLE IF NOT EXISTS lead_calls (
    id                 INTEGER PRIMARY KEY,
    lead_id            TEXT NOT NULL REFERENCES leads (id) ON DELETE CASCADE,
    -- Null for a call placed from the CRM rather than from a queue.
    list_id            INTEGER REFERENCES call_lists (id) ON DELETE SET NULL,
    actor_id           TEXT NOT NULL,
    actor_display_name TEXT NOT NULL,
    outcome            TEXT NOT NULL,
    next_step          TEXT NOT NULL DEFAULT 'nenhum',
    notes              TEXT,
    -- The number as it was actually dialled. The lead's phone can be corrected
    -- afterwards, and a log that then claims the wrong number was reached is
    -- worse than one that admits which one was.
    phone              TEXT,
    occurred_at        TEXT NOT NULL
                       DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  -- A short-lived reservation on a lead somebody is dialling *right now*.
  --
  -- Ownership (leads.owner_id) answers "who does this relationship belong to",
  -- and it is only stamped once a contact has actually happened. That leaves a
  -- window of exactly the wrong length: from the moment a dialer opens a lead
  -- to the moment the call is logged, the lead is unowned and any other queue
  -- may still hand it out. This table closes it.
  --
  -- One row per lead, so the primary key *is* the mutual exclusion: the claim is
  -- taken with a single INSERT .. ON CONFLICT DO UPDATE that only fires when the
  -- existing claim is the same operator's or has expired, which makes "who got
  -- it" a decision SQLite makes rather than a read followed by a write.
  --
  -- Expiring rather than released-on-exit, because the release that matters is
  -- the one that never arrives: a closed laptop, a dead tab, a browser that
  -- crashed mid-call. A claim nobody can outlive is a lead nobody can ever call
  -- again. The dialer renews while it is open — see CLAIM_TTL_MINUTES.
  CREATE TABLE IF NOT EXISTS lead_claims (
    lead_id            TEXT PRIMARY KEY
                       REFERENCES leads (id) ON DELETE CASCADE,
    actor_id           TEXT NOT NULL,
    actor_display_name TEXT NOT NULL,
    -- The queue it was claimed from, for display only. NULL for a lead worked
    -- straight from the CRM.
    list_id            INTEGER REFERENCES call_lists (id) ON DELETE SET NULL,
    claimed_at         TEXT NOT NULL
                       DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    expires_at         TEXT NOT NULL
  );

  -- The opener an operator actually sends, and its variants.
  --
  -- The copy used to be six literals in score.ts, which made every change to
  -- the pitch a deploy. It is the one text in this tool that should change
  -- weekly, and the people who learn what it should say are the ones sending
  -- it -- so it lives in a table they can write to. An empty table is a working
  -- state: DEFAULT_BODIES in templates.ts is what a missing slot falls back to.
  --
  -- Many rows per (owner, slot), exactly one of them active. The variants are
  -- the point: rewriting the message in place leaves nothing to compare it
  -- against, and "the short one did better" is a sentence somebody has to be
  -- able to write down next to the message it is about.
  CREATE TABLE IF NOT EXISTS outreach_templates (
    id                 INTEGER PRIMARY KEY,
    -- Whose message this is. NULL means the team: what somebody who has never
    -- opened the editor sends, and the text a new operator starts from. A user
    -- id means that one person, and theirs wins over the team for them alone.
    --
    -- A value, not a foreign key, like every other actor reference here: a
    -- deleted account must not cascade into the copy somebody else was about
    -- to fork. An orphaned row simply stops resolving for anyone, which is
    -- what a departed operator private message should do.
    owner_id           TEXT,
    -- 'cliente' or 'parceiro', and 'pt' / 'es' / 'en'. No CHECK: the union in
    -- templates.ts is the gate, enforced before the write like FUNNEL_STAGES.
    intent             TEXT NOT NULL,
    speaks             TEXT NOT NULL,
    name               TEXT NOT NULL,
    body               TEXT NOT NULL,
    -- At most one per (owner_id, intent, speaks). Enforced in the writer inside
    -- a transaction rather than by a constraint, because the rule is "one" and
    -- a unique index can only say "not two of the same value".
    active             INTEGER NOT NULL DEFAULT 0,
    -- Captured with the row for the same reason every audit row here captures
    -- one: accounts get deleted, and who wrote the pitch outlives the login.
    author_id          TEXT NOT NULL,
    author_name        TEXT NOT NULL,
    created_at         TEXT NOT NULL
                       DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at         TEXT NOT NULL
                       DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  -- What the operator learned from sending it. Append-only, one row per
  -- observation, because "worked better" is a thing you notice over a week of
  -- replies and not a field you overwrite.
  CREATE TABLE IF NOT EXISTS outreach_template_notes (
    id                 INTEGER PRIMARY KEY,
    template_id        INTEGER NOT NULL
                       REFERENCES outreach_templates (id) ON DELETE CASCADE,
    author_id          TEXT NOT NULL,
    author_name        TEXT NOT NULL,
    body               TEXT NOT NULL,
    created_at         TEXT NOT NULL
                       DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  -- One row per outreach opened while a template was the active one, so the
  -- notes have numbers to sit next to. Stamped by the outreach route from the
  -- template that was active when the click arrived -- which is the same one
  -- the link was rendered from, except in the seconds after somebody switches
  -- the active variant. Worth knowing about; not worth a round trip per row.
  --
  -- Its own table rather than a column on prospector_activity: that one is an
  -- immutable audit of what people did, and this is an experiment's readings.
  CREATE TABLE IF NOT EXISTS outreach_template_uses (
    id                 INTEGER PRIMARY KEY,
    template_id        INTEGER NOT NULL
                       REFERENCES outreach_templates (id) ON DELETE CASCADE,
    -- ON DELETE CASCADE, so a forgotten lead does not leave a reading behind
    -- pointing at nothing -- the counts join back to leads for the outcome.
    lead_id            TEXT NOT NULL REFERENCES leads (id) ON DELETE CASCADE,
    actor_id           TEXT NOT NULL,
    channel            TEXT NOT NULL,
    occurred_at        TEXT NOT NULL
                       DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );
`;

const INDEXES = `
  CREATE INDEX IF NOT EXISTS leads_city_niche ON leads (searched_uf, searched_city, niche);
  CREATE INDEX IF NOT EXISTS leads_status ON leads (status);
  CREATE INDEX IF NOT EXISTS leads_score ON leads (score DESC);
  CREATE INDEX IF NOT EXISTS leads_search ON leads (search_norm);
  CREATE INDEX IF NOT EXISTS leads_follow_up ON leads (next_follow_up_at);
  -- The shared-number count groups on this, and the daily queue filters on it.
  CREATE INDEX IF NOT EXISTS leads_phone_norm
    ON leads (phone_norm) WHERE phone_norm IS NOT NULL;
  CREATE INDEX IF NOT EXISTS leads_funnel ON leads (funnel_stage);
  -- Partial, because the column is NULL on every prospector row and an index
  -- over those is a copy of the table that answers nothing.
  -- Partial, like leads_intake_site below and for the same reason: the column
  -- is NULL on every lead we found ourselves, which is most of the table, and
  -- an index over those answers nothing. Every query a client makes carries an
  -- account_id equality, so this is the one that has to be fast.
  CREATE INDEX IF NOT EXISTS leads_account
    ON leads (account_id, score DESC) WHERE account_id IS NOT NULL;
  CREATE INDEX IF NOT EXISTS leads_intake_site
    ON leads (intake_site) WHERE intake_site IS NOT NULL;
  CREATE INDEX IF NOT EXISTS prospector_searches_actor_time
    ON prospector_searches (actor_id, searched_at DESC);
  CREATE INDEX IF NOT EXISTS prospector_searches_time
    ON prospector_searches (searched_at DESC);
  CREATE INDEX IF NOT EXISTS prospector_activity_actor_time
    ON prospector_activity (actor_id, occurred_at DESC);
  CREATE INDEX IF NOT EXISTS prospector_activity_time
    ON prospector_activity (occurred_at DESC);
  -- The per-operator outcome queries join activity back to leads on this. It is
  -- the one access path the two actor indexes above can't serve.
  CREATE INDEX IF NOT EXISTS prospector_activity_lead
    ON prospector_activity (lead_id);
  -- The queue's one hot query: the next pending position in a list.
  CREATE INDEX IF NOT EXISTS call_list_items_order
    ON call_list_items (list_id, state, position);
  CREATE INDEX IF NOT EXISTS call_list_items_lead
    ON call_list_items (lead_id);
  CREATE INDEX IF NOT EXISTS lead_calls_lead_time
    ON lead_calls (lead_id, occurred_at DESC);
  CREATE INDEX IF NOT EXISTS lead_calls_actor_time
    ON lead_calls (actor_id, occurred_at DESC);
  CREATE INDEX IF NOT EXISTS lead_calls_time
    ON lead_calls (occurred_at DESC);
  -- Partial, because the column is NULL on every lead nobody has contacted yet,
  -- which is most of the table — and the only question asked of it is "whose is
  -- this", never "which are unowned".
  CREATE INDEX IF NOT EXISTS leads_owner
    ON leads (owner_id) WHERE owner_id IS NOT NULL;
  -- Every queue query filters claims by "still valid", and the sweep deletes on
  -- the same predicate.
  CREATE INDEX IF NOT EXISTS lead_claims_expiry
    ON lead_claims (expires_at);
  CREATE INDEX IF NOT EXISTS lead_claims_actor
    ON lead_claims (actor_id);
  -- The one hot read: every page that renders a WhatsApp link asks for the
  -- active body of each slot, for one person and for the team, in one query.
  CREATE INDEX IF NOT EXISTS outreach_templates_slot
    ON outreach_templates (active, owner_id, intent, speaks);
  CREATE INDEX IF NOT EXISTS outreach_template_notes_template
    ON outreach_template_notes (template_id, created_at DESC);
  CREATE INDEX IF NOT EXISTS outreach_template_uses_template
    ON outreach_template_uses (template_id);
  -- Partial-free on purpose: the outcome query groups by template and joins
  -- every row of it back to leads.
  CREATE INDEX IF NOT EXISTS outreach_template_uses_lead
    ON outreach_template_uses (lead_id);
`;

export function databasePath(): string {
  return (
    process.env.PROSPECTOR_DB ??
    path.join(process.cwd(), "data", "prospector.db")
  );
}

let db: DatabaseSync | null = null;

export function getDb(): DatabaseSync {
  if (db) return db;

  const file = databasePath();
  mkdirSync(path.dirname(file), { recursive: true });
  const handle = new DatabaseSync(file);

  // WAL survives an unclean shutdown without corrupting the file, and lets the
  // dev server's overlapping requests read while a write is in flight.
  handle.exec("PRAGMA journal_mode = WAL");
  // The default (FULL) fsyncs on every commit. NORMAL can lose the last few
  // commits if the machine loses power, which for a re-derivable lead cache is
  // the right trade for not fsyncing once per search.
  handle.exec("PRAGMA synchronous = NORMAL");
  handle.exec("PRAGMA foreign_keys = ON");
  handle.exec(SCHEMA);
  handle.exec(META);
  addMissingColumns(handle);
  handle.exec(INDEXES);
  reniche(handle);
  deduplicateHistoricalLeads(handle);

  db = handle;
  return db;
}

/**
 * Additive schema catch-up for a database created by an older build.
 *
 * `CREATE TABLE IF NOT EXISTS` does nothing to a table that already exists, so
 * adding a column to SCHEMA left existing files behind — and because the column
 * is in the INSERT list, *every search* would fail with "no such column" rather
 * than degrading. That is too sharp an edge for a file people are told they can
 * keep, so missing columns get added on open.
 *
 * Deliberately only additive: no renames, no type changes, no drops. Anything
 * beyond that and deleting the file is the honest answer.
 */
function addMissingColumns(handle: DatabaseSync): void {
  // The audit table gets the same treatment, for the same reason: `country` was
  // added to its DDL when the prospector left Brazil, and an existing file would
  // otherwise fail every insert — which means every search — with "no such
  // column" while the search itself worked perfectly.
  addMissingColumn(
    handle,
    "prospector_searches",
    "country",
    "ALTER TABLE prospector_searches ADD COLUMN country TEXT",
  );

  // The outreach copy shipped shared before it shipped per person, so a
  // database from that build has the table without this column — and every
  // read of it names the column, so the screen would fail rather than degrade.
  // NULL on the existing rows is the correct answer for all of them: what was
  // written when there was only one message *is* the team's message.
  addMissingColumn(
    handle,
    "outreach_templates",
    "owner_id",
    "ALTER TABLE outreach_templates ADD COLUMN owner_id TEXT",
  );

  const existing = new Set(
    (
      handle.prepare("PRAGMA table_info(leads)").all() as { name: string }[]
    ).map((c) => c.name),
  );

  const additive: { name: string; ddl: string }[] = [
    {
      name: "search_norm",
      ddl: "ALTER TABLE leads ADD COLUMN search_norm TEXT",
    },
    { name: "phone_norm", ddl: "ALTER TABLE leads ADD COLUMN phone_norm TEXT" },
    // Nullable with no default, so every lead that existed before client
    // accounts did stays ours. That is the correct answer for all of them and
    // the only one that needs no guessing.
    { name: "account_id", ddl: "ALTER TABLE leads ADD COLUMN account_id TEXT" },
    {
      name: "next_follow_up_at",
      ddl: "ALTER TABLE leads ADD COLUMN next_follow_up_at TEXT",
    },
    {
      name: "source",
      ddl: "ALTER TABLE leads ADD COLUMN source TEXT NOT NULL DEFAULT 'overture'",
    },
    // No CHECK constraint: SQLite can't add one to an existing table, and half
    // the rows validating is worse than none. FUNNEL_STAGES is the gate instead,
    // enforced in history.ts before the write.
    {
      name: "funnel_stage",
      ddl: "ALTER TABLE leads ADD COLUMN funnel_stage TEXT NOT NULL DEFAULT 'descoberta'",
    },
    {
      name: "in_funnel",
      ddl: "ALTER TABLE leads ADD COLUMN in_funnel INTEGER NOT NULL DEFAULT 0",
    },
    // A JSON array of {platform, url}. One column rather than one per network:
    // a business has however many profiles it has, and the set of networks that
    // matter changes faster than the schema should.
    { name: "socials", ddl: "ALTER TABLE leads ADD COLUMN socials TEXT" },
    { name: "tags", ddl: "ALTER TABLE leads ADD COLUMN tags TEXT" },
    {
      name: "provider_socials",
      ddl: "ALTER TABLE leads ADD COLUMN provider_socials TEXT",
    },
    {
      name: "contact_name",
      ddl: "ALTER TABLE leads ADD COLUMN contact_name TEXT",
    },
    // No foreign key to intake_sites: deleting a site must not cascade into the
    // customer's pipeline, and SQLite cannot add a constraint to an existing
    // table anyway — so the reference is by value and readers tolerate a dangling
    // one, which is exactly what a deleted site leaves behind.
    {
      name: "intake_site",
      ddl: "ALTER TABLE leads ADD COLUMN intake_site TEXT",
    },
    // Left NULL on existing rows rather than backfilled to 'BR'. Every reader
    // already reads NULL as Brazil, and a backfill would state as a fact
    // something we only inferred from when the row was written.
    { name: "country", ddl: "ALTER TABLE leads ADD COLUMN country TEXT" },
    // Left NULL on every existing row, and deliberately not backfilled from the
    // call log. A backfill would be a guess with real consequences — it would
    // lock every lead in the history to whoever last happened to dial it,
    // including leads dialled once by someone who has since left. Ownership
    // starts being recorded from the first contact after this ships; everything
    // before it stays open to whoever picks it up.
    { name: "owner_id", ddl: "ALTER TABLE leads ADD COLUMN owner_id TEXT" },
    { name: "owner_name", ddl: "ALTER TABLE leads ADD COLUMN owner_name TEXT" },
    { name: "owned_at", ddl: "ALTER TABLE leads ADD COLUMN owned_at TEXT" },
  ];

  let addedSearchNorm = false;
  let addedFunnel = false;
  let addedInFunnel = false;
  let addedPhoneNorm = false;
  for (const col of additive) {
    if (existing.has(col.name)) continue;
    handle.exec(col.ddl);
    if (col.name === "search_norm") addedSearchNorm = true;
    if (col.name === "funnel_stage") addedFunnel = true;
    if (col.name === "in_funnel") addedInFunnel = true;
    if (col.name === "phone_norm") addedPhoneNorm = true;
  }

  // Same reasoning as search_norm below: a column added after the fact is NULL
  // on every existing row, and every phone-quality check reads it — so without
  // the backfill an established database reports its whole history as having no
  // usable number.
  if (addedPhoneNorm) {
    const rows = handle
      .prepare(
        "SELECT id, phone, country FROM leads WHERE phone IS NOT NULL AND phone != ''",
      )
      .all() as { id: string; phone: string; country: string | null }[];
    const update = handle.prepare(
      "UPDATE leads SET phone_norm = ? WHERE id = ?",
    );
    handle.exec("BEGIN");
    try {
      for (const r of rows)
        update.run(normalisePhone(r.phone, r.country), r.id);
      handle.exec("COMMIT");
    } catch (err) {
      handle.exec("ROLLBACK");
      throw err;
    }
  }

  // Every existing row would otherwise sit at 'descoberta' regardless of the
  // outreach already recorded against it — a database where the pipeline says
  // nobody has been contacted and the status column says otherwise. The two
  // fields are meant to agree, so the new one starts from the old one.
  if (addedFunnel) {
    handle.exec(`
      UPDATE leads SET funnel_stage = CASE status
        WHEN 'contatado'  THEN 'contato'
        WHEN 'respondeu'  THEN 'qualificado'
        WHEN 'cliente'    THEN 'fechado'
        WHEN 'descartado' THEN 'perdido'
        ELSE 'descoberta'
      END
    `);
  }

  // Preserve the board people had before membership became explicit. This is
  // a one-time migration only; new calls and messages do not add cards.
  if (addedInFunnel) {
    handle.exec(`
      UPDATE leads
         SET in_funnel = 1
       WHERE contacted_at IS NOT NULL OR funnel_stage != 'descoberta'
    `);
  }

  // A column added after the fact is NULL on every existing row, which would
  // quietly hide all your older leads from free-text search. Fill it in once.
  if (addedSearchNorm) {
    const rows = handle
      .prepare("SELECT id, name, address FROM leads")
      .all() as { id: string; name: string; address: string | null }[];
    const update = handle.prepare(
      "UPDATE leads SET search_norm = ? WHERE id = ?",
    );
    handle.exec("BEGIN");
    try {
      for (const r of rows) {
        update.run(normalise(`${r.name} ${r.address ?? ""}`), r.id);
      }
      handle.exec("COMMIT");
    } catch (err) {
      handle.exec("ROLLBACK");
      throw err;
    }
  }
}

/** One additive column on any table, applied only when it is missing. */
function addMissingColumn(
  handle: DatabaseSync,
  table: string,
  column: string,
  ddl: string,
): void {
  const existing = (
    handle.prepare(`PRAGMA table_info(${table})`).all() as { name: string }[]
  ).map((c) => c.name);
  if (!existing.includes(column)) handle.exec(ddl);
}

/**
 * Re-derives every stored `niche` from the lead's category when the niche
 * vocabulary has changed since the database was last written.
 *
 * Without this, splitting or renaming a niche leaves the history full of slugs
 * that no longer exist — the filter offers "barbearias" while the rows still say
 * "barbearias-saloes", so a niche you have hundreds of leads in reads as empty.
 * Since the category is stored on every row and the mapping is now one-to-one,
 * the correct value can always be recomputed rather than guessed at.
 */
function reniche(handle: DatabaseSync): void {
  const KEY = "niche_fingerprint";
  const current = nicheFingerprint();

  const stored = handle
    .prepare("SELECT value FROM meta WHERE key = ?")
    .get(KEY) as { value: string } | undefined;
  if (stored?.value === current) return;

  const categories = handle
    .prepare("SELECT DISTINCT category FROM leads WHERE category IS NOT NULL")
    .all() as { category: string }[];

  handle.exec("BEGIN");
  try {
    // One UPDATE per category rather than per row: a city search stores up to
    // 1.000 rows but there are only ~55 categories in total.
    const update = handle.prepare(
      "UPDATE leads SET niche = ? WHERE category = ? AND niche IS NOT ?",
    );
    for (const { category } of categories) {
      const slug = nicheForCategory(category);
      if (slug) update.run(slug, category, slug);
    }
    handle
      .prepare(
        "INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
      )
      .run(KEY, current);
    handle.exec("COMMIT");
  } catch (err) {
    handle.exec("ROLLBACK");
    throw err;
  }
}

type DuplicateLead = {
  id: string;
  source: string;
  status: string;
  funnel_stage: string;
  socials: string | null;
  contact_name: string | null;
  notes: string | null;
  contacted_at: string | null;
  next_follow_up_at: string | null;
  first_seen_at: string;
  last_seen_at: string;
};

/**
 * Collapse legacy cross-provider copies of the same business.
 *
 * Provider ids are unique, but a business surfaced by both Overture and OSM
 * used to have two ids.  We deliberately require the same normalised name,
 * address, city, and state: matching on a name alone could merge branches with
 * the same brand name.  All user-entered CRM work is moved to the survivor
 * before the redundant rows are deleted.
 */
function deduplicateHistoricalLeads(handle: DatabaseSync): void {
  const KEY = "lead_deduplication_v1";
  if (
    handle.prepare("SELECT 1 FROM meta WHERE key = ?").get(KEY) !== undefined
  ) {
    return;
  }

  const groups = handle
    .prepare(
      `SELECT search_norm, city, uf
       FROM leads
       WHERE search_norm IS NOT NULL AND search_norm <> ''
         AND city IS NOT NULL AND city <> ''
         AND uf IS NOT NULL AND uf <> ''
       GROUP BY search_norm, city, uf
       HAVING count(*) > 1`,
    )
    .all() as { search_norm: string; city: string; uf: string }[];

  const select = handle.prepare(
    `SELECT id, source, status, funnel_stage, socials, contact_name, notes,
            contacted_at, next_follow_up_at, first_seen_at, last_seen_at
     FROM leads WHERE search_norm = ? AND city = ? AND uf = ?`,
  );
  const update = handle.prepare(
    `UPDATE leads SET status = ?, funnel_stage = ?, socials = ?,
            contact_name = ?, notes = ?, contacted_at = ?, next_follow_up_at = ?,
            first_seen_at = ?, last_seen_at = ? WHERE id = ?`,
  );
  const remove = handle.prepare("DELETE FROM leads WHERE id = ?");

  let removed = 0;
  handle.exec("BEGIN");
  try {
    for (const group of groups) {
      const rows = select.all(
        group.search_norm,
        group.city,
        group.uf,
      ) as DuplicateLead[];
      if (rows.length < 2) continue;

      // Keep the record with the most advanced CRM state; prefer Overture on a
      // tie so subsequent provider refreshes keep updating the retained id.
      const ranked = [...rows].sort(
        (a, b) => leadPriority(b) - leadPriority(a),
      );
      const survivor = ranked[0];
      const mergedNotes =
        uniqueText(rows.map((row) => row.notes)).join("\n\n---\n\n") || null;
      const mergedSocials = mergeSocials(
        rows.map((row) => row.socials),
        survivor.socials,
      );
      const contactedAt = earliest(rows.map((row) => row.contacted_at));
      const followUpAt = earliest(rows.map((row) => row.next_follow_up_at));
      const firstSeenAt =
        earliest(rows.map((row) => row.first_seen_at)) ??
        survivor.first_seen_at;
      const lastSeenAt =
        latest(rows.map((row) => row.last_seen_at)) ?? survivor.last_seen_at;
      const contactName =
        rows.find((row) => row.contact_name?.trim())?.contact_name ?? null;

      update.run(
        survivor.status,
        survivor.funnel_stage,
        mergedSocials,
        contactName,
        mergedNotes,
        contactedAt,
        followUpAt,
        firstSeenAt,
        lastSeenAt,
        survivor.id,
      );
      for (const row of rows) {
        if (row.id === survivor.id) continue;
        remove.run(row.id);
        removed += 1;
      }
    }
    handle
      .prepare("INSERT INTO meta (key, value) VALUES (?, ?)")
      .run(KEY, String(removed));
    handle.exec("COMMIT");
  } catch (err) {
    handle.exec("ROLLBACK");
    throw err;
  }

  if (removed > 0)
    console.info(
      JSON.stringify({
        service: "prospector",
        event: "leads.deduplicated",
        removed,
      }),
    );
}

function leadPriority(lead: DuplicateLead): number {
  const status =
    { novo: 0, descartado: 1, contatado: 2, respondeu: 3, cliente: 4 }[
      lead.status
    ] ?? 0;
  const funnel =
    {
      descoberta: 0,
      perdido: 1,
      contato: 2,
      qualificado: 3,
      proposta: 4,
      negociacao: 5,
      fechado: 6,
    }[lead.funnel_stage] ?? 0;
  const manual =
    Number(Boolean(lead.notes?.trim())) +
    Number(Boolean(lead.contact_name?.trim())) +
    Number(Boolean(lead.contacted_at));
  return (
    status * 100 +
    funnel * 10 +
    manual +
    Number(lead.source === "overture") / 10
  );
}

function uniqueText(values: (string | null)[]): string[] {
  return [
    ...new Set(
      values
        .map((value) => value?.trim())
        .filter((value): value is string => Boolean(value)),
    ),
  ];
}

function earliest(values: (string | null)[]): string | null {
  const present = values.filter((value): value is string => Boolean(value));
  return present.length ? present.sort()[0] : null;
}

function latest(values: (string | null)[]): string | null {
  const present = values.filter((value): value is string => Boolean(value));
  return present.length ? (present.sort().at(-1) ?? null) : null;
}

function mergeSocials(
  values: (string | null)[],
  fallback: string | null,
): string | null {
  const links = new Map<string, unknown>();
  for (const value of values) {
    if (!value) continue;
    try {
      const parsed = JSON.parse(value) as unknown;
      if (!Array.isArray(parsed)) continue;
      for (const link of parsed) {
        if (
          link &&
          typeof link === "object" &&
          "url" in link &&
          typeof link.url === "string"
        ) {
          links.set(link.url, link);
        }
      }
    } catch {
      // Preserve a malformed legacy value on the selected survivor rather than
      // making a cleanup migration silently discard it.
    }
  }
  return links.size ? JSON.stringify([...links.values()]) : fallback;
}

export type PersistMeta = {
  niche: string;
  city: string;
  uf: string;
  /** ISO-3166 alpha-2 of the country the search ran in. */
  country: string;
};

export type PersistResult = {
  inserted: number;
  alreadyKnown: number;
  /** Ids not previously in the database, so the board can mark them. */
  newIds: string[];
};

/**
 * Upsert a batch of leads, reporting which were new.
 *
 * `first_seen_at` is deliberately never overwritten — it is the whole point of
 * keeping history. Everything else is refreshed, because a business that has
 * since published a website or changed its phone should update rather than
 * linger at whatever it looked like the first time it was seen.
 *
 * Returns null on failure rather than throwing: a database problem should cost
 * you the new-vs-seen badges, not the search results you just waited for.
 */
export function persistLeads(
  leads: ScoredLead[],
  meta: PersistMeta,
): { result: PersistResult | null; warning?: string } {
  if (leads.length === 0) {
    return { result: { inserted: 0, alreadyKnown: 0, newIds: [] } };
  }

  try {
    const handle = getDb();

    // Read the existing ids before writing, since the upsert destroys the
    // distinction. Chunked to stay well under SQLite's variable limit (999 by
    // default) — a city search returns up to 1.000 rows.
    const known = new Set<string>();
    for (let i = 0; i < leads.length; i += 500) {
      const chunk = leads.slice(i, i + 500);
      const holes = chunk.map(() => "?").join(",");
      const rows = handle
        .prepare(`SELECT id FROM leads WHERE id IN (${holes})`)
        .all(...chunk.map((l) => l.id)) as { id: string }[];
      for (const row of rows) known.add(row.id);
    }

    const assignments = COLUMNS.filter((c) => c !== "id")
      .map((c) => `${c} = excluded.${c}`)
      .join(", ");

    const upsert = handle.prepare(`
      INSERT INTO leads (${COLUMNS.join(", ")})
      VALUES (${COLUMNS.map(() => "?").join(", ")})
      ON CONFLICT(id) DO UPDATE SET
        ${assignments},
        last_seen_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
    `);

    // One transaction for the batch. Committing per row would fsync per row and
    // turn a 10ms write into seconds.
    handle.exec("BEGIN");
    try {
      for (const l of leads) {
        upsert.run(
          l.id,
          l.source ?? "overture",
          l.name,
          l.category,
          l.address,
          l.city,
          l.uf,
          // The lead's own country when the source set one, else the search's.
          // They only differ for a row that predates the column.
          l.country ?? meta.country,
          l.phone,
          normalisePhone(l.phone, l.country ?? meta.country),
          l.website,
          l.social,
          l.socialLinks?.length ? JSON.stringify(l.socialLinks) : null,
          l.email,
          l.lat,
          l.lon,
          l.confidence,
          l.score,
          // SQLite has no boolean type; store the integer the column expects.
          l.whatsapp ? 1 : 0,
          // Derived from the business's own category, not from meta.niche. The
          // search's niche made this depend on which search ran last, so a lead
          // could change niche just by being found again.
          nicheForCategory(l.category) ?? meta.niche,
          meta.city,
          meta.uf,
          normalise(`${l.name} ${l.address ?? ""}`),
        );
      }
      handle.exec("COMMIT");
    } catch (err) {
      handle.exec("ROLLBACK");
      throw err;
    }

    const newIds = leads.map((l) => l.id).filter((id) => !known.has(id));
    return {
      result: {
        inserted: newIds.length,
        alreadyKnown: known.size,
        newIds,
      },
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return {
      result: null,
      warning: `Não foi possível salvar o histórico: ${message}`,
    };
  }
}

/** How much history exists, for the header. */
export function historyCount(): number {
  try {
    const row = getDb().prepare("SELECT count(*) AS n FROM leads").get() as
      { n: number } | undefined;
    return Number(row?.n ?? 0);
  } catch {
    return 0;
  }
}

export type SearchActor = {
  id: string;
  username: string;
  displayName: string;
};

/** Records a completed use of the local-business prospector for the admin audit. */
export function recordProspectorSearch(input: {
  actor: SearchActor;
  niche: string;
  city: string;
  uf: string;
  country?: string;
  matched: number;
  returned: number;
  inserted: number;
}): void {
  try {
    const country = input.country ?? "BR";
    getDb()
      .prepare(
        `INSERT INTO prospector_searches
          (actor_id, actor_username, actor_display_name, niche, city, uf, country, matched, returned, inserted)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        input.actor.id,
        input.actor.username,
        input.actor.displayName,
        input.niche,
        input.city,
        input.uf,
        country,
        input.matched,
        input.returned,
        input.inserted,
      );
    // "Lisboa/" reads as a broken record; outside Brazil there is often no
    // region code to print, so the country stands in for it.
    const where = input.uf ? `${input.city}/${input.uf}` : input.city;
    recordProspectorActivity({
      actor: input.actor,
      action: "search",
      detail: `${input.niche} em ${where} (${country}) · ${input.returned} retornados`,
    });
  } catch (error) {
    // Audit data must never make a completed search look like it failed.
    console.error("Could not record prospector search activity", error);
  }
}

export type ProspectorActivityAction =
  | "search"
  | "outreach"
  | "status"
  | "funnel"
  | "contact"
  | "socials"
  | "tags"
  | "notes"
  | "follow_up"
  | "call"
  | "call_list"
  // The outreach copy itself, edited on /admin/mensagens. Its own action and
  // not "notes": that one is about one business, and this changes the message
  // every business receives from now on — which is the single widest-reaching
  // thing an operator can do here, and the one an admin most needs to see.
  | "mensagem"
  // Who a lead belongs to, changed by hand. Its own action rather than reusing
  // "outreach": that one is counted as `leadsContacted` in operatorOutcomes, and
  // an admin handing a lead back would register as the admin having contacted
  // the business.
  | "atendimento"
  | "intake"
  | "delete";

/**
 * The list and its labels sit next to the union so the three cannot drift. The
 * admin's filter renders from ACTIVITY_ACTIONS, so an action added to the union
 * and not to the list is invisible rather than merely unlabelled — which is the
 * failure you notice.
 */
export const ACTIVITY_ACTIONS: ProspectorActivityAction[] = [
  "search",
  "outreach",
  "status",
  "funnel",
  "contact",
  "socials",
  "tags",
  "notes",
  "follow_up",
  "call",
  "call_list",
  "mensagem",
  "atendimento",
  "intake",
  "delete",
];

export const ACTIVITY_LABEL: Record<ProspectorActivityAction, string> = {
  search: "Busca",
  outreach: "Contato WhatsApp",
  status: "Situação",
  funnel: "Etapa do funil",
  contact: "Dados de contato",
  socials: "Redes sociais",
  tags: "Etiquetas",
  notes: "Anotação",
  follow_up: "Follow-up",
  call: "Ligação",
  call_list: "Lista de ligações",
  mensagem: "Mensagem de abordagem",
  atendimento: "Atendimento do lead",
  intake: "Lead do site",
  delete: "Exclusão",
};

export function isActivityAction(
  value: unknown,
): value is ProspectorActivityAction {
  return (
    typeof value === "string" &&
    ACTIVITY_ACTIONS.includes(value as ProspectorActivityAction)
  );
}

export function recordProspectorActivity(input: {
  actor: SearchActor;
  action: ProspectorActivityAction;
  leadId?: string;
  detail?: string;
}): void {
  try {
    const handle = getDb();
    const lead = input.leadId
      ? (handle
          .prepare("SELECT name, city, uf FROM leads WHERE id = ?")
          .get(input.leadId) as
          { name: string; city: string | null; uf: string | null } | undefined)
      : undefined;
    handle
      .prepare(
        `INSERT INTO prospector_activity
          (actor_id, actor_username, actor_display_name, action, lead_id, lead_name, lead_city, lead_uf, detail)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        input.actor.id,
        input.actor.username,
        input.actor.displayName,
        input.action,
        input.leadId ?? null,
        lead?.name ?? null,
        lead?.city ?? null,
        lead?.uf ?? null,
        input.detail ?? null,
      );
  } catch (error) {
    console.error("Could not record prospector activity", error);
  }
}

export type ProspectorActivity = {
  id: number;
  actorId: string;
  username: string;
  displayName: string;
  action: ProspectorActivityAction;
  leadName: string | null;
  leadCity: string | null;
  leadUf: string | null;
  detail: string | null;
  occurredAt: string;
};

export type ActivityFilters = {
  actorId?: string;
  action?: ProspectorActivityAction;
  /** Inclusive local calendar dates, YYYY-MM-DD, as typed into a date input. */
  from?: string;
  to?: string;
  page: number;
  pageSize: number;
};

export type ActivityPage = {
  rows: ProspectorActivity[];
  total: number;
  page: number;
  pageSize: number;
  pages: number;
};

/**
 * The audit trail, filtered.
 *
 * Dates are compared as local calendar days on both sides — `occurred_at` is
 * UTC and the admin's "3 de agosto" is a São Paulo day, so reading the stored
 * timestamp as a plain prefix would file an evening's work under tomorrow. The
 * "today" counters elsewhere in this file fold the same way for the same reason.
 */
function activityWhere(f: {
  actorId?: string;
  action?: ProspectorActivityAction;
  from?: string;
  to?: string;
}): { sql: string; params: (string | number)[] } {
  const clauses: string[] = [];
  const params: (string | number)[] = [];

  if (f.actorId) {
    clauses.push("actor_id = ?");
    params.push(f.actorId);
  }
  if (f.action) {
    clauses.push("action = ?");
    params.push(f.action);
  }
  if (f.from) {
    clauses.push("date(occurred_at, 'localtime') >= date(?)");
    params.push(f.from);
  }
  if (f.to) {
    clauses.push("date(occurred_at, 'localtime') <= date(?)");
    params.push(f.to);
  }

  return {
    sql: clauses.length ? `WHERE ${clauses.join(" AND ")}` : "",
    params,
  };
}

type ActivityRow = {
  id: number;
  actor_id: string;
  actor_username: string;
  actor_display_name: string;
  action: ProspectorActivityAction;
  lead_name: string | null;
  lead_city: string | null;
  lead_uf: string | null;
  detail: string | null;
  occurred_at: string;
};

const ACTIVITY_SELECT = `id, actor_id, actor_username, actor_display_name,
   action, lead_name, lead_city, lead_uf, detail, occurred_at`;

function toActivity(row: ActivityRow): ProspectorActivity {
  return {
    id: row.id,
    actorId: row.actor_id,
    username: row.actor_username,
    displayName: row.actor_display_name,
    action: row.action,
    leadName: row.lead_name,
    leadCity: row.lead_city,
    leadUf: row.lead_uf,
    detail: row.detail,
    occurredAt: row.occurred_at,
  };
}

export function activityFeed(f: ActivityFilters): ActivityPage {
  const handle = getDb();
  const { sql, params } = activityWhere(f);

  const total = Number(
    (
      handle
        .prepare(`SELECT count(*) AS n FROM prospector_activity ${sql}`)
        .get(...params) as { n: number } | undefined
    )?.n ?? 0,
  );

  const pageSize = clamp(f.pageSize, 10, 200);
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const page = clamp(f.page, 1, pages);

  const rows = handle
    .prepare(
      `SELECT ${ACTIVITY_SELECT}
       FROM prospector_activity ${sql}
       ORDER BY occurred_at DESC, id DESC
       LIMIT ? OFFSET ?`,
    )
    .all(...params, pageSize, (page - 1) * pageSize) as ActivityRow[];

  return { rows: rows.map(toActivity), total, page, pageSize, pages };
}

/**
 * Every matching row, for the CSV. Capped rather than unbounded: the audit grows
 * forever and a year of it in one synchronous read would block the process, so
 * the export is the most recent 20.000 events of whatever was filtered.
 */
export const ACTIVITY_EXPORT_CAP = 20_000;

export function allActivity(f: {
  actorId?: string;
  action?: ProspectorActivityAction;
  from?: string;
  to?: string;
}): ProspectorActivity[] {
  const { sql, params } = activityWhere(f);
  const rows = getDb()
    .prepare(
      `SELECT ${ACTIVITY_SELECT}
       FROM prospector_activity ${sql}
       ORDER BY occurred_at DESC, id DESC
       LIMIT ${ACTIVITY_EXPORT_CAP}`,
    )
    .all(...params) as ActivityRow[];
  return rows.map(toActivity);
}

function clamp(value: number, lo: number, hi: number): number {
  if (!Number.isFinite(value)) return lo;
  return Math.min(hi, Math.max(lo, Math.trunc(value)));
}

export type ProspectorUsage = {
  actorId: string;
  username: string;
  displayName: string;
  searches: number;
  searchesToday: number;
  leadsReturned: number;
  leadsInserted: number;
  lastSearchAt: string | null;
};

export type ProspectorSearchActivity = {
  id: number;
  username: string;
  displayName: string;
  niche: string;
  city: string;
  uf: string;
  matched: number;
  returned: number;
  inserted: number;
  searchedAt: string;
};

/** Per-user totals plus the latest searches, used only by the admin usage view. */
export function prospectorUsage(actorId?: string): {
  totals: { searches: number; searchesToday: number; leadsReturned: number };
  byUser: ProspectorUsage[];
  recent: ProspectorSearchActivity[];
} {
  const handle = getDb();
  const where = actorId ? "WHERE actor_id = ?" : "";
  const values = actorId ? [actorId] : [];
  const totals = handle
    .prepare(
      `SELECT count(*) AS searches,
              coalesce(sum(CASE WHEN date(searched_at, 'localtime') = date('now', 'localtime') THEN 1 ELSE 0 END), 0) AS searches_today,
              coalesce(sum(returned), 0) AS leads_returned
       FROM prospector_searches ${where}`,
    )
    .get(...values) as {
    searches: number;
    searches_today: number;
    leads_returned: number;
  };
  const byUser = handle
    .prepare(
      `SELECT actor_id, actor_username, actor_display_name,
              count(*) AS searches,
              sum(CASE WHEN date(searched_at, 'localtime') = date('now', 'localtime') THEN 1 ELSE 0 END) AS searches_today,
              coalesce(sum(returned), 0) AS leads_returned,
              coalesce(sum(inserted), 0) AS leads_inserted,
              max(searched_at) AS last_search_at
       FROM prospector_searches ${where}
       GROUP BY actor_id, actor_username, actor_display_name
       ORDER BY searches DESC, last_search_at DESC`,
    )
    .all(...values) as {
    actor_id: string;
    actor_username: string;
    actor_display_name: string;
    searches: number;
    searches_today: number;
    leads_returned: number;
    leads_inserted: number;
    last_search_at: string | null;
  }[];
  const recent = handle
    .prepare(
      `SELECT id, actor_username, actor_display_name, niche, city, uf, matched, returned, inserted, searched_at
       FROM prospector_searches ${where} ORDER BY searched_at DESC LIMIT 20`,
    )
    .all(...values) as {
    id: number;
    actor_username: string;
    actor_display_name: string;
    niche: string;
    city: string;
    uf: string;
    matched: number;
    returned: number;
    inserted: number;
    searched_at: string;
  }[];

  return {
    totals: {
      searches: Number(totals.searches),
      searchesToday: Number(totals.searches_today),
      leadsReturned: Number(totals.leads_returned),
    },
    byUser: byUser.map((row) => ({
      actorId: row.actor_id,
      username: row.actor_username,
      displayName: row.actor_display_name,
      searches: Number(row.searches),
      searchesToday: Number(row.searches_today),
      leadsReturned: Number(row.leads_returned),
      leadsInserted: Number(row.leads_inserted),
      lastSearchAt: row.last_search_at,
    })),
    recent: recent.map((row) => ({
      id: row.id,
      username: row.actor_username,
      displayName: row.actor_display_name,
      niche: row.niche,
      city: row.city,
      uf: row.uf,
      matched: row.matched,
      returned: row.returned,
      inserted: row.inserted,
      searchedAt: row.searched_at,
    })),
  };
}

/**
 * Every actor the audit has ever seen, with the labels it captured at the time.
 *
 * The union matters: an operator who only ever worked leads someone else found
 * has no row in `prospector_searches` at all, and reading the actor list from
 * that table alone made their whole history unreachable from the admin's filter.
 */
export function knownActors(): {
  actorId: string;
  username: string;
  displayName: string;
  lastSeenAt: string | null;
}[] {
  const rows = getDb()
    .prepare(
      `SELECT actor_id, actor_username, actor_display_name, max(seen_at) AS last_seen_at
       FROM (
         SELECT actor_id, actor_username, actor_display_name, occurred_at AS seen_at
           FROM prospector_activity
         UNION ALL
         SELECT actor_id, actor_username, actor_display_name, searched_at AS seen_at
           FROM prospector_searches
       )
       GROUP BY actor_id
       ORDER BY last_seen_at DESC`,
    )
    .all() as {
    actor_id: string;
    actor_username: string;
    actor_display_name: string;
    last_seen_at: string | null;
  }[];
  return rows.map((row) => ({
    actorId: row.actor_id,
    username: row.actor_username,
    displayName: row.actor_display_name,
    lastSeenAt: row.last_seen_at,
  }));
}

/* -------------------------------------------------------------------------- */
/* What the operator actually achieved                                         */
/* -------------------------------------------------------------------------- */

/**
 * Usage answers "did they use the tool". This answers "did it come to
 * anything" — and they are different questions about the same person: an
 * operator can run fifty searches a week and close nothing, which the searches
 * column alone reports as their best week.
 *
 * Attribution is by *touch*, not ownership: a lead counts for everyone who
 * acted on it. There is no owner column on `leads` and inventing one would be a
 * bigger change than this needs, but it does mean two people who worked the same
 * deal both see it in their column. The admin screen says so; without that note
 * the totals look like they should add up to the pipeline, and they don't.
 */
export type OperatorOutcomes = {
  actorId: string;
  /** Distinct leads this operator did anything to, excluding plain searches. */
  leadsWorked: number;
  /** Distinct leads they opened a WhatsApp conversation with. */
  leadsContacted: number;
  /** Of the leads they touched, how many now sit in each end state. */
  leadsWon: number;
  leadsLost: number;
  leadsOpen: number;
  /** Live leads of theirs whose follow-up date has already passed. */
  followUpsOverdue: number;
  /** Live leads of theirs due today or earlier — the overdue ones included. */
  followUpsDue: number;
  actionsTotal: number;
  actionsToday: number;
  lastActivityAt: string | null;
};

/** The stages that mean a conversation is live. `fechado`/`perdido` are ends. */
const LIVE_STAGE_SQL = `('contato','qualificado','proposta','negociacao')`;

export function operatorOutcomes(actorId?: string): OperatorOutcomes[] {
  const handle = getDb();
  const where = actorId ? "WHERE a.actor_id = ?" : "";
  const values = actorId ? [actorId] : [];

  // Two passes rather than one: the lead-derived numbers need the join and
  // therefore drop searches (lead_id IS NULL), while the raw action counts must
  // keep them. Doing both in one query means every action count is silently a
  // count of non-search actions instead.
  const worked = handle
    .prepare(
      `SELECT a.actor_id,
              count(DISTINCT a.lead_id) AS leads_worked,
              count(DISTINCT CASE WHEN a.action = 'outreach' THEN a.lead_id END) AS leads_contacted,
              count(DISTINCT CASE WHEN l.funnel_stage = 'fechado' THEN a.lead_id END) AS leads_won,
              count(DISTINCT CASE WHEN l.funnel_stage = 'perdido' THEN a.lead_id END) AS leads_lost,
              count(DISTINCT CASE WHEN l.funnel_stage IN ${LIVE_STAGE_SQL} THEN a.lead_id END) AS leads_open,
              count(DISTINCT CASE WHEN l.funnel_stage IN ${LIVE_STAGE_SQL}
                                   AND l.next_follow_up_at IS NOT NULL
                                   AND l.next_follow_up_at < date('now', 'localtime')
                                  THEN a.lead_id END) AS follow_ups_overdue,
              count(DISTINCT CASE WHEN l.funnel_stage IN ${LIVE_STAGE_SQL}
                                   AND l.next_follow_up_at IS NOT NULL
                                   AND l.next_follow_up_at <= date('now', 'localtime')
                                  THEN a.lead_id END) AS follow_ups_due
       FROM prospector_activity a
       JOIN leads l ON l.id = a.lead_id
       ${where}
       GROUP BY a.actor_id`,
    )
    .all(...values) as {
    actor_id: string;
    leads_worked: number;
    leads_contacted: number;
    leads_won: number;
    leads_lost: number;
    leads_open: number;
    follow_ups_overdue: number;
    follow_ups_due: number;
  }[];

  const actions = handle
    .prepare(
      `SELECT a.actor_id,
              count(*) AS actions_total,
              coalesce(sum(CASE WHEN date(a.occurred_at, 'localtime') = date('now', 'localtime') THEN 1 ELSE 0 END), 0) AS actions_today,
              max(a.occurred_at) AS last_activity_at
       FROM prospector_activity a
       ${where}
       GROUP BY a.actor_id`,
    )
    .all(...values) as {
    actor_id: string;
    actions_total: number;
    actions_today: number;
    last_activity_at: string | null;
  }[];

  const byActor = new Map(worked.map((row) => [row.actor_id, row]));

  // Driven by the action counts, not the join: someone who has only ever run
  // searches has no row in `worked` and still needs to appear.
  return actions.map((row) => {
    const lead = byActor.get(row.actor_id);
    return {
      actorId: row.actor_id,
      leadsWorked: Number(lead?.leads_worked ?? 0),
      leadsContacted: Number(lead?.leads_contacted ?? 0),
      leadsWon: Number(lead?.leads_won ?? 0),
      leadsLost: Number(lead?.leads_lost ?? 0),
      leadsOpen: Number(lead?.leads_open ?? 0),
      followUpsOverdue: Number(lead?.follow_ups_overdue ?? 0),
      followUpsDue: Number(lead?.follow_ups_due ?? 0),
      actionsTotal: Number(row.actions_total),
      actionsToday: Number(row.actions_today),
      lastActivityAt: row.last_activity_at,
    };
  });
}

export const EMPTY_OUTCOMES = (actorId: string): OperatorOutcomes => ({
  actorId,
  leadsWorked: 0,
  leadsContacted: 0,
  leadsWon: 0,
  leadsLost: 0,
  leadsOpen: 0,
  followUpsOverdue: 0,
  followUpsDue: 0,
  actionsTotal: 0,
  actionsToday: 0,
  lastActivityAt: null,
});

/** One row of an operator's work queue, for the accountability lists. */
export type OperatorLead = {
  id: string;
  name: string;
  city: string | null;
  uf: string | null;
  funnelStage: string;
  status: string;
  phone: string | null;
  nextFollowUpAt: string | null;
  /**
   * Whether that date has passed — decided in SQL, not recomputed in the page.
   *
   * The counter beside these lists folds `date('now','localtime')`, so a page
   * that asked JavaScript the same question would answer it in whatever
   * timezone the renderer thinks it is in. On a container that isn't on
   * Brasília time the two differ by a day, and the list and the number above it
   * then disagree about the same lead.
   */
  followUpOverdue: boolean;
  /** When this operator last did anything to it — not when anyone last did. */
  lastTouchedAt: string;
};

type OperatorLeadRow = {
  id: string;
  name: string;
  city: string | null;
  uf: string | null;
  funnel_stage: string;
  status: string;
  phone: string | null;
  next_follow_up_at: string | null;
  follow_up_overdue: number;
  last_touched_at: string;
};

const toOperatorLead = (row: OperatorLeadRow): OperatorLead => ({
  id: row.id,
  name: row.name,
  city: row.city,
  uf: row.uf,
  funnelStage: row.funnel_stage,
  status: row.status,
  phone: row.phone,
  nextFollowUpAt: row.next_follow_up_at,
  followUpOverdue: row.follow_up_overdue === 1,
  lastTouchedAt: row.last_touched_at,
});

const OPERATOR_LEAD_SELECT = `l.id, l.name, l.city, l.uf, l.funnel_stage, l.status,
   l.phone, l.next_follow_up_at,
   CASE WHEN l.next_follow_up_at IS NOT NULL
             AND l.next_follow_up_at < date('now', 'localtime')
        THEN 1 ELSE 0 END AS follow_up_overdue,
   max(a.occurred_at) AS last_touched_at`;

/**
 * The follow-ups this operator owes, soonest first.
 *
 * Only live stages: a follow-up date left on a lead that was later closed or
 * discarded is bookkeeping, not a missed commitment, and listing it as one is
 * how an accountability screen loses the reader's trust.
 */
export function operatorFollowUps(actorId: string, limit = 25): OperatorLead[] {
  const rows = getDb()
    .prepare(
      `SELECT ${OPERATOR_LEAD_SELECT}
       FROM leads l
       JOIN prospector_activity a ON a.lead_id = l.id
       WHERE a.actor_id = ?
         AND l.next_follow_up_at IS NOT NULL
         AND l.funnel_stage IN ${LIVE_STAGE_SQL}
       GROUP BY l.id
       ORDER BY l.next_follow_up_at ASC
       LIMIT ?`,
    )
    .all(actorId, limit) as OperatorLeadRow[];
  return rows.map(toOperatorLead);
}

/**
 * Live leads this operator has not come back to in `days`.
 *
 * The quiet failure a follow-up list can't catch: nothing is overdue because
 * nothing was ever scheduled. Measured from *this* operator's last touch, so a
 * deal someone else picked up still shows as dropped by the person who left it.
 */
export function operatorStalled(
  actorId: string,
  days = 7,
  limit = 25,
): OperatorLead[] {
  const rows = getDb()
    .prepare(
      `SELECT ${OPERATOR_LEAD_SELECT}
       FROM leads l
       JOIN prospector_activity a ON a.lead_id = l.id
       WHERE a.actor_id = ?
         AND l.funnel_stage IN ${LIVE_STAGE_SQL}
       GROUP BY l.id
       HAVING julianday('now') - julianday(max(a.occurred_at)) >= ?
       ORDER BY last_touched_at ASC
       LIMIT ?`,
    )
    .all(actorId, days, limit) as OperatorLeadRow[];
  return rows.map(toOperatorLead);
}

/** The leads an operator has moved most recently, for the per-operator page. */
export function operatorRecentLeads(
  actorId: string,
  limit = 15,
): OperatorLead[] {
  const rows = getDb()
    .prepare(
      `SELECT ${OPERATOR_LEAD_SELECT}
       FROM leads l
       JOIN prospector_activity a ON a.lead_id = l.id
       WHERE a.actor_id = ?
       GROUP BY l.id
       ORDER BY last_touched_at DESC
       LIMIT ?`,
    )
    .all(actorId, limit) as OperatorLeadRow[];
  return rows.map(toOperatorLead);
}

export type { Lead };
