import type { City } from "./cities";
import type { Lead, SocialLink } from "./types";

/**
 * Optional commercial directory. Geoapify's Places API is deliberately behind
 * an environment key: it adds an independent POI index without turning a
 * normal search into a paid dependency.
 */
const CATEGORIES: Record<string, string> = {
  barbearias: "service.beauty.hairdresser",
  "saloes-beleza": "service.beauty",
  manicure: "service.beauty",
  "estetica-spa": "service.beauty",
  tatuagem: "service.beauty.tattoo",
  restaurantes: "catering.restaurant",
  bares: "catering.bar",
  pizzarias: "catering.fast_food.pizza,catering.restaurant",
  hamburguerias: "catering.fast_food.burger",
  padarias: "catering",
  cafeterias: "catering.cafe",
  "sorveterias-sucos": "catering.ice_cream,catering.cafe",
  "culinaria-internacional": "catering",
  odontologia: "healthcare",
  "clinicas-medicas": "healthcare",
  fisioterapia: "healthcare",
  psicologia: "healthcare",
  imobiliarias: "service.estate_agent",
  arquitetura: "service",
  "engenharia-construcao": "service",
  academias: "sport",
  pilates: "sport",
  oficinas: "service",
  "estetica-automotiva": "service",
  concessionarias: "commercial",
  "pet-shops": "commercial",
  veterinarios: "healthcare",
  advocacia: "service",
  contabilidade: "service",
  escolas: "education.school",
  "cursos-idiomas": "education",
  autoescolas: "education",
  "escolas-especializadas": "education",
};

type Feature = {
  id?: string;
  geometry?: { coordinates?: [number, number] };
  properties?: Record<string, unknown>;
};

export function hasGeoapifyKey(): boolean {
  return Boolean(process.env.GEOAPIFY_API_KEY?.trim());
}

export async function queryGeoapify(input: {
  city: City;
  niche: string;
  limit: number;
}): Promise<Lead[]> {
  const apiKey = process.env.GEOAPIFY_API_KEY?.trim();
  const categories = CATEGORIES[input.niche];
  if (!apiKey || !categories) return [];

  const { xmin, xmax, ymin, ymax } = input.city.bbox;
  const params = new URLSearchParams({
    categories,
    filter: `rect:${xmin},${ymin},${xmax},${ymax}`,
    bias: `proximity:${(xmin + xmax) / 2},${(ymin + ymax) / 2}`,
    limit: String(Math.min(input.limit, 500)),
    lang: "pt",
    apiKey,
  });
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 10_000);
  try {
    const response = await fetch(
      `https://api.geoapify.com/v2/places?${params}`,
      {
        signal: controller.signal,
      },
    );
    if (!response.ok) throw new Error(`Geoapify ${response.status}`);
    const payload = (await response.json()) as { features?: Feature[] };
    return (payload.features ?? []).map((feature, index) =>
      toLead(feature, input.city, index),
    );
  } finally {
    clearTimeout(timeout);
  }
}

function toLead(feature: Feature, city: City, index: number): Lead {
  const p = feature.properties ?? {};
  const get = (key: string): string | null => {
    const value = p[key];
    return typeof value === "string" && value.trim() ? value.trim() : null;
  };
  const socialLinks = socials(p);
  const [lon, lat] = feature.geometry?.coordinates ?? [null, null];
  return {
    id: `geoapify:${feature.id ?? `${city.uf}:${city.name}:${index}`}`,
    source: "geoapify",
    name: get("name") ?? "(sem nome)",
    category: get("categories") ?? null,
    address: get("address_line1") ?? get("formatted"),
    city: get("city") ?? city.name,
    uf: get("state_code")?.toUpperCase() ?? city.uf,
    phone: get("phone") ?? get("contact:phone"),
    website: get("website") ?? get("contact:website"),
    social: socialLinks[0]?.url ?? null,
    socialLinks,
    email: get("email") ?? get("contact:email"),
    lat: typeof lat === "number" ? lat : null,
    lon: typeof lon === "number" ? lon : null,
    confidence: 0.75,
  };
}

function socials(properties: Record<string, unknown>): SocialLink[] {
  const platforms = [
    "instagram",
    "facebook",
    "linkedin",
    "tiktok",
    "youtube",
    "telegram",
    "threads",
    "bluesky",
    "pinterest",
    "snapchat",
    "discord",
  ];
  return platforms.flatMap((platform) => {
    const value = properties[platform] ?? properties[`contact:${platform}`];
    if (typeof value !== "string" || !/^https?:\/\//i.test(value)) return [];
    return [{ platform, url: value }];
  });
}
