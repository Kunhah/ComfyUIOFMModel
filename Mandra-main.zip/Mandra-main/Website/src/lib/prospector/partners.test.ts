import assert from "node:assert/strict";
import test from "node:test";
import {
  MARKETING_NAME,
  NICHES,
  allCnaes,
  broadCnaes,
  findNiche,
  intentForCategory,
  nicheForCategory,
  nicheIntent,
  preciseCnaes,
} from "./niches";
import { outreachMessage, scoreAndSort, scoreLead } from "./score";

const lead = (over: Partial<Parameters<typeof scoreLead>[0]> = {}) => ({
  id: "x",
  name: "Agência Norte",
  category: "marketing_agency",
  address: null,
  city: null,
  uf: null,
  country: null,
  phone: null,
  website: null,
  social: null,
  email: null,
  lat: null,
  lon: null,
  confidence: 0.9,
  ...over,
});

test("the parcerias group is the only one that is not a prospect list", () => {
  const partners = NICHES.filter((n) => n.intent === "parceiro");
  assert.ok(partners.length > 0);
  for (const niche of partners) {
    assert.equal(niche.group, "Marketing e parcerias");
  }
  // Everything that was a client niche before parcerias must still be one — an
  // intent typo'd onto a real niche would silently invert its whole ranking.
  for (const niche of NICHES) {
    if (niche.group !== "Marketing e parcerias") {
      assert.equal(nicheIntent(niche.slug), "cliente", niche.slug);
    }
  }
});

test("intent comes from the category, so every caller gets it right unasked", () => {
  assert.equal(intentForCategory("marketing_agency"), "parceiro");
  assert.equal(intentForCategory("internet_marketing_service"), "parceiro");
  assert.equal(intentForCategory("barber"), "cliente");
  // An unmapped category, and a lead with none at all, are what an
  // unclassified business has always been.
  assert.equal(intentForCategory("something_new"), "cliente");
  assert.equal(intentForCategory(null), "cliente");
});

test("a partner is qualified by having a site, a client by lacking one", () => {
  const withSite = lead({ website: "https://agencianorte.com.br" });
  const without = lead({ website: null });

  assert.ok(scoreLead(withSite).score > scoreLead(without).score);
  assert.ok(scoreLead(withSite).reasons.includes("site próprio"));
  assert.ok(scoreLead(without).reasons.includes("sem site próprio"));

  // The same two leads read as a barbershop rank the other way round.
  const barber = { ...withSite, category: "barber" };
  const barberWithout = { ...without, category: "barber" };
  assert.ok(scoreLead(barberWithout).score > scoreLead(barber).score);
});

test("an explicit intent beats the category, for supplementary sources", () => {
  // An OpenStreetMap row carries OSM's vocabulary, not Overture's, so its
  // category maps to nothing and would score as a client.
  const osm = lead({ category: "advertising", website: "https://x.com.br" });
  assert.equal(scoreLead(osm).reasons.includes("site próprio"), false);
  assert.ok(scoreLead(osm, "parceiro").reasons.includes("site próprio"));
  assert.ok(
    scoreAndSort([osm], "parceiro")[0].reasons.includes("site próprio"),
  );
});

test("the partner opener offers a partnership and never a demo", () => {
  const pt = outreachMessage(lead({ country: "BR" }));
  assert.match(pt, /parceria/);
  assert.doesNotMatch(pt, /demonstração/);

  assert.match(outreachMessage(lead({ country: "ES" })), /alianza/);
  // No template for the language falls back to English, never to Portuguese.
  assert.match(outreachMessage(lead({ country: "DE" })), /partnership/);

  // A client niche is untouched by any of this.
  assert.match(
    outreachMessage(lead({ country: "BR", category: "barber" })),
    /captam cliente/,
  );
});

test("the parcerias niches carry the categories the extract is built from", () => {
  const trafego = findNiche("gestores-trafego");
  assert.ok(trafego);
  assert.ok(trafego.categories.includes("internet_marketing_service"));
  // A competitor must not be sold as a partner: see the comment in niches.ts.
  for (const niche of NICHES) {
    assert.equal(niche.categories.includes("web_designer"), false, niche.slug);
  }
});

test("CNAEs and Overture categories share one reverse map and one rule", () => {
  // Both vocabularies resolve, and they cannot collide: seven digits against a
  // lowercase word.
  assert.equal(nicheForCategory("7311400"), "agencias-marketing");
  assert.equal(nicheForCategory("marketing_agency"), "agencias-marketing");
  assert.equal(intentForCategory("7319099"), "parceiro");

  // Every CNAE we ship is unpunctuated and seven digits — the form the
  // Receita's own files carry. "7319-0/99" would match nothing, silently.
  for (const cnae of allCnaes()) assert.match(cnae, /^\d{7}$/);

  // Only parcerias niches carry CNAEs: the register has no website column, and
  // "has no website" is the whole question for a client niche.
  for (const niche of NICHES) {
    if (niche.cnaes || niche.broadCnaes) {
      assert.equal(niche.intent, "parceiro", niche.slug);
    }
  }
});

test("a broad CNAE is never taken whole, a precise one always is", () => {
  // 7319-0/02 measured as 70% of a plain CNAE filter's output and sampled as
  // glaziers and mechanics; it must stay behind the name rule.
  assert.ok(broadCnaes().includes("7319002"));
  assert.equal(preciseCnaes().includes("7319002"), false);
  assert.ok(preciseCnaes().includes("7311400"));

  // The two lists must not overlap, or a code would be both.
  for (const cnae of broadCnaes()) {
    assert.equal(preciseCnaes().includes(cnae), false, cnae);
  }

  // The name rule has to survive folding: it is applied to an unaccented,
  // lowercased string, so an accented alternative in the pattern matches nothing.
  assert.doesNotMatch(MARKETING_NAME, /[áâãéêíóôõúç]/i);
  const fold = (s: string) =>
    s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  const re = new RegExp(MARKETING_NAME);
  for (const name of [
    "2J MÍDIA DIGITAL",
    "TAGHY AGÊNCIA DIGITAL",
    "NOVA BELEM PUBLICIDADE",
  ]) {
    assert.ok(re.test(fold(name)), name);
  }
  for (const name of [
    "OFICINA MECANICA R.N.",
    "OLIVEIRA VIDRACARIA E ENERGIA SOLAR",
  ]) {
    assert.equal(re.test(fold(name)), false, name);
  }
});

test("a register row's blank website means unknown, not absent", () => {
  const registered = lead({
    source: "cnpj" as const,
    category: "7311400",
    website: null,
  });
  const mapped = lead({
    source: "overture" as const,
    category: "marketing_agency",
    website: null,
  });

  // The map says this agency has no site; the register says nothing at all.
  assert.ok(scoreLead(mapped).reasons.includes("sem site próprio"));
  assert.equal(
    scoreLead(registered).reasons.includes("sem site próprio"),
    false,
  );
  assert.ok(scoreLead(registered).reasons.includes("registro ativo"));
  assert.ok(scoreLead(registered).score > scoreLead(mapped).score);

  // But a mapped agency that actually has a site still outranks a register row:
  // we know strictly more about it.
  const withSite = lead({
    source: "overture" as const,
    website: "https://x.com.br",
    social: "https://instagram.com/x",
  });
  assert.ok(scoreLead(withSite).score > scoreLead(registered).score);
});

test("the register's own quirks are what the sync has to clean", () => {
  // These are the exact shapes seen in the 2026-08 files. They are pinned here
  // rather than only in the sync's SQL because each one reaches a human: the
  // name goes on a WhatsApp opener, the e-mail becomes a mailto, and a filler
  // phone becomes a dial. The SQL is the implementation; this is the contract.
  const stripRegistration = (s: string) =>
    s
      .replace(/^[0-9][0-9./-]{9,}\s+/, "")
      .replace(/\s+[0-9]{11}$/, "")
      .trim() || s;

  // A MEI has no trading name: the razão social is the number glued to the
  // person, either in front or behind.
  assert.equal(
    stripRegistration("41.729.911 THAMIRES AMARAL VIEIRA"),
    "THAMIRES AMARAL VIEIRA",
  );
  assert.equal(stripRegistration("EDUARDO BERTI 03738029940"), "EDUARDO BERTI");
  // A real company name that merely starts with a number must survive.
  assert.equal(stripRegistration("2J MIDIA DIGITAL"), "2J MIDIA DIGITAL");
  assert.equal(stripRegistration("NUCLEO 3 PROPAGANDA"), "NUCLEO 3 PROPAGANDA");

  // The e-mail field carries its own label often enough to matter.
  const cleanEmail = (s: string) => {
    const v = s
      .trim()
      .toLowerCase()
      .replace(/^e-?mail\s*:\s*/, "");
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? v : null;
  };
  assert.equal(
    cleanEmail("e-mail: anuncios@uai.com.br"),
    "anuncios@uai.com.br",
  );
  assert.equal(
    cleanEmail("BAG@BagPropaganda.com.br"),
    "bag@bagpropaganda.com.br",
  );
  // Anything not shaped like an address is worse than a blank: a mailto that
  // silently goes nowhere.
  assert.equal(cleanEmail("nao possui"), null);
  assert.equal(cleanEmail(""), null);

  // A repeated digit is never a line — it is what gets typed when the form
  // demands a phone, and it inflates the coverage this source was chosen for.
  const filler = (t: string) =>
    t.replace(new RegExp(t[0] ?? "", "g"), "") === "";
  assert.equal(filler("55555555"), true);
  assert.equal(filler("999999999"), true);
  assert.equal(filler("30252565"), false);
});
