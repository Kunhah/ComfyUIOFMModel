import type { InitialSearch } from "@/components/prospector/prospector";
import { isIndexedCountry } from "./cities";
import { findNiche } from "./niches";
import type { SearchScope } from "./types";

/**
 * A search expressed entirely in the URL — `?niche=pet&city=Manaus&uf=AM` runs
 * on load, which is what makes a lead list shareable and bookmarkable.
 *
 * One parser, shared by `/prospector` and by the `/admin/prospector` mount. It
 * used to be a copy in each, and they drifted exactly the way this codebase
 * already learned that page-local parsers drift: the CRM's copy predated broad
 * searches and still demanded a city, so running a state-wide search there and
 * pressing reload emptied the screen while the address bar still described the
 * search. `filtersToQuery`/`parseFilters` are shared for the same reason.
 *
 * The reader is deliberately the *writer's* counterpart: `runSearch` in
 * prospector.tsx puts `scope` and `region` in the query string, so anything
 * that reads it back has to understand them.
 *
 * Parsing happens on the server rather than from `window.location`, so a shared
 * link arrives with its table already rendered — reading the URL client-side
 * would mean either setting state in an effect (cascading renders) or seeding
 * from `window` (hydration mismatch, since the server render can't see it).
 */
export function parseInitialSearch(
  params: Record<string, string | string[] | undefined>,
): InitialSearch | null {
  const one = (v: string | string[] | undefined): string | undefined =>
    Array.isArray(v) ? v[0] : v;

  const niche = one(params.niche);
  const scopeValue = one(params.scope);
  const scope: SearchScope =
    scopeValue === "state" ||
    scopeValue === "region" ||
    scopeValue === "country"
      ? scopeValue
      : "city";
  const city = one(params.city) ?? "";
  // The state code is optional now: most countries outside Brazil have no
  // usable one in the records, and demanding it would make their links invalid.
  const uf = one(params.uf) ?? "";
  const country = one(params.country)?.toUpperCase();
  const region = one(params.region) ?? "";
  // An unknown niche would search zero categories and look like an empty city.
  if (!niche || !findNiche(niche)) return null;
  if (scope === "city" && !city) return null;
  if (scope === "state" && !uf) return null;
  if (scope === "region" && !region) return null;

  const conf = Number(one(params.conf));
  return {
    niche,
    scope,
    city,
    uf: uf.toUpperCase(),
    region,
    // Links written before the tool left Brazil carry no country and are
    // Brazilian; an unknown one would resolve to no city at all.
    country: country && isIndexedCountry(country) ? country : "BR",
    // ?all=1 includes businesses that already have a site.
    onlyWithoutWebsite: one(params.all) !== "1",
    minConfidence: Number.isFinite(conf) && conf >= 0 && conf <= 1 ? conf : 0.5,
    // ?save=0 runs the search without writing anything to the history.
    save: one(params.save) !== "0",
  };
}
