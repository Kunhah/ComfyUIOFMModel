import { getDb } from "./db";

/**
 * Who may contact a lead — and who may not.
 *
 * Cold outreach has one failure the prospect always notices: being phoned twice
 * by the same company, by two different people, who each open by introducing
 * themselves. It costs the deal and it is invisible from inside, because each
 * operator's own screen looks perfectly normal.
 *
 * The queue already prevented a *slice* of it: `AVAILABLE_SQL` refuses to build
 * an automatic list from leads still pending in somebody else's queue. That
 * leaves two holes, and this module closes both, because they are two different
 * questions:
 *
 *  - **Right now.** Between the dialer opening a lead and the call being logged,
 *    the lead is in nobody's completed set and nothing stops a second operator's
 *    queue from handing it out. That window is a *claim*: a short reservation in
 *    `lead_claims`, taken atomically, renewed while the dialer is open, and
 *    expiring on its own so a closed laptop cannot lock a lead forever.
 *
 *  - **From now on.** Once a contact has actually happened, the relationship
 *    belongs to the person who made it. That is *ownership*: `leads.owner_id`,
 *    stamped by the first logged call or outreach action and never reassigned by
 *    the writer that finds it already set. It has no expiry, because the
 *    prospect's memory of who called them doesn't have one either.
 *
 * Both are enforced in one place, `blockFor()`, which every contact path calls
 * before it writes. The SQL fragments below are the same rule in set form, for
 * the queue builders that must not *offer* what the routes would then refuse.
 *
 * Admins are exempt throughout. They supervise the operators and have to be able
 * to work any lead — and, with `releaseOwnership`, to hand one back when the
 * person who owned it is no longer the person who should.
 */

/**
 * How long a dialer holds a lead without renewing.
 *
 * Long enough to survive a real call plus the note written after it — the point
 * at which a claim is released is the *outcome*, not the hang-up. Short enough
 * that a browser closed mid-call frees the lead within the same working session
 * rather than the next morning.
 */
export const CLAIM_TTL_MINUTES = 20;

/** ISO-8601 UTC with milliseconds, as every other timestamp in this schema. */
const NOW_SQL = `strftime('%Y-%m-%dT%H:%M:%fZ', 'now')`;
const EXPIRY_SQL = `strftime('%Y-%m-%dT%H:%M:%fZ', 'now', '+${CLAIM_TTL_MINUTES} minutes')`;

/* -------------------------------------------------------------------------- */
/* The rule, as SQL                                                            */
/* -------------------------------------------------------------------------- */

/**
 * "This lead is closed to the operator whose id is bound here."
 *
 * Correlated on `leads`, so it drops into any WHERE clause over that table —
 * which is what the queue builders need, rather than a list of ids to subtract
 * in JS. Takes the actor id **twice**, in this order; `blockedParams()` exists
 * so no caller has to remember that.
 *
 * Expired claims are simply not seen. They are swept lazily (`sweepClaims`)
 * rather than on a timer: the predicate is already correct without the sweep,
 * and a delete that has to run for correctness is a delete that will one day not
 * run.
 */
export const BLOCKED_FOR_SQL = `(
  (leads.owner_id IS NOT NULL AND leads.owner_id != ?)
  OR EXISTS (
       SELECT 1 FROM lead_claims lc
        WHERE lc.lead_id = leads.id
          AND lc.actor_id != ?
          AND lc.expires_at > ${NOW_SQL}
     )
)`;

/** The parameters `BLOCKED_FOR_SQL` binds, in order. */
export function blockedParams(actorId: string): string[] {
  return [actorId, actorId];
}

/**
 * The same predicate for a caller with no operator to exempt — an admin, or a
 * report. Always false: nothing is blocked, and no parameters are bound.
 */
export const BLOCKED_FOR_NOBODY_SQL = `0`;

/**
 * The fragment plus its parameters, chosen by role.
 *
 * The one place the admin exemption is decided, so a new call site cannot half
 * apply it — which in this feature means either an admin who can't work a lead
 * or an operator who can work everyone's.
 */
export function blockedClause(actor: { id: string; isAdmin?: boolean }): {
  sql: string;
  params: string[];
} {
  if (actor.isAdmin) return { sql: BLOCKED_FOR_NOBODY_SQL, params: [] };
  return { sql: BLOCKED_FOR_SQL, params: blockedParams(actor.id) };
}

/* -------------------------------------------------------------------------- */
/* The rule, for one lead                                                      */
/* -------------------------------------------------------------------------- */

/** Why a lead is closed to this operator, in the terms the screen shows. */
export type LeadBlock = {
  /** `dono` outlives the session; `reservado` expires on its own. */
  reason: "dono" | "reservado";
  /** The operator holding it, by display name. */
  by: string;
  byId: string;
  /** When a reservation lapses. Null for ownership, which does not. */
  until: string | null;
  /** One pt-BR sentence, ready to be returned as an error body. */
  message: string;
};

export type ClaimActor = {
  id: string;
  displayName: string;
  /** Admins are never blocked. Defaults to false — the safe direction. */
  isAdmin?: boolean;
};

/**
 * A session as this module wants it.
 *
 * The one place `role === "admin"` is turned into the exemption, so a route
 * cannot forget it and no route has to restate it. Everything that contacts a
 * lead builds its actor through here.
 */
export function callActor(user: {
  id: string;
  displayName: string;
  role: string;
}): ClaimActor {
  return {
    id: user.id,
    displayName: user.displayName,
    isAdmin: user.role === "admin",
  };
}

/**
 * Is this lead closed to this operator? Null when they may contact it.
 *
 * Ownership is reported ahead of a claim when both apply: it is the one that
 * won't go away on its own, so it is the one the operator needs to be told
 * about. Reads as
 * `const blocked = blockFor(id, user); if (blocked) return conflict(blocked);`
 * — the same shape as `denyOutsideScope` in the auth module.
 */
export function blockFor(leadId: string, actor: ClaimActor): LeadBlock | null {
  if (actor.isAdmin) return null;

  const row = getDb()
    .prepare(
      `SELECT leads.owner_id, leads.owner_name,
              lc.actor_id AS claim_actor, lc.actor_display_name AS claim_name,
              lc.expires_at AS claim_until
         FROM leads
         LEFT JOIN lead_claims lc
                ON lc.lead_id = leads.id AND lc.expires_at > ${NOW_SQL}
        WHERE leads.id = ?`,
    )
    .get(leadId) as
    | {
        owner_id: string | null;
        owner_name: string | null;
        claim_actor: string | null;
        claim_name: string | null;
        claim_until: string | null;
      }
    | undefined;

  // A lead that isn't there is not "blocked" — the caller's own 404 is the
  // honest answer, and reporting it as taken would let this endpoint be used to
  // ask whether an id exists.
  if (!row) return null;

  if (row.owner_id !== null && row.owner_id !== actor.id) {
    const by = row.owner_name ?? "outro operador";
    return {
      reason: "dono",
      by,
      byId: row.owner_id,
      until: null,
      message: `Este lead já é atendido por ${by}. Fale com quem já tem o contato antes de ligar de novo.`,
    };
  }

  if (row.claim_actor !== null && row.claim_actor !== actor.id) {
    const by = row.claim_name ?? "outro operador";
    return {
      reason: "reservado",
      by,
      byId: row.claim_actor,
      until: row.claim_until,
      message: `${by} está atendendo este lead agora. Ele volta para a fila se a ligação não acontecer.`,
    };
  }

  return null;
}

/* -------------------------------------------------------------------------- */
/* Claims                                                                      */
/* -------------------------------------------------------------------------- */

export type ClaimResult =
  { ok: true; expiresAt: string } | { ok: false; block: LeadBlock };

/**
 * Reserve a lead for one operator, or say who already has it.
 *
 * The insert *is* the lock. Two dialers that render the same lead — which they
 * will, because both pages read the queue before either writes — both arrive
 * here, and the `ON CONFLICT` clause lets exactly one through: the row is only
 * overwritten when the existing claim belongs to the same operator (a renewal)
 * or has already expired. Checking first and then writing would be the same code
 * with a race in the middle, and the race is the entire thing being prevented.
 *
 * Ownership is checked before the insert rather than expressed in the conflict
 * clause: an owned lead is closed to everyone else permanently, and a claim on
 * it would be a reservation nobody could ever act on.
 */
export function claimLead(input: {
  leadId: string;
  actor: ClaimActor;
  listId?: number | null;
  /**
   * Internal. A refused insert whose block has already lapsed is retried once —
   * see below. Bounded rather than recursive-until-it-works: a claim that keeps
   * losing is a fact to report, not a loop to spin in.
   */
  retry?: boolean;
}): ClaimResult {
  const owner = ownerOf(input.leadId);
  if (owner && owner.id !== input.actor.id && !input.actor.isAdmin) {
    const block = blockFor(input.leadId, input.actor);
    if (block) return { ok: false, block };
  }

  const result = getDb()
    .prepare(
      `INSERT INTO lead_claims
         (lead_id, actor_id, actor_display_name, list_id, claimed_at, expires_at)
       VALUES (?, ?, ?, ?, ${NOW_SQL}, ${EXPIRY_SQL})
       ON CONFLICT (lead_id) DO UPDATE SET
         actor_id           = excluded.actor_id,
         actor_display_name = excluded.actor_display_name,
         list_id            = excluded.list_id,
         claimed_at         = excluded.claimed_at,
         expires_at         = excluded.expires_at
       WHERE lead_claims.actor_id = excluded.actor_id
          OR lead_claims.expires_at <= ${NOW_SQL}`,
    )
    .run(
      input.leadId,
      input.actor.id,
      input.actor.displayName,
      input.listId ?? null,
    );

  if (Number(result.changes) === 0) {
    const block = blockFor(input.leadId, input.actor);
    if (block) return { ok: false, block };
    // Somebody else's live claim is the only way the conflict clause refuses,
    // so no block here means it lapsed between the two statements. Reporting
    // that as taken would be a lie the operator can't act on — take it now.
    // Once: a second failure with nothing blocking is a bug, and the honest
    // answer is that the lead is busy rather than an unbounded retry.
    if (input.retry) {
      return {
        ok: false,
        block: {
          reason: "reservado",
          by: "outro operador",
          byId: "",
          until: null,
          message:
            "Este lead está sendo atendido agora. Tente novamente em instantes.",
        },
      };
    }
    return claimLead({ ...input, retry: true });
  }

  const row = getDb()
    .prepare("SELECT expires_at FROM lead_claims WHERE lead_id = ?")
    .get(input.leadId) as { expires_at: string };
  return { ok: true, expiresAt: row.expires_at };
}

/**
 * Give a lead back.
 *
 * Scoped to the holder: releasing is what a dialer does when it moves on, and a
 * request that could release anybody's claim would be a way to take a lead off
 * the operator currently talking to them. An admin releases through
 * `releaseOwnership`, which is the deliberate, audited path.
 */
export function releaseClaim(leadId: string, actorId: string): boolean {
  const result = getDb()
    .prepare("DELETE FROM lead_claims WHERE lead_id = ? AND actor_id = ?")
    .run(leadId, actorId);
  return Number(result.changes) > 0;
}

/** Every claim this operator is holding — for a "you left these open" view. */
export function claimsHeldBy(actorId: string): {
  leadId: string;
  leadName: string;
  listId: number | null;
  expiresAt: string;
}[] {
  const rows = getDb()
    .prepare(
      `SELECT lc.lead_id, leads.name AS lead_name, lc.list_id, lc.expires_at
         FROM lead_claims lc
         JOIN leads ON leads.id = lc.lead_id
        WHERE lc.actor_id = ? AND lc.expires_at > ${NOW_SQL}
        ORDER BY lc.claimed_at`,
    )
    .all(actorId) as {
    lead_id: string;
    lead_name: string;
    list_id: number | null;
    expires_at: string;
  }[];
  return rows.map((r) => ({
    leadId: r.lead_id,
    leadName: r.lead_name,
    listId: r.list_id === null ? null : Number(r.list_id),
    expiresAt: r.expires_at,
  }));
}

/**
 * Delete lapsed claims. Housekeeping only — every predicate here already ignores
 * them, so this is about the table not growing a row per lead ever dialled.
 */
export function sweepClaims(): number {
  const result = getDb()
    .prepare(`DELETE FROM lead_claims WHERE expires_at <= ${NOW_SQL}`)
    .run();
  return Number(result.changes);
}

/* -------------------------------------------------------------------------- */
/* Ownership                                                                   */
/* -------------------------------------------------------------------------- */

export type LeadOwner = { id: string; name: string; since: string | null };

export function ownerOf(leadId: string): LeadOwner | null {
  const row = getDb()
    .prepare("SELECT owner_id, owner_name, owned_at FROM leads WHERE id = ?")
    .get(leadId) as
    | {
        owner_id: string | null;
        owner_name: string | null;
        owned_at: string | null;
      }
    | undefined;
  if (!row?.owner_id) return null;
  return {
    id: row.owner_id,
    name: row.owner_name ?? "operador removido",
    since: row.owned_at,
  };
}

/**
 * Stamp the first contact's owner. Does nothing to a lead that already has one.
 *
 * `WHERE owner_id IS NULL` rather than a read-then-write, for the same reason
 * the claim is one statement: this runs inside the transaction that records a
 * call, and first-writer-wins has to be decided by the database. It also makes
 * the function safe to call on every contact — the callers do, so there is no
 * path that records outreach and forgets to assign.
 *
 * Returns true when this call is the one that took it.
 */
export function takeOwnership(leadId: string, actor: ClaimActor): boolean {
  const result = getDb()
    .prepare(
      `UPDATE leads
          SET owner_id = ?, owner_name = ?, owned_at = ${NOW_SQL}
        WHERE id = ? AND owner_id IS NULL`,
    )
    .run(actor.id, actor.displayName, leadId);
  return Number(result.changes) > 0;
}

/**
 * Hand a lead back to the team. Admin-only at every call site.
 *
 * The escape hatch the permanent half of this feature needs to have: an operator
 * leaves, a territory is reassigned, someone claimed a lead by mistake. Without
 * it the first contact would be an irreversible decision made by a single click,
 * which is not a thing worth building. Clears the live claim too — otherwise the
 * lead is free of an owner and still reserved for the person who had it.
 */
export function releaseOwnership(leadId: string): LeadOwner | null {
  const previous = ownerOf(leadId);
  const db = getDb();
  db.exec("BEGIN");
  try {
    db.prepare(
      "UPDATE leads SET owner_id = NULL, owner_name = NULL, owned_at = NULL WHERE id = ?",
    ).run(leadId);
    db.prepare("DELETE FROM lead_claims WHERE lead_id = ?").run(leadId);
    db.exec("COMMIT");
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
  return previous;
}

/** Move a lead to another operator outright. Admin-only, same as the release. */
export function assignOwnership(leadId: string, to: ClaimActor): boolean {
  const db = getDb();
  db.exec("BEGIN");
  try {
    const result = db
      .prepare(
        `UPDATE leads SET owner_id = ?, owner_name = ?, owned_at = ${NOW_SQL}
          WHERE id = ?`,
      )
      .run(to.id, to.displayName, leadId);
    // A claim held by the previous owner would outlive the reassignment and
    // block the person it was just given to.
    db.prepare(
      "DELETE FROM lead_claims WHERE lead_id = ? AND actor_id != ?",
    ).run(leadId, to.id);
    db.exec("COMMIT");
    return Number(result.changes) > 0;
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}

/** A 409 for a blocked contact. Its own helper so every route words it alike. */
export function conflict(block: LeadBlock): Response {
  return Response.json(
    {
      error: block.message,
      block: {
        reason: block.reason,
        by: block.by,
        until: block.until,
      },
    },
    { status: 409 },
  );
}
