/**
 * pt-BR niche → Overture `categories.primary` values.
 *
 * The category strings are not invented: they were taken from the live vocabulary
 * (`src/data/overture-categories.csv`, every category with ≥20 businesses in São
 * Paulo). An unknown category would silently match nothing, which is the worst
 * kind of bug here — an empty result looks like "no leads in this city" rather
 * than "you typo'd a category". Regenerate that CSV before adding to this list.
 *
 * Two rules hold this together, and the assertion further down enforces the
 * second one:
 *
 * 1. Niches are narrow enough to run a campaign against. They used to be 12 broad
 *    buckets, which sounds tidier and isn't: "restaurantes" bundled 16 categories
 *    and matched 32.895 businesses in São Paulo alone, so against the 1.000-row
 *    result cap you could never see past the first 3% of it. A pizzaria pitch and
 *    a padaria pitch are different conversations anyway.
 *
 * 2. **A category belongs to exactly one niche.** `nail_salon` used to be in both
 *    "barbearias-saloes" and "estetica" — 17.624 businesses appearing under two
 *    niches, and because a lead's stored niche was whichever search touched it
 *    last, the 133 nail salons already saved had split 61/72 between the two at
 *    random. Any per-niche count was therefore fiction. Overlap is now a thrown
 *    error at import rather than something you find months later.
 *
 * 3. A niche says what we want from it. Most are `cliente` — a business to sell a
 *    site to. The "Marketing e parcerias" family is `parceiro`: professionals who
 *    sell alongside us rather than buy from us, which inverts the qualification
 *    and rewrites the opener. See `scorePartner` and `outreachMessage` in
 *    `score.ts`.
 */
/**
 * What we want from the businesses in a niche.
 *
 * `cliente` is the original and the default: somebody who needs what Mandra
 * sells. `parceiro` is the other direction — a gestor de tráfego or a marketing
 * agency sells ads to the same shop we sell a site to, and neither of us sells
 * the other's half. The approach is a referral split, not a demo.
 */
export type NicheIntent = "cliente" | "parceiro";

export type Niche = {
  slug: string;
  label: string;
  /** Coarse family, used to group the dropdown so the options stay navigable. */
  group: string;
  /** Absent means `cliente`, which is what every niche was before parcerias. */
  intent?: NicheIntent;
  categories: string[];
  /**
   * Receita Federal CNAE codes, seven digits, no punctuation — the second
   * vocabulary this registry maps, alongside Overture's.
   *
   * They live on the niche rather than in a table of their own so that rule 2
   * holds across *both* vocabularies at once: a CNAE claimed by two niches is
   * the same corruption as a category claimed by two, and `reniche()` in db.ts
   * rebuilds a stored niche from whichever of the two a lead was found under.
   * Only the parcerias niches carry them; the CNPJ base is not a source for
   * client prospecting, where "has no website" is the whole question and the
   * Receita has no such field.
   */
  cnaes?: string[];
  /**
   * CNAEs that contain the trade but do not identify it — included only when the
   * business's own name also reads as marketing (`MARKETING_NAME`).
   *
   * This is not caution, it is measured. `7319-0/99` ("outras atividades de
   * publicidade") samples as 2J MIDIA DIGITAL, NOVA BELEM PUBLICIDADE, TAGHY
   * AGENCIA DIGITAL — the trade itself. `7319-0/02` ("promoção de vendas")
   * samples as OLIVEIRA VIDRACARIA E ENERGIA SOLAR, OFICINA MECANICA R.N.,
   * EMPORIO INDUSTRIAL E ELETRICO, and it is *seventy per cent* of everything
   * a plain CNAE filter returns. Taking it whole would have buried the real
   * base under three times its own volume in glaziers and mechanics.
   */
  broadCnaes?: string[];
};

/**
 * What a marketing business calls itself, folded and unaccented.
 *
 * Applied to razão social and nome fantasia together, and only ever to widen a
 * `broadCnaes` match — never to narrow a precise one, where the CNAE is already
 * the evidence and a firm named "Studio 9" would be thrown away for it.
 */
export const MARKETING_NAME =
  "market|publicid|propagand|agencia|midia|trafego|social media|" +
  "comunicac|criativ|digital|design|branding|audiovisual|assessoria de imprensa";

export const NICHES: Niche[] = [
  // --- Beleza ---------------------------------------------------------------
  {
    slug: "barbearias",
    label: "Barbearias",
    group: "Beleza",
    categories: ["barber"],
  },
  {
    slug: "saloes-beleza",
    label: "Salões de beleza",
    group: "Beleza",
    categories: ["beauty_salon", "hair_salon"],
  },
  {
    slug: "manicure",
    label: "Manicure e nail design",
    group: "Beleza",
    categories: ["nail_salon"],
  },
  {
    slug: "estetica-spa",
    label: "Estética e spa",
    group: "Beleza",
    categories: ["beauty_and_spa", "spas"],
  },
  {
    slug: "tatuagem",
    label: "Tatuagem e piercing",
    group: "Beleza",
    categories: ["tattoo_and_piercing"],
  },

  // --- Alimentação ----------------------------------------------------------
  {
    slug: "restaurantes",
    label: "Restaurantes",
    group: "Alimentação",
    categories: [
      "restaurant",
      "brazilian_restaurant",
      "bar_and_grill_restaurant",
      "buffet_restaurant",
    ],
  },
  {
    slug: "bares",
    label: "Bares",
    group: "Alimentação",
    categories: ["bar"],
  },
  {
    slug: "pizzarias",
    label: "Pizzarias",
    group: "Alimentação",
    categories: ["pizza_restaurant"],
  },
  {
    slug: "hamburguerias",
    label: "Hamburguerias e fast food",
    group: "Alimentação",
    categories: ["burger_restaurant", "fast_food_restaurant"],
  },
  {
    slug: "padarias",
    label: "Padarias",
    group: "Alimentação",
    categories: ["bakery"],
  },
  {
    slug: "cafeterias",
    label: "Cafeterias",
    group: "Alimentação",
    categories: ["cafe", "coffee_shop"],
  },
  {
    slug: "sorveterias-sucos",
    label: "Sorveterias e sucos",
    group: "Alimentação",
    categories: ["ice_cream_shop", "smoothie_juice_bar"],
  },
  {
    slug: "culinaria-internacional",
    label: "Culinária internacional",
    group: "Alimentação",
    categories: [
      "sushi_restaurant",
      "japanese_restaurant",
      "italian_restaurant",
    ],
  },

  // --- Saúde ----------------------------------------------------------------
  {
    slug: "odontologia",
    label: "Odontologia",
    group: "Saúde",
    categories: ["dentist", "general_dentistry"],
  },
  {
    slug: "clinicas-medicas",
    label: "Clínicas médicas",
    group: "Saúde",
    categories: [
      "medical_center",
      "health_and_medical",
      "medical_service_organizations",
    ],
  },
  {
    slug: "fisioterapia",
    label: "Fisioterapia",
    group: "Saúde",
    categories: ["physical_therapy"],
  },
  {
    slug: "psicologia",
    label: "Psicologia e terapia",
    group: "Saúde",
    categories: ["psychotherapist"],
  },

  // --- Casa e construção ----------------------------------------------------
  {
    slug: "imobiliarias",
    label: "Imobiliárias",
    group: "Casa e construção",
    categories: ["real_estate", "real_estate_agent"],
  },
  {
    slug: "arquitetura",
    label: "Arquitetura e design",
    group: "Casa e construção",
    categories: ["architectural_designer"],
  },
  {
    slug: "engenharia-construcao",
    label: "Engenharia e construção",
    group: "Casa e construção",
    categories: ["engineering_services", "construction_services"],
  },
  {
    slug: "reformas-coberturas",
    label: "Reformas e coberturas",
    group: "Casa e construção",
    categories: [
      "contractor",
      "roofing",
      "windows_installation",
      "countertop_installation",
    ],
  },
  {
    slug: "energia-solar",
    label: "Energia solar",
    group: "Casa e construção",
    categories: [
      "solar_installation",
      "energy_equipment_and_solution",
      "energy_company",
    ],
  },
  {
    slug: "climatizacao",
    label: "Climatização e ar-condicionado",
    group: "Casa e construção",
    categories: ["hvac_services"],
  },
  {
    slug: "piscinas",
    label: "Piscinas",
    group: "Casa e construção",
    categories: ["swimming_pool", "pool_cleaning"],
  },
  {
    // "Residencial" was the wrong half of the trade: the same installer does the
    // condomínio, the loja and the galpão, and the condomínio is the contract
    // worth having. `security_services` is the vigilância side and
    // `garage_door_service` the portão automático — in Brazil both are sold by
    // the CFTV/alarme installer, off the same orçamento and with the same hole
    // after it.
    slug: "seguranca-residencial",
    label: "Segurança eletrônica",
    group: "Casa e construção",
    categories: [
      "home_security",
      "security_systems",
      "security_services",
      "garage_door_service",
    ],
  },
  {
    // Planejados is the clearest case in the registry of the dor we sell
    // against: a visit, a 3D project, a five-figure orçamento, and then nothing
    // — the lead goes cold in a WhatsApp thread nobody owns. `furniture_store`
    // is where the planejados brands and their franchises sit; `carpenter` is
    // the marcenaria that does the same job without a showroom.
    slug: "moveis-planejados",
    label: "Móveis planejados e marcenaria",
    group: "Casa e construção",
    categories: ["furniture_store", "carpenter", "furniture_assembly"],
  },
  {
    // Small ticket per visit, but the contract is recurring and the buying
    // decision is immediate — a dedetizadora loses leads to response time
    // alone, which is the one thing an automated first reply fixes outright.
    slug: "dedetizacao",
    label: "Dedetização e controle de pragas",
    group: "Casa e construção",
    categories: ["pest_control_service"],
  },

  // --- Fitness --------------------------------------------------------------
  {
    slug: "academias",
    label: "Academias",
    group: "Fitness",
    categories: ["gym"],
  },
  {
    slug: "pilates",
    label: "Pilates e estúdios",
    group: "Fitness",
    categories: ["pilates_studio"],
  },

  // --- Automotivo -----------------------------------------------------------
  {
    slug: "oficinas",
    label: "Oficinas mecânicas",
    group: "Automotivo",
    categories: [
      "automotive_repair",
      "automotive_services_and_repair",
      "auto_body_shop",
    ],
  },
  {
    // Split from "Oficinas mecânicas" rather than folded into it, because the
    // conversation is different: these run on scheduled slots and on a return
    // the customer forgets (rodízio, revisão, troca de óleo), so the pitch is
    // agendamento e retorno, not "you have no website". Keeping them apart also
    // keeps the generic-repair search from being drowned by 1.100 borracharias.
    slug: "oficinas-especializadas",
    label: "Oficinas especializadas",
    group: "Automotivo",
    categories: [
      "tire_dealer_and_repair",
      "motorcycle_repair",
      "oil_change_station",
      "auto_glass_service",
      "truck_repair",
    ],
  },
  {
    slug: "estetica-automotiva",
    label: "Estética automotiva",
    group: "Automotivo",
    categories: ["auto_detailing", "car_wash"],
  },
  {
    slug: "concessionarias",
    label: "Concessionárias e revendas",
    group: "Automotivo",
    categories: [
      "car_dealer",
      "automotive_dealer",
      "used_car_dealer",
      "commercial_vehicle_dealer",
      "motorcycle_dealer",
    ],
  },

  // --- Pet ------------------------------------------------------------------
  {
    slug: "pet-shops",
    label: "Pet shops e banho e tosa",
    group: "Pet",
    categories: ["pet_store", "pet_services", "pet_groomer"],
  },
  {
    slug: "veterinarios",
    label: "Veterinários",
    group: "Pet",
    categories: ["veterinarian"],
  },

  // --- Serviços profissionais ------------------------------------------------
  {
    slug: "advocacia",
    label: "Advocacia",
    group: "Serviços profissionais",
    categories: ["lawyer"],
  },
  {
    slug: "contabilidade",
    label: "Contabilidade",
    group: "Serviços profissionais",
    categories: ["accountant"],
  },
  {
    slug: "seguros",
    label: "Seguros",
    group: "Serviços profissionais",
    categories: ["insurance_agency"],
  },
  {
    slug: "servicos-financeiros",
    label: "Serviços financeiros",
    group: "Serviços profissionais",
    categories: ["financial_service", "financial_advising"],
  },

  // --- Educação -------------------------------------------------------------
  {
    slug: "escolas",
    label: "Escolas",
    group: "Educação",
    categories: ["school", "private_school"],
  },
  {
    slug: "cursos-idiomas",
    label: "Cursos de idiomas",
    group: "Educação",
    categories: ["language_school"],
  },
  {
    slug: "autoescolas",
    label: "Autoescolas",
    group: "Educação",
    categories: ["driving_school"],
  },
  {
    slug: "escolas-especializadas",
    label: "Escolas especializadas",
    group: "Educação",
    categories: ["specialty_school", "dance_school"],
  },

  // --- Marketing e parcerias -------------------------------------------------
  // Not prospects. These are the people to split referrals with: they sell
  // campaigns to exactly the businesses above, and a campaign pointed at a shop
  // with no site burns their budget as surely as it wastes ours. So the pitch is
  // "send me the ones who need a site, I'll send you the ones who need traffic",
  // and the scoring runs the other way round — a marketing professional with no
  // website and no social presence is not a partner worth having.
  //
  // `web_designer` is deliberately absent: that is a competitor, not a partner,
  // and putting it here would fill a parcerias search with agencies selling the
  // one thing Mandra sells.
  {
    slug: "gestores-trafego",
    label: "Gestores de tráfego",
    group: "Marketing e parcerias",
    intent: "parceiro",
    categories: [
      "internet_marketing_service",
      "marketing_consultant",
      "business_advertising",
    ],
    cnaes: [
      // 7319-0/99 is where a gestor de tráfego who formalised alone most often
      // lands: it is the "outras atividades de publicidade" catch-all, and it
      // is the single reason this source exists — no map has these people.
      "7319099", // Outras atividades de publicidade não especificadas
      "7319003", // Marketing direto
      "7319004", // Consultoria em publicidade
    ],
    broadCnaes: [
      "7319002", // Promoção de vendas — mostly not marketing at all; see above
      "6319400", // Portais e provedores de conteúdo — half agencies, half shops
    ],
  },
  {
    slug: "agencias-marketing",
    label: "Agências de marketing e publicidade",
    group: "Marketing e parcerias",
    intent: "parceiro",
    categories: [
      "marketing_agency",
      "advertising_agency",
      "media_agency",
      "social_media_agency",
      "public_relations",
    ],
    cnaes: [
      "7311400", // Agências de publicidade — the anchor code of the trade
      "7312200", // Agenciamento de espaços para publicidade
      "7320300", // Pesquisas de mercado e de opinião pública
    ],
  },
  {
    slug: "design-criacao",
    label: "Design e criação",
    group: "Marketing e parcerias",
    intent: "parceiro",
    categories: ["graphic_designer", "product_design"],
    cnaes: [
      "7410201", // Design
      "7410203", // Design de produto
      "7410299", // Atividades de design não especificadas anteriormente
      "5911102", // Produção de filmes para publicidade
    ],
  },
];

/**
 * category → niche slug. This is the authoritative direction.
 *
 * A lead's niche is derived from the business's own Overture category, not from
 * whichever search happened to find it. Storing the search's niche instead made
 * the value depend on the order you ran your searches — and since every re-search
 * overwrote it, a lead could change niche just by being looked for again.
 */
const CATEGORY_TO_NICHE = new Map<string, string>();
/** Built in the same pass, so an intent can never disagree with its niche. */
const CATEGORY_TO_INTENT = new Map<string, NicheIntent>();
for (const niche of NICHES) {
  for (const category of niche.categories) {
    const existing = CATEGORY_TO_NICHE.get(category);
    if (existing !== undefined) {
      throw new Error(
        `Overture category "${category}" is in two niches ("${existing}" and ` +
          `"${niche.slug}"). Every category must belong to exactly one niche, or ` +
          `per-niche counts double-count and a lead's niche depends on search order.`,
      );
    }
    CATEGORY_TO_NICHE.set(category, niche.slug);
    CATEGORY_TO_INTENT.set(category, niche.intent ?? "cliente");
  }
  // CNAEs go into the same two maps, and are held to the same rule. They cannot
  // collide with an Overture category by construction — seven digits against a
  // lowercase word — so one map can serve both vocabularies, which is what lets
  // `nicheForCategory` and `reniche()` stay unaware that there are two.
  for (const cnae of [...(niche.cnaes ?? []), ...(niche.broadCnaes ?? [])]) {
    if (!/^\d{7}$/.test(cnae)) {
      throw new Error(
        `CNAE "${cnae}" in niche "${niche.slug}" is not seven digits. The ` +
          `Receita's own files carry them unpunctuated, and a code written as ` +
          `"7319-0/99" would match nothing and read as an empty base.`,
      );
    }
    const existing = CATEGORY_TO_NICHE.get(cnae);
    if (existing !== undefined) {
      throw new Error(
        `CNAE "${cnae}" is in two niches ("${existing}" and "${niche.slug}").`,
      );
    }
    CATEGORY_TO_NICHE.set(cnae, niche.slug);
    CATEGORY_TO_INTENT.set(cnae, niche.intent ?? "cliente");
  }
}

export function findNiche(slug: string): Niche | undefined {
  return NICHES.find((n) => n.slug === slug);
}

/** The niche a business belongs to, from its category. Null for anything unmapped. */
export function nicheForCategory(category: string | null): string | null {
  if (!category) return null;
  return CATEGORY_TO_NICHE.get(category) ?? null;
}

/** What a niche is for. Unknown slugs read as `cliente`, the original behaviour. */
export function nicheIntent(slug: string | null | undefined): NicheIntent {
  return (slug ? findNiche(slug)?.intent : undefined) ?? "cliente";
}

/**
 * What a *business* is for, from its own Overture category — the same direction
 * `nicheForCategory` runs in, and for the same reason.
 *
 * This is what lets every existing caller keep working unchanged: the WhatsApp
 * button in the CRM, the CSV export and the history page all hand `score.ts` a
 * lead and no context, and each of them must offer a marketing agency a
 * partnership opener rather than a "you have no website" pitch. A category we
 * don't map is a client, which is what an unclassified business has always been.
 */
export function intentForCategory(category: string | null): NicheIntent {
  if (!category) return "cliente";
  return CATEGORY_TO_INTENT.get(category) ?? "cliente";
}

/**
 * Every Overture category we prospect, for `sync-places.mjs`.
 *
 * CNAEs are deliberately excluded: that script builds the Overture extract, and
 * a seven-digit code passed to it would fail its own `^[a-z0-9_]+$` guard — or,
 * worse, silently match nothing. `allCnaes()` is the CNPJ sync's equivalent.
 */
export function allCategories(): string[] {
  return NICHES.flatMap((n) => n.categories).sort();
}

/**
 * CNAEs that identify the trade on their own — taken whole by `sync-cnpj.mjs`.
 */
export function preciseCnaes(): string[] {
  return NICHES.flatMap((n) => n.cnaes ?? []).sort();
}

/** CNAEs that only count when the business's name agrees. See `MARKETING_NAME`. */
export function broadCnaes(): string[] {
  return NICHES.flatMap((n) => n.broadCnaes ?? []).sort();
}

/** Both, for anything that just needs to know which codes we ever look at. */
export function allCnaes(): string[] {
  return [...preciseCnaes(), ...broadCnaes()].sort();
}

/** Niches in declaration order, grouped, for `<optgroup>`. */
export function nichesByGroup(): { group: string; niches: Niche[] }[] {
  const groups: { group: string; niches: Niche[] }[] = [];
  for (const niche of NICHES) {
    const last = groups[groups.length - 1];
    if (last && last.group === niche.group) last.niches.push(niche);
    else groups.push({ group: niche.group, niches: [niche] });
  }
  return groups;
}

/**
 * Fingerprint of the vocabulary. When it changes, stored niche values are stale,
 * and db.ts rebuilds them from each lead's category.
 */
export function nicheFingerprint(): string {
  return NICHES.map(
    (n) =>
      `${n.slug}:${n.categories.join(",")}:${(n.cnaes ?? []).join(",")}` +
      `:${(n.broadCnaes ?? []).join(",")}`,
  ).join("|");
}
