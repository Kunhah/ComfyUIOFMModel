import { countryLabel } from "@/lib/countries";
import { normalise } from "./cities";
import { persistLeads, recordProspectorSearch, type SearchActor } from "./db";
import { findNiche } from "./niches";
import { hasExtract, queryOverture } from "./overture";
import { hasCnpjExtract, queryCnpj } from "./cnpj";
import { queryOpenStreetMap } from "./openstreetmap";
import { hasGeoapifyKey, queryGeoapify } from "./geoapify";
import { isWhatsappCapable, scoreAndSort } from "./score";
import { dedupeLeads } from "./discovery";
import { contactHistoryFor } from "./history";
import type { SearchRequest, SearchResponse } from "./types";
import { resolveSearchArea } from "./scopes";

const log = (event: string, fields: Record<string, unknown> = {}) =>
  console.info(JSON.stringify({ service: "prospector", event, ...fields }));

/**
 * One implementation of "run a search", shared by the POST route (interactive
 * searches from the form) and by the page (a URL-driven search, rendered on the
 * server so a shared link shows its results immediately).
 *
 * Keeping it here rather than in the route handler is what stops the two paths
 * from drifting — the scoring, the stats and the persistence side effects have to
 * be identical or a deep link would disagree with the same search run by hand.
 */

export type SearchOutcome =
  | { ok: true; response: SearchResponse }
  | { ok: false; status: number; error: string };

export async function performSearch(
  input: SearchRequest,
  actor?: SearchActor,
): Promise<SearchOutcome> {
  const niche = findNiche(String(input.niche ?? ""));
  if (!niche) {
    return { ok: false, status: 400, error: "Nicho desconhecido." };
  }

  // Defaults to Brazil, so a link or a saved search made before the tool left
  // Brazil still resolves to the same city it always did.
  const country = String(input.country ?? "BR").toUpperCase();
  const area = resolveSearchArea(input);
  if (!area) {
    return {
      ok: false,
      status: 400,
      error: `Local não encontrado para ${countryLabel(country)}.`,
    };
  }

  // A parcerias niche is looking for somebody to work with, and the no-website
  // filter is the one thing that cannot be carried over from client prospecting:
  // it would keep exactly the marketing agencies that are dormant or one person
  // moonlighting, and throw away every firm worth partnering with. The filter is
  // therefore forced off rather than defaulted off — an old link carrying
  // `?all=` , a saved search, or a client-niche habit must not be able to turn a
  // partner search into an empty one.
  const intent = niche.intent ?? "cliente";
  const onlyWithoutWebsite =
    intent === "parceiro" ? false : input.onlyWithoutWebsite !== false;
  // History is on unless the search asks otherwise. It is a local file, so there
  // is no account to set up and no reason to make keeping it opt-in — but a run
  // meant to size a market rather than work it should be able to leave nothing
  // behind, which is what this is.
  const save = input.save !== false;
  const minConfidence = clamp(input.minConfidence ?? 0.5, 0, 1);
  const limit = Math.trunc(clamp(input.limit ?? 500, 1, 5000));
  const started = Date.now();
  log("search.start", {
    niche: niche.slug,
    intent,
    country: area.country,
    scope: area.scope,
    area: area.name,
    uf: area.uf,
    onlyWithoutWebsite,
    minConfidence,
    limit,
    includeOpenStreetMap: input.includeOpenStreetMap !== false,
    save,
  });

  const warnings: string[] = [];
  if (intent === "parceiro" && input.onlyWithoutWebsite === true) {
    warnings.push(
      "Busca de parceria: o filtro “só quem não tem site” foi ignorado — um profissional de marketing sem site próprio não é um parceiro.",
    );
  }
  if (!area.city && input.includeOpenStreetMap !== false) {
    warnings.push(
      "OpenStreetMap e Geoapify são consultados apenas em buscas por cidade; esta busca ampla usa o extrato Overture.",
    );
  }
  if (!hasExtract()) {
    warnings.push(
      "Extrato local indisponível. Reinicie o container para semear o banco de buscas.",
    );
  }

  let result;
  try {
    result = await queryOverture({
      area,
      categories: niche.categories,
      onlyWithoutWebsite,
      minConfidence,
      limit,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    log("search.failed", {
      niche: niche.slug,
      country: area.country,
      scope: area.scope,
      area: area.name,
      uf: area.uf,
      elapsedMs: Date.now() - started,
      error: message,
    });
    return { ok: false, status: 502, error: `Falha na consulta: ${message}` };
  }

  let combined = result.leads;
  if (area.city && input.includeOpenStreetMap !== false) {
    try {
      const osm = await queryOpenStreetMap({
        city: area.city,
        niche: niche.slug,
        limit: 500,
      });
      const eligible = (
        onlyWithoutWebsite ? osm.filter((lead) => !lead.website) : osm
      ).map((lead) => ({ ...lead, country: area.country }));
      const merged = mergeSupplementary(eligible, result.leads);
      combined = [...merged.primary, ...merged.extra];
    } catch {
      // OSM is a best-effort supplement on a public shared service. Overture is
      // still a complete, fast search if an Overpass mirror is temporarily busy.
      warnings.push(
        "OpenStreetMap indisponível nesta busca; resultados do Overture mantidos.",
      );
    }
  }

  if (area.city && hasGeoapifyKey()) {
    try {
      const geoapify = await queryGeoapify({
        city: area.city,
        niche: niche.slug,
        limit: 500,
      });
      const eligible = (
        onlyWithoutWebsite ? geoapify.filter((lead) => !lead.website) : geoapify
      ).map((lead) => ({ ...lead, country: area.country }));
      const merged = mergeSupplementary(eligible, combined);
      combined = [...merged.primary, ...merged.extra];
    } catch {
      warnings.push(
        "Geoapify indisponível nesta busca; demais fontes mantidas.",
      );
    }
  }

  // The Receita's register, for partner searches only.
  //
  // It is not a supplement in the sense OpenStreetMap is — it is usually the
  // larger half. A gestor de tráfego works from a laptop and has no storefront
  // to survey, so the map has never heard of them while the register has heard
  // of every one that formalised. It runs at every scope, not just city
  // searches, because it costs a local scan of a small file rather than a call
  // to somebody else's shared service.
  let cnpjTotals = { matched: 0, withPhone: 0, withEmail: 0, mei: 0 };
  const cnaes = [...(niche.cnaes ?? []), ...(niche.broadCnaes ?? [])];
  if (intent === "parceiro" && cnaes.length > 0) {
    if (!hasCnpjExtract()) {
      warnings.push(
        "Extrato CNPJ ausente: só o Overture respondeu, o que deixa de fora quem não tem endereço no mapa. Rode `npm run sync:cnpj`.",
      );
    } else {
      try {
        const cnpj = await queryCnpj({ area, cnaes, limit });
        cnpjTotals = cnpj.totals;
        const merged = mergeSupplementary(cnpj.leads, combined);
        combined = [...merged.primary, ...merged.extra];
      } catch (err) {
        // Same contract as the other supplementary sources: a missing or
        // unreadable second extract must not fail a search the first one
        // already answered.
        warnings.push(
          `Extrato CNPJ indisponível nesta busca (${err instanceof Error ? err.message : String(err)}); resultados do Overture mantidos.`,
        );
      }
    }
  }

  // A foreign mobile may support WhatsApp, but it is still actionable by a
  // normal call; e-mail and business social profiles are direct alternatives
  // too. Do not put an overseas business on an operator's board if the source
  // exposed none of those paths — it would turn "contact" into a WhatsApp-only
  // gamble, precisely what the international flow is meant to avoid.
  const unreachableInternational = combined.filter(
    (lead) =>
      lead.country &&
      lead.country !== "BR" &&
      !lead.phone &&
      !lead.email &&
      !(lead.socialLinks?.length || lead.social),
  ).length;
  if (unreachableInternational > 0) {
    combined = combined.filter(
      (lead) =>
        !(
          lead.country &&
          lead.country !== "BR" &&
          !lead.phone &&
          !lead.email &&
          !(lead.socialLinks?.length || lead.social)
        ),
    );
    warnings.push(
      `${unreachableInternational.toLocaleString("pt-BR")} ${plural(unreachableInternational, "negócio internacional sem canal direto foi ocultado", "negócios internacionais sem canal direto foram ocultados")}.`,
    );
  }

  // One business can arrive from all three directories under three spellings.
  // `mergeSupplementary` only reconciles them when the normalised names are
  // exactly equal, so the rest are collapsed here — before scoring, so a
  // duplicate can't take two rows on the board, and before `persistLeads`, so it
  // can't enter the history twice.
  const deduped = dedupeLeads(combined);
  combined = deduped.leads;
  if (deduped.removed > 0) {
    warnings.push(
      `${deduped.removed.toLocaleString("pt-BR")} ${plural(deduped.removed, "registro duplicado", "registros duplicados")} ${plural(deduped.removed, "unificado", "unificados")} entre as fontes.`,
    );
  }

  // Counted after the collapse, and attributed by the row's own `source`. Taken
  // at merge time these were the *pre-dedupe* extras, so a business that OSM and
  // Geoapify both knew was announced twice and counted twice in `total`.
  const supplementary = supplementaryRows(combined, result.leads);
  const fromOpenStreetMap = supplementary.filter(
    (lead) => lead.source === "openstreetmap",
  ).length;
  const fromGeoapify = supplementary.filter(
    (lead) => lead.source === "geoapify",
  ).length;
  // Counted after the collapse and attributed by the row's own source, for the
  // same reason as the two above: taken at merge time this was the pre-dedupe
  // figure, and an agency the register and the map both knew would be announced
  // twice and counted twice in `total`.
  const fromCnpj = supplementary.filter(
    (lead) => lead.source === "cnpj",
  ).length;
  if (fromCnpj > 0) {
    const mei = cnpjTotals.mei;
    warnings.push(
      `${fromCnpj.toLocaleString("pt-BR")} ${plural(fromCnpj, "profissional encontrado", "profissionais encontrados")} no registro da Receita ` +
        `(${cnpjTotals.withEmail.toLocaleString("pt-BR")} com e-mail, ` +
        `${mei.toLocaleString("pt-BR")} ${plural(mei, "é MEI", "são MEI")}). ` +
        `Fale por e-mail: a Receita não guarda site nem redes, e o telefone dela é ` +
        `anterior ao nono dígito, então quase nunca abre WhatsApp.`,
    );
  }
  for (const [count, label] of [
    [fromOpenStreetMap, "OpenStreetMap"],
    [fromGeoapify, "Geoapify"],
  ] as const) {
    if (count > 0) {
      warnings.push(
        `${count.toLocaleString("pt-BR")} ${plural(count, "negócio adicional", "negócios adicionais")} ${plural(count, "encontrado", "encontrados")} no ${label}.`,
      );
    }
  }

  // The intent is passed rather than left to each lead's category: a supplementary
  // OpenStreetMap or Geoapify row carries that source's own vocabulary, and a
  // partner scored as a client would be sorted to the bottom for having a site.
  const leads = scoreAndSort(combined, intent).slice(0, limit);

  // Straight from the query's own aggregates, which cover every match. Counting
  // `leads` instead would report `limit` back as the size of the pool.
  const stats = {
    total: result.totals.matched + fromOpenStreetMap + fromGeoapify + fromCnpj,
    withoutWebsite:
      result.totals.withoutWebsite +
      // A register row has no website *field*, so it is not evidence of a
      // business without a website and must not inflate this count — the same
      // unknown-versus-absent distinction `scorePartner` makes. Counting them
      // would report every partner search as almost entirely site-less, which
      // is a statement about the Receita's schema and not about the trade.
      supplementalCount(
        combined,
        result.leads,
        (lead) => !lead.website && lead.source !== "cnpj",
      ),
    withPhone:
      result.totals.withPhone +
      supplementalCount(combined, result.leads, (lead) => Boolean(lead.phone)),
    withWhatsapp:
      result.totals.withWhatsapp +
      supplementalCount(combined, result.leads, (lead) =>
        isWhatsappCapable(lead.phone, lead.country),
      ),
    returned: leads.length,
    elapsedMs: result.elapsedMs,
    fromOpenStreetMap,
    fromGeoapify,
    fromCnpj,
  };

  if (leads.length < stats.total) {
    warnings.push(
      `Mostrando ${leads.length.toLocaleString("pt-BR")} de ` +
        `${stats.total.toLocaleString("pt-BR")} negócios encontrados. ` +
        `Refine a busca para ver o resto.`,
    );
  }

  // Nothing at all is written when saving is off — not the leads, not a partial
  // row. `isNew` then stays undefined on every lead, which is exactly what it
  // means: this run has no idea whether the business was known, because it never
  // asked.
  const { result: persisted, warning } = save
    ? persistLeads(leads, {
        niche: niche.slug,
        country: area.country,
        city: area.name,
        uf: area.uf,
      })
    : { result: null, warning: undefined };
  if (warning) warnings.push(warning);
  if (!save) {
    warnings.push(
      "Histórico desativado nesta busca: nada foi salvo no banco de dados.",
    );
  }

  if (actor) {
    // Recorded even when the leads are not: the audit is about who used the
    // tool, and a search that saves nothing is still a search that ran.
    recordProspectorSearch({
      actor,
      niche: niche.slug,
      country: area.country,
      city: area.name,
      uf: area.uf,
      matched: result.totals.matched,
      returned: leads.length,
      inserted: persisted?.inserted ?? 0,
    });
  }

  // Marked after persisting, since "new" means "was not in the database before
  // this search". The board reads it to flag rows worth looking at first.
  const isNew = new Set(persisted?.newIds ?? []);
  const marked = persisted
    ? leads.map((l) => ({ ...l, isNew: isNew.has(l.id) }))
    : leads;

  // What we already did about these businesses, which the directory cannot know
  // and `isNew` does not answer. Read even when `save` is off: not writing the
  // history is a reason to leave it alone, never a reason to stop reading it,
  // and an exploratory search that offers an un-warned WhatsApp button to a
  // business a colleague phoned on Tuesday is the failure this exists to stop.
  const contacted = contactHistoryFor(marked.map((l) => l.id));
  const decorated = marked.map((l) => {
    const history = contacted.get(l.id);
    return history
      ? {
          ...l,
          contactedAt: history.contactedAt,
          attempts: history.attempts,
          owner: history.owner,
          funnelStage: history.funnelStage,
        }
      : l;
  });

  log("search.ready", {
    niche: niche.slug,
    country: area.country,
    scope: area.scope,
    area: area.name,
    uf: area.uf,
    elapsedMs: Date.now() - started,
    queryMs: result.elapsedMs,
    mode: result.mode,
    matched: result.totals.matched,
    returned: marked.length,
    fromOpenStreetMap,
    fromGeoapify,
    saved: save,
    inserted: persisted?.inserted ?? 0,
  });

  return {
    ok: true,
    response: {
      leads: decorated,
      stats,
      persisted: persisted && {
        inserted: persisted.inserted,
        alreadyKnown: persisted.alreadyKnown,
      },
      saved: save,
      warnings,
    },
  };
}

/**
 * OSM and Overture have unrelated ids. Keep an OSM row only when its stable map
 * id is genuinely absent from the Overture result: same normalised name plus an
 * exact phone, address, or nearby coordinate is the strongest safe match.
 */
function mergeSupplementary(
  extra: import("./types").Lead[],
  primary: import("./types").Lead[],
) {
  const ids = new Set(primary.map((lead) => lead.id));
  const seen = new Set<string>();
  const primaryWithContacts = primary.map((lead) => ({ ...lead }));
  const unmatched: import("./types").Lead[] = [];
  for (const lead of extra) {
    if (ids.has(lead.id) || seen.has(lead.id)) continue;
    seen.add(lead.id);
    const name = normalise(lead.name);
    const known = primaryWithContacts.find((candidate) => {
      if (normalise(candidate.name) !== name) return false;
      if (
        digits(candidate.phone) &&
        digits(candidate.phone) === digits(lead.phone)
      ) {
        return true;
      }
      if (
        candidate.address &&
        lead.address &&
        normalise(candidate.address) === normalise(lead.address)
      ) {
        return true;
      }
      return nearby(candidate, lead);
    });
    if (!known) {
      unmatched.push(lead);
      continue;
    }
    // Same business, different directory: retain Overture's identity and score,
    // but fill its blank contact fields with the map's live community updates.
    known.email ??= lead.email;
    known.phone ??= lead.phone;
    known.website ??= lead.website;
    const links = [...(known.socialLinks ?? []), ...(lead.socialLinks ?? [])];
    known.socialLinks = [
      ...new Map(links.map((link) => [link.url, link])).values(),
    ];
    known.social ??= known.socialLinks[0]?.url ?? lead.social;
  }
  return { primary: primaryWithContacts, extra: unmatched };
}

function digits(value: string | null): string {
  return value?.replace(/\D/g, "") ?? "";
}

// Overture's aggregates cover its complete match set, not just the page. Add
// only the new OSM rows here; counting `combined` would quietly turn totals into
// the page size whenever a city has more than the requested limit.
function supplementaryRows(
  combined: import("./types").Lead[],
  primary: import("./types").Lead[],
) {
  const ids = new Set(primary.map((lead) => lead.id));
  return combined.filter((lead) => !ids.has(lead.id));
}

function supplementalCount(
  combined: import("./types").Lead[],
  primary: import("./types").Lead[],
  test: (lead: import("./types").Lead) => boolean,
): number {
  return supplementaryRows(combined, primary).filter(test).length;
}

function nearby(a: import("./types").Lead, b: import("./types").Lead): boolean {
  if (a.lat === null || a.lon === null || b.lat === null || b.lon === null)
    return false;
  // 0.0007° is roughly 80m. Requiring the same name keeps this deliberately
  // conservative in malls and commercial streets.
  return Math.hypot(a.lat - b.lat, a.lon - b.lon) <= 0.0007;
}

function plural(count: number, one: string, many: string): string {
  return count === 1 ? one : many;
}

function clamp(n: number, lo: number, hi: number): number {
  const v = Number(n);
  if (!Number.isFinite(v)) return lo;
  return Math.min(hi, Math.max(lo, v));
}
