import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { after, before, beforeEach, describe, it } from "node:test";

/**
 * Whose message a lead actually receives, exercised against a real database.
 *
 * The rule is not expressible as a pure function: it is "your row beats the
 * team's row beats the code", decided by two SQL reads and a transaction that
 * must leave exactly one row active per person per slot. So every test here
 * drives the real statements.
 *
 * PROSPECTOR_DB has to be set before db.ts is imported — it reads it when the
 * connection is first opened — hence the dynamic imports inside `before`.
 */

let store: typeof import("./templates-store");
let db: typeof import("./db");
let dir: string;

const ANA = { id: "u1", displayName: "Ana" };
const BRUNO = { id: "u2", displayName: "Bruno" };

const SLOT = { intent: "cliente" as const, speaks: "pt" as const };

before(async () => {
  dir = mkdtempSync(path.join(tmpdir(), "templates-test-"));
  process.env.PROSPECTOR_DB = path.join(dir, "prospector.db");
  db = await import("./db");
  store = await import("./templates-store");
});

after(() => rmSync(dir, { recursive: true, force: true }));

beforeEach(() => {
  const handle = db.getDb();
  handle.exec("DELETE FROM outreach_template_uses");
  handle.exec("DELETE FROM outreach_template_notes");
  handle.exec("DELETE FROM outreach_templates");
  handle.exec("DELETE FROM leads");
  handle
    .prepare(
      `INSERT INTO leads (id, name, category, country, city, uf, confidence, score, status)
       VALUES ('l1', 'Padaria Sao Jorge', 'barber', 'BR', 'Belo Horizonte', 'MG', 0.9, 70, 'respondeu')`,
    )
    .run();
});

const write = (
  ownerId: string | null,
  body: string,
  author = ANA,
  activate = true,
) =>
  store.createTemplate(
    { ownerId, ...SLOT, name: body.slice(0, 12), body, activate },
    author,
  );

describe("whose message wins", () => {
  it("falls through to the code when nobody has written anything", () => {
    assert.deepEqual(store.activeTemplates(ANA.id), {});
  });

  it("gives everyone the team's copy until they write their own", () => {
    write(null, "Do time.");
    assert.equal(store.activeTemplates(ANA.id)["cliente:pt"], "Do time.");
    assert.equal(store.activeTemplates(BRUNO.id)["cliente:pt"], "Do time.");
  });

  it("gives one person their own and leaves everybody else alone", () => {
    write(null, "Do time.");
    write(ANA.id, "Da Ana.", ANA);

    assert.equal(store.activeTemplates(ANA.id)["cliente:pt"], "Da Ana.");
    assert.equal(store.activeTemplates(BRUNO.id)["cliente:pt"], "Do time.");
    // No viewer at all — a CSV with no session behind it — gets the team's,
    // never whichever personal row happened to sort first.
    assert.equal(store.activeTemplates()["cliente:pt"], "Do time.");
  });

  it("never shows one operator another operator's copy", () => {
    write(ANA.id, "Da Ana.", ANA);
    write(BRUNO.id, "Do Bruno.", BRUNO);

    const seen = store.listTemplates(ANA.id).map((t) => t.body);
    assert.deepEqual(seen, ["Da Ana."]);
    assert.equal(
      store.findTemplate(store.listTemplates(BRUNO.id)[0].id, ANA.id),
      null,
    );
  });
});

describe("exactly one active per person per slot", () => {
  it("retires only the same owner's previous message", () => {
    const team = write(null, "Do time.");
    const first = write(ANA.id, "Primeira da Ana.", ANA);
    const second = write(ANA.id, "Segunda da Ana.", ANA);

    const rows = store.listTemplates(ANA.id);
    assert.equal(rows.find((t) => t.id === second)?.active, true);
    assert.equal(rows.find((t) => t.id === first)?.active, false);
    // The team's row is a different owner and must not have been switched off
    // by Ana activating hers — the bug a plain `owner_id = ?` would have.
    assert.equal(rows.find((t) => t.id === team)?.active, true);
    assert.equal(store.activeTemplates(BRUNO.id)["cliente:pt"], "Do time.");
  });

  it("releases a slot back to the team without losing the text", () => {
    write(null, "Do time.");
    write(ANA.id, "Da Ana.", ANA);

    assert.equal(store.releaseSlot(ANA.id, "cliente", "pt"), true);
    assert.equal(store.activeTemplates(ANA.id)["cliente:pt"], "Do time.");
    // Kept, not deleted: somebody who reverts on Tuesday wants it back Thursday.
    assert.equal(store.listTemplates(ANA.id).length, 2);
  });

  it("refuses to delete the message that is going out", () => {
    const id = write(ANA.id, "Da Ana.", ANA);
    assert.equal(store.deleteTemplate(id), "ativa");
    store.releaseSlot(ANA.id, "cliente", "pt");
    assert.equal(store.deleteTemplate(id), "ok");
  });
});

describe("readings", () => {
  it("files a send under the sender's own message, not the team's", () => {
    const team = write(null, "Do time.");
    const ana = write(ANA.id, "Da Ana.", ANA);

    store.recordTemplateUse({
      leadId: "l1",
      actorId: ANA.id,
      channel: "whatsapp",
    });
    store.recordTemplateUse({
      leadId: "l1",
      actorId: BRUNO.id,
      channel: "whatsapp",
    });

    const rows = store.listTemplates(ANA.id);
    assert.equal(rows.find((t) => t.id === ana)?.stats.sends, 1);
    assert.equal(rows.find((t) => t.id === team)?.stats.sends, 1);
    // The lead answered, so both rows count it — the join is to the lead's
    // status, which is a fact about the business and not about the sender.
    assert.equal(rows.find((t) => t.id === ana)?.stats.replied, 1);
  });

  it("records nothing while a slot is still on the built-in opener", () => {
    store.recordTemplateUse({
      leadId: "l1",
      actorId: ANA.id,
      channel: "whatsapp",
    });
    assert.equal(store.listTemplates(ANA.id).length, 0);
  });

  it("keeps notes with the message they are about", () => {
    const id = write(ANA.id, "Da Ana.", ANA);
    store.addTemplateNote(id, "Duas respostas num dia.", ANA);

    const [row] = store.listTemplates(ANA.id);
    assert.equal(row.notes.length, 1);
    assert.equal(row.notes[0].authorName, "Ana");
  });
});
