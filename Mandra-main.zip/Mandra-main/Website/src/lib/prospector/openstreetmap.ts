import type { City } from "./cities";
import type { Lead } from "./types";

/**
 * A narrow, additive OpenStreetMap source.
 *
 * Overture remains the principal catalogue; OSM is independently maintained and
 * occasionally holds a small local business that the larger feed has missed.
 * The query is deliberately limited to tags that correspond to a selected
 * campaign — querying every named map object in a city would overload a shared
 * public Overpass instance and produce irrelevant rows.
 */
type Tag = readonly [key: string, value: string];

const TAGS: Record<string, readonly Tag[]> = {
  barbearias: [
    ["shop", "hairdresser"],
    ["barber", "yes"],
  ],
  "saloes-beleza": [
    ["shop", "hairdresser"],
    ["shop", "beauty"],
  ],
  manicure: [["beauty", "nails"]],
  "estetica-spa": [
    ["leisure", "spa"],
    ["beauty", "yes"],
  ],
  tatuagem: [["shop", "tattoo"]],
  restaurantes: [["amenity", "restaurant"]],
  bares: [["amenity", "bar"]],
  pizzarias: [["cuisine", "pizza"]],
  hamburguerias: [
    ["cuisine", "burger"],
    ["amenity", "fast_food"],
  ],
  padarias: [["shop", "bakery"]],
  cafeterias: [["amenity", "cafe"]],
  "sorveterias-sucos": [["amenity", "ice_cream"]],
  "culinaria-internacional": [
    ["cuisine", "japanese"],
    ["cuisine", "italian"],
  ],
  odontologia: [["amenity", "dentist"]],
  "clinicas-medicas": [
    ["amenity", "clinic"],
    ["amenity", "doctors"],
  ],
  fisioterapia: [["healthcare", "physiotherapist"]],
  psicologia: [["healthcare", "psychotherapist"]],
  imobiliarias: [["office", "estate_agent"]],
  arquitetura: [["office", "architect"]],
  "engenharia-construcao": [
    ["office", "engineer"],
    ["craft", "builder"],
  ],
  academias: [["leisure", "fitness_centre"]],
  pilates: [["sport", "pilates"]],
  oficinas: [["shop", "car_repair"]],
  "estetica-automotiva": [["amenity", "car_wash"]],
  concessionarias: [["shop", "car"]],
  "pet-shops": [["shop", "pet"]],
  veterinarios: [["amenity", "veterinary"]],
  advocacia: [["office", "lawyer"]],
  contabilidade: [["office", "accountant"]],
  escolas: [["amenity", "school"]],
  "cursos-idiomas": [["amenity", "language_school"]],
  autoescolas: [["amenity", "driving_school"]],
  "escolas-especializadas": [
    ["amenity", "music_school"],
    ["leisure", "dance"],
  ],
};

type Element = {
  type: "node" | "way" | "relation";
  id: number;
  lat?: number;
  lon?: number;
  center?: { lat?: number; lon?: number };
  tags?: Record<string, string>;
};

const ENDPOINTS = [
  "https://overpass-api.de/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter",
];

export async function queryOpenStreetMap(input: {
  city: City;
  niche: string;
  limit: number;
}): Promise<Lead[]> {
  const tags = TAGS[input.niche];
  if (!tags?.length) return [];

  const { xmin, xmax, ymin, ymax } = input.city.bbox;
  // Overpass uses south, west, north, east. The tag list is constant code, not
  // user input, so it cannot alter the query's shape.
  const bbox = `${ymin},${xmin},${ymax},${xmax}`;
  const selectors = tags
    .map(([key, value]) => `nwr["name"]["${key}"="${value}"](${bbox});`)
    .join("\n  ");
  const query = `[out:json][timeout:25];\n(\n  ${selectors}\n);\nout center tags;`;

  let lastError: unknown;
  for (const endpoint of ENDPOINTS) {
    const controller = new AbortController();
    // This source is a bonus, never permission to turn a fast local Overture
    // search into a long wait. A second mirror gets a chance after 12 seconds.
    const timeout = setTimeout(() => controller.abort(), 12_000);
    try {
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "content-type": "text/plain;charset=UTF-8" },
        body: query,
        signal: controller.signal,
      });
      if (!response.ok) throw new Error(`Overpass ${response.status}`);
      const data = (await response.json()) as { elements?: Element[] };
      return (data.elements ?? [])
        .slice(0, input.limit)
        .map((element) => toLead(element, input.city));
    } catch (error) {
      lastError = error;
    } finally {
      clearTimeout(timeout);
    }
  }
  throw lastError instanceof Error
    ? lastError
    : new Error("Overpass indisponível.");
}

function toLead(element: Element, city: City): Lead {
  const tags = element.tags ?? {};
  const lat = element.lat ?? element.center?.lat ?? null;
  const lon = element.lon ?? element.center?.lon ?? null;
  const phone = tags["contact:phone"] ?? tags.phone ?? null;
  const website = tags["contact:website"] ?? tags.website ?? null;
  const socialLinks = collectSocialLinks(tags);
  const address =
    [tags["addr:street"], tags["addr:housenumber"], tags["addr:postcode"]]
      .filter(Boolean)
      .join(", ") || null;

  return {
    id: `osm:${element.type}:${element.id}`,
    source: "openstreetmap",
    name: tags.name?.trim() || "(sem nome)",
    category:
      tags.amenity ??
      tags.shop ??
      tags.office ??
      tags.leisure ??
      tags.craft ??
      null,
    address,
    city: tags["addr:city"] ?? city.name,
    uf: city.uf,
    phone,
    website,
    social: socialLinks[0]?.url ?? null,
    socialLinks,
    email: tags["contact:email"] ?? tags.email ?? null,
    lat,
    lon,
    // Named, locally mapped POIs are usually real, but the source does not
    // expose Overture's evidence model, so never let it outrank a strong record.
    confidence: 0.7,
  };
}

/** OSM keeps contacts in both generic and `contact:` namespaces. Keep every
 * useful network instead of silently choosing the first Instagram/Facebook tag. */
function collectSocialLinks(tags: Record<string, string>) {
  const networks = [
    ["instagram", "Instagram"],
    ["facebook", "Facebook"],
    ["linkedin", "LinkedIn"],
    ["tiktok", "TikTok"],
    ["youtube", "YouTube"],
    ["telegram", "Telegram"],
    ["threads", "Threads"],
    ["bluesky", "Bluesky"],
    ["pinterest", "Pinterest"],
    ["snapchat", "Snapchat"],
    ["discord", "Discord"],
    ["twitter", "X / Twitter"],
    ["x", "X / Twitter"],
  ] as const;
  const seen = new Set<string>();
  const links = [] as { platform: string; url: string }[];
  for (const [key, platform] of networks) {
    const value = tags[`contact:${key}`] ?? tags[key];
    const url = socialUrl(key, value);
    if (url && !seen.has(url)) {
      seen.add(url);
      links.push({ platform, url });
    }
  }
  return links;
}

function socialUrl(network: string, raw: string | undefined): string | null {
  const value = raw?.trim();
  if (!value) return null;
  if (/^https?:\/\//i.test(value)) return value;
  // Mappers often use a username rather than a full URL. Turn only simple
  // handles into links; arbitrary tag values must never become clickable URLs.
  const handle = value.replace(/^@/, "");
  if (!/^[A-Za-z0-9._-]{1,100}$/.test(handle)) return null;
  const hosts: Record<string, string> = {
    instagram: "instagram.com",
    facebook: "facebook.com",
    linkedin: "linkedin.com/in",
    tiktok: "tiktok.com/@",
    youtube: "youtube.com/@",
    telegram: "t.me",
    threads: "threads.net/@",
    bluesky: "bsky.app/profile",
    pinterest: "pinterest.com",
    snapchat: "snapchat.com/add",
    discord: "discord.gg",
    twitter: "x.com",
    x: "x.com",
  };
  const host = hosts[network];
  return host ? `https://${host}/${handle}` : null;
}
