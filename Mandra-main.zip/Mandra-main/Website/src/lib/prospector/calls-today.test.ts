import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { after, before, describe, it } from "node:test";

/**
 * The daily call counter, against a real database file.
 *
 * The counter is a number people are measured by, so the things worth pinning
 * are the ways it could quietly lie: counting yesterday's calls as today's,
 * mixing two operators together, calling an unanswered dial "atendida", or
 * counting a skip — which is not a call at all — as work done.
 *
 * PROSPECTOR_DB has to be set before db.ts is imported, hence the dynamic
 * imports inside `before`.
 */

let calls: typeof import("./calls");
let db: typeof import("./db");
let dir: string;

const ANA = { id: "u-ana", displayName: "Ana" };
const BRUNO = { id: "u-bruno", displayName: "Bruno" };

function seed(id: string, name: string): void {
  db.getDb()
    .prepare(
      `INSERT INTO leads (id, name, phone, country, city, uf, confidence, score, search_norm)
       VALUES (?, ?, '+5531987911222', 'BR', 'Belo Horizonte', 'MG', 0.9, 70, ?)`,
    )
    .run(id, name, name.toLowerCase());
}

before(async () => {
  dir = mkdtempSync(path.join(tmpdir(), "calls-today-test-"));
  process.env.PROSPECTOR_DB = path.join(dir, "prospector.db");
  db = await import("./db");
  calls = await import("./calls");
  for (const n of [1, 2, 3, 4]) seed(`l${n}`, `Negocio ${n}`);
});

after(() => rmSync(dir, { recursive: true, force: true }));

describe("callsToday", () => {
  it("is empty before anybody dials", () => {
    assert.deepEqual(calls.callsToday(), []);
    assert.deepEqual(calls.callsTodayTotal(), {
      calls: 0,
      reached: 0,
      leads: 0,
      operators: 0,
    });
  });

  it("counts each dial, and only counts a human as reached", () => {
    calls.recordCall({ leadId: "l1", outcome: "interessado", actor: ANA });
    calls.recordCall({ leadId: "l2", outcome: "nao_atendeu", actor: ANA });
    calls.recordCall({ leadId: "l3", outcome: "caixa_postal", actor: ANA });

    const [ana] = calls.callsToday(ANA.id);
    assert.equal(ana.calls, 3);
    // Only "interessado" spoke to somebody; the other two are the phone ringing.
    assert.equal(ana.reached, 1);
    assert.equal(ana.leads, 3);
    assert.equal(ana.actorDisplayName, "Ana");
  });

  it("counts a retried lead twice as a call and once as a lead", () => {
    calls.recordCall({ leadId: "l2", outcome: "nao_atendeu", actor: ANA });

    const [ana] = calls.callsToday(ANA.id);
    assert.equal(ana.calls, 4);
    // l2 was dialled twice. Four attempts against three businesses is exactly
    // the distinction the queue's attempt limit is built on.
    assert.equal(ana.leads, 3);
  });

  it("keeps operators apart, and sums them for the team", () => {
    calls.recordCall({ leadId: "l4", outcome: "fechado", actor: BRUNO });

    const [bruno] = calls.callsToday(BRUNO.id);
    assert.equal(bruno.calls, 1);
    assert.equal(bruno.reached, 1);

    const everyone = calls.callsToday();
    assert.equal(everyone.length, 2);
    // Ordered by calls desc, so the busiest operator leads the breakdown.
    assert.equal(everyone[0].actorDisplayName, "Ana");

    const team = calls.callsTodayTotal();
    assert.equal(team.calls, 5);
    assert.equal(team.reached, 2);
    assert.equal(team.operators, 2);
  });

  it("ignores calls from another day", () => {
    const before = calls.callsTodayTotal().calls;

    // Written straight to the log, because there is no way to record a call in
    // the past through `recordCall` — which is correct, and is also why this has
    // to be checked at all: the counter's date fold is the only thing standing
    // between yesterday's work and today's number.
    db.getDb()
      .prepare(
        `INSERT INTO lead_calls (lead_id, actor_id, actor_display_name, outcome, occurred_at)
         VALUES ('l1', ?, 'Ana', 'interessado', datetime('now', '-1 day'))`,
      )
      .run(ANA.id);

    assert.equal(calls.callsTodayTotal().calls, before);
  });

  it("does not count a skip", () => {
    const before = calls.callsTodayTotal().calls;

    const list = calls.createCallList({
      name: "Fila",
      leadIds: ["l1", "l2"],
      actor: ANA,
      sourceQuery: null,
    })!;
    calls.skipItem(list.id, "l1");

    // Nothing was dialled, so nothing may appear in the day's count. Storing a
    // skip as an outcome would inflate every operator's number for free.
    assert.equal(calls.callsTodayTotal().calls, before);
  });
});
