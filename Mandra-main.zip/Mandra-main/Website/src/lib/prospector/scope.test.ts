import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { after, before, describe, it } from "node:test";

/**
 * The tenancy boundary, exercised against a real database file.
 *
 * This is the one rule in the CRM whose failure is silent and unbounded: a
 * client reading another client's pipeline produces no error, no empty screen
 * and no log line — just somebody else's leads, rendered as if they were
 * theirs. Every other test here protects a number; this one protects the
 * product being sellable at all.
 *
 * So it tests the *predicate*, not the pages. Pages come and go, and the next
 * screen someone adds will call `queryHistory` or `allMatching` without reading
 * this file — which is exactly why the scope is a required field on
 * HistoryFilters rather than an optional one, and why the assertions below are
 * about what SQL returns rather than about what a component renders.
 *
 * PROSPECTOR_DB must be set before db.ts is imported: it reads the path when the
 * connection is first opened. Hence the dynamic imports inside `before`.
 */

let history: typeof import("./history");
let db: typeof import("./db");
let dir: string;

const ATLAS = "Padaria Sao Jorge";
const CLIENTE_A = "Clinica Martins";
const CLIENTE_B = "Salao Bela";

function seed(id: string, name: string, accountId: string | null): void {
  db.getDb()
    .prepare(
      `INSERT INTO leads (id, name, account_id, phone, country, city, uf,
                          confidence, score, search_norm)
       VALUES (?, ?, ?, '+5531987911222', 'BR', 'Belo Horizonte', 'MG', 0.9, 70, ?)`,
    )
    .run(id, name, accountId, name.toLowerCase());
}

before(async () => {
  dir = mkdtempSync(path.join(tmpdir(), "scope-test-"));
  process.env.PROSPECTOR_DB = path.join(dir, "prospector.db");
  db = await import("./db");
  history = await import("./history");

  seed("l1", ATLAS, null);
  seed("l2", CLIENTE_A, "conta-a");
  seed("l3", CLIENTE_B, "conta-b");
});

after(() => rmSync(dir, { recursive: true, force: true }));

const names = (leads: { name: string }[]) => leads.map((l) => l.name).sort();

describe("LeadScope", () => {
  it("shows us everything, ours and the clients'", () => {
    const page = history.queryHistory({ scope: history.SCOPE_TUDO });
    assert.equal(page.total, 3);
    assert.deepEqual(names(page.leads), [CLIENTE_A, ATLAS, CLIENTE_B].sort());
  });

  it("separates our own base from the clients' when we ask it to", () => {
    const page = history.queryHistory({ scope: history.SCOPE_ATLAS });
    assert.equal(page.total, 1);
    assert.deepEqual(names(page.leads), [ATLAS]);
  });

  it("shows a client only their own leads", () => {
    const page = history.queryHistory({
      scope: { kind: "conta", id: "conta-a" },
    });
    assert.equal(page.total, 1);
    assert.deepEqual(names(page.leads), [CLIENTE_A]);
  });

  it("counts the total inside the scope, not over the table", () => {
    // The pagination total is its own COUNT query, so it can disagree with the
    // rows it heads — which reads as "you have 3 leads" above a list of one.
    const page = history.queryHistory({
      scope: { kind: "conta", id: "conta-b" },
      perPage: 1,
    });
    assert.equal(page.total, 1);
    assert.equal(page.pages, 1);
  });

  it("scopes the unpaginated export too", () => {
    // allMatching() is the CSV, which is the whole base in one file. It shares
    // where() with the table precisely so it cannot answer a wider question.
    const rows = history.allMatching({
      scope: { kind: "conta", id: "conta-a" },
    });
    assert.deepEqual(names(rows), [CLIENTE_A]);
  });

  it("cannot be widened from the query string", () => {
    // A client's session arrives as a `conta` scope. Everything below is a URL
    // they can type, and none of it may reach another account's rows.
    const mine: import("./history").LeadScope = {
      kind: "conta",
      id: "conta-a",
    };

    for (const conta of ["conta-b", "atlas", "", "tudo"]) {
      const filters = history.parseFilters({ conta }, mine);
      assert.deepEqual(
        filters.scope,
        mine,
        `?conta=${conta} must not change a client's scope`,
      );
      assert.deepEqual(names(history.allMatching(filters)), [CLIENTE_A]);
    }
  });

  it("lets us narrow to one client from the query string", () => {
    const filters = history.parseFilters(
      { conta: "conta-b" },
      history.SCOPE_TUDO,
    );
    assert.deepEqual(names(history.allMatching(filters)), [CLIENTE_B]);
  });

  it("narrows to our own base with ?conta=atlas", () => {
    const filters = history.parseFilters(
      { conta: "atlas" },
      history.SCOPE_TUDO,
    );
    assert.deepEqual(filters.scope, history.SCOPE_ATLAS);
    assert.deepEqual(names(history.allMatching(filters)), [ATLAS]);
  });

  it("keeps the account in the round-tripped query string", () => {
    // Dropping it here is how the admin's third click silently lands back on
    // everybody's leads while the heading still names one client.
    const filters = history.parseFilters(
      { conta: "conta-a", status: "novo" },
      history.SCOPE_TUDO,
    );
    const query = history.filtersToQuery(filters, { page: 2 });
    assert.ok(query.includes("conta=conta-a"), query);

    const round = history.parseFilters(
      Object.fromEntries(new URLSearchParams(query.replace(/^\?/, ""))),
      history.SCOPE_TUDO,
    );
    assert.deepEqual(round.scope, { kind: "conta", id: "conta-a" });
  });

  it("an unknown account matches nothing rather than everything", () => {
    const rows = history.allMatching({
      scope: { kind: "conta", id: "nao-existe" },
    });
    assert.deepEqual(rows, []);
  });
});

describe("idsInScope", () => {
  it("keeps only the ids the scope may touch", () => {
    assert.deepEqual(
      history.idsInScope(["l1", "l2", "l3"], { kind: "conta", id: "conta-a" }),
      ["l2"],
    );
  });

  it("passes everything through for us", () => {
    assert.deepEqual(
      history.idsInScope(["l1", "l2", "l3"], history.SCOPE_TUDO),
      ["l1", "l2", "l3"],
    );
  });

  it("refuses another account's lead by id", () => {
    // The mutation routes' guard. A client's browser can post any id it likes;
    // this is the answer that stops it becoming an edit.
    assert.equal(
      history.leadInScope("l3", { kind: "conta", id: "conta-a" }),
      false,
    );
    assert.equal(
      history.leadInScope("l2", { kind: "conta", id: "conta-a" }),
      true,
    );
  });

  it("treats our own leads as out of scope for a client", () => {
    assert.equal(
      history.leadInScope("l1", { kind: "conta", id: "conta-a" }),
      false,
    );
  });

  it("is empty for an empty selection rather than unbounded", () => {
    assert.deepEqual(history.idsInScope([], history.SCOPE_TUDO), []);
  });
});
