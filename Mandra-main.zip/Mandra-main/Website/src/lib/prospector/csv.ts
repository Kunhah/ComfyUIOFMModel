import { normalisePhone, outreachMessage, whatsappUrl } from "./score";
import { outreachContextFor } from "./templates-store";
import type { OutreachContext } from "./templates";
import type { ScoredLead, StoredLead } from "./types";

/**
 * Either kind of row. The board exports plain scored leads; the history export
 * adds the stored bookkeeping columns, so the getters have to tolerate both.
 */
type ExportLead = ScoredLead & Partial<Omit<StoredLead, keyof ScoredLead>>;

/**
 * One CSV writer, shared by the board export (rows posted back from the browser)
 * and the history export (rows read straight out of SQLite). They produced the
 * same file by coincidence when the column list lived inside the route handler;
 * this is what makes that a guarantee.
 */

/**
 * Columns are typed so numbers stay numbers. The formula-injection guard below
 * prefixes a value with an apostrophe, which is right for free text but turns a
 * coordinate or a score into a text cell you then can't sort or chart.
 */
type Column = {
  header: string;
  kind: "text" | "number";
  /**
   * `outreach` is the opener in force for whoever asked for the file, plus
   * their name. Only the whatsapp_link column reads it, but it is on every
   * getter rather than captured in a closure: a column list that reaches out
   * to a module-level variable is one whose output depends on when the file
   * was imported.
   */
  get: (lead: ExportLead, outreach: OutreachContext) => string;
};

const COLUMNS: Column[] = [
  { header: "nome", kind: "text", get: (l) => l.name },
  { header: "fonte", kind: "text", get: (l) => l.source ?? "overture" },
  { header: "categoria", kind: "text", get: (l) => l.category ?? "" },
  { header: "endereco", kind: "text", get: (l) => l.address ?? "" },
  { header: "cidade", kind: "text", get: (l) => l.city ?? "" },
  { header: "uf", kind: "text", get: (l) => l.uf ?? "" },
  // ISO-3166 alpha-2. Rows saved before the prospector left Brazil carry none
  // and are Brazilian, which is what every reader assumes of them.
  { header: "pais", kind: "text", get: (l) => l.country ?? "BR" },
  // E.164 digits with no leading "+". The plus makes Excel read the cell as a
  // formula, and the usual apostrophe fix leaves a visible quote in every other
  // tool. Digits are unambiguous, sort cleanly, and paste straight into a dialer.
  {
    header: "telefone",
    kind: "text",
    get: (l) => normalisePhone(l.phone, l.country) ?? "",
  },
  {
    header: "whatsapp",
    kind: "text",
    get: (l) => (l.whatsapp ? "sim" : "nao"),
  },
  // The actually useful artefact: click it and the conversation is open with the
  // opener already typed, in the language the country is likely to answer in.
  {
    header: "whatsapp_link",
    kind: "text",
    get: (l, outreach) =>
      whatsappUrl(
        l.phone,
        outreachMessage(l, undefined, outreach),
        l.country,
      ) ?? "",
  },
  { header: "site", kind: "text", get: (l) => l.website ?? "" },
  // Semicolons, matching redes_sociais below — a comma would need quoting in
  // every row and reads as a new column the moment someone opens it in Excel.
  {
    header: "etiquetas",
    kind: "text",
    get: (l) => (l.tags ?? []).join("; "),
  },
  {
    header: "redes_sociais",
    kind: "text",
    get: (l) =>
      (l.socialLinks?.map((s) => s.url) ?? [l.social ?? ""])
        .filter(Boolean)
        .join("; "),
  },
  { header: "email", kind: "text", get: (l) => l.email ?? "" },
  { header: "score", kind: "number", get: (l) => String(l.score) },
  { header: "sinais", kind: "text", get: (l) => (l.reasons ?? []).join("; ") },
  {
    header: "confianca",
    kind: "number",
    get: (l) =>
      typeof l.confidence === "number" ? l.confidence.toFixed(3) : "",
  },
  {
    header: "latitude",
    kind: "number",
    get: (l) => (l.lat === null ? "" : String(l.lat)),
  },
  {
    header: "longitude",
    kind: "number",
    get: (l) => (l.lon === null ? "" : String(l.lon)),
  },
  { header: "overture_id", kind: "text", get: (l) => l.id },
];

/**
 * Extra columns for the history export — the outreach state, which only exists
 * for rows that came out of the database.
 */
const HISTORY_COLUMNS: Column[] = [
  { header: "etapa_funil", kind: "text", get: (l) => l.funnelStage ?? "" },
  { header: "status", kind: "text", get: (l) => l.status ?? "" },
  { header: "contato_nome", kind: "text", get: (l) => l.contactName ?? "" },
  // Semicolon-joined rather than one column per network: the set of networks a
  // lead has is open-ended, and a column that is empty for 95% of rows is worse
  // than a list you can read.
  {
    header: "redes_sociais",
    kind: "text",
    get: (l) => (l.socials ?? []).map((s) => s.url).join("; "),
  },
  { header: "contatado_em", kind: "text", get: (l) => l.contactedAt ?? "" },
  {
    header: "proximo_follow_up",
    kind: "text",
    get: (l) => l.nextFollowUpAt ?? "",
  },
  { header: "anotacoes", kind: "text", get: (l) => l.notes ?? "" },
  { header: "primeiro_visto", kind: "text", get: (l) => l.firstSeenAt ?? "" },
  { header: "ultimo_visto", kind: "text", get: (l) => l.lastSeenAt ?? "" },
  { header: "nicho_busca", kind: "text", get: (l) => l.niche ?? "" },
];

/**
 * `viewer` is who asked for the file, so the wa.me links carry their opener
 * and their name. Optional, and absent means the team's copy — which is the
 * right answer for a caller with no session behind it.
 */
export type CsvOptions = {
  includeHistory?: boolean;
  viewer?: { id: string; displayName: string; role?: string } | null;
};

export function buildCsv(
  leads: ExportLead[],
  options: CsvOptions = {},
): string {
  const columns = options.includeHistory
    ? [...COLUMNS, ...HISTORY_COLUMNS]
    : COLUMNS;

  // Once per file, not once per row: the export is the one caller that hands
  // out a thousand wa.me links at a time, and each of them has to carry the
  // opener that is live right now — a CSV is opened days after it was made.
  // Whose opener depends on who asked; `viewer` absent is the team\'s.
  const outreach = outreachContextFor(options.viewer ?? null);

  const lines = [
    columns.map((c) => quote(c.header)).join(","),
    ...leads.map((lead) =>
      columns
        .map((c) => {
          const value = c.get(lead, outreach) ?? "";
          // Numbers are ours, never user text — emit bare so spreadsheets type them.
          return c.kind === "number" ? value : quote(guard(value));
        })
        .join(","),
    ),
  ];

  // Excel in a pt-BR locale won't detect UTF-8 without a BOM and mangles every
  // accented business name. The BOM is what makes the export usable there.
  return "\ufeff" + lines.join("\r\n");
}

export function csvResponse(
  leads: ExportLead[],
  filename: string,
  options: CsvOptions = {},
): Response {
  return new Response(buildCsv(leads, options), {
    headers: {
      "content-type": "text/csv; charset=utf-8",
      "content-disposition": `attachment; filename="${safeFilename(filename)}.csv"`,
    },
  });
}

/**
 * A CSV of plain text cells: the escaping, the formula guard and the BOM,
 * without the lead-shaped column list above.
 *
 * For the exports that aren't leads — the operator audit trail — so they can't
 * quietly reinvent the quoting or ship a file Excel mangles the accents in.
 */
export function textCsvResponse(
  headers: string[],
  rows: string[][],
  filename: string,
  options: { bom?: boolean } = {},
): Response {
  const lines = [
    headers.map(quote).join(","),
    ...rows.map((row) => row.map((cell) => quote(guard(cell ?? ""))).join(",")),
  ];
  // The BOM is what makes Excel read accents correctly and is right for every
  // file a person opens. It is wrong for a file a machine parses: the ad
  // platforms' uploaders read it as part of the first header name, so "email"
  // arrives as an unrecognised column and the whole upload matches on nothing.
  const bom = options.bom === false ? "" : "\ufeff";
  return new Response(bom + lines.join("\r\n"), {
    headers: {
      "content-type": "text/csv; charset=utf-8",
      "content-disposition": `attachment; filename="${safeFilename(filename)}.csv"`,
    },
  });
}

export function safeFilename(name: string): string {
  return (
    name
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-zA-Z0-9._-]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 80) || "leads"
  );
}

/**
 * A leading =, +, - or @ makes Excel and Sheets evaluate the cell as a formula.
 * A business genuinely named "+55 Barbearia" would otherwise execute rather than
 * display. Only applied to text columns.
 */
function guard(value: string): string {
  return /^[=+\-@\t\r]/.test(value) ? `'${value}` : value;
}

function quote(value: string): string {
  return `"${value.replace(/"/g, '""')}"`;
}
