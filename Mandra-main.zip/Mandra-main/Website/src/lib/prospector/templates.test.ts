import test from "node:test";
import assert from "node:assert/strict";
import {
  DEFAULT_BODIES,
  TEMPLATE_SLOTS,
  bodyFor,
  namesTheSender,
  render,
  slotOf,
} from "./templates";

const LEAD = {
  name: "Studio Bela Arte",
  contactName: "Marina",
  city: "Belo Horizonte",
  uf: "MG",
};

test("a token resolves to the lead's own field", () => {
  assert.equal(
    render("Oi [nome], vi o [negócio] em [cidade].", LEAD, "pt"),
    "Oi Marina, vi o Studio Bela Arte em Belo Horizonte.",
  );
});

test("an empty token takes the punctuation stranded behind it", () => {
  // The case that made the tidy pass exist: most leads have no contact name,
  // and "Oi ! Tudo bem?" tells the reader they are one of a thousand.
  assert.equal(
    render("Oi [nome]! Tudo bem?", { ...LEAD, contactName: null }, "pt"),
    "Oi! Tudo bem?",
  );
  assert.equal(
    render("¡Hola [nome]! ¿Qué tal?", { ...LEAD, contactName: "" }, "es"),
    "¡Hola! ¿Qué tal?",
  );
});

test("a nameless business still reads as a sentence, in its own language", () => {
  const blank = { ...LEAD, name: "" };
  assert.equal(
    render("Tava olhando o [negócio] de vocês.", blank, "pt"),
    "Tava olhando o negócio de vocês.",
  );
  assert.equal(
    render("I was looking at [negócio].", blank, "en"),
    "I was looking at your business.",
  );
});

test("an unknown token is left exactly as it was typed", () => {
  // Swallowing it would make a misspelling disappear silently, and the
  // operator would find out from the prospect.
  assert.equal(render("Olá [negocios]!", LEAD, "pt"), "Olá [negocios]!");
});

test("paragraph breaks survive; a token that was a whole line does not", () => {
  assert.equal(
    render("Primeira.\n\n[nome]\n\nSegunda.", { contactName: null }, "pt"),
    "Primeira.\n\nSegunda.",
  );
});

test("an edited body wins over the default, and only when it has text", () => {
  const slot = slotOf("cliente", "pt");
  assert.equal(bodyFor(slot, { [slot]: "Nova." }), "Nova.");
  assert.equal(bodyFor(slot, { [slot]: "   " }), DEFAULT_BODIES[slot]);
  assert.equal(bodyFor(slot, {}), DEFAULT_BODIES[slot]);
});

test("every slot ships with an opener, and none is a stub", () => {
  // A missing default is a slot that renders an empty WhatsApp message, and it
  // would only be found by whoever sent one.
  assert.equal(TEMPLATE_SLOTS.length, 6);
  for (const slot of TEMPLATE_SLOTS) {
    assert.ok(DEFAULT_BODIES[slot]?.trim().length > 40, slot);
  }
});

test("the client opener asks for the call; the partner one never pitches", () => {
  assert.match(DEFAULT_BODIES["cliente:pt"], /15 min/);
  assert.match(DEFAULT_BODIES["parceiro:pt"], /parceria/);
  assert.doesNotMatch(DEFAULT_BODIES["parceiro:pt"], /captam cliente/);
});

test("[meu-nome] is filled from the sender and closes up without one", () => {
  const body = "Aqui é [meu-nome], da Mandra.";
  assert.equal(
    render(body, { ...LEAD, senderName: "Ana" }, "pt"),
    "Aqui é Ana, da Mandra.",
  );
  assert.equal(namesTheSender(body), true);
  // The editor warns about exactly this on the team's copy: the client portal
  // renders it with nobody to name.
  assert.equal(namesTheSender("Oi [nome], tudo bem?"), false);
});

test("[estado] rides along with the city, and a missing one shows", () => {
  assert.equal(
    render("Negócio em [cidade]/[estado].", LEAD, "pt"),
    "Negócio em Belo Horizonte/MG.",
  );
  // The tidy pass closes whitespace, not sentences: "/." is what an empty
  // token leaves here, and the editor's hint says to write the phrase so it
  // survives. Pinned rather than papered over — inventing punctuation rules
  // would make the renderer unpredictable for the person who typed the line.
  assert.equal(
    render("Negócio em [cidade]/[estado].", { ...LEAD, uf: null }, "pt"),
    "Negócio em Belo Horizonte/.",
  );
});
