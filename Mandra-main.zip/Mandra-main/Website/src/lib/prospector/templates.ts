import type { NicheIntent } from "./niches";

/**
 * The outreach openers, as text an operator can edit.
 *
 * They used to be six string literals inside `outreachMessage()`, which made
 * every change to the pitch a deploy — and the pitch is the one thing in this
 * tool that should change weekly. The people who send the message are the ones
 * who learn what it should say, so the copy moved out of the code and into a
 * table they can write to; see `templates-store.ts` for where the edited
 * versions live and `outreachMessage()` in score.ts for who reads them.
 *
 * This module stays pure and database-free on purpose: `score.ts` is imported
 * by client components, and a `node:sqlite` import anywhere in that graph
 * breaks the bundle. The store is server-only and hands its result in.
 */

/** The language an opener is written in. Mirrors `speaks` in lib/countries.ts. */
export type TemplateLanguage = "pt" | "es" | "en";

export const TEMPLATE_LANGUAGES: TemplateLanguage[] = ["pt", "es", "en"];

export const LANGUAGE_LABEL: Record<TemplateLanguage, string> = {
  pt: "Português",
  es: "Espanhol",
  en: "Inglês",
};

export const INTENT_LABEL: Record<NicheIntent, string> = {
  cliente: "Cliente",
  parceiro: "Parceiro",
};

export const INTENT_HINT: Record<NicheIntent, string> = {
  cliente: "Negócios para quem a gente vende site, landing page e automação.",
  parceiro:
    "Gente para trabalhar junto — agência, gestor de tráfego. Não é venda.",
};

/**
 * Which opener a lead gets: what it is to us, and the language it answers in.
 *
 * One slot per pair rather than one template per country. A German machine shop
 * reading English is a normal cold e-mail and one reading Portuguese is spam —
 * that distinction is worth a template. "Munich vs Hamburg" is not.
 */
export type TemplateSlot = `${NicheIntent}:${TemplateLanguage}`;

export const TEMPLATE_SLOTS: TemplateSlot[] = (
  ["cliente", "parceiro"] as NicheIntent[]
).flatMap((intent) =>
  TEMPLATE_LANGUAGES.map((speaks): TemplateSlot => `${intent}:${speaks}`),
);

export function slotOf(
  intent: NicheIntent,
  speaks: TemplateLanguage,
): TemplateSlot {
  return `${intent}:${speaks}`;
}

export function isTemplateSlot(value: unknown): value is TemplateSlot {
  return (
    typeof value === "string" && (TEMPLATE_SLOTS as string[]).includes(value)
  );
}

/**
 * The bodies currently in force, by slot. A slot the operators never touched is
 * absent and falls back to `DEFAULT_BODIES` — so an empty table sends exactly
 * what the code used to send, and deleting every row is a safe way back.
 */
export type TemplateSet = Partial<Record<TemplateSlot, string>>;

/* -------------------------------------------------------------------------- */
/* Placeholders                                                                */
/* -------------------------------------------------------------------------- */

/**
 * The tokens an operator may write, in the bracket form the pitch was handed to
 * us in — `[nome]`, `[negócio]`. Curly braces would have been the programmer's
 * choice; brackets are what the person writing the message already types, and
 * the editor lists them next to the box.
 *
 * Every token resolves to something readable when the lead has no value for it.
 * That is the whole reason the fallback is per language: "Tava olhando o
 * [negócio] de vocês" has to survive a business whose name we never got, and
 * "Tava olhando o de vocês" is how a cold opener announces it was generated.
 */
export type Placeholder = {
  token: string;
  /** Accepted spellings, all lowercase and without the brackets. */
  aliases: string[];
  label: string;
  hint: string;
};

export const PLACEHOLDERS: Placeholder[] = [
  {
    token: "[nome]",
    aliases: ["nome", "contato"],
    label: "Nome da pessoa",
    hint: "Só existe depois que alguém digitou o contato no CRM. Sem ele o token some e a saudação se fecha sozinha.",
  },
  {
    token: "[negócio]",
    aliases: ["negócio", "negocio", "empresa"],
    label: "Nome do negócio",
    hint: "O nome como o provedor cadastrou. Sempre presente, na prática.",
  },
  {
    token: "[cidade]",
    aliases: ["cidade"],
    label: "Cidade do negócio",
    hint: "Vazio quando a fonte não trouxe cidade — escreva a frase de forma que ela sobreviva a isso.",
  },
  {
    token: "[estado]",
    aliases: ["estado", "uf"],
    label: "Estado (UF)",
    hint: "Duas letras, como vem da fonte. Fora do Brasil quase sempre vem vazio.",
  },
  {
    // The token that only makes sense now that each person has their own
    // message: a shared opener could not sign itself without lying on five
    // out of six sends.
    token: "[meu-nome]",
    aliases: ["meu-nome", "meu nome", "remetente"],
    label: "Seu nome",
    hint: "Quem está enviando — o nome da sua conta. Assina a mensagem sem você digitar.",
  },
];

/** What `[negócio]` becomes when the lead has no name we can print. */
const BUSINESS_FALLBACK: Record<TemplateLanguage, string> = {
  // Deliberately the bare noun: the Portuguese default reads "o [negócio] de
  // vocês", and only a bare noun survives that article.
  pt: "negócio",
  es: "su negocio",
  en: "your business",
};

/* -------------------------------------------------------------------------- */
/* Defaults                                                                    */
/* -------------------------------------------------------------------------- */

/**
 * The opener that ships with the tool, per slot.
 *
 * The client openers are short on purpose. The long version — who we are, what
 * we do, a free demo, "posso te mostrar?" — read as a brochure, and a brochure
 * on WhatsApp is deleted before the second paragraph. This one says what was
 * looked at, what it is about, and asks for a specific, small commitment with a
 * question the reader can answer in three words.
 *
 * The three languages are the same message, not three messages. They drift the
 * moment one of them is edited in the code and the others are not, which is
 * most of why they are editable in the CRM now: the person changing the pitch
 * can see all three side by side.
 */
export const DEFAULT_BODIES: Record<TemplateSlot, string> = {
  "cliente:pt":
    "Oi [nome]! Tudo bem? Tava olhando o [negócio] de vocês e me surgiu uma ideia que pode fazer diferença na forma como vocês captam cliente.\n\n" +
    "Posso te mostrar em 15 min numa call? Qual dia fica melhor pra você?",

  "cliente:es":
    "¡Hola [nome]! ¿Qué tal? Estuve mirando [negócio] y se me ocurrió una idea que puede cambiar la forma en que consiguen clientes.\n\n" +
    "¿Se la muestro en una llamada de 15 min? ¿Qué día le viene mejor?",

  "cliente:en":
    "Hi [nome]! How are you? I was looking at [negócio] and had an idea that could make a real difference to how you bring in new customers.\n\n" +
    "Could I show you on a 15-minute call? What day works best for you?",

  // The partner openers stay long, and the length is the point: a gestor de
  // tráfego reads "encontrei sua empresa e olhei sua presença na internet" as
  // the pitch they themselves send out forty times a week. The only thing that
  // makes this different from spam is that it names the trade immediately and
  // offers something in the direction they are short of — so it has to say all
  // of that before it asks for anything.
  "parceiro:pt":
    "Olá! Tudo bem? Sou da Mandra — a gente desenvolve sites, landing pages e automações para pequenos negócios.\n\n" +
    "Estou chamando vocês do [negócio] para falar de parceria, não para vender nada. Quando um cliente de vocês precisa de site ou de uma página decente para a campanha cair, a gente entrega no prazo; quando um cliente nosso pede tráfego pago e gestão de campanha, indicamos vocês.\n\n" +
    "Comissão por indicação nos dois sentidos, sem exclusividade.\n\n" +
    "Faz sentido conversarmos 15 minutos?",

  "parceiro:es":
    "¡Hola! ¿Qué tal? Le escribo de Mandra: desarrollamos sitios web, landing pages y automatizaciones para pequeños negocios.\n\n" +
    "Escribo al equipo de [negócio] para proponer una alianza, no para vender nada. Cuando un cliente suyo necesita un sitio o una página donde aterrizar la campaña, lo entregamos a tiempo; cuando un cliente nuestro pide gestión de campañas y tráfico de pago, los recomendamos a ustedes.\n\n" +
    "Comisión por referencia en ambos sentidos, sin exclusividad.\n\n" +
    "¿Tiene sentido hablar 15 minutos?",

  "parceiro:en":
    "Hello! I'm writing from Mandra — we build websites, landing pages and automations for small businesses.\n\n" +
    "I'm reaching out to the team at [negócio] about a partnership, not to sell anything. When one of your clients needs a site, or a decent page for a campaign to land on, we deliver it on time; when one of ours asks for paid traffic and campaign management, we point them at you.\n\n" +
    "Referral commission both ways, no exclusivity.\n\n" +
    "Would fifteen minutes make sense?",
};

/** The body in force for a slot: the edited one, or the one that ships. */
export function bodyFor(slot: TemplateSlot, templates?: TemplateSet): string {
  const edited = templates?.[slot]?.trim();
  return edited && edited.length > 0 ? edited : DEFAULT_BODIES[slot];
}

/* -------------------------------------------------------------------------- */
/* Rendering                                                                   */
/* -------------------------------------------------------------------------- */

/**
 * The fields a template may name. A subset of `Lead` rather than the type
 * itself, so the preview in the editor can render from a made-up business
 * without inventing coordinates and a confidence score.
 */
export type TemplateLead = {
  name?: string | null;
  /** The person at the business, typed in the CRM. Absent on most leads. */
  contactName?: string | null;
  city?: string | null;
  uf?: string | null;
};

/**
 * Everything a template can name, which is the lead plus the one thing that is
 * not about the lead at all: who is sending it.
 *
 * `senderName` arrives from the session, never from the row, because the same
 * stored body is rendered by whoever opens the screen — and a message that
 * signs itself with the name of the person who *wrote* it is worse than one
 * that does not sign itself at all.
 */
export type RenderContext = TemplateLead & { senderName?: string | null };

/**
 * What a server hands to `outreachMessage()`: the bodies in force for the
 * person looking, and their name.
 *
 * One value rather than two parameters because it travels a long way — from
 * the page that reads it, through the row mapper or the panel props, down to a
 * client component — and two things that must stay together should be one
 * thing by the time they are passed around.
 */
export type OutreachContext = {
  templates?: TemplateSet;
  senderName?: string | null;
};

/** Cap on a body, generous enough for the partner opener and its variants. */
export const MAX_BODY_LENGTH = 2000;

/** The tokens that resolve from the session rather than from the lead. */
const SENDER_ALIASES = ["meu-nome", "meu nome", "remetente"];

/**
 * Does this body name the sender?
 *
 * Asked only of the team's copy, and only by the editor. A personal message
 * always has a sender behind it; the team's is also rendered for the client
 * portal, where there is deliberately nobody to name — and "Aqui é, da Mandra"
 * is a sentence a real prospect would receive.
 */
export function namesTheSender(body: string): boolean {
  return [...body.matchAll(/\[([^\]\n]{1,24})\]/g)].some((match) =>
    SENDER_ALIASES.includes(match[1].trim().toLowerCase()),
  );
}

/**
 * Fills a template in for one lead.
 *
 * The tidy-up afterwards is not cosmetic. A token that resolves to nothing
 * leaves the punctuation that followed it stranded — "Oi ! Tudo bem?" — and a
 * message that visibly failed to fill a blank is worse than one that never had
 * the blank, because it tells the reader they are one of a thousand.
 */
export function render(
  body: string,
  lead: RenderContext,
  speaks: TemplateLanguage,
): string {
  const values: Record<string, string> = {
    nome: (lead.contactName ?? "").trim(),
    negócio: (lead.name ?? "").trim() || BUSINESS_FALLBACK[speaks],
    cidade: (lead.city ?? "").trim(),
    estado: (lead.uf ?? "").trim(),
    "meu-nome": (lead.senderName ?? "").trim(),
  };

  const filled = body.replace(/\[([^\]\n]{1,24})\]/g, (whole, raw: string) => {
    const key = raw.trim().toLowerCase();
    for (const placeholder of PLACEHOLDERS) {
      if (placeholder.aliases.includes(key)) {
        return values[placeholder.aliases[0]] ?? "";
      }
    }
    // An unknown token is left exactly as typed. Swallowing it would make a
    // misspelled "[negocios]" disappear silently, and the operator would only
    // find out from the prospect.
    return whole;
  });

  return tidy(filled);
}

/**
 * Closes the gaps an empty token leaves, without touching anything else.
 *
 * Only whitespace is moved: no sentence is re-cased and no punctuation is
 * invented, because the operator wrote this text and a renderer that edits it
 * is a renderer nobody can predict.
 */
function tidy(text: string): string {
  return (
    text
      .split("\n")
      .map((line) =>
        line
          // "Oi ! Tudo bem?" -> "Oi! Tudo bem?". Also catches the Spanish
          // opening marks, which sit before the word rather than after it.
          .replace(/\s+([!?.,;:])/g, "$1")
          .replace(/([¡¿])\s+/g, "$1")
          .replace(/[ \t]{2,}/g, " ")
          .trim(),
      )
      .join("\n")
      // A blank line is a paragraph break; three of them is a token that used to
      // be a whole line.
      .replace(/\n{3,}/g, "\n\n")
      .trim()
  );
}
