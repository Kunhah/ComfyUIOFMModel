/** A business as we store and display it, normalised from whatever provider found it. */
export type Lead = {
  /** Provider-stable id. Overture GERS ids are stable across releases, so this doubles as the dedupe key. */
  id: string;
  /**
   * Which source produced this record. `cnpj` is the Receita Federal's company
   * registry — the only one of these that is a legal register rather than a
   * business directory, which is why it is the only one with no `website` field
   * to report. See `KNOWS_WEBSITE` in score.ts.
   */
  source?: "overture" | "openstreetmap" | "geoapify" | "formulario" | "cnpj";
  name: string;
  category: string | null;
  /** Street address as a single line, e.g. "Rua Caramuru, 272". */
  address: string | null;
  city: string | null;
  /** State/province code, e.g. "MG" or "BY". Null where the source gives none. */
  uf: string | null;
  /**
   * ISO-3166 alpha-2 of the country the business sits in. Null only on rows
   * saved before the tool left Brazil; every reader treats null as "BR", which
   * is what those rows are.
   */
  country?: string | null;
  /** E.164, e.g. "+5531987911222". */
  phone: string | null;
  website: string | null;
  /** Best social profile, retained for compatibility with older extracts. */
  social: string | null;
  /** Every social profile the source exposed, including newer networks. */
  socialLinks?: SocialLink[];
  email: string | null;
  lat: number | null;
  lon: number | null;
  /** Provider's own 0–1 confidence that this record is real and current. */
  confidence: number;
};

/** A lead with our qualification verdict attached. */
export type ScoredLead = Lead & {
  /** 0–100. Higher means it needs what Mandra sells more badly and is easier to reach. */
  score: number;
  /** Short pt-BR phrases explaining the score, for display on the row. */
  reasons: string[];
  /**
   * True when the phone is a mobile in its own country's numbering plan, so
   * wa.me will actually resolve. False for landlines, and for every number in a
   * country whose plan doesn't let us tell the two apart — see `mobile` in
   * src/lib/countries.ts.
   */
  whatsapp: boolean;
  /**
   * Not in the local history before this search. Absent when the history write
   * failed, so the board can distinguish "not new" from "don't know".
   */
  isNew?: boolean;
  /**
   * When somebody here already reached out, from the local history. Absent or
   * null means nobody has — and it is a different question from `isNew`: a
   * business found six months ago and never phoned is neither new nor contacted.
   * Read next to every contact button, so a second first-contact is a decision
   * rather than an accident.
   */
  contactedAt?: string | null;
  /** Dials logged against the lead, ever. Zero when the contact was a message. */
  attempts?: number;
  /**
   * The operator the lead belongs to. Declared here as well as on `StoredLead`
   * so a live search result can carry it — the two must stay the same shape,
   * since `StoredLead` extends this.
   */
  owner?: { id: string; name: string } | null;
  /**
   * Where the deal stands, when the local history knows. Absent on a business
   * we have never touched. Read next to the contact controls so a closed or
   * lost lead says so — see `CLOSED_STAGES`.
   */
  funnelStage?: FunnelStage;
};

/**
 * Where a business sits in the marketing funnel.
 *
 * A different question from `status`, which records what happened to the
 * outreach ("did they answer?"). This records how far the deal has come, which
 * is what you sort a week's work by. The two are kept consistent — moving a lead
 * down the funnel updates its status, see `setFunnelStage` — because the
 * prospector's own board still reads `status` and must not disagree with the CRM.
 */
export type FunnelStage =
  | "descoberta"
  | "contato"
  | "qualificado"
  | "proposta"
  | "negociacao"
  | "fechado"
  | "perdido";

export const FUNNEL_STAGES: FunnelStage[] = [
  "descoberta",
  "contato",
  "qualificado",
  "proposta",
  "negociacao",
  "fechado",
  "perdido",
];

export const FUNNEL_LABEL: Record<FunnelStage, string> = {
  descoberta: "Descoberta",
  contato: "Contato feito",
  qualificado: "Qualificado",
  proposta: "Proposta enviada",
  negociacao: "Negociação",
  fechado: "Fechado",
  perdido: "Perdido",
};

/**
 * The outreach status each stage implies, so the two fields can never contradict
 * each other. `perdido` maps to `descartado` and `fechado` to `cliente`; the
 * three middle stages all mean the conversation is live.
 */
export const STAGE_STATUS: Record<FunnelStage, LeadStatus> = {
  descoberta: "novo",
  contato: "contatado",
  qualificado: "respondeu",
  proposta: "respondeu",
  negociacao: "respondeu",
  fechado: "cliente",
  perdido: "descartado",
};

/**
 * The stages where the conversation is over: they bought, or they said no.
 *
 * Derived from `STAGE_STATUS` rather than written out, for the same reason
 * `REACHED_LIST` is derived from `OUTCOME_REACHED`: a stage added to the funnel
 * and forgotten here would quietly re-enter the calling queue, and nothing about
 * a won customer being cold-pitched again reports itself as a bug.
 *
 * Read by the queue, which never draws one, and by every contact control, which
 * says so before it is pressed. Not a block — an existing customer is exactly
 * who you sometimes want to phone — but never something to do by accident.
 */
export const CLOSED_STAGES: FunnelStage[] = FUNNEL_STAGES.filter(
  (stage) =>
    STAGE_STATUS[stage] === "cliente" || STAGE_STATUS[stage] === "descartado",
);

export function isClosedStage(stage: FunnelStage | null | undefined): boolean {
  return stage != null && CLOSED_STAGES.includes(stage);
}

/** A social profile kept on the lead. Free-form: whatever the business uses. */
export type SocialLink = {
  /** Derived from the URL's host — instagram, facebook, linkedin, … */
  platform: string;
  url: string;
};

/** Outreach state. Mirrors the CHECK constraint on `leads.status`. */
export type LeadStatus =
  "novo" | "contatado" | "respondeu" | "cliente" | "descartado";

export const LEAD_STATUSES: LeadStatus[] = [
  "novo",
  "contatado",
  "respondeu",
  "cliente",
  "descartado",
];

/**
 * A lead read back out of the local history, carrying the bookkeeping the live
 * search can't know: when you first saw it and where it is in your pipeline.
 */
export type StoredLead = ScoredLead & {
  /**
   * The client account the lead belongs to, or null for Atlas's own — which is
   * every lead the prospector found. Read-only here: a lead is stamped with an
   * account when a client's site produces it, and nothing moves one afterwards.
   */
  accountId: string | null;
  status: LeadStatus;
  /** The niche whose search first surfaced it. */
  niche: string | null;
  searchedCity: string | null;
  searchedUf: string | null;
  firstSeenAt: string;
  lastSeenAt: string;
  /** When the next follow-up is due, in YYYY-MM-DD form. */
  nextFollowUpAt: string | null;
  /** First time we recorded an actual outreach attempt. */
  contactedAt: string | null;
  /** Free-text note typed in the CRM — what was said, what to try next. */
  notes: string | null;
  /** Where the deal sits. Never null: an unworked lead is at `descoberta`. */
  funnelStage: FunnelStage;
  /** Profiles added by hand in the CRM, alongside the one the provider found. */
  socials: SocialLink[];
  /** The person we actually talk to at the business. */
  contactName: string | null;
  /**
   * The operator who contacted this lead first, and to whom it now belongs.
   * Null until somebody has actually reached out. Nobody else may contact it
   * from then on — the rule, and the admin's way to undo it, are in
   * `ownership.ts`.
   */
  owner: { id: string; name: string } | null;
  /**
   * Free-text labels the operator groups by — their own axis, alongside the
   * niche (what the business is) and the stage (how far the deal has come).
   * The rules live in `tags.ts`; never empty strings, never duplicated.
   */
  tags: string[];
};

export type SearchScope = "city" | "state" | "region" | "country";

export type SearchRequest = {
  niche: string;
  /** Defaults to city so old bookmarks and API clients keep working. */
  scope?: SearchScope;
  city?: string;
  uf?: string;
  /** Brazilian macro-region slug (`sudeste`, `sul`, ...). */
  region?: string;
  /**
   * ISO-3166 alpha-2 of the country to search in. Defaults to Brazil, so links
   * and saved searches made before the tool left Brazil still resolve.
   */
  country?: string;
  /**
   * Only return businesses with no website — the default, since that's the
   * sellable pool.
   *
   * Ignored by a `parceiro` niche, which forces it off: see `performSearch`.
   */
  onlyWithoutWebsite?: boolean;
  minConfidence?: number;
  limit?: number;
  /** Supplement Overture with OpenStreetMap's live mapped businesses (on by default). */
  includeOpenStreetMap?: boolean;
  /**
   * Write what was found to the local history. On by default — that is what
   * makes "novo" mean anything and what the CRM reads.
   *
   * Turning it off is for exploring: counting how many dentists a city has, or
   * trying six niches to see which is worth a campaign, without any of it
   * entering the pipeline. Nothing is written at all, so a lead found this way
   * still reports as new the first time it is found with saving on.
   */
  save?: boolean;
};

export type SearchResponse = {
  leads: ScoredLead[];
  /**
   * Counted across every match, not just the returned page — `leads` is capped
   * by the request's `limit`.
   */
  stats: {
    /** Businesses matched before the no-website filter. */
    total: number;
    withoutWebsite: number;
    withPhone: number;
    withWhatsapp: number;
    /** How many rows `leads` actually holds. */
    returned: number;
    elapsedMs: number;
    /** Unique supplementary businesses found in OpenStreetMap for this search. */
    fromOpenStreetMap?: number;
    /** Unique supplementary businesses found in Geoapify, when configured. */
    fromGeoapify?: number;
    /** Unique professionals found in the Receita's register. Partner searches only. */
    fromCnpj?: number;
  };
  /**
   * Local history outcome, so the UI can say what was new vs already known.
   * The ids themselves stay server-side — each lead already carries `isNew`.
   *
   * Null when the write failed *and* when the search asked not to save; `saved`
   * is what tells those two apart.
   */
  persisted?: { inserted: number; alreadyKnown: number } | null;
  /** False when the search ran with history off, so the board can say so. */
  saved: boolean;
  warnings: string[];
};

/* -------------------------------------------------------------------------- */
/* Cold calling                                                                */
/* -------------------------------------------------------------------------- */

/**
 * What happened on one call.
 *
 * A third question, alongside `status` ("what happened to the outreach") and
 * `funnel_stage` ("how far has the deal come"): this one is per *attempt*, and a
 * lead has as many of them as it has been dialled. It has to be its own record
 * rather than another column, because the useful things — "how many dials to
 * reach a dentist", "which operator's calls convert" — are questions about the
 * attempts, and a column only ever remembers the last one.
 *
 * The stage each outcome implies is `OUTCOME_STAGE`; whether it is actually
 * applied depends on `OUTCOME_TERMINAL` and the stage the lead is already at.
 */
export type CallOutcome =
  /** Spoke to someone and they want to hear more. */
  | "interessado"
  /** Spoke to someone and they don't. The end of the line. */
  | "sem_interesse"
  /** Reached them, wrong moment — call back, same conversation. */
  | "retornar"
  /** Rang out. Nobody was reached, so nothing was learned about the business. */
  | "nao_atendeu"
  /** Voicemail, or a receptionist who took a message. */
  | "caixa_postal"
  /** Dead line, fax, wrong business. The number is the problem, not the lead. */
  | "numero_invalido"
  /** Closed on the call. Rare and worth its own outcome. */
  | "fechado";

export const CALL_OUTCOMES: CallOutcome[] = [
  "interessado",
  "retornar",
  "nao_atendeu",
  "caixa_postal",
  "sem_interesse",
  "numero_invalido",
  "fechado",
];

export const CALL_OUTCOME_LABEL: Record<CallOutcome, string> = {
  interessado: "Atendeu — interessado",
  retornar: "Atendeu — pediu retorno",
  nao_atendeu: "Não atendeu",
  caixa_postal: "Caixa postal / recado",
  sem_interesse: "Sem interesse",
  numero_invalido: "Número inválido",
  fechado: "Fechou na ligação",
};

/**
 * Short forms for the queue's buttons, where the row already says whose call it
 * is and the long label wraps to two lines on every one of seven buttons.
 */
export const CALL_OUTCOME_SHORT: Record<CallOutcome, string> = {
  interessado: "Interessado",
  retornar: "Retornar",
  nao_atendeu: "Não atendeu",
  caixa_postal: "Caixa postal",
  sem_interesse: "Sem interesse",
  numero_invalido: "Número inválido",
  fechado: "Fechou",
};

/** True when someone actually spoke to a human. The rest are dial attempts. */
export const OUTCOME_REACHED: Record<CallOutcome, boolean> = {
  interessado: true,
  retornar: true,
  sem_interesse: true,
  fechado: true,
  nao_atendeu: false,
  caixa_postal: false,
  numero_invalido: false,
};

/**
 * The funnel stage each outcome argues for.
 *
 * Only ever *applied* when it moves the lead forward, or when the outcome is
 * terminal — see `OUTCOME_TERMINAL`. A lead in `negociacao` that doesn't pick up
 * the phone is still in negociacao; letting `nao_atendeu` write its stage back
 * to `contato` would erase a month of work with one missed call.
 */
export const OUTCOME_STAGE: Record<CallOutcome, FunnelStage> = {
  interessado: "qualificado",
  retornar: "contato",
  nao_atendeu: "contato",
  caixa_postal: "contato",
  sem_interesse: "perdido",
  numero_invalido: "perdido",
  fechado: "fechado",
};

/**
 * Outcomes that end the conversation and so are written even when they move the
 * lead backwards. "Sem interesse" from a lead in `proposta` is exactly the case
 * the forward-only rule must not swallow.
 */
export const OUTCOME_TERMINAL: Record<CallOutcome, boolean> = {
  interessado: false,
  retornar: false,
  nao_atendeu: false,
  caixa_postal: false,
  sem_interesse: true,
  numero_invalido: true,
  fechado: true,
};

/**
 * Ranking used by the forward-only rule. Index in FUNNEL_STAGES would be wrong:
 * `perdido` sits last there and is not "further along" than anything.
 */
export const STAGE_RANK: Record<FunnelStage, number> = {
  descoberta: 0,
  contato: 1,
  qualificado: 2,
  proposta: 3,
  negociacao: 4,
  fechado: 5,
  perdido: 0,
};

/**
 * What the operator decided to do next — the pipeline half of the answer.
 *
 * Separate from the outcome because the same outcome routes differently: an
 * interested lead may be worth a video call, or just a proposal by e-mail, and
 * that is a judgement made on the call rather than something derivable from it.
 * A step that implies a further stage carries it in `NEXT_STEP_STAGE`, subject to
 * the same forward-only rule as the outcome's.
 */
export type NextStep =
  | "nenhum"
  | "nova_ligacao"
  | "videochamada"
  | "reuniao_presencial"
  | "enviar_proposta"
  | "enviar_material";

export const NEXT_STEPS: NextStep[] = [
  "nova_ligacao",
  "videochamada",
  "reuniao_presencial",
  "enviar_proposta",
  "enviar_material",
  "nenhum",
];

export const NEXT_STEP_LABEL: Record<NextStep, string> = {
  nenhum: "Nenhum",
  nova_ligacao: "Nova ligação",
  videochamada: "Videochamada",
  reuniao_presencial: "Reunião presencial",
  enviar_proposta: "Enviar proposta",
  enviar_material: "Enviar material",
};

/** The stage a next step implies, where it implies one. */
export const NEXT_STEP_STAGE: Partial<Record<NextStep, FunnelStage>> = {
  videochamada: "qualificado",
  reuniao_presencial: "qualificado",
  enviar_proposta: "proposta",
};

/**
 * How many days out the follow-up lands when the operator doesn't pick a date.
 *
 * `null` means the step schedules nothing: a lost lead and a lead with no next
 * step must both leave the daily queue, or the queue stops being a list of work
 * and becomes a list of everything.
 */
export const NEXT_STEP_DEFAULT_DAYS: Record<NextStep, number | null> = {
  nenhum: null,
  nova_ligacao: 3,
  videochamada: 2,
  reuniao_presencial: 5,
  enviar_proposta: 1,
  enviar_material: 1,
};

/** One recorded call attempt. */
export type CallLog = {
  id: number;
  leadId: string;
  /** The list it was dialled from, or null for a call placed off a lead page. */
  listId: number | null;
  actorId: string;
  actorDisplayName: string;
  outcome: CallOutcome;
  nextStep: NextStep;
  /** What was said. The single most valuable field on the next call. */
  notes: string | null;
  /** The number as dialled, E.164 — the lead's phone may be edited later. */
  phone: string | null;
  occurredAt: string;
};

/** A named, ordered queue of leads to work through. */
export type CallList = {
  id: number;
  name: string;
  createdById: string;
  createdByName: string;
  createdAt: string;
  /** The filter query the list was built from, for the "rebuild" affordance. */
  sourceQuery: string | null;
  total: number;
  done: number;
  skipped: number;
  pending: number;
};

/** One position in a call list, joined to the lead it points at. */
export type CallQueueItem = {
  listId: number;
  leadId: string;
  position: number;
  state: "pendente" | "concluido" | "pulado";
  /** The lead as the queue screen needs it — not the full StoredLead. */
  lead: StoredLead;
  /** Every call already recorded against this lead, newest first. */
  history: CallLog[];
};
