import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { after, before, describe, it } from "node:test";

/**
 * The funnel board and the call-result stats, against a real database file.
 *
 * The things worth pinning are the ones a board gets quietly wrong: reporting
 * the card cap as the size of a stage, hiding a stage because it is empty,
 * counting a twice-dialled lead as two businesses, dividing by a zero that has
 * not happened yet — and, now that leads carry an account, showing one tenant's
 * pipeline on another's board.
 */

let funnel: typeof import("./funnel");
let calls: typeof import("./calls");
let history: typeof import("./history");
let db: typeof import("./db");
let dir: string;

const ACTOR = { id: "u1", displayName: "Ana" };

function seed(
  id: string,
  name: string,
  extra: {
    niche?: string;
    account?: string | null;
    score?: number;
    inFunnel?: boolean;
  } = {},
): void {
  db.getDb()
    .prepare(
      // `phone_norm` is folded on write by every real writer; the fixture does
      // it by hand so the board's phone search is tested against the shape of
      // row it will actually meet.
      `INSERT INTO leads (id, name, phone, phone_norm, country, city, uf,
                          confidence, score, search_norm, niche, account_id,
                          in_funnel)
       VALUES (?, ?, '+5531987911222', '5531987911222', 'BR', 'Belo Horizonte',
               'MG', 0.9, ?, ?, ?, ?, ?)`,
    )
    .run(
      id,
      name,
      extra.score ?? 70,
      name.toLowerCase(),
      extra.niche ?? "barbearias",
      extra.account ?? null,
      extra.inFunnel ? 1 : 0,
    );
}

before(async () => {
  dir = mkdtempSync(path.join(tmpdir(), "funnel-test-"));
  process.env.PROSPECTOR_DB = path.join(dir, "prospector.db");
  db = await import("./db");
  calls = await import("./calls");
  history = await import("./history");
  funnel = await import("./funnel");

  seed("l1", "Barbearia Um", { score: 90 });
  seed("l2", "Barbearia Dois", { score: 80, inFunnel: true });
  seed("l3", "Padaria Tres", {
    niche: "padarias",
    score: 70,
    inFunnel: true,
  });
  // Belongs to a client account, not to Atlas.
  seed("l4", "Cliente Quatro", {
    account: "acc-1",
    score: 95,
    inFunnel: true,
  });
});

after(() => rmSync(dir, { recursive: true, force: true }));

describe("funnelBoard", () => {
  it("returns every stage, including the empty ones", () => {
    const { columns } = funnel.funnelBoard({ scope: history.SCOPE_ATLAS });
    assert.equal(columns.length, 7);
    assert.deepEqual(
      columns.map((c) => c.stage),
      [
        "descoberta",
        "contato",
        "qualificado",
        "proposta",
        "negociacao",
        "fechado",
        "perdido",
      ],
    );
    // An empty stage is the informative one; it must not be dropped.
    assert.equal(columns.find((c) => c.stage === "proposta")!.total, 0);
  });

  it("only shows leads manually included in the funnel", () => {
    const before = funnel.funnelBoard({ scope: history.SCOPE_ATLAS });
    const ids = before.columns.flatMap((column) =>
      column.cards.map((card) => card.id),
    );
    assert.ok(!ids.includes("l1"));

    history.setFunnelMembership("l1", true);
    const after = funnel.funnelBoard({ scope: history.SCOPE_ATLAS });
    assert.equal(
      after.columns.find((column) => column.stage === "descoberta")!.cards[0]
        .id,
      "l1",
    );

    history.setFunnelMembership("l1", false);
    const removed = funnel.funnelBoard({ scope: history.SCOPE_ATLAS });
    assert.ok(
      !removed.columns.some((column) =>
        column.cards.some((card) => card.id === "l1"),
      ),
    );

    // The later call-card test uses the same fixture.
    history.setFunnelMembership("l1", true);
  });

  it("finds only leads that are available to add", () => {
    history.setFunnelMembership("l1", false);
    assert.deepEqual(
      funnel.funnelCandidates("Barbearia Um").map((lead) => lead.id),
      ["l1"],
    );

    // Clicking a call/message action uses this same writer: it should make the
    // lead disappear from the add picker and enter the contact column.
    history.recordOutreach("l1");
    assert.deepEqual(funnel.funnelCandidates("Barbearia Um"), []);
    assert.equal(
      funnel
        .funnelBoard({ scope: history.SCOPE_ATLAS })
        .columns.find((column) => column.stage === "contato")!.cards[0].id,
      "l1",
    );

    // Restore the shared fixture for the later stage/count assertions.
    history.setFunnelStage("l1", "descoberta");
  });

  it("keeps another account's leads off Atlas's board", () => {
    const atlas = funnel.funnelBoard({ scope: history.SCOPE_ATLAS });
    const ids = atlas.columns.flatMap((c) => c.cards.map((card) => card.id));
    assert.ok(!ids.includes("l4"));
    assert.equal(atlas.columns.find((c) => c.stage === "descoberta")!.total, 3);

    // The same board for that client shows only their lead.
    const client = funnel.funnelBoard({
      scope: { kind: "conta", id: "acc-1" },
    });
    assert.deepEqual(
      client.columns.flatMap((c) => c.cards.map((card) => card.id)),
      ["l4"],
    );

    // And "tudo" sees both, which is what makes the other two meaningful.
    const all = funnel.funnelBoard({ scope: history.SCOPE_TUDO });
    assert.equal(all.columns.find((c) => c.stage === "descoberta")!.total, 4);
  });

  it("carries the last call onto the card", () => {
    calls.recordCall({ leadId: "l1", outcome: "nao_atendeu", actor: ACTOR });
    calls.recordCall({ leadId: "l1", outcome: "interessado", actor: ACTOR });

    const { columns } = funnel.funnelBoard({ scope: history.SCOPE_ATLAS });
    const card = columns.flatMap((c) => c.cards).find((c) => c.id === "l1")!;

    // The most recent outcome, not the first — it is why the card moved.
    assert.equal(card.lastOutcome, "interessado");
    assert.equal(card.attempts, 2);
    // "interessado" qualifies the lead, so the card left descoberta.
    assert.equal(
      columns.find((c) => c.stage === "qualificado")!.cards[0].id,
      "l1",
    );
  });

  it("reports the stage's real total, not the number of cards drawn", () => {
    const { columns, limit } = funnel.funnelBoard({
      scope: history.SCOPE_ATLAS,
    });
    const descoberta = columns.find((c) => c.stage === "descoberta")!;
    // Small fixture, so these agree here; the assertion that matters is that
    // the total is never *derived* from the capped card list.
    assert.equal(descoberta.total, descoberta.cards.length);
    assert.ok(limit > 0);
  });
});

describe("funnelBoard search", () => {
  const ids = (search: string) =>
    funnel
      .funnelBoard({ scope: history.SCOPE_ATLAS, search })
      .columns.flatMap((column) => column.cards.map((card) => card.id))
      .sort();

  it("narrows the board to the matching leads", () => {
    assert.deepEqual(ids("barbearia"), ["l1", "l2"]);
    assert.deepEqual(ids("padaria"), ["l3"]);
  });

  it("narrows the column totals with the cards, not only the cards", () => {
    // A header still counting the whole stage under a filtered column reads as
    // "the rest are hidden by the cap", which is a worse lie than the cap.
    const { columns } = funnel.funnelBoard({
      scope: history.SCOPE_ATLAS,
      search: "padaria",
    });
    assert.equal(
      columns.reduce((sum, column) => sum + column.total, 0),
      1,
    );
  });

  it("finds a lead by its phone number as well as its name", () => {
    assert.ok(ids("98791").includes("l2"));
    // Too few digits to be a phone; nothing on the board says "987" either.
    assert.deepEqual(ids("987"), []);
  });

  it("matches without regard to case or accents", () => {
    assert.deepEqual(ids("BARBEARIA"), ["l1", "l2"]);
    assert.deepEqual(ids("Bárbeáriá"), ["l1", "l2"]);
  });

  it("keeps another account's leads out of the results", () => {
    assert.deepEqual(ids("cliente"), []);
  });

  it("filters nothing when the box is empty", () => {
    assert.deepEqual(ids(""), ids("   "));
    assert.deepEqual(
      ids(""),
      funnel
        .funnelBoard({ scope: history.SCOPE_ATLAS })
        .columns.flatMap((column) => column.cards.map((card) => card.id))
        .sort(),
    );
  });
});

describe("the note on a card", () => {
  it("comes back on the card, written through the CRM's own writer", () => {
    // The board owns no writer of its own — the card posts to the same
    // `/api/prospector/history/notes` route the CRM table's editor uses, so
    // `setNotes` stays the one place a note is written and audited.
    history.setNotes("l2", "  ligou, chamar em janeiro  ");

    const card = funnel
      .funnelBoard({ scope: history.SCOPE_ATLAS })
      .columns.flatMap((column) => column.cards)
      .find((c) => c.id === "l2")!;
    assert.equal(card.notes, "ligou, chamar em janeiro");

    // Cleared is null, not an empty string, so "has a note" stays one check.
    history.setNotes("l2", "   ");
    assert.equal(
      funnel
        .funnelBoard({ scope: history.SCOPE_ATLAS })
        .columns.flatMap((column) => column.cards)
        .find((c) => c.id === "l2")!.notes,
      null,
    );
  });
});

describe("callResultStats", () => {
  it("counts distinct businesses rather than summing the outcome rows", () => {
    const stats = funnel.callResultStats(history.SCOPE_ATLAS);
    // l1 was dialled twice with two different outcomes. Adding the per-outcome
    // lead counts would report two businesses; there is one.
    assert.equal(stats.calls, 2);
    assert.equal(stats.leads, 1);
    assert.equal(stats.reached, 1);
    assert.equal(stats.interested, 1);
  });

  it("adds up to the calls it reports, and never divides by zero", () => {
    const stats = funnel.callResultStats(history.SCOPE_ATLAS);
    const summed = stats.byOutcome.reduce((sum, o) => sum + o.count, 0);
    assert.equal(summed, stats.calls);
    const shares = stats.byOutcome.reduce((sum, o) => sum + o.share, 0);
    assert.ok(Math.abs(shares - 1) < 1e-9);

    // An account with no calls at all is zeroes, not NaN.
    const empty = funnel.callResultStats({ kind: "conta", id: "acc-1" });
    assert.equal(empty.calls, 0);
    assert.ok(empty.byOutcome.every((o) => o.share === 0));
  });
});

describe("callStatsByNiche", () => {
  it("rates interest over who answered, not over every dial", () => {
    const [row] = funnel.callStatsByNiche(history.SCOPE_ATLAS);
    assert.equal(row.niche, "barbearias");
    assert.equal(row.calls, 2);
    assert.equal(row.reached, 1);
    // One of two dials reached a human...
    assert.equal(row.reachRate, 0.5);
    // ...and that one was interested, so interest is 1/1, not 1/2. Dividing by
    // every dial would mix "do they want it" with "is the number any good".
    assert.equal(row.interestRate, 1);
  });
});
