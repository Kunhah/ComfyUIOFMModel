import { getDb } from "./db";
import { normalise } from "./cities";
import type { LeadScope } from "./history";
import {
  CALL_OUTCOMES,
  FUNNEL_STAGES,
  OUTCOME_REACHED,
  type CallOutcome,
  type FunnelStage,
} from "./types";

/**
 * The pipeline as a board, and what the phone did to it.
 *
 * The CRM's table answers "show me the leads matching this filter" and the
 * funnel chips answer "how many are in each stage". Neither answers the question
 * a pipeline review actually asks — *what is in play right now, and what moved* —
 * which wants the stages side by side with the leads inside them.
 *
 * Everything here is read-only. Moving a card writes through the same
 * `/api/prospector/history/details` route the table's stage dropdown uses, so
 * there is exactly one writer for `funnel_stage` and the board cannot invent a
 * second meaning for a stage.
 *
 * Every query takes a `LeadScope` and none of them defaults it. These read the
 * `leads` table directly rather than going through `queryHistory`, which is the
 * exact shape of query that leaks one account's pipeline into another's board
 * if the predicate is left off — so it is a required argument, and the compiler
 * refuses a caller that forgets rather than quietly returning everything.
 */

/**
 * The scope predicate, written the same way `idsInScope` writes it: `tudo` is
 * unbounded, `atlas` is our own base, `conta` is one client's.
 */
function scopeClause(scope: LeadScope): { sql: string; params: string[] } {
  if (scope.kind === "tudo") return { sql: "", params: [] };
  if (scope.kind === "atlas")
    return { sql: "leads.account_id IS NULL", params: [] };
  return { sql: "leads.account_id = ?", params: [scope.id] };
}

/** Joins a list of SQL predicates into a WHERE clause, skipping the empty ones. */
function whereOf(...clauses: string[]): string {
  const kept = clauses.filter((c) => c.length > 0);
  return kept.length > 0 ? `WHERE ${kept.join(" AND ")}` : "";
}

/**
 * The board's free-text filter.
 *
 * Matched against `search_norm` the way the CRM table matches it — folded once
 * on write, so "Estudio" finds "Estúdio" — and widened to the two other things
 * someone types when hunting for a card: the person they spoke to, and the
 * phone number sitting in front of them. A needle that is all digits is also
 * tried against `phone_norm`, which is stored without the leading plus.
 *
 * An empty needle is no clause at all rather than a match-everything one, so
 * the unfiltered board pays nothing for the feature existing.
 */
function searchClause(search: string | null | undefined): {
  sql: string;
  params: string[];
} {
  const needle = normalise(search ?? "").slice(0, 120);
  if (needle.length === 0) return { sql: "", params: [] };

  const parts = [
    "instr(COALESCE(leads.search_norm, ''), ?) > 0",
    "instr(lower(COALESCE(leads.contact_name, '')), ?) > 0",
    "instr(lower(COALESCE(leads.city, '')), ?) > 0",
  ];
  const params = [needle, needle, needle];

  const digits = needle.replace(/[^0-9]/g, "");
  if (digits.length >= 4) {
    parts.push("instr(COALESCE(leads.phone_norm, ''), ?) > 0");
    params.push(digits);
  }

  return { sql: `(${parts.join(" OR ")})`, params };
}

/* -------------------------------------------------------------------------- */
/* The board                                                                   */
/* -------------------------------------------------------------------------- */

export type BoardCard = {
  id: string;
  name: string;
  city: string | null;
  uf: string | null;
  phone: string | null;
  score: number;
  niche: string | null;
  contactName: string | null;
  /** The CRM's free-text note, editable from the card. */
  notes: string | null;
  nextFollowUpAt: string | null;
  /** Folded against the operator's calendar day in SQL, never in the renderer. */
  followUpOverdue: boolean;
  /** Dials logged against this lead, ever. */
  attempts: number;
  /** What the most recent call did, which is usually why the card is where it is. */
  lastOutcome: CallOutcome | null;
  lastCallAt: string | null;
};

export type BoardColumn = {
  stage: FunnelStage;
  /** Every lead in the stage — not the number of cards below it. */
  total: number;
  cards: BoardCard[];
};

/**
 * How many cards one column renders.
 *
 * A cap rather than a page, and it is not a nicety: `descoberta` holds every
 * lead the harvest ever found — 395.418 of them on the machine this was written
 * for — and a board that tried to draw them would hang the browser rather than
 * show a pipeline. The header carries the true total and links to the table,
 * which is the view that can actually page through six figures.
 */
export const BOARD_COLUMN_LIMIT = 40;

export type FunnelCandidate = {
  id: string;
  name: string;
  city: string | null;
  uf: string | null;
  niche: string | null;
};

/** Atlas leads not currently on the board that an admin can add manually. */
export function funnelCandidates(
  search: string,
  limit = 20,
): FunnelCandidate[] {
  const needle = normalise(search).slice(0, 120);
  if (needle.length < 2) return [];

  return getDb()
    .prepare(
      `SELECT id, name, city, uf, niche
         FROM leads
        WHERE account_id IS NULL
          AND in_funnel = 0
          AND instr(search_norm, ?) > 0
        ORDER BY score DESC, confidence DESC
        LIMIT ?`,
    )
    .all(needle, Math.max(1, Math.min(limit, 50))) as FunnelCandidate[];
}

/**
 * Cards ordered by what makes one worth picking up next, which is the same
 * priority `QUEUE_ORDER_SQL` uses for the phone: a promised callback first, then
 * score. A board sorted by name looks tidy and buries the work.
 */
const CARD_ORDER = `
  CASE WHEN leads.next_follow_up_at IS NOT NULL
            AND leads.next_follow_up_at <= date('now','localtime')
       THEN 0 ELSE 1 END,
  leads.next_follow_up_at IS NULL,
  leads.next_follow_up_at,
  leads.score DESC,
  leads.confidence DESC`;

type CardRow = {
  id: string;
  name: string;
  city: string | null;
  uf: string | null;
  phone: string | null;
  score: number;
  niche: string | null;
  contact_name: string | null;
  notes: string | null;
  next_follow_up_at: string | null;
  follow_up_overdue: number;
  attempts: number;
  last_outcome: string | null;
  last_call_at: string | null;
};

function toCard(r: CardRow): BoardCard {
  return {
    id: r.id,
    name: r.name,
    city: r.city,
    uf: r.uf,
    phone: r.phone,
    score: Number(r.score ?? 0),
    niche: r.niche,
    contactName: r.contact_name,
    notes: r.notes,
    nextFollowUpAt: r.next_follow_up_at,
    followUpOverdue: Number(r.follow_up_overdue) === 1,
    attempts: Number(r.attempts ?? 0),
    lastOutcome: CALL_OUTCOMES.includes(r.last_outcome as CallOutcome)
      ? (r.last_outcome as CallOutcome)
      : null,
    lastCallAt: r.last_call_at,
  };
}

/**
 * One column per stage, every stage present even when empty.
 *
 * An empty column is the most informative thing on a pipeline board — nothing in
 * "proposta" is the gap you came to find — so stages are never hidden for being
 * at zero, exactly like the funnel chips they sit next to.
 *
 * The per-stage counts come from their own grouped query rather than from the
 * cards, which are capped: counting the cards would report the cap back as the
 * size of the stage, the same mistake `limit` invites everywhere else here.
 */
export function funnelBoard(options: {
  scope: LeadScope;
  niche?: string | null;
  /** Free text typed into the board's search box. Empty or absent filters nothing. */
  search?: string | null;
}): {
  columns: BoardColumn[];
  limit: number;
} {
  const db = getDb();
  const niche = options.niche ?? null;
  const scope = scopeClause(options.scope);
  const search = searchClause(options.search);
  const nicheClause = niche ? "leads.niche = ?" : "";
  const includedClause = "leads.in_funnel = 1";
  // Scope first in both the clause and the params, so the two orders cannot
  // drift apart as filters are added on the end.
  const filterParams = [
    ...scope.params,
    ...(niche ? [niche] : []),
    ...search.params,
  ];

  // The totals carry the same search predicate as the cards. A header that kept
  // counting the whole stage while the column below it showed two matches would
  // read as "38 hidden by the cap", which is a different and much worse lie than
  // the cap notice it sits next to.
  const totals = db
    .prepare(
      `SELECT leads.funnel_stage AS funnel_stage, COUNT(*) AS total
         FROM leads
         ${whereOf(includedClause, scope.sql, nicheClause, search.sql)}
        GROUP BY leads.funnel_stage`,
    )
    .all(...filterParams) as { funnel_stage: string; total: number }[];

  // The call columns are a correlated lookup rather than a join: a lead has at
  // most a handful of calls, `lead_calls_lead_time` answers both directly, and a
  // GROUP BY over the whole log to decorate forty cards is the wrong shape.
  const cards = db.prepare(
    `SELECT leads.id, leads.name, leads.city, leads.uf, leads.phone, leads.score,
            leads.niche, leads.contact_name, leads.notes, leads.next_follow_up_at,
            CASE WHEN leads.next_follow_up_at IS NOT NULL
                      AND leads.next_follow_up_at <= date('now','localtime')
                 THEN 1 ELSE 0 END AS follow_up_overdue,
            (SELECT COUNT(*) FROM lead_calls c WHERE c.lead_id = leads.id) AS attempts,
            (SELECT c.outcome FROM lead_calls c WHERE c.lead_id = leads.id
              ORDER BY c.occurred_at DESC, c.id DESC LIMIT 1) AS last_outcome,
            (SELECT c.occurred_at FROM lead_calls c WHERE c.lead_id = leads.id
              ORDER BY c.occurred_at DESC, c.id DESC LIMIT 1) AS last_call_at
       FROM leads
      ${whereOf(
        "leads.funnel_stage = ?",
        includedClause,
        scope.sql,
        nicheClause,
        search.sql,
      )}
      ORDER BY ${CARD_ORDER}
      LIMIT ${BOARD_COLUMN_LIMIT}`,
  );

  const columns = FUNNEL_STAGES.map((stage) => ({
    stage,
    total: Number(totals.find((t) => t.funnel_stage === stage)?.total ?? 0),
    cards: (cards.all(stage, ...filterParams) as CardRow[]).map(toCard),
  }));

  return { columns, limit: BOARD_COLUMN_LIMIT };
}

/* -------------------------------------------------------------------------- */
/* What the calls produced                                                     */
/* -------------------------------------------------------------------------- */

export type OutcomeStat = {
  outcome: CallOutcome;
  count: number;
  /** Of all calls, 0–1. Zero when nothing has been dialled, never NaN. */
  share: number;
  reached: boolean;
};

export type CallResultStats = {
  /** Dials logged, ever. Skips are not calls and are not in here. */
  calls: number;
  /** Distinct businesses dialled, which is what the rates below are per-lead on. */
  leads: number;
  reached: number;
  interested: number;
  won: number;
  lost: number;
  byOutcome: OutcomeStat[];
};

const REACHED_LIST = CALL_OUTCOMES.filter((o) => OUTCOME_REACHED[o])
  .map((o) => `'${o}'`)
  .join(",");

/**
 * What happens when you dial, over the whole log.
 *
 * Counted in one pass over `lead_calls` rather than per outcome, and the derived
 * totals are summed from the same rows the breakdown shows — so the headline
 * "atendidas" can never disagree with the outcomes listed underneath it, which
 * is the failure mode of computing each with its own query.
 */
export function callResultStats(scope: LeadScope): CallResultStats {
  const db = getDb();
  const s = scopeClause(scope);
  // The join exists only to reach `account_id`, so it is skipped when the scope
  // is unbounded — the log is the larger table and this is its hot read.
  const from =
    s.sql.length > 0
      ? `FROM lead_calls c JOIN leads ON leads.id = c.lead_id ${whereOf(s.sql)}`
      : "FROM lead_calls c";

  const rows = db
    .prepare(
      `SELECT c.outcome AS outcome, COUNT(*) AS count,
              COUNT(DISTINCT c.lead_id) AS leads
         ${from} GROUP BY c.outcome`,
    )
    .all(...s.params) as { outcome: string; count: number; leads: number }[];

  const count = (outcome: CallOutcome) =>
    Number(rows.find((r) => r.outcome === outcome)?.count ?? 0);

  const calls = rows.reduce((sum, r) => sum + Number(r.count), 0);

  const byOutcome: OutcomeStat[] = CALL_OUTCOMES.map((outcome) => ({
    outcome,
    count: count(outcome),
    share: calls > 0 ? count(outcome) / calls : 0,
    reached: OUTCOME_REACHED[outcome],
  }));

  // Distinct across the whole log, not summed from the grouped rows: a lead
  // dialled twice with two different outcomes appears in two of them, and adding
  // those up would report more businesses called than exist.
  const leads = Number(
    (
      db
        .prepare("SELECT COUNT(DISTINCT lead_id) AS n FROM lead_calls")
        .get() as {
        n: number;
      }
    ).n ?? 0,
  );

  return {
    calls,
    leads,
    reached: byOutcome
      .filter((o) => o.reached)
      .reduce((sum, o) => sum + o.count, 0),
    interested: count("interessado") + count("retornar"),
    won: count("fechado"),
    lost: count("sem_interesse"),
    byOutcome,
  };
}

export type NicheCallStats = {
  niche: string;
  calls: number;
  leads: number;
  reached: number;
  interested: number;
  won: number;
  /** Of the calls made into this niche, how many reached a human. 0–1. */
  reachRate: number;
  /** Of the businesses reached, how many showed interest or closed. 0–1. */
  interestRate: number;
};

/**
 * Which niches answer the phone, and which of those buy.
 *
 * The single most useful thing the call log can tell a hundred-a-day operation:
 * it is the difference between spending tomorrow's dials on the niche that picks
 * up and the one that never does, and no amount of lead volume substitutes for
 * it. Ordered by calls, because a niche with one call and a 100% rate is noise
 * and sorting by rate would put it on top.
 *
 * `interestRate` is deliberately over *reached*, not over calls: whether someone
 * wants what we sell is only answerable once they pick up, and dividing by every
 * dial mixes that question with how good the phone numbers are.
 */
export function callStatsByNiche(
  scope: LeadScope,
  limit = 20,
): NicheCallStats[] {
  const s = scopeClause(scope);
  const rows = getDb()
    .prepare(
      `SELECT leads.niche AS niche,
              COUNT(*)                                             AS calls,
              COUNT(DISTINCT c.lead_id)                            AS leads_n,
              COALESCE(SUM(c.outcome IN (${REACHED_LIST})), 0)     AS reached,
              COALESCE(SUM(c.outcome IN ('interessado','retornar','fechado')), 0) AS interested,
              COALESCE(SUM(c.outcome = 'fechado'), 0)              AS won
         FROM lead_calls c
         JOIN leads ON leads.id = c.lead_id
        ${whereOf("leads.niche IS NOT NULL", s.sql)}
        GROUP BY leads.niche
        ORDER BY calls DESC, won DESC
        LIMIT ?`,
    )
    .all(...s.params, limit) as {
    niche: string;
    calls: number;
    leads_n: number;
    reached: number;
    interested: number;
    won: number;
  }[];

  return rows.map((r) => {
    const calls = Number(r.calls);
    const reached = Number(r.reached);
    const interested = Number(r.interested);
    return {
      niche: r.niche,
      calls,
      leads: Number(r.leads_n),
      reached,
      interested,
      won: Number(r.won),
      reachRate: calls > 0 ? reached / calls : 0,
      // Zero reached is zero, not a division by zero dressed up as 100%.
      interestRate: reached > 0 ? interested / reached : 0,
    };
  });
}
