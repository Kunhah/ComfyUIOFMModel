import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { after, before, describe, it } from "node:test";

/**
 * Who the automatic queue picks, and who it refuses to.
 *
 * These rules decide what an operator spends their day dialling, and every one
 * of them fails silently: a shared switchboard number looks like a fine lead
 * right up until the third person answers "shopping centre, how may I help".
 * So each exclusion is asserted against a database rather than reasoned about.
 */

let calls: typeof import("./calls");
let quality: typeof import("./phone-quality");
let db: typeof import("./db");
let dir: string;

const ACTOR = { id: "u1", displayName: "Operadora" };

function seed(
  id: string,
  name: string,
  phone: string | null,
  over: { score?: number; stage?: string; followUp?: string | null } = {},
): void {
  db.getDb()
    .prepare(
      `INSERT INTO leads
         (id, name, phone, phone_norm, country, city, uf, confidence, score,
          search_norm, funnel_stage, next_follow_up_at)
       VALUES (?, ?, ?, ?, 'BR', 'Belo Horizonte', 'MG', 0.9, ?, ?, ?, ?)`,
    )
    .run(
      id,
      name,
      phone,
      // Seeded pre-folded: persistLeads does this with normalisePhone, and the
      // test is about the queue's rules, not about that function.
      phone ? phone.replace(/\D/g, "") : null,
      over.score ?? 70,
      name.toLowerCase(),
      over.stage ?? "descoberta",
      over.followUp ?? null,
    );
}

before(async () => {
  dir = mkdtempSync(path.join(tmpdir(), "daily-test-"));
  process.env.PROSPECTOR_DB = path.join(dir, "prospector.db");
  db = await import("./db");
  calls = await import("./calls");
  quality = await import("./phone-quality");
});

after(() => rmSync(dir, { recursive: true, force: true }));

describe("phone quality", () => {
  it("excludes a number listed by several businesses", () => {
    // Three shops in one gallery, all listing the gallery's switchboard. None of
    // them can be reached on it, and the directory has no field that says so.
    seed("s1", "Loja Um", "+553133330001");
    seed("s2", "Loja Dois", "+553133330001");
    seed("s3", "Loja Tres", "+553133330001");
    // A business on its own line, for contrast.
    seed("ok1", "Padaria Boa", "+5531988880001");

    assert.equal(quality.phoneQuality("s1")?.good, false);
    assert.equal(quality.phoneQuality("s1")?.sharedWith, 3);
    assert.match(
      quality.phoneQuality("s1")?.warning ?? "",
      /aparece em 3 empresas/,
    );
    assert.equal(quality.phoneQuality("ok1")?.good, true);
    assert.equal(quality.phoneQuality("ok1")?.warning, null);
  });

  it("allows two branches sharing a line, but warns", () => {
    // Deliberately still callable: a genuine second branch is common, and
    // excluding it would throw away real leads.
    seed("b1", "Filial Centro", "+553133330002");
    seed("b2", "Filial Savassi", "+553133330002");
    assert.equal(quality.phoneQuality("b1")?.good, true);
    assert.match(
      quality.phoneQuality("b1")?.warning ?? "",
      /aparece em outra empresa/,
    );
  });

  it("kills a number for every lead once one call finds it dead", () => {
    seed("d1", "Bar Um", "+553133330003");
    seed("d2", "Bar Dois", "+553133330003");
    assert.equal(quality.phoneQuality("d2")?.good, true);

    calls.recordCall({
      leadId: "d1",
      outcome: "numero_invalido",
      actor: ACTOR,
    });

    // The other lead carrying the same number is now known-bad too, without
    // anyone having dialled it.
    assert.equal(quality.phoneQuality("d2")?.dead, true);
    assert.equal(quality.phoneQuality("d2")?.good, false);
  });

  it("treats a lead with no number as unusable", () => {
    seed("n1", "Sem Telefone", null);
    assert.equal(quality.phoneQuality("n1")?.good, false);
    assert.equal(quality.phoneQuality("n1")?.phoneNorm, null);
  });
});

describe("daily candidates", () => {
  it("offers only leads with a trustworthy number", () => {
    const picked = calls.dailyCandidates(100);
    // The switchboard trio, the dead-number pair and the phoneless lead are all
    // out; the private lines and the two-branch pair remain.
    assert.ok(picked.includes("ok1"));
    assert.ok(picked.includes("b1"));
    for (const excluded of ["s1", "s2", "s3", "d1", "d2", "n1"]) {
      assert.ok(!picked.includes(excluded), `${excluded} should be excluded`);
    }
  });

  it("puts due follow-ups before high scores", () => {
    seed("late", "Retorno Atrasado", "+5531988880002", {
      score: 10,
      stage: "contato",
      followUp: "2020-01-01",
    });
    seed("shiny", "Lead Excelente", "+5531988880003", { score: 99 });

    const picked = calls.dailyCandidates(100);
    // A promise made on a call outranks any score, however good.
    assert.ok(picked.indexOf("late") < picked.indexOf("shiny"));
  });

  it("does not offer a lead scheduled for the future", () => {
    seed("later", "Marcado Para Depois", "+5531988880004", {
      stage: "contato",
      followUp: "2099-01-01",
    });
    assert.ok(!calls.dailyCandidates(500).includes("later"));
  });

  it("does not offer closed or lost leads", () => {
    seed("won", "Ja Cliente", "+5531988880005", { stage: "fechado" });
    seed("lost", "Ja Perdido", "+5531988880006", { stage: "perdido" });
    const picked = calls.dailyCandidates(500);
    assert.ok(!picked.includes("won"));
    assert.ok(!picked.includes("lost"));
  });

  it("does not offer a lead already waiting in a queue", () => {
    seed("queued", "Ja Na Fila", "+5531988880007");
    assert.ok(calls.dailyCandidates(500).includes("queued"));

    calls.createCallList({ name: "Outra", leadIds: ["queued"], actor: ACTOR });

    // Two operators must never be handed the same business on the same morning.
    assert.ok(!calls.dailyCandidates(500).includes("queued"));
  });

  it("stops offering a lead nobody ever answers", () => {
    seed("silent", "Nunca Atende", "+5531988880008");
    seed("tried-twice", "Tentado Duas Vezes", "+5531988880010");

    const dial = (id: string, times: number) => {
      for (let i = 0; i < times; i += 1) {
        calls.recordCall({
          leadId: id,
          outcome: "nao_atendeu",
          followUpAt: null,
          actor: ACTOR,
        });
      }
    };
    dial("silent", quality.MAX_UNANSWERED_ATTEMPTS);
    dial("tried-twice", 2);

    // Age both leads' calls past the cooldown. Without this the test proves
    // nothing: a lead dialled a moment ago is excluded by the cooldown whatever
    // its attempt count, so both rules would look identical from the outside.
    db.getDb()
      .prepare(
        "UPDATE lead_calls SET occurred_at = datetime('now','-60 days') WHERE lead_id IN (?, ?)",
      )
      .run("silent", "tried-twice");

    const picked = calls.dailyCandidates(500);
    // Same age, same outcome, different attempt counts — so the attempt ceiling
    // is the only thing separating them.
    assert.ok(
      picked.includes("tried-twice"),
      "two attempts is still worth a call",
    );
    assert.ok(!picked.includes("silent"), "four unanswered attempts is enough");
  });

  it("respects the cooldown on a lead called recently", () => {
    seed("fresh", "Ligado Ontem", "+5531988880009");
    calls.recordCall({
      leadId: "fresh",
      outcome: "nao_atendeu",
      followUpAt: null,
      actor: ACTOR,
    });
    // Called just now with nothing scheduled — it must wait, or the queue hands
    // back the same numbers every morning.
    assert.ok(!calls.dailyCandidates(500).includes("fresh"));
  });

  it("honours the requested size", () => {
    assert.equal(calls.dailyCandidates(2).length, 2);
  });
});

describe("the daily list", () => {
  it("is built once per operator per day", () => {
    const first = calls.dailyList({ actor: ACTOR, target: 3 });
    assert.ok(first);
    assert.equal(first.created, true);
    assert.equal(first.list.total, 3);

    // Pressed again — a refresh, a second tab, back from lunch. It must return
    // the same queue rather than handing out three more leads.
    const second = calls.dailyList({ actor: ACTOR, target: 3 });
    assert.ok(second);
    assert.equal(second.created, false);
    assert.equal(second.list.id, first.list.id);
  });

  it("tops a worked list up without disturbing its order", () => {
    const list = calls.dailyList({ actor: ACTOR, target: 3 })!.list;
    const before = calls
      .listItems(list.id)
      .map((i) => `${i.position}:${i.leadId}`);

    const { added } = calls.topUpList(list.id, 2);
    assert.ok(added > 0);

    const after = calls
      .listItems(list.id)
      .map((i) => `${i.position}:${i.leadId}`);
    // The positions already being worked are untouched; the new leads land after.
    assert.deepEqual(after.slice(0, before.length), before);
    assert.equal(after.length, before.length + added);
  });

  it("never re-queues a lead the same list already holds", () => {
    const list = calls.dailyList({ actor: ACTOR, target: 3 })!.list;
    const ids = new Set(calls.listItems(list.id).map((i) => i.leadId));
    calls.topUpList(list.id, 100);
    const after = calls.listItems(list.id).map((i) => i.leadId);
    assert.equal(new Set(after).size, after.length, "no duplicate positions");
    for (const id of ids) assert.ok(after.includes(id));
  });
});

describe("pool stats", () => {
  it("accounts for every open lead exactly once across the exclusions", () => {
    const pool = quality.phonePoolStats();
    assert.ok(pool.workable > 0);
    // The three headline numbers only ever narrow.
    assert.ok(pool.good <= pool.workable);
    assert.ok(pool.available <= pool.good);
    // And the reasons for exclusion are real rather than always zero.
    assert.ok(pool.noPhone > 0);
    assert.ok(pool.shared > 0);
    assert.ok(pool.dead > 0);
  });
});

describe("the two forms of the phone rule", () => {
  it("select exactly the same leads", () => {
    // `GOOD_PHONE_SQL` composes into any WHERE clause and is what the CRM filter
    // uses; the CTE form is what the whole-table queries use because the
    // correlated one re-counts every shared number per row. Two shapes of one
    // rule is a real duplication, and this is what stops them drifting into two
    // different definitions of "telefone confiável".
    const handle = db.getDb();

    const correlated = (
      handle
        .prepare(
          `SELECT leads.id FROM leads WHERE ${quality.GOOD_PHONE_SQL} ORDER BY leads.id`,
        )
        .all() as { id: string }[]
    ).map((r) => r.id);

    const setBased = (
      handle
        .prepare(
          `WITH ${quality.PHONE_QUALITY_CTE}
           SELECT leads.id FROM leads ${quality.PHONE_QUALITY_JOINS}
            WHERE ${quality.GOOD_PHONE_CTE_SQL} ORDER BY leads.id`,
        )
        .all() as { id: string }[]
    ).map((r) => r.id);

    assert.ok(correlated.length > 0, "the fixture must exercise the rule");
    assert.deepEqual(setBased, correlated);
  });
});
