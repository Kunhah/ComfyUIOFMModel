import { normalise } from "./cities";

/**
 * Etiquetas — the operator's own way of grouping leads.
 *
 * The funnel says how far a deal has come and the niche says what the business
 * is; neither answers "which of these did I decide to treat as one batch".
 * That question changes shape every week — "orçamento enviado por e-mail",
 * "indicação do Marcelo", "revisitar em 2027" — so it is deliberately free text
 * rather than a registry like `niches.ts`. There is nothing to migrate when the
 * way of working changes.
 *
 * Stored as one JSON column for the same reason `socials` is: the set of useful
 * labels changes far faster than a schema should.
 */

/** Enough to group by, short enough to stay a chip rather than a sentence. */
export const MAX_TAG_LENGTH = 30;

/**
 * Past a dozen the chips stop being scannable and the label has become a note.
 * `notes` is the field for that.
 */
export const MAX_TAGS = 12;

/** Control characters, including the newlines a spreadsheet paste brings along. */
const CONTROL = /[\u0000-\u001f\u007f]/g;

/**
 * Clean one label, or reject it.
 *
 * Casing and accents are preserved — these are shown back to the person who
 * typed them, and "Indicação" reading as "indicacao" in their own list is the
 * kind of small wrongness that makes a tool feel careless. Folding is only for
 * comparison, see `tagKey`.
 */
export function normaliseTag(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  const cleaned = raw.replace(CONTROL, " ").replace(/\s+/g, " ").trim();
  if (cleaned.length === 0) return null;
  return cleaned.slice(0, MAX_TAG_LENGTH);
}

/**
 * The comparison form. Folds case, accents and punctuation through the same
 * `normalise` the city index uses, so "Follow-up", "follow up" and "FOLLOWUP"
 * are one tag rather than three columns of the same thing.
 */
export function tagKey(tag: string): string {
  return normalise(tag);
}

/**
 * Clean a whole list: drop the unusable, collapse the duplicates, cap the rest.
 *
 * First spelling wins on a duplicate, so re-adding a tag never silently re-cases
 * the one already on the lead.
 */
export function sanitiseTags(raw: unknown): string[] {
  if (!Array.isArray(raw)) return [];
  const out: string[] = [];
  const seen = new Set<string>();
  for (const entry of raw) {
    const tag = normaliseTag(entry);
    if (tag === null) continue;
    const key = tagKey(tag);
    if (key.length === 0 || seen.has(key)) continue;
    seen.add(key);
    out.push(tag);
    if (out.length === MAX_TAGS) break;
  }
  return out;
}

/** Reads the column back, degrading a hand-edited value to an empty list. */
export function parseTags(rawColumn: string | null): string[] {
  if (!rawColumn) return [];
  try {
    return sanitiseTags(JSON.parse(rawColumn));
  } catch {
    return [];
  }
}

/**
 * The `instr()` needle that finds this tag inside the stored JSON array.
 *
 * Quoted on both sides on purpose: a bare "vip" would also match the "vip-plus"
 * in `["vip-plus"]`, whereas `"vip"` — closing quote included — cannot.
 */
export function tagNeedle(tag: string): string {
  return JSON.stringify(tag);
}
