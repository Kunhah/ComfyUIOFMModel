import { existsSync } from "node:fs";
import path from "node:path";
import { DuckDBInstance, type DuckDBConnection } from "@duckdb/node-api";
import { normalise } from "./cities";
import { duckdbConfig } from "./overture";
import type { SearchArea } from "./scopes";
import type { Lead } from "./types";

/**
 * The Receita Federal half of a partner search.
 *
 * Kept beside `overture.ts` rather than inside it because the two extracts are
 * unrelated in every way that matters: different provenance, different refresh
 * cadence (Overture roughly monthly on their calendar, the Receita on theirs),
 * different columns, and different questions. `places.parquet` answers "which
 * businesses are on this street"; `cnpj.parquet` answers "who is registered to
 * do this for a living", which for a trade that works from a laptop is the only
 * question with an answer.
 *
 * It is read-only, small (~80k rows against the places extract's 7,4M) and
 * queried straight out of Parquet rather than materialised into memory: at this
 * size the scan is already sub-100ms, and a second resident copy of a table
 * would cost the container more than it saves.
 */

export function cnpjExtractPath(): string {
  return path.join(process.cwd(), "data", "cnpj.parquet");
}

export function hasCnpjExtract(): boolean {
  return existsSync(cnpjExtractPath());
}

let connection: Promise<DuckDBConnection> | null = null;

async function getConnection(): Promise<DuckDBConnection> {
  if (!connection) {
    connection = (async () => {
      const instance = await DuckDBInstance.create(":memory:", duckdbConfig());
      let db: DuckDBConnection | undefined;
      try {
        db = await instance.connect();
        // The same fold as build-city-index.mjs and normalise() in cities.ts.
        // Only ever applied to the *needle* here — the extract stores a folded
        // `city_norm` so the haystack side stays a plain column comparison and
        // keeps its row-group statistics, which is the whole point of the sort.
        await db.run(`CREATE MACRO nrm(s) AS
          trim(regexp_replace(regexp_replace(lower(strip_accents(s)), '[^a-z0-9]+', ' ', 'g'), '\\s+', ' ', 'g'))`);
        return db;
      } catch (err) {
        // See prospector/overture.ts: an abandoned instance keeps its threads,
        // and the retry below is what turns that into a per-request leak. The
        // connection has to go first — an open one keeps the database, and the
        // pool, alive past instance.closeSync().
        db?.closeSync();
        instance.closeSync();
        throw err;
      }
    })().catch((err) => {
      // Don't cache a failed init: seeding the extract must start working
      // without a restart, the same contract `overture.ts` keeps.
      connection = null;
      throw err;
    });
  }
  return connection;
}

export type CnpjQuery = {
  area: SearchArea;
  /** CNAE codes to match, from the niche. Seven digits, unpunctuated. */
  cnaes: string[];
  limit: number;
};

export type CnpjResult = {
  leads: Lead[];
  /** Counted over every match, never over the returned page. */
  totals: {
    matched: number;
    withPhone: number;
    withEmail: number;
    /** How many are MEI — one person, which is a different conversation. */
    mei: number;
  };
  elapsedMs: number;
};

const str = (v: unknown): string | null => {
  const s = typeof v === "string" ? v.trim() : v == null ? "" : String(v);
  return s.length > 0 ? s : null;
};

export async function queryCnpj(q: CnpjQuery): Promise<CnpjResult> {
  if (q.cnaes.length === 0) {
    return {
      leads: [],
      totals: { matched: 0, withPhone: 0, withEmail: 0, mei: 0 },
      elapsedMs: 0,
    };
  }

  const db = await getConnection();
  const started = Date.now();
  const source = `read_parquet(${quote(cnpjExtractPath())})`;

  // The registry is Brazilian by definition, so a search anywhere else has no
  // CNPJ half at all. Saying so here keeps `performSearch` from having to know.
  if (q.area.country !== "BR") {
    return {
      leads: [],
      totals: { matched: 0, withPhone: 0, withEmail: 0, mei: 0 },
      elapsedMs: 0,
    };
  }

  const where: string[] = [`category IN (${q.cnaes.map(quote).join(", ")})`];
  if (q.area.scope === "city" && q.area.city) {
    // City *and* state: "Bom Jesus" exists in a dozen Brazilian states, and the
    // POI path narrows that with a bounding box this extract does not have —
    // the Receita publishes no coordinates. The UF is what replaces it, and it
    // is on every row, so this pin is if anything tighter than the map's.
    where.push(`city_norm = ${quote(normalise(q.area.city.name))}`);
    if (q.area.city.uf) where.push(`uf = ${quote(q.area.city.uf)}`);
  } else if (q.area.scope === "state") {
    where.push(`uf = ${quote(q.area.uf)}`);
  } else if (q.area.scope === "region") {
    where.push(`uf IN (${q.area.ufs.map(quote).join(", ")})`);
  }

  const predicate = where.join(" AND ");
  const rows = await db.runAndReadAll(
    `SELECT id, name, category, address, city, uf, phone, email, cnpj, mei,
            matriz, opened_at, confidence
     FROM ${source}
     WHERE ${predicate}
     -- Reachability first: a partner we cannot contact is not a partner.
     --
     -- Then age, as a band rather than a direction. "Oldest first" was the
     -- obvious rule and it is wrong here — it fills the page with traditional
     -- propaganda houses founded in the eighties, which are a different trade
     -- from the one we are looking for. A firm under two years old may never
     -- have traded; one over twenty-five predates paid social entirely. The
     -- gestor de tráfego and the small digital agency sit in between, so that
     -- band sorts first and everything else after it.
     --
     -- MEI last, and deliberately *preferred*: one person running campaigns is
     -- exactly the profile no map has, which is why this source exists at all.
     ORDER BY (phone IS NOT NULL) DESC, (email IS NOT NULL) DESC,
              CASE
                WHEN opened_at IS NULL THEN 2
                WHEN opened_at BETWEEN current_date - INTERVAL 25 YEAR
                                   AND current_date - INTERVAL 2 YEAR THEN 0
                ELSE 1
              END ASC,
              mei DESC,
              opened_at DESC NULLS LAST
     LIMIT ${Math.max(1, Math.trunc(q.limit))}`,
  );

  const totals = await db.runAndReadAll(
    // Every alias here is quoted. `matched` is a DuckDB keyword (it belongs to
    // MERGE), and an unquoted one is a parser error rather than a column — the
    // same trap as `source` and `rows` in the sync script. Quoting all four is
    // cheaper than learning the keyword list again on the next edit.
    `SELECT count(*) AS "matched",
            count(*) FILTER (WHERE phone IS NOT NULL) AS "with_phone",
            count(*) FILTER (WHERE email IS NOT NULL) AS "with_email",
            count(*) FILTER (WHERE mei) AS "mei"
     FROM ${source} WHERE ${predicate}`,
  );
  const t = totals.getRowObjects()[0] ?? {};

  const leads: Lead[] = rows.getRowObjects().map((r) => ({
    id: String(r.id),
    source: "cnpj" as const,
    name: str(r.name) ?? "(sem nome)",
    // The CNAE, stored where an Overture category would be. `nicheForCategory`
    // and `intentForCategory` map both vocabularies, so nothing downstream —
    // the CRM, the history, the opener — needs to know which one it is holding.
    category: str(r.category),
    address: str(r.address),
    city: str(r.city),
    uf: str(r.uf),
    country: "BR",
    phone: str(r.phone),
    // Not "has no website": the Receita has no such field and never asked. The
    // difference matters — `scorePartner` must not read this as a firm without
    // one. See `KNOWS_WEBSITE` in score.ts.
    website: null,
    social: null,
    socialLinks: [],
    email: str(r.email),
    lat: null,
    lon: null,
    confidence: Number(r.confidence ?? 0.9),
  }));

  return {
    leads,
    totals: {
      matched: Number(t.matched ?? 0),
      withPhone: Number(t.with_phone ?? 0),
      withEmail: Number(t.with_email ?? 0),
      mei: Number(t.mei ?? 0),
    },
    elapsedMs: Date.now() - started,
  };
}

/**
 * Single-quoted SQL literal. Every value interpolated here is ours — CNAEs from
 * the niche registry, UF codes from the Brazil table, a city name folded by
 * `normalise` — but the extract path comes from the filesystem and the escape
 * is what keeps that from being an assumption.
 */
function quote(value: string): string {
  return `'${value.replace(/'/g, "''")}'`;
}
