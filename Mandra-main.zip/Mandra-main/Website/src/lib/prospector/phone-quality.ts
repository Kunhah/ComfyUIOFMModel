import { getDb } from "./db";

/**
 * Is this number actually *this* business's number?
 *
 * The single most expensive failure in cold calling is not a bad lead — it is a
 * good lead with someone else's phone on it. You dial, reach a shopping centre
 * switchboard or a franchise head office, and burn the call plus the operator's
 * patience. `dedup.ts` already documents why this happens often enough to matter:
 * "shopping-centre switchboards, franchise head offices, salon chairs sublet,
 * multi-venue owners all do it".
 *
 * There is no field in any directory that says "this number is shared", so it has
 * to be inferred, and the inference is available locally and for free: count how
 * many *distinct businesses in our own history* list the same folded number. One
 * is a private line. Two is usually two branches. Forty is a switchboard, and
 * every one of those forty leads has a phone that does not correlate to it.
 *
 * Two other signals join it, both earned from the call log rather than guessed:
 * a number someone has already marked `numero_invalido` is dead for *every* lead
 * carrying it, and a lead dialled repeatedly without ever reaching a human has
 * shown what it is worth.
 *
 * Everything here is expressed as SQL fragments over `leads`, because the callers
 * are a filter, a facet count and a queue builder — all of which need this inside
 * their own WHERE clause rather than as a list of ids to intersect in JS.
 */

/**
 * How many distinct businesses may list a number before we stop believing it
 * belongs to any one of them.
 *
 * Three rather than two: a genuine second branch sharing a line is common and
 * legitimate, and excluding it would throw away real leads. By three the pattern
 * is a switchboard far more often than it is a chain, and the operator can still
 * see and call them — this only decides what "bom" means and what the automatic
 * queue reaches for first.
 */
export const MAX_SHARED_PHONE = 3;

/**
 * Dial attempts without ever reaching a human, after which a lead stops being
 * offered by the automatic queue.
 *
 * Not a deletion and not a stage change: the lead keeps its place in the CRM and
 * can be called by hand forever. This only stops the daily list handing you the
 * same unanswered number every morning for a month, which is how an automatic
 * queue quietly becomes a queue nobody trusts.
 */
export const MAX_UNANSWERED_ATTEMPTS = 4;

/**
 * Days before an already-dialled lead may be offered by the automatic queue
 * again. A follow-up that is actually due overrides this — that date was a
 * promise made on a call, and this is only about leads nobody has scheduled.
 */
export const RECALL_COOLDOWN_DAYS = 14;

/**
 * True when the number is dead: someone dialled it and marked it invalid.
 *
 * Matched on the folded number rather than the lead, so one operator finding a
 * dead line protects every other lead that lists it — which, for exactly the
 * shared-number reason above, is often several.
 */
const DEAD_NUMBER = `
  EXISTS (
    SELECT 1 FROM lead_calls c
      JOIN leads dead ON dead.id = c.lead_id
     WHERE dead.phone_norm = leads.phone_norm
       AND c.outcome = 'numero_invalido'
  )`;

/** How many distinct businesses in the history list this same folded number. */
export const SHARED_PHONE_COUNT = `
  (SELECT COUNT(*) FROM leads other WHERE other.phone_norm = leads.phone_norm)`;

/**
 * The predicate for "a number worth dialling".
 *
 * Deliberately *not* about how good the business is — that is what `score`
 * already answers. This is only about whether the line reaches them.
 */
export const GOOD_PHONE_SQL = `
  leads.phone_norm IS NOT NULL
  AND ${SHARED_PHONE_COUNT} < ${MAX_SHARED_PHONE}
  AND NOT ${DEAD_NUMBER}`;

/** Calls against this lead that never reached a human. */
export const UNANSWERED_COUNT = `
  (SELECT COUNT(*) FROM lead_calls c
    WHERE c.lead_id = leads.id
      AND c.outcome IN ('nao_atendeu','caixa_postal'))`;

/** The most recent dial against this lead, or NULL. */
export const LAST_CALL_AT = `
  (SELECT MAX(c.occurred_at) FROM lead_calls c WHERE c.lead_id = leads.id)`;

/* -------------------------------------------------------------------------- */
/* The same rules, set-based                                                   */
/* -------------------------------------------------------------------------- */

/**
 * The whole-table form of the two phone rules.
 *
 * The correlated fragments above compose into anyone's WHERE clause, which is
 * what the CRM filter and the single-lead check need. They are the wrong shape
 * for a query that touches every row: the shared-number count is re-evaluated
 * per row and several times per row, and at 50.000 leads the pool summary took
 * 2,2s — on a page that renders on every visit, over a base meant to grow well
 * past that.
 *
 * These CTEs answer both questions in one pass each, and the query joins them.
 * Two shapes of the same rule is a duplication worth naming: `phone-quality.test.ts`
 * asserts the two select exactly the same leads, so a change to one that isn't
 * made to the other fails rather than quietly producing two definitions of "bom".
 */
export const PHONE_QUALITY_CTE = `
  shared_phones AS (
    SELECT phone_norm, COUNT(*) AS businesses
      FROM leads
     WHERE phone_norm IS NOT NULL
     GROUP BY phone_norm
  ),
  dead_phones AS (
    SELECT DISTINCT l.phone_norm
      FROM lead_calls c
      JOIN leads l ON l.id = c.lead_id
     WHERE c.outcome = 'numero_invalido'
       AND l.phone_norm IS NOT NULL
  )`;

/** `GOOD_PHONE_SQL` against the CTEs above. Requires both to be in scope. */
export const GOOD_PHONE_CTE_SQL = `
  leads.phone_norm IS NOT NULL
  AND COALESCE(sp.businesses, 0) < ${MAX_SHARED_PHONE}
  AND dp.phone_norm IS NULL`;

/** The joins `GOOD_PHONE_CTE_SQL` reads. LEFT, so a lead with no match survives. */
export const PHONE_QUALITY_JOINS = `
  LEFT JOIN shared_phones sp ON sp.phone_norm = leads.phone_norm
  LEFT JOIN dead_phones   dp ON dp.phone_norm = leads.phone_norm`;

/**
 * Ready to be handed out by the automatic queue *right now*.
 *
 * Three separate ways a lead can be unavailable, and they mean different things:
 * it is already waiting in someone's queue, it has been dialled into the ground,
 * or it was called recently and nobody scheduled a reason to call again. A due
 * follow-up overrides the cooldown entirely — that date was a promise made on a
 * call, and a queue that ignores it is worse than no queue. A follow-up set for
 * *next week* excludes the lead: it is scheduled, and pre-empting it is how you
 * phone someone four days before you said you would.
 */
export const AVAILABLE_SQL = `
  ${UNANSWERED_COUNT} < ${MAX_UNANSWERED_ATTEMPTS}
  AND NOT EXISTS (
        SELECT 1 FROM call_list_items q
         WHERE q.lead_id = leads.id AND q.state = 'pendente'
      )
  AND (
        (leads.next_follow_up_at IS NOT NULL
         AND leads.next_follow_up_at <= date('now','localtime'))
        OR (leads.next_follow_up_at IS NULL
            AND (${LAST_CALL_AT} IS NULL
                 OR ${LAST_CALL_AT} < datetime('now','-${RECALL_COOLDOWN_DAYS} days')))
      )`;

/**
 * Due follow-ups first, then the best businesses.
 *
 * The ordering the daily list is built with, shared with the screen that
 * previews it so the preview cannot describe a different queue from the one you
 * get. A promise already made outranks any score.
 */
export const QUEUE_ORDER_SQL = `
  CASE WHEN leads.next_follow_up_at IS NOT NULL
            AND leads.next_follow_up_at <= date('now','localtime')
       THEN 0 ELSE 1 END ASC,
  leads.next_follow_up_at ASC,
  leads.score DESC,
  leads.confidence DESC`;

/** What the quality check concluded about one lead, for display on its row. */
export type PhoneQuality = {
  /** Bare E.164 digits, or null when the lead has no usable number at all. */
  phoneNorm: string | null;
  /** Distinct businesses in the history listing this same number. */
  sharedWith: number;
  /** Someone dialled this number and marked it invalid. */
  dead: boolean;
  /** Dials against this lead that never reached a human. */
  unanswered: number;
  /** Passes `GOOD_PHONE_SQL` — the line plausibly reaches this business. */
  good: boolean;
  /** One short pt-BR phrase, or null when there is nothing to warn about. */
  warning: string | null;
};

export function phoneQuality(leadId: string): PhoneQuality | null {
  const row = getDb()
    .prepare(
      `SELECT phone_norm,
              ${SHARED_PHONE_COUNT} AS shared,
              ${UNANSWERED_COUNT}   AS unanswered,
              CASE WHEN ${DEAD_NUMBER} THEN 1 ELSE 0 END AS dead
         FROM leads WHERE id = ?`,
    )
    .get(leadId) as
    | {
        phone_norm: string | null;
        shared: number;
        unanswered: number;
        dead: number;
      }
    | undefined;
  if (!row) return null;

  const sharedWith = Number(row.shared);
  const dead = Number(row.dead) === 1;
  const unanswered = Number(row.unanswered);
  const good =
    row.phone_norm !== null && sharedWith < MAX_SHARED_PHONE && !dead;

  return {
    phoneNorm: row.phone_norm,
    sharedWith,
    dead,
    unanswered,
    good,
    warning: warningFor(row.phone_norm, sharedWith, dead, unanswered),
  };
}

/**
 * The warning shown on the dialer, in the operator's language.
 *
 * One phrase, not a list: it is read in the two seconds before a call connects,
 * and three stacked caveats get skipped where one gets acted on. Ordered by what
 * would waste the call soonest.
 */
function warningFor(
  phoneNorm: string | null,
  sharedWith: number,
  dead: boolean,
  unanswered: number,
): string | null {
  if (phoneNorm === null) return "Sem telefone utilizável.";
  if (dead) return "Este número já foi marcado como inválido.";
  if (sharedWith >= MAX_SHARED_PHONE) {
    return `Este número aparece em ${sharedWith} empresas — provavelmente é uma central, e não a linha desta.`;
  }
  if (sharedWith === 2) {
    return "Este número aparece em outra empresa também — confirme com quem atender.";
  }
  if (unanswered >= MAX_UNANSWERED_ATTEMPTS) {
    return `${unanswered} tentativas sem falar com ninguém.`;
  }
  return null;
}

/** How much of the base is actually callable, for the queue screen. */
export type PhonePoolStats = {
  /** Leads not closed or lost — the pool the queue can ever draw from. */
  workable: number;
  /** Of those, how many have a number worth dialling. */
  good: number;
  /** Of those, how many are ready right now (cooldown and attempts allowing). */
  available: number;
  /** Excluded because their number is listed by several businesses. */
  shared: number;
  /** Excluded because the number is dead. */
  dead: number;
  /** Excluded because they have no number at all. */
  noPhone: number;
};

const OPEN_STAGES = `leads.funnel_stage NOT IN ('fechado','perdido')`;

export function phonePoolStats(): PhonePoolStats {
  const row = getDb()
    .prepare(
      `WITH ${PHONE_QUALITY_CTE}
       SELECT
         COUNT(*) AS workable,
         SUM(CASE WHEN leads.phone_norm IS NULL THEN 1 ELSE 0 END) AS no_phone,
         SUM(CASE WHEN leads.phone_norm IS NOT NULL AND dp.phone_norm IS NOT NULL
                  THEN 1 ELSE 0 END) AS dead,
         SUM(CASE WHEN leads.phone_norm IS NOT NULL
                       AND COALESCE(sp.businesses, 0) >= ${MAX_SHARED_PHONE}
                  THEN 1 ELSE 0 END) AS shared,
         SUM(CASE WHEN ${GOOD_PHONE_CTE_SQL} THEN 1 ELSE 0 END) AS good,
         SUM(CASE WHEN ${GOOD_PHONE_CTE_SQL} AND ${AVAILABLE_SQL}
                  THEN 1 ELSE 0 END) AS available
       FROM leads
       ${PHONE_QUALITY_JOINS}
      WHERE ${OPEN_STAGES}`,
    )
    .get() as Record<string, number>;

  return {
    workable: Number(row.workable ?? 0),
    good: Number(row.good ?? 0),
    available: Number(row.available ?? 0),
    shared: Number(row.shared ?? 0),
    dead: Number(row.dead ?? 0),
    noPhone: Number(row.no_phone ?? 0),
  };
}
