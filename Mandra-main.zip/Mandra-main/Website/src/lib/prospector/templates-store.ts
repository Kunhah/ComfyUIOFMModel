import { findCountry } from "@/lib/countries";
import { getDb } from "./db";
import { intentForCategory, type NicheIntent } from "./niches";
import {
  DEFAULT_BODIES,
  MAX_BODY_LENGTH,
  type OutreachContext,
  type TemplateLanguage,
  type TemplateSet,
  type TemplateSlot,
} from "./templates";

/**
 * Where the edited openers live.
 *
 * Split from `templates.ts` because that module is reachable from a client
 * bundle through `score.ts` and this one opens SQLite. Same split as
 * `history.ts` / `types.ts`, same reason.
 *
 * Every write here is a change to what a stranger reads on WhatsApp, so each
 * one records who made it. Nothing is versioned beyond that: the variants *are*
 * the history, which is the point of keeping the old one active-off rather than
 * overwriting it.
 *
 * Two levels, and the resolution order is the whole design:
 *
 *   1. the row this person owns for the slot,
 *   2. the team row for the slot,
 *   3. `DEFAULT_BODIES`, which ships in the code.
 *
 * So editing is never a negotiation. An operator rewrites their own opener and
 * it changes their own links and nobody else's; the admin edits the team one
 * and it moves everyone who has not written their own. Nothing here needs a
 * permission, because nothing an operator does here reaches anyone else.
 */

export type TemplateAuthor = { id: string; displayName: string };

/** One note an operator left about how a variant performed. */
export type TemplateNote = {
  id: number;
  authorId: string;
  authorName: string;
  body: string;
  createdAt: string;
};

/**
 * What a variant produced, counted from `outreach_template_uses` joined back to
 * the leads it was sent to.
 *
 * Deliberately three plain counts and no rate. A rate over eleven sends reads
 * as a measurement and is a coin toss, and this screen is exactly where someone
 * would act on it; the note field next to these numbers is where the judgement
 * belongs.
 */
export type TemplateStats = {
  /** Outreach opened with this variant, across every channel. */
  sends: number;
  /** Distinct businesses, which is the honest denominator — a lead can be retried. */
  leads: number;
  /** Of those, how many ever answered (status left `contatado`). */
  replied: number;
  /** Of those, how many became customers. */
  closed: number;
};

export type OutreachTemplate = {
  id: number;
  /** Null for the team's copy; a user id for somebody's own. */
  ownerId: string | null;
  intent: NicheIntent;
  speaks: TemplateLanguage;
  slot: TemplateSlot;
  name: string;
  body: string;
  active: boolean;
  authorId: string;
  authorName: string;
  createdAt: string;
  updatedAt: string;
  stats: TemplateStats;
  notes: TemplateNote[];
};

type TemplateRow = {
  id: number;
  owner_id: string | null;
  intent: string;
  speaks: string;
  name: string;
  body: string;
  active: number;
  author_id: string;
  author_name: string;
  created_at: string;
  updated_at: string;
};

/* -------------------------------------------------------------------------- */
/* Reading                                                                     */
/* -------------------------------------------------------------------------- */

/**
 * The body in force for every slot, for one person.
 *
 * Called once per page that renders outreach links and handed to
 * `outreachMessage()`. Twelve rows at most — this person's and the team's — off
 * an index, on a connection that is already open, which is what makes it
 * affordable to do per request rather than caching it and explaining to an
 * operator why their edit took a restart.
 *
 * `ownerId` absent means "the team's, whoever is asking". That is what the CSV
 * export uses for a client portal and what any caller with no session gets: a
 * message nobody has claimed rather than a stranger's private one.
 *
 * Never throws. A database that isn't there yet, or a table an older build
 * never created, has to degrade to the openers that ship rather than take down
 * every screen with a WhatsApp button on it.
 */
export function activeTemplates(ownerId?: string | null): TemplateSet {
  try {
    const rows = getDb()
      .prepare(
        `SELECT owner_id, intent, speaks, body
           FROM outreach_templates
          WHERE active = 1 AND (owner_id IS NULL OR owner_id = ?)`,
      )
      .all(ownerId ?? null) as {
      owner_id: string | null;
      intent: string;
      speaks: string;
      body: string;
    }[];

    const set: TemplateSet = {};
    // Two passes rather than an ORDER BY: the personal row must win, and a
    // sort that expresses that is a sort somebody will later "tidy up".
    for (const row of rows) {
      if (row.owner_id !== null) continue;
      const slot = `${row.intent}:${row.speaks}` as TemplateSlot;
      if (slot in DEFAULT_BODIES) set[slot] = row.body;
    }
    for (const row of rows) {
      if (row.owner_id === null) continue;
      const slot = `${row.intent}:${row.speaks}` as TemplateSlot;
      if (slot in DEFAULT_BODIES) set[slot] = row.body;
    }
    return set;
  } catch (error) {
    console.error("Could not read outreach templates", error);
    return {};
  }
}

/**
 * Everything `outreachMessage()` needs for one viewer, in one call.
 *
 * Every page that renders a WhatsApp link calls exactly this, so no page has to
 * remember that `[meu-nome]` exists or that the templates are per person. A
 * `cliente` gets the team's copy and no sender name: the portal shows them
 * their own leads, and signing our operator's name to a message they send is
 * the one thing that must not happen.
 */
export function outreachContextFor(
  user: { id: string; displayName: string; role?: string } | null,
): OutreachContext {
  const staff = user && user.role !== "cliente" ? user : null;
  return {
    templates: activeTemplates(staff?.id),
    senderName: staff?.displayName ?? null,
  };
}

/**
 * Every variant this person may see: their own and the team's, never a
 * colleague's.
 *
 * Not a privacy rule so much as a legibility one. Six slots times however many
 * people work here is a list nobody can read, and the question the screen
 * answers — "what am I sending, and is it working" — is about one person at a
 * time. The admin edits the team copy from the same screen, which is the only
 * row they hold that anybody else reads.
 */
export function listTemplates(viewerId: string): OutreachTemplate[] {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT id, owner_id, intent, speaks, name, body, active, author_id,
              author_name, created_at, updated_at
         FROM outreach_templates
        WHERE owner_id IS NULL OR owner_id = ?
        ORDER BY active DESC, updated_at DESC`,
    )
    .all(viewerId) as TemplateRow[];
  if (rows.length === 0) return [];

  const stats = statsByTemplate();
  const notes = notesByTemplate();

  return rows.map((row) => ({
    id: row.id,
    ownerId: row.owner_id,
    intent: row.intent as NicheIntent,
    speaks: row.speaks as TemplateLanguage,
    slot: `${row.intent}:${row.speaks}` as TemplateSlot,
    name: row.name,
    body: row.body,
    active: row.active === 1,
    authorId: row.author_id,
    authorName: row.author_name,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    stats: stats.get(row.id) ?? { sends: 0, leads: 0, replied: 0, closed: 0 },
    notes: notes.get(row.id) ?? [],
  }));
}

/**
 * One query for the whole screen rather than one per variant. There are never
 * many variants, but the join walks the leads table and doing it six times for
 * a page that shows six boxes is the kind of thing that is invisible until the
 * history has half a million rows in it.
 */
function statsByTemplate(): Map<number, TemplateStats> {
  const rows = getDb()
    .prepare(
      `SELECT u.template_id AS id,
              COUNT(*) AS sends,
              COUNT(DISTINCT u.lead_id) AS leads,
              COUNT(DISTINCT CASE WHEN l.status IN ('respondeu','cliente')
                                  THEN u.lead_id END) AS replied,
              COUNT(DISTINCT CASE WHEN l.status = 'cliente'
                                  THEN u.lead_id END) AS closed
         FROM outreach_template_uses u
         JOIN leads l ON l.id = u.lead_id
        GROUP BY u.template_id`,
    )
    .all() as Record<string, number>[];

  return new Map(
    rows.map((row) => [
      Number(row.id),
      {
        sends: Number(row.sends),
        leads: Number(row.leads),
        replied: Number(row.replied),
        closed: Number(row.closed),
      },
    ]),
  );
}

function notesByTemplate(): Map<number, TemplateNote[]> {
  const rows = getDb()
    .prepare(
      `SELECT id, template_id, author_id, author_name, body, created_at
         FROM outreach_template_notes
        ORDER BY created_at DESC, id DESC`,
    )
    .all() as {
    id: number;
    template_id: number;
    author_id: string;
    author_name: string;
    body: string;
    created_at: string;
  }[];

  const grouped = new Map<number, TemplateNote[]>();
  for (const row of rows) {
    const list = grouped.get(Number(row.template_id)) ?? [];
    list.push({
      id: Number(row.id),
      authorId: row.author_id,
      authorName: row.author_name,
      body: row.body,
      createdAt: row.created_at,
    });
    grouped.set(Number(row.template_id), list);
  }
  return grouped;
}

/**
 * One variant, for the routes that have to check what they are about to touch.
 *
 * Scoped like the listing, so a route cannot be handed an id belonging to
 * somebody else and act on it: it simply does not exist for this caller, which
 * is the same answer `denyOutsideScope` gives for a lead.
 */
export function findTemplate(
  id: number,
  viewerId: string,
): OutreachTemplate | null {
  return listTemplates(viewerId).find((template) => template.id === id) ?? null;
}

/* -------------------------------------------------------------------------- */
/* Writing                                                                     */
/* -------------------------------------------------------------------------- */

export type TemplateInput = {
  /** Null writes the team's copy — admin only, checked at the route. */
  ownerId: string | null;
  intent: NicheIntent;
  speaks: TemplateLanguage;
  name: string;
  body: string;
  /** Put it in front of prospects immediately, retiring whatever held the slot. */
  activate: boolean;
};

/**
 * Saves a new variant. Returns its id.
 *
 * Activation happens in the same transaction as the insert: a moment where two
 * variants of one slot are both active is a moment where which message a lead
 * receives depends on which row SQLite returns first.
 */
export function createTemplate(
  input: TemplateInput,
  author: TemplateAuthor,
): number {
  const db = getDb();
  db.exec("BEGIN");
  try {
    const id = Number(
      db
        .prepare(
          `INSERT INTO outreach_templates
             (owner_id, intent, speaks, name, body, active, author_id, author_name)
           VALUES (?, ?, ?, ?, ?, 0, ?, ?)`,
        )
        .run(
          input.ownerId,
          input.intent,
          input.speaks,
          input.name,
          input.body,
          author.id,
          author.displayName,
        ).lastInsertRowid,
    );
    if (input.activate) {
      activateWithin(db, id, input.ownerId, input.intent, input.speaks);
    }
    db.exec("COMMIT");
    return id;
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
}

/**
 * Rewrites a variant in place.
 *
 * In place, and not a new row, because the alternative is a slot with nine
 * variants that differ by a comma — the "save as a new variant" button exists
 * for when the difference is worth comparing, and that is a judgement only the
 * person typing can make. The notes stay attached either way, which is why the
 * editor warns that a rewrite makes the notes above it about a message that no
 * longer exists.
 */
export function updateTemplate(
  id: number,
  fields: { name?: string; body?: string },
): boolean {
  const sets: string[] = [];
  const values: (string | number)[] = [];
  if (fields.name !== undefined) {
    sets.push("name = ?");
    values.push(fields.name);
  }
  if (fields.body !== undefined) {
    sets.push("body = ?");
    values.push(fields.body);
  }
  if (sets.length === 0) return false;
  sets.push("updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')");

  const result = getDb()
    .prepare(`UPDATE outreach_templates SET ${sets.join(", ")} WHERE id = ?`)
    .run(...values, id);
  return Number(result.changes) > 0;
}

/** Makes one variant the message its slot sends, retiring the previous one. */
export function activateTemplate(id: number): boolean {
  const db = getDb();
  const row = db
    .prepare(
      "SELECT owner_id, intent, speaks FROM outreach_templates WHERE id = ?",
    )
    .get(id) as
    { owner_id: string | null; intent: string; speaks: string } | undefined;
  if (!row) return false;

  db.exec("BEGIN");
  try {
    activateWithin(db, id, row.owner_id, row.intent, row.speaks);
    db.exec("COMMIT");
    return true;
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
}

/**
 * The "exactly one active per owner per slot" rule, as two statements that must
 * not split.
 *
 * `IS NOT DISTINCT FROM` rather than `=`, because the team's owner is NULL and
 * `owner_id = NULL` is never true — with a plain equality, activating a team
 * variant would leave the previous team variant active too, and both messages
 * would be "the one being sent".
 */
function activateWithin(
  db: ReturnType<typeof getDb>,
  id: number,
  ownerId: string | null,
  intent: string,
  speaks: string,
): void {
  db.prepare(
    `UPDATE outreach_templates
        SET active = 0
      WHERE owner_id IS NOT DISTINCT FROM ?
        AND intent = ? AND speaks = ? AND id <> ?`,
  ).run(ownerId, intent, speaks, id);
  db.prepare(
    `UPDATE outreach_templates
        SET active = 1, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
      WHERE id = ?`,
  ).run(id);
}

/**
 * Deletes a variant and everything written about it.
 *
 * Refuses the active one. Deleting it would silently fall the slot back to the
 * level below — the team's copy, or the built-in opener — which is the right
 * answer for a row that never existed and a bewildering one for somebody who
 * spent a month tuning their message.
 *
 * To stop sending your own and go back to the team's, there is a separate
 * verb: `releaseSlot`.
 */
export function deleteTemplate(id: number): "ok" | "ativa" | "ausente" {
  const db = getDb();
  const row = db
    .prepare("SELECT active FROM outreach_templates WHERE id = ?")
    .get(id) as { active: number } | undefined;
  if (!row) return "ausente";
  if (row.active === 1) return "ativa";
  db.prepare("DELETE FROM outreach_templates WHERE id = ?").run(id);
  return "ok";
}

/**
 * Stops using your own copy of a slot and goes back to the team's.
 *
 * Deactivating rather than deleting: the text and everything written about it
 * are worth keeping, and somebody who reverts on a Tuesday usually wants the
 * old one back on Thursday. With no personal row active, `activeTemplates()`
 * falls through to the team row and then to the built-in opener, which is
 * exactly what somebody who has never opened this screen sends.
 */
export function releaseSlot(
  ownerId: string,
  intent: NicheIntent,
  speaks: TemplateLanguage,
): boolean {
  const result = getDb()
    .prepare(
      `UPDATE outreach_templates
          SET active = 0
        WHERE owner_id = ? AND intent = ? AND speaks = ? AND active = 1`,
    )
    .run(ownerId, intent, speaks);
  return Number(result.changes) > 0;
}

export function addTemplateNote(
  templateId: number,
  body: string,
  author: TemplateAuthor,
): TemplateNote | null {
  const db = getDb();
  const exists = db
    .prepare("SELECT 1 FROM outreach_templates WHERE id = ?")
    .get(templateId);
  if (!exists) return null;

  const id = Number(
    db
      .prepare(
        `INSERT INTO outreach_template_notes
           (template_id, author_id, author_name, body)
         VALUES (?, ?, ?, ?)`,
      )
      .run(templateId, author.id, author.displayName, body).lastInsertRowid,
  );

  // Read the timestamp back rather than computing one here: the column's
  // default is what every other reader sorts by, and a clock the writer picks
  // is a clock that disagrees with it by however long the insert took.
  const row = db
    .prepare("SELECT created_at FROM outreach_template_notes WHERE id = ?")
    .get(id) as { created_at: string };

  return {
    id,
    authorId: author.id,
    authorName: author.displayName,
    body,
    createdAt: row.created_at,
  };
}

/** Notes are an observation log, so only their author — or an admin — removes one. */
export function deleteTemplateNote(id: number): boolean {
  const result = getDb()
    .prepare("DELETE FROM outreach_template_notes WHERE id = ?")
    .run(id);
  return Number(result.changes) > 0;
}

export function noteAuthor(id: number): string | null {
  const row = getDb()
    .prepare("SELECT author_id FROM outreach_template_notes WHERE id = ?")
    .get(id) as { author_id: string } | undefined;
  return row?.author_id ?? null;
}

/* -------------------------------------------------------------------------- */
/* Readings                                                                    */
/* -------------------------------------------------------------------------- */

/**
 * Records that an outreach went out under whichever variant is live for the
 * lead's slot.
 *
 * Called from the outreach route, which already knows the lead and the channel.
 * The alternative — passing a template id down through every WhatsApp button on
 * every screen — would have put an experiment's bookkeeping into four client
 * components, and a button that forgets to send it is a reading that silently
 * never happens.
 *
 * Never throws, for the same reason `recordProspectorActivity` doesn't: a
 * measurement must not be able to make a contact attempt look like it failed.
 */
export function recordTemplateUse(input: {
  leadId: string;
  actorId: string;
  channel: string;
}): void {
  try {
    const db = getDb();
    const lead = db
      .prepare("SELECT category, country FROM leads WHERE id = ?")
      .get(input.leadId) as
      { category: string | null; country: string | null } | undefined;
    if (!lead) return;

    // Resolved from the lead's own fields with the same two functions
    // `outreachMessage()` uses, so the reading is filed under the variant the
    // link was actually written from. Deriving it any other way — from the
    // stored niche, say — would file a partner approach under the client
    // opener the moment those two disagree.
    const intent = intentForCategory(lead.category);
    const speaks = (findCountry(lead.country ?? "BR") ?? findCountry("BR")!)
      .speaks;

    // Own before team, the same order `activeTemplates()` resolves in — and
    // expressed as an ORDER BY here because this one wants a single row.
    // Reading it any other way would file the send under the team's copy for
    // somebody who has written their own, which is precisely the person whose
    // numbers matter.
    const row = db
      .prepare(
        `SELECT id FROM outreach_templates
          WHERE intent = ? AND speaks = ? AND active = 1
            AND (owner_id IS NULL OR owner_id = ?)
          ORDER BY owner_id IS NULL
          LIMIT 1`,
      )
      .get(intent, speaks, input.actorId) as { id: number } | undefined;
    // No row means the slot is still on the built-in opener. There is nothing
    // to attribute the send to, and inventing a row for the default would make
    // it look like somebody chose it.
    if (!row) return;

    db.prepare(
      `INSERT INTO outreach_template_uses (template_id, lead_id, actor_id, channel)
       VALUES (?, ?, ?, ?)`,
    ).run(Number(row.id), input.leadId, input.actorId, input.channel);
  } catch (error) {
    console.error("Could not record outreach template use", error);
  }
}

/** Shared by the routes: the body is free text, but it is not unbounded. */
export function invalidBody(body: string): string | null {
  const trimmed = body.trim();
  if (trimmed.length === 0) return "A mensagem não pode ficar vazia.";
  if (trimmed.length > MAX_BODY_LENGTH) {
    return `Mensagem muito longa (máx. ${MAX_BODY_LENGTH} caracteres).`;
  }
  return null;
}
