import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { after, before, describe, it } from "node:test";

/**
 * "Has anybody here already reached out to this business?"
 *
 * The question every WhatsApp and telephone button on the live search, the
 * history and the CRM table now asks before it is pressed. Getting it wrong is
 * silent in both directions and only one of them is recoverable: a missing mark
 * means a prospect is cold-called twice by two people, which is the one mistake
 * they always notice.
 *
 * The three things worth pinning are the three that would fail quietly —
 * absence meaning "not contacted" rather than "not asked", a message counting as
 * contact even with no call logged, and a client account's outreach never
 * reaching our screens.
 *
 * PROSPECTOR_DB must be set before db.ts is imported: it reads the path when the
 * connection is first opened. Hence the dynamic imports inside `before`.
 */

let history: typeof import("./history");
let calls: typeof import("./calls");
let db: typeof import("./db");
let dir: string;

const ACTOR = { id: "u1", displayName: "Ana" };

function seed(id: string, name: string, accountId: string | null): void {
  db.getDb()
    .prepare(
      `INSERT INTO leads (id, name, account_id, phone, country, city, uf,
                          confidence, score, search_norm)
       VALUES (?, ?, ?, '+5531987911222', 'BR', 'Belo Horizonte', 'MG', 0.9, 70, ?)`,
    )
    .run(id, name, accountId, name.toLowerCase());
}

before(async () => {
  dir = mkdtempSync(path.join(tmpdir(), "contact-history-test-"));
  process.env.PROSPECTOR_DB = path.join(dir, "prospector.db");
  db = await import("./db");
  calls = await import("./calls");
  history = await import("./history");

  seed("virgem", "Padaria Nunca Tocada", null);
  seed("mensagem", "Barbearia So Mensagem", null);
  seed("ligada", "Clinica Ja Ligada", null);
  seed("cliente", "Salao De Outra Conta", "conta-a");
});

after(() => rmSync(dir, { recursive: true, force: true }));

describe("contactHistoryFor", () => {
  it("says nothing about a lead nobody has contacted", () => {
    const found = history.contactHistoryFor(["virgem"]);
    // Absence is the answer. A row saying "contacted: null" would have to be
    // told apart from a row that is simply missing, and the caller decorating
    // 200 search results would carry 200 of them.
    assert.equal(found.size, 0);
    assert.equal(found.get("virgem"), undefined);
  });

  it("counts a message as contact, even with no call logged", () => {
    // This is the case reading `lead_calls` alone gets wrong: opening WhatsApp
    // from the prospector stamps contacted_at and writes no call row at all.
    history.recordOutreach("mensagem");

    const entry = history.contactHistoryFor(["mensagem"]).get("mensagem")!;
    assert.ok(entry.contactedAt);
    assert.equal(entry.attempts, 0);
    assert.equal(entry.owner, null);
  });

  it("carries the dial count and the owner once somebody has phoned", () => {
    calls.recordCall({ leadId: "ligada", outcome: "nao_atendeu", actor: ACTOR });
    calls.recordCall({ leadId: "ligada", outcome: "interessado", actor: ACTOR });

    const entry = history.contactHistoryFor(["ligada"]).get("ligada")!;
    assert.ok(entry.contactedAt);
    assert.equal(entry.attempts, 2);
    assert.equal(entry.owner?.name, ACTOR.displayName);
  });

  it("carries the stage, so a closed lead can say so", () => {
    // The second warning a contact button owes, and it rides along with the
    // first rather than costing a second query per rendered page.
    history.setFunnelStage("mensagem", "perdido");
    assert.equal(
      history.contactHistoryFor(["mensagem"]).get("mensagem")?.funnelStage,
      "perdido",
    );

    history.setFunnelStage("mensagem", "contato");
    assert.equal(
      history.contactHistoryFor(["mensagem"]).get("mensagem")?.funnelStage,
      "contato",
    );
  });

  it("never reports a client account's outreach", () => {
    history.recordOutreach("cliente");
    // Contacted, and still invisible: our screens must not be told what a
    // client did with their own pipeline.
    assert.equal(history.contactHistoryFor(["cliente"]).size, 0);
  });

  it("answers for a whole page of ids in one call, and for none in zero", () => {
    assert.equal(history.contactHistoryFor([]).size, 0);
    const ids = ["virgem", "mensagem", "ligada", "cliente", "nao-existe"];
    assert.deepEqual(
      [...history.contactHistoryFor(ids).keys()].sort(),
      ["ligada", "mensagem"],
    );
  });
});

describe("CLOSED_STAGES", () => {
  it("is every stage whose status ends the conversation", async () => {
    const types = await import("./types");
    assert.deepEqual(types.CLOSED_STAGES, ["fechado", "perdido"]);

    // Derived, not written out: a stage added to the funnel and forgotten here
    // would quietly re-enter the calling queue, and a won customer being
    // cold-pitched again reports itself as nothing at all.
    for (const stage of types.FUNNEL_STAGES) {
      const ends =
        types.STAGE_STATUS[stage] === "cliente" ||
        types.STAGE_STATUS[stage] === "descartado";
      assert.equal(types.isClosedStage(stage), ends, stage);
    }
    assert.equal(types.isClosedStage(null), false);
  });
});
