import assert from "node:assert/strict";
import test from "node:test";
import { COUNTRIES } from "@/lib/countries";
import {
  isWhatsappCapable,
  normalisePhone,
  outreachMessage,
  scoreLead,
  whatsappUrl,
} from "./score";

const lead = (over: Partial<Parameters<typeof scoreLead>[0]> = {}) => ({
  id: "x",
  name: "Barbearia",
  category: "barber",
  address: null,
  city: null,
  uf: null,
  country: null,
  phone: null,
  website: null,
  social: null,
  email: null,
  lat: null,
  lon: null,
  confidence: 0.9,
  ...over,
});

test("a Brazilian mobile is reachable, a landline is not", () => {
  assert.equal(isWhatsappCapable("(31) 99999-1234", "BR"), true);
  assert.equal(isWhatsappCapable("+55 31 99999-1234", "BR"), true);
  assert.equal(isWhatsappCapable("(31) 3222-1111", "BR"), false);
});

test("no country means Brazil, which is what the older rows are", () => {
  assert.equal(isWhatsappCapable("+55 31 99999-1234"), true);
  assert.equal(normalisePhone("(31) 99999-1234"), "5531999991234");
});

test("the same digits mean different things in different countries", () => {
  // A Portuguese mobile, and the same national number read as Brazilian is not
  // a mobile at all — which is the whole reason the country is carried around.
  assert.equal(isWhatsappCapable("912 345 678", "PT"), true);
  assert.equal(isWhatsappCapable("+351 22 123 4567", "PT"), false);
  assert.equal(isWhatsappCapable("0171 2345678", "DE"), true);
  assert.equal(isWhatsappCapable("+49 30 123456", "DE"), false);
});

test("a trunk zero is stripped, a country code is not doubled", () => {
  assert.equal(normalisePhone("0171 2345678", "DE"), "491712345678");
  assert.equal(normalisePhone("+49 171 2345678", "DE"), "491712345678");
});

test("a country whose plan can't tell mobiles apart can still be messaged", () => {
  // The US and Canada share one format for both, so this remains false as a
  // qualification signal. The prospector still gives the operator a WhatsApp
  // link for every valid phone number.
  assert.equal(isWhatsappCapable("+1 415 555 0123", "US"), false);
  assert.ok(
    whatsappUrl("+1 415 555 0123", "oi", "US")?.startsWith(
      "https://wa.me/14155550123?text=",
    ),
  );
});

test("the wa.me link carries the country code of the country it is in", () => {
  const url = whatsappUrl("912 345 678", "olá", "PT");
  assert.ok(url?.startsWith("https://wa.me/351912345678?text="));
});

test("the opener is written in the language the country answers in", () => {
  assert.match(outreachMessage(lead({ country: "BR" })), /me surgiu uma ideia/);
  assert.match(outreachMessage(lead({ country: "PT" })), /me surgiu uma ideia/);
  assert.match(
    outreachMessage(lead({ country: "ES" })),
    /se me ocurrió una idea/,
  );
  assert.match(outreachMessage(lead({ country: "DE" })), /had an idea/);
  // Unknown code falls back to Brazil, the same way every other reader does.
  assert.match(outreachMessage(lead({ country: "ZZ" })), /me surgiu uma ideia/);
});

test("an edited template replaces the built-in opener for its slot alone", () => {
  const edited = {
    templates: { "cliente:pt": "Oi [nome], tudo certo com o [negócio]?" },
  };

  assert.equal(
    outreachMessage(
      lead({ country: "BR", name: "Barbearia Rex" }),
      undefined,
      edited,
    ),
    "Oi, tudo certo com o Barbearia Rex?",
  );
  // The slot is (audience, language), so the Spanish opener is untouched by an
  // edit to the Portuguese one — which is the whole reason there are six.
  assert.match(
    outreachMessage(lead({ country: "ES" }), undefined, edited),
    /se me ocurrió una idea/,
  );
});

test("[meu-nome] is the sender, never the person who wrote the template", () => {
  const body = { templates: { "cliente:pt": "Sou o [meu-nome], da Mandra." } };
  assert.equal(
    outreachMessage(lead({ country: "BR" }), undefined, {
      ...body,
      senderName: "Pedro",
    }),
    "Sou o Pedro, da Mandra.",
  );
  // No session behind the render — a CSV built for a client portal — closes
  // the gap rather than signing with somebody who is not sending it.
  assert.equal(
    outreachMessage(lead({ country: "BR" }), undefined, body),
    "Sou o, da Mandra.",
  );
});

test("a contact name fills [nome], and its absence closes the gap", () => {
  const withName = outreachMessage({
    ...lead({ country: "BR" }),
    contactName: "Marina",
  });
  assert.match(withName, /^Oi Marina! Tudo bem\?/);
  assert.match(outreachMessage(lead({ country: "BR" })), /^Oi! Tudo bem\?/);
});

test("scoring reads the lead's own country", () => {
  const german = scoreLead(lead({ country: "DE", phone: "+49 171 2345678" }));
  assert.equal(german.whatsapp, true);
  assert.ok(german.reasons.includes("WhatsApp"));
  const same = scoreLead(lead({ country: "BR", phone: "+49 171 2345678" }));
  assert.equal(same.whatsapp, false);
});

test("every mobile pattern is one both JS and DuckDB can run", () => {
  // The counts in the header come from the SQL half of this rule (whatsappSql in
  // overture.ts) and the buttons from the JS half. A pattern that only one of
  // them accepts is a count that disagrees with the rows under it — and the SQL
  // one is interpolated, so a quote in here would end the string literal.
  for (const country of COUNTRIES) {
    if (!country.mobile) continue;
    assert.doesNotThrow(
      () => new RegExp(country.mobile!),
      `${country.code}: not a valid regex`,
    );
    assert.match(
      country.mobile,
      /^[\^\$0-9A-Za-z()|\[\]{},.*+?-]+$/,
      `${country.code}: pattern is not safe to interpolate into SQL`,
    );
    assert.match(
      country.dial,
      /^[0-9]{1,4}$/,
      `${country.code}: bad dial code`,
    );
  }
});
