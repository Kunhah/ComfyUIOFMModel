import { getDb } from "./db";
import { SELECT_COLUMNS, toStored, type LeadRow } from "./history";
import { normalisePhone } from "./score";
import {
  AVAILABLE_SQL,
  GOOD_PHONE_CTE_SQL,
  phonePoolStats,
  PHONE_QUALITY_CTE,
  PHONE_QUALITY_JOINS,
  QUEUE_ORDER_SQL,
} from "./phone-quality";
import {
  blockFor,
  blockedClause,
  releaseClaim,
  takeOwnership,
  type ClaimActor,
  type LeadBlock,
} from "./ownership";
import {
  CALL_OUTCOMES,
  CLOSED_STAGES,
  FUNNEL_STAGES,
  NEXT_STEPS,
  NEXT_STEP_DEFAULT_DAYS,
  NEXT_STEP_STAGE,
  OUTCOME_REACHED,
  OUTCOME_STAGE,
  OUTCOME_TERMINAL,
  STAGE_RANK,
  STAGE_STATUS,
  type CallList,
  type CallLog,
  type CallOutcome,
  type CallQueueItem,
  type FunnelStage,
  type NextStep,
  type StoredLead,
} from "./types";

/**
 * Cold calling: an ordered queue, and what each call did to the pipeline.
 *
 * The CRM already answers "who should I talk to" (the history, filtered) and
 * "how far has this deal come" (`funnel_stage`). What it could not answer is the
 * question a calling session actually asks — *where was I* — and that has to be
 * server-side state, not a cursor in the operator's browser: a session is picked
 * up the next morning, on a different machine, sometimes by a different person.
 *
 * Hence one row per queue position with its own `state`, and one row per dial in
 * `lead_calls`. `recordCall` is the only writer that closes both at once, in a
 * transaction, so a recorded call can never leave the queue thinking the lead is
 * still pending — which would hand the same business to the next operator to
 * dial a second time.
 *
 * That last guarantee only ever covered one operator's own queue. Who may work a
 * lead *at all* is `ownership.ts`: a live reservation while somebody is dialling,
 * and a permanent owner once they have actually spoken to them. Every function
 * here that hands a lead out or records a contact against one takes the acting
 * operator for that reason, and the queue applies the same predicate the routes
 * enforce — a queue that offers what the outcome endpoint will refuse is worse
 * than no queue.
 */

type Param = string | number | null;

/* -------------------------------------------------------------------------- */
/* Validation                                                                  */
/* -------------------------------------------------------------------------- */

export function isCallOutcome(value: unknown): value is CallOutcome {
  return (
    typeof value === "string" && CALL_OUTCOMES.includes(value as CallOutcome)
  );
}

export function isNextStep(value: unknown): value is NextStep {
  return typeof value === "string" && NEXT_STEPS.includes(value as NextStep);
}

/** Enough to name a campaign, short enough to stay one line in the sidebar. */
export const MAX_LIST_NAME = 60;

/**
 * A ceiling on one list. Not a database limit — it is a working limit: a queue
 * nobody can finish is a queue nobody starts, and the honest fix for 4.000 leads
 * is four lists, not one that reports 3% forever.
 */
export const MAX_LIST_SIZE = 500;

/** Control characters, including the newlines a paste from a spreadsheet brings. */
const CONTROL = /[\u0000-\u001f\u007f]/g;

export function normaliseListName(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  const cleaned = raw.replace(CONTROL, " ").replace(/\s+/g, " ").trim();
  if (cleaned.length === 0) return null;
  return cleaned.slice(0, MAX_LIST_NAME);
}

/* -------------------------------------------------------------------------- */
/* Lists                                                                       */
/* -------------------------------------------------------------------------- */

type ListRow = {
  id: number;
  name: string;
  created_by_id: string;
  created_by_name: string;
  source_query: string | null;
  created_at: string;
  total: number;
  done: number;
  skipped: number;
};

/**
 * The counters are computed in SQL rather than by reading the items back and
 * counting in JS — the same rule the rest of this codebase follows, and here it
 * is what lets the index page render fifty lists with one query.
 */
const LIST_SELECT = `
  SELECT l.id, l.name, l.created_by_id, l.created_by_name, l.source_query, l.created_at,
         COUNT(i.lead_id)                        AS total,
         COALESCE(SUM(i.state = 'concluido'), 0) AS done,
         COALESCE(SUM(i.state = 'pulado'), 0)    AS skipped
    FROM call_lists l
    LEFT JOIN call_list_items i ON i.list_id = l.id
`;

function toList(r: ListRow): CallList {
  const total = Number(r.total);
  const done = Number(r.done);
  const skipped = Number(r.skipped);
  return {
    id: Number(r.id),
    name: r.name,
    createdById: r.created_by_id,
    createdByName: r.created_by_name,
    createdAt: r.created_at,
    sourceQuery: r.source_query,
    total,
    done,
    skipped,
    // Derived rather than stored: a lead deleted from the CRM cascades its queue
    // row away, and a stored "pending" would keep counting work that is gone.
    pending: total - done - skipped,
  };
}

export function callLists(): CallList[] {
  const rows = getDb()
    .prepare(`${LIST_SELECT} GROUP BY l.id ORDER BY l.created_at DESC`)
    .all() as ListRow[];
  return rows.map(toList);
}

export function callList(id: number): CallList | null {
  const row = getDb()
    .prepare(`${LIST_SELECT} WHERE l.id = ? GROUP BY l.id`)
    .get(id) as ListRow | undefined;
  return row && row.id !== null ? toList(row) : null;
}

/**
 * `'fechado','perdido'` as a SQL list, built from `CLOSED_STAGES` so the queue
 * and the list builder cannot disagree about which stages are over. Safe to
 * interpolate: the values come from our own union type, never from a request.
 */
const CLOSED_STAGES_SQL = CLOSED_STAGES.map((stage) => `'${stage}'`).join(",");

/**
 * Build a list from an explicit, already-ordered set of lead ids.
 *
 * The caller decides the order — normally the history's current sort, so the
 * queue arrives in the order the operator was looking at. Ids that aren't in
 * `leads` are dropped rather than inserted: the foreign key would reject them
 * anyway, and failing the whole list because one lead was deleted mid-build is
 * the wrong answer to a race nobody can see.
 *
 * Leads with no phone number are dropped for a sharper reason: this is a queue
 * of calls, and a position nobody can dial is one the operator has to skip past
 * every time they reach it. They stay in the CRM, where WhatsApp and e-mail are
 * still open to them. `list.total` against the ids you passed is what tells you
 * how many went — the caller reports the difference rather than guessing at it.
 *
 * Returns the created list, or null when nothing survived the filter.
 */
export function createCallList(input: {
  name: string;
  leadIds: string[];
  actor: ClaimActor;
  sourceQuery?: string | null;
}): CallList | null {
  const db = getDb();

  // De-duplicated with insertion order preserved: the composite primary key
  // would reject the second copy, and a list that dials the same business twice
  // is exactly what an operator will notice and stop trusting.
  const ids = [...new Set(input.leadIds.filter((id) => id.length > 0))].slice(
    0,
    MAX_LIST_SIZE,
  );
  if (ids.length === 0) return null;

  // Leads another operator owns or is dialling right now are dropped here, not
  // at the moment they come up in the queue. A list that contains them looks
  // like work and is not: every one of those positions would be refused by the
  // outcome route, and the operator would have skipped past them one at a time
  // to find out. The caller reports the difference — see `excluded` in the route.
  //
  // Closed and lost leads are dropped for a different reason: the conversation
  // is over. `dailyCandidates` has always excluded them, so the automatic queue
  // never offered one; a list built from a CRM filter went straight past that
  // and handed an operator a customer to cold-pitch, or a business that already
  // said no. Both paths now agree, and both read `CLOSED_STAGES`.
  const blocked = blockedClause(input.actor);
  const known = new Set(
    (
      db
        .prepare(
          `SELECT id FROM leads
            WHERE id IN (${ids.map(() => "?").join(",")})
              AND phone IS NOT NULL AND phone != ''
              AND funnel_stage NOT IN (${CLOSED_STAGES_SQL})
              AND NOT ${blocked.sql}`,
        )
        .all(...ids, ...blocked.params) as { id: string }[]
    ).map((r) => r.id),
  );
  const ordered = ids.filter((id) => known.has(id));
  if (ordered.length === 0) return null;

  db.exec("BEGIN");
  try {
    const listId = Number(
      db
        .prepare(
          `INSERT INTO call_lists (name, created_by_id, created_by_name, source_query)
           VALUES (?, ?, ?, ?)`,
        )
        .run(
          input.name,
          input.actor.id,
          input.actor.displayName,
          input.sourceQuery ?? null,
        ).lastInsertRowid,
    );
    const item = db.prepare(
      "INSERT INTO call_list_items (list_id, lead_id, position) VALUES (?, ?, ?)",
    );
    ordered.forEach((leadId, index) => item.run(listId, leadId, index));
    db.exec("COMMIT");
    return callList(listId);
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}

/** Removes a list and its positions. The calls themselves survive, unattached. */
export function deleteCallList(id: number): boolean {
  const result = getDb().prepare("DELETE FROM call_lists WHERE id = ?").run(id);
  return Number(result.changes) > 0;
}

/**
 * Puts every skipped position back in the queue.
 *
 * Skipping is for "not now" — a bad moment, a number that needs looking up —
 * and without this the only way to get those back is to rebuild the list, which
 * loses everything already done in it.
 */
export function resetSkipped(listId: number): number {
  const result = getDb()
    .prepare(
      "UPDATE call_list_items SET state = 'pendente' WHERE list_id = ? AND state = 'pulado'",
    )
    .run(listId);
  return Number(result.changes);
}

/* -------------------------------------------------------------------------- */
/* The queue                                                                   */
/* -------------------------------------------------------------------------- */

type ItemRow = LeadRow & { position: number; state: string };

const QUEUE_SELECT = `
  SELECT ${SELECT_COLUMNS}, i.position AS position, i.state AS state
    FROM call_list_items i
    JOIN leads ON leads.id = i.lead_id
`;

/**
 * `history` is opt-in because it costs a query per row. The dialer wants it — it
 * is the most useful thing on the screen while the phone rings — and a whole-list
 * overview does not, which at 500 positions is the difference between one query
 * and 501.
 */
function toQueueItem(
  listId: number,
  r: ItemRow,
  options: { history?: boolean } = {},
): CallQueueItem {
  return {
    listId,
    leadId: r.id,
    position: Number(r.position),
    state:
      r.state === "concluido" || r.state === "pulado" ? r.state : "pendente",
    lead: toStored(r),
    history: options.history ? callHistory(r.id) : [],
  };
}

/**
 * The next lead to dial: the lowest pending position.
 *
 * Position order rather than score order, because the ordering decision was made
 * once when the list was built. Re-sorting the queue as it is worked would mean
 * the operator never knows what is coming, and a lead whose score changed on a
 * re-search could jump the queue it had already passed through.
 */
export function nextInList(
  listId: number,
  actor?: ClaimActor,
): CallQueueItem | null {
  // Positions closed to this operator are stepped over rather than removed: the
  // block can lapse (a reservation expires, an admin hands a lead back), and a
  // list that deleted them would have quietly lost the work. The position keeps
  // its `pendente` state and simply isn't offered to this person today.
  const blocked = actor ? blockedClause(actor) : { sql: "0", params: [] };
  const row = getDb()
    .prepare(
      `${QUEUE_SELECT} WHERE i.list_id = ? AND i.state = 'pendente'
         AND NOT ${blocked.sql}
       ORDER BY i.position ASC LIMIT 1`,
    )
    .get(listId, ...blocked.params) as ItemRow | undefined;
  return row ? toQueueItem(listId, row, { history: true }) : null;
}

/**
 * How many pending positions in this list are closed to this operator.
 *
 * The honest half of `nextInList` stepping over them: without this the queue
 * counter says eighty pending and hands back "fila vazia", which reads as a bug
 * rather than as eighty leads that belong to somebody else.
 */
export function blockedInList(listId: number, actor: ClaimActor): number {
  const blocked = blockedClause(actor);
  if (blocked.params.length === 0) return 0;
  const row = getDb()
    .prepare(
      `SELECT COUNT(*) AS n
         FROM call_list_items i
         JOIN leads ON leads.id = i.lead_id
        WHERE i.list_id = ? AND i.state = 'pendente' AND ${blocked.sql}`,
    )
    .get(listId, ...blocked.params) as { n: number };
  return Number(row.n);
}

/** One named position, for resuming or for jumping back to a lead. */
export function itemInList(
  listId: number,
  leadId: string,
): CallQueueItem | null {
  const row = getDb()
    .prepare(`${QUEUE_SELECT} WHERE i.list_id = ? AND i.lead_id = ?`)
    .get(listId, leadId) as ItemRow | undefined;
  return row ? toQueueItem(listId, row, { history: true }) : null;
}

/**
 * The whole queue in order, for a list overview. Without each lead's call
 * history — see `toQueueItem`.
 */
export function listItems(listId: number): CallQueueItem[] {
  const rows = getDb()
    .prepare(`${QUEUE_SELECT} WHERE i.list_id = ? ORDER BY i.position ASC`)
    .all(listId) as ItemRow[];
  return rows.map((r) => toQueueItem(listId, r));
}

/**
 * Take a position out of the queue without recording a call against it.
 *
 * Releases the operator's reservation as it goes: skipping is the operator
 * saying they are not going to call this one, and a lead they have moved past
 * must not stay locked to them for the rest of the claim's life. No ownership is
 * taken — nothing was contacted.
 */
export function skipItem(
  listId: number,
  leadId: string,
  actorId?: string,
): boolean {
  const result = getDb()
    .prepare(
      `UPDATE call_list_items SET state = 'pulado'
       WHERE list_id = ? AND lead_id = ? AND state = 'pendente'`,
    )
    .run(listId, leadId);
  if (actorId) releaseClaim(leadId, actorId);
  return Number(result.changes) > 0;
}

/* -------------------------------------------------------------------------- */
/* Recording a call                                                            */
/* -------------------------------------------------------------------------- */

type CallRow = {
  id: number;
  lead_id: string;
  list_id: number | null;
  actor_id: string;
  actor_display_name: string;
  outcome: string;
  next_step: string;
  notes: string | null;
  phone: string | null;
  occurred_at: string;
};

function toCallLog(r: CallRow): CallLog {
  return {
    id: Number(r.id),
    leadId: r.lead_id,
    listId: r.list_id === null ? null : Number(r.list_id),
    actorId: r.actor_id,
    actorDisplayName: r.actor_display_name,
    // Degraded rather than thrown on: these are read back on a screen the
    // operator is mid-call on, and a hand-edited database must not blank it.
    outcome: isCallOutcome(r.outcome) ? r.outcome : "nao_atendeu",
    nextStep: isNextStep(r.next_step) ? r.next_step : "nenhum",
    notes: r.notes,
    phone: r.phone,
    occurredAt: r.occurred_at,
  };
}

/** Every call recorded against one lead, newest first. */
export function callHistory(leadId: string): CallLog[] {
  const rows = getDb()
    .prepare(
      `SELECT id, lead_id, list_id, actor_id, actor_display_name, outcome,
              next_step, notes, phone, occurred_at
         FROM lead_calls WHERE lead_id = ? ORDER BY occurred_at DESC, id DESC`,
    )
    .all(leadId) as CallRow[];
  return rows.map(toCallLog);
}

/**
 * The stage a call moves the lead to, or null to leave it where it is.
 *
 * Exported because it is the rule the whole feature turns on, and a rule that
 * only exists inside a transaction is a rule nothing can test. Both the outcome
 * and the next step propose a stage; the later of the two wins, and neither is
 * applied when the lead is already further along — a "não atendeu" on a lead in
 * negociação is a missed call, not a demotion. Terminal outcomes bypass all of
 * it: "sem interesse" from a lead in proposta is precisely the news that matters.
 */
export function stageAfterCall(
  current: FunnelStage,
  outcome: CallOutcome,
  nextStep: NextStep,
): FunnelStage | null {
  if (OUTCOME_TERMINAL[outcome]) {
    const terminal = OUTCOME_STAGE[outcome];
    return terminal === current ? null : terminal;
  }

  const proposed = [OUTCOME_STAGE[outcome], NEXT_STEP_STAGE[nextStep]].filter(
    (s): s is FunnelStage => s !== undefined,
  );
  let best = current;
  for (const stage of proposed) {
    if (STAGE_RANK[stage] > STAGE_RANK[best]) best = stage;
  }
  // A lead already marked perdido ranks 0 like descoberta, so it does move when
  // a later call goes well — which is right: it is back in the pipeline.
  return best === current ? null : best;
}

export type RecordCallInput = {
  leadId: string;
  listId?: number | null;
  outcome: CallOutcome;
  nextStep?: NextStep;
  notes?: string | null;
  /** YYYY-MM-DD. Omitted means "use the next step's default"; null means none. */
  followUpAt?: string | null;
  actor: ClaimActor;
};

export type RecordCallResult = {
  callId: number;
  stage: FunnelStage;
  /** Null when the call scheduled nothing — a lost lead leaves the queue. */
  followUpAt: string | null;
  /** How many times this lead has now been dialled, this call included. */
  attempts: number;
  /** True when this call is the one that made the lead theirs. */
  becameOwner: boolean;
};

/**
 * Why a call could not be recorded. `null` from `recordCall` still means "no
 * such lead"; this is the other refusal, and it is a different answer to give.
 */
export type RecordCallRefusal = { blocked: LeadBlock };

export function isRefusal(
  result: RecordCallResult | RecordCallRefusal | null,
): result is RecordCallRefusal {
  return result !== null && "blocked" in result;
}

/**
 * Record one call and settle everything it decided, in a single transaction.
 *
 * Four things move together and must not be able to disagree: the call log, the
 * queue position, the lead's stage/status pair, and the follow-up date. Writing
 * them separately is how you get a lead marked "sem interesse" that is still
 * pending in the queue, or a closed deal still due for a call on Friday.
 *
 * Returns null when the lead isn't in the history.
 */
export function recordCall(
  input: RecordCallInput,
): RecordCallResult | RecordCallRefusal | null {
  const db = getDb();
  const lead = db
    .prepare("SELECT funnel_stage, phone, country FROM leads WHERE id = ?")
    .get(input.leadId) as
    | { funnel_stage: string; phone: string | null; country: string | null }
    | undefined;
  if (!lead) return null;

  // Checked here rather than only in the route, because this is the writer: a
  // call recorded against somebody else's lead moves their pipeline, stamps
  // their prospect as contacted by us twice, and cannot be taken back. The
  // route's own check is the one that produces a good error message; this is the
  // one that makes the rule true.
  const blocked = blockFor(input.leadId, input.actor);
  if (blocked) return { blocked };

  const current = FUNNEL_STAGES.includes(lead.funnel_stage as FunnelStage)
    ? (lead.funnel_stage as FunnelStage)
    : "descoberta";
  const nextStep = input.nextStep ?? "nenhum";
  const stage = stageAfterCall(current, input.outcome, nextStep) ?? current;

  // An explicit date wins; otherwise the next step's own default. `undefined`
  // and `null` mean different things here and the route preserves the difference:
  // "I didn't say" is not "no follow-up".
  const explicit = input.followUpAt !== undefined;
  const followUpDays = explicit ? null : NEXT_STEP_DEFAULT_DAYS[nextStep];

  // Terminal stages leave the queue whatever anyone asked for. A follow-up on a
  // lead marked perdido is work that will be opened and closed again forever.
  const terminal = stage === "fechado" || stage === "perdido";

  const notes = input.notes?.trim();
  const phone = normalisePhone(lead.phone, lead.country);

  db.exec("BEGIN");
  let callId: number;
  let becameOwner = false;
  try {
    callId = Number(
      db
        .prepare(
          `INSERT INTO lead_calls
             (lead_id, list_id, actor_id, actor_display_name, outcome, next_step, notes, phone)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        )
        .run(
          input.leadId,
          input.listId ?? null,
          input.actor.id,
          input.actor.displayName,
          input.outcome,
          nextStep,
          notes && notes.length > 0 ? notes : null,
          phone,
        ).lastInsertRowid,
    );

    // `contacted_at` is stamped on any dial, reached or not: the CRM's question
    // is "has anyone worked this lead", and a rung-out number was work. Whether
    // a human was actually spoken to is what OUTCOME_REACHED and the log answer.
    const sets: string[] = [
      "funnel_stage = ?",
      "status = ?",
      "in_funnel = 1",
      "contacted_at = COALESCE(contacted_at, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))",
    ];
    const params: Param[] = [stage, STAGE_STATUS[stage]];

    if (terminal) {
      sets.push("next_follow_up_at = NULL");
    } else if (explicit) {
      sets.push("next_follow_up_at = ?");
      params.push(input.followUpAt ?? null);
    } else if (followUpDays !== null) {
      // Overwritten, not COALESCEd: the operator has just spoken to them and
      // said when to come back. A stale date from an earlier call is exactly
      // what this replaces. The interval is interpolated because SQLite's
      // date() takes the modifier as one literal string — it is a number from
      // NEXT_STEP_DEFAULT_DAYS, never from the request.
      sets.push(
        `next_follow_up_at = date('now', 'localtime', '+${followUpDays} days')`,
      );
    } else {
      sets.push("next_follow_up_at = NULL");
    }

    db.prepare(`UPDATE leads SET ${sets.join(", ")} WHERE id = ?`).run(
      ...params,
      input.leadId,
    );

    if (input.listId) {
      db.prepare(
        `UPDATE call_list_items SET state = 'concluido'
         WHERE list_id = ? AND lead_id = ?`,
      ).run(input.listId, input.leadId);
    }

    // The fifth thing that has to move with the other four. A call logged
    // outside this transaction and an owner stamped inside it can disagree
    // exactly once — on the call that first reaches a lead, which is the only
    // one where the answer matters.
    becameOwner = takeOwnership(input.leadId, input.actor);
    // The reservation existed to protect this moment; the moment has passed.
    // Ownership carries the exclusivity from here on, and leaving the claim
    // behind would only make the lead unreachable for its own owner from another
    // machine for the next twenty minutes.
    releaseClaim(input.leadId, input.actor.id);

    db.exec("COMMIT");
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }

  const row = db
    .prepare(
      `SELECT next_follow_up_at,
              (SELECT COUNT(*) FROM lead_calls WHERE lead_id = ?) AS attempts
         FROM leads WHERE id = ?`,
    )
    .get(input.leadId, input.leadId) as {
    next_follow_up_at: string | null;
    attempts: number;
  };

  return {
    callId,
    stage,
    followUpAt: row.next_follow_up_at,
    attempts: Number(row.attempts),
    becameOwner,
  };
}

/* -------------------------------------------------------------------------- */
/* Reporting                                                                   */
/* -------------------------------------------------------------------------- */

export type CallStats = {
  total: number;
  /** Calls where a human was actually spoken to. */
  reached: number;
  today: number;
  byOutcome: { outcome: CallOutcome; count: number }[];
};

/**
 * How the calling is going, optionally for one list or one operator.
 *
 * "Today" folds `occurred_at` to a local calendar day on both sides, like every
 * other today-counter in this codebase: the timestamps are UTC and the working
 * day belongs to whoever is dialling, so a plain prefix match files an evening's
 * calls under tomorrow and the counter resets mid-afternoon.
 */
export function callStats(
  scope: { listId?: number; actorId?: string } = {},
): CallStats {
  const clauses: string[] = [];
  const params: Param[] = [];
  if (scope.listId) {
    clauses.push("list_id = ?");
    params.push(scope.listId);
  }
  if (scope.actorId) {
    clauses.push("actor_id = ?");
    params.push(scope.actorId);
  }
  const where = clauses.length > 0 ? `WHERE ${clauses.join(" AND ")}` : "";
  const db = getDb();

  const rows = db
    .prepare(
      `SELECT outcome, COUNT(*) AS count FROM lead_calls ${where} GROUP BY outcome`,
    )
    .all(...params) as { outcome: string; count: number }[];

  const today = Number(
    (
      db
        .prepare(
          `SELECT COUNT(*) AS count FROM lead_calls ${where}
           ${where ? "AND" : "WHERE"} date(occurred_at, 'localtime') = date('now', 'localtime')`,
        )
        .get(...params) as { count: number }
    ).count,
  );

  const byOutcome = CALL_OUTCOMES.map((outcome) => ({
    outcome,
    count: Number(rows.find((r) => r.outcome === outcome)?.count ?? 0),
  }));

  return {
    total: byOutcome.reduce((sum, r) => sum + r.count, 0),
    reached: byOutcome
      .filter((r) => OUTCOME_REACHED[r.outcome])
      .reduce((sum, r) => sum + r.count, 0),
    today,
    byOutcome,
  };
}

/** One operator's day at the phone. */
export type DailyCalls = {
  actorId: string;
  actorDisplayName: string;
  /** Dials logged today. Skips are not calls and never appear here. */
  calls: number;
  /** …of which reached a human. */
  reached: number;
  /** Distinct businesses dialled, which is smaller whenever a lead was retried. */
  leads: number;
};

/**
 * The outcomes that count as having spoken to somebody, as a SQL list.
 *
 * Derived from `OUTCOME_REACHED` rather than written out, unlike the older
 * hardcoded outcome lists in this file. This one feeds a number an operator is
 * measured by, and a new outcome silently missing from it would quietly deflate
 * everybody's day rather than failing.
 */
const REACHED_SQL = CALL_OUTCOMES.filter((o) => OUTCOME_REACHED[o])
  .map((o) => `'${o}'`)
  .join(",");

/**
 * How many calls were made today, per operator.
 *
 * Its own query rather than `callStats`, which groups every call ever logged by
 * outcome to answer a question about one day — fine on a few hundred rows, and
 * the wrong shape on a log that a 100-a-day operation grows by 500 a week.
 * `lead_calls_actor_time` serves this directly.
 *
 * "Today" folds `occurred_at` to a local calendar day on both sides, like every
 * other today-counter here: the timestamps are UTC and the working day belongs
 * to whoever is dialling, so a plain prefix match files an evening's calls under
 * tomorrow and the counter resets mid-afternoon.
 *
 * The display name comes from the call row, not from `users`. It is captured
 * with the dial for the same reason the rest of the audit captures its labels —
 * a deleted account must not erase the day it worked.
 */
export function callsToday(actorId?: string): DailyCalls[] {
  const rows = getDb()
    .prepare(
      `SELECT actor_id, actor_display_name,
              COUNT(*)                                            AS calls,
              COUNT(DISTINCT lead_id)                             AS leads,
              COALESCE(SUM(outcome IN (${REACHED_SQL})), 0)       AS reached
         FROM lead_calls
        WHERE date(occurred_at, 'localtime') = date('now', 'localtime')
          ${actorId ? "AND actor_id = ?" : ""}
        GROUP BY actor_id, actor_display_name
        ORDER BY calls DESC, actor_display_name`,
    )
    .all(...(actorId ? [actorId] : [])) as {
    actor_id: string;
    actor_display_name: string;
    calls: number;
    leads: number;
    reached: number;
  }[];

  return rows.map((r) => ({
    actorId: r.actor_id,
    actorDisplayName: r.actor_display_name,
    calls: Number(r.calls),
    reached: Number(r.reached),
    leads: Number(r.leads),
  }));
}

/**
 * The same day summed across everyone — the team's number, not a person's.
 *
 * Summing `callsToday()` in the caller would be one row per operator and the
 * same answer; it is here so the dashboard and the operator portal cannot
 * disagree about what "hoje" means by folding the date differently.
 */
export function callsTodayTotal(actorId?: string): {
  calls: number;
  reached: number;
  leads: number;
  operators: number;
} {
  const rows = callsToday(actorId);
  return {
    calls: rows.reduce((sum, r) => sum + r.calls, 0),
    reached: rows.reduce((sum, r) => sum + r.reached, 0),
    // Deliberately summed rather than counted distinctly across operators: two
    // people dialling the same business is two leads worked, and it is also
    // something the queue is built to prevent.
    leads: rows.reduce((sum, r) => sum + r.leads, 0),
    operators: rows.length,
  };
}

/* -------------------------------------------------------------------------- */
/* Audience seeds                                                              */
/* -------------------------------------------------------------------------- */

/**
 * The named seeds an ads audience can be built from.
 *
 * Presets rather than a free query builder, because the choice being made is a
 * marketing one and it has exactly a few sensible answers. Each is a claim about
 * what the resulting lookalike would be modelled on, and `AUDIENCE_SEED_HINT`
 * states it — an audience whose definition nobody can recall is one that quietly
 * stops meaning anything three campaigns later.
 */
export type AudienceSeed =
  "interessados" | "clientes" | "qualificados" | "perdidos";

export const AUDIENCE_SEEDS: AudienceSeed[] = [
  "interessados",
  "clientes",
  "qualificados",
  "perdidos",
];

export const AUDIENCE_SEED_LABEL: Record<AudienceSeed, string> = {
  interessados: "Demonstraram interesse na ligação",
  clientes: "Viraram clientes",
  qualificados: "Qualificados ou além",
  perdidos: "Perdidos (para excluir)",
};

export const AUDIENCE_SEED_HINT: Record<AudienceSeed, string> = {
  interessados:
    "Quem atendeu e demonstrou interesse, mesmo sem fechar. É a maior semente com sinal real de intenção — normalmente a melhor base para um lookalike.",
  clientes:
    "Só quem fechou. Sinal mais forte e lista menor; abaixo de umas centenas de linhas as plataformas modelam mal.",
  qualificados:
    "Todo mundo de 'qualificado' para frente no funil, tenha vindo da ligação ou não.",
  perdidos:
    "Sem interesse ou número inválido. Serve como público de exclusão, para não pagar de novo por quem já disse não.",
};

export function isAudienceSeed(value: unknown): value is AudienceSeed {
  return (
    typeof value === "string" && AUDIENCE_SEEDS.includes(value as AudienceSeed)
  );
}

/**
 * The leads behind one seed.
 *
 * "Interessados" and "perdidos" are defined by the *call log* rather than by the
 * funnel stage, and that difference is the point of the feature: a lead that was
 * interested on the phone and later went cold has moved on in the funnel, but it
 * is still exactly the kind of business the ads should be finding more of. The
 * stage-based seeds ask the other question, about where the deal stands now.
 */
export function leadsForAudience(seed: AudienceSeed): StoredLead[] {
  const db = getDb();

  const byOutcome = (outcomes: CallOutcome[]) =>
    db
      .prepare(
        `SELECT ${SELECT_COLUMNS}
           FROM leads
          WHERE EXISTS (
                  SELECT 1 FROM lead_calls c
                   WHERE c.lead_id = leads.id
                     AND c.outcome IN (${outcomes.map(() => "?").join(",")})
                )
          ORDER BY score DESC`,
      )
      .all(...outcomes) as LeadRow[];

  const byStage = (stages: FunnelStage[]) =>
    db
      .prepare(
        `SELECT ${SELECT_COLUMNS}
           FROM leads
          WHERE funnel_stage IN (${stages.map(() => "?").join(",")})
          ORDER BY score DESC`,
      )
      .all(...stages) as LeadRow[];

  const rows =
    seed === "interessados"
      ? byOutcome(["interessado", "fechado"])
      : seed === "clientes"
        ? byStage(["fechado"])
        : seed === "qualificados"
          ? byStage(["qualificado", "proposta", "negociacao", "fechado"])
          : // "Perdidos" unions both sides: a lead marked lost by hand in the CRM
            // belongs in an exclusion audience just as much as one that said no on
            // the phone, and leaving either out means paying to reach them again.
            (db
              .prepare(
                `SELECT ${SELECT_COLUMNS}
                   FROM leads
                  WHERE funnel_stage = 'perdido'
                     OR EXISTS (
                          SELECT 1 FROM lead_calls c
                           WHERE c.lead_id = leads.id
                             AND c.outcome IN ('sem_interesse','numero_invalido')
                        )
                  ORDER BY score DESC`,
              )
              .all() as LeadRow[]);

  return rows.map(toStored);
}

/* -------------------------------------------------------------------------- */
/* The automatic daily queue                                                   */
/* -------------------------------------------------------------------------- */

/** A day's target. 100 is the number a person can actually dial in a day. */
export const DEFAULT_DAILY_TARGET = 100;

/**
 * Ceiling on one automatic build. Above this the list stops being a day's work
 * and the operator is back to a queue they cannot finish — the thing
 * `MAX_LIST_SIZE` exists to prevent, applied to the automatic path too.
 */
export const MAX_DAILY_TARGET = MAX_LIST_SIZE;

/**
 * Pick the leads today's queue should contain, best first.
 *
 * The whole selection is one SQL statement on purpose. Reading candidates into
 * JS to filter them there would mean paging through a base that is meant to grow
 * past six figures, and every rule here — phone quality, cooldown, attempts,
 * already-queued — is cheaper as a predicate than as a set intersection.
 *
 * `excludeListId` lets a rebuild ignore the list it is replacing, so rebuilding
 * today's queue doesn't find every one of its own leads "already queued".
 */
export function dailyCandidates(
  limit: number,
  excludeListId?: number,
  actor?: ClaimActor,
): string[] {
  // Without an actor this is a *preview* — "how much work is there" on the
  // finished-queue screen — and it counts the whole pool. With one it is a
  // build, and it must not draw leads that belong to somebody else or are on
  // another operator's screen right now.
  const blocked = actor ? blockedClause(actor) : { sql: "0", params: [] };
  const params: Param[] = [
    ...blocked.params,
    ...(excludeListId ? [excludeListId] : []),
    limit,
  ];
  const rows = getDb()
    .prepare(
      // The CTE form of the phone rules, not the correlated one: this scans the
      // whole base to fill a hundred slots, and the per-row form re-counts every
      // shared number once per candidate considered.
      `WITH ${PHONE_QUALITY_CTE}
       SELECT leads.id
         FROM leads
         ${PHONE_QUALITY_JOINS}
        WHERE leads.funnel_stage NOT IN (${CLOSED_STAGES_SQL})
          AND ${GOOD_PHONE_CTE_SQL}
          AND NOT ${blocked.sql}
          AND ${AVAILABLE_SQL}
          ${excludeListId ? "AND NOT EXISTS (SELECT 1 FROM call_list_items x WHERE x.lead_id = leads.id AND x.list_id = ? AND x.state = 'pendente')" : ""}
        ORDER BY ${QUEUE_ORDER_SQL}
        LIMIT ?`,
    )
    .all(...params) as {
    id: string;
  }[];
  return rows.map((r) => r.id);
}

/**
 * Today's list for one operator: created on first ask, returned as-is after.
 *
 * Idempotent by (actor, day) rather than "make a new list every time the button
 * is pressed", because the button *will* be pressed twice — a refresh, a second
 * tab, coming back after lunch — and a second list would hand out a hundred
 * different leads while the first still had eighty pending. The name carries the
 * date so a week of them reads as a week.
 *
 * Returns the list plus whether it was built now, so the screen can tell "here is
 * your queue" from "here is the queue you already started".
 */
export function dailyList(input: {
  actor: ClaimActor;
  target?: number;
}): { list: CallList; created: boolean; available: number } | null {
  const target = Math.max(
    1,
    Math.min(input.target ?? DEFAULT_DAILY_TARGET, MAX_DAILY_TARGET),
  );
  const db = getDb();

  // Local calendar day, folded the same way every other "today" in this codebase
  // is: the timestamps are UTC and the working day belongs to the operator.
  const today = (
    db.prepare("SELECT date('now','localtime') AS d").get() as { d: string }
  ).d;
  const name = `Fila do dia · ${today}`;

  const existing = db
    .prepare(
      `SELECT id FROM call_lists
        WHERE created_by_id = ? AND name = ?
        ORDER BY created_at DESC LIMIT 1`,
    )
    .get(input.actor.id, name) as { id: number } | undefined;

  if (existing) {
    const list = callList(Number(existing.id));
    if (list) return { list, created: false, available: 0 };
  }

  const ids = dailyCandidates(target, undefined, input.actor);
  if (ids.length === 0) return null;

  const list = createCallList({
    name,
    leadIds: ids,
    actor: input.actor,
    sourceQuery: null,
  });
  if (!list) return null;

  // What is left after this list took its share — the honest answer to "can I do
  // this again tomorrow", which is the question a 100-a-day operation lives on.
  // Counted rather than taken from `dailyCandidates`, which is capped by its own
  // limit and would report "500 left" forever on a base of any size.
  const available = phonePoolStats().available;
  return { list, created: true, available };
}

/**
 * Top up a list that has been worked down, without losing its history.
 *
 * The alternative — build a fresh list every time — throws away the progress
 * counters and scatters one campaign across a dozen lists. Appends after the
 * last position so the order already being worked is untouched.
 */
export function topUpList(
  listId: number,
  wanted: number,
  actor?: ClaimActor,
): { added: number } {
  const db = getDb();
  const ids = dailyCandidates(
    Math.max(1, Math.min(wanted, MAX_DAILY_TARGET)),
    listId,
    actor,
  );
  if (ids.length === 0) return { added: 0 };

  const next = Number(
    (
      db
        .prepare(
          "SELECT COALESCE(MAX(position), -1) + 1 AS next FROM call_list_items WHERE list_id = ?",
        )
        .get(listId) as { next: number }
    ).next,
  );

  const insert = db.prepare(
    `INSERT OR IGNORE INTO call_list_items (list_id, lead_id, position)
     VALUES (?, ?, ?)`,
  );
  let added = 0;
  db.exec("BEGIN");
  try {
    for (const id of ids) {
      // INSERT OR IGNORE rather than a pre-check: the composite primary key
      // already states the rule, and a lead worked earlier in this same list
      // must not be re-queued by a top-up.
      if (Number(insert.run(listId, id, next + added).changes) > 0) added += 1;
    }
    db.exec("COMMIT");
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
  return { added };
}
