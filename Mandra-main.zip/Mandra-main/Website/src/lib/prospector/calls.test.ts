import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { after, before, describe, it } from "node:test";

/**
 * The call queue's rules, exercised against a real database file.
 *
 * `stageAfterCall` is pure and could be tested alone, but the half that actually
 * breaks is the transaction: whether a recorded call closes the queue position,
 * moves the stage and the status together, and clears the follow-up on a lead
 * that has just said no. Those are four writes that must agree, so the test
 * drives them the way a route does.
 *
 * PROSPECTOR_DB has to be set before db.ts is imported — it reads it when the
 * connection is first opened — hence the dynamic imports inside `before`.
 */

let calls: typeof import("./calls");
let history: typeof import("./history");
let db: typeof import("./db");
let dir: string;

const ACTOR = { id: "u1", displayName: "Operadora" };

function seed(id: string, name: string, phone: string | null): void {
  db.getDb()
    .prepare(
      `INSERT INTO leads (id, name, phone, country, city, uf, confidence, score, search_norm)
       VALUES (?, ?, ?, 'BR', 'Belo Horizonte', 'MG', 0.9, 70, ?)`,
    )
    .run(id, name, phone, name.toLowerCase());
}

before(async () => {
  dir = mkdtempSync(path.join(tmpdir(), "calls-test-"));
  process.env.PROSPECTOR_DB = path.join(dir, "prospector.db");
  db = await import("./db");
  calls = await import("./calls");
  history = await import("./history");
  seed("l1", "Padaria Sao Jorge", "+5531987911222");
  seed("l2", "Bar do Ze", "+5531987911333");
  seed("l3", "Salao Bela", null);
});

after(() => rmSync(dir, { recursive: true, force: true }));

describe("stageAfterCall", () => {
  it("moves an untouched lead forward", () => {
    assert.equal(
      calls.stageAfterCall("descoberta", "nao_atendeu", "nenhum"),
      "contato",
    );
    assert.equal(
      calls.stageAfterCall("descoberta", "interessado", "nenhum"),
      "qualificado",
    );
  });

  it("never drags a lead backwards on a missed call", () => {
    // The rule the whole feature turns on: a lead in negociação that doesn't
    // pick up the phone has not regressed to "contato feito".
    assert.equal(
      calls.stageAfterCall("negociacao", "nao_atendeu", "nenhum"),
      null,
    );
    assert.equal(
      calls.stageAfterCall("proposta", "retornar", "nova_ligacao"),
      null,
    );
  });

  it("applies terminal outcomes even when they move backwards", () => {
    assert.equal(
      calls.stageAfterCall("negociacao", "sem_interesse", "nenhum"),
      "perdido",
    );
    assert.equal(
      calls.stageAfterCall("proposta", "numero_invalido", "nenhum"),
      "perdido",
    );
    assert.equal(
      calls.stageAfterCall("contato", "fechado", "nenhum"),
      "fechado",
    );
  });

  it("lets the next step carry the lead further than the outcome would", () => {
    // "Interessado" alone argues for qualificado; deciding to send a proposal
    // on the same call is the stronger signal and wins.
    assert.equal(
      calls.stageAfterCall("descoberta", "interessado", "enviar_proposta"),
      "proposta",
    );
  });

  it("brings a lost lead back when a later call goes well", () => {
    assert.equal(
      calls.stageAfterCall("perdido", "interessado", "nenhum"),
      "qualificado",
    );
  });
});

describe("call lists", () => {
  it("keeps the order it was given and skips unknown ids", () => {
    const list = calls.createCallList({
      name: "Padarias BH",
      leadIds: ["l2", "l1", "nao-existe", "l2"],
      actor: ACTOR,
      sourceQuery: "?niche=padarias",
    });
    assert.ok(list);
    assert.equal(list.total, 2);
    assert.equal(list.pending, 2);

    const items = calls.listItems(list.id);
    assert.deepEqual(
      items.map((i) => i.leadId),
      ["l2", "l1"],
    );

    // The queue hands out the first position, not the highest-scoring lead.
    assert.equal(calls.nextInList(list.id)?.leadId, "l2");
  });

  it("refuses a list with nothing in it", () => {
    assert.equal(
      calls.createCallList({ name: "Vazia", leadIds: ["nada"], actor: ACTOR }),
      null,
    );
  });

  it("never builds in a closed or lost lead", () => {
    // `dailyCandidates` has always excluded these; a list built from a CRM
    // filter went straight past that and handed an operator a customer to
    // cold-pitch, or a business that had already said no.
    seed("won", "Cliente Fechado", "+5531987911444");
    seed("lost", "Nao Quis", "+5531987911555");
    history.setFunnelStage("won", "fechado");
    history.setFunnelStage("lost", "perdido");

    const list = calls.createCallList({
      name: "Mistura",
      leadIds: ["won", "l1", "lost"],
      actor: ACTOR,
    });
    assert.ok(list);
    assert.deepEqual(
      calls.listItems(list.id).map((item) => item.leadId),
      ["l1"],
    );

    // And a list of nothing but closed leads is refused outright rather than
    // created empty — the route turns that into a message, not a dead queue.
    assert.equal(
      calls.createCallList({
        name: "So fechados",
        leadIds: ["won", "lost"],
        actor: ACTOR,
      }),
      null,
    );
  });
});

describe("recordCall", () => {
  it("closes the queue position and moves stage and status together", () => {
    const list = calls.createCallList({
      name: "Sessao",
      leadIds: ["l1", "l2"],
      actor: ACTOR,
    })!;

    const result = calls.recordCall({
      leadId: "l1",
      listId: list.id,
      outcome: "interessado",
      nextStep: "videochamada",
      notes: "  pediu proposta ate sexta  ",
      actor: ACTOR,
    })!;
    // The other refusal `recordCall` can return is "somebody else owns this
    // lead" — see ownership.test.ts. Narrowed here so the assertions below read
    // as the result they are about.
    assert.ok(!calls.isRefusal(result));

    assert.equal(result.stage, "qualificado");
    assert.equal(result.attempts, 1);
    // videochamada schedules two days out rather than leaving the lead unqueued.
    assert.ok(result.followUpAt);

    const lead = history.queryHistory({ scope: history.SCOPE_TUDO, q: "padaria" }).leads[0];
    assert.equal(lead.funnelStage, "qualificado");
    // The pair must never disagree: the prospector's board still reads status.
    assert.equal(lead.status, "respondeu");
    assert.ok(lead.contactedAt);

    // The position is done, so the queue has moved on to the next lead.
    assert.equal(calls.itemInList(list.id, "l1")?.state, "concluido");
    assert.equal(calls.nextInList(list.id)?.leadId, "l2");

    const log = calls.callHistory("l1");
    assert.equal(log.length, 1);
    assert.equal(log[0].outcome, "interessado");
    assert.equal(log[0].notes, "pediu proposta ate sexta");
    // The number as dialled, normalised to the same bare-digit E.164 the CSV
    // export uses — not whatever the lead's phone column says months later.
    assert.equal(log[0].phone, "5531987911222");
  });

  it("clears the follow-up when the lead says no", () => {
    calls.recordCall({
      leadId: "l2",
      outcome: "sem_interesse",
      actor: ACTOR,
    });
    const lead = history.queryHistory({ scope: history.SCOPE_TUDO, q: "bar do ze" }).leads[0];
    assert.equal(lead.funnelStage, "perdido");
    assert.equal(lead.status, "descartado");
    // A lost lead must leave the daily queue, whatever the next step asked for.
    assert.equal(lead.nextFollowUpAt, null);
  });

  it("honours an explicit follow-up date over the step's default", () => {
    calls.recordCall({
      leadId: "l3",
      outcome: "retornar",
      nextStep: "nova_ligacao",
      followUpAt: "2027-03-01",
      actor: ACTOR,
    });
    const lead = history.queryHistory({ scope: history.SCOPE_TUDO, q: "salao" }).leads[0];
    assert.equal(lead.nextFollowUpAt, "2027-03-01");
  });

  it("counts every dial, and only counts reached calls as reached", () => {
    calls.recordCall({ leadId: "l3", outcome: "nao_atendeu", actor: ACTOR });
    assert.equal(calls.callHistory("l3").length, 2);

    const stats = calls.callStats();
    assert.equal(stats.total, 4);
    // interessado + sem_interesse + retornar reached a human; nao_atendeu didn't.
    assert.equal(stats.reached, 3);
    assert.equal(stats.today, 4);
  });

  it("returns null for a lead that isn't in the history", () => {
    assert.equal(
      calls.recordCall({
        leadId: "ausente",
        outcome: "nao_atendeu",
        actor: ACTOR,
      }),
      null,
    );
  });
});

describe("skipping", () => {
  it("takes a position out of the queue and puts it back", () => {
    // Its own leads rather than the shared fixture: by now `recordCall`'s tests
    // have marked l2 "sem interesse", and a lost lead is no longer something a
    // list can be built from — which is the rule above, not a bug here.
    seed("s1", "Pular Um", "+5531987911666");
    seed("s2", "Pular Dois", "+5531987911777");

    const list = calls.createCallList({
      name: "Pular",
      leadIds: ["s1", "s2"],
      actor: ACTOR,
    })!;
    assert.ok(calls.skipItem(list.id, "s1"));
    assert.equal(calls.nextInList(list.id)?.leadId, "s2");
    assert.equal(calls.callList(list.id)?.skipped, 1);

    assert.equal(calls.resetSkipped(list.id), 1);
    assert.equal(calls.nextInList(list.id)?.leadId, "s1");
  });
});

describe("deleting a lead", () => {
  it("cascades its queue positions away", () => {
    const list = calls.createCallList({
      name: "Cascata",
      leadIds: ["l1"],
      actor: ACTOR,
    })!;
    history.deleteLeads(["l1"]);
    // The position is gone rather than pointing at a lead that no longer exists.
    assert.equal(calls.callList(list.id)?.total, 0);
    assert.equal(calls.nextInList(list.id), null);
  });
});
