import { isCountryCode } from "@/lib/countries";
import { getDb } from "./db";
import { normalise } from "./cities";
import { GOOD_PHONE_SQL } from "./phone-quality";
import { parseTags, sanitiseTags, tagKey, tagNeedle } from "./tags";
import { scoreLead } from "./score";
import {
  FUNNEL_STAGES,
  LEAD_STATUSES,
  STAGE_STATUS,
  type FunnelStage,
  type LeadStatus,
  type SocialLink,
  type StoredLead,
} from "./types";

/**
 * Reading the local history back out.
 *
 * Everything a search finds is written to SQLite, and until this existed none of
 * it could be looked at again — the board only ever showed the search you had
 * just run, so the accumulated database was write-only. This is the read side:
 * browse it, filter it, export it.
 *
 * Filters arrive from the query string and are all optional, so the page is a
 * plain GET form. That keeps every view shareable as a URL and working without
 * JavaScript, the same way searches already do.
 */

/**
 * Whose leads a query is allowed to see.
 *
 * This is the tenancy boundary, and it is a *required* field on HistoryFilters
 * rather than an optional one, because the failure mode of forgetting it is a
 * client reading another client's pipeline — silently, with no error anywhere.
 * Making it required means `parseFilters()` cannot be called without deciding
 * the question, and every existing caller had to answer it to keep compiling.
 *
 * It deliberately does not come from the query string. `parseFilters` takes it
 * as a second argument, from the session, so a hand-edited `?conta=` can narrow
 * an admin's view (see `conta` below) but can never widen a client's.
 *
 * - `tudo`  — Atlas: every lead, ours and every client's. Admins and operators.
 * - `atlas` — only `account_id IS NULL`: the prospector's own base, with the
 *   clients' leads filtered out.
 * - `conta` — exactly one client account. The only scope a `cliente` session
 *   can ever hold.
 */
export type LeadScope =
  { kind: "tudo" } | { kind: "atlas" } | { kind: "conta"; id: string };

export const SCOPE_TUDO: LeadScope = { kind: "tudo" };
export const SCOPE_ATLAS: LeadScope = { kind: "atlas" };

export type HistoryFilters = {
  /**
   * Whose leads these filters may return. Required: see LeadScope. Everything
   * else on this type narrows a result set the scope has already bounded.
   */
  scope: LeadScope;
  /** Free text over name and address. */
  q?: string;
  niche?: string;
  /** ISO-3166 alpha-2. "BR" also matches the rows saved before the column existed. */
  country?: string;
  uf?: string;
  city?: string;
  status?: LeadStatus;
  /** Where in the marketing funnel. Independent of `status` as a filter. */
  stage?: FunnelStage;
  /** Only rows whose phone is a WhatsApp-capable mobile. */
  onlyWhatsapp?: boolean;
  /** Only rows with no website — the sellable pool. */
  onlyNoSite?: boolean;
  /**
   * Only rows whose number plausibly reaches *that* business — see
   * `phone-quality.ts`. Excludes leads with no number, numbers already found
   * dead, and numbers listed by several businesses at once (switchboards).
   */
  onlyGoodPhone?: boolean;
  minScore?: number;
  /** Only leads whose follow-up is due today or earlier. */
  onlyDue?: boolean;
  /**
   * Operator labels. Combined with AND — picking two narrows to the leads
   * carrying both, which is what "show me the ones I marked X *and* Y" means.
   */
  tags?: string[];
  sort?: "score" | "recent" | "oldest" | "name" | "followup";
  page?: number;
  perPage?: number;
};

export type HistoryPage = {
  leads: StoredLead[];
  total: number;
  page: number;
  perPage: number;
  pages: number;
};

export type HistoryFacets = {
  total: number;
  noSite: number;
  whatsapp: number;
  /** Rows whose number plausibly reaches that business — see phone-quality.ts. */
  goodPhone: number;
  due: number;
  /** Overdue — a subset of `due`, kept separate because it is the urgent half. */
  overdue: number;
  /** First seen today, i.e. what the last searches added. */
  addedToday: number;
  /** Reached out to today, for the "worked today" side of the metric row. */
  contactedToday: number;
  byStatus: { status: LeadStatus; count: number }[];
  /** The funnel itself: how many businesses sit at each stage. */
  byStage: { stage: FunnelStage; count: number }[];
  niches: { niche: string; count: number }[];
  /** Every label in use under the current filters, most-used first. */
  tags: { tag: string; count: number }[];
  cities: { city: string; uf: string; count: number }[];
  /** Which countries the history actually holds, for the filter bar. */
  countries: { country: string; count: number }[];
};

/** One row of the per-niche breakdown. */
export type NicheBreakdown = {
  niche: string;
  total: number;
  noSite: number;
  whatsapp: number;
  /** Anything past 'novo' — how far along that niche's outreach is. */
  worked: number;
};

/**
 * A `leads` row as SELECT_COLUMNS returns it. Exported because the call queue in
 * `calls.ts` reads the same table and must map it the same way — a second
 * hand-written mapper is how one screen ends up showing a stage the other doesn't.
 */
export type LeadRow = {
  id: string;
  source: "overture" | "openstreetmap" | "geoapify" | "formulario" | null;
  account_id: string | null;
  name: string;
  category: string | null;
  address: string | null;
  city: string | null;
  uf: string | null;
  country: string | null;
  phone: string | null;
  website: string | null;
  social: string | null;
  provider_socials: string | null;
  email: string | null;
  lat: number | null;
  lon: number | null;
  confidence: number | null;
  status: string;
  niche: string | null;
  searched_city: string | null;
  searched_uf: string | null;
  first_seen_at: string;
  last_seen_at: string;
  contacted_at: string | null;
  next_follow_up_at: string | null;
  owner_id: string | null;
  owner_name: string | null;
  notes: string | null;
  funnel_stage: string;
  socials: string | null;
  contact_name: string | null;
  tags: string | null;
};

/**
 * Everything we bind is a string, a number or a null; naming that keeps
 * node:sqlite happy. Nulls only come from the writers — a filter never binds one.
 */
type Param = string | number | null;

/**
 * Builds the shared WHERE clause. Every filter is a bound parameter — the free
 * text one especially, since it comes straight from a query string.
 */
function where(f: HistoryFilters): { sql: string; params: Param[] } {
  const clauses: string[] = [];
  const params: Param[] = [];

  // First, and unconditionally. A client's scope is the one predicate on this
  // list that is not a convenience: every other clause narrows what they are
  // allowed to see, this one defines it. `tudo` adds nothing, which is why it
  // is spelled out as a case rather than left as the absence of one — an
  // unhandled scope must read as a mistake here, not as "no filter".
  if (f.scope.kind === "atlas") {
    clauses.push("account_id IS NULL");
  } else if (f.scope.kind === "conta") {
    clauses.push("account_id = ?");
    params.push(f.scope.id);
  }

  const needle = normalise(f.q ?? "");
  if (needle.length > 0) {
    // Matched against `search_norm`, which db.ts folds on write with the same
    // normalise() the city index uses — so "estudio" finds "Estúdio" and
    // "sao joao" finds "São João". Covers name and address together.
    clauses.push("instr(search_norm, ?) > 0");
    params.push(needle);
  }
  if (f.niche) {
    clauses.push("niche = ?");
    params.push(f.niche);
  }
  if (f.country) {
    // Rows written before the column existed are Brazilian and carry NULL, so
    // filtering to Brazil has to include them or half the history disappears
    // the first time someone picks a country.
    const country = f.country.toUpperCase();
    if (country === "BR") {
      clauses.push("(country = ? OR country IS NULL)");
    } else {
      clauses.push("country = ?");
    }
    params.push(country);
  }
  if (f.uf) {
    clauses.push("uf = ?");
    params.push(f.uf.toUpperCase());
  }
  if (f.city) {
    clauses.push("city = ?");
    params.push(f.city);
  }
  if (f.status) {
    clauses.push("status = ?");
    params.push(f.status);
  }
  if (f.stage) {
    clauses.push("funnel_stage = ?");
    params.push(f.stage);
  }
  if (f.onlyWhatsapp) clauses.push("whatsapp = 1");
  // The predicate lives in phone-quality.ts so the filter, the facet count and
  // the automatic queue cannot disagree about what "bom" means.
  if (f.onlyGoodPhone) clauses.push(`(${GOOD_PHONE_SQL})`);
  if (f.onlyNoSite) clauses.push("(website IS NULL OR website = '')");
  if (f.onlyDue)
    clauses.push(
      "next_follow_up_at IS NOT NULL AND next_follow_up_at <= date('now', 'localtime')",
    );
  for (const tag of f.tags ?? []) {
    // instr() against the stored JSON rather than json_each(), so one clause
    // per tag composes with AND without a join per tag. `tagNeedle` quotes both
    // ends, which is what stops "vip" matching the "vip-plus" beside it.
    clauses.push("tags IS NOT NULL AND instr(tags, ?) > 0");
    params.push(tagNeedle(tag));
  }
  if (typeof f.minScore === "number" && f.minScore > 0) {
    clauses.push("score >= ?");
    params.push(f.minScore);
  }

  return {
    sql: clauses.length > 0 ? `WHERE ${clauses.join(" AND ")}` : "",
    params,
  };
}

const ORDER: Record<NonNullable<HistoryFilters["sort"]>, string> = {
  // Same tiebreak as the live board: confidence, not name, because scores bunch
  // at the ceiling and alphabetical ordering buries the best records under
  // every business starting with "A".
  score: "score DESC, confidence DESC",
  recent: "first_seen_at DESC, score DESC",
  followup: "next_follow_up_at IS NULL, next_follow_up_at ASC, score DESC",
  oldest: "first_seen_at ASC, score DESC",
  name: "name COLLATE NOCASE ASC",
};

export function toStored(r: LeadRow): StoredLead {
  const scored = scoreLead({
    id: r.id,
    source:
      r.source === "openstreetmap" ||
      r.source === "geoapify" ||
      r.source === "formulario"
        ? r.source
        : "overture",
    name: r.name,
    category: r.category,
    address: r.address,
    city: r.city,
    uf: r.uf,
    country: r.country ?? "BR",
    phone: r.phone,
    website: r.website,
    social: r.social,
    socialLinks: parseSocials(r.provider_socials),
    email: r.email,
    lat: r.lat,
    lon: r.lon,
    confidence: r.confidence ?? 0,
  });

  // Score and reasons are recomputed rather than read back. The stored score is
  // what SQL sorts and filters on (it's indexed), but the rules live in score.ts
  // and recomputing means a row displays under today's rules instead of whatever
  // was in force the day it was first saved.
  return {
    ...scored,
    accountId: r.account_id,
    status: (LEAD_STATUSES as string[]).includes(r.status)
      ? (r.status as LeadStatus)
      : "novo",
    niche: r.niche,
    searchedCity: r.searched_city,
    searchedUf: r.searched_uf,
    firstSeenAt: r.first_seen_at,
    lastSeenAt: r.last_seen_at,
    contactedAt: r.contacted_at,
    nextFollowUpAt: r.next_follow_up_at,
    // A name is kept alongside the id for the same reason the audit keeps one:
    // the account can be deleted, and "atendido por" with nothing after it is
    // worse than a stale name.
    owner: r.owner_id
      ? { id: r.owner_id, name: r.owner_name ?? "operador removido" }
      : null,
    notes: r.notes,
    funnelStage: FUNNEL_STAGES.includes(r.funnel_stage as FunnelStage)
      ? (r.funnel_stage as FunnelStage)
      : "descoberta",
    socials: parseSocials(r.socials),
    contactName: r.contact_name,
    tags: parseTags(r.tags),
  };
}

/**
 * The socials column is JSON we wrote, but a database people are told they can
 * keep is a database someone will edit by hand. Anything unreadable degrades to
 * "no extra profiles" rather than taking the page down with it.
 */
function parseSocials(raw: string | null): SocialLink[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed.flatMap((entry) => {
      if (typeof entry !== "object" || entry === null) return [];
      const { platform, url } = entry as Record<string, unknown>;
      if (typeof url !== "string" || url.length === 0) return [];
      return [
        {
          platform: typeof platform === "string" ? platform : "link",
          url,
        },
      ];
    });
  } catch {
    return [];
  }
}

/**
 * The stored columns, in the order `LeadRow` declares them. Both readers select the
 * same set — when they were written out twice, `notes` reached the CRM table and
 * not the CSV, and the export quietly shipped without the column.
 */
export const SELECT_COLUMNS = `id, source, account_id, name, category, address, city, uf, country, phone, website, social, provider_socials,
       email, lat, lon, confidence, status, niche, searched_city, searched_uf,
       first_seen_at, last_seen_at, contacted_at, next_follow_up_at, notes,
       funnel_stage, socials, contact_name, tags, owner_id, owner_name`;

export function queryHistory(f: HistoryFilters): HistoryPage {
  const db = getDb();
  const { sql: whereSql, params } = where(f);

  const perPage = clamp(f.perPage ?? 100, 1, 1000);
  const total = Number(
    (
      db
        .prepare(`SELECT count(*) AS n FROM leads ${whereSql}`)
        .get(...params) as { n: number }
    ).n,
  );

  const pages = Math.max(1, Math.ceil(total / perPage));
  const page = clamp(f.page ?? 1, 1, pages);
  const order = ORDER[f.sort ?? "score"];

  const rows = db
    .prepare(
      `SELECT ${SELECT_COLUMNS}
       FROM leads ${whereSql}
       ORDER BY ${order}
       LIMIT ? OFFSET ?`,
    )
    .all(...params, perPage, (page - 1) * perPage) as LeadRow[];

  return { leads: rows.map(toStored), total, page, perPage, pages };
}

/**
 * Every row matching the filters, for the CSV export. Deliberately unpaginated:
 * exporting only the page you happen to be looking at is the behaviour that made
 * the board's export feel broken on wide searches.
 */
export function allMatching(f: HistoryFilters): StoredLead[] {
  const db = getDb();
  const { sql: whereSql, params } = where(f);
  const rows = db
    .prepare(
      `SELECT ${SELECT_COLUMNS}
       FROM leads ${whereSql}
       ORDER BY ${ORDER[f.sort ?? "score"]}`,
    )
    .all(...params) as LeadRow[];
  return rows.map(toStored);
}

/**
 * Counts for the filter bar. Scoped to the current filters *except* the one each
 * facet drives, so the numbers describe what picking an option would give you.
 */
export function historyFacets(f: HistoryFilters): HistoryFacets {
  const db = getDb();
  const base = where(f);

  const scalar = (expr: string): number => {
    const row = db
      .prepare(`SELECT ${expr} AS n FROM leads ${base.sql}`)
      .get(...base.params) as { n: number } | undefined;
    return Number(row?.n ?? 0);
  };

  const byStatusWhere = where({ ...f, status: undefined });
  const byStageWhere = where({ ...f, stage: undefined });
  const byNicheWhere = where({ ...f, niche: undefined });
  const byCityWhere = where({ ...f, city: undefined, uf: undefined });
  const byTagWhere = where({ ...f, tags: undefined });
  // The country facet must not be scoped by the country already picked, or it
  // reports one country holding everything the moment you filter by it. The city
  // facet is narrowed by it on purpose: São Paulo and Lisbon in one dropdown is
  // a list nobody can use.
  const byCountryWhere = where({
    ...f,
    country: undefined,
    city: undefined,
    uf: undefined,
  });

  return {
    total: scalar("count(*)"),
    noSite: scalar("count(*) FILTER (WHERE website IS NULL OR website = '')"),
    whatsapp: scalar("count(*) FILTER (WHERE whatsapp = 1)"),
    goodPhone: scalar(`count(*) FILTER (WHERE ${GOOD_PHONE_SQL})`),
    due: scalar(
      "count(*) FILTER (WHERE next_follow_up_at IS NOT NULL AND next_follow_up_at <= date('now', 'localtime'))",
    ),
    overdue: scalar(
      "count(*) FILTER (WHERE next_follow_up_at IS NOT NULL AND next_follow_up_at < date('now', 'localtime'))",
    ),
    // The timestamps are stored as UTC but the working day is the operator's, so
    // both sides of the comparison are converted before the dates are compared.
    // Reading `first_seen_at` as a plain prefix instead counts an 21:00 lead as
    // tomorrow's, which shows up as a metric row that resets in the evening.
    addedToday: scalar(
      "count(*) FILTER (WHERE date(first_seen_at, 'localtime') = date('now', 'localtime'))",
    ),
    contactedToday: scalar(
      "count(*) FILTER (WHERE contacted_at IS NOT NULL AND date(contacted_at, 'localtime') = date('now', 'localtime'))",
    ),
    byStatus: (
      db
        .prepare(
          `SELECT status, count(*) AS count FROM leads ${byStatusWhere.sql}
           GROUP BY status ORDER BY count DESC`,
        )
        .all(...byStatusWhere.params) as { status: string; count: number }[]
    ).map((r) => ({ status: r.status as LeadStatus, count: Number(r.count) })),
    // One query, then mapped over FUNNEL_STAGES so the result is in funnel order
    // and every stage is present. Ordering by count instead would make it a bar
    // chart, and dropping the empty stages would hide exactly the gap you are
    // looking for.
    byStage: stageCounts(db, byStageWhere),
    niches: (
      db
        .prepare(
          `SELECT niche, count(*) AS count FROM leads ${byNicheWhere.sql}
           ${byNicheWhere.sql ? "AND" : "WHERE"} niche IS NOT NULL
           GROUP BY niche ORDER BY count DESC`,
        )
        .all(...byNicheWhere.params) as { niche: string; count: number }[]
    ).map((r) => ({ niche: r.niche, count: Number(r.count) })),
    cities: (
      db
        .prepare(
          `SELECT city, uf, count(*) AS count FROM leads ${byCityWhere.sql}
           ${byCityWhere.sql ? "AND" : "WHERE"} city IS NOT NULL
           GROUP BY city, uf ORDER BY count DESC LIMIT 60`,
        )
        .all(...byCityWhere.params) as {
        city: string;
        uf: string;
        count: number;
      }[]
    ).map((r) => ({ city: r.city, uf: r.uf, count: Number(r.count) })),
    tags: tagCounts(db, byTagWhere),
    // Folded to 'BR' in SQL, so the rows written before the column existed count
    // as the Brazilian leads they are instead of showing up as a nameless group.
    countries: (
      db
        .prepare(
          `SELECT coalesce(country, 'BR') AS country, count(*) AS count
           FROM leads ${byCountryWhere.sql}
           GROUP BY 1 ORDER BY count DESC`,
        )
        .all(...byCountryWhere.params) as { country: string; count: number }[]
    ).map((r) => ({ country: r.country, count: Number(r.count) })),
  };
}

/**
 * The label vocabulary, counted.
 *
 * Aggregated in JS over the `tags` column rather than with `json_each`. The
 * counts have to fold case and accents — an operator who typed "Indicação" once
 * and "indicacao" twice has one label, not two chips that each undercount — and
 * `tagKey` is the same fold the writers dedupe with, so the list can't disagree
 * with what a lead actually carries. It also keeps the CRM's first query off a
 * JSON extension, which is worth more than the microseconds: this runs on the
 * page that renders the whole tool.
 */
function tagCounts(
  db: ReturnType<typeof getDb>,
  w: { sql: string; params: Param[] },
): { tag: string; count: number }[] {
  const rows = db
    .prepare(
      `SELECT tags FROM leads ${w.sql}
       ${w.sql ? "AND" : "WHERE"} tags IS NOT NULL AND tags != '[]'`,
    )
    .all(...w.params) as { tags: string | null }[];

  const counts = new Map<string, { tag: string; count: number }>();
  for (const row of rows) {
    for (const tag of parseTags(row.tags)) {
      const key = tagKey(tag);
      const seen = counts.get(key);
      // First spelling encountered wins the label, so the chip matches what is
      // on the leads rather than whichever row SQLite happened to return last.
      if (seen) seen.count += 1;
      else counts.set(key, { tag, count: 1 });
    }
  }

  return [...counts.values()].sort(
    (a, b) => b.count - a.count || a.tag.localeCompare(b.tag, "pt-BR"),
  );
}

function stageCounts(
  db: ReturnType<typeof getDb>,
  scope: { sql: string; params: Param[] },
): { stage: FunnelStage; count: number }[] {
  const rows = db
    .prepare(
      `SELECT funnel_stage, count(*) AS count FROM leads ${scope.sql}
       GROUP BY funnel_stage`,
    )
    .all(...scope.params) as { funnel_stage: string; count: number }[];

  const counts = new Map(rows.map((r) => [r.funnel_stage, Number(r.count)]));
  return FUNNEL_STAGES.map((stage) => ({
    stage,
    count: counts.get(stage) ?? 0,
  }));
}

/**
 * Leads per niche, so you can see which niches you've built up and which you've
 * actually worked. Respects every filter *except* the niche one — the point is to
 * compare niches against each other, so fixing one would leave a single row.
 *
 * Trustworthy only because a category now maps to exactly one niche; while
 * `nail_salon` sat in two, these counts summed to more than the total.
 */
export function nicheBreakdown(f: HistoryFilters): NicheBreakdown[] {
  const db = getDb();
  const { sql: whereSql, params } = where({ ...f, niche: undefined });

  const rows = db
    .prepare(
      `SELECT niche,
              count(*) AS total,
              count(*) FILTER (WHERE website IS NULL OR website = '') AS no_site,
              count(*) FILTER (WHERE whatsapp = 1) AS whatsapp,
              count(*) FILTER (WHERE status <> 'novo') AS worked
       FROM leads ${whereSql}
       ${whereSql ? "AND" : "WHERE"} niche IS NOT NULL
       GROUP BY niche
       ORDER BY no_site DESC, total DESC`,
    )
    .all(...params) as {
    niche: string;
    total: number;
    no_site: number;
    whatsapp: number;
    worked: number;
  }[];

  return rows.map((r) => ({
    niche: r.niche,
    total: Number(r.total),
    noSite: Number(r.no_site),
    whatsapp: Number(r.whatsapp),
    worked: Number(r.worked),
  }));
}

/**
 * The stage each status implies, used when the status is set directly — from the
 * prospector's board, which has no funnel control.
 *
 * Only applied when the current stage disagrees, so re-marking a lead as
 * "respondeu" doesn't drag it back from "negociação" to "qualificado". The three
 * middle stages all mean "respondeu", and the point is to keep the coarse field
 * from destroying the fine one.
 */
const STATUS_STAGE: Record<LeadStatus, FunnelStage> = {
  novo: "descoberta",
  contatado: "contato",
  respondeu: "qualificado",
  cliente: "fechado",
  descartado: "perdido",
};

/** SQL fragment: leave funnel_stage alone if it already implies this status. */
const KEEP_STAGE = `funnel_stage = CASE
             WHEN funnel_stage IN (${FUNNEL_STAGES.filter(
               (s) => STAGE_STATUS[s] === "respondeu",
             )
               .map((s) => `'${s}'`)
               .join(", ")})
                  AND ? = 'respondeu'
               THEN funnel_stage
             ELSE ?
           END`;

/** Move a lead along the pipeline. Returns false if the id isn't in the history. */
export function setStatus(id: string, status: LeadStatus): boolean {
  if (!LEAD_STATUSES.includes(status)) return false;
  const db = getDb();
  const result = db
    .prepare(
      `UPDATE leads
       SET status = ?,
           ${KEEP_STAGE},
           -- Only the states that imply you actually reached out get a timestamp,
           -- and going back to 'novo' clears it, so contacted_at never claims an
           -- outreach that didn't happen or was undone. 'descartado' on its own
           -- doesn't stamp it — you can discard a lead without ever messaging it.
           contacted_at = CASE
             WHEN ? = 'novo' THEN NULL
             WHEN ? IN ('contatado', 'respondeu', 'cliente')
                  AND contacted_at IS NULL
               THEN strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
             ELSE contacted_at
           END,
           -- Reaching a lead deserves a next action; terminal states must not
           -- stay in the daily queue. A manually set "contatado" follows the
           -- same rule as opening WhatsApp from the live board.
           next_follow_up_at = CASE
             WHEN ? IN ('novo', 'cliente', 'descartado') THEN NULL
             WHEN ? IN ('contatado', 'respondeu') AND next_follow_up_at IS NULL
               THEN date('now', 'localtime', '+3 days')
             ELSE next_follow_up_at
           END
       WHERE id = ?`,
    )
    // Bound in statement order: status, then KEEP_STAGE's two, then the two
    // CASEs' four, then the id.
    .run(
      status,
      status,
      STATUS_STAGE[status],
      status,
      status,
      status,
      status,
      id,
    );
  return Number(result.changes) > 0;
}

/**
 * Move a lead to a funnel stage, bringing its outreach status with it.
 *
 * The funnel is the CRM's control and the status is what the prospector's board
 * reads; writing only one of them is how the two views end up disagreeing about
 * the same business. `contacted_at` is stamped for the stages that mean someone
 * was actually spoken to, and terminal stages leave the follow-up queue.
 */
export function setFunnelStage(id: string, stage: FunnelStage): boolean {
  if (!FUNNEL_STAGES.includes(stage)) return false;

  const status = STAGE_STATUS[stage];
  const db = getDb();
  const result = db
    .prepare(
      `UPDATE leads
       SET funnel_stage = ?,
           status = ?,
           contacted_at = CASE
             WHEN ? = 'descoberta' THEN NULL
             WHEN contacted_at IS NULL
               THEN strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
             ELSE contacted_at
           END,
           next_follow_up_at = CASE
             WHEN ? IN ('descoberta', 'fechado', 'perdido') THEN NULL
             WHEN next_follow_up_at IS NULL
               THEN date('now', 'localtime', '+3 days')
             ELSE next_follow_up_at
           END
       WHERE id = ?`,
    )
    .run(stage, status, stage, stage, id);
  return Number(result.changes) > 0;
}

/** Add or remove a lead from the funnel board without changing its stage. */
export function setFunnelMembership(id: string, included: boolean): boolean {
  const result = getDb()
    .prepare("UPDATE leads SET in_funnel = ? WHERE id = ?")
    .run(included ? 1 : 0, id);
  return Number(result.changes) > 0;
}

/** The person we deal with and the profiles we found, both typed by hand. */
export function setLeadDetails(
  id: string,
  details: {
    contactName?: string | null;
    socials?: SocialLink[];
    tags?: string[];
  },
): boolean {
  const db = getDb();
  const sets: string[] = [];
  const params: Param[] = [];

  if (details.contactName !== undefined) {
    const trimmed = details.contactName?.trim();
    sets.push("contact_name = ?");
    params.push(trimmed && trimmed.length > 0 ? trimmed : null);
  }
  if (details.socials !== undefined) {
    sets.push("socials = ?");
    // An empty list stores NULL, so "has profiles" stays one check rather than
    // one check plus a length test on a parsed array.
    params.push(
      details.socials.length > 0 ? JSON.stringify(details.socials) : null,
    );
  }
  if (details.tags !== undefined) {
    // Re-sanitised here rather than trusting the caller: this is the only door
    // into the column, and the route is not the only thing that can call it.
    const tags = sanitiseTags(details.tags);
    sets.push("tags = ?");
    params.push(tags.length > 0 ? JSON.stringify(tags) : null);
  }
  if (sets.length === 0) return false;

  const result = db
    .prepare(`UPDATE leads SET ${sets.join(", ")} WHERE id = ?`)
    .run(...params, id);
  return Number(result.changes) > 0;
}

/**
 * Records an outreach attempt and seeds a short, visible follow-up loop.
 * The update is idempotent: opening the same wa.me link again never pushes a
 * due follow-up further away or erases a later pipeline state.
 */
export function recordOutreach(id: string): boolean {
  const db = getDb();
  const result = db
    .prepare(
      `UPDATE leads
       SET status = CASE WHEN status = 'novo' THEN 'contatado' ELSE status END,
           funnel_stage = CASE
             WHEN funnel_stage = 'descoberta' THEN 'contato'
             ELSE funnel_stage
           END,
           in_funnel = 1,
           contacted_at = COALESCE(contacted_at, strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
           next_follow_up_at = COALESCE(next_follow_up_at, date('now', 'localtime', '+3 days'))
       WHERE id = ?`,
    )
    .run(id);
  return Number(result.changes) > 0;
}

/**
 * Sets or clears the note on one lead. Empty text stores NULL rather than an
 * empty string, so "has a note" stays a single check for anything reading it.
 */
export function setNotes(id: string, notes: string | null): boolean {
  const trimmed = notes?.trim();
  const db = getDb();
  const result = db
    .prepare("UPDATE leads SET notes = ? WHERE id = ?")
    .run(trimmed && trimmed.length > 0 ? trimmed : null, id);
  return Number(result.changes) > 0;
}

/** Sets or clears the human-managed next follow-up date for one lead. */
export function setFollowUp(id: string, date: string | null): boolean {
  const db = getDb();
  const result = db
    .prepare("UPDATE leads SET next_follow_up_at = ? WHERE id = ?")
    .run(date, id);
  return Number(result.changes) > 0;
}

/**
 * Forget leads.
 *
 * The counterpart to a history that otherwise only ever grows: a search of the
 * wrong city, a niche that turned out to be worthless, or simply a country
 * someone was trying out. Deleting is the only destructive operation the tool
 * has, so it is deliberately explicit — ids, or the filters currently on screen,
 * never "everything" by default.
 *
 * A deleted lead is not tombstoned. It will be found again by the next search
 * that covers it and will come back marked "novo", which is the honest answer:
 * as far as the history is concerned it has never been seen. The audit trail in
 * `prospector_activity` outlives the row and keeps the record of the deletion.
 */
export function deleteLeads(ids: string[]): number {
  const unique = [...new Set(ids.filter((id) => id.length > 0))];
  if (unique.length === 0) return 0;
  const db = getDb();
  let removed = 0;
  db.exec("BEGIN");
  try {
    // Chunked under SQLite's 999-variable default, the same way persistLeads
    // reads ids back: a bulk delete from the board can carry a thousand.
    for (let i = 0; i < unique.length; i += 500) {
      const chunk = unique.slice(i, i + 500);
      const holes = chunk.map(() => "?").join(",");
      const result = db
        .prepare(`DELETE FROM leads WHERE id IN (${holes})`)
        .run(...chunk);
      removed += Number(result.changes);
    }
    db.exec("COMMIT");
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
  return removed;
}

/**
 * Everything the current filters match, in one statement.
 *
 * Shares `where()` with the table above it, which is what makes "apagar" delete
 * exactly the rows the page was showing. A second, hand-written predicate here
 * is the bug that deletes more than the screen ever displayed.
 */
export function deleteMatching(f: HistoryFilters): number {
  const db = getDb();
  const { sql: whereSql, params } = where(f);
  const result = db.prepare(`DELETE FROM leads ${whereSql}`).run(...params);
  return Number(result.changes);
}

/**
 * Names for a set of ids, for an audit line written before the rows go.
 * `recordProspectorActivity` resolves a lead's labels from the table itself,
 * which is empty of them by the time a deletion is being logged.
 */
/**
 * Of these lead ids, the ones this scope may touch.
 *
 * The read side is safe by construction — every query goes through `where()`,
 * which always carries the scope. The *write* side is not: `setStatus(id, …)`
 * and its neighbours take a bare id, and a client's browser can post any id it
 * likes. This is what each mutating route checks first, the same shape and for
 * the same reason as `denyWithout()`: the control is in the route, and a hidden
 * button is only courtesy.
 *
 * Returns the allowed subset rather than a boolean, so a bulk action on a mixed
 * selection does the part it may and reports the difference, instead of failing
 * whole or — far worse — succeeding whole.
 */
export function idsInScope(ids: string[], scope: LeadScope): string[] {
  if (ids.length === 0) return [];
  if (scope.kind === "tudo") return ids;

  const db = getDb();
  const placeholders = ids.map(() => "?").join(",");
  const predicate =
    scope.kind === "atlas" ? "account_id IS NULL" : "account_id = ?";
  const params: Param[] =
    scope.kind === "atlas" ? [...ids] : [...ids, scope.id];

  const rows = db
    .prepare(
      `SELECT id FROM leads WHERE id IN (${placeholders}) AND ${predicate}`,
    )
    .all(...params) as { id: string }[];
  return rows.map((row) => row.id);
}

/** One lead, or null when it is outside the scope — which is the same answer as "gone". */
export function leadInScope(id: string, scope: LeadScope): boolean {
  return idsInScope([id], scope).length === 1;
}

export function leadNames(ids: string[]): Map<string, string> {
  const named = new Map<string, string>();
  const unique = [...new Set(ids)];
  if (unique.length === 0) return named;
  const db = getDb();
  for (let i = 0; i < unique.length; i += 500) {
    const chunk = unique.slice(i, i + 500);
    const holes = chunk.map(() => "?").join(",");
    const rows = db
      .prepare(`SELECT id, name, city FROM leads WHERE id IN (${holes})`)
      .all(...chunk) as { id: string; name: string; city: string | null }[];
    for (const row of rows) {
      named.set(row.id, row.city ? `${row.name} (${row.city})` : row.name);
    }
  }
  return named;
}

/**
 * What has already happened to these businesses, keyed by lead id.
 *
 * The question every contact button needs answered before it is pressed: has
 * somebody here already reached out, when, and whose lead is it now. A live
 * search knows none of that — it returns what the directory holds, not what we
 * did about it — and `isNew` is the wrong field to read for it: a business we
 * found six months ago and never phoned is not new *and* not contacted.
 *
 * Only contacted leads come back. Absence is the answer for everything else, so
 * a caller decorating 200 search results carries 3 entries rather than 200, and
 * "no row" cannot be confused with "row saying nothing happened".
 *
 * Scoped to Atlas because every caller is: the prospector's own results, our
 * history, our CRM rows. A client's board must not be told what we dialled, and
 * this deliberately cannot answer for their leads at all.
 */
export type ContactHistory = {
  /** ISO-8601 UTC. Never null here — a row without it is not returned. */
  contactedAt: string;
  /**
   * Where the deal ended up. Carried alongside the timestamp because the two
   * warnings a contact button owes are one question apart: "somebody already
   * reached out" and "this one is over" — see `CLOSED_STAGES`.
   */
  funnelStage: FunnelStage;
  /** Dials logged against the lead, ever. Zero when the contact was a message. */
  attempts: number;
  /** Whose lead it is now, when somebody has claimed it by contacting it. */
  owner: { id: string; name: string } | null;
};

export function contactHistoryFor(
  ids: string[],
): Map<string, ContactHistory> {
  const found = new Map<string, ContactHistory>();
  const unique = [...new Set(ids)];
  if (unique.length === 0) return found;

  const db = getDb();
  // Chunked for the same reason `leadNames` is: a page of results is bound as
  // one parameter each, and SQLite has a ceiling on how many that can be.
  for (let i = 0; i < unique.length; i += 500) {
    const chunk = unique.slice(i, i + 500);
    const holes = chunk.map(() => "?").join(",");
    const rows = db
      .prepare(
        `SELECT id, contacted_at, funnel_stage, owner_id, owner_name,
                (SELECT COUNT(*) FROM lead_calls c WHERE c.lead_id = leads.id) AS attempts
           FROM leads
          WHERE id IN (${holes})
            AND account_id IS NULL
            AND contacted_at IS NOT NULL`,
      )
      .all(...chunk) as {
      id: string;
      contacted_at: string;
      funnel_stage: string;
      owner_id: string | null;
      owner_name: string | null;
      attempts: number;
    }[];
    for (const row of rows) {
      found.set(row.id, {
        contactedAt: row.contacted_at,
        // Anything unrecognised reads as `descoberta`, the same degradation
        // `toStored` applies: a stage this build has never heard of must not
        // become a silently missing warning.
        funnelStage: FUNNEL_STAGES.includes(row.funnel_stage as FunnelStage)
          ? (row.funnel_stage as FunnelStage)
          : "descoberta",
        attempts: Number(row.attempts ?? 0),
        owner:
          row.owner_id && row.owner_name
            ? { id: row.owner_id, name: row.owner_name }
            : null,
      });
    }
  }
  return found;
}

/** Normalises query-string values into filters. */
/**
 * Filters from a query string, bounded by the caller's scope.
 *
 * `scope` is a second argument rather than another key in `params` on purpose:
 * the query string is user input and the scope is not. A `cliente` session's
 * scope arrives here as `{ kind: "conta" }` and leaves unchanged no matter what
 * the URL says — `?conta=` is read **only** when the caller already holds
 * `tudo`, which is to say only for us. That is the whole rule, and it is why
 * this function cannot be called without deciding it.
 */
export function parseFilters(
  params: Record<string, string | string[] | undefined>,
  scope: LeadScope,
): HistoryFilters {
  const one = (v: string | string[] | undefined): string | undefined => {
    const s = Array.isArray(v) ? v[0] : v;
    const t = (s ?? "").trim();
    return t.length > 0 ? t : undefined;
  };

  const status = one(params.status);
  const stage = one(params.stage);
  const sort = one(params.sort);
  const score = Number(one(params.score));
  const page = Number(one(params.page));
  const perPage = Number(one(params.per));

  return {
    scope: narrow(scope, one(params.conta)),
    q: one(params.q),
    niche: one(params.niche),
    // Only a country we know. An unrecognised code would filter everything away
    // and read as an empty history rather than as a bad link.
    country: isCountryCode(one(params.country))
      ? one(params.country)!.toUpperCase()
      : undefined,
    uf: one(params.uf)?.toUpperCase(),
    city: one(params.city),
    status: LEAD_STATUSES.includes(status as LeadStatus)
      ? (status as LeadStatus)
      : undefined,
    stage: FUNNEL_STAGES.includes(stage as FunnelStage)
      ? (stage as FunnelStage)
      : undefined,
    onlyWhatsapp: one(params.wa) === "1",
    onlyNoSite: one(params.nosite) === "1",
    onlyGoodPhone: one(params.telbom) === "1",
    onlyDue: one(params.due) === "1",
    // Repeated `tag=` params, so a multi-label view is still a URL you can send
    // to someone. Sanitised with the same rules the writers use.
    tags: sanitiseTags(
      Array.isArray(params.tag) ? params.tag : params.tag ? [params.tag] : [],
    ),
    minScore: Number.isFinite(score) ? clamp(score, 0, 100) : undefined,
    sort:
      sort === "recent" ||
      sort === "oldest" ||
      sort === "name" ||
      sort === "followup"
        ? sort
        : "score",
    page: Number.isFinite(page) ? Math.max(1, Math.trunc(page)) : 1,
    // Only honoured by callers that page; the CSV export reads every match and
    // ignores it. clamp() already caps it, so a hand-edited `?per=99999` costs
    // one large page rather than the whole table.
    perPage: Number.isFinite(perPage) ? clamp(perPage, 1, 200) : undefined,
  };
}

/**
 * The `conta` picker on our own screens: "show me only this client", or only
 * our own base.
 *
 * Widening is impossible by construction — anything but `tudo` is returned
 * untouched, so a client fiddling with the URL narrows their view to nothing at
 * worst and never sees a row that isn't theirs. An unknown id is left to the
 * query: it matches no leads, which reads as an empty pipeline rather than as
 * somebody else's.
 */
function narrow(scope: LeadScope, conta: string | undefined): LeadScope {
  if (scope.kind !== "tudo" || !conta) return scope;
  if (conta === "atlas") return SCOPE_ATLAS;
  return { kind: "conta", id: conta };
}

/** The `conta` value that reproduces a scope in a URL, or null when it is the default. */
export function scopeParam(scope: LeadScope): string | null {
  if (scope.kind === "atlas") return "atlas";
  if (scope.kind === "conta") return scope.id;
  return null;
}

/** Rebuilds the query string, so links can change one filter and keep the rest. */
export function filtersToQuery(
  f: HistoryFilters,
  overrides: Partial<HistoryFilters> = {},
): string {
  const merged = { ...f, ...overrides };
  const p = new URLSearchParams();
  // Carried like any other filter so paging and sorting inside one client's
  // pipeline stay inside it. Dropping it here is how the admin's third click
  // silently lands back on everybody's leads.
  const conta = scopeParam(merged.scope);
  if (conta) p.set("conta", conta);
  if (merged.q) p.set("q", merged.q);
  if (merged.niche) p.set("niche", merged.niche);
  if (merged.country) p.set("country", merged.country);
  if (merged.uf) p.set("uf", merged.uf);
  if (merged.city) p.set("city", merged.city);
  if (merged.status) p.set("status", merged.status);
  if (merged.stage) p.set("stage", merged.stage);
  if (merged.onlyWhatsapp) p.set("wa", "1");
  if (merged.onlyNoSite) p.set("nosite", "1");
  if (merged.onlyGoodPhone) p.set("telbom", "1");
  if (merged.onlyDue) p.set("due", "1");
  for (const tag of merged.tags ?? []) p.append("tag", tag);
  if (merged.minScore) p.set("score", String(merged.minScore));
  if (merged.sort && merged.sort !== "score") p.set("sort", merged.sort);
  if (merged.perPage) p.set("per", String(merged.perPage));
  if (merged.page && merged.page > 1) p.set("page", String(merged.page));
  const s = p.toString();
  return s.length > 0 ? `?${s}` : "";
}

function clamp(n: number, lo: number, hi: number): number {
  if (!Number.isFinite(n)) return lo;
  return Math.min(hi, Math.max(lo, Math.trunc(n)));
}
