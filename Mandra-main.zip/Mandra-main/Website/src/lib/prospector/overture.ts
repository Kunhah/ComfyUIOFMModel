import { existsSync } from "node:fs";
import path from "node:path";
import { DuckDBInstance, type DuckDBConnection } from "@duckdb/node-api";
import { findCountry } from "@/lib/countries";
import type { SearchArea } from "./scopes";
import { normalise } from "./cities";
import type { Lead } from "./types";

/**
 * Overture Maps places, queried with DuckDB.
 *
 * Why this source: it is free, needs no API key, and its licence (CDLA
 * Permissive 2.0) lets us store and export results — which the Google Maps
 * Platform terms do not. Coverage of Brazilian SMBs is also far better than
 * OpenStreetMap: for hair/beauty in Belo Horizonte, Overture returns ~4.4k
 * businesses against OSM's 68.
 *
 * There are three modes, tried in this order, and the difference is not small:
 *
 *   local  — queries data/places.parquet, the extract built by `npm run sync`
 *            for whatever countries were asked for. Sub-second.
 *   hosted — queries the same extract over HTTP (PROSPECTOR_EXTRACT_URL), for a
 *            deployment with no disk. DuckDB reads it with range requests, and
 *            because the file is sorted on `city_norm` a city search touches ~20
 *            of them for ~9-18MB of the 122MB: a couple of seconds, measured.
 *   remote — queries the public S3 bucket directly. Works with no setup at all,
 *            but measured 90s–230s per search and is highly variable, because
 *            the places dataset has no geographic partitioning: pruning relies
 *            entirely on Parquet row-group statistics and the whole planet's
 *            metadata still has to be fetched.
 *
 * The first two are the same data and must return identical results. Remote is
 * the fallback that lets a fresh clone work before the sync has run, and the only
 * one the UI warns about — it is also the one that will blow any serverless
 * function timeout, which is what `hosted` exists to avoid.
 */

/** Pin the release so results are reproducible; bump deliberately. */
export const overtureRelease = process.env.OVERTURE_RELEASE ?? "2026-07-22.0";

/**
 * Where `npm run sync` writes the extract.
 *
 * `places.parquet` is the current name — the file stopped being Brazil-only when
 * the sync learned `--countries`. `br-leads.parquet` is still read when it is
 * the only one present, because people were told they could keep it and a
 * Brazil-only extract is a perfectly good extract; it simply has no `country`
 * column, which `hasColumn()` below detects and the query then assumes is BR.
 */
export function localExtractPath(): string {
  const dir = path.join(process.cwd(), "data");
  const current = path.join(dir, "places.parquet");
  if (existsSync(current)) return current;
  const legacy = path.join(dir, "br-leads.parquet");
  if (existsSync(legacy)) return legacy;
  return current;
}

export function hasLocalExtract(): boolean {
  return existsSync(localExtractPath());
}

/** A search is available only after the local extract has been seeded. */
export function hasExtract(): boolean {
  return hasLocalExtract();
}

let connectionPromise: Promise<DuckDBConnection> | null = null;

const log = (event: string, fields: Record<string, unknown> = {}) =>
  console.info(JSON.stringify({ service: "prospector", event, ...fields }));

/**
 * DuckDB resolves `~/.duckdb` for INSTALL and for its secrets file. Serverless
 * runtimes (Netlify Functions, Lambda) hand the process an empty `HOME`, and the
 * remote path then dies on `INSTALL httpfs` with "Can't find the home directory
 * at ''" — which reads as a query failure but happens before any query runs.
 * `/tmp` is the only writable path there. Left alone when HOME is set, so a
 * normal machine keeps its extension cache instead of re-downloading into /tmp.
 */
export function duckdbConfig(): Record<string, string> {
  // DuckDB sizes its thread pool from the core count it can see, and inside a
  // container that is the *host's* count, not this container's share of it. On
  // a shared VPS that is dozens of threads per instance, held for the life of
  // the process and idle almost all of it. Four is more than this workload ever
  // needs: the extract is materialized once and the queries are filters over an
  // in-memory table. Override with DUCKDB_THREADS if a machine ever justifies it.
  const threads: Record<string, string> = {
    threads: process.env.DUCKDB_THREADS?.trim() || "4",
  };
  if (process.env.HOME?.trim()) return threads;
  return {
    ...threads,
    home_directory: "/tmp",
    extension_directory: "/tmp/.duckdb/extensions",
  };
}

/**
 * One connection for the process. The local extract is materialized into an
 * in-memory table before Next accepts requests, so searches never read S3 or
 * wait on a network extension install.
 */
async function getConnection(): Promise<DuckDBConnection> {
  if (!connectionPromise) {
    connectionPromise = (async () => {
      if (!hasLocalExtract()) {
        throw new Error(`Extrato local ausente em ${localExtractPath()}.`);
      }
      const started = Date.now();
      const source = localExtractPath().replace(/'/g, "''");
      log("database.load.start", { source: localExtractPath() });
      const instance = await DuckDBInstance.create(":memory:", duckdbConfig());
      let connection: DuckDBConnection | undefined;
      try {
        connection = await instance.connect();
        await connection.run(
          `CREATE TABLE prospector_places AS SELECT * FROM read_parquet('${source}')`,
        );
        const reader = await connection.runAndReadAll(
          "SELECT count(*) AS rows FROM prospector_places",
        );
        log("database.load.ready", {
          rows: Number(reader.getRowObjectsJS()[0]?.rows ?? 0),
          elapsedMs: Date.now() - started,
        });
        return connection;
      } catch (err) {
        // The instance takes its threads at create() and keeps them whether or
        // not a query ever succeeded, so an abandoned one leaks the whole pool.
        // That matters here precisely because the retry below is deliberate: an
        // extract this process can never load — a truncated file, or a CREATE
        // TABLE that runs the box out of memory — otherwise leaks one pool per
        // request, forever, at no CPU. It reads as thousands of idle "processes"
        // in `docker stats`, whose PIDs column counts threads, not processes.
        //
        // Both handles, in this order, and the connection is not optional: the
        // database outlives `instance.closeSync()` for as long as a connection
        // is open on it, and the failure above happens *after* connect(). Closing
        // only the instance reclaims nothing — measured, it still leaks a pool
        // per attempt.
        connection?.closeSync();
        instance.closeSync();
        throw err;
      }
    })().catch((err) => {
      // Don't cache a failed init — the next request should be able to retry.
      connectionPromise = null;
      throw err;
    });
  }
  return connectionPromise;
}

/** Called by Next instrumentation before the server begins accepting requests. */
export async function warmProspector(): Promise<void> {
  await getConnection();
}

/**
 * Does this extract carry a given column?
 *
 * Two are probed rather than assumed, both for the same reason: an extract built
 * before the column existed is still perfectly queryable, and people are told
 * they can keep their Parquet. Assuming would turn every search against an older
 * file into "Binder Error: column … not found".
 *
 *   city_norm — pre-folded city name. Without it the slower `nrm(city)` path is
 *               used; `npm run upgrade-extract` adds it in seconds.
 *   country   — added when the sync learned to pull more than Brazil. An extract
 *               without it is Brazil, which is what it was built as.
 *
 * Cached per source and column: DESCRIBE costs a round trip.
 */
const columnCache = new Map<string, boolean>();

async function hasColumn(
  connection: DuckDBConnection,
  source: string,
  column: string,
): Promise<boolean> {
  const key = `${source}:${column}`;
  const cached = columnCache.get(key);
  if (cached !== undefined) return cached;
  let present = false;
  try {
    const reader = await connection.runAndReadAll(
      `SELECT * FROM (DESCRIBE SELECT * FROM ${source}) WHERE column_name = '${column}'`,
    );
    present = reader.getRowObjectsJS().length > 0;
  } catch {
    // A source we can't describe will fail the real query with a better message
    // than anything invented here; fall back and let it speak for itself.
    present = false;
  }
  columnCache.set(key, present);
  return present;
}

type Source = {
  /** The materialized local DuckDB table. */
  sql: string;
  mode: OvertureMode;
};

function resolveSource(): Source {
  if (hasLocalExtract()) {
    return {
      sql: "prospector_places",
      mode: "local",
    };
  }
  throw new Error(`Extrato local ausente em ${localExtractPath()}.`);
}

/**
 * Categories come from our own registry in niches.ts, never from user input, but
 * they are interpolated into SQL rather than bound (DuckDB list binding through
 * the node bindings is fiddlier than it's worth). This assertion is the guard
 * that keeps that safe if the registry is ever edited carelessly.
 */
function quoteCategories(categories: string[]): string {
  for (const c of categories) {
    if (!/^[a-z0-9_]+$/.test(c)) {
      throw new Error(`Invalid Overture category: ${JSON.stringify(c)}`);
    }
  }
  return categories.map((c) => `'${c}'`).join(", ");
}

/**
 * The WhatsApp test from score.ts, in SQL, for one country.
 *
 * The two must agree. The board shows a WhatsApp button per row from the JS
 * rule and the header counts "com WhatsApp" from this one, so a disagreement
 * shows up as a count that doesn't match the buttons under it.
 *
 * Countries whose numbering plan doesn't separate mobiles from fixed lines carry
 * no pattern, and the count is then honestly zero rather than a guess.
 */
function whatsappSql(country: string): string {
  const c = findCountry(country);
  if (!c?.mobile) return "false";
  // The registry is ours, but it is interpolated rather than bound, so hold it
  // to what a numbering-plan pattern can contain. A quote in here would end the
  // string literal and the rest of the pattern would be parsed as SQL.
  if (!/^[\^\$0-9A-Za-z()|\[\]{},.*+?-]+$/.test(c.mobile)) {
    throw new Error(`Invalid mobile pattern for ${c.code}`);
  }
  if (!/^[0-9]{1,4}$/.test(c.dial)) {
    throw new Error(`Invalid dial code for ${c.code}`);
  }
  const digits = `regexp_replace(coalesce(phone, ''), '[^0-9]', '', 'g')`;
  // Strip the country code only when what is left is still a plausible number,
  // then the trunk zero — the same two steps, in the same order, as
  // nationalNumber() in score.ts.
  const stripped =
    `(CASE WHEN starts_with(${digits}, '${c.dial}') AND len(${digits}) - ${c.dial.length} >= 6` +
    ` THEN substr(${digits}, ${c.dial.length + 1}) ELSE ${digits} END)`;
  const national = `regexp_replace(${stripped}, '^0+', '')`;
  return `(len(${national}) BETWEEN 6 AND 12 AND regexp_matches(${national}, '${c.mobile}'))`;
}

/**
 * The SQL half of `normalise()` in cities.ts — case, accents and punctuation all
 * folded away. These two have to produce the same string for the same input: the
 * picker resolves a city with the JS version and the query matches rows with this
 * one, so any disagreement shows up as a city that autocompletes fine and then
 * returns nothing.
 */
function nrm(expr: string): string {
  return `trim(regexp_replace(lower(strip_accents(${expr})), '[^a-z0-9]+', ' ', 'g'))`;
}

export type OvertureQuery = {
  area: SearchArea;
  categories: string[];
  onlyWithoutWebsite: boolean;
  minConfidence: number;
  limit: number;
};

export type OvertureResult = {
  leads: Lead[];
  /**
   * Counted over every match, not over the returned page. `leads` is capped by
   * `limit`, so deriving these from it would report the limit back as if it were
   * the size of the pool.
   */
  totals: {
    /** Before the no-website filter, so the UI can show "x of y". */
    matched: number;
    withoutWebsite: number;
    /** Scoped to the rows being shown, i.e. respects the no-website filter. */
    withPhone: number;
    withWhatsapp: number;
  };
  elapsedMs: number;
  mode: OvertureMode;
};

/**
 * The local extract is loaded into DuckDB during startup; requests query that
 * in-memory table.
 */
export type OvertureMode = "local";

export async function queryOverture(q: OvertureQuery): Promise<OvertureResult> {
  const connection = await getConnection();
  const { sql: source, mode } = resolveSource();

  const cols =
    "id, name, category, address, city, uf, phone, website, social, email, lon, lat, confidence";
  const cityExpr = "city";
  const categoryExpr = "category";

  // The city predicate is the selective one, and matching it against a stored,
  // pre-folded column instead of `nrm(city)` is what lets DuckDB prune row groups
  // with it: a function over a column defeats the min/max statistics, an equality
  // on a sorted column uses them. Measured over HTTP on Belo Horizonte, that is
  // 10 requests and 9MB against 80 requests and 82MB — the difference between a
  // search that fits in a serverless timeout and one that doesn't.
  //
  // It also matters on disk, where the same scan is 4.6x more I/O than it needs.
  const cityMatch = (await hasColumn(connection, source, "city_norm"))
    ? "city_norm = $city"
    : `${nrm(cityExpr)} = $city`;

  // Locality names repeat across the planet far more than inside one country —
  // there is a Santiago in Chile, in Spain and in Rio Grande do Sul — so the
  // country is what keeps two of them from being merged into one lead list.
  // An extract built before the sync learned `--countries` has no such column
  // and is Brazil in its entirety, which the city index also records.
  const hasCountry = await hasColumn(connection, source, "country");
  const countryFilter = hasCountry ? "AND country = $country" : "";

  // Brazil reuses city names heavily ("Bom Jesus" exists in a dozen states), so
  // matching on locality alone would merge them. The bbox narrows it and the
  // state code settles it.
  const ufExpr = "uf";

  // A missing state is not a reason to drop a lead. 15.203 Brazilian records
  // give a city with no region at all, and by this point the country, the bbox
  // and the locality name have already pinned the municipality, so the state
  // code has nothing left to disambiguate. The city index only folds state-less
  // rows into names that occur in exactly one state, which is what keeps this
  // from crediting them to the wrong "Santa Luzia".
  //
  // This disjunction is also why the city predicate above has to carry the
  // pruning: an `OR ... IS NULL` is opaque to row-group statistics, so however
  // the extract is sorted, `uf` prunes nothing here.
  //
  // Outside Brazil the region is often unreadable for a whole country, and the
  // index then holds no state code at all for the city. There is nothing to
  // filter on and nothing to disambiguate with — bbox and locality carry it.
  const ufFilter =
    q.area.scope === "city" && q.area.uf
      ? `AND (${ufExpr} = $uf OR ${ufExpr} IS NULL)`
      : q.area.ufs.length
        ? `AND ${ufExpr} IN (${q.area.ufs.map((_, i) => `$areaUf${i}`).join(", ")})`
        : "";

  // The bbox removes nearby municipalities whose locality name happens to match.
  const geographyFilter = q.area.city
    ? `${cityMatch} AND lon BETWEEN $xmin AND $xmax AND lat BETWEEN $ymin AND $ymax`
    : "true";

  // Same rule as isWhatsappCapable() in score.ts, expressed in SQL against the
  // searched country's own numbering plan. It has to be duplicated here rather
  // than derived in JS because the totals below are computed over every match,
  // not just the page we return — reporting "613 with WhatsApp" when that was
  // only counted across the first 1,000 rows would understate the pool and
  // quietly mislead.
  const waExpr = whatsappSql(q.area.country);

  // Restricts the reachability counts to the rows the table will actually show.
  const scopeToShown = q.onlyWithoutWebsite ? "AND no_site" : "";

  // The counts are window aggregates rather than a second query or a CROSS JOIN
  // against an aggregate CTE, both of which would scan the source twice. One
  // scan matters: remotely a scan is minutes.
  const sql = `
    WITH matched AS (
      SELECT ${cols} FROM ${source}
      WHERE ${geographyFilter}
        ${countryFilter}
        AND ${categoryExpr} IN (${quoteCategories(q.categories)})
        ${ufFilter}
        AND confidence >= $minConf
    ),
    flagged AS (
      SELECT *,
             (website IS NULL OR website = '') AS no_site,
             (phone IS NOT NULL AND phone <> '') AS has_phone,
             ${waExpr} AS wa
      FROM matched
    ),
    counted AS (
      SELECT *,
             count(*) OVER ()                                   AS total_matched,
             sum(CASE WHEN no_site THEN 1 ELSE 0 END) OVER ()   AS total_no_site,
             -- Reachability is counted over the rows the user is actually being
             -- shown. Counting it over every match instead produced nonsense
             -- like "sem site: 458 / com WhatsApp: 538" — more contactable leads
             -- than there were leads.
             sum(CASE WHEN has_phone ${scopeToShown} THEN 1 ELSE 0 END) OVER () AS total_phone,
             sum(CASE WHEN wa        ${scopeToShown} THEN 1 ELSE 0 END) OVER () AS total_wa
      FROM flagged
    )
    SELECT * FROM counted
    ${q.onlyWithoutWebsite ? "WHERE no_site" : ""}
    -- Confidence, not name, is the tiebreak: scores bunch at the top (a
    -- no-site business with a mobile scores 100 outright), and ordering those
    -- ties alphabetically buries the best records under every shop whose name
    -- starts with A.
    ORDER BY no_site DESC, confidence DESC
    LIMIT ${Math.max(1, Math.min(5000, Math.trunc(q.limit)))}
  `;

  // Only the parameters the SQL actually names: DuckDB rejects a binding that
  // no placeholder uses, so a region-less city or a country-less extract must
  // not carry one along.
  const params: Record<string, string | number> = { minConf: q.minConfidence };
  if (q.area.city) {
    params.xmin = q.area.city.bbox.xmin;
    params.xmax = q.area.city.bbox.xmax;
    params.ymin = q.area.city.bbox.ymin;
    params.ymax = q.area.city.bbox.ymax;
    params.city = normalise(q.area.city.name);
  }
  if (q.area.scope === "city" && q.area.uf) params.uf = q.area.uf;
  q.area.ufs.forEach((uf, i) => {
    params[`areaUf${i}`] = uf;
  });
  if (hasCountry) params.country = q.area.country;

  const started = Date.now();
  const reader = await connection.runAndReadAll(sql, params);
  const rows = reader.getRowObjectsJS() as Record<string, unknown>[];
  const elapsedMs = Date.now() - started;

  const str = (v: unknown): string | null => {
    if (v === null || v === undefined) return null;
    const s = String(v).trim();
    return s.length > 0 ? s : null;
  };
  const num = (v: unknown): number | null =>
    v === null || v === undefined ? null : Number(v);

  const leads: Lead[] = rows.map((r) => {
    const social = str(r.social);
    return {
      id: String(r.id),
      source: "overture",
      name: str(r.name) ?? "(sem nome)",
      category: str(r.category),
      address: str(r.address),
      city: str(r.city),
      uf: str(r.uf),
      country: q.area.country,
      phone: str(r.phone),
      website: str(r.website),
      social,
      socialLinks:
        social && /^https?:\/\//i.test(social)
          ? [{ platform: socialPlatform(social), url: social }]
          : [],
      email: str(r.email),
      lat: num(r.lat),
      lon: num(r.lon),
      confidence: num(r.confidence) ?? 0,
    };
  });

  // The window aggregates are repeated on every row; with no rows there is
  // nothing to read them from, and zero is the correct answer anyway.
  const first = rows[0];
  const agg = (key: string): number =>
    first === undefined ? 0 : (num(first[key]) ?? 0);

  return {
    leads,
    totals: {
      matched: agg("total_matched"),
      withoutWebsite: agg("total_no_site"),
      withPhone: agg("total_phone"),
      withWhatsapp: agg("total_wa"),
    },
    elapsedMs,
    mode,
  };
}

function socialPlatform(url: string): string {
  try {
    const host = new URL(url).hostname.replace(/^www\./, "");
    if (host === "t.me" || host === "telegram.me") return "telegram";
    return host.split(".")[0] || "rede social";
  } catch {
    return "rede social";
  }
}
