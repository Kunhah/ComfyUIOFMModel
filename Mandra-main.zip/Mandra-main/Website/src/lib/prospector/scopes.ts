import { findCountry } from "@/lib/countries";
import { isIndexedCountry, resolveCity } from "./cities";
import type { City } from "./cities";
import type { SearchRequest, SearchScope } from "./types";
import { BRAZIL_REGIONS, BRAZIL_STATES } from "./brazil";

export type SearchArea = {
  scope: SearchScope;
  name: string;
  country: string;
  /** State for a state/city search; empty for broader scopes. */
  uf: string;
  /** State codes included by a Brazilian macro-region. */
  ufs: readonly string[];
  city?: City;
};

export function resolveSearchArea(
  input: SearchRequest,
): SearchArea | undefined {
  const country = String(input.country ?? "BR").toUpperCase();
  if (!findCountry(country) || !isIndexedCountry(country)) return undefined;
  const scope = input.scope ?? "city";

  if (scope === "city") {
    const city = resolveCity(
      String(input.city ?? ""),
      String(input.uf ?? ""),
      country,
    );
    return city
      ? { scope, name: city.name, country, uf: city.uf, ufs: [], city }
      : undefined;
  }

  if (scope === "country") {
    return {
      scope,
      name: findCountry(country)!.label,
      country,
      uf: "",
      ufs: [],
    };
  }

  // State and macro-region searches currently describe Brazil's official
  // geography. Other countries can still be searched city-by-city or whole.
  if (country !== "BR") return undefined;
  if (scope === "state") {
    const uf = String(input.uf ?? "").toUpperCase();
    const state = BRAZIL_STATES.find(([code]) => code === uf);
    return state
      ? { scope, name: state[1], country, uf, ufs: [uf] }
      : undefined;
  }
  if (scope === "region") {
    const region = BRAZIL_REGIONS.find((item) => item.slug === input.region);
    return region
      ? { scope, name: region.label, country, uf: "", ufs: region.ufs }
      : undefined;
  }
  return undefined;
}
