"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { LeadInsight } from "./lead-insight";
import { useRouter } from "next/navigation";
import {
  Ban,
  CalendarClock,
  Check,
  Globe,
  MapPin,
  MessageCircle,
  Phone,
  PhoneForwarded,
  Lock,
  SkipForward,
  StickyNote,
  TriangleAlert,
} from "lucide-react";
import {
  CALL_OUTCOME_SHORT,
  NEXT_STEPS,
  NEXT_STEP_DEFAULT_DAYS,
  NEXT_STEP_LABEL,
  CALL_OUTCOMES,
  type CallOutcome,
  type NextStep,
} from "@/lib/prospector/types";

/**
 * The dialer.
 *
 * One lead at a time, in the list's order, with the outcome form already on
 * screen before the call starts — an operator who has to go looking for where to
 * record what just happened records it badly or not at all, and the call log is
 * the only thing that makes the rest of this feature worth anything.
 *
 * The queue's position is server state (see `nextInList`), so this component
 * never tracks "where am I": it renders the item it was handed and calls
 * `router.refresh()` after each outcome. That is what lets a session be closed
 * on one machine and resumed on another, and what stops two operators working
 * the same list from being handed the same business.
 *
 * The one piece of local state that matters is the draft: the note and the next
 * step are typed *during* the call, and losing them to a stray refresh is losing
 * the call. The draft survives a refresh that brings back the same lead, and is
 * cleared by the caller keying this component on the lead's id — a remount, not
 * an effect that resets six fields and re-renders to do it.
 *
 * It also reserves the lead for as long as it is on screen. The server hands the
 * same next position to two dialers that render before either writes, so the
 * reservation is what actually decides between them — see ownership.ts. It is
 * renewed on a timer because it expires on purpose, and released on unmount so
 * moving on doesn't leave a lead locked behind.
 */

/** The lead as this screen needs it, flattened server-side. */
export type CallCard = {
  id: string;
  name: string;
  nicheLabel: string;
  /** The niche slug, not the label. The objection brief is keyed on it, and a
   * label ("Salões de beleza") is a display string that can be reworded. */
  niche: string | null;
  category: string | null;
  address: string | null;
  place: string;
  phone: string | null;
  /** `tel:` URL, built server-side from the same normalisation the CSV uses. */
  telUrl: string | null;
  whatsappUrl: string | null;
  website: string | null;
  email: string | null;
  mapUrl: string | null;
  score: number;
  reasons: string[];
  contactName: string | null;
  /**
   * Why this number may not reach this business — a shared switchboard, a line
   * already found dead. Null when there is nothing to say. See phone-quality.ts.
   */
  phoneWarning: string | null;
  stageLabel: string;
  /**
   * Set when this lead is at a closed stage — won or lost. The queue no longer
   * builds one in, but a list created before that rule existed still holds
   * them, and the dialer is the last place that can say so before the number is
   * pressed. See `CLOSED_STAGES`.
   */
  closedStage: "fechado" | "perdido" | null;
  notes: string | null;
  nextFollowUpAt: string | null;
  /**
   * When somebody first reached out, already formatted. Separate from `history`
   * because the two answer different questions: `lead_calls` knows about dials,
   * and a lead messaged on WhatsApp from the prospector has a `contacted_at`
   * and no call row at all. Reading only the log tells the operator this is a
   * first approach when it is not.
   */
  contactedAt: string | null;
  /** Previous calls, newest first, already formatted for display. */
  history: {
    id: number;
    outcomeLabel: string;
    stepLabel: string | null;
    notes: string | null;
    actor: string;
    when: string;
  }[];
};

type Props = {
  listId: number;
  listName: string;
  item: CallCard;
  position: number;
  done: number;
  total: number;
};

/** Outcomes that end the conversation, so the next-step row is hidden for them. */
const TERMINAL: CallOutcome[] = ["sem_interesse", "numero_invalido", "fechado"];

/** YYYY-MM-DD, `days` from today, in the operator's own timezone. */
function isoIn(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  // Built from the local parts rather than toISOString(), which converts to UTC
  // and hands back yesterday's date for anyone west of Greenwich after 21:00.
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export function CallSession({
  listId,
  listName,
  item,
  position,
  done,
  total,
}: Props) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [outcome, setOutcome] = useState<CallOutcome | null>(null);
  const [nextStep, setNextStep] = useState<NextStep>("nova_ligacao");
  const [followUp, setFollowUp] = useState("");
  const [notes, setNotes] = useState("");
  const [dialled, setDialled] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const noteRef = useRef<HTMLTextAreaElement>(null);
  /**
   * Whether this operator actually holds the lead. `esperando` only until the
   * first answer comes back — the controls stay live through it rather than
   * flashing disabled on every lead, because the overwhelming majority of claims
   * succeed and a form that greys out for 200ms each time reads as broken.
   */
  const [claim, setClaim] = useState<{
    state: "esperando" | "reservado" | "ocupado";
    message?: string;
  }>({ state: "esperando" });

  useEffect(() => {
    let cancelled = false;
    let renew: ReturnType<typeof setInterval> | undefined;

    async function take() {
      const response = await fetch("/api/prospector/calls/claim", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ id: item.id, listId }),
      });
      const body = (await response.json().catch(() => ({}))) as {
        error?: string;
        ttlMinutes?: number;
      };
      if (cancelled) return;
      if (!response.ok) {
        setClaim({ state: "ocupado", message: body.error });
        if (renew) clearInterval(renew);
        return;
      }
      setClaim({ state: "reservado" });
      // Half the server's own TTL, read from the response rather than restated
      // here: a copy of that number in the client is a copy that drifts, and the
      // failure it causes — a claim lapsing mid-call — looks like a race.
      if (!renew && typeof body.ttlMinutes === "number") {
        renew = setInterval(
          () => void take(),
          Math.max(60_000, (body.ttlMinutes * 60_000) / 2),
        );
      }
    }

    void take();
    return () => {
      cancelled = true;
      if (renew) clearInterval(renew);
      // keepalive, because this fires as the page is being torn down and a
      // normal fetch would be cancelled with it. Best effort by design — the
      // claim expires on its own, and that is the guarantee this leans on.
      void fetch(
        `/api/prospector/calls/claim?id=${encodeURIComponent(item.id)}`,
        { method: "DELETE", keepalive: true },
      );
    };
  }, [item.id, listId]);

  const taken = claim.state === "ocupado";

  const terminal = outcome !== null && TERMINAL.includes(outcome);
  const step: NextStep = terminal ? "nenhum" : nextStep;
  const defaultDays = NEXT_STEP_DEFAULT_DAYS[step];

  function record() {
    if (!outcome) return;
    setError(null);
    startTransition(async () => {
      const response = await fetch("/api/prospector/calls/outcome", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          id: item.id,
          listId,
          outcome,
          nextStep: step,
          notes,
          // Absent means "use the step's default", which is not the same as null.
          // Sending the empty string would mean "no follow-up at all" and quietly
          // drop a callback the operator just agreed to.
          ...(followUp ? { followUpAt: followUp } : {}),
        }),
      });
      if (!response.ok) {
        const body = (await response.json().catch(() => ({}))) as {
          error?: string;
        };
        setError(body.error ?? "Não foi possível registrar a ligação.");
        return;
      }
      router.refresh();
    });
  }

  function skip() {
    setError(null);
    startTransition(async () => {
      await fetch("/api/prospector/calls/skip", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ id: item.id, listId }),
      });
      router.refresh();
    });
  }

  return (
    <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_360px]">
      <section className="border-line bg-surface rounded-2xl border">
        {/* Progress. The position is the operator's sense of how long is left,
            and a queue with no visible end is one people stop halfway through. */}
        <div className="border-line flex flex-wrap items-center gap-3 border-b px-5 py-3.5 text-sm">
          <span className="text-fg-muted">
            {listName} · lead{" "}
            <span className="tnum font-medium">{position}</span> de{" "}
            <span className="tnum">{total}</span>
          </span>
          <div className="bg-surface-2 ml-auto h-1.5 w-40 overflow-hidden rounded-full">
            <div
              className="bg-brand h-full rounded-full transition-[width]"
              style={{ width: `${total > 0 ? (done / total) * 100 : 0}%` }}
            />
          </div>
          <span className="text-fg-subtle tnum text-xs">
            {done}/{total}
          </span>
        </div>

        <div className="px-5 py-5">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <h2 className="text-2xl font-semibold tracking-tight">
                {item.name}
              </h2>
              <p className="text-fg-muted mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
                <span className="inline-flex items-center gap-1.5">
                  <MapPin className="text-fg-subtle size-3.5" />
                  {item.place}
                </span>
                <span>{item.nicheLabel}</span>
                <span className="text-fg-subtle">
                  score <span className="tnum">{item.score}</span>
                </span>
              </p>
              {item.contactName && (
                <p className="mt-1.5 text-sm">
                  Falar com{" "}
                  <span className="font-medium">{item.contactName}</span>
                </p>
              )}
            </div>
            <span className="border-line text-fg-muted rounded-full border px-3 py-1 text-xs">
              {item.stageLabel}
            </span>
          </div>

          {item.reasons.length > 0 && (
            <ul className="mt-3.5 flex flex-wrap gap-1.5">
              {item.reasons.map((reason) => (
                <li
                  key={reason}
                  className="bg-surface-2 text-fg-muted rounded-lg px-2.5 py-1 text-xs"
                >
                  {reason}
                </li>
              ))}
            </ul>
          )}

          {/* Between the score's reasons and the phone warning: the reasons say
              why this lead is on the list, this says what to do with it, and the
              warning says what could waste the call. Read top to bottom in the
              seconds before dialling, which is the order they are needed in. */}
          <LeadInsight key={item.id} leadId={item.id} niche={item.niche} />

          {/* Shown above the dial, not beside it. The whole point is that it is
              read *before* the call rather than discovered during it. */}
          {item.phoneWarning && (
            <p className="mt-4 flex items-start gap-2 rounded-xl border border-amber-500/30 bg-amber-500/10 px-3.5 py-2.5 text-sm text-amber-700 dark:text-amber-400">
              <TriangleAlert className="mt-0.5 size-4 shrink-0" />
              {item.phoneWarning}
            </p>
          )}

          {/* Louder than the phone warning above it, because it is the one that
              says not to make this call at all. It does not disable the button:
              phoning a customer back, or a lost lead with a new reason, is a
              real thing to do — it just must never happen by working down a
              queue on autopilot. */}
          {item.closedStage && (
            <p
              className={`mt-4 flex items-start gap-2 rounded-xl border px-3.5 py-2.5 text-sm ${
                item.closedStage === "fechado"
                  ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-800 dark:text-emerald-400"
                  : "border-red-500/40 bg-red-500/10 text-red-800 dark:text-red-400"
              }`}
            >
              <Ban className="mt-0.5 size-4 shrink-0" />
              {item.closedStage === "fechado"
                ? "Este negócio já foi fechado — é cliente. Não prospecte de novo; confirme com o responsável antes de ligar."
                : "Este lead foi dado como perdido. Só ligue de novo se houver um motivo novo."}
            </p>
          )}

          {/* The dial. Deliberately the largest thing on the screen: it is the
              one action the whole page exists for. `tel:` hands off to whatever
              the machine uses — a softphone, a paired handset, the operator's
              own phone — rather than this app pretending to place calls. */}
          <div className="mt-5 flex flex-wrap items-center gap-2.5">
            {item.telUrl ? (
              <a
                href={item.telUrl}
                onClick={() => {
                  setDialled(true);
                  // Focusing the note is what makes people write one: by the time
                  // the call ends the cursor is already in the right place.
                  window.setTimeout(() => noteRef.current?.focus(), 400);
                }}
                className="bg-brand inline-flex items-center gap-2.5 rounded-xl px-5 py-3 text-base font-semibold text-white transition hover:opacity-90"
              >
                <Phone className="size-5" />
                Ligar para {item.phone}
              </a>
            ) : (
              <span className="border-line text-fg-muted inline-flex items-center gap-2 rounded-xl border border-dashed px-4 py-3 text-sm">
                <TriangleAlert className="size-4" />
                Sem telefone utilizável
              </span>
            )}
            {item.whatsappUrl && (
              <a
                href={item.whatsappUrl}
                target="_blank"
                rel="noreferrer"
                className="border-line hover:border-line-strong inline-flex items-center gap-2 rounded-xl border px-4 py-3 text-sm font-medium transition"
              >
                <MessageCircle className="size-4" />
                WhatsApp
              </a>
            )}
            {item.website && (
              <a
                href={item.website}
                target="_blank"
                rel="noreferrer"
                className="border-line hover:border-line-strong inline-flex items-center gap-2 rounded-xl border px-4 py-3 text-sm font-medium transition"
              >
                <Globe className="size-4" />
                Site
              </a>
            )}
            <button
              type="button"
              onClick={skip}
              disabled={pending}
              className="text-fg-muted hover:text-fg ml-auto inline-flex items-center gap-2 px-3 py-3 text-sm transition disabled:opacity-50"
            >
              <SkipForward className="size-4" />
              Pular
            </button>
          </div>

          {/* Someone else got here first. Said before the outcome buttons rather
              than after a refused save, because the point is to stop the call
              from being made — a 409 read after the fact is a business that has
              already been phoned twice. */}
          {taken && (
            <div className="mt-6 flex flex-wrap items-center gap-3 rounded-xl border border-amber-600/40 bg-amber-500/10 px-4 py-3 text-sm">
              <Lock className="size-4 shrink-0 text-amber-700" />
              <span className="text-fg">
                {claim.message ??
                  "Outro operador está atendendo este lead agora."}
              </span>
              <button
                type="button"
                onClick={() => {
                  setClaim({ state: "esperando" });
                  router.refresh();
                }}
                className="border-line hover:border-line-strong ml-auto rounded-lg border px-3 py-1.5 text-sm font-medium transition"
              >
                Próximo lead
              </button>
            </div>
          )}

          {/* The qualification. Present before the call rather than after it, so
              recording the outcome is one click on a target that was already
              under the cursor. */}
          <fieldset className="mt-6">
            <legend className="text-fg-muted text-xs font-medium tracking-wide uppercase">
              Como foi a ligação?
            </legend>
            <div className="mt-2.5 flex flex-wrap gap-2">
              {CALL_OUTCOMES.map((value) => {
                const active = outcome === value;
                return (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setOutcome(value)}
                    className={`rounded-xl border px-3.5 py-2.5 text-sm font-medium transition ${
                      active
                        ? "border-brand bg-brand/10 text-brand"
                        : "border-line hover:border-line-strong"
                    }`}
                  >
                    {CALL_OUTCOME_SHORT[value]}
                  </button>
                );
              })}
            </div>
          </fieldset>

          {outcome && !terminal && (
            <fieldset className="mt-5">
              <legend className="text-fg-muted text-xs font-medium tracking-wide uppercase">
                Próximo passo
              </legend>
              <div className="mt-2.5 flex flex-wrap gap-2">
                {NEXT_STEPS.map((value) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setNextStep(value)}
                    className={`rounded-xl border px-3.5 py-2 text-sm transition ${
                      step === value
                        ? "border-brand bg-brand/10 text-brand font-medium"
                        : "border-line hover:border-line-strong"
                    }`}
                  >
                    {NEXT_STEP_LABEL[value]}
                  </button>
                ))}
              </div>

              <label className="mt-3.5 flex flex-wrap items-center gap-2.5 text-sm">
                <CalendarClock className="text-fg-subtle size-4" />
                <span className="text-fg-muted">Retornar em</span>
                <input
                  type="date"
                  value={followUp}
                  onChange={(event) => setFollowUp(event.target.value)}
                  className="border-line bg-surface-2 rounded-lg border px-3 py-1.5"
                />
                {!followUp && (
                  <span className="text-fg-subtle text-xs">
                    {defaultDays === null
                      ? "sem follow-up"
                      : `padrão: ${isoIn(defaultDays)}`}
                  </span>
                )}
              </label>
            </fieldset>
          )}

          <label className="mt-5 block">
            <span className="text-fg-muted flex items-center gap-1.5 text-xs font-medium tracking-wide uppercase">
              <StickyNote className="size-3.5" />O que foi dito
            </span>
            <textarea
              ref={noteRef}
              value={notes}
              onChange={(event) => setNotes(event.target.value)}
              rows={3}
              placeholder="Fica no histórico do lead — é o que você vai querer ler na próxima ligação."
              className="border-line bg-surface-2 placeholder:text-fg-subtle mt-2 w-full rounded-xl border px-3.5 py-2.5 text-sm"
            />
          </label>

          {error && (
            <p className="mt-3 flex items-center gap-2 text-sm text-red-600">
              <TriangleAlert className="size-4" />
              {error}
            </p>
          )}

          <div className="mt-4 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={record}
              disabled={!outcome || pending || taken}
              className="bg-fg text-bg inline-flex items-center gap-2 rounded-xl px-5 py-3 text-sm font-semibold transition hover:opacity-90 disabled:opacity-40"
            >
              <Check className="size-4" />
              {pending ? "Salvando…" : "Salvar e próximo"}
            </button>
            {!outcome && (
              <span className="text-fg-subtle text-sm">
                Escolha um resultado para continuar.
              </span>
            )}
            {dialled && !outcome && (
              <span className="text-fg-muted inline-flex items-center gap-1.5 text-sm">
                <PhoneForwarded className="size-4" />
                Ligação iniciada — registre o resultado.
              </span>
            )}
          </div>
        </div>
      </section>

      {/* What happened last time. The single most useful thing to have on screen
          while the phone rings, and the reason the note field is worth pushing. */}
      <aside className="border-line bg-surface h-fit rounded-2xl border">
        <h3 className="border-line border-b px-5 py-3.5 text-sm font-medium">
          Histórico deste lead
        </h3>
        <div className="px-5 py-4">
          {item.notes && (
            <p className="border-line text-fg-muted mb-4 border-l-2 pl-3 text-sm">
              {item.notes}
            </p>
          )}
          {item.history.length === 0 ? (
            item.contactedAt ? (
              <p className="text-sm text-amber-800">
                Nunca foi ligado, mas já houve contato em {item.contactedAt} —
                provavelmente por mensagem. Não se apresente como o primeiro
                contato.
              </p>
            ) : (
              <p className="text-fg-subtle text-sm">
                Nunca foi ligado. Esta é a primeira tentativa.
              </p>
            )
          ) : (
            <ol className="space-y-3.5">
              {item.history.map((call) => (
                <li key={call.id} className="text-sm">
                  <p className="font-medium">{call.outcomeLabel}</p>
                  <p className="text-fg-subtle text-xs">
                    {call.when} · {call.actor}
                    {call.stepLabel ? ` · ${call.stepLabel}` : ""}
                  </p>
                  {call.notes && (
                    <p className="text-fg-muted mt-1">{call.notes}</p>
                  )}
                </li>
              ))}
            </ol>
          )}
          {item.nextFollowUpAt && (
            <p className="border-line text-fg-muted mt-4 flex items-center gap-1.5 border-t pt-3.5 text-xs">
              <CalendarClock className="size-3.5" />
              Follow-up marcado para {item.nextFollowUpAt}
            </p>
          )}
        </div>
      </aside>
    </div>
  );
}
