"use client";

import { useCallback, useEffect, useState } from "react";
import { Loader2, MessageCircle, Power, RefreshCw, Save } from "lucide-react";

/**
 * Pairing one client's WhatsApp number, and telling the agent who it is.
 *
 * Two settings that fail independently and are done at different moments: the
 * number is paired in a meeting with the client's phone on the table, and what
 * the assistant should say about their business usually arrives days later. The
 * screen keeps them apart and says so, because a paired number with no brief is
 * a real state — the agent stays silent and a person answers.
 *
 * The QR code expires roughly every 40 seconds, which is why this polls rather
 * than rendering once: a stale code that silently stops working reads as "our
 * system is broken" to whoever is holding the phone.
 */

type Status = {
  configured: boolean;
  instance: string | null;
  state: "open" | "connecting" | "close" | "unknown";
  number: string | null;
  brief: string | null;
};

/** Slow enough not to hammer the bridge, fast enough to beat the QR's lifetime. */
const POLL_MS = 4000;

export function WhatsappConnect({
  accountId,
  accountName,
  initial,
}: {
  accountId: string;
  accountName: string;
  initial: Status;
}) {
  const [status, setStatus] = useState<Status>(initial);
  const [qr, setQr] = useState<string | null>(null);
  const [pairingCode, setPairingCode] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [brief, setBrief] = useState(initial.brief ?? "");
  const [savedBrief, setSavedBrief] = useState(initial.brief ?? "");
  const [savingBrief, setSavingBrief] = useState(false);

  const base = `/api/admin/accounts/${accountId}/whatsapp`;

  /**
   * Asks the server, and changes nothing.
   *
   * Split from `applyStatus` so the callers decide whether the answer is still
   * wanted by the time it arrives. A poll that resolves after the panel has been
   * unmounted — or after the operator has just pressed "desconectar" — would
   * otherwise write a stale "connected" over the state that replaced it.
   */
  const fetchStatus = useCallback(async (): Promise<Status | null> => {
    try {
      const response = await fetch(base, { cache: "no-store" });
      if (!response.ok) return null;
      return (await response.json()) as Status;
    } catch {
      // A failed poll is not worth a message: the next one is four seconds away
      // and what is on screen is still the last thing we actually knew.
      return null;
    }
  }, [base]);

  const applyStatus = useCallback((next: Status | null) => {
    if (!next) return;
    setStatus(next);
    // The code is only meaningful while the bridge is waiting for a scan.
    // Leaving it on screen after the phone has paired invites a second device
    // being linked to the same client's number.
    if (next.state === "open") {
      setQr(null);
      setPairingCode(null);
    }
  }, []);

  /**
   * Poll only while something is actually in flight. A connected account is a
   * screen someone leaves open all afternoon, and polling it forever is a
   * request every four seconds for a value that changes once a year.
   */
  const watching = qr !== null || status.state === "connecting";

  // Once on mount, always. The server renders what the database knows — whether
  // an instance is bound — never whether the phone is online, so the live state
  // has to be asked for. Asking here rather than on the server keeps a slow or
  // dead bridge from holding up the whole install-kit page.
  useEffect(() => {
    let cancelled = false;
    void fetchStatus().then((next) => {
      if (!cancelled) applyStatus(next);
    });
    return () => {
      cancelled = true;
    };
  }, [fetchStatus, applyStatus]);

  useEffect(() => {
    if (!watching) return;
    let cancelled = false;
    const timer = setInterval(() => {
      void fetchStatus().then((next) => {
        if (!cancelled) applyStatus(next);
      });
    }, POLL_MS);
    return () => {
      cancelled = true;
      clearInterval(timer);
    };
  }, [watching, fetchStatus, applyStatus]);

  async function connect() {
    setBusy(true);
    setError(null);
    try {
      const response = await fetch(base, { method: "POST" });
      const data = (await response.json().catch(() => ({}))) as {
        error?: string;
        qr?: string | null;
        pairingCode?: string | null;
        state?: Status["state"];
      };
      if (!response.ok)
        throw new Error(data.error ?? `Erro ${response.status}`);
      setQr(data.qr ?? null);
      setPairingCode(data.pairingCode ?? null);
      applyStatus(await fetchStatus());
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Falha ao conectar.");
    } finally {
      setBusy(false);
    }
  }

  async function disconnect() {
    if (
      !confirm(
        `Desconectar o WhatsApp de ${accountName}?\n\nO número para de responder. As conversas continuam no CRM — elas são o registro do que foi dito a pessoas reais.`,
      )
    ) {
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const response = await fetch(base, { method: "DELETE" });
      if (!response.ok) {
        const data = (await response.json().catch(() => ({}))) as {
          error?: string;
        };
        throw new Error(data.error ?? `Erro ${response.status}`);
      }
      setQr(null);
      setPairingCode(null);
      applyStatus(await fetchStatus());
    } catch (cause) {
      setError(
        cause instanceof Error ? cause.message : "Falha ao desconectar.",
      );
    } finally {
      setBusy(false);
    }
  }

  async function saveBrief() {
    setSavingBrief(true);
    setError(null);
    try {
      const response = await fetch(base, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ brief }),
      });
      if (!response.ok) {
        const data = (await response.json().catch(() => ({}))) as {
          error?: string;
        };
        throw new Error(data.error ?? `Erro ${response.status}`);
      }
      setSavedBrief(brief);
      applyStatus(await fetchStatus());
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Falha ao salvar.");
    } finally {
      setSavingBrief(false);
    }
  }

  const connected = status.state === "open";
  const briefDirty = brief.trim() !== savedBrief.trim();

  if (!status.configured) {
    return (
      <section className="border-line bg-surface rounded-2xl border p-5">
        <Header />
        <p className="text-fg-muted mt-3 text-sm">
          A ponte de WhatsApp não está configurada neste servidor. Defina{" "}
          <code className="text-xs">EVOLUTION_API_URL</code>,{" "}
          <code className="text-xs">EVOLUTION_API_KEY</code> e{" "}
          <code className="text-xs">EVOLUTION_WEBHOOK_SECRET</code> e suba o
          serviço <code className="text-xs">evolution</code>.
        </p>
      </section>
    );
  }

  return (
    <section className="border-line bg-surface rounded-2xl border p-5">
      <Header />

      <div className="mt-4 flex flex-wrap items-center gap-3">
        <span
          className={`rounded-full border px-2.5 py-1 text-xs font-medium ${
            connected
              ? "border-emerald-300 bg-emerald-50 text-emerald-800"
              : "border-line bg-surface-2 text-fg-muted"
          }`}
        >
          {connected
            ? "Conectado"
            : status.state === "connecting"
              ? "Aguardando leitura do QR"
              : "Não conectado"}
        </span>
        {connected && status.number && (
          <span className="text-fg-muted text-sm">+{status.number}</span>
        )}
        {status.instance && (
          <span className="text-fg-subtle text-xs">
            instância <code className="text-[11px]">{status.instance}</code>
          </span>
        )}

        <div className="ml-auto flex items-center gap-2">
          {busy && <Loader2 className="text-fg-subtle size-4 animate-spin" />}
          {connected ? (
            <button
              type="button"
              onClick={disconnect}
              disabled={busy}
              className="border-line inline-flex items-center gap-2 rounded-xl border px-3 py-2 text-sm text-red-700 transition hover:border-red-300 hover:bg-red-50 disabled:opacity-60"
            >
              <Power className="size-4" />
              Desconectar
            </button>
          ) : (
            <button
              type="button"
              onClick={connect}
              disabled={busy}
              className="bg-brand text-brand-fg inline-flex items-center gap-2 rounded-xl px-3.5 py-2 text-sm font-medium transition hover:opacity-90 disabled:opacity-60"
            >
              {qr ? (
                <RefreshCw className="size-4" />
              ) : (
                <MessageCircle className="size-4" />
              )}
              {qr ? "Gerar novo QR" : "Conectar número"}
            </button>
          )}
        </div>
      </div>

      {error && (
        <p className="mt-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
          {error}
        </p>
      )}

      {qr && !connected && (
        <div className="border-line bg-surface-2 mt-4 flex flex-wrap items-center gap-5 rounded-2xl border p-5">
          {/* eslint-disable-next-line @next/next/no-img-element -- a data: URI from
              the bridge, regenerated every ~40s; next/image would want a loader
              and a remote pattern for something that is never cached. */}
          <img
            src={qr}
            alt="QR code para parear o WhatsApp"
            width={200}
            height={200}
            className="rounded-xl bg-white p-2"
          />
          <div className="min-w-[220px] flex-1 text-sm">
            <p className="font-medium">No celular do cliente:</p>
            <ol className="text-fg-muted mt-2 list-decimal space-y-1 pl-4">
              <li>Abra o WhatsApp</li>
              <li>
                Toque em <strong>Configurações → Aparelhos conectados</strong>
              </li>
              <li>
                Toque em <strong>Conectar um aparelho</strong> e aponte para o
                código
              </li>
            </ol>
            {pairingCode && (
              <p className="text-fg-muted mt-3">
                Ou use o código{" "}
                <code className="text-fg text-sm font-semibold">
                  {pairingCode}
                </code>
              </p>
            )}
            {/* The expiry is the thing that confuses people holding the phone. */}
            <p className="text-fg-subtle mt-3 text-xs">
              O código expira em cerca de 40 segundos. Esta tela gera outro
              sozinha enquanto estiver aberta.
            </p>
          </div>
        </div>
      )}

      <div className="border-line mt-5 border-t pt-5">
        <label className="block text-sm">
          <span className="font-medium">O que o assistente deve saber</span>
          <span className="text-fg-muted mt-1 block">
            O que a empresa faz, nas palavras dela. É isto que o assistente
            responde no WhatsApp do cliente.
          </span>
          <textarea
            value={brief}
            onChange={(event) => setBrief(event.target.value)}
            rows={5}
            maxLength={4000}
            placeholder="Clínica odontológica em Belo Horizonte. Atende de segunda a sexta, 9h às 18h. Faz limpeza, clareamento, implante e ortodontia. Convênios: Amil e Bradesco Dental."
            className="border-line bg-surface-2 focus:border-brand mt-2 w-full rounded-xl border px-3 py-2.5 text-sm outline-none"
          />
        </label>

        <div className="mt-3 flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={saveBrief}
            disabled={savingBrief || !briefDirty}
            className="border-line hover:border-brand inline-flex items-center gap-2 rounded-xl border px-3.5 py-2 text-sm font-medium transition disabled:opacity-50"
          >
            {savingBrief ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <Save className="size-4" />
            )}
            Salvar
          </button>

          {/* The consequence, stated where the empty field is. Without this the
              silence reads as a broken integration rather than as the deliberate
              refusal it is. */}
          {!savedBrief.trim() && (
            <p className="text-fg-muted text-sm">
              Sem este texto o assistente <strong>não responde</strong> as
              conversas desta conta — elas ficam para uma pessoa atender.
            </p>
          )}
        </div>
      </div>
    </section>
  );
}

function Header() {
  return (
    <div className="flex items-center gap-3">
      <span className="bg-brand/10 text-brand flex size-10 shrink-0 items-center justify-center rounded-xl">
        <MessageCircle className="size-5" />
      </span>
      <div>
        <h2 className="font-semibold">WhatsApp do cliente</h2>
        <p className="text-fg-muted text-sm">
          O número do cliente, atendido pelo assistente — não o nosso.
        </p>
      </div>
    </div>
  );
}
