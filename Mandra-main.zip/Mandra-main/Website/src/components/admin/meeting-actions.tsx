"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, RotateCcw, Trash2 } from "lucide-react";
import { PENDING_STATUS, type ReviewStatus } from "@/lib/review/types";

/**
 * Retry, delete, and the poll that turns "Transcrevendo" into the review.
 *
 * The poll lives here rather than in the page because the page is a server
 * component holding the rendered analysis — refreshing it is the point, and a
 * client island that calls `router.refresh()` is the whole mechanism.
 */
export function MeetingActions({
  id,
  status,
  /** Where a delete returns to — the list this review was opened from. */
  basePath,
}: {
  id: string;
  status: ReviewStatus;
  basePath: string;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!PENDING_STATUS.includes(status)) return;
    const timer = setInterval(() => router.refresh(), 5000);
    return () => clearInterval(timer);
  }, [status, router]);

  async function act(method: "POST" | "DELETE") {
    if (method === "DELETE" && !confirm("Apagar esta reunião e sua análise?")) {
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const response = await fetch(`/api/review/${id}`, { method });
      if (!response.ok) {
        const data = (await response.json().catch(() => ({}))) as {
          error?: string;
        };
        setError(data.error ?? `Falhou (HTTP ${response.status}).`);
        return;
      }
      if (method === "DELETE") router.push(basePath);
      else router.refresh();
    } catch {
      setError("Sem conexão com o servidor.");
    } finally {
      setBusy(false);
    }
  }

  const working = PENDING_STATUS.includes(status);

  return (
    <div className="flex flex-wrap items-center gap-2">
      <button
        type="button"
        onClick={() => act("POST")}
        disabled={busy || working}
        className="border-line text-fg-muted hover:text-fg inline-flex items-center gap-2 rounded-xl border px-3 py-2 text-xs font-medium disabled:opacity-40"
      >
        {busy ? (
          <Loader2 className="size-3.5 animate-spin" />
        ) : (
          <RotateCcw className="size-3.5" />
        )}
        Analisar de novo
      </button>
      <button
        type="button"
        onClick={() => act("DELETE")}
        disabled={busy || working}
        className="border-line inline-flex items-center gap-2 rounded-xl border px-3 py-2 text-xs font-medium text-red-500 disabled:opacity-40"
      >
        <Trash2 className="size-3.5" />
        Apagar
      </button>
      {error && <span className="text-xs text-red-500">{error}</span>}
    </div>
  );
}
