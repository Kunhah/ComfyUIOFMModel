"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { PhoneCall, X } from "lucide-react";

/**
 * "Turn what I'm looking at into a call queue."
 *
 * Two ways in, because there are two ways people decide who to call: the filter
 * currently on screen ("todas as padarias sem site em BH") or the rows they
 * ticked. Both end at the same route, and the difference is deliberate — with
 * `filters` the server re-runs the query and takes *every* match, so a list is
 * not silently capped at the page you happened to be on. Only `ids` sends rows.
 *
 * Inline rather than a modal: naming a list is one short field, and a dialog for
 * it costs a focus trap, an escape handler and a scroll lock to ask one question.
 */
export function CreateCallListButton({
  filters,
  ids,
  count,
  tone = "light",
  basePath = "/admin/ligacoes",
}: {
  /**
   * Where the new queue opens. Defaults to the CRM's tree; the operator's
   * screens pass their own, because a list built by an operator that opens
   * under /admin drops them back on /operador with the list already created and
   * no way to reach it.
   */
  basePath?: string;
  /** The history view to build from, as a query string. Server re-runs it. */
  filters?: string;
  /** Explicit rows, when the operator ticked them. Takes precedence. */
  ids?: string[];
  /** How many leads this would queue, for the button's label. */
  count: number;
  /** The bulk bar is a dark surface; the page header is not. */
  tone?: "light" | "dark";
}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);

  const dark = tone === "dark";

  function create() {
    setError(null);
    startTransition(async () => {
      const response = await fetch("/api/prospector/calls/lists", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(
          ids && ids.length > 0
            ? { name, ids }
            : // "?" rather than "" so the route takes the filters branch and
              // builds from the whole history rather than rejecting the request.
              { name, filters: filters || "?" },
        ),
      });
      const body = (await response.json().catch(() => ({}))) as {
        error?: string;
        excluded?: number;
        list?: { id: number };
      };
      if (!response.ok || !body.list) {
        setError(body.error ?? "Não foi possível criar a lista.");
        return;
      }
      // Straight into the queue. Building a list is never the goal — calling is,
      // and a screen that congratulates you on creating it adds a click to every
      // single session.
      router.push(`${basePath}/${body.list.id}`);
    });
  }

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        disabled={count === 0}
        className={
          dark
            ? "inline-flex items-center gap-2 rounded-lg bg-white/10 px-3 py-2 font-medium transition hover:bg-white/20 disabled:opacity-50 sm:py-1.5"
            : "border-line bg-surface hover:border-line-strong inline-flex items-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-medium transition disabled:opacity-50"
        }
      >
        <PhoneCall className="size-4" />
        Criar lista de ligações
      </button>
    );
  }

  return (
    <div
      className={
        dark
          ? "flex flex-wrap items-center gap-2"
          : "border-line bg-surface flex flex-wrap items-center gap-2 rounded-xl border px-2 py-1.5"
      }
    >
      <input
        autoFocus
        value={name}
        onChange={(event) => setName(event.target.value)}
        onKeyDown={(event) => {
          if (event.key === "Enter" && name.trim()) create();
          if (event.key === "Escape") setOpen(false);
        }}
        maxLength={60}
        placeholder={`Nome da lista (${count} leads)`}
        className={
          dark
            ? "w-56 rounded-lg bg-white/10 px-3 py-1.5 text-sm placeholder:text-slate-400"
            : "bg-surface-2 placeholder:text-fg-subtle w-64 rounded-lg px-3 py-1.5 text-sm"
        }
      />
      <button
        type="button"
        onClick={create}
        disabled={pending || name.trim().length === 0}
        className={
          dark
            ? "rounded-lg bg-white px-3 py-1.5 text-sm font-semibold text-black transition hover:opacity-90 disabled:opacity-40"
            : "bg-fg text-bg rounded-lg px-3 py-1.5 text-sm font-semibold transition hover:opacity-90 disabled:opacity-40"
        }
      >
        {pending ? "Criando…" : "Criar e ligar"}
      </button>
      <button
        type="button"
        onClick={() => setOpen(false)}
        aria-label="Cancelar"
        className={dark ? "text-slate-400 hover:text-white" : "text-fg-subtle"}
      >
        <X className="size-4" />
      </button>
      {error && (
        <span className={dark ? "text-red-300" : "text-sm text-red-600"}>
          {error}
        </span>
      )}
    </div>
  );
}
