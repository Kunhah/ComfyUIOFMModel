"use client";

import { useEffect, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Search, X } from "lucide-react";

/**
 * Finding one card on a board that holds hundreds.
 *
 * The filter is in the query string and the query runs in SQLite, not in the
 * browser: each column renders at most `BOARD_COLUMN_LIMIT` cards, so a filter
 * applied to what is already on screen would search forty leads per stage and
 * confidently report that the lead you are looking for is not in the funnel.
 * That is the same reason the column totals are counted in SQL rather than from
 * the card list, and it is the failure this box would have if it were client-side.
 *
 * Being in the URL also makes a filtered board shareable and survives the
 * `router.refresh()` every card move triggers. `replace` rather than `push`, so
 * typing eight characters does not leave eight entries in the back button.
 */
export function FunnelSearch({ value }: { value: string }) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const [text, setText] = useState(value);

  // The URL is authoritative — the back button and a cleared filter both change
  // it from outside this component — but it is adopted only when it disagrees
  // with what was typed, or the navigation this box just made would race the
  // caret. Same shape as `seenColumns` in the board next to it.
  const [seen, setSeen] = useState(value);
  if (seen !== value) {
    setSeen(value);
    if (text.trim() !== value) setText(value);
  }

  useEffect(() => {
    // The trim is on both sides of the comparison and of the write, so a
    // trailing space cannot bounce the effect between two states forever.
    const typed = text.trim();
    if (typed === value) return;
    const timer = window.setTimeout(() => {
      const next = new URLSearchParams(params.toString());
      if (typed.length > 0) next.set("q", typed);
      else next.delete("q");
      const query = next.toString();
      router.replace(query ? `${pathname}?${query}` : pathname, {
        scroll: false,
      });
    }, 300);
    return () => window.clearTimeout(timer);
  }, [text, value, params, pathname, router]);

  return (
    <div className="relative w-full max-w-sm">
      <Search
        aria-hidden
        className="text-fg-subtle pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2"
      />
      <input
        type="search"
        value={text}
        onChange={(event) => setText(event.target.value)}
        placeholder="Buscar no funil: nome, contato, cidade ou telefone"
        aria-label="Buscar um lead no funil"
        className="border-line bg-surface focus:border-brand w-full rounded-lg border py-2 pr-9 pl-9 text-sm outline-none"
      />
      {text.length > 0 && (
        <button
          type="button"
          onClick={() => setText("")}
          className="text-fg-subtle hover:text-fg absolute top-1/2 right-2 -translate-y-1/2 rounded p-1"
        >
          <X className="size-4" />
          <span className="sr-only">Limpar a busca</span>
        </button>
      )}
    </div>
  );
}
