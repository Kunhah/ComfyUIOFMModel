"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Code2, KeyRound, Plus, Users } from "lucide-react";

/**
 * The client accounts screen.
 *
 * Two actions, and the order matters: create the account, then give it a login.
 * They are deliberately not one form. An account with leads arriving and no
 * login is a real and useful state — it is every client whose site we finished
 * before the hand-over meeting — and folding the two together would force a
 * password to be invented weeks before anyone needs it.
 *
 * `logins: 0` is therefore not an error, but it *is* the thing worth seeing at
 * a glance: it means the product exists and the client has never opened it.
 */

export type ManagedAccount = {
  id: string;
  name: string;
  slug: string;
  country: string;
  active: boolean;
  notes: string | null;
  leads: number;
  logins: number;
  sites: number;
  lastLeadAt: string | null;
};

export function AccountManager({ accounts }: { accounts: ManagedAccount[] }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState("");
  /** Which account's "new login" form is open. Only ever one at a time. */
  const [loginFor, setLoginFor] = useState<string | null>(null);

  async function send(url: string, method: string, body: unknown) {
    setError(null);
    const response = await fetch(url, {
      method,
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!response.ok) {
      const data = (await response.json().catch(() => null)) as {
        error?: string;
      } | null;
      setError(data?.error ?? "Não foi possível concluir a ação.");
      return false;
    }
    // The server is authoritative: refresh rather than patching local state, so
    // the counters below come back from SQL instead of being guessed at here.
    startTransition(() => router.refresh());
    return true;
  }

  async function createAccount(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (await send("/api/admin/accounts", "POST", { name })) {
      setName("");
      setCreating(false);
    }
  }

  async function createLogin(
    event: React.FormEvent<HTMLFormElement>,
    accountId: string,
  ) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const ok = await send("/api/admin/users", "POST", {
      username: form.get("username"),
      displayName: form.get("displayName"),
      password: form.get("password"),
      role: "cliente",
      accountId,
    });
    if (ok) setLoginFor(null);
  }

  return (
    <div className="flex flex-col gap-5">
      {error && (
        <p className="rounded-xl border border-red-300 bg-red-50 px-4 py-3 text-sm text-red-800">
          {error}
        </p>
      )}

      <div className="flex items-center justify-between gap-3">
        <p className="text-fg-muted text-sm">
          {accounts.length === 0
            ? "Nenhuma conta ainda."
            : `${accounts.length} conta${accounts.length === 1 ? "" : "s"}`}
        </p>
        <button
          type="button"
          onClick={() => setCreating((open) => !open)}
          className="bg-brand text-brand-fg flex items-center gap-2 rounded-xl px-3.5 py-2 text-sm font-medium transition hover:opacity-90"
        >
          <Plus className="size-4" />
          Nova conta
        </button>
      </div>

      {creating && (
        <form
          onSubmit={createAccount}
          className="border-line bg-surface flex flex-wrap items-end gap-3 rounded-2xl border p-4"
        >
          <label className="flex-1 text-sm">
            <span className="text-fg-muted">Nome do cliente</span>
            <input
              value={name}
              onChange={(event) => setName(event.target.value)}
              required
              autoFocus
              placeholder="Clínica Martins"
              className="border-line bg-bg mt-1.5 w-full rounded-xl border px-3 py-2.5 text-sm outline-none focus:border-[var(--color-brand)]"
            />
          </label>
          <button
            type="submit"
            disabled={pending}
            className="bg-brand text-brand-fg rounded-xl px-4 py-2.5 text-sm font-medium disabled:opacity-60"
          >
            Criar
          </button>
        </form>
      )}

      {accounts.map((account) => (
        <section
          key={account.id}
          className="border-line bg-surface rounded-2xl border p-5"
        >
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="min-w-0">
              <h2 className="flex items-center gap-2 font-semibold">
                {account.name}
                {!account.active && (
                  <span className="border-line text-fg-subtle rounded-full border px-2 py-0.5 text-xs">
                    Suspensa
                  </span>
                )}
              </h2>
              <p className="text-fg-subtle mt-0.5 text-xs">
                {account.slug} · {account.country}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* The scope in a link. /admin holds `tudo`, so ?conta= narrows
                  it — which is the whole point of the admin-only narrowing in
                  parseFilters(). */}
              <Link
                href={`/admin?conta=${encodeURIComponent(account.id)}`}
                className="border-line hover:border-brand rounded-xl border px-3 py-2 text-sm transition"
              >
                Ver pipeline
              </Link>
              {/* Everything the client's own repository needs, in one place.
                  Reading a key off /admin/sites and retyping the endpoint from
                  memory is where the install mistakes come from, and each one
                  fails silently — a form posting nowhere looks exactly like a
                  form nobody has filled in. */}
              <Link
                href={`/admin/contas/${encodeURIComponent(account.slug)}`}
                className="border-line hover:border-brand flex items-center gap-2 rounded-xl border px-3 py-2 text-sm transition"
              >
                <Code2 className="size-4" />
                Kit de instalação
              </Link>
              <button
                type="button"
                onClick={() =>
                  setLoginFor(loginFor === account.id ? null : account.id)
                }
                className="border-line hover:border-brand flex items-center gap-2 rounded-xl border px-3 py-2 text-sm transition"
              >
                <KeyRound className="size-4" />
                Novo acesso
              </button>
              <button
                type="button"
                disabled={pending}
                onClick={() =>
                  send("/api/admin/accounts", "PATCH", {
                    id: account.id,
                    active: !account.active,
                  })
                }
                className="border-line hover:border-brand rounded-xl border px-3 py-2 text-sm transition disabled:opacity-60"
              >
                {account.active ? "Suspender" : "Reativar"}
              </button>
            </div>
          </div>

          <dl className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat
              label="Contatos"
              value={account.leads.toLocaleString("pt-BR")}
            />
            <Stat label="Sites" value={String(account.sites)} />
            <Stat
              label="Acessos"
              value={String(account.logins)}
              /* The one number that reads as a to-do rather than as a fact. */
              warn={account.logins === 0}
            />
            <Stat
              label="Último contato"
              value={
                account.lastLeadAt
                  ? new Date(account.lastLeadAt).toLocaleDateString("pt-BR")
                  : "—"
              }
            />
          </dl>

          {account.logins === 0 && (
            <p className="text-fg-muted mt-3 flex items-center gap-2 text-sm">
              <Users className="size-4" />
              Esta conta ainda não foi entregue — ninguém do cliente consegue
              entrar.
            </p>
          )}

          {loginFor === account.id && (
            <form
              onSubmit={(event) => createLogin(event, account.id)}
              className="border-line mt-4 grid gap-3 rounded-xl border border-dashed p-4 sm:grid-cols-4"
            >
              <Field
                name="displayName"
                label="Nome"
                placeholder="Dr. Martins"
              />
              <Field
                name="username"
                label="Usuário"
                placeholder="martins"
                autoCapitalize="none"
              />
              <Field
                name="password"
                label="Senha"
                type="password"
                placeholder="mínimo 8 caracteres"
              />
              <button
                type="submit"
                disabled={pending}
                className="bg-brand text-brand-fg mt-auto rounded-xl px-4 py-2.5 text-sm font-medium disabled:opacity-60"
              >
                Criar acesso
              </button>
            </form>
          )}
        </section>
      ))}
    </div>
  );
}

function Stat({
  label,
  value,
  warn,
}: {
  label: string;
  value: string;
  warn?: boolean;
}) {
  return (
    <div>
      <dt className="text-fg-subtle text-xs">{label}</dt>
      <dd
        className={`mt-0.5 text-lg font-semibold tabular-nums ${
          warn ? "text-amber-700" : ""
        }`}
      >
        {value}
      </dd>
    </div>
  );
}

function Field({
  name,
  label,
  ...rest
}: {
  name: string;
  label: string;
} & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="text-sm">
      <span className="text-fg-muted">{label}</span>
      <input
        name={name}
        required
        {...rest}
        className="border-line bg-bg mt-1.5 w-full rounded-xl border px-3 py-2.5 text-sm outline-none focus:border-[var(--color-brand)]"
      />
    </label>
  );
}
