import { PhoneCall, PhoneOff, ThumbsUp, Trophy } from "lucide-react";
import type { CallResultStats, NicheCallStats } from "@/lib/prospector/funnel";
import { CALL_OUTCOME_LABEL } from "@/lib/prospector/types";

/**
 * What the calling produced, as opposed to how much of it happened.
 *
 * The daily counter answers "did we make the calls"; this answers "what came
 * back". They are different questions and deliberately different screens — a
 * hundred dials that reach nobody is a good day by the first measure and a
 * wasted one by this.
 *
 * COLOUR. The seven outcomes are not seven identities needing seven hues. The
 * one distinction that changes what you do tomorrow is whether a human picked
 * up, so that is the only thing colour encodes: brand for reached, a neutral for
 * the dial that found nobody. Valence stays in the text, because "sem interesse"
 * is a reached call and painting it the same green as "fechou" would call a
 * rejection a win.
 *
 * The pair is validated against the #fdfbf7 surface rather than eyeballed:
 * ΔE 14.4 deutan / 15.9 normal, both above the floor, and both marks clear 3:1.
 * The neutral fails a chroma floor written for categorical palettes, which is
 * intended — "não atendeu" is the absence of contact, and giving it a hue would
 * invent a meaning it does not have. Identity is never colour-alone regardless:
 * every bar is directly labelled with its outcome and its count.
 */

const REACHED_FILL = "#a85f09";
const UNREACHED_FILL = "#7d8792";

const fmt = (value: number) => value.toLocaleString("pt-BR");
const pct = (value: number) =>
  `${(value * 100).toLocaleString("pt-BR", { maximumFractionDigits: 1 })}%`;

export function CallResults({
  stats,
  byNiche,
  nicheLabels,
}: {
  stats: CallResultStats;
  byNiche: NicheCallStats[];
  nicheLabels: Record<string, string>;
}) {
  if (stats.calls === 0) {
    return (
      <section className="border-line bg-surface rounded-2xl border p-8 text-center">
        <PhoneOff className="text-fg-subtle mx-auto size-6" />
        <h2 className="mt-3 font-semibold">Nenhuma ligação registrada ainda</h2>
        <p className="text-fg-muted mx-auto mt-1.5 max-w-md text-sm leading-6">
          Os resultados aparecem aqui assim que as primeiras ligações forem
          registradas. Cada ligação classifica o lead automaticamente e o move
          de etapa no funil abaixo.
        </p>
      </section>
    );
  }

  // Ranked, because the question is "what happens most when we dial" and funnel
  // order buries the answer among outcomes that barely occur.
  const ranked = [...stats.byOutcome]
    .filter((o) => o.count > 0)
    .sort((a, b) => b.count - a.count);
  const peak = Math.max(...ranked.map((o) => o.count), 1);

  return (
    <div className="space-y-4">
      <div className="border-line bg-surface grid divide-y overflow-hidden rounded-2xl border sm:grid-cols-2 sm:divide-x sm:divide-y-0 xl:grid-cols-4">
        <Tile
          icon={PhoneCall}
          label="Ligações feitas"
          value={fmt(stats.calls)}
          note={`${fmt(stats.leads)} ${stats.leads === 1 ? "negócio" : "negócios"}`}
        />
        <Tile
          icon={PhoneCall}
          label="Atenderam"
          value={fmt(stats.reached)}
          note={`${pct(stats.calls > 0 ? stats.reached / stats.calls : 0)} das ligações`}
        />
        <Tile
          icon={ThumbsUp}
          label="Interessados"
          value={fmt(stats.interested)}
          note={
            stats.reached > 0
              ? `${pct(stats.interested / stats.reached)} de quem atendeu`
              : "ninguém atendeu ainda"
          }
        />
        <Tile
          icon={Trophy}
          label="Fechados"
          value={fmt(stats.won)}
          note={
            stats.leads > 0
              ? `${pct(stats.won / stats.leads)} dos negócios falados`
              : "—"
          }
          accent={stats.won > 0}
        />
      </div>

      <section className="border-line bg-surface rounded-2xl border p-5">
        <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
          <h2 className="font-semibold">O que acontece quando ligamos</h2>
          {/* Two marks, so a legend is present. It names the encoding rather
              than the series, because the bar's own label already says which
              outcome it is. */}
          <p className="text-fg-muted flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1.5">
              <span
                aria-hidden
                className="size-2.5 rounded-[2px]"
                style={{ background: REACHED_FILL }}
              />
              falou com alguém
            </span>
            <span className="flex items-center gap-1.5">
              <span
                aria-hidden
                className="size-2.5 rounded-[2px]"
                style={{ background: UNREACHED_FILL }}
              />
              não atendeu
            </span>
          </p>
        </div>

        <ul className="mt-4 space-y-2.5">
          {ranked.map((row) => (
            <li key={row.outcome} className="grid grid-cols-[1fr_auto] gap-x-3">
              <p className="text-fg col-start-1 truncate text-[13px]">
                {CALL_OUTCOME_LABEL[row.outcome]}
              </p>
              <p className="tnum text-fg-muted col-start-2 self-baseline text-[13px]">
                <span className="text-fg font-medium">{fmt(row.count)}</span>
                <span className="text-fg-subtle ml-1.5 text-xs">
                  {pct(row.share)}
                </span>
              </p>
              {/* The track is the full width; the fill is the value. Rounded
                  data-end only, so the bar stays anchored to its baseline. */}
              <div className="col-span-2 mt-1 h-2 overflow-hidden rounded-[2px] bg-[var(--color-surface-2)]">
                <div
                  className="h-full rounded-r-[4px]"
                  style={{
                    width: `${Math.max(1, (row.count / peak) * 100)}%`,
                    background: row.reached ? REACHED_FILL : UNREACHED_FILL,
                  }}
                />
              </div>
            </li>
          ))}
        </ul>
      </section>

      {byNiche.length > 0 && (
        <section className="border-line bg-surface rounded-2xl border p-5">
          <h2 className="font-semibold">Desempenho por nicho</h2>
          <p className="text-fg-muted mt-1 text-sm leading-6">
            Quem atende o telefone e quem compra. Ordenado por volume de
            ligações — um nicho com três ligações e 100% de atendimento é ruído,
            não um padrão.
          </p>

          {/* A table, not a chart: five measures across many rows is what a
              table does best, and the eye compares the columns directly. */}
          <div className="-mx-1 mt-4 overflow-x-auto px-1">
            <table className="w-full min-w-[560px] text-sm">
              <thead>
                <tr className="text-fg-muted border-line border-b text-left text-xs">
                  <th scope="col" className="pb-2 font-medium">
                    Nicho
                  </th>
                  <th scope="col" className="pb-2 text-right font-medium">
                    Ligações
                  </th>
                  <th scope="col" className="pb-2 text-right font-medium">
                    Atenderam
                  </th>
                  <th scope="col" className="pb-2 text-right font-medium">
                    Interesse
                  </th>
                  <th scope="col" className="pb-2 text-right font-medium">
                    Fechados
                  </th>
                </tr>
              </thead>
              <tbody className="divide-line divide-y">
                {byNiche.map((row) => (
                  <tr key={row.niche}>
                    <th
                      scope="row"
                      className="max-w-[220px] truncate py-2 pr-3 text-left font-normal"
                    >
                      {nicheLabels[row.niche] ?? row.niche}
                    </th>
                    <td className="tnum py-2 text-right">{fmt(row.calls)}</td>
                    <td className="tnum py-2 text-right">
                      {fmt(row.reached)}
                      <span className="text-fg-subtle ml-1.5 text-xs">
                        {pct(row.reachRate)}
                      </span>
                    </td>
                    <td className="tnum py-2 text-right">
                      {fmt(row.interested)}
                      <span className="text-fg-subtle ml-1.5 text-xs">
                        {pct(row.interestRate)}
                      </span>
                    </td>
                    <td className="tnum py-2 text-right font-medium">
                      {fmt(row.won)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
}

function Tile({
  icon: Icon,
  label,
  value,
  note,
  accent,
}: {
  icon: typeof PhoneCall;
  label: string;
  value: string;
  note: string;
  accent?: boolean;
}) {
  return (
    <div className="flex items-center gap-3.5 px-5 py-5">
      <span className="bg-brand/10 text-brand flex size-11 shrink-0 items-center justify-center rounded-xl">
        <Icon className="size-5" />
      </span>
      <div className="min-w-0">
        <p className="text-fg-muted text-xs">{label}</p>
        <p className="tnum mt-0.5 text-2xl font-semibold tracking-tight">
          {value}
        </p>
        <p
          className={`mt-0.5 text-xs ${accent ? "text-brand font-medium" : "text-fg-subtle"}`}
        >
          {note}
        </p>
      </div>
    </div>
  );
}
