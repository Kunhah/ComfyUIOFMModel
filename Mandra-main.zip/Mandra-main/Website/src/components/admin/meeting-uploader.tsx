"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, Upload } from "lucide-react";
import { OUTCOME_LABEL, type MeetingOutcome } from "@/lib/review/types";

/**
 * The upload form.
 *
 * `XMLHttpRequest` rather than `fetch`, for the one thing fetch still cannot do:
 * report upload progress. A 200 MB recording over a domestic connection is
 * several minutes of a page that otherwise looks frozen, and a seller who
 * assumes it broke uploads it three more times.
 *
 * The file goes as the raw body with the metadata in the query string, matching
 * the route — a FormData here would defeat the streaming on the other end.
 */
export function MeetingUploader({ ready }: { ready: boolean }) {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);

  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [outcome, setOutcome] = useState<MeetingOutcome>("perdeu");
  const [focus, setFocus] = useState("");
  const [progress, setProgress] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  function pick(next: File | null) {
    setFile(next);
    setError(null);
    // The filename is almost always a better title than an empty box, and it is
    // still editable. One less field to fill for the common case.
    if (next && !title) setTitle(next.name.replace(/\.[^.]+$/, ""));
  }

  function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!file || progress !== null) return;
    if (!title.trim()) {
      setError("Dê um nome à reunião.");
      return;
    }

    setError(null);
    setProgress(0);

    const params = new URLSearchParams({ title: title.trim(), outcome });
    if (focus.trim()) params.set("focus", focus.trim());

    const request = new XMLHttpRequest();
    request.open("POST", `/api/review?${params.toString()}`);
    request.setRequestHeader("content-type", file.type || "audio/mpeg");

    request.upload.addEventListener("progress", (event) => {
      if (event.lengthComputable) {
        setProgress(Math.round((event.loaded / event.total) * 100));
      }
    });

    request.addEventListener("load", () => {
      setProgress(null);
      if (request.status === 201) {
        setFile(null);
        setTitle("");
        setFocus("");
        if (inputRef.current) inputRef.current.value = "";
        // The row lands as "Na fila"; the list polls from there.
        router.refresh();
        return;
      }
      try {
        setError(
          (JSON.parse(request.responseText) as { error?: string }).error ??
            "Falha no envio.",
        );
      } catch {
        setError(`Falha no envio (HTTP ${request.status}).`);
      }
    });

    request.addEventListener("error", () => {
      setProgress(null);
      setError("A conexão caiu durante o envio.");
    });

    request.send(file);
  }

  const busy = progress !== null;

  return (
    <form
      onSubmit={submit}
      className="border-line bg-surface mt-6 rounded-2xl border p-5 md:p-6"
    >
      <div className="grid gap-4 md:grid-cols-2">
        <label className="block">
          <span className="text-fg-muted text-xs font-medium">Gravação</span>
          <input
            ref={inputRef}
            type="file"
            accept="audio/*,video/mp4,video/webm,video/quicktime"
            onChange={(event) => pick(event.target.files?.[0] ?? null)}
            disabled={busy}
            className="border-line bg-surface-raised file:bg-brand/10 file:text-brand mt-1.5 block w-full rounded-xl border px-3 py-2 text-sm file:mr-3 file:rounded-lg file:border-0 file:px-3 file:py-1.5 file:text-xs file:font-medium"
          />
        </label>

        <label className="block">
          <span className="text-fg-muted text-xs font-medium">
            Nome da reunião
          </span>
          <input
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            disabled={busy}
            placeholder="Clínica Martins — 2ª reunião"
            className="border-line bg-surface-raised mt-1.5 block w-full rounded-xl border px-3 py-2 text-sm"
          />
        </label>

        <label className="block">
          <span className="text-fg-muted text-xs font-medium">Desfecho</span>
          <select
            value={outcome}
            onChange={(event) =>
              setOutcome(event.target.value as MeetingOutcome)
            }
            disabled={busy}
            className="border-line bg-surface-raised mt-1.5 block w-full rounded-xl border px-3 py-2 text-sm"
          >
            {(Object.keys(OUTCOME_LABEL) as MeetingOutcome[]).map((value) => (
              <option key={value} value={value}>
                {OUTCOME_LABEL[value]}
              </option>
            ))}
          </select>
          <span className="text-fg-subtle mt-1 block text-xs">
            Informado por você, nunca deduzido. É o que decide se a análise
            procura o que sustentou a venda ou o que a derrubou.
          </span>
        </label>

        <label className="block">
          <span className="text-fg-muted text-xs font-medium">
            Algo específico para olhar{" "}
            <span className="text-fg-subtle">(opcional)</span>
          </span>
          <input
            value={focus}
            onChange={(event) => setFocus(event.target.value)}
            disabled={busy}
            placeholder="Travei quando ele falou de preço"
            className="border-line bg-surface-raised mt-1.5 block w-full rounded-xl border px-3 py-2 text-sm"
          />
        </label>
      </div>

      {error && (
        <p className="mt-4 rounded-xl border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-500">
          {error}
        </p>
      )}

      {busy && (
        <div className="mt-4">
          <div className="bg-surface-raised h-1.5 w-full overflow-hidden rounded-full">
            <div
              className="bg-brand h-full transition-[width]"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-fg-muted mt-1.5 text-xs">
            Enviando {progress}% — não feche a aba.
          </p>
        </div>
      )}

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <button
          type="submit"
          disabled={!file || busy || !ready}
          className="bg-brand text-ink-950 inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium disabled:opacity-40"
        >
          {busy ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <Upload className="size-4" />
          )}
          Enviar e analisar
        </button>
        {!ready && (
          <span className="text-fg-muted text-xs">
            A transcrição não está configurada neste servidor.
          </span>
        )}
      </div>
    </form>
  );
}
