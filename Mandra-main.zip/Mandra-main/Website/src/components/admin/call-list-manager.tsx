"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ListPlus, Phone, Trash2, TriangleAlert } from "lucide-react";

/**
 * The list index: what exists, and the manual way to build one.
 *
 * Lists are normally created from the CRM itself — `CreateCallListButton` in the
 * header carries the filter on screen, and the bulk bar carries the ticked rows.
 * This form is the fallback for a query typed or pasted by hand, which is worth
 * keeping for a filter someone has bookmarked, but is not the path to advertise.
 * Either way the filter string is re-run server-side; see the route for why the
 * client must not send the ids it happens to have loaded.
 */

export type ListCard = {
  id: number;
  name: string;
  total: number;
  done: number;
  skipped: number;
  pending: number;
  createdByName: string;
  createdAtLabel: string;
  sourceQuery: string | null;
};

export function CallListManager({
  lists,
  // Every link stays inside the tree the screen was mounted in. An operator
  // handed an /admin URL is an operator redirected home mid-queue.
  basePath = "/admin/ligacoes",
}: {
  lists: ListCard[];
  basePath?: string;
}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [name, setName] = useState("");
  const [filters, setFilters] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [priorizar, setPriorizar] = useState(false);

  function create() {
    setError(null);
    setNotice(null);
    startTransition(async () => {
      const response = await fetch("/api/prospector/calls/lists", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ name, filters: filters || "?", priorizar }),
      });
      const body = (await response.json().catch(() => ({}))) as {
        error?: string;
        excluded?: number;
        limit?: number;
        leitura?: string | null;
        list?: { total: number };
      };
      if (!response.ok) {
        setError(body.error ?? "Não foi possível criar a lista.");
        return;
      }
      // Said out loud when it ran, and silent when it did not. The ranking fails
      // open on purpose, and an operator who ticked the box deserves to know
      // whether the order they are about to work is the model's or their own.
      if (body.leitura) setNotice(body.leitura);
      else if (priorizar) {
        setNotice("A IA não respondeu; a lista ficou na ordem do filtro.");
      }

      if (body.excluded) {
        // Reported rather than swallowed. A list quietly smaller than the filter
        // that built it is one an operator finishes believing they called
        // everyone in it.
        setNotice(
          `${body.excluded} lead(s) ficaram de fora — sem telefone, ou acima do limite de ${body.limit} por lista.`,
        );
      }
      setName("");
      setFilters("");
      router.refresh();
    });
  }

  function remove(id: number, listName: string) {
    if (
      !window.confirm(
        `Excluir a lista "${listName}"? As ligações já registradas continuam no histórico dos leads.`,
      )
    ) {
      return;
    }
    startTransition(async () => {
      await fetch(`/api/prospector/calls/lists?id=${id}`, { method: "DELETE" });
      router.refresh();
    });
  }

  return (
    <div className="mt-4 space-y-4">
      <div className="border-line bg-surface rounded-2xl border px-4 py-4">
        <h3 className="flex items-center gap-2 text-sm font-medium">
          <ListPlus className="size-4" />
          Nova lista
        </h3>
        <div className="mt-3 grid gap-2.5 sm:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_auto]">
          <input
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder="Nome da lista"
            maxLength={60}
            className="border-line bg-surface-2 placeholder:text-fg-subtle rounded-xl border px-3.5 py-2.5 text-sm"
          />
          <input
            value={filters}
            onChange={(event) => setFilters(event.target.value)}
            placeholder="Filtro do CRM, ex: ?nicho=padarias&cidade=Belo Horizonte"
            className="border-line bg-surface-2 placeholder:text-fg-subtle rounded-xl border px-3.5 py-2.5 text-sm"
          />
          <button
            type="button"
            onClick={create}
            disabled={pending || name.trim().length === 0}
            className="bg-fg text-bg rounded-xl px-4 py-2.5 text-sm font-semibold transition hover:opacity-90 disabled:opacity-40"
          >
            {pending ? "Criando…" : "Criar"}
          </button>
        </div>
        <label className="text-fg-muted mt-2.5 flex items-center gap-2 text-xs">
          <input
            type="checkbox"
            checked={priorizar}
            onChange={(event) => setPriorizar(event.target.checked)}
            className="accent-brand size-3.5"
          />
          Deixar a IA escolher a ordem (telefone que funciona e sinal de que
          falta o que vendemos sobem; quem ninguém atende desce)
        </label>
        <p className="text-fg-subtle mt-2 text-xs">
          O caminho normal é filtrar no CRM e clicar em{" "}
          <strong className="font-medium">Criar lista de ligações</strong> lá —
          ou marcar linhas e usar a barra de seleção. Este campo é a saída
          manual: cole a query da barra de endereço, ou deixe em branco para
          pegar todos os leads com telefone. Só entram leads que tenham um
          número.
        </p>
        {error && (
          <p className="mt-2.5 flex items-center gap-1.5 text-sm text-red-600">
            <TriangleAlert className="size-4" />
            {error}
          </p>
        )}
        {notice && <p className="text-fg-muted mt-2.5 text-sm">{notice}</p>}
      </div>

      {lists.length === 0 ? (
        <p className="border-line text-fg-muted rounded-2xl border border-dashed px-4 py-8 text-center text-sm">
          Nenhuma lista ainda. Crie uma acima para começar a ligar.
        </p>
      ) : (
        <ul className="space-y-3">
          {lists.map((list) => {
            const progress =
              list.total > 0
                ? ((list.done + list.skipped) / list.total) * 100
                : 0;
            return (
              <li
                key={list.id}
                className="border-line bg-surface rounded-2xl border px-4 py-4"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 className="truncate font-medium">{list.name}</h3>
                    <p className="text-fg-subtle mt-0.5 text-xs">
                      {list.createdByName} · {list.createdAtLabel}
                      {list.sourceQuery ? ` · ${list.sourceQuery}` : ""}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Link
                      href={`${basePath}/${list.id}`}
                      className={`inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold transition ${
                        list.pending > 0
                          ? "bg-brand text-white hover:opacity-90"
                          : "border-line text-fg-muted border"
                      }`}
                    >
                      <Phone className="size-4" />
                      {list.pending > 0 ? "Ligar" : "Ver"}
                    </Link>
                    <button
                      type="button"
                      onClick={() => remove(list.id, list.name)}
                      disabled={pending}
                      aria-label={`Excluir a lista ${list.name}`}
                      className="text-fg-subtle rounded-lg p-2 transition hover:text-red-600 disabled:opacity-50"
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                </div>

                <div className="mt-3 flex items-center gap-3">
                  <div className="bg-surface-2 h-1.5 flex-1 overflow-hidden rounded-full">
                    <div
                      className="bg-brand h-full rounded-full"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <span className="text-fg-muted tnum text-xs whitespace-nowrap">
                    {list.done}/{list.total}
                    {list.skipped > 0 ? ` · ${list.skipped} pulados` : ""}
                  </span>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
