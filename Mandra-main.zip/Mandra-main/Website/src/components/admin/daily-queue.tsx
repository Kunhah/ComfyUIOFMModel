"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { PhoneCall, TriangleAlert } from "lucide-react";

/**
 * The one-click daily queue.
 *
 * Everything the operator needs to start calling is behind this button: no
 * filter to compose, no rows to tick, no name to invent. That matters more than
 * it sounds — a hundred calls a day only happens if starting costs nothing, and
 * every decision placed in front of the first dial is one that gets made badly
 * at 9am and skipped entirely by Thursday.
 *
 * The pool numbers are shown next to it rather than inside a report, because
 * "how many can I still call" is the question that decides whether today's job
 * is calling or prospecting, and it should not need a second screen.
 */
export function DailyQueueButton({
  basePath = "/admin/ligacoes",
  target,
  available,
}: {
  /** The tree this button lives in, so the queue it opens stays in that tree. */
  basePath?: string;
  target: number;
  /** Leads that pass every rule right now — the honest size of the pool. */
  available: number;
}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  function start() {
    setError(null);
    startTransition(async () => {
      const response = await fetch("/api/prospector/calls/daily", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ target }),
      });
      const body = (await response.json().catch(() => ({}))) as {
        error?: string;
        list?: { id: number };
      };
      if (!response.ok || !body.list) {
        setError(body.error ?? "Não foi possível montar a fila.");
        return;
      }
      // Straight into the dialer. Returning to a list index would add a click to
      // the start of every single day.
      router.push(`${basePath}/${body.list.id}`);
    });
  }

  return (
    <div className="flex flex-col items-start gap-1.5">
      <button
        type="button"
        onClick={start}
        disabled={pending || available === 0}
        className="bg-brand inline-flex items-center gap-2.5 rounded-xl px-5 py-3 text-base font-semibold text-white transition hover:opacity-90 disabled:opacity-40"
      >
        <PhoneCall className="size-5" />
        {pending
          ? "Montando…"
          : `Ligar para ${Math.min(target, available)} hoje`}
      </button>
      {error && (
        <p className="flex items-center gap-1.5 text-sm text-red-600">
          <TriangleAlert className="size-4" />
          {error}
        </p>
      )}
    </div>
  );
}

/**
 * Adds more leads to a list already being worked, rather than starting another.
 *
 * Offered at the end of a queue, where the alternative is building a second list
 * and scattering one campaign's progress across two sets of counters.
 */
// No basePath here, unlike DailyQueueButton: topping up refreshes the page it
// is already on rather than navigating, so there is no tree to stay inside.
export function TopUpButton({
  listId,
  amount,
}: {
  listId: number;
  amount: number;
}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [message, setMessage] = useState<string | null>(null);

  function topUp() {
    setMessage(null);
    startTransition(async () => {
      const response = await fetch("/api/prospector/calls/daily", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ topUp: listId, target: amount }),
      });
      const body = (await response.json().catch(() => ({}))) as {
        added?: number;
      };
      if (!body.added) {
        setMessage("Não há mais leads disponíveis para ligar agora.");
        return;
      }
      router.refresh();
    });
  }

  return (
    <div className="flex flex-col items-center gap-1.5">
      <button
        type="button"
        onClick={topUp}
        disabled={pending}
        className="bg-fg text-bg inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition hover:opacity-90 disabled:opacity-50"
      >
        <PhoneCall className="size-4" />
        {pending ? "Buscando…" : `Adicionar mais ${amount}`}
      </button>
      {message && <p className="text-fg-muted text-xs">{message}</p>}
    </div>
  );
}
