"use client";

import { useMemo, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  Check,
  Loader2,
  MessageSquarePlus,
  NotebookPen,
  Plus,
  RotateCcw,
  Trash2,
  Users,
} from "lucide-react";
import type { NicheIntent } from "@/lib/prospector/niches";
import type {
  OutreachTemplate,
  TemplateNote,
  TemplateStats,
} from "@/lib/prospector/templates-store";
import {
  DEFAULT_BODIES,
  INTENT_HINT,
  INTENT_LABEL,
  LANGUAGE_LABEL,
  MAX_BODY_LENGTH,
  PLACEHOLDERS,
  namesTheSender,
  TEMPLATE_LANGUAGES,
  render,
  slotOf,
  type TemplateLanguage,
  type TemplateSlot,
} from "@/lib/prospector/templates";

/**
 * The screen where each person writes their own pitch.
 *
 * Three levels, shown in the order they win: your message, the team's, and the
 * one that ships in the code. Editing the first is what an operator came here
 * to do and it is the box at the top; the other two are below it, stated
 * plainly, because "where did this text come from" is the question somebody
 * asks the first time they open this and never asks again.
 *
 * One slot at a time on purpose. There are six — two audiences times three
 * languages — and showing all of them is how a screen about *one* sentence
 * becomes a wall nobody edits.
 *
 * Next to the text sit the two things that stop a rewrite being a guess: what
 * it looks like filled in for a real lead, and what happened when it was sent.
 * A rewrite made without the preview sends "Oi ! Tudo bem?"; one made without
 * the numbers is somebody throwing away the message that was working because
 * the newest one feels better.
 */

const INTENTS: NicheIntent[] = ["cliente", "parceiro"];

/**
 * The lead the preview fills in. Invented, and obviously so — a real one would
 * put a stranger's business name on a screen about copywriting, and the point
 * of the preview is the shape of the sentence, not the data.
 */
const SAMPLE = {
  name: "Studio Bela Arte",
  contactName: "Marina",
  city: "Belo Horizonte",
  uf: "MG",
};

/** Whose copy a box is editing. The word the UI uses, so the two can't drift. */
type Scope = "minha" | "time";

export function OutreachTemplates({
  templates,
  isAdmin,
  viewerId,
  viewerName,
}: {
  /** This person's rows and the team's, already scoped by the server. */
  templates: OutreachTemplate[];
  /** Only the admin may write the team's copy; everyone writes their own. */
  isAdmin: boolean;
  viewerId: string;
  viewerName: string;
}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const [intent, setIntent] = useState<NicheIntent>("cliente");
  const [speaks, setSpeaks] = useState<TemplateLanguage>("pt");
  const slot: TemplateSlot = slotOf(intent, speaks);

  const inSlot = useMemo(
    () => templates.filter((template) => template.slot === slot),
    [templates, slot],
  );
  const mine = inSlot.filter((template) => template.ownerId !== null);
  const team = inSlot.filter((template) => template.ownerId === null);
  const myLive = mine.find((template) => template.active) ?? null;
  const teamLive = team.find((template) => template.active) ?? null;

  /**
   * What a lead would actually receive right now, resolved the same way
   * `activeTemplates()` resolves it on the server. Written once here so the
   * banner, the editor's starting text and the preview cannot disagree.
   */
  const inForce = myLive?.body ?? teamLive?.body ?? DEFAULT_BODIES[slot];
  const source: "minha" | "time" | "padrão" = myLive
    ? "minha"
    : teamLive
      ? "time"
      : "padrão";

  /** Every mutation goes through here so failures surface the same way. */
  function send(
    url: string,
    init: RequestInit,
    onSuccess: string,
    key: string,
  ) {
    setError(null);
    setNotice(null);
    setBusy(key);
    startTransition(async () => {
      try {
        const res = await fetch(url, {
          headers: { "content-type": "application/json" },
          ...init,
        });
        const payload = (await res.json().catch(() => ({}))) as {
          error?: string;
        };
        if (!res.ok) throw new Error(payload.error ?? `Erro ${res.status}`);
        setNotice(onSuccess);
        router.refresh();
      } catch (cause) {
        setError(cause instanceof Error ? cause.message : "Falha na operação.");
      } finally {
        setBusy(null);
      }
    });
  }

  /**
   * Saving a box.
   *
   * Two different writes behind one button, and nobody should have to know
   * which: a scope with no row of its own has nothing to update, so the first
   * save creates the row and activates it in the same request. That is what
   * makes "escreva e salve" the whole interaction for a first-time operator.
   */
  function save(scope: Scope, live: OutreachTemplate | null, body: string) {
    if (live) {
      send(
        `/api/prospector/templates/${live.id}`,
        { method: "PATCH", body: JSON.stringify({ body }) },
        scope === "minha"
          ? "Salvo. Seus próximos contatos já saem com esta mensagem."
          : "Mensagem do time salva. Vale para quem não escreveu a sua.",
        `save:${scope}`,
      );
      return;
    }
    send(
      "/api/prospector/templates",
      {
        method: "POST",
        body: JSON.stringify({
          escopo: scope,
          intent,
          speaks,
          name: scope === "minha" ? "Minha mensagem" : "Mensagem do time",
          body,
          activate: true,
        }),
      },
      scope === "minha"
        ? "Pronto — agora você tem a sua mensagem. Ela vale só para os seus contatos."
        : "Mensagem do time criada e ativada.",
      `save:${scope}`,
    );
  }

  /** Keeps the current message and parks the rewrite next to it, for comparison. */
  function saveAsVariant(scope: Scope, body: string) {
    const name = window.prompt(
      "Nome da variante — o que ela testa, em três palavras:",
      "Versão curta",
    );
    if (name === null) return;
    send(
      "/api/prospector/templates",
      {
        method: "POST",
        body: JSON.stringify({
          escopo: scope,
          intent,
          speaks,
          name,
          body,
          activate: false,
        }),
      },
      "Variante guardada. Ative quando quiser testá-la.",
      `variant:${scope}`,
    );
  }

  const backToTeam = () =>
    send(
      "/api/prospector/templates/release",
      { method: "POST", body: JSON.stringify({ intent, speaks }) },
      "Você voltou para a mensagem do time. A sua continua guardada aqui.",
      "release",
    );

  const activate = (template: OutreachTemplate) =>
    send(
      `/api/prospector/templates/${template.id}`,
      { method: "PATCH", body: JSON.stringify({ activate: true }) },
      `"${template.name}" é a mensagem que sai a partir de agora.`,
      `activate:${template.id}`,
    );

  function remove(template: OutreachTemplate) {
    if (
      !window.confirm(
        `Apagar "${template.name}"? As anotações sobre ela vão junto, e isso não pode ser desfeito.`,
      )
    ) {
      return;
    }
    send(
      `/api/prospector/templates/${template.id}`,
      { method: "DELETE" },
      "Variante apagada.",
      `delete:${template.id}`,
    );
  }

  const addNote = (template: OutreachTemplate, body: string) =>
    send(
      `/api/prospector/templates/${template.id}/notes`,
      { method: "POST", body: JSON.stringify({ body }) },
      "Anotação salva.",
      `note:${template.id}`,
    );

  const removeNote = (template: OutreachTemplate, note: TemplateNote) =>
    send(
      `/api/prospector/templates/${template.id}/notes`,
      { method: "DELETE", body: JSON.stringify({ noteId: note.id }) },
      "Anotação apagada.",
      `note:${note.id}`,
    );

  const noteProps = {
    viewerId,
    isAdmin,
    pending,
    busy,
    onAdd: addNote,
    onRemove: removeNote,
  };

  return (
    <>
      <div className="mt-6 flex flex-wrap items-center gap-2">
        {INTENTS.map((option) => (
          <button
            key={option}
            type="button"
            onClick={() => setIntent(option)}
            className={`rounded-xl border px-4 py-2 text-sm font-medium transition ${
              option === intent
                ? "border-brand bg-brand/10 text-brand"
                : "border-line bg-surface text-fg-muted hover:text-fg"
            }`}
          >
            {INTENT_LABEL[option]}
          </button>
        ))}
        <span className="text-fg-subtle mx-1 hidden text-xs sm:inline">·</span>
        {TEMPLATE_LANGUAGES.map((option) => (
          <button
            key={option}
            type="button"
            onClick={() => setSpeaks(option)}
            className={`rounded-xl border px-4 py-2 text-sm font-medium transition ${
              option === speaks
                ? "border-brand bg-brand/10 text-brand"
                : "border-line bg-surface text-fg-muted hover:text-fg"
            }`}
          >
            {LANGUAGE_LABEL[option]}
          </button>
        ))}
      </div>
      <p className="text-fg-muted mt-2 text-sm">{INTENT_HINT[intent]}</p>

      {error && (
        <p className="mt-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
          {error}
        </p>
      )}
      {notice && !error && (
        <p className="border-brand/30 bg-brand/10 text-brand mt-4 rounded-xl border px-4 py-3 text-sm font-medium">
          {notice}
        </p>
      )}

      {/* Said before the box, not after it: "which of the three am I actually
          sending" is the first question, and an editor that answers it only
          once you press something is an editor people distrust. */}
      <p className="text-fg-muted mt-4 text-sm">
        Agora seus contatos saem com{" "}
        <strong className="text-fg font-semibold">
          {source === "minha"
            ? "a sua mensagem"
            : source === "time"
              ? "a mensagem padrão do time"
              : "a mensagem que vem com a ferramenta"}
        </strong>
        {source !== "minha" && " — é só editar o campo abaixo para ter a sua."}
      </p>

      <MessageEditor
        // The draft lives inside the editor, so the key is what throws it away
        // at the two moments it must be thrown away: the audience or language
        // changed, and the save came back. Without the id and the timestamp in
        // here, switching to Espanhol would leave yesterday's Portuguese
        // rewrite sitting in a box now labelled Spanish.
        key={`minha:${slot}:${myLive?.id ?? "nova"}:${myLive?.updatedAt ?? ""}`}
        title="Sua mensagem"
        subtitle={
          myLive
            ? `Escrita por você · vale só nos seus contatos`
            : source === "time"
              ? "Você ainda não escreveu a sua — o texto abaixo é o do time. Salve para torná-lo seu."
              : "Você ainda não escreveu a sua — o texto abaixo é o que vem com a ferramenta. Salve para torná-lo seu."
        }
        live={myLive}
        initialBody={inForce}
        speaks={speaks}
        viewerName={viewerName}
        pending={pending}
        busy={busy}
        saveKey="save:minha"
        variantKey="variant:minha"
        saveLabel={myLive ? "Salvar" : "Salvar e usar a minha"}
        onSave={(body) => save("minha", myLive, body)}
        onSaveAsVariant={(body) => saveAsVariant("minha", body)}
        footer={
          myLive && (
            <button
              type="button"
              onClick={backToTeam}
              disabled={pending}
              className="border-line text-fg-muted hover:text-fg inline-flex items-center gap-2 rounded-lg border px-3.5 py-2 text-sm font-medium transition disabled:opacity-50"
            >
              {busy === "release" ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <RotateCcw className="size-4" />
              )}
              Voltar para a do time
            </button>
          )
        }
        notes={myLive && <Notes template={myLive} {...noteProps} />}
        stats={myLive?.stats}
      />

      <section className="border-line bg-surface mt-6 rounded-2xl border p-5">
        <div className="flex flex-wrap items-baseline justify-between gap-3">
          <h2 className="flex items-center gap-2 text-lg font-semibold">
            <Users className="text-fg-subtle size-4" />
            Mensagem padrão do time
          </h2>
          <p className="text-fg-subtle text-xs">
            {isAdmin
              ? "Vale para todo mundo que não escreveu a sua."
              : "Só o administrador muda esta. Ela é o ponto de partida da sua."}
          </p>
        </div>

        {isAdmin ? (
          <MessageEditor
            key={`time:${slot}:${teamLive?.id ?? "nova"}:${teamLive?.updatedAt ?? ""}`}
            bare
            live={teamLive}
            initialBody={teamLive?.body ?? DEFAULT_BODIES[slot]}
            speaks={speaks}
            viewerName={viewerName}
            pending={pending}
            busy={busy}
            saveKey="save:time"
            variantKey="variant:time"
            saveLabel={teamLive ? "Salvar para o time" : "Criar a do time"}
            warnAboutSender
            onSave={(body) => save("time", teamLive, body)}
            onSaveAsVariant={(body) => saveAsVariant("time", body)}
            notes={teamLive && <Notes template={teamLive} {...noteProps} />}
            stats={teamLive?.stats}
          />
        ) : (
          <>
            <div className="border-line bg-surface-2 mt-3 rounded-xl border px-4 py-3 text-sm leading-6 whitespace-pre-wrap">
              {teamLive?.body ?? DEFAULT_BODIES[slot]}
            </div>
            {teamLive && (
              <div className="mt-3">
                <Numbers stats={teamLive.stats} />
                <Notes template={teamLive} {...noteProps} />
              </div>
            )}
          </>
        )}
      </section>

      <Variants
        heading="Suas variantes"
        empty="Nenhuma. Reescreva a mensagem acima e use “Guardar como variante” para manter as duas e comparar."
        templates={mine.filter((template) => !template.active)}
        canDelete
        pending={pending}
        busy={busy}
        onActivate={activate}
        onDelete={remove}
        notesFor={(template) => <Notes template={template} {...noteProps} />}
      />

      {team.filter((template) => !template.active).length > 0 && (
        <Variants
          heading="Variantes do time"
          empty=""
          templates={team.filter((template) => !template.active)}
          canDelete={isAdmin}
          canActivate={isAdmin}
          pending={pending}
          busy={busy}
          onActivate={activate}
          onDelete={remove}
          notesFor={(template) => <Notes template={template} {...noteProps} />}
        />
      )}
    </>
  );
}

/**
 * One editable message: the text, the tokens, the preview and the two save
 * verbs.
 *
 * Its own component because the screen shows two of them — yours and the
 * team's — and the second one existing is exactly how the first would have
 * drifted: one box would grow a token list the other never learned about.
 *
 * The draft is keyed from outside via `key`, so switching audience or language
 * remounts it with the right text instead of leaving yesterday's rewrite in a
 * box now labelled Spanish.
 */
function MessageEditor({
  title,
  subtitle,
  bare,
  live,
  initialBody,
  speaks,
  viewerName,
  pending,
  busy,
  saveKey,
  variantKey,
  saveLabel,
  onSave,
  onSaveAsVariant,
  footer,
  notes,
  stats,
  warnAboutSender,
}: {
  title?: string;
  subtitle?: string;
  /** Skips the card chrome, for the box already inside one. */
  bare?: boolean;
  live: OutreachTemplate | null;
  initialBody: string;
  speaks: TemplateLanguage;
  viewerName: string;
  pending: boolean;
  busy: string | null;
  saveKey: string;
  variantKey: string;
  saveLabel: string;
  onSave: (body: string) => void;
  onSaveAsVariant: (body: string) => void;
  footer?: React.ReactNode;
  notes?: React.ReactNode;
  stats?: TemplateStats;
  /**
   * Only the team's box asks for this. Its text is also what the client portal
   * renders, and there is deliberately nobody to put in `[meu-nome]` there.
   */
  warnAboutSender?: boolean;
}) {
  const [body, setBody] = useState(initialBody);
  const [withContact, setWithContact] = useState(true);
  const box = useRef<HTMLTextAreaElement>(null);

  const dirty = body !== initialBody;

  /**
   * Drops a token where the cursor is, rather than at the end.
   *
   * The end is almost never where it goes — `[nome]` belongs in the greeting
   * that is already typed — and a button that appends is a button people press
   * once, then go back to typing the brackets by hand.
   */
  function insert(token: string) {
    const el = box.current;
    if (!el) {
      setBody((current) => `${current}${token}`);
      return;
    }
    const start = el.selectionStart ?? body.length;
    const end = el.selectionEnd ?? start;
    const next = body.slice(0, start) + token + body.slice(end);
    setBody(next);
    // After React has written the value back, or the caret jumps to the end
    // and the next token lands in the wrong sentence.
    requestAnimationFrame(() => {
      el.focus();
      el.setSelectionRange(start + token.length, start + token.length);
    });
  }

  const preview = render(
    body,
    {
      ...SAMPLE,
      contactName: withContact ? SAMPLE.contactName : null,
      senderName: viewerName,
    },
    speaks,
  );

  const inner = (
    <>
      {title && (
        <div className="flex flex-wrap items-baseline justify-between gap-3">
          <h2 className="text-lg font-semibold">{title}</h2>
          {subtitle && <p className="text-fg-subtle text-xs">{subtitle}</p>}
        </div>
      )}

      <div className="mt-4 grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        <div>
          {/* Above the box, where the cursor is about to be. A list of tokens
              under a preview is documentation; here it is a keyboard. */}
          <div className="mb-2 flex flex-wrap items-center gap-1.5">
            <span className="text-fg-subtle mr-1 text-xs">Inserir:</span>
            {PLACEHOLDERS.map((placeholder) => (
              <button
                key={placeholder.token}
                type="button"
                onClick={() => insert(placeholder.token)}
                title={`${placeholder.label} — ${placeholder.hint}`}
                className="border-line bg-surface-2 text-fg-muted hover:border-brand hover:text-fg rounded-lg border px-2 py-1 font-mono text-xs transition"
              >
                {placeholder.token}
              </button>
            ))}
          </div>

          <textarea
            ref={box}
            value={body}
            maxLength={MAX_BODY_LENGTH}
            onChange={(event) => setBody(event.target.value)}
            rows={12}
            spellCheck
            className="border-line bg-surface-2 focus:border-brand w-full resize-y rounded-xl border px-3.5 py-3 text-sm leading-6 outline-none"
          />

          <div className="mt-2 flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => onSave(body)}
              disabled={pending || !dirty}
              className="inline-flex items-center gap-2 rounded-lg bg-[#1d2228] px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-black disabled:opacity-50"
            >
              {busy === saveKey ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Check className="size-4" />
              )}
              {saveLabel}
            </button>
            <button
              type="button"
              onClick={() => onSaveAsVariant(body)}
              disabled={pending || !dirty}
              className="border-line text-fg-muted hover:text-fg inline-flex items-center gap-2 rounded-lg border px-4 py-2.5 text-sm font-medium transition disabled:opacity-50"
            >
              {busy === variantKey ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <MessageSquarePlus className="size-4" />
              )}
              Guardar como variante
            </button>
            {footer}
            <span className="text-fg-subtle text-xs">
              {body.length}/{MAX_BODY_LENGTH}
            </span>
          </div>

          {warnAboutSender && namesTheSender(body) && (
            <p className="border-warm/30 bg-warm/10 mt-2 rounded-lg border px-3 py-2 text-xs leading-5">
              Esta mensagem usa <code>[meu-nome]</code>, e ela também é a que o
              portal do cliente escreve — lá não existe remetente, e a frase
              chega sem o nome. Na sua mensagem o token é seguro; nesta, escreva
              “da Mandra” em vez de assinar.
            </p>
          )}

          {/* The distinction the two buttons make, said once. Without it the
              second reads as "salvar de outro jeito" and nobody ends up with
              two versions to compare. */}
          <p className="text-fg-subtle mt-2 text-xs leading-5">
            Salvar reescreve a mensagem atual — as anotações continuam presas a
            ela e passam a falar de um texto que mudou. Guardar como variante
            mantém a atual no ar e deixa a nova ao lado, para ativar e comparar.
          </p>
        </div>

        <div>
          <div className="flex items-center justify-between gap-3">
            <p className="text-fg-muted text-xs font-semibold tracking-[0.14em] uppercase">
              Como chega
            </p>
            <label className="text-fg-muted flex items-center gap-2 text-xs">
              <input
                type="checkbox"
                checked={withContact}
                onChange={(event) => setWithContact(event.target.checked)}
                className="accent-brand size-3.5"
              />
              lead com nome de contato salvo
            </label>
          </div>
          {/* Pre-wrap rather than paragraphs: the line breaks typed here are
              the ones WhatsApp will show, and a renderer that re-flows them
              hides exactly the mistake worth catching. */}
          <div className="border-line bg-surface-2 mt-2 min-h-[220px] rounded-xl border px-4 py-3 text-sm leading-6 whitespace-pre-wrap">
            {preview}
          </div>
          <p className="text-fg-subtle mt-2 text-xs leading-5">
            Exemplo fictício, com o seu nome em <code>[meu-nome]</code>. Sem
            contato salvo — que é a maioria dos leads — o <code>[nome]</code>{" "}
            some e a saudação se fecha sozinha.
          </p>

          <dl className="mt-3 space-y-1.5">
            {PLACEHOLDERS.map((placeholder) => (
              <div key={placeholder.token} className="flex gap-2 text-xs">
                <dt className="text-fg shrink-0 font-mono font-semibold">
                  {placeholder.token}
                </dt>
                <dd className="text-fg-subtle leading-5">
                  {placeholder.label} — {placeholder.hint}
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </div>

      {live && (
        <div className="border-line mt-5 border-t pt-4">
          {stats && <Numbers stats={stats} />}
          {notes}
        </div>
      )}
    </>
  );

  if (bare) return <div className="mt-1">{inner}</div>;
  return (
    <section className="border-line bg-surface mt-4 rounded-2xl border p-5">
      {inner}
    </section>
  );
}

/** The parked rewrites for one scope, each with its numbers and its notes. */
function Variants({
  heading,
  empty,
  templates,
  canDelete,
  canActivate = true,
  pending,
  busy,
  onActivate,
  onDelete,
  notesFor,
}: {
  heading: string;
  empty: string;
  templates: OutreachTemplate[];
  canDelete: boolean;
  canActivate?: boolean;
  pending: boolean;
  busy: string | null;
  onActivate: (template: OutreachTemplate) => void;
  onDelete: (template: OutreachTemplate) => void;
  notesFor: (template: OutreachTemplate) => React.ReactNode;
}) {
  return (
    <section className="mt-6">
      <h2 className="text-lg font-semibold">{heading}</h2>
      {templates.length === 0 ? (
        <p className="text-fg-muted mt-1 text-sm">{empty}</p>
      ) : (
        <p className="text-fg-muted mt-1 text-sm">
          Ative uma para que ela passe a ser a enviada. Os números contam só os
          contatos abertos enquanto cada uma estava ativa.
        </p>
      )}

      <div className="mt-4 space-y-4">
        {templates.map((template) => (
          <article
            key={template.id}
            className="border-line bg-surface rounded-2xl border p-5"
          >
            <div className="flex flex-wrap items-baseline justify-between gap-3">
              <div>
                <h3 className="font-semibold">{template.name}</h3>
                <p className="text-fg-subtle text-xs">
                  {template.authorName} · {stamp(template.createdAt)}
                </p>
              </div>
              <div className="flex items-center gap-2">
                {canActivate && (
                  <button
                    type="button"
                    onClick={() => onActivate(template)}
                    disabled={pending}
                    className="border-brand/40 text-brand hover:bg-brand/10 inline-flex items-center gap-2 rounded-lg border px-3.5 py-2 text-sm font-medium transition disabled:opacity-50"
                  >
                    {busy === `activate:${template.id}` ? (
                      <Loader2 className="size-4 animate-spin" />
                    ) : (
                      <Check className="size-4" />
                    )}
                    Ativar
                  </button>
                )}
                {canDelete && (
                  <button
                    type="button"
                    onClick={() => onDelete(template)}
                    disabled={pending}
                    title="Apagar variante"
                    aria-label={`Apagar ${template.name}`}
                    className="text-fg-subtle hover:text-fg rounded-lg p-2 transition disabled:opacity-50"
                  >
                    {busy === `delete:${template.id}` ? (
                      <Loader2 className="size-4 animate-spin" />
                    ) : (
                      <Trash2 className="size-4" />
                    )}
                  </button>
                )}
              </div>
            </div>

            <div className="border-line bg-surface-2 mt-3 rounded-xl border px-4 py-3 text-sm leading-6 whitespace-pre-wrap">
              {template.body}
            </div>

            <div className="mt-3">
              <Numbers stats={template.stats} />
            </div>
            {notesFor(template)}
          </article>
        ))}
      </div>
    </section>
  );
}

/**
 * Three counts and no percentage.
 *
 * A reply rate over eleven sends is a coin toss wearing a decimal point, and
 * this is exactly the screen where somebody would act on it. The counts say how
 * much evidence there is at the same time as what it says, which a rate cannot.
 */
function Numbers({ stats }: { stats: TemplateStats }) {
  const cells: [string, number][] = [
    ["enviada para", stats.leads],
    ["responderam", stats.replied],
    ["viraram cliente", stats.closed],
  ];
  return (
    <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
      {cells.map(([label, value]) => (
        <div key={label} className="flex items-baseline gap-1.5">
          <span className="tnum text-lg font-semibold">{value}</span>
          <span className="text-fg-subtle text-xs">
            {label === "enviada para"
              ? `negócios${stats.sends > stats.leads ? ` (${stats.sends} envios)` : ""}`
              : label}
          </span>
        </div>
      ))}
      {stats.leads === 0 && (
        <span className="text-fg-subtle text-xs">
          ainda não saiu para ninguém
        </span>
      )}
    </div>
  );
}

/** The log next to the numbers: what the person who sent it noticed. */
function Notes({
  template,
  viewerId,
  isAdmin,
  pending,
  busy,
  onAdd,
  onRemove,
}: {
  template: OutreachTemplate;
  viewerId: string;
  isAdmin: boolean;
  pending: boolean;
  busy: string | null;
  onAdd: (template: OutreachTemplate, body: string) => void;
  onRemove: (template: OutreachTemplate, note: TemplateNote) => void;
}) {
  const [draft, setDraft] = useState("");

  return (
    <div className="mt-4">
      <p className="text-fg-muted text-xs font-semibold tracking-[0.14em] uppercase">
        Anotações
      </p>

      {template.notes.length > 0 && (
        <ul className="mt-2 space-y-2">
          {template.notes.map((note) => (
            <li
              key={note.id}
              className="border-line bg-surface-2 flex items-start gap-3 rounded-xl border px-4 py-2.5"
            >
              <div className="min-w-0 flex-1">
                <p className="text-sm leading-6 whitespace-pre-wrap">
                  {note.body}
                </p>
                <p className="text-fg-subtle mt-1 text-xs">
                  {note.authorName} · {stamp(note.createdAt)}
                </p>
              </div>
              {(note.authorId === viewerId || isAdmin) && (
                <button
                  type="button"
                  onClick={() => onRemove(template, note)}
                  disabled={pending}
                  title="Apagar anotação"
                  aria-label="Apagar anotação"
                  className="text-fg-subtle hover:text-fg rounded-lg p-1.5 transition disabled:opacity-50"
                >
                  {busy === `note:${note.id}` ? (
                    <Loader2 className="size-3.5 animate-spin" />
                  ) : (
                    <Trash2 className="size-3.5" />
                  )}
                </button>
              )}
            </li>
          ))}
        </ul>
      )}

      <div className="mt-2 flex items-start gap-2">
        <NotebookPen className="text-fg-subtle mt-2.5 size-4 shrink-0" />
        <textarea
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          rows={2}
          placeholder="O que aconteceu com esta mensagem? Quem respondeu, o que perguntaram, o que você mudaria."
          className="border-line bg-surface-2 focus:border-brand min-w-0 flex-1 resize-y rounded-xl border px-3.5 py-2 text-sm leading-6 outline-none"
        />
        <button
          type="button"
          onClick={() => {
            onAdd(template, draft.trim());
            setDraft("");
          }}
          disabled={pending || draft.trim().length === 0}
          className="border-line text-fg-muted hover:text-fg mt-0.5 inline-flex items-center gap-2 rounded-lg border px-3.5 py-2 text-sm font-medium transition disabled:opacity-50"
        >
          {busy === `note:${template.id}` ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <Plus className="size-4" />
          )}
          Anotar
        </button>
      </div>
    </div>
  );
}

/** Short and local: these are read next to each other, never sorted by. */
function stamp(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "2-digit",
  });
}
