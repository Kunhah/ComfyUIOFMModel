"use client";

import { useCallback, useEffect, useState } from "react";
import { Sparkles, ThumbsDown, ThumbsUp, RefreshCw } from "lucide-react";
import type { Insight } from "@/lib/ai/skills/insight-lead";
import type { ObjectionBrief } from "@/lib/ai/skills/insight-objecao";

/**
 * The insight panel, read in the seconds before the number is pressed.
 *
 * Never generates on mount. It fetches what already exists and shows a button
 * otherwise — because generating on load would pay for an insight every time an
 * operator scrolls past a lead they end up skipping, and because an insight that
 * changes on every refresh reads as unserious even when both versions are good.
 * `roteiro-ligacao.md` §0 budgets thirty seconds here; one click is inside that.
 *
 * The observation/hypothesis split is rendered, not flattened. Everything under
 * "observado" carries the id of the fact it came from and is safe to say out
 * loud; everything under "achismo" is the model guessing, and an operator who
 * cannot tell the two apart will eventually state a guess as a fact to a
 * stranger. Making the distinction visible is the entire reason the skill emits
 * two lists.
 */

type Loaded = {
  insight: Insight;
  runId: number | null;
  geradoEm: string | null;
};

export function LeadInsight({
  leadId,
  niche,
}: {
  leadId: string;
  /** The niche slug, for the objection brief. Null is fine — the corpus then
   * covers every analysed meeting rather than one segment. */
  niche: string | null;
}) {
  const [loaded, setLoaded] = useState<Loaded | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [voted, setVoted] = useState<boolean | null>(null);

  // The cached read is cheap and silent: no spinner, no empty state flash. A
  // lead with no insight yet simply shows the button.
  //
  // Nothing is reset here when `leadId` changes, because the caller mounts this
  // with `key={item.id}` — a new lead is a new component, which is what actually
  // guarantees the previous lead's insight can never be on screen next to this
  // one's name. Clearing three pieces of state by hand does the same thing right
  // up until someone adds a fourth.
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const response = await fetch(
          `/api/ai/insight/lead?lead=${encodeURIComponent(leadId)}`,
        );
        if (!response.ok) return;
        const body = (await response.json()) as Partial<Loaded>;
        if (!cancelled && body.insight) {
          setLoaded({
            insight: body.insight,
            runId: body.runId ?? null,
            geradoEm: body.geradoEm ?? null,
          });
        }
      } catch {
        // A cache read that fails is not worth a message: the button below is
        // the same action the operator would take anyway.
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [leadId]);

  const generate = useCallback(async () => {
    setBusy(true);
    setError(null);
    try {
      const response = await fetch("/api/ai/insight/lead", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ lead: leadId }),
      });
      const body = (await response.json()) as Partial<Loaded> & {
        error?: string;
      };
      if (!response.ok || !body.insight) {
        setError(body.error ?? "Não deu para gerar agora.");
        return;
      }
      setLoaded({
        insight: body.insight,
        runId: body.runId ?? null,
        geradoEm: body.geradoEm ?? null,
      });
      setVoted(null);
    } catch {
      setError("Não deu para gerar agora.");
    } finally {
      setBusy(false);
    }
  }, [leadId]);

  const vote = useCallback(
    async (useful: boolean) => {
      if (!loaded?.runId) return;
      setVoted(useful);
      await fetch("/api/ai/util", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ runId: loaded.runId, useful }),
      }).catch(() => setVoted(null));
    },
    [loaded],
  );

  // The objection brief is per niche, not per lead, so it is fetched separately
  // and cached far longer. It is also the only part of this panel that can
  // legitimately be empty forever: a company with no analysed meetings has no
  // corpus, and saying so is better than an empty box that looks broken.
  const [objecoes, setObjecoes] = useState<ObjectionBrief | null>(null);
  const [objBusy, setObjBusy] = useState(false);
  const [objError, setObjError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const response = await fetch(
          `/api/ai/insight/objecao?niche=${encodeURIComponent(niche ?? "")}`,
        );
        if (!response.ok) return;
        const body = (await response.json()) as { brief?: ObjectionBrief };
        if (!cancelled && body.brief) setObjecoes(body.brief);
      } catch {
        // Same as the insight cache read: the button is the fallback.
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [niche]);

  const loadObjecoes = useCallback(async () => {
    setObjBusy(true);
    setObjError(null);
    try {
      const response = await fetch("/api/ai/insight/objecao", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ niche }),
      });
      const body = (await response.json()) as {
        brief?: ObjectionBrief;
        error?: string;
      };
      if (!response.ok || !body.brief) {
        setObjError(body.error ?? "Não deu para ler as objeções.");
        return;
      }
      setObjecoes(body.brief);
    } catch {
      setObjError("Não deu para ler as objeções.");
    } finally {
      setObjBusy(false);
    }
  }, [niche]);

  if (!loaded) {
    return (
      <div className="border-line mt-4 rounded-xl border border-dashed px-3.5 py-3">
        <button
          type="button"
          onClick={() => void generate()}
          disabled={busy}
          className="text-fg-muted hover:text-fg inline-flex items-center gap-2 text-sm disabled:opacity-60"
        >
          <Sparkles className="size-4" />
          {busy ? "Lendo a ficha…" : "Preparar a ligação"}
        </button>
        {error && <p className="mt-2 text-sm text-red-500">{error}</p>}
      </div>
    );
  }

  const { insight } = loaded;

  return (
    <div className="border-line bg-surface-2/40 mt-4 rounded-xl border px-3.5 py-3.5">
      <div className="flex items-start justify-between gap-3">
        <p className="text-sm font-medium">{insight.angulo}</p>
        <span className="border-line text-fg-muted tnum shrink-0 rounded-full border px-2.5 py-0.5 text-xs">
          encaixe {insight.encaixe.nota}
        </span>
      </div>
      {insight.encaixe.porque && (
        <p className="text-fg-subtle mt-1 text-xs">{insight.encaixe.porque}</p>
      )}

      {insight.abertura && (
        <p className="border-line mt-3 rounded-lg border-l-2 py-0.5 pl-3 text-sm italic">
          “{insight.abertura}”
        </p>
      )}

      {insight.observado.length > 0 && (
        <ul className="text-fg-muted mt-3 space-y-1 text-sm">
          {insight.observado.map((item) => (
            <li key={`${item.fonte}-${item.texto}`}>
              · {item.texto}{" "}
              <span className="text-fg-subtle text-xs">[{item.fonte}]</span>
            </li>
          ))}
        </ul>
      )}

      {insight.hipotese.length > 0 && (
        <div className="mt-3">
          {/* Labelled as a guess in the copy, not just by position. An operator
              skimming this at speed reads the words, not the layout. */}
          <p className="text-fg-subtle text-xs">Achismo, não confirmado:</p>
          <ul className="text-fg-subtle mt-1 space-y-1 text-sm">
            {insight.hipotese.map((item) => (
              <li key={item}>· {item}</li>
            ))}
          </ul>
        </div>
      )}

      {insight.perguntas.length > 0 && (
        <ul className="mt-3 space-y-1 text-sm">
          {insight.perguntas.map((item) => (
            <li key={item}>— {item}</li>
          ))}
        </ul>
      )}

      {insight.evitar.length > 0 && (
        <p className="text-fg-subtle mt-3 text-xs">
          Evitar: {insight.evitar.join(" · ")}
        </p>
      )}

      <div className="border-line mt-3.5 border-t pt-2.5">
        {objecoes ? (
          <div>
            <p className="text-fg-subtle text-xs">
              Objeções que costumam aparecer:
            </p>
            <ul className="mt-1.5 space-y-1.5 text-sm">
              {objecoes.provaveis.map((item) => (
                <li key={item.objecao}>
                  <span className="font-medium">“{item.objecao}”</span>
                  <span className="text-fg-subtle text-xs">
                    {" "}
                    · {item.frequencia}
                    {item.vistoEm > 0 ? ` · ${item.vistoEm} reunião(ões)` : ""}
                  </span>
                  <span className="text-fg-muted block">{item.resposta}</span>
                </li>
              ))}
            </ul>
            {objecoes.atencao && (
              <p className="text-fg-subtle mt-2 text-xs">{objecoes.atencao}</p>
            )}
          </div>
        ) : (
          <button
            type="button"
            onClick={() => void loadObjecoes()}
            disabled={objBusy}
            className="text-fg-subtle hover:text-fg text-xs disabled:opacity-60"
          >
            {objBusy ? "Lendo as reuniões…" : "Objeções deste nicho"}
          </button>
        )}
        {objError && (
          <p className="text-fg-subtle mt-1.5 text-xs">{objError}</p>
        )}
      </div>

      <div className="border-line mt-3 flex items-center gap-3 border-t pt-2.5">
        <button
          type="button"
          onClick={() => void generate()}
          disabled={busy}
          className="text-fg-subtle hover:text-fg inline-flex items-center gap-1.5 text-xs disabled:opacity-60"
        >
          <RefreshCw className={`size-3.5 ${busy ? "animate-spin" : ""}`} />
          Gerar de novo
        </button>
        {/* The cheapest evaluation we have, and the only one from the person
            whose call it changed. The zeroes become eval fixtures. */}
        <div className="text-fg-subtle ml-auto flex items-center gap-2">
          <button
            type="button"
            onClick={() => void vote(true)}
            className={`hover:text-fg ${voted === true ? "text-brand" : ""}`}
            aria-label="Serviu"
          >
            <ThumbsUp className="size-3.5" />
          </button>
          <button
            type="button"
            onClick={() => void vote(false)}
            className={`hover:text-fg ${voted === false ? "text-amber-500" : ""}`}
            aria-label="Não serviu"
          >
            <ThumbsDown className="size-3.5" />
          </button>
        </div>
      </div>
      {error && <p className="mt-2 text-sm text-red-500">{error}</p>}
    </div>
  );
}
