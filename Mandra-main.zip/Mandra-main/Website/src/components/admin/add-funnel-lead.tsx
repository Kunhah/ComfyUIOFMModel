"use client";

import { FormEvent, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Loader2, Plus, Search, X } from "lucide-react";
import type { FunnelCandidate } from "@/lib/prospector/funnel";

export function AddFunnelLead({
  nicheLabels,
}: {
  nicheLabels: Record<string, string>;
}) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<FunnelCandidate[]>([]);
  const [message, setMessage] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  function search(event: FormEvent) {
    event.preventDefault();
    setMessage(null);
    startTransition(async () => {
      const response = await fetch(
        `/api/prospector/funnel/candidates?q=${encodeURIComponent(query)}`,
      );
      if (!response.ok) {
        setMessage("Não foi possível buscar os leads.");
        return;
      }
      const body = (await response.json()) as { leads?: FunnelCandidate[] };
      const leads = body.leads ?? [];
      setResults(leads);
      if (leads.length === 0)
        setMessage("Nenhum lead fora do funil encontrado.");
    });
  }

  function add(lead: FunnelCandidate) {
    setMessage(null);
    startTransition(async () => {
      const response = await fetch("/api/prospector/history/details", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ id: lead.id, inFunnel: true }),
      });
      if (!response.ok) {
        setMessage(`Não foi possível adicionar ${lead.name}.`);
        return;
      }
      setResults((current) => current.filter((item) => item.id !== lead.id));
      setMessage(`${lead.name} foi adicionado ao funil.`);
      router.refresh();
    });
  }

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="bg-brand text-brand-fg inline-flex items-center gap-2 rounded-lg px-3.5 py-2 text-sm font-semibold"
      >
        <Plus className="size-4" />
        Adicionar lead
      </button>
    );
  }

  return (
    <div className="border-line bg-surface w-full max-w-xl rounded-xl border p-3 shadow-sm">
      <div className="flex items-center gap-2">
        <form onSubmit={search} className="flex flex-1 gap-2">
          <input
            autoFocus
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Buscar por nome ou endereço"
            minLength={2}
            className="border-line bg-surface-2 focus:border-brand min-w-0 flex-1 rounded-lg border px-3 py-2 text-sm outline-none"
          />
          <button
            type="submit"
            disabled={pending || query.trim().length < 2}
            className="border-line hover:border-line-strong inline-flex size-10 items-center justify-center rounded-lg border disabled:opacity-50"
          >
            {pending ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <Search className="size-4" />
            )}
            <span className="sr-only">Buscar</span>
          </button>
        </form>
        <button
          type="button"
          onClick={() => setOpen(false)}
          className="text-fg-muted hover:text-fg p-2"
        >
          <X className="size-4" />
          <span className="sr-only">Fechar</span>
        </button>
      </div>

      {message && <p className="text-fg-muted mt-2 text-xs">{message}</p>}

      {results.length > 0 && (
        <ul className="border-line mt-3 max-h-72 divide-y overflow-y-auto rounded-lg border">
          {results.map((lead) => (
            <li key={lead.id} className="flex items-center gap-3 px-3 py-2.5">
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-medium">
                  {lead.name}
                </span>
                <span className="text-fg-muted block truncate text-xs">
                  {[lead.city, lead.uf].filter(Boolean).join("/") || "—"}
                  {lead.niche
                    ? ` · ${nicheLabels[lead.niche] ?? lead.niche}`
                    : ""}
                </span>
              </span>
              <button
                type="button"
                disabled={pending}
                onClick={() => add(lead)}
                className="border-brand text-brand hover:bg-brand/5 rounded-lg border px-2.5 py-1.5 text-xs font-semibold disabled:opacity-50"
              >
                Adicionar
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
