"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  CalendarClock,
  Check,
  ChevronDown,
  Phone,
  PhoneOff,
  StickyNote,
  X,
} from "lucide-react";
import type { BoardCard, BoardColumn } from "@/lib/prospector/funnel";
import {
  CALL_OUTCOME_SHORT,
  FUNNEL_LABEL,
  FUNNEL_STAGES,
  OUTCOME_REACHED,
  type FunnelStage,
} from "@/lib/prospector/types";

/**
 * The pipeline as columns of cards, with the stage written by dropping one.
 *
 * Drag-and-drop is the *second* way to move a card, never the only one. It is
 * unreachable by keyboard and invisible to a screen reader, so every card also
 * carries an explicit stage menu — which is the control that actually has to
 * work, with dragging as the fast path on top of it.
 *
 * That menu is a button and a list of buttons rather than a `<select>`, which
 * this board did use and could not keep. A native select inside a `draggable`
 * ancestor is a control the browser half-owns: the pointer press that opens the
 * popup also starts a drag, and the release lands on whichever option sits under
 * the cursor — so *opening* the dropdown moved the lead, usually several stages
 * along. A stray wheel tick over a focused select does the same thing with no
 * popup at all. Both silently wrote a stage nobody chose, which on this screen
 * means a lead announced as "em negociação" that never was. Explicit buttons
 * have neither failure: nothing here changes the stage except a click on the
 * stage you clicked.
 *
 * Native HTML5 drag events rather than a library: seven columns of cards is the
 * case the browser API handles well, and this is a screen inside an internal
 * tool, not a general-purpose board.
 *
 * Writes go to `/api/prospector/history/details` — the same route, and therefore
 * the same validation, the same `setFunnelStage()` and the same audit row, as
 * the table's dropdown. The board deliberately owns no writer of its own.
 */

const STAGE_TONE: Record<FunnelStage, string> = {
  descoberta: "border-line bg-surface-2 text-fg-muted",
  contato: "border-amber-300 bg-amber-50 text-amber-800",
  qualificado: "border-sky-300 bg-sky-50 text-sky-800",
  proposta: "border-indigo-300 bg-indigo-50 text-indigo-800",
  negociacao: "border-violet-300 bg-violet-50 text-violet-800",
  fechado: "border-emerald-300 bg-emerald-50 text-emerald-800",
  perdido: "border-line bg-surface-2 text-fg-subtle",
};

/** The bar along the top of a column, so the stages read as a progression. */
const STAGE_BAR: Record<FunnelStage, string> = {
  descoberta: "bg-fg-subtle/30",
  contato: "bg-amber-400",
  qualificado: "bg-sky-400",
  proposta: "bg-indigo-400",
  negociacao: "bg-violet-400",
  fechado: "bg-emerald-500",
  perdido: "bg-fg-subtle/30",
};

const fmt = (value: number) => value.toLocaleString("pt-BR");

/** A YYYY-MM-DD as a short local date. Never `new Date(iso)` — that reads UTC. */
function shortDate(value: string): string {
  const [y, m, d] = value.slice(0, 10).split("-");
  return y && m && d ? `${d}/${m}` : value;
}

export function FunnelBoard({
  columns,
  limit,
  nicheLabels,
}: {
  columns: BoardColumn[];
  limit: number;
  /** slug → label, resolved on the server so the niche registry stays there. */
  nicheLabels: Record<string, string>;
}) {
  const router = useRouter();
  const [, startTransition] = useTransition();

  // Where each moved card now lives, keyed by id. The server data is re-read on
  // every successful write; this only covers the gap until it arrives.
  const [moved, setMoved] = useState<Record<string, FunnelStage>>({});
  const [failed, setFailed] = useState<string | null>(null);
  const [dragging, setDragging] = useState<string | null>(null);
  const [over, setOver] = useState<FunnelStage | null>(null);
  const [removed, setRemoved] = useState<ReadonlySet<string>>(new Set());
  // What the note now says, keyed by id, until the refresh brings it back from
  // the server. Same contract as `moved` and cleared by the same reset.
  const [notes, setNotes] = useState<Record<string, string | null>>({});
  const [seenColumns, setSeenColumns] = useState(columns);

  // A route refresh replaces the authoritative columns. Drop optimistic state
  // then, especially so a lead removed and subsequently re-added can reappear.
  if (seenColumns !== columns) {
    setSeenColumns(columns);
    setMoved({});
    setRemoved(new Set());
    setNotes({});
  }

  const stageOf = (card: BoardCard, column: FunnelStage): FunnelStage =>
    moved[card.id] ?? column;

  function move(card: BoardCard, from: FunnelStage, to: FunnelStage) {
    if (from === to) return;
    setFailed(null);
    setMoved((current) => ({ ...current, [card.id]: to }));

    startTransition(async () => {
      try {
        const res = await fetch("/api/prospector/history/details", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ id: card.id, stage: to }),
        });
        if (!res.ok) throw new Error(String(res.status));
        // The column counts and the stats above the board are both invalidated
        // by this write, so the whole route is re-read rather than patched.
        router.refresh();
      } catch {
        setMoved((current) => {
          const next = { ...current };
          delete next[card.id];
          return next;
        });
        setFailed(card.name);
      }
    });
  }

  /**
   * Writes the CRM note for one card.
   *
   * Through `/api/prospector/history/notes` — the route the CRM table's own
   * editor uses, so `setNotes` stays the single writer and the note gets the
   * same audit row wherever it was typed. The board owns no writer of its own,
   * exactly as it owns none for the stage.
   */
  function saveNote(card: BoardCard, text: string) {
    const value = text.trim().length > 0 ? text : null;
    const previous = notes[card.id] ?? card.notes;
    if (value === previous) return;
    setFailed(null);
    setNotes((current) => ({ ...current, [card.id]: value }));

    startTransition(async () => {
      try {
        const res = await fetch("/api/prospector/history/notes", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ id: card.id, notes: value }),
        });
        if (!res.ok) throw new Error(String(res.status));
        router.refresh();
      } catch {
        setNotes((current) => {
          const next = { ...current };
          delete next[card.id];
          return next;
        });
        setFailed(card.name);
      }
    });
  }

  function remove(card: BoardCard) {
    if (!confirm(`Remover “${card.name}” do funil?`)) return;
    setFailed(null);
    setRemoved((current) => new Set(current).add(card.id));

    startTransition(async () => {
      try {
        const res = await fetch("/api/prospector/history/details", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ id: card.id, inFunnel: false }),
        });
        if (!res.ok) throw new Error(String(res.status));
        router.refresh();
      } catch {
        setRemoved((current) => {
          const next = new Set(current);
          next.delete(card.id);
          return next;
        });
        setFailed(card.name);
      }
    });
  }

  // Cards are drawn from the column they are currently *shown* in, which is the
  // optimistic stage where one exists. Without this a dropped card would sit in
  // both columns until the refresh landed.
  const cardsFor = (column: BoardColumn): BoardCard[] => {
    const arrived = columns
      .flatMap((c) => c.cards.map((card) => ({ card, from: c.stage })))
      .filter(
        ({ card, from }) =>
          moved[card.id] === column.stage && from !== column.stage,
      )
      .map(({ card }) => card);
    const kept = column.cards.filter(
      (card) =>
        !removed.has(card.id) && stageOf(card, column.stage) === column.stage,
    );
    return [...arrived, ...kept].filter((card) => !removed.has(card.id));
  };

  return (
    <div>
      {failed && (
        <p
          role="alert"
          className="mb-3 rounded-xl border border-red-300 bg-red-50 px-4 py-2.5 text-sm text-red-800"
        >
          Não foi possível mover “{failed}”. A etapa continua como estava.
        </p>
      )}

      {/* One scroller for seven columns: below a very wide screen the board is
          meant to be pushed sideways, not reflowed into something that is no
          longer a funnel. */}
      <div className="-mx-1 flex gap-3 overflow-x-auto px-1 pb-2">
        {columns.map((column) => {
          const cards = cardsFor(column);
          const isOver = over === column.stage;
          return (
            <section
              key={column.stage}
              onDragOver={(event) => {
                // Without preventDefault the browser refuses the drop entirely.
                event.preventDefault();
                setOver(column.stage);
              }}
              onDragLeave={() =>
                setOver((s) => (s === column.stage ? null : s))
              }
              onDrop={(event) => {
                event.preventDefault();
                setOver(null);
                const id = event.dataTransfer.getData("text/plain");
                const found = columns
                  .flatMap((c) =>
                    c.cards.map((card) => ({ card, from: c.stage })),
                  )
                  .find(({ card }) => card.id === id);
                if (found) {
                  move(
                    found.card,
                    stageOf(found.card, found.from),
                    column.stage,
                  );
                }
                setDragging(null);
              }}
              className={`flex w-[260px] shrink-0 flex-col rounded-2xl border transition ${
                isOver
                  ? "border-brand bg-brand/5"
                  : "border-line bg-surface-2/40"
              }`}
            >
              <div
                aria-hidden
                className={`h-1 rounded-t-2xl ${STAGE_BAR[column.stage]}`}
              />
              <header className="px-3.5 pt-3 pb-2">
                <div className="flex items-baseline justify-between gap-2">
                  <h2 className="text-sm font-semibold">
                    {FUNNEL_LABEL[column.stage]}
                  </h2>
                  <span className="tnum text-fg-muted text-xs">
                    {fmt(column.total)}
                  </span>
                </div>
                {/* The cap is stated rather than hidden: a column showing 40 of
                    395.418 must not read as a stage holding 40 leads. */}
                {column.total > limit && (
                  <Link
                    href={`/admin?stage=${column.stage}&page=1`}
                    className="text-fg-subtle hover:text-fg mt-0.5 inline-block text-[11px] underline underline-offset-2"
                  >
                    mostrando {fmt(limit)} — ver todos
                  </Link>
                )}
              </header>

              <div className="flex flex-1 flex-col gap-2 px-2.5 pb-2.5">
                {cards.length === 0 && (
                  <p className="text-fg-subtle px-1 py-6 text-center text-xs">
                    Nada aqui.
                  </p>
                )}
                {cards.map((card) => (
                  <Card
                    key={card.id}
                    card={card}
                    stage={stageOf(card, column.stage)}
                    nicheLabel={
                      card.niche
                        ? (nicheLabels[card.niche] ?? card.niche)
                        : null
                    }
                    dragging={dragging === card.id}
                    onDragStart={(event) => {
                      event.dataTransfer.setData("text/plain", card.id);
                      event.dataTransfer.effectAllowed = "move";
                      setDragging(card.id);
                    }}
                    onDragEnd={() => setDragging(null)}
                    notes={notes[card.id] ?? card.notes}
                    onStage={(to) =>
                      move(card, stageOf(card, column.stage), to)
                    }
                    onNote={(text) => saveNote(card, text)}
                    onRemove={() => remove(card)}
                  />
                ))}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}

function Card({
  card,
  stage,
  nicheLabel,
  notes,
  dragging,
  onDragStart,
  onDragEnd,
  onStage,
  onNote,
  onRemove,
}: {
  card: BoardCard;
  stage: FunnelStage;
  nicheLabel: string | null;
  /** The note as currently shown — the optimistic value where there is one. */
  notes: string | null;
  dragging: boolean;
  onDragStart: (event: React.DragEvent) => void;
  onDragEnd: () => void;
  onStage: (stage: FunnelStage) => void;
  onNote: (text: string) => void;
  onRemove: () => void;
}) {
  const reached = card.lastOutcome ? OUTCOME_REACHED[card.lastOutcome] : null;
  const [menuOpen, setMenuOpen] = useState(false);
  const [editing, setEditing] = useState(false);

  return (
    <article
      // Not while a control on the card is open: a press inside the stage menu
      // must be a click on a stage, and a drag through a textarea selects text
      // rather than moving the card — neither can be allowed to start a drag.
      draggable={!menuOpen && !editing}
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      className={`border-line bg-surface cursor-grab rounded-xl border p-3 shadow-sm transition active:cursor-grabbing ${
        dragging ? "opacity-40" : ""
      }`}
    >
      <div className="flex items-start justify-between gap-2">
        <h3 className="text-[13px] leading-tight font-semibold">{card.name}</h3>
        <span className="flex shrink-0 items-center gap-1">
          <span className="tnum text-fg-subtle text-[11px]">{card.score}</span>
          <button
            type="button"
            onClick={onRemove}
            title={`Remover ${card.name} do funil`}
            className="text-fg-subtle rounded p-1 transition hover:bg-red-50 hover:text-red-700"
          >
            <X className="size-3.5" />
            <span className="sr-only">Remover do funil</span>
          </button>
        </span>
      </div>

      <p className="text-fg-muted mt-1 truncate text-[11px]">
        {[card.city, card.uf].filter(Boolean).join("/") || "—"}
        {nicheLabel ? ` · ${nicheLabel}` : ""}
      </p>

      {card.contactName && (
        <p className="text-fg-muted mt-0.5 truncate text-[11px]">
          {card.contactName}
        </p>
      )}

      {/* What the phone said about this lead. This is why the card is in the
          column it is in, so it belongs on the card rather than one click away. */}
      {card.lastOutcome && (
        <p
          className={`mt-2 flex items-center gap-1.5 text-[11px] ${
            reached ? "text-fg-muted" : "text-fg-subtle"
          }`}
        >
          {reached ? (
            <Phone className="size-3 shrink-0" />
          ) : (
            <PhoneOff className="size-3 shrink-0" />
          )}
          <span className="truncate">
            {CALL_OUTCOME_SHORT[card.lastOutcome]}
            {card.attempts > 1 ? ` · ${card.attempts} tentativas` : ""}
          </span>
        </p>
      )}

      {card.nextFollowUpAt && (
        <p
          className={`mt-1 flex items-center gap-1.5 text-[11px] ${
            card.followUpOverdue ? "font-medium text-red-700" : "text-fg-subtle"
          }`}
        >
          <CalendarClock className="size-3 shrink-0" />
          {card.followUpOverdue ? "atrasado " : "retorno "}
          {shortDate(card.nextFollowUpAt)}
        </p>
      )}

      <CardNote
        note={notes}
        name={card.name}
        editing={editing}
        onEditing={setEditing}
        onSave={onNote}
      />

      {/* The accessible path, and the one that works without a pointer. */}
      <div className="mt-2.5">
        <button
          type="button"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((open) => !open)}
          className={`focus:border-brand flex w-full items-center justify-between gap-1 rounded-lg border px-2 py-1 text-left text-[11px] font-medium outline-none ${STAGE_TONE[stage]}`}
        >
          <span className="truncate">{FUNNEL_LABEL[stage]}</span>
          <ChevronDown
            aria-hidden
            className={`size-3 shrink-0 transition ${menuOpen ? "rotate-180" : ""}`}
          />
          <span className="sr-only">Mudar a etapa de {card.name}</span>
        </button>

        {/* Expanded inline rather than floated over the board. The columns sit
            in a horizontal scroller, which clips an absolutely positioned popup
            at the edge of the viewport — the card growing for a moment is the
            cheaper trade, and it needs no portal to be reliable. */}
        {menuOpen && (
          <ul className="border-line mt-1 overflow-hidden rounded-lg border">
            {FUNNEL_STAGES.map((option) => {
              const current = option === stage;
              return (
                <li key={option}>
                  <button
                    type="button"
                    onClick={() => {
                      setMenuOpen(false);
                      if (!current) onStage(option);
                    }}
                    className={`flex w-full items-center gap-1.5 px-2 py-1.5 text-left text-[11px] transition ${
                      current
                        ? "bg-surface-2 font-semibold"
                        : "hover:bg-surface-2"
                    }`}
                  >
                    <Check
                      aria-hidden
                      className={`size-3 shrink-0 ${current ? "" : "opacity-0"}`}
                    />
                    <span className="truncate">{FUNNEL_LABEL[option]}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </article>
  );
}

/**
 * The note on one card.
 *
 * Collapsed to the text itself, or to a quiet "anotar" when there is none: a
 * board is scanned, and seven columns of open textareas is not a pipeline. The
 * note is what a card is actually missing when you come back to it — "ligou,
 * pediu para chamar em janeiro" is the reason the lead is where it is, and
 * until now reading it meant leaving the board for the CRM table.
 *
 * Saves on blur, like the table's `NoteEditor`, and for the same reasons: a note
 * is written in one sitting, a request per keystroke could not be rolled back
 * coherently, and Escape has to mean "forget it". ⌘/Ctrl+Enter commits, because
 * plain Enter belongs to the note.
 *
 * `onEditing` tells the card to stop being draggable while this is open —
 * dragging through a textarea should select text, not move the lead.
 */
function CardNote({
  note,
  name,
  editing,
  onEditing,
  onSave,
}: {
  note: string | null;
  name: string;
  editing: boolean;
  onEditing: (editing: boolean) => void;
  onSave: (text: string) => void;
}) {
  const [text, setText] = useState(note ?? "");

  // The server value wins whenever it changes under us — a refresh after a save,
  // or somebody else's edit arriving — but never while it is being typed into.
  const [seen, setSeen] = useState(note);
  if (seen !== note) {
    setSeen(note);
    if (!editing) setText(note ?? "");
  }

  if (!editing) {
    return (
      <button
        type="button"
        onClick={() => {
          setText(note ?? "");
          onEditing(true);
        }}
        className={`mt-2 flex w-full items-start gap-1.5 rounded-lg px-1.5 py-1 text-left text-[11px] transition ${
          note
            ? "text-fg-muted hover:bg-surface-2"
            : "text-fg-subtle hover:bg-surface-2 hover:text-fg-muted"
        }`}
      >
        <StickyNote className="mt-px size-3 shrink-0" />
        {note ? (
          // Two lines, then it is cut. The whole note is one click away and the
          // card has to stay a card.
          <span className="line-clamp-2 min-w-0 flex-1">{note}</span>
        ) : (
          <span className="flex-1">anotar</span>
        )}
        <span className="sr-only">
          {note ? `Editar a anotação de ${name}` : `Anotar sobre ${name}`}
        </span>
      </button>
    );
  }

  const commit = () => {
    onEditing(false);
    onSave(text);
  };

  return (
    <div className="mt-2">
      <label className="block">
        <span className="sr-only">Anotação sobre {name}</span>
        <textarea
          autoFocus
          value={text}
          rows={3}
          placeholder="O que foi conversado, o que tentar na próxima…"
          onChange={(event) => setText(event.target.value)}
          onBlur={commit}
          onKeyDown={(event) => {
            if (event.key === "Escape") {
              setText(note ?? "");
              onEditing(false);
            }
            if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
              event.currentTarget.blur();
            }
          }}
          className="border-line bg-surface focus:border-brand w-full resize-y rounded-lg border px-2 py-1.5 text-[11px] outline-none"
        />
      </label>
      <p className="text-fg-subtle mt-1 text-[10px]">
        Salva ao sair do campo · Esc desfaz
      </p>
    </div>
  );
}
