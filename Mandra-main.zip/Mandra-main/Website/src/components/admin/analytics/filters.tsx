import { Chip } from "./ui";
import { measuredPages } from "@/lib/analytics/pages";
import { PERIODS, type ParsedScope } from "@/lib/analytics/scope";

/**
 * The filter bar every page-analytics screen carries.
 *
 * Shared rather than repeated so the four screens cannot disagree about what
 * "30 dias" or "só tráfego pago" selects — and so that switching tabs keeps
 * the filters, which is the difference between a dashboard you investigate
 * with and one you re-configure on every click.
 *
 * `recorded` dims the pages that have no data instead of hiding them: a
 * landing page that is live and has never been opened is itself a finding,
 * and a picker that quietly omits it hides exactly that.
 */
export function Filters({
  path,
  scope,
  recorded,
  showPages = true,
}: {
  /** The screen this bar belongs to, so a chip keeps you on it. */
  path: string;
  scope: ParsedScope;
  recorded: Set<string>;
  showPages?: boolean;
}) {
  const { href, days, page, template, paidOnly } = scope;

  return (
    <div className="mt-6 flex flex-wrap items-center gap-2">
      {PERIODS.map((period) => (
        <Chip
          key={period.days}
          href={href(path, { dias: String(period.days) })}
          active={period.days === days}
        >
          {period.label}
        </Chip>
      ))}

      <span className="bg-line mx-1 h-6 w-px" />

      <Chip
        href={href(path, { pagina: "", tipo: "" })}
        active={!page && !template}
      >
        Tudo
      </Chip>
      <Chip
        href={href(path, { tipo: "site", pagina: "" })}
        active={!page && template === "site"}
      >
        Site
      </Chip>
      <Chip
        href={href(path, { tipo: "ads", pagina: "" })}
        active={!page && template === "ads"}
      >
        Landing pages
      </Chip>

      {showPages && (
        <>
          <span className="bg-line mx-1 h-6 w-px" />
          {measuredPages.map((entry) => (
            <Chip
              key={entry.slug}
              href={href(path, { pagina: entry.slug })}
              active={page === entry.slug}
              muted={!recorded.has(entry.slug)}
            >
              {entry.label}
            </Chip>
          ))}
        </>
      )}

      <span className="bg-line mx-1 h-6 w-px" />
      <Chip href={href(path, { pago: paidOnly ? "" : "1" })} active={paidOnly}>
        Só tráfego pago
      </Chip>
    </div>
  );
}
