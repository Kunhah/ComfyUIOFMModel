import Link from "next/link";
import { fmt } from "@/lib/admin/format";

/**
 * The shared furniture of the analytics screens.
 *
 * It lives in one file because the six screens under `/admin/analytics` have
 * to be readable *against each other*: a tile that means one thing on the
 * overview and a slightly different thing on the acquisition screen is how a
 * dashboard starts being argued with instead of used. Every screen therefore
 * draws its counters, bars and tables from here.
 *
 * Two reading rules are built into these components rather than left to each
 * page to remember:
 *
 * - **A rate is always shown next to the count it came from.** A percentage
 *   alone invites a decision; a percentage over eleven sessions should not.
 * - **Anything below `CONFIDENT_AT` sessions is visibly de-emphasised**, so a
 *   row describing four people cannot be read at the same weight as one
 *   describing four hundred.
 */

/** Below this a percentage is a story about a handful of people. */
export const CONFIDENT_AT = 30;

export const pct = (value: number) => `${value.toFixed(1).replace(".", ",")}%`;

export function seconds(ms: number | null | undefined): string {
  if (ms === null || ms === undefined || ms <= 0) return "—";
  const total = Math.round(ms / 1000);
  if (total < 60) return `${total}s`;
  return `${Math.floor(total / 60)}min ${String(total % 60).padStart(2, "0")}s`;
}

/** Sub-second matters for "was the hero read or scrolled past". */
export function shortTime(ms: number | null | undefined): string {
  if (ms === null || ms === undefined || ms <= 0) return "—";
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(1).replace(".", ",")}s`;
}

export function Chip({
  href,
  active,
  muted,
  children,
}: {
  href: string;
  active: boolean;
  muted?: boolean;
  children: React.ReactNode;
}) {
  return (
    <Link
      href={href}
      className={`rounded-full border px-3 py-1.5 text-xs font-medium transition ${
        active
          ? "border-brand bg-brand text-brand-fg"
          : muted
            ? "border-line text-fg-subtle hover:text-fg-muted"
            : "border-line text-fg-muted hover:text-fg"
      }`}
    >
      {children}
    </Link>
  );
}

export function Tile({
  label,
  value,
  note,
  highlight,
  alarm,
}: {
  label: string;
  value: string;
  note?: string;
  highlight?: boolean;
  /** For a counter whose *existence* is the problem, like a dead click. */
  alarm?: boolean;
}) {
  return (
    <div
      className={`rounded-xl border px-4 py-3.5 ${
        alarm
          ? "border-amber-500/40 bg-amber-500/5"
          : highlight
            ? "border-brand/40 bg-brand/5"
            : "border-line bg-surface-raised"
      }`}
    >
      <p className="text-fg-subtle text-xs">{label}</p>
      <p className="mt-1 text-2xl font-semibold tabular-nums">{value}</p>
      {note && <p className="text-fg-muted mt-0.5 text-xs">{note}</p>}
    </div>
  );
}

export function Panel({
  title,
  hint,
  children,
}: {
  title: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="border-line bg-surface-raised mt-6 rounded-2xl border p-5">
      <h2 className="text-base font-semibold">{title}</h2>
      {hint && <p className="text-fg-muted mt-1 mb-4 text-xs">{hint}</p>}
      <div className={hint ? "" : "mt-4"}>{children}</div>
    </section>
  );
}

export function Empty({ children }: { children: React.ReactNode }) {
  return <p className="text-fg-muted text-sm">{children}</p>;
}

export type BarRow = {
  label: string;
  value: number;
  /** Drawn to the right of the count, e.g. a share or a delta. */
  note?: string;
  /** 0–100. Defaults to the value as a share of the largest row. */
  fill?: number;
  /** Draws the bar in the warning tone — for a row that is bad news. */
  warn?: boolean;
  /**
   * Suppress the raw count, leaving only the note.
   *
   * For a bar whose value is a unit the reader does not think in: a dwell of
   * 5,584 milliseconds is noise printed beside the "6s" that says the same
   * thing. The bar still scales by the raw value — that is what makes the
   * lengths comparable — it is only the number that goes.
   */
  hideValue?: boolean;
};

/**
 * A horizontal bar list.
 *
 * Deliberately not a charting library. Every distribution on these screens is
 * a short list of named things compared by one number, which is a layout
 * problem rather than a plotting one — and a dependency that ships a canvas to
 * draw eight rectangles would be the heaviest thing in the admin bundle.
 */
export function Bars({ rows }: { rows: BarRow[] }) {
  if (rows.length === 0) return <Empty>Sem dados no período.</Empty>;
  const max = Math.max(...rows.map((row) => row.value), 1);

  return (
    <ul className="space-y-2">
      {rows.map((row) => (
        <li key={row.label}>
          <div className="mb-1 flex items-baseline justify-between gap-4">
            <span className="truncate text-sm">{row.label}</span>
            <span className="text-fg-muted shrink-0 text-xs tabular-nums">
              {!row.hideValue && fmt(row.value)}
              {row.note && (
                <span className={row.hideValue ? "" : "ml-2"}>{row.note}</span>
              )}
            </span>
          </div>
          <div className="bg-surface-2 h-2 w-full overflow-hidden rounded-full">
            <div
              className={`h-full rounded-full ${row.warn ? "bg-amber-500" : "bg-brand"}`}
              style={{ width: `${row.fill ?? (row.value / max) * 100}%` }}
            />
          </div>
        </li>
      ))}
    </ul>
  );
}

export type Column = {
  head: string;
  /** Right-aligned and tabular. Everything that is a number should be. */
  numeric?: boolean;
};

export function DataTable({
  columns,
  rows,
}: {
  columns: Column[];
  /** One array of cells per row, already formatted. `key` keeps React happy. */
  rows: { key: string; cells: React.ReactNode[]; dim?: boolean }[];
}) {
  if (rows.length === 0) return <Empty>Sem dados no período.</Empty>;

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="text-fg-subtle text-xs">
          <tr className="border-line border-b">
            {columns.map((column) => (
              <th
                key={column.head}
                className={`py-2 font-medium ${column.numeric ? "text-right" : "text-left"}`}
              >
                {column.head}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.key} className="border-line border-b last:border-0">
              {row.cells.map((cell, index) => (
                <td
                  key={columns[index]?.head ?? index}
                  className={`py-2 ${
                    columns[index]?.numeric
                      ? "text-right tabular-nums"
                      : "max-w-[20rem] truncate"
                  } ${row.dim && index === row.cells.length - 1 ? "text-fg-subtle" : ""}`}
                >
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/**
 * The trend, as columns.
 *
 * The block the dashboard was missing entirely, and the one that separates
 * measuring from improving: every other number on these screens describes a
 * period as a single figure, which can say the page converts at 6% and can
 * never say whether last Tuesday's rewrite is the reason. A rate with no
 * series behind it can only be compared against a memory.
 *
 * Contacts are drawn over sessions in the same column rather than beside them,
 * because the question is always the ratio — two bars side by side invite
 * reading the heights against each other, which for these two quantities is
 * meaningless.
 */
export function Trend({
  rows,
  label = "sessões",
}: {
  rows: { day: string; sessions: number; converted: number }[];
  label?: string;
}) {
  if (rows.length === 0) return <Empty>Sem dados no período.</Empty>;

  const max = Math.max(...rows.map((row) => row.sessions), 1);
  const total = rows.reduce((sum, row) => sum + row.sessions, 0);
  const contacts = rows.reduce((sum, row) => sum + row.converted, 0);

  return (
    <div>
      <div className="flex h-36 items-end gap-[3px]">
        {rows.map((row) => {
          const height = (row.sessions / max) * 100;
          const share = row.sessions ? (row.converted / row.sessions) * 100 : 0;
          return (
            <div
              key={row.day}
              className="group relative flex-1"
              style={{ height: "100%" }}
            >
              <div className="absolute inset-x-0 bottom-0 flex flex-col justify-end">
                <div
                  className="bg-surface-2 relative w-full overflow-hidden rounded-t-[2px]"
                  style={{ height: `${Math.max(height, 1.5)}%` }}
                >
                  <div
                    className="bg-brand absolute inset-x-0 bottom-0"
                    style={{ height: `${share}%` }}
                  />
                </div>
              </div>
              {/* Native title rather than a tooltip component: this is an
                  internal screen and a hover label is not worth a listener on
                  ninety nodes. */}
              <span
                className="absolute inset-0"
                title={`${row.day}: ${fmt(row.sessions)} ${label}, ${fmt(row.converted)} contatos`}
              />
            </div>
          );
        })}
      </div>
      <div className="text-fg-subtle mt-2 flex justify-between text-xs">
        <span>{rows[0]?.day}</span>
        <span className="text-fg-muted">
          {fmt(total)} {label} · {fmt(contacts)} contatos
          <span className="bg-brand ml-3 inline-block size-2 rounded-[1px] align-middle" />
          <span className="ml-1.5">parcela que contatou</span>
        </span>
        <span>{rows[rows.length - 1]?.day}</span>
      </div>
    </div>
  );
}

/**
 * The failure that must never be quiet.
 *
 * A collector that cannot open its database swallows every beacon and leaves
 * a screen of confident zeroes, which is indistinguishable from "no traffic
 * yet" — the worst class of bug this codebase knows how to produce. So every
 * analytics screen asks first, and says which path it looked at.
 */
export function Broken({ path, reason }: { path: string; reason?: string }) {
  return (
    <div className="border-brand/40 bg-brand/5 mt-8 rounded-2xl border p-6">
      <h2 className="text-base font-semibold">
        O banco de analytics não pode ser escrito
      </h2>
      <p className="text-fg-muted mt-2 max-w-[70ch] text-sm">
        Nada está sendo registrado, e uma tela zerada aqui seria indistinguível
        de &quot;ainda não há tráfego&quot;. O caminho que este processo tentou
        abrir foi <code className="text-fg">{path}</code>.
      </p>
      <p className="text-fg-muted mt-3 max-w-[70ch] text-sm">
        O site, o coletor e este painel são o mesmo contêiner, com{" "}
        <code className="text-fg">data/</code> num volume. Se esta mensagem
        aparece, o volume não está montado onde o processo espera. Os detalhes
        estão em <code className="text-fg">docs/analytics.md</code>.
      </p>
      {reason && (
        <p className="text-fg-subtle mt-3 font-mono text-xs">{reason}</p>
      )}
    </div>
  );
}

export function NoSessions() {
  return (
    <div className="border-line bg-surface-raised mt-8 rounded-2xl border p-6">
      <h2 className="text-base font-semibold">Ainda não há sessões</h2>
      <p className="text-fg-muted mt-2 max-w-[70ch] text-sm">
        As páginas começam a registrar assim que alguém as abre em produção. Se
        já houver tráfego e esta tela continuar vazia, o mais provável é que o
        volume montado em <code className="text-fg">data/</code> não seja o
        mesmo do contêiner que está servindo — o arquivo é{" "}
        <code className="text-fg">data/analytics.db</code>.
      </p>
    </div>
  );
}

/** The warning that a percentage below it is describing a handful of people. */
export function ThinSample({ sessions }: { sessions: number }) {
  if (sessions >= CONFIDENT_AT) return null;
  return (
    <p className="border-line bg-surface-raised text-fg-muted mt-4 rounded-xl border px-4 py-3 text-sm">
      Menos de {CONFIDENT_AT} sessões no período. As porcentagens abaixo ainda
      descrevem um punhado de pessoas — use-as para detectar algo quebrado, não
      para decidir orçamento.
    </p>
  );
}
