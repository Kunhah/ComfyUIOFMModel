"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Bot, Loader2, Send, TriangleAlert, User } from "lucide-react";

/**
 * One conversation: what was said, and the two things an operator does about it.
 *
 * Sending as a person deliberately turns the assistant off on this thread — the
 * server does it, and the switch below reflects it. A human and a model both
 * answering is the worst thing this feature could do in front of a customer, so
 * taking over must not be something you can forget to do.
 */

export type ThreadMessage = {
  id: number;
  direction: "in" | "out";
  origin: "agent" | "job" | "operator" | "client";
  body: string;
  status: "ok" | "failed";
  error: string | null;
  at: string;
};

const ORIGIN_LABEL: Record<ThreadMessage["origin"], string> = {
  agent: "assistente",
  job: "programada",
  operator: "você",
  client: "cliente",
};

export function WhatsappThread({
  conversationId,
  autoReply,
  messages,
}: {
  conversationId: string;
  autoReply: boolean;
  messages: ThreadMessage[];
}) {
  const router = useRouter();
  const [, startTransition] = useTransition();
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function send() {
    const body = text.trim();
    if (!body || busy) return;
    setError(null);
    setBusy(true);
    startTransition(async () => {
      try {
        const res = await fetch("/api/admin/whatsapp/send", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ conversationId, text: body }),
        });
        const payload = (await res.json()) as { error?: string };
        if (!res.ok) setError(payload.error ?? "Não foi possível enviar.");
        else {
          setText("");
          router.refresh();
        }
      } catch {
        setError("Falha de rede ao enviar.");
      } finally {
        setBusy(false);
      }
    });
  }

  function toggleAuto(next: boolean) {
    setError(null);
    startTransition(async () => {
      try {
        const res = await fetch("/api/admin/whatsapp/atendimento", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ conversationId, auto: next }),
        });
        if (!res.ok) {
          const payload = (await res.json()) as { error?: string };
          setError(payload.error ?? "Não foi possível mudar o atendimento.");
        } else router.refresh();
      } catch {
        setError("Falha de rede.");
      }
    });
  }

  return (
    <div className="border-line bg-surface mt-6 overflow-hidden rounded-2xl border">
      <div className="border-line flex flex-wrap items-center justify-between gap-3 border-b px-5 py-3">
        <p className="flex items-center gap-2 text-sm">
          {autoReply ? (
            <>
              <Bot className="text-brand size-4" />O assistente está respondendo
            </>
          ) : (
            <>
              <User className="size-4" />
              Atendimento humano — o assistente não responde
            </>
          )}
        </p>
        <button
          type="button"
          onClick={() => toggleAuto(!autoReply)}
          className="border-line hover:bg-surface-raised rounded-xl border px-3 py-1.5 text-sm font-medium transition"
        >
          {autoReply ? "Assumir conversa" : "Devolver ao assistente"}
        </button>
      </div>

      <ol className="flex max-h-[520px] flex-col gap-3 overflow-y-auto px-5 py-5">
        {messages.length === 0 && (
          <li className="text-fg-muted text-sm">Nenhuma mensagem ainda.</li>
        )}
        {messages.map((message) => (
          <li
            key={message.id}
            className={`flex ${message.direction === "in" ? "justify-start" : "justify-end"}`}
          >
            <div
              className={`max-w-[80%] rounded-2xl px-4 py-2.5 ${
                message.direction === "in"
                  ? "bg-surface-raised"
                  : "bg-brand/10 border-brand/20 border"
              }`}
            >
              <p className="text-sm whitespace-pre-wrap">{message.body}</p>
              <p className="text-fg-subtle mt-1 text-[11px]">
                {ORIGIN_LABEL[message.origin]} · {message.at}
              </p>
              {/* A message that failed is shown in place, struck through in
                  meaning if not in style: the operator has to be able to see
                  what the client did *not* receive. */}
              {message.status === "failed" && (
                <p className="text-fg-subtle mt-1 flex items-start gap-1.5 text-[11px]">
                  <TriangleAlert className="mt-px size-3 shrink-0" />
                  não entregue{message.error ? ` — ${message.error}` : ""}
                </p>
              )}
            </div>
          </li>
        ))}
      </ol>

      <div className="border-line border-t p-3">
        {error && <p className="px-2 pb-2 text-sm">{error}</p>}
        <div className="flex items-end gap-2">
          <textarea
            value={text}
            onChange={(event) => setText(event.target.value)}
            onKeyDown={(event) => {
              // Enter sends, Shift+Enter breaks the line — the WhatsApp
              // convention, and the one the operator's hands already know.
              if (event.key === "Enter" && !event.shiftKey) {
                event.preventDefault();
                send();
              }
            }}
            rows={2}
            placeholder="Escreva… (o assistente para de responder esta conversa)"
            className="border-line bg-surface-raised focus:border-brand min-h-[44px] flex-1 resize-y rounded-xl border px-3.5 py-2.5 text-sm outline-none"
          />
          <button
            type="button"
            onClick={send}
            disabled={busy || text.trim().length === 0}
            className="bg-brand text-brand-fg flex size-11 shrink-0 items-center justify-center rounded-xl transition disabled:opacity-50"
            aria-label="Enviar"
          >
            {busy ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <Send className="size-4" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
