"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  BarChart3,
  KeyRound,
  Loader2,
  LogOut,
  Plus,
  RotateCcw,
  ShieldBan,
  Trash2,
} from "lucide-react";
import {
  DEFAULT_PERMISSIONS,
  PERMISSIONS,
  PERMISSION_HINT,
  PERMISSION_LABEL,
  type Permission,
} from "@/lib/auth/session";

/**
 * Granting and revoking access, and deciding what an access is worth.
 *
 * Not optimistic, unlike the lead table: creating an account can fail for
 * reasons the browser can't predict (the name is taken, the password is too
 * short) and the server's message is the useful one. Every action waits, and
 * says what happened.
 */

export type ManagedUser = {
  id: string;
  username: string;
  displayName: string;
  active: boolean;
  permissions: Permission[];
  createdAt: string;
  createdBy: string | null;
  lastLoginAt: string | null;
  /**
   * Whether a session is probably still open, computed on the server from the
   * last login and the account's session cutoff. "Probably" is the honest word:
   * the cookie is stateless, so nothing here can see a browser that was closed.
   */
  signedIn: boolean;
};

export function UserManager({ users }: { users: ManagedUser[] }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  /** Every mutation goes through here so failures surface the same way. */
  function send(
    url: string,
    init: RequestInit,
    onSuccess: string,
    id?: string,
  ) {
    setError(null);
    setNotice(null);
    setBusy(id ?? "form");

    startTransition(async () => {
      try {
        const res = await fetch(url, {
          headers: { "content-type": "application/json" },
          ...init,
        });
        const payload = (await res.json().catch(() => ({}))) as {
          error?: string;
        };
        if (!res.ok) throw new Error(payload.error ?? `Erro ${res.status}`);
        setNotice(onSuccess);
        router.refresh();
      } catch (cause) {
        setError(cause instanceof Error ? cause.message : "Falha na operação.");
      } finally {
        setBusy(null);
      }
    });
  }

  function create(form: FormData) {
    const password = String(form.get("password") ?? "");
    send(
      "/api/admin/users",
      {
        method: "POST",
        body: JSON.stringify({
          username: form.get("username"),
          displayName: form.get("displayName"),
          password,
        }),
      },
      "Acesso criado. Passe o usuário e a senha para a pessoa.",
    );
  }

  const toggle = (user: ManagedUser) =>
    send(
      `/api/admin/users/${user.id}`,
      { method: "PATCH", body: JSON.stringify({ active: !user.active }) },
      user.active
        ? `Acesso de ${user.username} revogado. As sessões abertas caíram.`
        : `Acesso de ${user.username} reativado.`,
      user.id,
    );

  /** Sends the whole grant, so two open admin tabs can't half-undo each other. */
  function togglePermission(user: ManagedUser, permission: Permission) {
    const granted = user.permissions.includes(permission);
    const permissions = granted
      ? user.permissions.filter((held) => held !== permission)
      : [...user.permissions, permission];
    send(
      `/api/admin/users/${user.id}`,
      { method: "PATCH", body: JSON.stringify({ permissions }) },
      granted
        ? `${PERMISSION_LABEL[permission]}: removido de ${user.username}. Vale já na próxima ação dela.`
        : `${PERMISSION_LABEL[permission]}: liberado para ${user.username}.`,
      user.id,
    );
  }

  const signOut = (user: ManagedUser) =>
    send(
      `/api/admin/users/${user.id}`,
      { method: "PATCH", body: JSON.stringify({ signOut: true }) },
      `${user.username} foi desconectado. O acesso continua ativo — pode entrar de novo.`,
      user.id,
    );

  function reset(user: ManagedUser) {
    const password = window.prompt(
      `Nova senha para ${user.username} (mínimo 8 caracteres):`,
    );
    if (!password) return;
    send(
      `/api/admin/users/${user.id}`,
      { method: "PATCH", body: JSON.stringify({ password }) },
      `Senha de ${user.username} trocada. As sessões abertas caíram.`,
      user.id,
    );
  }

  function remove(user: ManagedUser) {
    if (
      !window.confirm(
        `Excluir o acesso de ${user.username}? Isso não pode ser desfeito — para bloquear temporariamente, use "revogar".`,
      )
    ) {
      return;
    }
    send(
      `/api/admin/users/${user.id}`,
      { method: "DELETE" },
      `Acesso de ${user.username} excluído.`,
      user.id,
    );
  }

  return (
    <>
      <form
        action={create}
        className="border-line bg-surface mt-7 rounded-2xl border p-5"
      >
        <h2 className="text-lg font-semibold">Novo acesso</h2>
        <p className="text-fg-muted mt-1 text-sm">
          Cria um operador: usa o CRM e o prospector, mas não gerencia acessos.
          Já nasce com{" "}
          {DEFAULT_PERMISSIONS.map((p) => PERMISSION_LABEL[p]).join(", ")} — a
          exportação de CSV fica desligada e você libera por pessoa, na tabela
          abaixo.
        </p>

        <div className="mt-4 grid gap-3 md:grid-cols-[1fr_1fr_1fr_auto]">
          <Field label="Usuário" hint="minúsculas, sem espaços">
            <input
              name="username"
              required
              autoComplete="off"
              autoCapitalize="none"
              spellCheck={false}
              placeholder="ana.silva"
              className="border-line bg-surface-2 focus:border-brand w-full rounded-lg border px-3 py-2.5 text-sm outline-none"
            />
          </Field>
          <Field label="Nome" hint="como aparece no topo">
            <input
              name="displayName"
              placeholder="Ana Silva"
              className="border-line bg-surface-2 focus:border-brand w-full rounded-lg border px-3 py-2.5 text-sm outline-none"
            />
          </Field>
          <Field label="Senha" hint="mínimo 8 caracteres">
            <input
              name="password"
              type="text"
              required
              minLength={8}
              autoComplete="new-password"
              className="border-line bg-surface-2 focus:border-brand w-full rounded-lg border px-3 py-2.5 text-sm outline-none"
            />
          </Field>
          <button
            type="submit"
            disabled={pending}
            className="mt-auto inline-flex items-center justify-center gap-2 rounded-lg bg-[#1d2228] px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-black disabled:opacity-60"
          >
            {busy === "form" ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <Plus className="size-4" />
            )}
            Criar
          </button>
        </div>

        {/* Shown in the clear on purpose: the admin has to be able to read the
            password back to the person. It is hashed the moment it is saved. */}
        <p className="text-fg-subtle mt-3 text-xs">
          A senha só aparece aqui, uma vez. Depois de salva ela vira hash e nem
          o administrador consegue lê-la — só definir outra.
        </p>
      </form>

      {error && (
        <p className="mt-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
          {error}
        </p>
      )}
      {notice && !error && (
        <p className="border-brand/30 bg-brand/10 text-brand mt-4 rounded-xl border px-4 py-3 text-sm font-medium">
          {notice}
        </p>
      )}

      <section className="border-line bg-surface mt-4 overflow-hidden rounded-2xl border">
        <div className="px-5 py-4">
          <h2 className="text-lg font-semibold">Acessos criados</h2>
          <p className="text-fg-muted mt-0.5 text-sm">
            {users.length === 0
              ? "Nenhum acesso além do administrador."
              : `${users.length} ${users.length === 1 ? "acesso" : "acessos"} · o administrador vem do ambiente e não aparece aqui`}
          </p>
        </div>

        {users.length > 0 && (
          <div className="hidden overflow-x-auto lg:block">
            <table className="w-full min-w-[720px] text-left text-sm">
              <thead className="bg-surface-2 text-fg-muted border-line border-y text-xs font-medium">
                <tr>
                  <th className="px-5 py-3">Usuário</th>
                  <th className="px-3 py-3">Situação</th>
                  <th className="px-3 py-3">Pode</th>
                  <th className="px-3 py-3">Criado</th>
                  <th className="px-3 py-3">Último acesso</th>
                  <th className="px-5 py-3 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-line divide-y">
                {users.map((user) => (
                  <tr key={user.id} className={user.active ? "" : "opacity-60"}>
                    <td className="px-5 py-3.5">
                      <div className="font-medium">{user.displayName}</div>
                      <div className="text-fg-subtle text-xs">
                        {user.username} · operador
                      </div>
                    </td>
                    <td className="px-3 py-3.5">
                      <div className="flex flex-col items-start gap-1">
                        <span
                          className={`rounded-full border px-2.5 py-1 text-xs font-medium ${
                            user.active
                              ? "border-emerald-300 bg-emerald-50 text-emerald-800"
                              : "border-line bg-surface-2 text-fg-muted"
                          }`}
                        >
                          {user.active ? "Ativo" : "Revogado"}
                        </span>
                        {/* Only worth printing when true: "não conectado" on
                            every idle row is noise, and the cookie is stateless
                            enough that the absence isn't news. */}
                        {user.active && user.signedIn && (
                          <span className="text-fg-subtle text-[11px]">
                            sessão aberta
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-3 py-3.5">
                      <div className="flex flex-wrap gap-1.5">
                        {PERMISSIONS.map((permission) => {
                          const granted = user.permissions.includes(permission);
                          return (
                            <button
                              key={permission}
                              type="button"
                              onClick={() => togglePermission(user, permission)}
                              disabled={pending}
                              aria-pressed={granted}
                              title={`${PERMISSION_HINT[permission]} Clique para ${granted ? "remover" : "liberar"}.`}
                              className={`rounded-full border px-2.5 py-1 text-xs font-medium transition disabled:opacity-50 ${
                                granted
                                  ? "border-brand/40 bg-brand/10 text-brand"
                                  : "border-line bg-surface-2 text-fg-subtle hover:border-line-strong line-through"
                              }`}
                            >
                              {PERMISSION_LABEL[permission]}
                            </button>
                          );
                        })}
                      </div>
                    </td>
                    <td className="text-fg-muted px-3 py-3.5 text-xs">
                      {shortDate(user.createdAt)}
                      {user.createdBy && ` por ${user.createdBy}`}
                    </td>
                    <td className="text-fg-muted px-3 py-3.5 text-xs">
                      {user.lastLoginAt ? shortDate(user.lastLoginAt) : "nunca"}
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center justify-end gap-1.5">
                        {busy === user.id && (
                          <Loader2 className="text-fg-subtle size-4 animate-spin" />
                        )}
                        <a
                          href={`/admin/uso-prospector/${user.id}`}
                          title="Ver atividade e resultados"
                          aria-label="Ver atividade e resultados"
                          className="border-line text-fg-muted hover:border-line-strong hover:text-fg flex size-8 items-center justify-center rounded-lg border transition"
                        >
                          <BarChart3 className="size-4" />
                        </a>
                        <Action
                          onClick={() => reset(user)}
                          disabled={pending}
                          title="Definir nova senha"
                        >
                          <KeyRound className="size-4" />
                        </Action>
                        <Action
                          onClick={() => signOut(user)}
                          disabled={pending || !user.active}
                          title="Encerrar sessões abertas (sem revogar o acesso)"
                        >
                          <LogOut className="size-4" />
                        </Action>
                        <Action
                          onClick={() => toggle(user)}
                          disabled={pending}
                          title={
                            user.active ? "Revogar acesso" : "Reativar acesso"
                          }
                        >
                          {user.active ? (
                            <ShieldBan className="size-4" />
                          ) : (
                            <RotateCcw className="size-4" />
                          )}
                        </Action>
                        <Action
                          onClick={() => remove(user)}
                          disabled={pending}
                          title="Excluir acesso"
                          danger
                        >
                          <Trash2 className="size-4" />
                        </Action>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {users.length > 0 && (
          <div className="divide-line divide-y lg:hidden">
            {users.map((user) => (
              <div
                key={user.id}
                className={`px-4 py-4 ${user.active ? "" : "opacity-60"}`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-medium">{user.displayName}</p>
                    <p className="text-fg-subtle text-xs">
                      {user.username} · operador
                    </p>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-1">
                    <span
                      className={`rounded-full border px-2.5 py-1 text-xs font-medium ${
                        user.active
                          ? "border-emerald-300 bg-emerald-50 text-emerald-800"
                          : "border-line bg-surface-2 text-fg-muted"
                      }`}
                    >
                      {user.active ? "Ativo" : "Revogado"}
                    </span>
                    {user.active && user.signedIn && (
                      <span className="text-fg-subtle text-[11px]">
                        sessão aberta
                      </span>
                    )}
                  </div>
                </div>

                <div className="mt-3 flex flex-wrap gap-1.5">
                  {PERMISSIONS.map((permission) => {
                    const granted = user.permissions.includes(permission);
                    return (
                      <button
                        key={permission}
                        type="button"
                        onClick={() => togglePermission(user, permission)}
                        disabled={pending}
                        aria-pressed={granted}
                        title={`${PERMISSION_HINT[permission]} Toque para ${granted ? "remover" : "liberar"}.`}
                        className={`rounded-full border px-2.5 py-1.5 text-xs font-medium transition disabled:opacity-50 ${
                          granted
                            ? "border-brand/40 bg-brand/10 text-brand"
                            : "border-line bg-surface-2 text-fg-subtle hover:border-line-strong line-through"
                        }`}
                      >
                        {PERMISSION_LABEL[permission]}
                      </button>
                    );
                  })}
                </div>

                <p className="text-fg-subtle mt-3 text-xs">
                  Criado {shortDate(user.createdAt)}
                  {user.createdBy && ` por ${user.createdBy}`}
                  {" · último acesso "}
                  {user.lastLoginAt ? shortDate(user.lastLoginAt) : "nunca"}
                </p>

                <div className="mt-3 flex items-center gap-1.5">
                  {busy === user.id && (
                    <Loader2 className="text-fg-subtle size-4 animate-spin" />
                  )}
                  <a
                    href={`/admin/uso-prospector/${user.id}`}
                    title="Ver atividade e resultados"
                    aria-label="Ver atividade e resultados"
                    className="border-line text-fg-muted hover:border-line-strong hover:text-fg flex size-10 items-center justify-center rounded-lg border transition"
                  >
                    <BarChart3 className="size-4" />
                  </a>
                  <Action
                    onClick={() => reset(user)}
                    disabled={pending}
                    title="Definir nova senha"
                  >
                    <KeyRound className="size-4" />
                  </Action>
                  <Action
                    onClick={() => signOut(user)}
                    disabled={pending || !user.active}
                    title="Encerrar sessões abertas (sem revogar o acesso)"
                  >
                    <LogOut className="size-4" />
                  </Action>
                  <Action
                    onClick={() => toggle(user)}
                    disabled={pending}
                    title={user.active ? "Revogar acesso" : "Reativar acesso"}
                  >
                    {user.active ? (
                      <ShieldBan className="size-4" />
                    ) : (
                      <RotateCcw className="size-4" />
                    )}
                  </Action>
                  <Action
                    onClick={() => remove(user)}
                    disabled={pending}
                    title="Excluir acesso"
                    danger
                  >
                    <Trash2 className="size-4" />
                  </Action>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </>
  );
}

function Action({
  onClick,
  disabled,
  title,
  danger,
  children,
}: {
  onClick: () => void;
  disabled: boolean;
  title: string;
  danger?: boolean;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      title={title}
      aria-label={title}
      className={`border-line flex size-10 items-center justify-center rounded-lg border transition disabled:opacity-50 lg:size-8 ${
        danger
          ? "text-fg-muted hover:border-red-300 hover:bg-red-50 hover:text-red-700"
          : "text-fg-muted hover:border-line-strong hover:text-fg"
      }`}
    >
      {children}
    </button>
  );
}

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint: string;
  children: React.ReactNode;
}) {
  return (
    <label className="text-fg-muted block text-xs font-medium">
      <span className="mb-1.5 block">
        {label} <span className="text-fg-subtle font-normal">· {hint}</span>
      </span>
      {children}
    </label>
  );
}

function shortDate(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso.slice(0, 10);
  return date.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "2-digit",
  });
}
