import { Download } from "lucide-react";
import {
  activityDescription,
  activityFiltersToQuery,
  hasActivityFilters,
} from "@/lib/admin/activity";
import { dateTime, fmt } from "@/lib/admin/format";
import { KIND_LABEL, type OperatorAccount } from "@/lib/admin/operators";
import {
  ACTIVITY_ACTIONS,
  ACTIVITY_LABEL,
  type ActivityFilters,
  type ActivityPage,
} from "@/lib/prospector/db";

/**
 * The audit trail, with its filters and its pages.
 *
 * One component for both admin screens: the overview renders it across every
 * account, the per-operator page renders it with the account fixed. The
 * difference is the presence of `accounts` — passing them adds the picker,
 * leaving them out means the actor is already decided by the URL.
 *
 * A server component with a plain GET form, like the lead filters: the whole
 * view is in the query string, so a page of the audit can be linked to and
 * comes back the same.
 */
export function ActivityFeed({
  basePath,
  filters,
  feed,
  accounts,
  title = "Atividade detalhada",
  description = "Buscas, contatos e alterações nos leads, do mais recente para o mais antigo.",
}: {
  /** Where the form posts and the pagination links point. */
  basePath: string;
  filters: ActivityFilters;
  feed: ActivityPage;
  /** Given only when the actor is the reader's to choose. */
  accounts?: OperatorAccount[];
  title?: string;
  description?: string;
}) {
  const link = (page: number) =>
    `${basePath}${activityFiltersToQuery(filters, { page })}`;
  const filtered = hasActivityFilters(filters);

  return (
    <section className="border-line bg-surface mt-6 overflow-hidden rounded-2xl border">
      <div className="border-line flex flex-wrap items-start justify-between gap-4 border-b px-5 py-4">
        <div>
          <h2 className="font-semibold">{title}</h2>
          <p className="text-fg-muted mt-1 text-sm">{description}</p>
        </div>
        <a
          href={`/api/admin/activity/export${activityFiltersToQuery(filters, { page: 1 })}`}
          className="border-line bg-surface-2 hover:border-line-strong inline-flex items-center gap-2 rounded-xl border px-3.5 py-2 text-sm font-medium transition"
        >
          <Download className="size-4" />
          Exportar {filtered ? "filtro" : "tudo"}
        </a>
      </div>

      {/* No `pagina` field: applying a filter must land on page 1, not on a page
          number the new result set may not have. */}
      <form
        method="GET"
        action={basePath}
        className="border-line bg-surface-2 flex flex-wrap items-end gap-3 border-b px-5 py-4"
      >
        {accounts && (
          <Field label="Acesso">
            <select
              name="usuario"
              defaultValue={filters.actorId ?? ""}
              className="border-line bg-surface focus:border-brand min-w-56 rounded-lg border px-3 py-2.5 text-sm outline-none"
            >
              <option value="">Todos os acessos</option>
              {accounts.map((account) => (
                <option key={account.id} value={account.id}>
                  {account.displayName} · {account.username}
                  {account.kind !== "operador" &&
                    ` (${KIND_LABEL[account.kind].toLowerCase()})`}
                </option>
              ))}
            </select>
          </Field>
        )}
        <Field label="Ação">
          <select
            name="acao"
            defaultValue={filters.action ?? ""}
            className="border-line bg-surface focus:border-brand min-w-44 rounded-lg border px-3 py-2.5 text-sm outline-none"
          >
            <option value="">Todas as ações</option>
            {ACTIVITY_ACTIONS.map((action) => (
              <option key={action} value={action}>
                {ACTIVITY_LABEL[action]}
              </option>
            ))}
          </select>
        </Field>
        <Field label="De">
          <input
            type="date"
            name="de"
            defaultValue={filters.from ?? ""}
            className="border-line bg-surface focus:border-brand rounded-lg border px-3 py-2.5 text-sm outline-none"
          />
        </Field>
        <Field label="Até">
          <input
            type="date"
            name="ate"
            defaultValue={filters.to ?? ""}
            className="border-line bg-surface focus:border-brand rounded-lg border px-3 py-2.5 text-sm outline-none"
          />
        </Field>
        <button
          type="submit"
          className="bg-brand text-brand-fg rounded-lg px-4 py-2.5 text-sm font-semibold"
        >
          Filtrar
        </button>
        {filtered && (
          <a
            href={basePath}
            className="text-fg-muted hover:text-fg px-2 py-2.5 text-sm"
          >
            Limpar
          </a>
        )}
      </form>

      {feed.rows.length === 0 ? (
        <p className="text-fg-muted px-5 py-8 text-sm">
          {filtered
            ? "Nenhuma atividade nesse filtro."
            : "Nenhuma atividade registrada ainda."}
        </p>
      ) : (
        <>
          <ul className="divide-line divide-y">
            {feed.rows.map((event) => (
              <li
                key={event.id}
                className="flex flex-wrap items-start justify-between gap-3 px-5 py-4"
              >
                <div className="min-w-0">
                  <p className="font-medium">
                    {event.displayName}{" "}
                    <span className="text-fg-subtle font-normal">
                      · {event.username}
                    </span>
                  </p>
                  <p className="text-fg-muted mt-1 text-sm">
                    {activityDescription(event)}
                  </p>
                </div>
                <div className="text-right">
                  <span className="border-line text-fg-subtle inline-block rounded-full border px-2 py-0.5 text-[11px]">
                    {ACTIVITY_LABEL[event.action]}
                  </span>
                  <time
                    className="text-fg-subtle mt-1 block text-sm"
                    dateTime={event.occurredAt}
                  >
                    {dateTime(event.occurredAt)}
                  </time>
                </div>
              </li>
            ))}
          </ul>

          <div className="border-line text-fg-muted flex flex-wrap items-center justify-between gap-3 border-t px-5 py-3.5 text-sm">
            <p>
              {fmt(feed.total)} {feed.total === 1 ? "evento" : "eventos"} ·
              página {feed.page} de {feed.pages}
            </p>
            <div className="flex items-center gap-2">
              <Step href={link(feed.page - 1)} disabled={feed.page <= 1}>
                Anterior
              </Step>
              <Step
                href={link(feed.page + 1)}
                disabled={feed.page >= feed.pages}
              >
                Próxima
              </Step>
            </div>
          </div>
        </>
      )}
    </section>
  );
}

function Step({
  href,
  disabled,
  children,
}: {
  href: string;
  disabled: boolean;
  children: React.ReactNode;
}) {
  // A span rather than a disabled link: there is no such thing, and an <a> with
  // no href is still focusable in a way that promises something will happen.
  if (disabled) {
    return (
      <span className="border-line text-fg-subtle rounded-lg border px-3 py-1.5 opacity-50">
        {children}
      </span>
    );
  }
  return (
    <a
      href={href}
      className="border-line hover:border-line-strong hover:text-fg rounded-lg border px-3 py-1.5 transition"
    >
      {children}
    </a>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="text-fg-muted mb-1.5 block text-sm">{label}</span>
      {children}
    </label>
  );
}
