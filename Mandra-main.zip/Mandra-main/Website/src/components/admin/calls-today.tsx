import { PhoneCall } from "lucide-react";
import type { DailyCalls } from "@/lib/prospector/calls";

/**
 * How much calling got done today.
 *
 * The one number a cold-calling operation is actually run on, and until now the
 * only place it existed was inside `callStats` on an admin-only screen. An
 * operator working a hundred dials a day could not see their own count without
 * asking somebody for it.
 *
 * Rendered against the day's target rather than on its own, because a bare "37"
 * answers nothing at 9am and everything at 5pm. The target is the same
 * `DEFAULT_DAILY_TARGET` the automatic queue builds to, so the bar and the queue
 * are describing one day's work rather than two different ideas of it.
 *
 * Presentation only, and deliberately unaware of who is looking: the caller
 * decides whether it is handed one operator's day or the team's, which is what
 * keeps the "operators see themselves, the admin sees everyone" rule in the
 * pages that enforce it rather than in a component that could be reused wrongly.
 */

const fmt = (value: number) => value.toLocaleString("pt-BR");
const plural = (count: number, one: string, many: string) =>
  count === 1 ? one : many;

export function CallsToday({
  calls,
  reached,
  target,
  breakdown,
  label = "Ligações hoje",
}: {
  calls: number;
  reached: number;
  target: number;
  /** Per-operator rows. Omitted for the view that only shows one person. */
  breakdown?: DailyCalls[];
  label?: string;
}) {
  // Capped for the bar only; the printed number stays honest about a day that
  // went past target, which is the day worth seeing.
  const pct =
    target > 0 ? Math.min(100, Math.round((calls / target) * 100)) : 0;
  const done = calls >= target && target > 0;

  return (
    <section className="border-line bg-surface rounded-2xl border p-5">
      <div className="flex items-start gap-3.5">
        <span className="bg-brand/10 text-brand flex size-11 shrink-0 items-center justify-center rounded-xl">
          <PhoneCall className="size-5" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-fg-muted text-xs">{label}</p>
          <p className="tnum mt-0.5 text-3xl font-semibold tracking-tight">
            {fmt(calls)}
            <span className="text-fg-subtle ml-1.5 text-base font-normal">
              / {fmt(target)}
            </span>
          </p>
          <p
            className={`mt-0.5 text-xs ${done ? "text-brand font-medium" : "text-fg-subtle"}`}
          >
            {calls === 0
              ? "nenhuma ligação registrada hoje"
              : `${fmt(reached)} ${plural(reached, "atendida", "atendidas")}` +
                (done ? " · meta batida" : ` · faltam ${fmt(target - calls)}`)}
          </p>
        </div>
      </div>

      {/* aria-hidden because the numbers above already say this, and a
          progressbar role would read the same value twice. */}
      <div
        aria-hidden
        className="bg-surface-raised mt-4 h-1.5 overflow-hidden rounded-full"
      >
        <div
          className="bg-brand h-full rounded-full transition-[width]"
          style={{ width: `${pct}%` }}
        />
      </div>

      {breakdown && breakdown.length > 0 && (
        <ul className="border-line mt-4 space-y-2 border-t pt-4">
          {breakdown.map((row) => (
            <li
              key={row.actorId}
              className="flex items-baseline justify-between gap-3 text-sm"
            >
              <span className="text-fg-muted truncate">
                {row.actorDisplayName}
              </span>
              <span className="tnum shrink-0 font-medium">
                {fmt(row.calls)}
                <span className="text-fg-subtle ml-1 text-xs font-normal">
                  · {fmt(row.reached)} atend.
                </span>
              </span>
            </li>
          ))}
        </ul>
      )}

      {breakdown && breakdown.length === 0 && (
        <p className="text-fg-subtle border-line mt-4 border-t pt-4 text-xs">
          Ninguém ligou ainda hoje.
        </p>
      )}
    </section>
  );
}
