"use client";

import { useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  ChevronDown,
  Globe,
  Lock,
  MapPin,
  MessageCircle,
  Phone,
  Plus,
  Share2,
  StickyNote,
  Tag,
  TriangleAlert,
  X,
} from "lucide-react";
import { CreateCallListButton } from "@/components/admin/create-call-list";
import { ContactedMark } from "@/components/prospector/contacted-mark";
import {
  FUNNEL_LABEL,
  FUNNEL_STAGES,
  STAGE_STATUS,
  type FunnelStage,
  type LeadStatus,
  type SocialLink,
} from "@/lib/prospector/types";

/**
 * The pipeline table.
 *
 * One client component for the whole tbody rather than a client control per
 * cell: selection, row expansion and the bulk bar are all state that spans rows,
 * and threading it through server-rendered cells would mean lifting it into a
 * provider anyway. The page stays a server component and hands down plain data.
 *
 * Every mutation is optimistic. Marking twenty leads as contacted shouldn't be
 * twenty round-trip waits, and a failed write against a local SQLite file is
 * close to impossible — but showing the wrong pipeline state is worse than a
 * flicker, so each one rolls back and flags the row on failure.
 */

/**
 * A row, flattened server-side. The niche label and the wa.me URL are resolved
 * before they get here so the niche registry and the scoring module stay out of
 * the client bundle.
 */
export type CrmLead = {
  id: string;
  name: string;
  category: string | null;
  nicheLabel: string;
  address: string | null;
  city: string | null;
  uf: string | null;
  /** Country label, already resolved server-side. Null for the older rows. */
  country: string | null;
  phone: string | null;
  whatsappUrl: string | null;
  website: string | null;
  social: string | null;
  email: string | null;
  mapUrl: string | null;
  score: number;
  reasons: string[];
  status: LeadStatus;
  funnelStage: FunnelStage;
  socials: SocialLink[];
  contactName: string | null;
  /** Operator labels. Free text — see lib/prospector/tags.ts for the rules. */
  tags: string[];
  nextFollowUpAt: string | null;
  notes: string | null;
  firstSeenAt: string;
  contactedAt: string | null;
  /** Who this lead belongs to, or null while nobody has contacted it. */
  owner: { id: string; name: string } | null;
  /**
   * The owner's name when that owner is somebody *other* than the person looking
   * at the row, and null otherwise — including for an admin, who is exempt.
   * Resolved server-side by `toCrmRow`; the table only decides what to render,
   * never who is allowed. The contact actions go inert when it is set, because
   * the honest place to stop a duplicate approach is before the tab opens.
   */
  blockedBy: string | null;
};

/**
 * "São Paulo - SP · Brasil". The country is spelled out rather than left to the
 * state code, because two-letter codes stop being self-explanatory the moment
 * the pipeline holds more than one country — "SP" is São Paulo and it is also
 * a Portuguese district nobody would read as Brazilian.
 */
function placeOf(lead: CrmLead): string {
  if (!lead.city) return "—";
  const region = lead.uf ? ` - ${lead.uf}` : "";
  const country = lead.country ? ` · ${lead.country}` : "";
  return `${lead.city}${region}${country}`;
}

const STATUS_LABEL: Record<LeadStatus, string> = {
  novo: "Novo",
  contatado: "Contatado",
  respondeu: "Respondeu",
  cliente: "Cliente",
  descartado: "Descartado",
};

/**
 * Seven funnel stages need seven distinguishable hues, which is more than the
 * token layer carries — this is the one place in the CRM that names colours, and
 * they are fixed shades chosen to pass on the paper tone's white rows. They run
 * cool-to-committed in funnel order so a column of them reads as progress.
 */
const STAGE_TONE: Record<FunnelStage, string> = {
  descoberta: "border-line bg-surface-2 text-fg-muted",
  contato: "border-amber-300 bg-amber-50 text-amber-800",
  qualificado: "border-sky-300 bg-sky-50 text-sky-800",
  proposta: "border-indigo-300 bg-indigo-50 text-indigo-800",
  negociacao: "border-violet-300 bg-violet-50 text-violet-800",
  fechado: "border-emerald-300 bg-emerald-50 text-emerald-800",
  perdido: "border-line bg-surface-2 text-fg-subtle line-through",
};

type Override = {
  funnelStage?: FunnelStage;
  status?: LeadStatus;
  contactName?: string | null;
  socials?: SocialLink[];
  tags?: string[];
  nextFollowUpAt?: string | null;
  notes?: string | null;
};

export function LeadTable({
  leads,
  /**
   * Whether the bulk bar offers "criar lista de ligações".
   *
   * Off for the client portal, which renders this same table: cold-calling is
   * our tooling, the queue it opens lives under /admin, and a client pressing it
   * would be pushed to a page their session cannot open. Hiding it is not the
   * control — /api/prospector/calls/lists scopes what it can queue either way —
   * it is not offering something that would dead-end.
   */
  canCall = true,
  /**
   * Whether the expanded row offers "liberar atendimento".
   *
   * Admin only, and the escape hatch the permanent half of the exclusivity rule
   * needs: without it the first contact is an irreversible decision made by one
   * click. The route checks the role itself — this is only about not offering a
   * button that would 403.
   */
  canRelease = false,
}: {
  leads: CrmLead[];
  canCall?: boolean;
  canRelease?: boolean;
}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();

  const [selected, setSelected] = useState<ReadonlySet<string>>(new Set());
  const [expanded, setExpanded] = useState<ReadonlySet<string>>(new Set());
  const [overrides, setOverrides] = useState<Record<string, Override>>({});
  const [failed, setFailed] = useState<ReadonlySet<string>>(new Set());

  // Server data is authoritative the moment it arrives: a refresh replaces the
  // array, which drops the optimistic values it has now caught up with. Without
  // this the overrides outlive the write they were covering for and a row edited
  // in another tab would keep showing this tab's guess.
  const [seen, setSeen] = useState(leads);
  if (seen !== leads) {
    setSeen(leads);
    setOverrides({});
    setSelected(new Set());
    setFailed(new Set());
  }

  const valueOf = (lead: CrmLead): CrmLead => ({
    ...lead,
    ...overrides[lead.id],
  });

  const mark = (id: string, ok: boolean) =>
    setFailed((current) => {
      const next = new Set(current);
      if (ok) next.delete(id);
      else next.add(id);
      return next;
    });

  /**
   * Applies the change locally, then persists it.
   *
   * Rollback restores the row's whole override entry rather than the single key
   * that failed — dropping it entirely when there wasn't one, which falls back
   * to the value the server sent. Reverting key by key would leave the row
   * showing a mix of a failed write and the server's state.
   */
  function save(id: string, patch: Override, endpoint: string, body: unknown) {
    const previous = overrides[id];

    setOverrides((current) => ({
      ...current,
      [id]: { ...current[id], ...patch },
    }));
    mark(id, true);

    startTransition(async () => {
      try {
        const res = await fetch(endpoint, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(body),
        });
        if (!res.ok) throw new Error(String(res.status));
        // Re-reads the metric tiles and the facet counts, which the row edit has
        // just invalidated.
        router.refresh();
      } catch {
        setOverrides((current) => {
          const next = { ...current };
          if (previous === undefined) delete next[id];
          else next[id] = previous;
          return next;
        });
        mark(id, false);
      }
    });
  }

  /**
   * Moving a lead down the funnel moves its outreach status with it — the
   * prospector's board reads `status` and would otherwise disagree with the CRM
   * about the same business. The server applies the same mapping; this is the
   * optimistic copy of it.
   */
  const setStage = (id: string, stage: FunnelStage) =>
    save(
      id,
      { funnelStage: stage, status: STAGE_STATUS[stage] },
      "/api/prospector/history/details",
      { id, stage },
    );

  const setContactName = (id: string, contactName: string) =>
    save(
      id,
      { contactName: contactName || null },
      "/api/prospector/history/details",
      {
        id,
        contactName,
      },
    );

  const setSocials = (id: string, socials: SocialLink[]) =>
    save(id, { socials }, "/api/prospector/history/details", {
      id,
      socials: socials.map((link) => link.url),
    });

  const setTags = (id: string, tags: string[]) =>
    save(id, { tags }, "/api/prospector/history/details", { id, tags });

  const setFollowUp = (id: string, date: string) =>
    save(
      id,
      { nextFollowUpAt: date || null },
      "/api/prospector/history/follow-up",
      { id, date: date || null },
    );

  const setNotes = (id: string, notes: string) =>
    save(id, { notes: notes || null }, "/api/prospector/history/notes", {
      id,
      notes,
    });

  /** Bulk stage change. One request per lead — the endpoint takes a single id,
   *  and a handful of parallel writes to a local file is not worth a batch API. */
  function bulkStage(stage: FunnelStage) {
    const ids = [...selected];
    if (ids.length === 0) return;

    setOverrides((current) => {
      const next = { ...current };
      for (const id of ids) {
        next[id] = {
          ...next[id],
          funnelStage: stage,
          status: STAGE_STATUS[stage],
        };
      }
      return next;
    });

    startTransition(async () => {
      const results = await Promise.allSettled(
        ids.map((id) =>
          fetch("/api/prospector/history/details", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ id, stage }),
          }).then((res) => {
            if (!res.ok) throw new Error(String(res.status));
          }),
        ),
      );
      results.forEach((result, index) => {
        if (result.status === "rejected") mark(ids[index], false);
      });
      setSelected(new Set());
      router.refresh();
    });
  }

  /**
   * Adds one label to every selected lead, keeping what each already carries.
   *
   * A union rather than a replace: bulk-tagging is how you mark a batch as
   * belonging to something, and overwriting would silently strip the labels
   * that made the batch worth selecting.
   */
  function bulkTag(raw: string) {
    const tag = raw.replace(/\s+/g, " ").trim().slice(0, MAX_TAG_LENGTH);
    const ids = [...selected];
    if (tag.length === 0 || ids.length === 0) return;

    const nextFor = new Map<string, string[]>();
    for (const row of leads) {
      if (!selected.has(row.id)) continue;
      const current = valueOf(row).tags;
      if (current.some((t) => sameTag(t, tag))) continue;
      if (current.length >= MAX_TAGS) continue;
      nextFor.set(row.id, [...current, tag]);
    }
    if (nextFor.size === 0) {
      setSelected(new Set());
      return;
    }

    setOverrides((current) => {
      const next = { ...current };
      for (const [id, tags] of nextFor) next[id] = { ...next[id], tags };
      return next;
    });

    startTransition(async () => {
      const entries = [...nextFor];
      const results = await Promise.allSettled(
        entries.map(([id, tags]) =>
          fetch("/api/prospector/history/details", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ id, tags }),
          }).then((res) => {
            if (!res.ok) throw new Error(String(res.status));
          }),
        ),
      );
      results.forEach((result, index) => {
        if (result.status === "rejected") mark(entries[index][0], false);
      });
      setSelected(new Set());
      router.refresh();
    });
  }

  const toggle = (
    set: ReadonlySet<string>,
    update: (next: ReadonlySet<string>) => void,
    id: string,
  ) => {
    const next = new Set(set);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    update(next);
  };

  const allSelected = leads.length > 0 && selected.size === leads.length;

  return (
    <>
      {/* Below `lg` the sidebar itself drops to a horizontal strip (see the CRM
          shell), which is the same width the table's eight columns stop fitting
          at — so the switch to cards rides the same breakpoint. */}
      <div className="hidden overflow-x-auto lg:block">
        <table className="w-full min-w-[1080px] text-left text-sm">
          <thead className="bg-surface-2 text-fg-muted border-line border-y text-xs font-medium">
            <tr>
              <th className="w-10 py-3 pr-2 pl-5">
                <input
                  type="checkbox"
                  checked={allSelected}
                  ref={(node) => {
                    if (node) {
                      node.indeterminate =
                        selected.size > 0 && selected.size < leads.length;
                    }
                  }}
                  onChange={() =>
                    setSelected(
                      allSelected ? new Set() : new Set(leads.map((l) => l.id)),
                    )
                  }
                  aria-label="Selecionar todos os leads da página"
                  className="accent-brand size-4 align-middle"
                />
              </th>
              <th className="px-3 py-3 font-medium">Empresa</th>
              <th className="px-3 py-3 font-medium">Segmento</th>
              <th className="px-3 py-3 font-medium">Localização</th>
              <th className="px-3 py-3 font-medium">Contato</th>
              <th className="px-3 py-3 font-medium">Site</th>
              {/* Wide enough for "Proposta enviada" — the select clips rather
                  than wraps, and a clipped stage name is unreadable. */}
              <th className="w-44 px-3 py-3 font-medium">Etapa do funil</th>
              <th className="w-36 px-3 py-3 font-medium">Follow-up</th>
              <th className="w-28 px-3 py-3 pr-5 font-medium">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-line divide-y">
            {leads.map((row) => {
              const lead = valueOf(row);
              const isOpen = expanded.has(lead.id);
              const isSelected = selected.has(lead.id);
              const hasFailed = failed.has(lead.id);

              return (
                <Row
                  key={lead.id}
                  lead={lead}
                  canRelease={canRelease}
                  isOpen={isOpen}
                  isSelected={isSelected}
                  hasFailed={hasFailed}
                  pending={pending}
                  onToggleSelect={() => toggle(selected, setSelected, lead.id)}
                  onToggleExpand={() => toggle(expanded, setExpanded, lead.id)}
                  onStage={(stage) => setStage(lead.id, stage)}
                  onFollowUp={(date) => setFollowUp(lead.id, date)}
                  onNotes={(notes) => setNotes(lead.id, notes)}
                  onContactName={(name) => setContactName(lead.id, name)}
                  onSocials={(socials) => setSocials(lead.id, socials)}
                  onTags={(tags) => setTags(lead.id, tags)}
                />
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="divide-line divide-y lg:hidden">
        {leads.length > 0 && (
          <label className="flex items-center gap-3 px-4 py-3">
            <input
              type="checkbox"
              checked={allSelected}
              ref={(node) => {
                if (node) {
                  node.indeterminate =
                    selected.size > 0 && selected.size < leads.length;
                }
              }}
              onChange={() =>
                setSelected(
                  allSelected ? new Set() : new Set(leads.map((l) => l.id)),
                )
              }
              aria-label="Selecionar todos os leads da página"
              className="accent-brand size-5"
            />
            <span className="text-fg-muted text-sm">
              Selecionar todos ({leads.length})
            </span>
          </label>
        )}
        {leads.map((row) => {
          const lead = valueOf(row);
          const isOpen = expanded.has(lead.id);
          const isSelected = selected.has(lead.id);
          const hasFailed = failed.has(lead.id);

          return (
            <LeadCard
              key={lead.id}
              lead={lead}
              canRelease={canRelease}
              isOpen={isOpen}
              isSelected={isSelected}
              hasFailed={hasFailed}
              pending={pending}
              onToggleSelect={() => toggle(selected, setSelected, lead.id)}
              onToggleExpand={() => toggle(expanded, setExpanded, lead.id)}
              onStage={(stage) => setStage(lead.id, stage)}
              onFollowUp={(date) => setFollowUp(lead.id, date)}
              onNotes={(notes) => setNotes(lead.id, notes)}
              onContactName={(name) => setContactName(lead.id, name)}
              onSocials={(socials) => setSocials(lead.id, socials)}
              onTags={(tags) => setTags(lead.id, tags)}
            />
          );
        })}
      </div>

      {selected.size > 0 && (
        <div
          style={{ bottom: "max(1rem, env(safe-area-inset-bottom))" }}
          className="sticky z-10 mx-4 mb-4 flex flex-wrap items-center gap-3 rounded-xl border border-[#2b333b] bg-[#171c21] px-4 py-3 text-sm text-white shadow-lg sm:mx-5"
        >
          <span className="font-medium">
            {selected.size}{" "}
            {selected.size === 1 ? "lead selecionado" : "leads selecionados"}
          </span>
          <span className="text-slate-400">mover para</span>
          <div className="flex flex-wrap gap-1.5">
            {FUNNEL_STAGES.filter((stage) => stage !== "descoberta").map(
              (stage) => (
                <button
                  key={stage}
                  type="button"
                  disabled={pending}
                  onClick={() => bulkStage(stage)}
                  className="rounded-lg bg-white/10 px-3 py-2 font-medium transition hover:bg-white/20 disabled:opacity-50 sm:py-1.5"
                >
                  {FUNNEL_LABEL[stage]}
                </button>
              ),
            )}
          </div>
          <BulkTagBox disabled={pending} onAdd={bulkTag} />
          {/* The ticked rows as a queue. Sends ids rather than the filter,
              because "these ones" is exactly what a selection means. */}
          {canCall && (
            <CreateCallListButton
              ids={[...selected]}
              count={selected.size}
              tone="dark"
            />
          )}
          <button
            type="button"
            onClick={() => setSelected(new Set())}
            className="ml-auto text-slate-400 underline-offset-2 hover:text-white hover:underline"
          >
            limpar
          </button>
        </div>
      )}
    </>
  );
}

function Row({
  lead,
  canRelease,
  isOpen,
  isSelected,
  hasFailed,
  pending,
  onToggleSelect,
  onToggleExpand,
  onStage,
  onFollowUp,
  onNotes,
  onContactName,
  onSocials,
  onTags,
}: {
  lead: CrmLead;
  canRelease: boolean;
  isOpen: boolean;
  isSelected: boolean;
  hasFailed: boolean;
  pending: boolean;
  onToggleSelect: () => void;
  onToggleExpand: () => void;
  onStage: (stage: FunnelStage) => void;
  onFollowUp: (date: string) => void;
  onNotes: (notes: string) => void;
  onContactName: (name: string) => void;
  onSocials: (socials: SocialLink[]) => void;
  onTags: (tags: string[]) => void;
}) {
  const overdue = lead.nextFollowUpAt !== null && lead.nextFollowUpAt < today();

  return (
    <>
      <tr className={isSelected ? "bg-brand/[0.06]" : "hover:bg-surface-2"}>
        <td className="py-3.5 pr-2 pl-5 align-top">
          <input
            type="checkbox"
            checked={isSelected}
            onChange={onToggleSelect}
            aria-label={`Selecionar ${lead.name}`}
            className="accent-brand mt-0.5 size-4"
          />
        </td>
        <td className="px-3 py-3.5 align-top">
          <button
            type="button"
            onClick={onToggleExpand}
            aria-expanded={isOpen}
            className="group flex items-start gap-1.5 text-left"
          >
            <ChevronDown
              className={`text-fg-subtle mt-0.5 size-4 shrink-0 transition-transform ${isOpen ? "rotate-180" : ""}`}
            />
            <span>
              <span className="group-hover:text-brand font-medium">
                {lead.name}
              </span>
              {/* The note itself only exists in the expanded row, so a lead with
                  one would otherwise look identical to a lead without. */}
              {lead.notes && (
                <StickyNote
                  className="text-brand ml-1.5 inline size-3.5 align-[-0.15em]"
                  aria-label="Tem anotação"
                />
              )}
              <span className="text-fg-subtle block text-xs">
                {lead.category ?? "—"} · score{" "}
                <span className="tnum">{lead.score}</span>
              </span>
              {/* Shown for every owned lead, not only the ones closed to this
                  operator: "quem está atendendo" is the question the whole rule
                  exists to answer, and a badge that appears only on other
                  people's leads reads as an error state rather than as a fact. */}
              {lead.owner && (
                <span className="text-fg-subtle block text-xs">
                  Atendido por {lead.owner.name}
                </span>
              )}
              {/* Inside the disclosure button so the labels are readable
                  without expanding the row — which is the point of having
                  grouped by them in the first place. */}
              <TagChips tags={lead.tags} />
            </span>
          </button>
        </td>
        <td className="text-fg-muted px-3 py-3.5 align-top">
          {lead.nicheLabel}
        </td>
        <td className="text-fg-muted px-3 py-3.5 align-top">
          <span className="inline-flex items-center gap-1">
            <MapPin className="text-fg-subtle size-3.5 shrink-0" />
            {placeOf(lead)}
          </span>
        </td>
        <td className="px-3 py-3.5 align-top">
          {/* Above the links, so it is read on the way to them. The stage column
              two cells over does not answer this: a lead can sit in "descoberta"
              after a conversation, and one in "contato feito" may have got there
              from somebody opening WhatsApp yesterday. */}
          <span className="flex flex-col items-start gap-1.5">
            <ContactedMark lead={lead} />
            {lead.whatsappUrl ? (
              <>
                <WhatsappLink lead={lead} variant="text" />
                {!lead.blockedBy && lead.phone && (
                  <PhoneLink lead={lead} variant="text" />
                )}
              </>
            ) : lead.phone ? (
              <PhoneLink lead={lead} variant="number" />
            ) : (
              <span className="text-fg-subtle">{lead.email ?? "—"}</span>
            )}
          </span>
        </td>
        <td className="px-3 py-3.5 align-top whitespace-nowrap">
          {lead.website ? (
            <a
              href={lead.website}
              target="_blank"
              rel="noopener noreferrer"
              className="text-fg-muted hover:text-brand inline-flex items-center gap-1.5"
            >
              <Globe className="size-3.5 shrink-0" />
              Possui
            </a>
          ) : (
            <span className="text-brand font-medium">Não possui</span>
          )}
        </td>
        <td className="px-3 py-3.5 align-top">
          <select
            value={lead.funnelStage}
            disabled={pending}
            onChange={(event) => onStage(event.target.value as FunnelStage)}
            aria-label={`Etapa do funil de ${lead.name}`}
            className={`focus:border-brand w-full rounded-lg border px-2 py-1.5 text-xs font-medium outline-none disabled:opacity-60 ${STAGE_TONE[lead.funnelStage]}`}
          >
            {FUNNEL_STAGES.map((stage) => (
              <option key={stage} value={stage}>
                {FUNNEL_LABEL[stage]}
              </option>
            ))}
          </select>
        </td>
        <td className="px-3 py-3.5 align-top">
          <input
            type="date"
            value={lead.nextFollowUpAt ?? ""}
            disabled={pending}
            onChange={(event) => onFollowUp(event.target.value)}
            aria-label={`Próximo follow-up de ${lead.name}`}
            className={`bg-surface-2 focus:border-brand w-full rounded-lg border px-2 py-1.5 text-xs outline-none disabled:opacity-60 ${
              overdue ? "border-hot/50 text-hot" : "border-line text-fg-muted"
            }`}
          />
        </td>
        <td className="px-3 py-3.5 pr-5 align-top">
          <div className="flex items-center gap-1.5">
            <ContactedMark lead={lead} variant="icon" />
            {lead.whatsappUrl ? (
              <>
                <WhatsappLink lead={lead} variant="icon" />
                {!lead.blockedBy && lead.phone && (
                  <PhoneLink lead={lead} variant="icon" />
                )}
              </>
            ) : (
              // A landline still gets an action. An empty cell on some rows and
              // a button on others reads as a row that failed to render.
              lead.phone && <PhoneLink lead={lead} variant="icon" />
            )}
            {hasFailed && (
              <span
                title="Não foi possível salvar — a alteração foi desfeita"
                className="text-hot"
              >
                <TriangleAlert className="size-4" />
              </span>
            )}
          </div>
        </td>
      </tr>

      {isOpen && (
        <tr className="bg-surface-2/70">
          <td />
          <td colSpan={8} className="px-3 pt-1 pb-5">
            <LeadDetails
              lead={lead}
              canRelease={canRelease}
              onNotes={onNotes}
              onContactName={onContactName}
              onSocials={onSocials}
              onTags={onTags}
            />
          </td>
        </tr>
      )}
    </>
  );
}

/**
 * The expanded panel's contents — address, signals, history, contact name and
 * the note/social editors. Shared between the desktop row's expanded `<tr>`
 * and the mobile card's expanded section so the two never drift apart.
 */
function LeadDetails({
  lead,
  canRelease,
  onNotes,
  onContactName,
  onSocials,
  onTags,
}: {
  lead: CrmLead;
  canRelease: boolean;
  onNotes: (notes: string) => void;
  onContactName: (name: string) => void;
  onSocials: (socials: SocialLink[]) => void;
  onTags: (tags: string[]) => void;
}) {
  return (
    <div className="grid gap-5 md:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
      <div className="space-y-3 text-sm">
        <Detail label="Endereço">
          {lead.address ?? "—"}
          {lead.mapUrl && (
            <a
              href={lead.mapUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-brand ml-2 text-xs hover:underline"
            >
              ver no mapa
            </a>
          )}
        </Detail>
        {lead.reasons.length > 0 && (
          <Detail label="Sinais">
            <span className="flex flex-wrap gap-1.5">
              {lead.reasons.map((reason) => (
                <span
                  key={reason}
                  className="border-line bg-surface rounded-full border px-2 py-0.5 text-xs"
                >
                  {reason}
                </span>
              ))}
            </span>
          </Detail>
        )}
        {lead.owner && (
          <Detail label="Atendimento">
            <span className="flex flex-wrap items-center gap-2">
              {lead.owner.name}
              {canRelease && <ReleaseOwner id={lead.id} />}
            </span>
          </Detail>
        )}
        <Detail label="Histórico">
          Encontrado em {shortDate(lead.firstSeenAt)}
          {lead.contactedAt
            ? ` · contatado em ${shortDate(lead.contactedAt)}`
            : " · sem contato registrado"}
          {" · status "}
          {STATUS_LABEL[lead.status].toLowerCase()}
        </Detail>
        {lead.email && (
          <Detail label="E-mail">
            <a
              href={`mailto:${lead.email}`}
              className="text-fg-muted hover:text-brand"
            >
              {lead.email}
            </a>
          </Detail>
        )}

        <TextField
          key={`contact-${lead.id}`}
          label="Pessoa de contato"
          value={lead.contactName ?? ""}
          placeholder="Quem atende — nome, cargo"
          onSave={onContactName}
        />

        <SocialEditor
          key={`socials-${lead.id}`}
          value={lead.socials}
          found={lead.social}
          onSave={onSocials}
        />

        <TagEditor key={`tags-${lead.id}`} value={lead.tags} onSave={onTags} />
      </div>

      <NoteEditor key={lead.id} value={lead.notes ?? ""} onSave={onNotes} />
    </div>
  );
}

/**
 * The same row, as a card. Below `lg` the table's eight columns don't fit any
 * useful width without horizontal scrolling, so the mobile view isn't a
 * shrunk table — it's the row's fields re-laid-out vertically, with the two
 * actions an operator actually reaches for on the go (the funnel stage and
 * WhatsApp) given full-width, thumb-sized controls instead of the desktop
 * row's compact inline ones.
 */
function LeadCard({
  lead,
  canRelease,
  isOpen,
  isSelected,
  hasFailed,
  pending,
  onToggleSelect,
  onToggleExpand,
  onStage,
  onFollowUp,
  onNotes,
  onContactName,
  onSocials,
  onTags,
}: {
  lead: CrmLead;
  canRelease: boolean;
  isOpen: boolean;
  isSelected: boolean;
  hasFailed: boolean;
  pending: boolean;
  onToggleSelect: () => void;
  onToggleExpand: () => void;
  onStage: (stage: FunnelStage) => void;
  onFollowUp: (date: string) => void;
  onNotes: (notes: string) => void;
  onContactName: (name: string) => void;
  onSocials: (socials: SocialLink[]) => void;
  onTags: (tags: string[]) => void;
}) {
  const overdue = lead.nextFollowUpAt !== null && lead.nextFollowUpAt < today();

  return (
    <div className={`px-4 py-4 ${isSelected ? "bg-brand/[0.06]" : ""}`}>
      <div className="flex items-start gap-3">
        {/* The checkbox stays its usual size — the label around it is what
            gives the tap 44px of real height, without visually ballooning it. */}
        <label className="flex shrink-0 items-center justify-center py-1 pr-1">
          <input
            type="checkbox"
            checked={isSelected}
            onChange={onToggleSelect}
            aria-label={`Selecionar ${lead.name}`}
            className="accent-brand size-5"
          />
        </label>
        <button
          type="button"
          onClick={onToggleExpand}
          aria-expanded={isOpen}
          className="min-w-0 flex-1 text-left"
        >
          <span className="flex flex-wrap items-center gap-1.5">
            <span className="font-medium">{lead.name}</span>
            {lead.notes && (
              <StickyNote
                className="text-brand size-3.5 shrink-0"
                aria-label="Tem anotação"
              />
            )}
          </span>
          <span className="text-fg-subtle mt-0.5 block text-xs">
            {lead.category ?? lead.nicheLabel} · score{" "}
            <span className="tnum">{lead.score}</span>
          </span>
          {lead.owner && (
            <span className="text-fg-subtle mt-0.5 block text-xs">
              Atendido por {lead.owner.name}
            </span>
          )}
          <span className="text-fg-muted mt-1.5 flex items-center gap-1 text-xs">
            <MapPin className="size-3.5 shrink-0" />
            {placeOf(lead)}
          </span>
          <TagChips tags={lead.tags} />
        </button>
        <ChevronDown
          className={`text-fg-subtle mt-1 size-5 shrink-0 transition-transform ${isOpen ? "rotate-180" : ""}`}
        />
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
        <span className="border-line bg-surface-2 text-fg-muted rounded-full border px-2.5 py-1">
          {lead.nicheLabel}
        </span>
        {lead.website ? (
          <a
            href={lead.website}
            target="_blank"
            rel="noopener noreferrer"
            className="border-line bg-surface-2 text-fg-muted inline-flex items-center gap-1 rounded-full border px-2.5 py-1"
          >
            <Globe className="size-3 shrink-0" />
            Possui site
          </a>
        ) : (
          <span className="border-brand/30 bg-brand/10 text-brand rounded-full border px-2.5 py-1 font-medium">
            Sem site
          </span>
        )}
        {hasFailed && (
          <span
            title="Não foi possível salvar — a alteração foi desfeita"
            className="text-hot inline-flex items-center gap-1"
          >
            <TriangleAlert className="size-3.5" />
            Falhou ao salvar
          </span>
        )}
      </div>

      <div className="mt-3 space-y-2">
        <select
          value={lead.funnelStage}
          disabled={pending}
          onChange={(event) => onStage(event.target.value as FunnelStage)}
          aria-label={`Etapa do funil de ${lead.name}`}
          className={`focus:border-brand w-full rounded-lg border px-3 py-3 text-sm font-medium outline-none disabled:opacity-60 ${STAGE_TONE[lead.funnelStage]}`}
        >
          {FUNNEL_STAGES.map((stage) => (
            <option key={stage} value={stage}>
              {FUNNEL_LABEL[stage]}
            </option>
          ))}
        </select>
        <label className="text-fg-subtle flex items-center gap-2.5 text-xs">
          Follow-up
          <input
            type="date"
            value={lead.nextFollowUpAt ?? ""}
            disabled={pending}
            onChange={(event) => onFollowUp(event.target.value)}
            aria-label={`Próximo follow-up de ${lead.name}`}
            className={`bg-surface-2 focus:border-brand flex-1 rounded-lg border px-3 py-2.5 text-sm outline-none disabled:opacity-60 ${
              overdue ? "border-hot/50 text-hot" : "border-line text-fg-muted"
            }`}
          />
        </label>
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <ContactedMark lead={lead} />
        {lead.whatsappUrl ? (
          <>
            <WhatsappLink lead={lead} variant="button" />
            {!lead.blockedBy && lead.phone && (
              <PhoneLink lead={lead} variant="button" />
            )}
          </>
        ) : lead.phone ? (
          <PhoneLink lead={lead} variant="number" />
        ) : (
          <span className="text-fg-subtle text-xs">
            {lead.email ?? "Sem contato direto"}
          </span>
        )}
      </div>

      {isOpen && (
        <div className="border-line mt-4 border-t pt-4">
          <LeadDetails
            lead={lead}
            canRelease={canRelease}
            onNotes={onNotes}
            onContactName={onContactName}
            onSocials={onSocials}
            onTags={onTags}
          />
        </div>
      )}
    </div>
  );
}

/**
 * Hands a lead back to the team.
 *
 * Admin only — the route checks the role, this only decides whether the button
 * is offered. Confirmed rather than instant: it takes a lead away from the
 * operator who has the relationship with that business, and the person pressing
 * it is not that operator.
 */
function ReleaseOwner({ id }: { id: string }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();

  return (
    <button
      type="button"
      disabled={pending}
      onClick={() => {
        if (
          !confirm(
            "Liberar este lead? Ele volta a ficar disponível para qualquer operador.",
          )
        )
          return;
        startTransition(async () => {
          await fetch("/api/prospector/calls/claim", {
            method: "PATCH",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ id }),
          });
          router.refresh();
        });
      }}
      className="border-line hover:border-line-strong text-fg-muted rounded-lg border px-2 py-0.5 text-xs transition disabled:opacity-50"
    >
      {pending ? "Liberando…" : "liberar"}
    </button>
  );
}

/**
 * Opening the conversation is also the moment the lead becomes "contatado", so
 * the click records the outreach on the way out. The tab navigation to wa.me can
 * cancel an ordinary fetch, hence keepalive; the server update is idempotent, so
 * a second click never resets the follow-up date it set the first time.
 *
 * A lead somebody else owns renders as a disabled control naming them, not as a
 * link that opens WhatsApp and 409s behind the operator's back. That order
 * matters here more than anywhere else in this feature: the route refusing to
 * *log* the outreach does nothing about the message already typed into a chat
 * with a business a colleague is mid-negotiation with. The route is still the
 * control — this is what stops the click.
 */
function WhatsappLink({
  lead,
  variant,
}: {
  lead: CrmLead;
  variant: "icon" | "text" | "button";
}) {
  const router = useRouter();

  const record = () => {
    void fetch("/api/prospector/history/outreach", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id: lead.id }),
      keepalive: true,
    }).then(() => router.refresh());
  };

  if (lead.blockedBy) {
    const title = `Atendido por ${lead.blockedBy} — fale com ${lead.blockedBy} antes de entrar em contato.`;
    if (variant === "icon") {
      return (
        <span
          title={title}
          className="bg-surface-2 text-fg-subtle flex size-8 items-center justify-center rounded-lg"
        >
          <Lock className="size-4" />
          <span className="sr-only">{title}</span>
        </span>
      );
    }
    if (variant === "button") {
      return (
        <span
          title={title}
          className="bg-surface-2 text-fg-muted flex flex-1 items-center justify-center gap-2 rounded-lg py-3 text-sm font-semibold"
        >
          <Lock className="size-4" />
          Com {lead.blockedBy}
        </span>
      );
    }
    return (
      <span
        title={title}
        className="text-fg-subtle inline-flex items-center gap-1.5 whitespace-nowrap"
      >
        <Lock className="size-3.5 shrink-0" />
        Com {lead.blockedBy}
      </span>
    );
  }

  if (variant === "icon") {
    return (
      <a
        href={lead.whatsappUrl ?? "#"}
        target="_blank"
        rel="noopener noreferrer"
        onClick={record}
        title={`Abrir conversa com ${lead.name}`}
        className="flex size-8 items-center justify-center rounded-lg bg-[#1d2228] text-white transition hover:bg-black"
      >
        <MessageCircle className="size-4" />
        <span className="sr-only">Abrir WhatsApp</span>
      </a>
    );
  }

  // Full-width, 44px-tall: on the mobile card this is the primary action, so it
  // gets a thumb-sized button rather than the desktop row's inline text link.
  if (variant === "button") {
    return (
      <a
        href={lead.whatsappUrl ?? "#"}
        target="_blank"
        rel="noopener noreferrer"
        onClick={record}
        className="flex flex-1 items-center justify-center gap-2 rounded-lg bg-[#1d2228] py-3 text-sm font-semibold text-white transition hover:bg-black"
      >
        <MessageCircle className="size-4" />
        {lead.phone ? formatPhone(lead.phone) : "Abrir WhatsApp"}
      </a>
    );
  }

  return (
    <a
      href={lead.whatsappUrl ?? "#"}
      target="_blank"
      rel="noopener noreferrer"
      onClick={record}
      className="inline-flex items-center gap-1.5 whitespace-nowrap text-[#128C4A] hover:underline"
    >
      <MessageCircle className="size-3.5 shrink-0" />
      {lead.phone ? formatPhone(lead.phone) : "WhatsApp"}
    </a>
  );
}

/**
 * A phone is an outreach action too, not just a browser link. Recording the
 * click before handing it to the dialler is what makes call and message clicks
 * obey the same ownership rule and the same funnel inclusion rule.
 */
function PhoneLink({
  lead,
  variant,
}: {
  lead: CrmLead;
  variant: "icon" | "text" | "button" | "number";
}) {
  const router = useRouter();

  const record = () => {
    void fetch("/api/prospector/history/outreach", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id: lead.id, channel: "phone" }),
      keepalive: true,
    }).then(() => router.refresh());
  };

  if (!lead.phone) return null;

  if (lead.blockedBy) {
    const title = `Atendido por ${lead.blockedBy} — fale com ${lead.blockedBy} antes de ligar.`;
    return (
      <span
        title={title}
        className="bg-surface-2 text-fg-subtle inline-flex items-center gap-1.5 rounded-lg px-2 py-1 text-xs"
      >
        <Lock className="size-3.5" />
        Com {lead.blockedBy}
      </span>
    );
  }

  if (variant === "icon") {
    return (
      <a
        href={`tel:${lead.phone}`}
        onClick={record}
        title={`Ligar para ${lead.name}`}
        className="border-line text-fg-muted hover:border-line-strong hover:text-fg flex size-8 items-center justify-center rounded-lg border transition"
      >
        <Phone className="size-4" />
        <span className="sr-only">Ligar</span>
      </a>
    );
  }

  if (variant === "button") {
    return (
      <a
        href={`tel:${lead.phone}`}
        onClick={record}
        className="border-line text-fg-muted hover:border-line-strong flex flex-1 items-center justify-center gap-2 rounded-lg border py-3 text-sm font-medium"
      >
        <Phone className="size-4" />
        Ligar
      </a>
    );
  }

  return (
    <a
      href={`tel:${lead.phone}`}
      onClick={record}
      className="text-fg-muted hover:text-fg inline-flex items-center gap-1.5 text-xs whitespace-nowrap"
    >
      <Phone className="size-3.5 shrink-0" />
      {variant === "number" ? formatPhone(lead.phone) : "Ligar"}
    </a>
  );
}

/**
 * Saves on blur rather than on every keystroke: a note is written in one sitting,
 * and a request per character would be both wasteful and impossible to roll back
 * coherently. Escape restores the last saved value.
 */
function NoteEditor({
  value,
  onSave,
}: {
  value: string;
  onSave: (notes: string) => void;
}) {
  const [text, setText] = useState(value);
  const saved = useRef(value);

  const commit = () => {
    if (text === saved.current) return;
    saved.current = text;
    onSave(text);
  };

  return (
    <label className="block">
      <span className="text-fg-subtle mb-1.5 block text-xs font-medium tracking-wide uppercase">
        Anotações
      </span>
      <textarea
        value={text}
        rows={5}
        placeholder="O que foi conversado, objeções, o que tentar na próxima…"
        onChange={(event) => setText(event.target.value)}
        onBlur={commit}
        onKeyDown={(event) => {
          if (event.key === "Escape") {
            setText(saved.current);
            event.currentTarget.blur();
          }
          if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
            event.currentTarget.blur();
          }
        }}
        className="border-line bg-surface focus:border-brand w-full resize-y rounded-lg border px-3 py-2 text-sm outline-none"
      />
      <span className="text-fg-subtle mt-1 block text-xs">
        Salva ao sair do campo · Esc desfaz
      </span>
    </label>
  );
}

/** Same save-on-blur contract as the note editor, for a one-line field. */
function TextField({
  label,
  value,
  placeholder,
  onSave,
}: {
  label: string;
  value: string;
  placeholder?: string;
  onSave: (value: string) => void;
}) {
  const [text, setText] = useState(value);
  const saved = useRef(value);

  const commit = () => {
    if (text === saved.current) return;
    saved.current = text;
    onSave(text);
  };

  return (
    <label className="block">
      <span className="text-fg-subtle mb-1 block text-xs font-medium tracking-wide uppercase">
        {label}
      </span>
      <input
        value={text}
        placeholder={placeholder}
        onChange={(event) => setText(event.target.value)}
        onBlur={commit}
        onKeyDown={(event) => {
          if (event.key === "Escape") {
            setText(saved.current);
            event.currentTarget.blur();
          }
          if (event.key === "Enter") event.currentTarget.blur();
        }}
        className="border-line bg-surface focus:border-brand w-full rounded-lg border px-3 py-2 text-sm outline-none"
      />
    </label>
  );
}

/**
 * The social profiles for a business.
 *
 * Adds and removes save immediately — unlike a text field there is no
 * "half-typed" state worth waiting for, and a link you pasted that vanishes
 * because you clicked elsewhere is the more annoying failure. The server
 * re-parses every URL it is sent and rejects anything that isn't http(s), so a
 * rejected paste comes back as the row's warning triangle rather than as a link
 * nobody should click.
 *
 * The profile the provider found is shown alongside but not editable: it is part
 * of the lead record, not of what you typed.
 */
function SocialEditor({
  value,
  found,
  onSave,
}: {
  value: SocialLink[];
  found: string | null;
  onSave: (socials: SocialLink[]) => void;
}) {
  const [links, setLinks] = useState(value);
  const [draft, setDraft] = useState("");

  const commit = (next: SocialLink[]) => {
    setLinks(next);
    onSave(next);
  };

  function add() {
    const url = draft.trim();
    if (url.length === 0) return;
    // The platform label is the server's to decide; until it answers, the host
    // is a good enough guess and never renders as anything but text.
    const guess = url.replace(/^https?:\/\//i, "").replace(/^www\./, "");
    commit([...links, { platform: guess.split("/")[0] ?? "link", url }]);
    setDraft("");
  }

  return (
    <div>
      <span className="text-fg-subtle mb-1 block text-xs font-medium tracking-wide uppercase">
        Redes sociais
      </span>

      {found && (
        <a
          href={found}
          target="_blank"
          rel="noopener noreferrer"
          className="text-fg-muted hover:text-brand mb-1.5 inline-flex items-center gap-1.5 text-xs"
        >
          <Share2 className="size-3.5 shrink-0" />
          encontrada na busca
        </a>
      )}

      <ul className="space-y-1.5">
        {links.map((link, index) => (
          <li key={`${link.url}-${index}`} className="flex items-center gap-2">
            <a
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className="border-line bg-surface hover:border-brand min-w-0 flex-1 truncate rounded-lg border px-3 py-1.5 text-xs"
              title={link.url}
            >
              <span className="text-brand font-medium">{link.platform}</span>
              <span className="text-fg-muted"> · {link.url}</span>
            </a>
            <button
              type="button"
              onClick={() => commit(links.filter((_, i) => i !== index))}
              title="Remover"
              aria-label={`Remover ${link.url}`}
              className="border-line text-fg-muted flex size-7 shrink-0 items-center justify-center rounded-lg border transition hover:border-red-300 hover:bg-red-50 hover:text-red-700"
            >
              <X className="size-3.5" />
            </button>
          </li>
        ))}
      </ul>

      <div className="mt-1.5 flex items-center gap-2">
        <input
          value={draft}
          placeholder="instagram.com/negocio"
          onChange={(event) => setDraft(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter") {
              event.preventDefault();
              add();
            }
          }}
          className="border-line bg-surface focus:border-brand min-w-0 flex-1 rounded-lg border px-3 py-2 text-sm outline-none"
        />
        <button
          type="button"
          onClick={add}
          disabled={draft.trim().length === 0}
          className="border-line text-fg-muted hover:border-line-strong hover:text-fg flex size-9 shrink-0 items-center justify-center rounded-lg border transition disabled:opacity-40"
          title="Adicionar rede social"
          aria-label="Adicionar rede social"
        >
          <Plus className="size-4" />
        </button>
      </div>
    </div>
  );
}

/**
 * Mirrors MAX_TAGS / MAX_TAG_LENGTH in lib/prospector/tags.ts, which is the
 * authority — the route re-sanitises and rejects anything past them. Copied
 * rather than imported because tags.ts pulls in `normalise` from cities.ts,
 * and that module carries the 480KB city index; importing it here would ship
 * the whole thing to the browser to check a length.
 */
const MAX_TAGS = 12;
const MAX_TAG_LENGTH = 30;

/**
 * Case- and accent-insensitive comparison, so the client doesn't offer to add
 * a label the server will fold into one the lead already has. `tagKey` on the
 * server is the real rule; this is the affordance.
 */
function sameTag(a: string, b: string): boolean {
  const fold = (v: string) =>
    v
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, " ")
      .trim();
  return fold(a) === fold(b);
}

/** Read-only labels, for the collapsed row and the card. */
function TagChips({ tags }: { tags: string[] }) {
  if (tags.length === 0) return null;
  return (
    <span className="mt-1.5 flex flex-wrap gap-1">
      {tags.map((tag) => (
        <span
          key={tag}
          className="border-brand/30 bg-brand/10 text-brand inline-flex max-w-[14rem] items-center gap-1 truncate rounded-full border px-2 py-0.5 text-[11px] font-medium"
        >
          <Tag className="size-2.5 shrink-0" />
          {tag}
        </span>
      ))}
    </span>
  );
}

/**
 * Add and remove a lead's labels.
 *
 * Each change saves immediately rather than behind a button: a chip you added
 * and a chip that is saved look the same, so an explicit save step is a state
 * the row can't show you it is in.
 */
function TagEditor({
  value,
  onSave,
}: {
  value: string[];
  onSave: (tags: string[]) => void;
}) {
  const [tags, setTags] = useState(value);
  const [draft, setDraft] = useState("");

  const commit = (next: string[]) => {
    setTags(next);
    onSave(next);
  };

  function add() {
    const tag = draft.replace(/\s+/g, " ").trim().slice(0, MAX_TAG_LENGTH);
    if (tag.length === 0) return;
    // Clearing the box even when the tag is a duplicate: the label is on the
    // lead either way, and leaving the text behind reads as a failed add.
    setDraft("");
    if (tags.some((t) => sameTag(t, tag))) return;
    if (tags.length >= MAX_TAGS) return;
    commit([...tags, tag]);
  }

  const full = tags.length >= MAX_TAGS;

  return (
    <div>
      <span className="text-fg-subtle mb-1 block text-xs font-medium tracking-wide uppercase">
        Etiquetas
      </span>

      {tags.length > 0 && (
        <ul className="mb-1.5 flex flex-wrap gap-1.5">
          {tags.map((tag) => (
            <li key={tag}>
              <span className="border-brand/30 bg-brand/10 text-brand inline-flex items-center gap-1.5 rounded-full border py-1 pr-1 pl-2.5 text-xs font-medium">
                {tag}
                <button
                  type="button"
                  onClick={() => commit(tags.filter((t) => t !== tag))}
                  title={`Remover ${tag}`}
                  aria-label={`Remover etiqueta ${tag}`}
                  className="hover:bg-brand/20 flex size-4 items-center justify-center rounded-full transition"
                >
                  <X className="size-3" />
                </button>
              </span>
            </li>
          ))}
        </ul>
      )}

      <div className="flex items-center gap-2">
        <input
          value={draft}
          maxLength={MAX_TAG_LENGTH}
          disabled={full}
          placeholder={
            full ? `Máximo de ${MAX_TAGS} etiquetas` : "Orçamento enviado"
          }
          onChange={(event) => setDraft(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter") {
              event.preventDefault();
              add();
            }
          }}
          className="border-line bg-surface focus:border-brand min-w-0 flex-1 rounded-lg border px-3 py-2 text-sm outline-none disabled:opacity-50"
        />
        <button
          type="button"
          onClick={add}
          disabled={full || draft.trim().length === 0}
          className="border-line text-fg-muted hover:border-line-strong hover:text-fg flex size-9 shrink-0 items-center justify-center rounded-lg border transition disabled:opacity-40"
          title="Adicionar etiqueta"
          aria-label="Adicionar etiqueta"
        >
          <Plus className="size-4" />
        </button>
      </div>
    </div>
  );
}

/** The label box in the bulk bar. Local state, so it can clear on submit. */
function BulkTagBox({
  disabled,
  onAdd,
}: {
  disabled: boolean;
  onAdd: (tag: string) => void;
}) {
  const [draft, setDraft] = useState("");

  const submit = () => {
    if (draft.trim().length === 0) return;
    onAdd(draft);
    setDraft("");
  };

  return (
    <span className="flex items-center gap-1.5">
      <span className="text-slate-400">etiquetar</span>
      <input
        value={draft}
        maxLength={MAX_TAG_LENGTH}
        placeholder="nome da etiqueta"
        onChange={(event) => setDraft(event.target.value)}
        onKeyDown={(event) => {
          if (event.key === "Enter") {
            event.preventDefault();
            submit();
          }
        }}
        className="w-40 rounded-lg border border-[#2b333b] bg-white/10 px-2.5 py-2 text-sm text-white outline-none placeholder:text-slate-500 focus:border-slate-400 sm:py-1.5"
      />
      <button
        type="button"
        disabled={disabled || draft.trim().length === 0}
        onClick={submit}
        className="rounded-lg bg-white/10 px-3 py-2 font-medium transition hover:bg-white/20 disabled:opacity-50 sm:py-1.5"
      >
        aplicar
      </button>
    </span>
  );
}

function Detail({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <span className="text-fg-subtle block text-xs font-medium tracking-wide uppercase">
        {label}
      </span>
      <span className="text-fg-muted mt-0.5 block">{children}</span>
    </div>
  );
}

/**
 * `(31) 99981-9741` out of `+5531999819741`. The stored form is E.164 because
 * that is what wa.me and a dialer need; it is not what anyone reads a list of
 * phone numbers in. Anything that isn't a Brazilian number is left alone rather
 * than forced into a shape it doesn't have.
 */
function formatPhone(phone: string): string {
  const match = /^\+55(\d{2})(\d{4,5})(\d{4})$/.exec(phone);
  return match ? `(${match[1]}) ${match[2]}-${match[3]}` : phone;
}

/** Local date in YYYY-MM-DD, to compare against the stored follow-up date. */
function today(): string {
  const now = new Date();
  const local = new Date(now.getTime() - now.getTimezoneOffset() * 60_000);
  return local.toISOString().slice(0, 10);
}

function shortDate(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso.slice(0, 10);
  return date.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "2-digit",
  });
}
