"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Bot, Loader2, TriangleAlert, X } from "lucide-react";

/**
 * The schedule, with the one control it needs: stop.
 *
 * Not optimistic. Cancelling a message that is about to go to a customer is the
 * kind of action where "it looked like it worked" is not good enough — the row
 * disappears only once the server has said it is gone.
 */

export type ScheduledJob = {
  id: string;
  conversationId: string;
  who: string;
  /** Already rendered by the server: a date, or a cron in plain Portuguese. */
  when: string;
  body: string;
  reason: string | null;
  runs: number;
  maxRuns: number | null;
  byAgent: boolean;
  lastError: string | null;
};

export function JobList({ jobs }: { jobs: ScheduledJob[] }) {
  const router = useRouter();
  const [, startTransition] = useTransition();
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  function cancel(id: string) {
    setError(null);
    setBusy(id);
    startTransition(async () => {
      try {
        const res = await fetch("/api/admin/whatsapp/jobs", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ intent: "cancelar", jobId: id }),
        });
        const body = (await res.json()) as { error?: string };
        if (!res.ok) setError(body.error ?? "Não foi possível cancelar.");
        else router.refresh();
      } catch {
        setError("Falha de rede ao cancelar.");
      } finally {
        setBusy(null);
      }
    });
  }

  return (
    <>
      {error && (
        <p className="border-line text-fg border-b px-5 py-2.5 text-sm">
          {error}
        </p>
      )}
      <ul className="divide-line divide-y">
        {jobs.map((job) => (
          <li key={job.id} className="flex items-start gap-4 px-5 py-3.5">
            <div className="min-w-0 flex-1">
              <p className="flex flex-wrap items-center gap-2 text-sm font-medium">
                <Link
                  href={`/admin/whatsapp/${job.conversationId}`}
                  className="hover:underline"
                >
                  {job.who}
                </Link>
                <span className="text-fg-subtle font-normal">· {job.when}</span>
                {job.byAgent && (
                  <span className="text-fg-subtle border-line flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-normal">
                    <Bot className="size-3" />
                    assistente
                  </span>
                )}
                {job.maxRuns !== null && job.maxRuns > 1 && (
                  <span className="text-fg-subtle text-[11px] font-normal">
                    {job.runs}/{job.maxRuns}
                  </span>
                )}
              </p>
              <p className="text-fg-muted mt-1 text-sm">{job.body}</p>
              {job.reason && (
                <p className="text-fg-subtle mt-0.5 text-xs">{job.reason}</p>
              )}
              {/* The last failure is shown on the row rather than in a log.
                  A reminder that quietly stopped sending is invisible
                  everywhere else. */}
              {job.lastError && (
                <p className="text-fg-subtle mt-1 flex items-start gap-1.5 text-xs">
                  <TriangleAlert className="mt-0.5 size-3 shrink-0" />
                  {job.lastError}
                </p>
              )}
            </div>
            <button
              type="button"
              onClick={() => cancel(job.id)}
              disabled={busy === job.id}
              title="Cancelar"
              aria-label={`Cancelar mensagem programada para ${job.who}`}
              className="text-fg-muted hover:bg-surface-raised hover:text-fg flex size-9 shrink-0 items-center justify-center rounded-xl transition disabled:opacity-50"
            >
              {busy === job.id ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <X className="size-4" />
              )}
            </button>
          </li>
        ))}
      </ul>
    </>
  );
}
