"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { AlertTriangle, Loader2 } from "lucide-react";
import {
  OUTCOME_LABEL,
  PENDING_STATUS,
  REVIEW_STATUS_LABEL,
  type MeetingOutcome,
  type ReviewStatus,
} from "@/lib/review/types";

export type ReviewSummary = {
  id: string;
  title: string;
  status: ReviewStatus;
  outcome: MeetingOutcome;
  actorName: string;
  durationSeconds: number | null;
  error: string | null;
  createdAt: string;
  notaGeral: number | null;
};

/**
 * The list, which polls while anything is unfinished and stops when nothing is.
 *
 * Polling rather than a stream: transcription takes minutes and reports no
 * intermediate progress worth pushing, so a websocket would carry three state
 * changes over ten minutes and need a reconnect story for each. Five seconds is
 * fast enough for a step measured in minutes, and the interval is torn down when
 * every row is finished so an idle tab is not asking forever.
 */
export function MeetingList({
  initial,
  /** Where a row links to. The same list is mounted under /admin and /operador. */
  basePath,
}: {
  initial: ReviewSummary[];
  basePath: string;
}) {
  const router = useRouter();
  // Null until a poll has answered, and the render prefers it when it exists.
  // Copying the prop into state and re-syncing it in an effect is the same idea
  // with a cascading render attached — and it silently drops a poll that landed
  // between two server renders.
  const [polled, setPolled] = useState<ReviewSummary[] | null>(null);

  const reviews = polled ?? initial;
  const pending = reviews.some((r) => PENDING_STATUS.includes(r.status));

  useEffect(() => {
    if (!pending) return;

    const timer = setInterval(async () => {
      try {
        const response = await fetch("/api/review", { cache: "no-store" });
        if (!response.ok) return;
        const data = (await response.json()) as { reviews: ReviewSummary[] };
        setPolled(data.reviews);
        // Refresh the server component too, so a finished review has its full
        // page ready the moment the row becomes a link worth clicking.
        if (!data.reviews.some((r) => PENDING_STATUS.includes(r.status)))
          router.refresh();
      } catch {
        // A failed poll is the next poll's problem. Surfacing it would put a
        // network error on screen every time a laptop sleeps.
      }
    }, 5000);

    return () => clearInterval(timer);
  }, [pending, router]);

  if (reviews.length === 0) {
    return (
      <p className="text-fg-muted border-line mt-6 rounded-2xl border border-dashed px-5 py-10 text-center text-sm">
        Nenhuma reunião enviada ainda.
      </p>
    );
  }

  return (
    <ul className="mt-6 space-y-2">
      {reviews.map((review) => {
        const working = PENDING_STATUS.includes(review.status);
        const failed = review.status === "erro";

        return (
          <li key={review.id}>
            <Link
              href={`${basePath}/${review.id}`}
              className="border-line bg-surface hover:bg-surface-raised flex flex-wrap items-center gap-x-4 gap-y-2 rounded-2xl border px-5 py-4 transition"
            >
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{review.title}</p>
                <p className="text-fg-subtle mt-0.5 text-xs">
                  {review.actorName} ·{" "}
                  {new Date(review.createdAt).toLocaleString("pt-BR", {
                    dateStyle: "short",
                    timeStyle: "short",
                  })}
                  {review.durationSeconds
                    ? ` · ${Math.round(review.durationSeconds / 60)} min`
                    : ""}
                </p>
              </div>

              <span className="border-line text-fg-muted rounded-lg border px-2 py-1 text-xs">
                {OUTCOME_LABEL[review.outcome]}
              </span>

              {review.notaGeral !== null && (
                <span className="text-sm font-semibold tabular-nums">
                  {review.notaGeral.toFixed(1)}
                  <span className="text-fg-subtle text-xs font-normal">
                    /10
                  </span>
                </span>
              )}

              <span
                className={`inline-flex items-center gap-1.5 text-xs ${
                  failed ? "text-red-500" : "text-fg-muted"
                }`}
              >
                {working && <Loader2 className="size-3.5 animate-spin" />}
                {failed && <AlertTriangle className="size-3.5" />}
                {REVIEW_STATUS_LABEL[review.status]}
              </span>
            </Link>
          </li>
        );
      })}
    </ul>
  );
}
