"use client";

import { useState } from "react";
import { Check, Copy } from "lucide-react";

/**
 * The copy-paste half of an account's handover page.
 *
 * A client's site lives in its own repository on whatever host we picked that
 * month, so nothing here can assume a framework, a build step or a shared
 * package. Everything the other repo needs is therefore text: a script tag, two
 * environment variables and one HTTP call. That is the whole integration
 * surface, and keeping it that small is what makes it survive a site we hand to
 * someone else to maintain.
 *
 * Client component only for the copy buttons — the content is composed on the
 * server, where the site keys already are.
 */

export function CopyBlock({
  label,
  hint,
  code,
  language = "html",
  scroll = false,
  action,
}: {
  label: string;
  hint?: string;
  code: string;
  language?: string;
  /** Caps the height for long files, so one block can't own the whole page. */
  scroll?: boolean;
  /** An extra control beside Copiar — a download link, typically. */
  action?: React.ReactNode;
}) {
  const [copied, setCopied] = useState(false);

  async function copy() {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      // Clipboard access is refused on insecure origins and in some browsers.
      // The block is on screen and selectable either way, so a failed copy is
      // not worth an error state — the same call the site manager already makes.
    }
  }

  return (
    <div className="border-line bg-surface overflow-hidden rounded-xl border">
      <div className="border-line flex items-center justify-between gap-3 border-b px-4 py-2.5">
        <div className="min-w-0">
          <p className="text-sm font-medium">{label}</p>
          {hint && (
            <p className="text-fg-subtle mt-0.5 text-xs leading-5">{hint}</p>
          )}
        </div>
        <div className="flex shrink-0 items-center gap-1.5">
          {action}
          <button
            type="button"
            onClick={copy}
            className="border-line hover:border-brand text-fg-muted hover:text-fg inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs transition"
          >
            {copied ? (
              <>
                <Check className="size-3.5" />
                Copiado
              </>
            ) : (
              <>
                <Copy className="size-3.5" />
                Copiar
              </>
            )}
          </button>
        </div>
      </div>
      {/* Its own scroll container: a long key or URL must not push the page
          sideways, which is the one layout failure a copy block reliably causes. */}
      <pre
        className={`bg-surface-2 overflow-x-auto px-4 py-3 text-xs leading-6 ${
          scroll ? "max-h-80 overflow-y-auto" : ""
        }`}
      >
        <code data-language={language}>{code}</code>
      </pre>
    </div>
  );
}
