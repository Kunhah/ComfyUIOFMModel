"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  Check,
  Copy,
  Globe,
  Loader2,
  Plus,
  Power,
  RotateCcw,
  Trash2,
} from "lucide-react";
import { COUNTRIES } from "@/lib/countries";

/**
 * The plug-in point, managed.
 *
 * Not optimistic, for the same reason `UserManager` isn't: creating a site fails
 * for reasons the browser can't predict (a domain that doesn't parse, a name
 * already in use) and the server's message is the useful one. Every action waits
 * and says what happened.
 *
 * The snippet is shown ready to paste rather than described. A install
 * instruction a person has to assemble from three fields is an install
 * instruction that gets assembled wrong.
 */

export type ManagedSite = {
  id: string;
  key: string;
  name: string;
  origins: string[];
  country: string;
  active: boolean;
  createdAt: string;
  createdBy: string;
  lastLeadAt: string | null;
  leadCount: number;
  /** The client whose pipeline this form fills. Null for one of our own sites. */
  accountId: string | null;
};

/** Just enough of an account to offer it in the picker. */
export type SiteAccount = { id: string; name: string };

export function SiteManager({
  sites,
  accounts,
  scriptOrigin,
}: {
  sites: ManagedSite[];
  /**
   * The client accounts a site can be filed under.
   *
   * This picker is load-bearing rather than convenient. A site with no account
   * writes its leads to `account_id = NULL`, which means *ours* — so a form
   * built for a client but filed under nobody fills our pipeline instead of
   * theirs, their portal stays empty, and nothing anywhere reports it. The
   * field is on the create form for that reason, and the list prints the
   * account beside every site so a misfiled one is visible.
   */
  accounts: SiteAccount[];
  /**
   * Where this CRM answers from, resolved on the server from the request. The
   * snippet has to name an absolute URL — it is pasted into someone else's
   * site — and guessing it in the browser would print `localhost` into an
   * instruction meant for production.
   */
  scriptOrigin: string;
}) {
  const router = useRouter();
  // Built once rather than searched per row: the list renders every site and
  // would otherwise scan the accounts array for each one.
  const accountName = new Map(accounts.map((a) => [a.id, a.name]));
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);

  /** Every mutation goes through here so failures surface the same way. */
  function send(
    url: string,
    init: RequestInit,
    onSuccess: string,
    id?: string,
  ) {
    setError(null);
    setNotice(null);
    setBusy(id ?? "form");

    startTransition(async () => {
      try {
        const res = await fetch(url, {
          headers: { "content-type": "application/json" },
          ...init,
        });
        const payload = (await res.json().catch(() => ({}))) as {
          error?: string;
        };
        if (!res.ok) throw new Error(payload.error ?? `Erro ${res.status}`);
        setNotice(onSuccess);
        router.refresh();
      } catch (cause) {
        setError(cause instanceof Error ? cause.message : "Falha na operação.");
      } finally {
        setBusy(null);
      }
    });
  }

  function create(form: FormData) {
    // One domain per line is what people actually paste — a comma-separated list
    // invites a stray space, and a textarea shows all of them at once.
    const origins = String(form.get("origins") ?? "")
      .split(/[\n,]/)
      .map((origin) => origin.trim())
      .filter(Boolean);

    send(
      "/api/admin/sites",
      {
        method: "POST",
        body: JSON.stringify({
          name: form.get("name"),
          country: form.get("country"),
          // "" is our own site, which the route turns into null. Sent
          // explicitly rather than omitted, so "nobody" is a choice someone
          // made on the form instead of a field that failed to serialise.
          accountId: form.get("accountId") || "",
          origins,
        }),
      },
      "Site criado. Cole o trecho abaixo no site do cliente.",
    );
  }

  const toggle = (site: ManagedSite) =>
    send(
      `/api/admin/sites/${site.id}`,
      { method: "PATCH", body: JSON.stringify({ active: !site.active }) },
      site.active
        ? `${site.name} desativado. O formulário para de enviar, mas o trecho continua instalado.`
        : `${site.name} reativado.`,
      site.id,
    );

  const rotate = (site: ManagedSite) => {
    if (
      !confirm(
        `Gerar uma chave nova para ${site.name}?\n\nO formulário do cliente para de funcionar até que o trecho no site dele seja atualizado com a chave nova.`,
      )
    ) {
      return;
    }
    send(
      `/api/admin/sites/${site.id}`,
      { method: "PATCH", body: JSON.stringify({ rotate: true }) },
      `Chave de ${site.name} trocada. Atualize o trecho no site do cliente.`,
      site.id,
    );
  };

  const remove = (site: ManagedSite) => {
    if (
      !confirm(
        `Excluir ${site.name}?\n\nOs leads que este site já trouxe continuam no CRM. O que para é a entrada de novos.`,
      )
    ) {
      return;
    }
    send(
      `/api/admin/sites/${site.id}`,
      { method: "DELETE" },
      `${site.name} excluído. Os leads que ele trouxe continuam no CRM.`,
      site.id,
    );
  };

  function snippetFor(site: ManagedSite): string {
    return [
      `<form data-atlas-crm>`,
      `  <input name="nome" required placeholder="Seu nome">`,
      `  <input name="email" type="email" placeholder="Seu e-mail">`,
      `  <input name="telefone" placeholder="WhatsApp">`,
      `  <textarea name="mensagem" placeholder="Como podemos ajudar?"></textarea>`,
      `  <button type="submit">Enviar</button>`,
      `</form>`,
      ``,
      `<script src="${scriptOrigin}/atlas-crm.js" data-key="${site.key}"></script>`,
    ].join("\n");
  }

  async function copy(text: string, id: string) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(id);
      window.setTimeout(() => setCopied(null), 2000);
    } catch {
      // Clipboard access is refused over plain HTTP and in some embedded
      // browsers. The snippet is on screen and selectable either way, so this
      // says so rather than failing silently.
      setError("O navegador não liberou a área de transferência. Copie à mão.");
    }
  }

  return (
    <>
      <form
        action={create}
        className="border-line bg-surface mt-7 rounded-2xl border p-5"
      >
        <h2 className="text-lg font-semibold">Novo site</h2>
        <p className="text-fg-muted mt-1 text-sm">
          Um por site do cliente, não um por cliente — quem tem uma landing page
          e um site principal quer saber qual das duas converteu.
        </p>

        <div className="mt-4 grid gap-3 md:grid-cols-[1fr_1fr_1fr_auto]">
          <Field label="Nome" hint="como você reconhece o cliente">
            <input
              name="name"
              required
              minLength={2}
              placeholder="Padaria do Zé"
              className="border-line bg-surface-2 focus:border-brand w-full rounded-lg border px-3 py-2.5 text-sm outline-none"
            />
          </Field>
          <Field label="País" hint="decide o link de WhatsApp">
            <select
              name="country"
              defaultValue="BR"
              className="border-line bg-surface-2 focus:border-brand w-full rounded-lg border px-3 py-2.5 text-sm outline-none"
            >
              {COUNTRIES.map((country) => (
                <option key={country.code} value={country.code}>
                  {country.label}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Conta" hint="de quem são os leads deste site">
            <select
              name="accountId"
              defaultValue=""
              className="border-line bg-surface-2 focus:border-brand w-full rounded-lg border px-3 py-2.5 text-sm outline-none"
            >
              {/* Deliberately not preselected to the first client. "Atlas" is
                  the honest default for a site nobody has named an owner for,
                  and it is the one choice that cannot silently misfile another
                  client's enquiries. */}
              <option value="">Atlas (nossos próprios leads)</option>
              {accounts.map((account) => (
                <option key={account.id} value={account.id}>
                  {account.name}
                </option>
              ))}
            </select>
          </Field>
          <button
            type="submit"
            disabled={pending}
            className="mt-auto inline-flex items-center justify-center gap-2 rounded-lg bg-[#1d2228] px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-black disabled:opacity-60"
          >
            {busy === "form" ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <Plus className="size-4" />
            )}
            Criar
          </button>
        </div>

        <div className="mt-3">
          <Field label="Domínios autorizados" hint="um por linha, com https://">
            <textarea
              name="origins"
              required
              rows={2}
              spellCheck={false}
              placeholder={
                "https://padariadoze.com.br\nhttps://www.padariadoze.com.br"
              }
              className="border-line bg-surface-2 focus:border-brand w-full rounded-lg border px-3 py-2.5 font-mono text-sm outline-none"
            />
          </Field>
          {/* The `www` trap is worth naming: a browser sends the exact origin it
              is on, so a site that answers on both and is only allowlisted on
              one has a form that works for half its visitors. */}
          <p className="text-fg-subtle mt-2 text-xs">
            É o endereço exato que o navegador envia. Se o site atende em{" "}
            <code className="text-[11px]">com</code> e em{" "}
            <code className="text-[11px]">www.com</code>, liste os dois — senão
            o formulário funciona só para metade dos visitantes.
          </p>
        </div>
      </form>

      {error && (
        <p className="mt-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
          {error}
        </p>
      )}
      {notice && !error && (
        <p className="border-brand/30 bg-brand/10 text-brand mt-4 rounded-xl border px-4 py-3 text-sm font-medium">
          {notice}
        </p>
      )}

      <section className="border-line bg-surface mt-4 overflow-hidden rounded-2xl border">
        <div className="px-5 py-4">
          <h2 className="text-lg font-semibold">Sites conectados</h2>
          <p className="text-fg-muted mt-0.5 text-sm">
            {sites.length === 0
              ? "Nenhum site conectado ainda."
              : `${sites.length} ${sites.length === 1 ? "site" : "sites"} enviando leads para este CRM`}
          </p>
        </div>

        {sites.length > 0 && (
          <ul className="divide-line border-line divide-y border-t">
            {sites.map((site) => {
              const open = expanded === site.id;
              const snippet = snippetFor(site);
              return (
                <li key={site.id} className={site.active ? "" : "opacity-60"}>
                  <div className="flex flex-wrap items-start gap-3 px-5 py-4">
                    <span className="bg-brand/10 text-brand flex size-10 shrink-0 items-center justify-center rounded-xl">
                      <Globe className="size-5" />
                    </span>

                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="font-medium">{site.name}</p>
                        <span
                          className={`rounded-full border px-2.5 py-0.5 text-xs font-medium ${
                            site.active
                              ? "border-emerald-300 bg-emerald-50 text-emerald-800"
                              : "border-line bg-surface-2 text-fg-muted"
                          }`}
                        >
                          {site.active ? "Ativo" : "Desativado"}
                        </span>
                        {/* Whose leads these are, on every row. A site filed
                            under Atlas by mistake is otherwise indistinguishable
                            from one filed correctly, and the symptom — the
                            client's portal staying empty — shows up somewhere
                            else entirely, weeks later. */}
                        <span
                          className={`rounded-full border px-2.5 py-0.5 text-xs font-medium ${
                            site.accountId
                              ? "border-line bg-surface-2 text-fg-muted"
                              : "border-amber-300 bg-amber-50 text-amber-900"
                          }`}
                        >
                          {site.accountId
                            ? (accountName.get(site.accountId) ??
                              "Conta removida")
                            : "Atlas"}
                        </span>
                      </div>
                      <p className="text-fg-subtle mt-0.5 truncate text-xs">
                        {site.origins.join(" · ")}
                      </p>
                      {/* "Never" is the interesting state and gets the word: a
                          site with the snippet not yet pasted looks exactly like
                          a site nobody has written to, and only one of those is
                          something to go and fix. */}
                      <p className="text-fg-muted mt-1 text-xs">
                        {site.leadCount === 0
                          ? "Nenhum lead ainda — confira se o trecho foi colado no site."
                          : `${site.leadCount} ${site.leadCount === 1 ? "lead" : "leads"} · último em ${shortDate(site.lastLeadAt)}`}
                      </p>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {busy === site.id && (
                        <Loader2 className="text-fg-subtle size-4 animate-spin" />
                      )}
                      <button
                        type="button"
                        onClick={() => setExpanded(open ? null : site.id)}
                        aria-expanded={open}
                        className="border-line hover:border-line-strong rounded-lg border px-3 py-2 text-xs font-medium transition"
                      >
                        {open ? "Ocultar" : "Instalar"}
                      </button>
                      <IconButton
                        label={site.active ? "Desativar" : "Reativar"}
                        onClick={() => toggle(site)}
                        disabled={pending}
                      >
                        <Power className="size-4" />
                      </IconButton>
                      <IconButton
                        label="Trocar a chave"
                        onClick={() => rotate(site)}
                        disabled={pending}
                      >
                        <RotateCcw className="size-4" />
                      </IconButton>
                      <IconButton
                        label="Excluir"
                        onClick={() => remove(site)}
                        disabled={pending}
                        danger
                      >
                        <Trash2 className="size-4" />
                      </IconButton>
                    </div>
                  </div>

                  {open && (
                    <div className="bg-surface-2 border-line border-t px-5 py-4">
                      <div className="flex items-center justify-between gap-3">
                        <p className="text-sm font-medium">
                          Cole antes de{" "}
                          <code className="text-xs">&lt;/body&gt;</code> no site
                          do cliente
                        </p>
                        <button
                          type="button"
                          onClick={() => copy(snippet, site.id)}
                          className="border-line hover:border-line-strong inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition"
                        >
                          {copied === site.id ? (
                            <Check className="size-3.5" />
                          ) : (
                            <Copy className="size-3.5" />
                          )}
                          {copied === site.id ? "Copiado" : "Copiar"}
                        </button>
                      </div>
                      <pre className="border-line bg-surface mt-2 overflow-x-auto rounded-xl border p-4 text-xs leading-relaxed">
                        <code>{snippet}</code>
                      </pre>
                      <p className="text-fg-subtle mt-2 text-xs">
                        Os campos podem ter os nomes que o site já usa —{" "}
                        <code className="text-[11px]">nome</code>,{" "}
                        <code className="text-[11px]">name</code>,{" "}
                        <code className="text-[11px]">telefone</code> e{" "}
                        <code className="text-[11px]">phone</code> chegam no
                        mesmo lugar. Qualquer campo extra vira uma linha na
                        anotação do lead.
                      </p>
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </>
  );
}

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="text-fg-muted text-xs font-medium">
        {label}
        {hint && <span className="text-fg-subtle font-normal"> · {hint}</span>}
      </span>
      <span className="mt-1.5 block">{children}</span>
    </label>
  );
}

function IconButton({
  label,
  onClick,
  disabled,
  danger,
  children,
}: {
  label: string;
  onClick: () => void;
  disabled?: boolean;
  danger?: boolean;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      title={label}
      aria-label={label}
      className={`border-line rounded-lg border p-2 transition disabled:opacity-50 ${
        danger
          ? "text-red-700 hover:border-red-300 hover:bg-red-50"
          : "text-fg-muted hover:border-line-strong hover:text-fg"
      }`}
    >
      {children}
    </button>
  );
}

function shortDate(value: string | null): string {
  if (!value) return "nunca";
  return new Date(value).toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "2-digit",
  });
}
