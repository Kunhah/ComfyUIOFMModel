"use client";

import { useRef, useState } from "react";
import {
  motion,
  useScroll,
  useMotionValueEvent,
  useSpring,
  useTransform,
} from "motion/react";
import { rota } from "@/content/rede";
import { Container } from "@/components/ui/container";
import { Lamp, PlateCode } from "@/components/rede/plate";
import { cn } from "@/lib/utils";

/**
 * The run: seven pull-boxes along one cable.
 *
 * Vertical rather than a row of columns. Seven abreast squeezed every step to
 * about 150px and broke the words, and wrapping them into two rows turns the
 * section into exactly the card grid this page's thesis refuses.
 *
 * The steps carry no plate fill and no shadow. A filled, shadowed box beside a
 * hairline conductor inverts the section: the boxes become the subject and the
 * run becomes decoration in the gutter, which is the card grid again wearing a
 * cable. The conductor and its taps are the dominant object; each step is an
 * ID field, a name and a measure hung off it.
 *
 * The numbers stay because the sequence is the information: someone asking
 * "what actually happens after I call" needs the order, not a set of themes.
 *
 * ── The pull ───────────────────────────────────────────────────────────────
 *
 * The section is called "how the network is pulled" and used to be the most
 * inert thing on the page: seven boxes on a cable that was never energized.
 * The reader now pulls it. Scrolling drives the cable's energized length down
 * the run, and each box latches as the head reaches its tap — so the order the
 * copy insists on is the order the reader physically performs, and a step that
 * has not been reached is visibly not carrying yet.
 *
 * This is scroll *position*, not a scroll-triggered animation: scrolling back
 * up de-energizes the run again, because a claim about sequence that only
 * works in one direction is a cutscene. Reduced motion keeps all of it — the
 * fill is a position, not a loop — and only loses the spring's smoothing.
 */
export function Rota() {
  const runRef = useRef<HTMLOListElement>(null);
  const [reached, setReached] = useState(0);

  // Starts as the first tap clears the lower third and completes as the last
  // one passes the middle, so the run is energizing through the whole time the
  // section owns the screen rather than finishing while it is still arriving.
  const { scrollYProgress } = useScroll({
    target: runRef,
    offset: ["start 72%", "end 62%"],
  });

  // Wheel scroll arrives in coarse jumps; the same treatment the hero gives its
  // pin, for the same reason — an unsmoothed head advances in visible steps.
  const progress = useSpring(scrollYProgress, {
    stiffness: 150,
    damping: 32,
    mass: 0.3,
    restDelta: 0.001,
  });

  // The energized length is continuous, because the cable is being pulled and
  // a head that jumps between seven fixed heights is a progress bar. Only the
  // boxes latch.
  const energized = useTransform(
    progress,
    (v) => `${Math.max(0, Math.min(1, v)) * 100}%`,
  );

  useMotionValueEvent(progress, "change", (v) => {
    // A tap latches as the head arrives at it, which is the midpoint of its own
    // band rather than the top — a lamp lighting the instant the head enters
    // the band lights a step early the whole way down.
    const next = Math.max(
      0,
      Math.min(rota.length, Math.round(v * rota.length + 0.18)),
    );
    setReached((prev) => (prev === next ? prev : next));
  });

  return (
    <section
      id="rota"
      data-section="rota"
      data-tone="light"
      className="bg-surface text-fg relative overflow-hidden py-20 sm:py-28"
    >
      <Container size="wide">
        <div className="max-w-[38rem]">
          <h2 className="font-display text-[clamp(1.9rem,4vw,3.1rem)] leading-[1.02] font-extrabold tracking-[-0.03em]">
            Como a rede é puxada.
          </h2>
          <p className="text-fg-muted mt-5 max-w-[54ch] text-[15px] leading-relaxed">
            Sete etapas, na ordem em que acontecem. Nenhuma delas começa antes
            de a anterior estar carregando.
          </p>
        </div>

        <ol ref={runRef} className="relative mt-12 sm:mt-16">
          {/* The run itself, threading every box on the way down. */}
          <span
            aria-hidden
            className="conductor absolute top-3 bottom-3 left-[4px] w-[3px] rounded-full sm:left-[5px]"
          >
            {/* The energized length. Its height is the reader's scroll itself,
                and the head sits at the bottom of it — the cable is being
                pulled, so the bright end is where the work currently is. */}
            <motion.span
              className="absolute inset-x-0 top-0 origin-top rounded-full bg-[linear-gradient(180deg,rgb(243_163_58/0.45),rgb(243_163_58/0.85)_78%,rgb(255_216_160))]"
              style={{ height: energized }}
            />
          </span>

          {rota.map((step, i) => {
            const live = i < reached;

            return (
              <li
                key={step.step}
                className="relative grid grid-cols-[auto_minmax(0,1fr)] items-start gap-x-6 border-b border-[var(--line)] py-6 last:border-b-0 sm:gap-x-10"
              >
                {/* The tap where this box sits on the run. The conductor and
                    its lamps are the section; the step is a field hung off
                    them, not a card floating beside them. */}
                <span
                  aria-hidden
                  className={cn(
                    "ease-out-soft relative z-10 mt-2 block size-[11px] shrink-0 rounded-full border-[3px] border-[var(--surface)] transition-[background-color,box-shadow,transform] duration-500 sm:size-[13px]",
                    live
                      ? "bg-brand-500 scale-100 shadow-[0_0_0_1px_rgb(168_95_9/0.4),0_0_12px_2px_rgb(243_163_58/0.45)]"
                      : "scale-[0.82] bg-[var(--line-strong)] shadow-none",
                  )}
                />

                <div className="flex flex-col gap-x-8 gap-y-2 sm:flex-row sm:items-baseline">
                  <div className="flex items-baseline gap-4 sm:contents">
                    <PlateCode live={live} className="shrink-0 sm:w-12">
                      {step.step}
                    </PlateCode>
                    <h3
                      className={cn(
                        "font-display text-lg leading-tight font-bold tracking-[-0.02em] transition-colors duration-500 sm:w-44 sm:shrink-0",
                        live ? "text-fg" : "text-fg-subtle",
                      )}
                    >
                      {step.name}
                    </h3>
                  </div>
                  <p
                    className={cn(
                      "max-w-[62ch] text-sm leading-relaxed transition-colors duration-500",
                      live ? "text-fg-muted" : "text-fg-subtle",
                    )}
                  >
                    {step.text}
                  </p>
                </div>
              </li>
            );
          })}
        </ol>

        {/* What the run is worth once it is all the way down. It reports the
            reader's own position rather than asserting anything, so it cannot
            become a fabricated metric. */}
        <p className="text-fg-subtle mt-8 flex items-center gap-3 font-mono text-[10px] tracking-[0.2em] uppercase">
          <Lamp live={reached >= rota.length} load={reached >= rota.length} />
          {reached >= rota.length
            ? "Rota completa · 7 de 7 sob carga"
            : `Puxando · ${reached} de ${rota.length}`}
        </p>
      </Container>
    </section>
  );
}
