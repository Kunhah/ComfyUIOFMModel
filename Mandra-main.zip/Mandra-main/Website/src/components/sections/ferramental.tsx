import { techStack } from "@/content/tech";
import { Container } from "@/components/ui/container";
import { Bolts, Lamp, PlateCode } from "@/components/rede/plate";

/**
 * The tooling, returned to the page.
 *
 * This is the one section written for the technical evaluator rather than for
 * the owner, so it sits deep and stays terse: a rack of marks, named, with no
 * claim attached to any of them. On the night ground because it belongs to the
 * hardware register — this is what the rede is built out of, not a drawing of
 * it.
 *
 * Brand marks keep their own colours at rest and come up to full strength on
 * hover, which is the one place on this page a colour other than amber is
 * allowed to appear: a logo is evidence, not decoration, and repainting them
 * amber would misrepresent them.
 */
export function Ferramental() {
  return (
    <section
      id="ferramental"
      data-section="ferramental"
      data-tone="night"
      className="bg-surface text-fg relative py-20 sm:py-28"
    >
      <Container size="wide">
        <div className="grid gap-12 lg:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)] lg:gap-16">
          <div>
            <h2 className="font-display text-[clamp(1.9rem,4vw,3.1rem)] leading-[1.02] font-extrabold tracking-[-0.03em]">
              Do que a rede é feita.
            </h2>
            <p className="text-fg-muted mt-5 max-w-[46ch] text-[15px] leading-relaxed">
              Ferramentas de mercado, escolhidas porque outra equipe consegue
              assumir o que construímos. Nada aqui é proprietário nosso.
            </p>
            <div className="mt-6 flex items-center gap-3">
              <Lamp live />
              <PlateCode live>STK-00 · 12 terminais</PlateCode>
            </div>
          </div>

          <div className="plate relative rounded-[4px] p-3 sm:p-4">
            <Bolts />
            <ul className="recess grid grid-cols-2 gap-px rounded-[3px] sm:grid-cols-3 lg:grid-cols-4">
              {techStack.map((tech) => (
                <li
                  key={tech.name}
                  className="group relative flex items-center gap-3 border-b border-white/[0.05] px-4 py-4 transition-colors duration-200 hover:bg-white/[0.025]"
                >
                  {/* The tap on this terminal's edge. A rack of twelve needs no
                    more interaction than telling you which one you are on, and
                    a lit edge is how a real one does it — the section is
                    evidence, not a toy. */}
                  <span
                    aria-hidden
                    className="bg-brand-400 ease-out-soft absolute inset-y-2 left-0 w-[2px] origin-center scale-y-0 rounded-full opacity-0 transition-[transform,opacity] duration-300 group-hover:scale-y-100 group-hover:opacity-100"
                  />
                  {tech.path ? (
                    <svg
                      viewBox="0 0 24 24"
                      aria-hidden
                      className="size-5 shrink-0 opacity-55 transition-opacity duration-200 group-hover:opacity-100"
                      style={{ fill: `#${tech.hex}` }}
                    >
                      <path d={tech.path} />
                    </svg>
                  ) : (
                    <span
                      aria-hidden
                      className="grid size-5 shrink-0 place-items-center font-mono text-[10px] font-bold opacity-55 transition-opacity duration-200 group-hover:opacity-100"
                      style={{ color: `#${tech.hex}` }}
                    >
                      {tech.name.slice(0, 3)}
                    </span>
                  )}
                  <span className="text-fg-muted group-hover:text-fg truncate text-[13px] font-medium transition-colors duration-200">
                    {tech.name}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Container>
    </section>
  );
}
