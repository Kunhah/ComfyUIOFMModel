import { ArrowRight } from "lucide-react";
import { HeroPin, HeroPhase } from "@/components/motion/hero-pin";
import { lines } from "@/content/rede";
import { CableField } from "@/components/rede/cable-field";
import { Bolts, Lamp, PlateCode } from "@/components/rede/plate";
import { Container } from "@/components/ui/container";

/**
 * The first viewport: the bundle, and the terminal it lands in.
 *
 * The headline is set in the negative space the cables leave rather than in a
 * panel over them — the field is the composition, not a backdrop, and a card
 * here would put the page's own thesis inside the container the thesis
 * refuses. The primary action sits in the terminal block at the lower left,
 * which is the point every conductor in the frame converges on: the button is
 * where the lines land.
 */
export function RedeHero() {
  return (
    <HeroPin className="-mt-16 bg-[#06080b] lg:-mt-[72px]">
      <CableField className="pointer-events-none absolute inset-0" />

      {/* The night deepens toward the copy so the headline holds against the
          bundle, and toward the top so the sticky header never fights the
          cables for contrast. */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 bg-[linear-gradient(to_bottom,rgb(6_8_11/0.94)_8%,rgb(6_8_11/0.72)_38%,transparent_72%)] sm:bg-[radial-gradient(75%_60%_at_8%_44%,rgb(6_8_11/0.92),transparent_62%),linear-gradient(to_bottom,rgb(6_8_11/0.85),transparent_22%)]"
      />

      {/* The layout peels away in stages as the discharge takes the stage: the
          bus strip first, then the copy, so the mark assembles on an empty
          screen rather than behind a headline. */}
      <div className="relative flex h-full w-full flex-col justify-between pt-28 pb-0 sm:pt-32 lg:pt-36">
        <Container size="wide" className="relative">
          <HeroPhase exitBy={0.34} lift={-70}>
            <div>
              <h1 className="font-display max-w-none text-[clamp(2.05rem,7.6vw,4.4rem)] leading-[0.96] font-extrabold tracking-[-0.035em] sm:max-w-[26rem] sm:leading-[0.94] lg:max-w-[42rem]">
                Do primeiro clique ao cliente atendido,{" "}
                <span className="text-brand-400">numa linha só.</span>
              </h1>
            </div>

            <p className="text-fg-muted mt-6 max-w-[52ch] text-[15px] leading-relaxed sm:text-base">
              Sites, campanhas, automação e inteligência artificial construídos
              juntos e operados por quem construiu — para que nenhum contato se
              perca entre uma ferramenta e outra.
            </p>

            {/* The terminal block: where the bundle lands.

                The cable field's convergence point is aimed at this element's
                left edge (ANCHOR in cable-canvas.tsx), so the strands run
                behind the landing lug and stop — pressing the primary action
                is pressing the thing the current arrives in. */}
            <div className="relative mt-8 inline-flex max-w-full flex-col sm:flex-row sm:items-stretch">
              <span
                aria-hidden
                className="plate relative hidden w-7 shrink-0 self-stretch rounded-l-[3px] sm:block"
              >
                <span className="hazard absolute inset-y-2 left-1/2 w-2 -translate-x-1/2" />
              </span>

              <div className="plate relative flex flex-col gap-px overflow-hidden rounded-[3px] sm:flex-row sm:items-stretch sm:rounded-l-none">
                <Bolts />
                <a
                  href="#contato"
                  className="group bg-brand-400 text-ink-950 hover:bg-brand-300 focus-visible:outline-brand-300 flex items-center justify-between gap-6 px-6 py-4 text-[15px] font-semibold transition-colors duration-200 sm:justify-start"
                >
                  Solicitar orçamento
                  <ArrowRight
                    aria-hidden
                    className="ease-out-soft size-4 transition-transform duration-200 group-hover:translate-x-0.5"
                  />
                </a>
                <a
                  href="#carga"
                  className="text-fg hover:text-brand-300 flex items-center gap-3 px-6 py-4 text-[15px] font-medium transition-colors duration-200"
                >
                  <Lamp live />
                  Ver o que já roda aqui
                </a>
              </div>
            </div>
          </HeroPhase>
        </Container>

        {/* The bus strip names the five conductors in the field above it, so
            the WebGL reads as information rather than atmosphere: the visitor
            can point at a cable and read what it carries. */}
        <HeroPhase exitBy={0.24} lift={40}>
          <div className="border-line relative border-t bg-[rgb(6_8_11/0.92)] backdrop-blur-md">
            <Container size="wide">
              <ul className="divide-line grid grid-cols-1 divide-y sm:grid-cols-3 sm:divide-x sm:divide-y-0 lg:grid-cols-5">
                {lines.map((line) => (
                  <li key={line.code}>
                    <a
                      href={`#${line.id}`}
                      className="group hover:bg-surface-raised flex items-center gap-3 px-1 py-4 transition-colors duration-200 sm:px-5"
                    >
                      <Lamp live />
                      <span className="min-w-0">
                        <PlateCode live className="block">
                          {line.code}
                        </PlateCode>
                        <span className="text-fg group-hover:text-brand-300 mt-1.5 block text-[13px] font-medium transition-colors">
                          {line.name}
                        </span>
                      </span>
                    </a>
                  </li>
                ))}
              </ul>
            </Container>
          </div>
        </HeroPhase>
      </div>
    </HeroPin>
  );
}
