import { processSteps } from "@/content/process";
import { Eyebrow } from "@/components/ui/section-heading";
import {
  Appear,
  ScrollInStagger,
  ProcessTrack,
} from "@/components/motion/scroll-motion";

/**
 * 7-step timeline. Horizontal with a connecting rule from `md` up; a vertical
 * spine below that, where seven columns would be unreadable.
 */
export function Process() {
  return (
    <div id="processo" className="scroll-mt-24">
      <Appear>
        <Eyebrow>Como trabalhamos</Eyebrow>
        <h2 className="mt-3 text-3xl leading-tight font-bold sm:text-[36px]">
          Nosso processo em 7 etapas
        </h2>
      </Appear>

      <ol className="relative mt-12 grid gap-8 md:grid-cols-7 md:gap-3">
        {/* Connecting rule — horizontal on md+, vertical below. It draws itself
            from origin as the section scrolls, so the timeline builds rather
            than simply being present. */}
        <ProcessTrack />

        {processSteps.map(({ step, title, description }, i) => (
          <ScrollInStagger
            as="li"
            key={step}
            index={i}
            y={40}
            className="relative flex items-start gap-4 md:flex-col md:items-center md:gap-0 md:text-center"
          >
            <span className="border-brand-200 text-brand-600 relative z-10 flex size-10 shrink-0 items-center justify-center rounded-full border bg-white text-[13px] font-bold shadow-[0_0_0_4px_var(--surface)]">
              {step}
            </span>
            <div className="md:mt-4">
              <h3 className="text-fg text-sm font-semibold">{title}</h3>
              <p className="text-fg-muted mt-1 text-xs leading-relaxed">
                {description}
              </p>
            </div>
          </ScrollInStagger>
        ))}
      </ol>
    </div>
  );
}
