import { carga } from "@/content/rede";
import { Container } from "@/components/ui/container";
import { Lamp, PlateCode } from "@/components/rede/plate";
import { Conductor } from "@/components/rede/conductor";

/**
 * The proof, and the only kind available honestly.
 *
 * There are no client metrics, logos or testimonials on hand — the previous
 * site's were invented — so this section shows the one thing that can actually
 * be pointed at: the systems Mandra runs its own company on, which are the
 * same systems it builds for clients. It is a stronger claim than a number
 * nobody can check, and it is the one thing on this page a competitor cannot
 * copy-paste.
 *
 * ── Why these lines run ────────────────────────────────────────────────────
 *
 * This band is the answer to Emaranhado, so it is drawn with Emaranhado's own
 * parts: the same conductor, the same head of current. The difference is the
 * only thing the section has to say — there, the packet reaches a cut face and
 * dies; here it travels the whole run and leaves at the far end, five times,
 * staggered so they read as five independent systems rather than one bank
 * flashing. A reader who scrolled past the tangle recognises the gesture
 * before they read a word of it.
 *
 * Nothing here animates a figure. The section's claim is "these are running",
 * which is exactly what a conductor under load says and no more — an uptime
 * percentage or a request counter would be the invented metric this whole page
 * was rebuilt to remove.
 */
export function Carga() {
  return (
    <section
      id="carga"
      data-section="carga"
      data-tone="night"
      className="bg-bg text-fg relative py-20 sm:py-28"
    >
      <Container size="wide">
        <div className="max-w-[42rem]">
          <h2 className="font-display text-[clamp(1.9rem,4vw,3.1rem)] leading-[1.02] font-extrabold tracking-[-0.03em]">
            O que já roda <span className="text-brand-400">aqui dentro</span>.
          </h2>
          <p className="text-fg-muted mt-5 max-w-[58ch] text-[15px] leading-relaxed">
            A Mandra opera na própria rede que vende. Estes cinco sistemas estão
            em uso todos os dias — não são demonstrações, são a nossa operação.
          </p>
        </div>

        <ul className="border-line mt-14 grid gap-px border-t sm:mt-20">
          {carga.map((sys, i) => {
            // Spread across the run's own period so no two heads share a
            // frame, and slow — these are systems in service, not a progress
            // bar. A bank of five on one beat is a strobe.
            const delay = `${(i * 1.15).toFixed(2)}s`;

            return (
              <li
                key={sys.code}
                className="group border-line relative border-b py-7"
              >
                <div className="grid grid-cols-1 gap-x-8 gap-y-3 sm:grid-cols-[auto_minmax(0,0.7fr)_minmax(0,1.6fr)] sm:items-baseline">
                  <div className="flex items-center gap-3 sm:w-[7rem]">
                    <Lamp live load duration="4.2s" delay={delay} />
                    <PlateCode live>{sys.code}</PlateCode>
                  </div>
                  <h3 className="font-display text-fg text-lg leading-tight font-bold tracking-[-0.02em]">
                    {sys.name}
                  </h3>
                  <p className="text-fg-muted group-hover:text-fg max-w-[62ch] text-[15px] leading-relaxed transition-colors duration-300">
                    {sys.text}
                  </p>
                </div>

                {/* The run under the row, carrying end to end. It sits on the
                    row's lower rule rather than above it, so five of them read
                    as five services stacked on a board — not as five underlines
                    borrowed from the tangle. */}
                <Conductor
                  live
                  duration="5.8s"
                  delay={delay}
                  className="absolute inset-x-0 -bottom-px h-[2px] opacity-70 transition-opacity duration-300 group-hover:opacity-100"
                />
              </li>
            );
          })}
        </ul>
      </Container>
    </section>
  );
}
