import { Phone, Mail, MapPin, Info } from "lucide-react";
import { site } from "@/content/site";
import { services } from "@/content/services";
import { Container } from "@/components/ui/container";
import { Section } from "@/components/ui/section";
import { SectionHeading } from "@/components/ui/section-heading";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Appear } from "@/components/motion/scroll-motion";

const fieldClass =
  "w-full rounded-control border border-line bg-surface px-3.5 py-2.5 text-sm text-fg placeholder:text-fg-subtle " +
  "transition-colors focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-400/30";

function Field({
  label,
  htmlFor,
  children,
  className,
}: {
  label: string;
  htmlFor: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      <label
        htmlFor={htmlFor}
        className="text-fg mb-1.5 block text-xs font-medium"
      >
        {label}
      </label>
      {children}
    </div>
  );
}

const contactRows = [
  { icon: Phone, text: site.contact.phone, href: site.contact.phoneHref },
  { icon: Mail, text: site.contact.email, href: site.contact.emailHref },
  { icon: MapPin, text: site.contact.address, href: null },
];

/**
 * Presentational only — the form has no action and submit is disabled by
 * design. Submission, validation and email delivery are a later phase.
 */
export function Contact() {
  return (
    <Section id="contato" tone="muted" spacing="lg">
      <Container size="wide">
        <Appear>
          <SectionHeading
            eyebrow="Vamos conversar"
            title="Conte o que sua empresa precisa"
            description="Respondemos em até 1 dia útil com um diagnóstico inicial e uma proposta de escopo."
          />
        </Appear>

        <div className="mt-12 grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
          <Appear>
            <Card className="p-6 sm:p-8">
              <form className="grid gap-5 sm:grid-cols-2">
                <Field label="Nome" htmlFor="nome">
                  <input
                    id="nome"
                    name="nome"
                    type="text"
                    autoComplete="name"
                    placeholder="Seu nome completo"
                    className={fieldClass}
                  />
                </Field>

                <Field label="E-mail" htmlFor="email">
                  <input
                    id="email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    placeholder="voce@empresa.com.br"
                    className={fieldClass}
                  />
                </Field>

                <Field label="Empresa" htmlFor="empresa">
                  <input
                    id="empresa"
                    name="empresa"
                    type="text"
                    autoComplete="organization"
                    placeholder="Nome da empresa"
                    className={fieldClass}
                  />
                </Field>

                <Field label="Telefone" htmlFor="telefone">
                  <input
                    id="telefone"
                    name="telefone"
                    type="tel"
                    autoComplete="tel"
                    placeholder="(11) 90000-0000"
                    className={fieldClass}
                  />
                </Field>

                <Field
                  label="Serviço de interesse"
                  htmlFor="servico"
                  className="sm:col-span-2"
                >
                  <select id="servico" name="servico" className={fieldClass}>
                    <option value="">Selecione uma opção</option>
                    {services.map((service) => (
                      <option key={service.id} value={service.id}>
                        {service.title}
                      </option>
                    ))}
                    <option value="outro">Outro</option>
                  </select>
                </Field>

                <Field
                  label="Mensagem"
                  htmlFor="mensagem"
                  className="sm:col-span-2"
                >
                  <textarea
                    id="mensagem"
                    name="mensagem"
                    rows={4}
                    placeholder="Descreva brevemente seu projeto ou desafio."
                    className={`${fieldClass} resize-y`}
                  />
                </Field>

                <div className="flex flex-wrap items-center gap-4 sm:col-span-2">
                  <Button type="submit" size="lg" withArrow disabled>
                    Solicitar orçamento
                  </Button>
                  <p className="text-fg-muted flex items-center gap-1.5 text-xs">
                    <Info aria-hidden className="size-3.5 shrink-0" />
                    Envio pelo site em breve — por enquanto fale conosco pelos
                    canais ao lado.
                  </p>
                </div>
              </form>
            </Card>
          </Appear>

          <Appear delay={0.08}>
            <Card className="h-fit p-6 sm:p-8">
              <h3 className="text-fg text-base font-semibold">Fale direto</h3>
              <ul className="mt-5 space-y-4">
                {contactRows.map(({ icon: Icon, text, href }) => (
                  <li key={text} className="flex items-start gap-3">
                    <span className="bg-brand-50 text-brand-600 flex size-8 shrink-0 items-center justify-center rounded-full">
                      <Icon className="size-4" />
                    </span>
                    {href ? (
                      <a
                        href={href}
                        className="text-fg-muted hover:text-brand-600 pt-1.5 text-sm transition-colors"
                      >
                        {text}
                      </a>
                    ) : (
                      <span className="text-fg-muted pt-1.5 text-sm">
                        {text}
                      </span>
                    )}
                  </li>
                ))}
              </ul>
            </Card>
          </Appear>
        </div>
      </Container>
    </Section>
  );
}
