import { tangle } from "@/content/rede";
import { Container } from "@/components/ui/container";
import { Bolts, Lamp } from "@/components/rede/plate";

/**
 * How far short of the column each run is cut, in pixels.
 *
 * Cables cut by five different installers over five different years do not end
 * flush, and five ends on one vertical line read as a drawn rule rather than as
 * damage. The slack is the only thing in the section that is arbitrary, so it
 * lives here rather than in `tangle` — it is how the rows are drawn, not what
 * they say.
 */
const SLACK = [0, 13, 5, 18, 9];

/**
 * The before state, rendered as absence.
 *
 * Each row is a conductor that physically breaks: a run of sheath, an open
 * gap with the fault stamped in it, and a second run that terminates nowhere.
 * The gap is drawn rather than described, because the section's whole argument
 * is that the visitor already owns these five loose ends — a list of pain
 * points in prose would ask them to take that on faith instead of seeing it.
 *
 * The rows are alive: a packet of current runs each live side and dies at the
 * cut, staggered so the five never pulse together. Hovering a row turns that
 * from an idle glimmer into the full event — the packet at full brightness and
 * an arc struck across the break. Nothing ever lights on the far side, which is
 * the point of the interaction: the visitor gets to push current down their own
 * loose end and watch where it stops. The whole thing is CSS on `group`, so the
 * section stays a server component and costs the page nothing.
 */
export function Emaranhado() {
  return (
    <section
      id="emaranhado"
      data-section="emaranhado"
      data-tone="night"
      className="bg-surface text-fg relative overflow-hidden pt-24 pb-20 sm:pt-32 sm:pb-28"
    >
      {/* The hero is pinned on `night-950` and this band sits a stop lighter,
          so the two meet on a hard rule if nothing is done about it. The ramp
          carries the hero's ground down into this one over a screen-third,
          which is long enough that the eye never finds the seam. */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-72 bg-[linear-gradient(to_bottom,var(--color-night-950)_0%,rgb(6_8_11/0.72)_38%,transparent_100%)]"
      />

      <Container size="wide" className="relative">
        <div className="max-w-[38rem]">
          <h2 className="font-display text-[clamp(1.9rem,4vw,3.1rem)] leading-[1.02] font-extrabold tracking-[-0.03em]">
            Toda empresa já tem cinco linhas.
            <span className="text-dead-300"> Nenhuma delas termina.</span>
          </h2>
          <p className="text-fg-muted mt-5 max-w-[54ch] text-[15px] leading-relaxed">
            Não falta ferramenta. Falta ponta terminada — cada coisa foi
            contratada num momento, com um fornecedor diferente, e nenhuma sabe
            da existência da outra.
          </p>
        </div>

        <div className="plate relative mt-12 rounded-[4px] p-5 sm:mt-16 sm:p-8">
          <Bolts />
          <p className="text-dead-300 font-mono text-[10px] tracking-[0.24em] uppercase">
            Caixa aberta · 5 pontas sem terminação
          </p>
          <ul className="recess mt-5 flex flex-col rounded-[3px] px-4 sm:px-7">
            {tangle.map((row, i) => {
              // One delay per row, shared by the packet and the arc it strikes
              // so the two stay welded; prime-ish spacing keeps any two rows
              // from falling into step over the loop.
              const beat = { animationDelay: `${(i * 0.83).toFixed(2)}s` };

              return (
                <li
                  key={row.fault}
                  className="group grid grid-cols-[minmax(0,1fr)_auto] items-center gap-x-4 gap-y-3 border-b border-white/[0.05] py-6 last:border-b-0 sm:grid-cols-[minmax(0,0.85fr)_auto_minmax(0,1.15fr)] sm:gap-x-0"
                >
                  {/* The live run: sheath, going somewhere. It stops dead. */}
                  <span
                    aria-hidden
                    className="relative flex h-[7px] items-center"
                    style={{ marginRight: SLACK[i] }}
                  >
                    <span className="relative h-full flex-1 overflow-hidden rounded-l-full shadow-[0_1px_2px_rgb(0_0_0/0.6)]">
                      <span className="conductor absolute inset-0 rounded-l-full" />
                      {/* Idle at a glimmer, full on hover. The opacity sits on
                          this wrapper and never on the animated child — the
                          keyframes own that child's opacity envelope. */}
                      <span className="absolute inset-0 opacity-40 transition-opacity duration-300 group-hover:opacity-100">
                        <span
                          style={beat}
                          className="surge absolute inset-y-[1px] left-0 w-[36%] rounded-full bg-[linear-gradient(90deg,transparent,var(--color-brand-400)_55%,transparent)]"
                        />
                      </span>
                    </span>

                    {/* The cut end. Bare metal in cross-section — brightest at
                        the top where the light is, squared rather than rounded,
                        because a conductor that was severed has no cap. */}
                    <span className="relative h-full w-[3px] shrink-0 bg-[linear-gradient(to_bottom,#c3cedb,#8290a1_40%,#46515f)] shadow-[0_1px_2px_rgb(0_0_0/0.6)]">
                      <span className="pointer-events-none absolute top-1/2 left-1/2 size-5 -translate-x-1/2 -translate-y-1/2 opacity-0 transition-opacity duration-200 group-hover:opacity-100">
                        <span
                          style={beat}
                          className="arc-strike absolute inset-0 rounded-full bg-[radial-gradient(circle,var(--color-accent-glow)_0%,rgb(243_163_58/0.4)_42%,transparent_70%)]"
                        />
                      </span>
                    </span>
                  </span>

                  {/* The break. Real empty space, with the fault stamped in it. */}
                  <span className="col-start-2 row-start-1 flex items-center gap-3 sm:px-7">
                    <Lamp />
                    {/* Every row is its own grid, so an `auto` middle column
                        sizes to that row's own stamp and the five lamps drift
                        out of column. One width for all five stamps puts the
                        break on a single vertical, which is what lets the
                        ragged cut ends read as damage rather than as slop. */}
                    <span className="border-dead-600 text-dead-300 group-hover:border-dead-400 group-hover:text-fg inline-flex min-w-[7.5rem] justify-center rounded-[3px] border border-dashed px-2.5 py-1.5 font-mono text-[10px] leading-none tracking-[0.2em] whitespace-nowrap uppercase transition-colors duration-300">
                      {row.fault}
                    </span>
                  </span>

                  {/* The other side, which nothing reaches. Same cable, same
                      cut, no current — so it is drawn with the conductor's own
                      gradient held down rather than with a flat grey nub. */}
                  <span className="col-span-2 flex min-w-0 items-center gap-4 sm:col-span-1 sm:col-start-3">
                    <span
                      aria-hidden
                      className="hidden h-[7px] w-7 shrink-0 items-center sm:flex"
                    >
                      <span className="bg-dead-600 h-full w-[2px]" />
                      <span className="conductor h-full flex-1 rounded-r-full opacity-45 shadow-[0_1px_2px_rgb(0_0_0/0.5)]" />
                    </span>
                    <span className="text-fg-muted group-hover:text-fg text-[15px] leading-snug transition-colors duration-300 sm:text-base">
                      {row.text}
                    </span>
                  </span>
                </li>
              );
            })}
          </ul>
        </div>

        {/* The turn. One sentence, on the bus that the next section runs on. */}
        <div className="mt-12 flex flex-col gap-6 sm:mt-16 sm:flex-row sm:items-center sm:gap-10">
          <span aria-hidden className="conductor h-[6px] flex-1 rounded-full" />
          <p className="font-display text-fg max-w-[30ch] text-[clamp(1.15rem,2.2vw,1.6rem)] leading-snug font-bold tracking-[-0.02em]">
            Na Mandra, essas cinco pontas terminam{" "}
            <span className="text-brand-400">no mesmo lugar</span>.
          </p>
        </div>
      </Container>
    </section>
  );
}
