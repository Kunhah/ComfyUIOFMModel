import {
  MonitorSmartphone,
  ShoppingCart,
  LayoutTemplate,
  Users,
  Mail,
  BrainCircuit,
  BarChart3,
  Plug,
  Boxes,
  type LucideIcon,
} from "lucide-react";
import { siWhatsapp } from "simple-icons";
import {
  inputNodes,
  outputNodes,
  topNode,
  baseNodes,
  type EcosystemNode,
} from "@/content/ecosystem";
import { Container } from "@/components/ui/container";
import { Section } from "@/components/ui/section";
import { Eyebrow } from "@/components/ui/section-heading";
import { ButtonLink } from "@/components/ui/button";
import { LogoMark } from "@/components/ui/logo";
import {
  Appear,
  EcosystemDiagram,
  DiagramNode,
} from "@/components/motion/scroll-motion";
import { cn } from "@/lib/utils";

const icons: Record<string, LucideIcon> = {
  monitor: MonitorSmartphone,
  cart: ShoppingCart,
  layout: LayoutTemplate,
  users: Users,
  mail: Mail,
  brain: BrainCircuit,
  chart: BarChart3,
  plug: Plug,
  boxes: Boxes,
};

function NodeIcon({ name }: { name: string }) {
  if (name === "whatsapp") {
    return (
      <svg
        viewBox="0 0 24 24"
        fill="currentColor"
        aria-hidden
        className="size-4"
      >
        <path d={siWhatsapp.path} />
      </svg>
    );
  }
  const Icon = icons[name] ?? Boxes;
  return <Icon aria-hidden className="size-4" />;
}

function NodeCard({
  node,
  className,
}: {
  node: EcosystemNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "border-line bg-ink-800/80 flex items-center gap-2.5 rounded-[12px] border px-3 py-2.5 shadow-[0_0_0_1px_rgb(255_255_255/0.02),0_12px_28px_-18px_rgb(0_0_0/0.9)] backdrop-blur-sm",
        className,
      )}
    >
      <span className="bg-brand-400/15 text-brand-400 flex size-7 shrink-0 items-center justify-center rounded-[8px]">
        <NodeIcon name={node.icon} />
      </span>
      <span className="min-w-0">
        <span className="text-fg block truncate text-[12px] font-semibold">
          {node.title}
        </span>
        <span className="text-fg-muted block truncate text-[10px] leading-tight">
          {node.caption}
        </span>
      </span>
    </div>
  );
}

function MandraCore({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "flex aspect-square flex-col items-center justify-center rounded-full",
        "bg-[radial-gradient(circle_at_50%_38%,#3a3025,#1c1a17_52%,#0b0e12_78%)]",
        "shadow-[inset_0_0_40px_rgb(11_14_18/0.85),0_0_70px_-6px_rgb(243_163_58/0.55)]",
        "ring-brand-400/45 ring-1",
        className,
      )}
    >
      <LogoMark className="text-brand-400 size-7" />
      <p className="mt-1.5 text-[12px] font-bold tracking-[0.08em] text-white">
        MANDRA CORE
      </p>
      <p className="text-brand-200 mt-0.5 text-[8px] tracking-wide">
        Integração • Automação • IA
      </p>
    </div>
  );
}

/**
 * Connector overlay. Shares the 900×560 coordinate space with the absolutely
 * positioned node cards, so lines and boxes stay aligned at any width. Each
 * path carries pathLength="100" so one dash animation fits every length.
 */
function Connectors() {
  // The core is centred in the 900×560 box (450, 280) with a 19%-wide diameter,
  // so its radius is ~85 units. Anchors sit just inside that edge, giving the
  // lines a small overlap rather than a visible gap.
  const sideY = [151, 280, 391];
  const baseX = [237, 450, 664];

  const paths = [
    // top node → core
    "M450 78 L450 190",
    // left nodes → core
    ...sideY.map((y) => `M214 ${y} C 310 ${y}, 330 280, 362 280`),
    // core → right nodes
    ...sideY.map((y) => `M538 280 C 574 280, 592 ${y}, 686 ${y}`),
    // core → base nodes
    ...baseX.map((x) => `M450 370 C 450 428, ${x} 418, ${x} 462`),
  ];

  return (
    <svg
      viewBox="0 0 900 560"
      fill="none"
      aria-hidden
      className="absolute inset-0 size-full"
    >
      {paths.map((d, i) => (
        <g key={d}>
          <path
            d={d}
            pathLength="100"
            stroke="rgb(243 163 58 / 0.35)"
            strokeWidth="1.3"
            strokeLinecap="round"
            strokeDasharray="0.4 2.4"
          />
          <path
            d={d}
            pathLength="100"
            stroke="rgb(255 190 105 / 0.95)"
            strokeWidth="1.6"
            strokeLinecap="round"
            className="connector-pulse"
            style={{ animationDelay: `${(i % 5) * 0.55}s` }}
          />
        </g>
      ))}
    </svg>
  );
}

/** Node positions inside the 900×560 space, as percentages. */
const layout = {
  top: { left: "37.5%", top: "3.6%", width: "25%" },
  left: [
    { left: "1.5%", top: "21.8%" },
    { left: "1.5%", top: "44.8%" },
    { left: "1.5%", top: "64.6%" },
  ],
  right: [
    { right: "1.5%", top: "21.8%" },
    { right: "1.5%", top: "44.8%" },
    { right: "1.5%", top: "64.6%" },
  ],
  base: [
    { left: "15.6%", top: "82.5%" },
    { left: "39.3%", top: "82.5%" },
    { left: "63%", top: "82.5%" },
  ],
  sideWidth: "21.5%",
} as const;

export function Ecosystem() {
  return (
    <Section id="sobre" tone="dark" spacing="lg" className="overflow-hidden">
      <div
        aria-hidden
        className="pointer-events-none absolute top-1/2 left-1/2 size-[760px] -translate-x-1/4 -translate-y-1/2 rounded-full bg-[radial-gradient(circle,rgb(243_163_58/0.14),transparent_62%)]"
      />

      <Container size="wide" className="relative">
        <div className="grid gap-14 lg:grid-cols-[minmax(0,0.72fr)_minmax(0,1.28fr)] lg:items-center lg:gap-10">
          <Appear className="max-w-md">
            <Eyebrow>Tudo conectado. Tudo integrado.</Eyebrow>
            <h2 className="mt-3 text-3xl leading-[1.15] font-bold sm:text-[38px]">
              O ecossistema digital que impulsiona seu negócio.
            </h2>
            <p className="text-fg-muted mt-5 text-[15px] leading-relaxed">
              Conectamos tecnologias, dados e pessoas em um sistema inteligente
              e escalável, feito para gerar resultados reais.
            </p>
            <ButtonLink href="#servicos" size="lg" withArrow className="mt-8">
              Conhecer serviços
            </ButtonLink>
          </Appear>

          {/* --- diagram (lg and up) --- */}
          <EcosystemDiagram className="relative hidden aspect-[900/560] w-full lg:block">
            <Connectors />

            <DiagramNode from="top" className="absolute" style={layout.top}>
              <NodeCard node={topNode} />
            </DiagramNode>

            {inputNodes.map((node, i) => (
              <DiagramNode
                key={node.id}
                from="left"
                className="absolute"
                style={{ ...layout.left[i], width: layout.sideWidth }}
              >
                <NodeCard node={node} />
              </DiagramNode>
            ))}

            {outputNodes.map((node, i) => (
              <DiagramNode
                key={node.id}
                from="right"
                className="absolute"
                style={{ ...layout.right[i], width: layout.sideWidth }}
              >
                <NodeCard node={node} />
              </DiagramNode>
            ))}

            {baseNodes.map((node, i) => (
              <DiagramNode
                key={node.id}
                from="bottom"
                className="absolute"
                style={{ ...layout.base[i], width: layout.sideWidth }}
              >
                <NodeCard node={node} />
              </DiagramNode>
            ))}

            <MandraCore className="absolute top-1/2 left-1/2 w-[19%] -translate-x-1/2 -translate-y-1/2" />
          </EcosystemDiagram>

          {/* --- stacked fallback (below lg) --- */}
          <div className="lg:hidden">
            <MandraCore className="mx-auto w-40" />
            <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3">
              {[topNode, ...inputNodes, ...outputNodes, ...baseNodes].map(
                (node) => (
                  <NodeCard key={node.id} node={node} />
                ),
              )}
            </div>
          </div>
        </div>
      </Container>
    </Section>
  );
}
