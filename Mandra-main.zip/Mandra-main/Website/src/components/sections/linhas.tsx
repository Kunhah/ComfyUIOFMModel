"use client";

import { useEffect, useRef, useState } from "react";
import { lines } from "@/content/rede";
import { Container } from "@/components/ui/container";
import { Lamp, PlateCode, Legend } from "@/components/rede/plate";
import { Conductor } from "@/components/rede/conductor";
import { cn } from "@/lib/utils";

/**
 * The five lines Mandra terminates.
 *
 * Deliberately not five cards. Five equal boxes side by side is the arrangement
 * this page exists to argue against — it is the tangle, drawn tidily. Each
 * service is instead a full-width run of conductor that the section energizes
 * one at a time: exactly one line carries load, everything else is unlit steel.
 * That binary is the navigation signal, so the visitor's eye is never asked to
 * choose between five things shouting equally.
 *
 * The sequence runs on its own once the section is on screen and hands control
 * to the pointer the moment there is one, which is what keeps it from being
 * either a dead list or an animation that ignores the reader.
 */
export function Linhas() {
  const sectionRef = useRef<HTMLElement>(null);
  const [active, setActive] = useState(0);
  const [held, setHeld] = useState(false);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const node = sectionRef.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      ([entry]) => setInView(entry.isIntersecting),
      { rootMargin: "-15% 0px -15% 0px" },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!inView || held) return;
    // Matches the hero's switching cadence, so the page has one clock.
    const id = window.setInterval(
      () => setActive((i) => (i + 1) % lines.length),
      2800,
    );
    return () => window.clearInterval(id);
  }, [inView, held]);

  return (
    <section
      ref={sectionRef}
      id="linhas"
      data-section="linhas"
      data-tone="light"
      className="bg-bg text-fg relative py-20 sm:py-28"
    >
      <Container size="wide">
        <div className="max-w-[40rem]">
          <h2 className="font-display text-[clamp(1.9rem,4vw,3.1rem)] leading-[1.02] font-extrabold tracking-[-0.03em]">
            Cinco linhas, um terminal.
          </h2>
          <p className="text-fg-muted mt-5 max-w-[56ch] text-[15px] leading-relaxed">
            Cada uma resolve um problema sozinha. Juntas, e só juntas, elas
            fecham o circuito entre quem procurou você e quem foi atendido.
          </p>
        </div>

        <ul className="mt-14 sm:mt-20" onMouseLeave={() => setHeld(false)}>
          {lines.map((line, i) => {
            const live = i === active;
            return (
              <li
                key={line.code}
                id={line.id}
                className="scroll-mt-28"
                onMouseEnter={() => {
                  setHeld(true);
                  setActive(i);
                }}
              >
                <div className="ease-out-soft grid grid-cols-[auto_minmax(0,1fr)] items-start gap-x-5 gap-y-5 py-8 sm:gap-x-8 sm:py-10 lg:grid-cols-[auto_minmax(0,1.05fr)_minmax(0,1.35fr)]">
                  {/* Identification: the same three-field plate every named
                      thing on this page wears. */}
                  <div className="flex flex-col items-start gap-2.5 lg:w-[8.5rem] lg:gap-4">
                    <Lamp live={live} />
                    <PlateCode live={live}>{line.code}</PlateCode>
                  </div>

                  <div className="col-start-2 lg:col-start-auto">
                    <h3>
                      <button
                        type="button"
                        aria-pressed={live}
                        onFocus={() => {
                          setHeld(true);
                          setActive(i);
                        }}
                        className={cn(
                          "font-display cursor-pointer text-left text-[clamp(1.5rem,3vw,2.3rem)] leading-[1.05] font-bold tracking-[-0.025em] transition-colors duration-500 focus-visible:outline-[var(--ink-accent)]",
                          live
                            ? "text-[var(--ink-accent)]"
                            : "text-fg hover:text-[var(--ink-accent)]",
                        )}
                      >
                        {line.name}
                      </button>
                    </h3>
                    <p className="text-fg-muted mt-3 font-mono text-[11px] tracking-[0.16em] uppercase">
                      carga · {line.load}
                    </p>
                  </div>

                  <div className="col-span-2 lg:col-span-1 lg:col-start-auto">
                    <p className="text-fg-muted max-w-[52ch] text-[15px] leading-relaxed">
                      {line.detail}
                    </p>
                    <ul className="mt-5 flex flex-wrap gap-1.5">
                      {line.items.map((item) => (
                        <li key={item}>
                          <Legend>{item}</Legend>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <Conductor live={live} duration="2.6s" />
              </li>
            );
          })}
        </ul>
      </Container>
    </section>
  );
}
