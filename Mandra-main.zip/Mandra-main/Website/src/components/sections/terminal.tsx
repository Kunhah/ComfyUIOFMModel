import { Mail } from "lucide-react";
import { site } from "@/content/site";
import { lines } from "@/content/rede";
import { Container } from "@/components/ui/container";
import { Bolts, Lamp, PlateCode } from "@/components/rede/plate";
import { Conductor } from "@/components/rede/conductor";
import { CallAction, WhatsappAction } from "@/components/ads/actions";

/**
 * The terminal: where every line on the page lands.
 *
 * This is the one band where the brand colour owns the whole surface rather
 * than marking a state. That is deliberate and it is the page's only such
 * moment: amber has meant "carrying current" for five sections, so a field of
 * it at the end reads as the whole rede under load — a meaning it would lose
 * immediately if amber had been used as decoration anywhere above.
 *
 * The box itself is the payoff of the argument, so it is built rather than
 * described: the five conductors named at the top of the page arrive here and
 * are terminated, on the same bolted plate the hero's action is made of. An
 * amber slab with a button on it would have been the generic CTA band this
 * whole direction exists to refuse.
 *
 * Charcoal on amber, never white: white type on #f3a33a is 2.3:1.
 */
export function Terminal() {
  return (
    <section
      id="contato"
      data-section="terminal"
      data-tone="brand"
      className="bg-surface text-fg relative overflow-hidden"
    >
      {/* The landing edge of the box. */}
      <span
        aria-hidden
        className="hazard absolute inset-x-0 top-0 h-2.5 [--hazard-color:rgb(22_25_29/0.5)]"
      />

      <Container size="wide" className="relative py-20 sm:py-28">
        <div className="grid gap-14 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)] lg:items-start lg:gap-20">
          <div>
            <h2 className="font-display text-[clamp(2rem,4.6vw,3.6rem)] leading-[0.98] font-extrabold tracking-[-0.035em]">
              Traga suas pontas soltas.
              <br />
              Nós terminamos todas.
            </h2>
            <p className="mt-6 max-w-[52ch] text-[15px] leading-relaxed text-[rgb(22_25_29/0.78)]">
              Conte o que já existe na sua operação e o que não está
              funcionando. A primeira conversa é um levantamento, não uma
              proposta.
            </p>

            {/* The same terminal block the hero's action is made of, and the
                same object the ad landing pages end on — one `tel:` href, with
                the number as its own label so it can be read and dialled
                without being clicked. Bolts alone were invisible on a dark
                face; the action only reads as hardware once it has the landing
                lug and the hazard edge too. */}
            <div className="mt-10 flex flex-col items-start gap-3 sm:flex-row sm:items-stretch sm:gap-4">
              <CallAction tone="brand" />
              <WhatsappAction
                tone="brand"
                message="Olá! Vim pelo site da Mandra e quero falar sobre um projeto."
              />
            </div>

            {/* The address that is also an action. The postal address in
                src/content/site.ts is still inherited placeholder data and an
                unverified one asserted on the page's conversion surface is a
                truth exposure — it is not a contact method, and it stays in
                the footer. */}
            <ul className="mt-8 flex flex-col gap-3">
              <li>
                <a
                  href={site.contact.emailHref}
                  className="inline-flex items-center gap-3 text-[15px] font-medium transition-opacity duration-200 hover:opacity-70"
                >
                  <Mail
                    aria-hidden
                    className="size-4 shrink-0 text-[rgb(22_25_29/0.62)]"
                  />
                  {site.contact.email}
                </a>
              </li>
            </ul>
          </div>

          {/* The box. Five conductors in, five terminals, all under load. */}
          <div
            data-tone="night"
            className="plate relative rounded-[4px] p-5 sm:p-7"
          >
            <Bolts />
            <p className="text-dead-300 font-mono text-[10px] tracking-[0.24em] uppercase">
              Terminal · MDR-00
            </p>

            <ul className="recess mt-5 rounded-[3px] px-4 sm:px-5">
              {lines.map((line, i) => {
                // The five arrive one after another rather than together. A
                // bank landing on one frame is a light show; landing in
                // sequence is five separate lines reaching the same box, which
                // is the sentence this whole band is here to finish.
                const delay = `${(i * 0.46).toFixed(2)}s`;

                return (
                  <li
                    key={line.code}
                    className="flex items-center gap-4 border-b border-white/[0.06] py-4 last:border-b-0"
                  >
                    {/* The conductor arriving from the page above — and it does
                        arrive. Every other run on the site either dies at a cut
                        (Emaranhado) or passes through (Carga); these are the
                        only ones that stop somewhere on purpose, in a lamp that
                        is already lit when they get there. */}
                    <Conductor
                      live
                      duration="2.9s"
                      delay={delay}
                      className="h-[5px] w-8 shrink-0 rounded-l-full rounded-r-none sm:w-12"
                    />
                    <Lamp live load duration="2.9s" delay={delay} />
                    <PlateCode live className="shrink-0">
                      {line.code}
                    </PlateCode>
                    <span className="text-fg min-w-0 truncate text-[13px] font-medium">
                      {line.name}
                    </span>
                  </li>
                );
              })}
            </ul>

            <p className="text-dead-300 mt-5 font-mono text-[10px] leading-relaxed tracking-[0.14em] uppercase">
              5 linhas · carga total · um responsável
            </p>
          </div>
        </div>
      </Container>
    </section>
  );
}
