import { Megaphone, Zap, BrainCircuit, Boxes, Star } from "lucide-react";
import { Container } from "@/components/ui/container";
import { ButtonLink } from "@/components/ui/button";
import { Eyebrow } from "@/components/ui/section-heading";
import { GlobeStage } from "@/components/globe/globe-stage";
import { HeroPin, HeroPhase, GlobeFrame } from "@/components/motion/hero-pin";
import { cn } from "@/lib/utils";

const metrics = [
  {
    icon: Megaphone,
    title: "Publicidade digital",
    value: "Google Ads",
    caption: "campanhas para ser encontrado",
  },
  {
    icon: Zap,
    title: "Automação",
    value: "Fluxos",
    caption: "que conectam sua operação",
  },
  {
    icon: BrainCircuit,
    title: "IA Inteligente",
    value: "IA aplicada",
    caption: "para atender e decidir melhor",
  },
  {
    icon: Boxes,
    title: "Sistemas",
    value: "Sob medida",
    caption: "para o jeito de trabalhar da sua empresa",
  },
];

function MetricCard({
  icon: Icon,
  title,
  value,
  caption,
  className,
}: {
  icon: typeof Megaphone;
  title: string;
  value: string;
  caption: string;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "border-line shadow-soft rounded-[14px] border bg-white/85 p-3.5 backdrop-blur-sm",
        className,
      )}
    >
      <div className="flex items-center gap-1.5">
        <Icon className="text-brand-600 size-3.5" />
        <span className="text-fg text-[11px] font-semibold">{title}</span>
      </div>
      <p className="text-brand-600 mt-1.5 text-lg leading-none font-bold">
        {value}
      </p>
      <p className="text-fg-subtle mt-1 text-[10px] leading-tight">{caption}</p>
    </div>
  );
}

function AvatarCluster() {
  const initials = ["MR", "JS", "AL", "CF"];
  return (
    <div className="flex -space-x-2.5">
      {initials.map((label, i) => (
        <span
          key={label}
          aria-hidden
          className={cn(
            "flex size-9 items-center justify-center rounded-full border-2 border-white text-[10px] font-semibold text-white shadow-sm",
            // Charcoal in the run rather than a fourth amber: four ambers in a
            // row read as one smudged pill at 36px.
            ["bg-brand-700", "bg-brand-600", "bg-ink-800", "bg-brand-800"][i],
          )}
        >
          {label}
        </span>
      ))}
    </div>
  );
}

export function Hero() {
  return (
    <HeroPin>
      {/* Ambient wash behind the globe. */}
      <div
        aria-hidden
        className="bg-grid pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_70%_60%_at_70%_35%,black,transparent)] [--grid-color:rgb(168_95_9/0.055)]"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute top-[-15%] right-[-10%] size-[900px] rounded-full bg-[radial-gradient(circle,rgb(243_163_58/0.22),transparent_62%)]"
      />

      <Container size="wide" className="relative">
        <div className="grid items-center gap-12 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)] lg:gap-8">
          {/* ---- copy ---- */}
          {/* Clears out once the globe starts breaking apart, so the sequence
              has the stage to itself. */}
          <HeroPhase className="max-w-xl" exitBy={0.34} lift={-70}>
            <Eyebrow>Soluções digitais inteligentes</Eyebrow>

            <h1 className="mt-4 text-[40px] leading-[1.08] font-bold sm:text-[52px] xl:text-[58px]">
              Transformamos sua presença digital em{" "}
              <span className="text-brand-600">
                uma ferramenta para atrair e atender melhor.
              </span>
            </h1>

            <p className="text-fg-muted mt-6 max-w-md text-[15px] leading-relaxed">
              Criamos sites, sistemas personalizados, automações inteligentes,
              soluções com Inteligência Artificial e campanhas de Google Ads
              para empresas que querem crescer.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <ButtonLink href="#contato" size="lg" withArrow>
                Solicitar orçamento
              </ButtonLink>
              <ButtonLink href="#cases" size="lg" variant="secondary">
                Ver projetos
              </ButtonLink>
            </div>

            <div className="mt-10 flex items-center gap-4">
              <AvatarCluster />
              <div>
                <p className="text-fg text-[13px] font-medium">
                  +120 empresas atendidas
                </p>
                <div className="mt-0.5 flex items-center gap-1.5">
                  <div className="flex gap-0.5" aria-hidden>
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className="fill-brand-500 text-brand-500 size-3.5"
                      />
                    ))}
                  </div>
                  <span className="text-fg text-[13px] font-semibold">5.0</span>
                </div>
              </div>
            </div>
          </HeroPhase>

          {/* ---- globe stage + metric rail ---- */}
          <div className="flex items-center gap-4">
            <GlobeFrame className="relative mx-auto aspect-square w-full max-w-[600px] min-w-0 flex-1">
              <GlobeStage />
            </GlobeFrame>

            {/* Rail beside the globe on xl; a grid underneath below that.
                Each card leaves at its own moment so the stack peels away. */}
            <div className="hidden w-[168px] shrink-0 flex-col gap-3 xl:flex">
              {metrics.map((m, i) => (
                <HeroPhase
                  key={m.title}
                  exitBy={0.22 + i * 0.04}
                  lift={-40}
                  slide={60}
                >
                  <MetricCard {...m} />
                </HeroPhase>
              ))}
            </div>
          </div>

          <HeroPhase
            exitBy={0.3}
            lift={-30}
            className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:col-span-2 xl:hidden"
          >
            {metrics.map((m) => (
              <MetricCard key={m.title} {...m} />
            ))}
          </HeroPhase>
        </div>
      </Container>
    </HeroPin>
  );
}
