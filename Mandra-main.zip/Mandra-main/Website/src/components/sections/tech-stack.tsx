import { techStack } from "@/content/tech";
import { Eyebrow } from "@/components/ui/section-heading";
import { ScrollInStagger } from "@/components/motion/scroll-motion";

/**
 * Several brand marks (Next.js, Vercel, GitHub, OpenAI) are near-black and
 * would vanish on this panel, so anything below a luminance floor renders
 * white instead of its official colour.
 */
function chipColor(hex: string) {
  const [r, g, b] = [0, 2, 4].map(
    (i) => parseInt(hex.slice(i, i + 2), 16) / 255,
  );
  const luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  return luminance < 0.3 ? "#ffffff" : `#${hex}`;
}

/**
 * Dark panel of technology chips. Sits beside the process timeline on xl and
 * stacks beneath it below that, per the reference. Carries its own
 * `data-tone="dark"` so it reads correctly on the surrounding light band.
 */
export function TechStack() {
  return (
    <div
      id="tecnologias"
      data-tone="dark"
      className="rounded-panel bg-ink-950 text-fg shadow-raised scroll-mt-24 p-7 sm:p-8"
    >
      <Eyebrow className="text-brand-400">Tecnologias que utilizamos</Eyebrow>

      <ul className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-2">
        {techStack.map((tech, i) => (
          <ScrollInStagger
            as="li"
            key={tech.name}
            index={i % 4}
            y={36}
            className="border-line hover:border-line-strong flex items-center gap-2.5 rounded-[12px] border bg-white/[0.03] px-3 py-2.5 transition-colors hover:bg-white/[0.06]"
          >
            <span
              className="flex size-7 shrink-0 items-center justify-center rounded-[8px] bg-white/[0.06]"
              style={{ color: chipColor(tech.hex) }}
            >
              {tech.path ? (
                <svg
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  aria-hidden
                  className="size-4"
                >
                  <path d={tech.path} />
                </svg>
              ) : (
                <span aria-hidden className="text-[9px] font-bold lowercase">
                  {tech.name}
                </span>
              )}
            </span>
            <span className="text-fg truncate text-[13px] font-medium">
              {tech.name}
            </span>
          </ScrollInStagger>
        ))}
      </ul>
    </div>
  );
}
