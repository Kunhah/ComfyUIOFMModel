import { stats } from "@/content/stats";
import { Container } from "@/components/ui/container";
import { Appear } from "@/components/motion/scroll-motion";

/**
 * Elevated card straddling the hero and the section below it, matching the
 * reference. Negative top margin does the overlap; the parent section supplies
 * no padding of its own.
 */
export function Stats() {
  return (
    <div className="relative z-10 -mt-16 sm:-mt-20">
      <Container size="wide">
        <Appear>
          <div className="rounded-panel border-line bg-line shadow-raised grid grid-cols-2 gap-px overflow-hidden border lg:grid-cols-4">
            {stats.map(({ value, label, icon: Icon }) => (
              <div
                key={label}
                className="flex items-center gap-4 bg-white px-6 py-7 sm:px-8"
              >
                <span className="bg-brand-50 text-brand-600 flex size-11 shrink-0 items-center justify-center rounded-full">
                  <Icon className="size-5" />
                </span>
                <div>
                  <p className="text-fg text-[26px] leading-none font-bold">
                    {value}
                  </p>
                  <p className="text-fg-muted mt-1.5 text-[13px]">{label}</p>
                </div>
              </div>
            ))}
          </div>
        </Appear>
      </Container>
    </div>
  );
}
