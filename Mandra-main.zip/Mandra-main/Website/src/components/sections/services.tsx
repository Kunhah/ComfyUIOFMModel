"use client";

import { services } from "@/content/services";
import { Container } from "@/components/ui/container";
import { Section } from "@/components/ui/section";
import { Eyebrow } from "@/components/ui/section-heading";
import { ArrowLink } from "@/components/ui/button";
import { IconTile } from "@/components/ui/card";
import {
  PinnedShowcase,
  ShowcasePanel,
  ShowcaseIndexItem,
} from "@/components/motion/pinned-showcase";

/**
 * Pinned showcase: the section holds the screen while each service panel
 * transitions into the next, with the index on the left tracking progress.
 */
export function Services() {
  return (
    <Section id="servicos" tone="muted" spacing="none">
      <PinnedShowcase count={services.length}>
        <Container size="wide" className="w-full">
          <div className="grid items-center gap-12 lg:grid-cols-[minmax(0,0.78fr)_minmax(0,1.22fr)] lg:gap-16">
            {/* ---- heading + index ---- */}
            <div>
              <Eyebrow>Do primeiro clique ao atendimento</Eyebrow>
              <h2 className="mt-3 text-3xl leading-[1.12] font-bold sm:text-[40px]">
                Uma presença digital que trabalha pelo seu negócio
              </h2>

              <ul className="border-line mt-9 border-t max-lg:hidden">
                {services.map((service, i) => (
                  <ShowcaseIndexItem
                    key={service.id}
                    index={i}
                    label={service.title}
                  />
                ))}
              </ul>

              <div className="mt-8">
                <ArrowLink href="#contato">Falar com um especialista</ArrowLink>
              </div>
            </div>

            {/* ---- panel stage ---- */}
            <div className="relative min-h-[430px] max-lg:!min-h-0 lg:min-h-[460px]">
              {services.map(({ id, title, icon: Icon, items }, i) => (
                <ShowcasePanel key={id} index={i}>
                  <div className="rounded-panel border-line bg-surface-raised shadow-raised flex h-full flex-col justify-center border p-8 sm:p-10">
                    <div className="flex items-center gap-4">
                      <IconTile className="size-12 rounded-[14px]">
                        <Icon className="size-6" />
                      </IconTile>
                      <span className="text-fg-subtle font-mono text-[13px]">
                        {String(i + 1).padStart(2, "0")} /{" "}
                        {String(services.length).padStart(2, "0")}
                      </span>
                    </div>

                    <h3 className="text-fg mt-6 text-2xl leading-tight font-bold sm:text-[28px]">
                      {title}
                    </h3>

                    <ul className="mt-6 grid gap-x-6 gap-y-3 sm:grid-cols-2">
                      {items.map((item) => (
                        <li
                          key={item}
                          className="text-fg-muted flex items-center gap-2.5 text-[15px]"
                        >
                          <span
                            aria-hidden
                            className="bg-brand-500 size-1.5 shrink-0 rounded-full"
                          />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </ShowcasePanel>
              ))}
            </div>
          </div>
        </Container>
      </PinnedShowcase>
    </Section>
  );
}
