"use client";

import { caseStudies } from "@/content/cases";
import { Container } from "@/components/ui/container";
import { Section } from "@/components/ui/section";
import { Eyebrow } from "@/components/ui/section-heading";
import { Badge, CategoryLabel } from "@/components/ui/badge";
import { ArrowLink } from "@/components/ui/button";
import { LogoMark } from "@/components/ui/logo";
import {
  PinnedShowcase,
  ShowcasePanel,
  ShowcaseIndexItem,
} from "@/components/motion/pinned-showcase";
import { cn } from "@/lib/utils";

/**
 * Stand-in for a real project screenshot: a tinted gradient plate with faint
 * browser chrome and the Mandra mark. Swapped for `next/image` once assets land.
 */
function CasePlate({ gradient, title }: { gradient: string; title: string }) {
  return (
    <div
      role="img"
      aria-label={`Prévia do projeto ${title}`}
      className={cn(
        "rounded-card relative aspect-[16/10] w-full overflow-hidden bg-gradient-to-br",
        gradient,
      )}
    >
      <div className="absolute inset-x-0 top-0 flex items-center gap-1.5 px-4 py-3">
        <span className="size-2 rounded-full bg-white/25" />
        <span className="size-2 rounded-full bg-white/25" />
        <span className="size-2 rounded-full bg-white/25" />
      </div>
      <div className="absolute inset-x-5 top-11 bottom-5 rounded-lg border border-white/10 bg-white/[0.04] backdrop-blur-[1px]" />
      <div className="absolute inset-0 flex items-center justify-center">
        <LogoMark className="size-12 opacity-40" />
      </div>
    </div>
  );
}

/**
 * Pinned showcase: each case takes over the screen in turn, its plate and
 * details swapping together as the section scrolls.
 */
export function Cases() {
  // Note: no `overflow-hidden` on the Section — an overflow other than visible
  // on any ancestor silently disables the sticky pin inside it.
  return (
    <Section id="cases" tone="dark" spacing="none">
      {/* Clipper is a sibling of the showcase, never an ancestor of the sticky
          panel — putting overflow-hidden above that would disable the pin. */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 overflow-hidden"
      >
        <div className="absolute top-1/4 -left-40 size-[620px] rounded-full bg-[radial-gradient(circle,rgb(243_163_58/0.14),transparent_65%)]" />
      </div>

      <PinnedShowcase count={caseStudies.length}>
        <Container size="wide" className="relative w-full">
          <div className="grid items-center gap-12 lg:grid-cols-[minmax(0,0.72fr)_minmax(0,1.28fr)] lg:gap-16">
            {/* ---- heading + index ---- */}
            <div>
              <Eyebrow>Projetos que geram resultados</Eyebrow>
              <h2 className="mt-3 text-3xl leading-[1.12] font-bold sm:text-[40px]">
                Cases de sucesso
              </h2>

              <ul className="border-line mt-9 border-t max-lg:hidden">
                {caseStudies.map((item, i) => (
                  <ShowcaseIndexItem
                    key={item.id}
                    index={i}
                    label={item.title}
                  />
                ))}
              </ul>

              <div className="mt-8">
                <ArrowLink href="#contato">Ver todos os cases</ArrowLink>
              </div>
            </div>

            {/* ---- panel stage ---- */}
            <div className="relative min-h-[560px] max-lg:!min-h-0 lg:min-h-[640px]">
              {caseStudies.map((item, i) => (
                <ShowcasePanel key={item.id} index={i}>
                  <div className="flex h-full flex-col justify-center">
                    <CasePlate gradient={item.gradient} title={item.title} />

                    <div className="mt-6 flex flex-wrap items-end justify-between gap-4">
                      <div>
                        <CategoryLabel>{item.category}</CategoryLabel>
                        <h3 className="text-fg mt-2 text-xl font-bold sm:text-2xl">
                          {item.title}
                        </h3>
                        <p className="text-fg-muted mt-2 max-w-md text-[15px] leading-relaxed">
                          {item.result}
                        </p>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {item.stack.map((tech) => (
                          <Badge key={tech}>{tech}</Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </ShowcasePanel>
              ))}
            </div>
          </div>
        </Container>
      </PinnedShowcase>
    </Section>
  );
}
