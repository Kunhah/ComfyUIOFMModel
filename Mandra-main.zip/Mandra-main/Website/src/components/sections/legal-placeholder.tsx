import Link from "next/link";
import { Mail, ArrowLeft } from "lucide-react";
import { site } from "@/content/site";
import { Container } from "@/components/ui/container";
import { Section } from "@/components/ui/section";
import { Legend } from "@/components/rede/plate";

/**
 * Placeholder for the legal pages. These routes exist so the footer links
 * resolve instead of 404-ing, but the actual policy text has to come from the
 * client's counsel — inventing it here would be worse than saying it's pending.
 */
export function LegalPlaceholder({
  kind,
  title,
}: {
  /** Stamped on the legend strip, the way every named thing on the site is. */
  kind: string;
  title: string;
}) {
  return (
    <main data-rede className="flex-1">
      <Section tone="night" spacing="lg">
        <Container size="narrow">
          <Legend>{kind}</Legend>
          <h1 className="font-display mt-5 text-[clamp(1.9rem,4vw,2.9rem)] leading-[1.02] font-extrabold tracking-[-0.03em]">
            {title}
          </h1>

          <p className="text-fg-muted mt-6 text-[15px] leading-relaxed">
            Este documento está em elaboração e será publicado em breve.
            Enquanto isso, se você tiver qualquer dúvida sobre como tratamos
            seus dados ou sobre as condições dos nossos serviços, fale
            diretamente com a nossa equipe — respondemos em até 1 dia útil.
          </p>

          <a
            href={site.contact.emailHref}
            className="plate text-fg hover:text-brand-300 mt-8 inline-flex items-center gap-2.5 rounded-[4px] px-4 py-3 text-sm font-medium transition-colors duration-200"
          >
            <Mail aria-hidden className="text-brand-400 size-4" />
            {site.contact.email}
          </a>

          <div className="border-line mt-12 border-t pt-6">
            <Link
              href="/"
              className="group text-brand-400 hover:text-brand-300 inline-flex items-center gap-2 text-sm font-medium transition-colors"
            >
              <ArrowLeft
                aria-hidden
                className="size-4 transition-transform group-hover:-translate-x-0.5"
              />
              Voltar para a página inicial
            </Link>
          </div>
        </Container>
      </Section>
    </main>
  );
}
