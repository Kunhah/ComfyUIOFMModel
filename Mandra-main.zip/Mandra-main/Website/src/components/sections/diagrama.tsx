"use client";

import { useEffect, useRef, useState } from "react";
import {
  MonitorSmartphone,
  ShoppingCart,
  LayoutTemplate,
  Users,
  Mail,
  BrainCircuit,
  BarChart3,
  Plug,
  Boxes,
  type LucideIcon,
} from "lucide-react";
import { siWhatsapp } from "simple-icons";
import {
  inputNodes,
  outputNodes,
  topNode,
  baseNodes,
  type EcosystemNode,
} from "@/content/ecosystem";
import { Container } from "@/components/ui/container";
import { Legend, Lamp, PlateCode } from "@/components/rede/plate";
import { LogoMark } from "@/components/ui/logo";
import { cn } from "@/lib/utils";

/**
 * The wiring diagram, on paper.
 *
 * The old ecosystem section returned to the page and put in the register it
 * always belonged in: it is a schematic, so it is drawn rather than lit.
 *
 * Every node is actually wired. That is not decoration — a section called "the
 * diagram", on a page whose thesis is that every line gets terminated and
 * numbered, cannot show nine boxes near a core and call them connected. Each
 * run is a real conductor ending in a numbered lug on the core's edge, so the
 * count of lugs and the count of nodes are the same number and a reader can
 * follow any one line from its box to where it lands.
 *
 * ── Following a line ───────────────────────────────────────────────────────
 *
 * A schematic's whole value is that you can trace one line through it, and on
 * a screen the reader should not have to do that with a finger. Exactly one
 * terminal carries at a time: its run energizes in the direction the load
 * actually travels — inputs feed the core, the core drives outputs — its lug
 * lights, and every other node steps back so the traced line is the only thing
 * with contrast.
 *
 * The same binary as Linhas, and on the same clock, because the page is one
 * panel and two sections energizing at two different rates would read as two
 * different systems. It runs on its own until there is a pointer and then does
 * what the pointer says, so it is never a dead drawing and never an animation
 * that ignores the reader.
 */

const icons: Record<string, LucideIcon> = {
  monitor: MonitorSmartphone,
  cart: ShoppingCart,
  layout: LayoutTemplate,
  users: Users,
  mail: Mail,
  brain: BrainCircuit,
  chart: BarChart3,
  plug: Plug,
  boxes: Boxes,
};

/**
 * Every terminal on the board, in the order the load travels: what feeds the
 * core, the core's own intelligence, what it drives, and what it writes down.
 * The cycle walks this, so the idle state reads as a circuit being traced
 * rather than as boxes taking turns flashing.
 */
const ORDER = [
  ...inputNodes.map((n) => n.id),
  topNode.id,
  ...outputNodes.map((n) => n.id),
  ...baseNodes.map((n) => n.id),
];

function NodeIcon({ name }: { name: string }) {
  if (name === "whatsapp") {
    return (
      <svg
        viewBox="0 0 24 24"
        fill="currentColor"
        aria-hidden
        className="size-4"
      >
        <path d={siWhatsapp.path} />
      </svg>
    );
  }
  const Icon = icons[name] ?? Plug;
  return <Icon aria-hidden className="size-4" />;
}

/**
 * A ruled field carrying one node's identity. No fill, no shadow — ink.
 *
 * It is a button because it is the thing the reader aims at: making the plate
 * itself the control means the line can be traced by keyboard as well as by
 * pointer, and `aria-pressed` is what tells a screen reader which terminal the
 * board is currently reporting on.
 */
function NodeField({
  node,
  code,
  live,
  dim,
  onEnter,
  onRelease,
}: {
  node: EcosystemNode;
  code: string;
  live: boolean;
  dim: boolean;
  onEnter: () => void;
  onRelease: () => void;
}) {
  return (
    <button
      type="button"
      aria-pressed={live}
      onMouseEnter={onEnter}
      onFocus={onEnter}
      // A tap on a touch screen focuses the plate and no `mouseleave` ever
      // follows it, so without this the board latches on whatever was tapped
      // and the cycle never starts again. Blur is the only release a touch
      // reader will ever generate.
      onBlur={onRelease}
      className={cn(
        "plate ease-out-soft group flex min-w-0 flex-1 cursor-pointer items-center gap-3 rounded-[3px] px-3.5 py-3 text-left",
        "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--ink-accent)]",
        "transition-[opacity,transform,box-shadow] duration-500",
        live && "-translate-y-px shadow-[0_2px_14px_-4px_rgb(243_163_58/0.55)]",
        dim && "opacity-45",
      )}
    >
      <span
        className={cn(
          "shrink-0 transition-colors duration-500",
          live ? "text-[var(--ink-accent)]" : "text-brand-600",
        )}
      >
        <NodeIcon name={node.icon} />
      </span>
      <span className="min-w-0 flex-1">
        <span className="text-fg block truncate text-[13px] leading-tight font-semibold">
          {node.title}
        </span>
        <span className="text-fg-subtle block truncate text-[11px] leading-tight">
          {node.caption}
        </span>
      </span>
      <PlateCode live={live} className="shrink-0">
        {code}
      </PlateCode>
    </button>
  );
}

/**
 * The run from a node to the core, ending in a lug.
 *
 * `flow` is the direction the load actually travels on this side of the board,
 * not the direction the run is drawn in — an input feeds the core and an output
 * is driven by it, so a single travel direction would have half the diagram
 * lying about which way its current goes.
 */
function Run({ side, live }: { side: "left" | "right"; live: boolean }) {
  return (
    <span
      aria-hidden
      className={cn(
        "hidden items-center lg:flex",
        side === "left" ? "flex-row" : "flex-row-reverse",
      )}
    >
      <span className="conductor relative h-[3px] w-6 overflow-hidden xl:w-10">
        <span
          className={cn(
            "absolute inset-y-0 left-0 w-[55%] transition-opacity duration-300",
            side === "left"
              ? "bg-[linear-gradient(90deg,transparent,rgb(255_216_160))]"
              : "bg-[linear-gradient(270deg,transparent,rgb(255_216_160))]",
            live ? "current-run opacity-100" : "opacity-0",
          )}
          style={{ ["--current-duration" as string]: "1.5s" }}
        />
      </span>
      <span
        className={cn(
          "size-[7px] rounded-full transition-[background-color,box-shadow] duration-500",
          live
            ? "bg-[var(--ink-accent)] shadow-[0_0_9px_2px_rgb(243_163_58/0.5)]"
            : "bg-brand-600",
        )}
      />
    </span>
  );
}

function VerticalRun({ live }: { live?: boolean }) {
  return (
    <span aria-hidden className="flex flex-col items-center">
      <span className="conductor relative h-7 w-[3px] overflow-hidden rounded-full">
        <span
          className={cn(
            "absolute inset-x-0 top-0 h-[55%] bg-[linear-gradient(180deg,transparent,rgb(255_216_160))] transition-opacity duration-300",
            live ? "current-drop opacity-100" : "opacity-0",
          )}
          style={{ ["--current-duration" as string]: "1.5s" }}
        />
      </span>
      <span
        className={cn(
          "size-[7px] rounded-full transition-[background-color,box-shadow] duration-500",
          live
            ? "bg-[var(--ink-accent)] shadow-[0_0_9px_2px_rgb(243_163_58/0.5)]"
            : "bg-brand-600",
        )}
      />
    </span>
  );
}

/**
 * The same wiring at 390, where the columns collapse into one stack.
 *
 * The horizontal runs cannot survive the reflow, so below lg each group is
 * tapped off a vertical bus down its left edge and the bus continues toward
 * the core. Without this the section reflows into exactly the unwired boxes
 * the desktop fix was raised against, under a caption that promises ten
 * terminals.
 */
function Bus({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative pl-7 lg:pl-0">
      <span
        aria-hidden
        className="conductor absolute top-3 bottom-3 left-[6px] w-[3px] rounded-full lg:hidden"
      />
      {children}
    </div>
  );
}

/** A tap off the mobile bus, sitting on the node's left edge. */
function Tap({ live }: { live: boolean }) {
  return (
    <span
      aria-hidden
      className={cn(
        "absolute top-1/2 -left-7 size-[7px] -translate-y-1/2 rounded-full transition-[background-color,box-shadow] duration-500 lg:hidden",
        live
          ? "bg-[var(--ink-accent)] shadow-[0_0_9px_2px_rgb(243_163_58/0.5)]"
          : "bg-brand-600",
      )}
    />
  );
}

export function Diagrama() {
  const sectionRef = useRef<HTMLElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const [held, setHeld] = useState(false);
  const [inView, setInView] = useState(false);

  const active = ORDER[activeIndex];
  /** Nothing is dimmed until something is actually being traced. */
  const isDim = (id: string) => active !== id;

  useEffect(() => {
    const node = sectionRef.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      ([entry]) => setInView(entry.isIntersecting),
      { rootMargin: "-15% 0px -15% 0px" },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!inView || held) return;
    // The page's one clock — the same cadence Linhas and the hero switch on.
    const id = window.setInterval(
      () => setActiveIndex((i) => (i + 1) % ORDER.length),
      2800,
    );
    return () => window.clearInterval(id);
  }, [inView, held]);

  const take = (id: string) => () => {
    setHeld(true);
    setActiveIndex(ORDER.indexOf(id));
  };
  const release = () => setHeld(false);

  return (
    <section
      ref={sectionRef}
      id="diagrama"
      data-section="diagrama"
      data-tone="muted"
      className="bg-surface text-fg relative py-20 sm:py-28"
      onMouseLeave={() => setHeld(false)}
    >
      <Container size="wide">
        <div className="max-w-[40rem]">
          <h2 className="font-display text-[clamp(1.9rem,4vw,3.1rem)] leading-[1.02] font-extrabold tracking-[-0.03em]">
            O diagrama da sua operação.
          </h2>
          <p className="text-fg-muted mt-5 max-w-[56ch] text-[15px] leading-relaxed">
            Tudo o que entra, tudo o que é acionado, e a caixa no meio que faz
            uma coisa saber da outra. Dez linhas, dez terminais.
          </p>
          {/* Only where there is a cursor to pass. On a touch screen the board
              cycles itself and this line would be instructing the reader to
              use a device they are not holding. */}
          <p className="text-fg-subtle mt-4 hidden font-mono text-[10px] tracking-[0.2em] uppercase [@media(hover:hover)]:block">
            Passe o cursor por um terminal para seguir a linha
          </p>
        </div>

        <div className="mt-14 grid gap-4 sm:mt-20 lg:grid-cols-[minmax(0,1fr)_auto_minmax(0,1fr)] lg:items-center lg:gap-0">
          {/* What feeds the core. */}
          <div>
            <Legend>Entra</Legend>
            <Bus>
              <ul className="mt-4 flex flex-col gap-3">
                {inputNodes.map((n, i) => (
                  <li key={n.id} className="relative flex items-center">
                    <Tap live={active === n.id} />
                    <NodeField
                      node={n}
                      code={`E-0${i + 1}`}
                      live={active === n.id}
                      dim={isDim(n.id)}
                      onEnter={take(n.id)}
                      onRelease={release}
                    />
                    <Run side="left" live={active === n.id} />
                  </li>
                ))}
              </ul>
            </Bus>
          </div>

          {/* Carries the bus from the ENTRA stack into the core at mobile. */}
          <div className="flex justify-start pl-[6px] lg:hidden">
            <VerticalRun live={inputNodes.some((n) => n.id === active)} />
          </div>

          {/* The core, with intelligence above and the records below. */}
          <div className="flex flex-col items-center">
            <ul className="w-full max-w-[16rem] lg:w-[16rem]">
              <li className="flex items-center">
                <NodeField
                  node={topNode}
                  code="IA-00"
                  live={active === topNode.id}
                  dim={isDim(topNode.id)}
                  onEnter={take(topNode.id)}
                  onRelease={release}
                />
              </li>
            </ul>
            <VerticalRun live={active === topNode.id} />

            <div className="plate relative flex w-full max-w-[16rem] flex-col items-center gap-2 rounded-[5px] px-5 py-6 lg:w-[16rem]">
              <LogoMark className="size-8" />
              <span className="text-fg text-sm font-bold tracking-[-0.01em]">
                Mandra Core
              </span>
              <span className="text-fg-subtle text-[11px]">
                A caixa onde tudo termina
              </span>
              {/* The core is the one terminal that never goes quiet: every line
                  on the board lands here, so it carries whichever one is being
                  traced and reports the board's own count rather than a figure
                  nobody can check. */}
              <span className="mt-1 flex items-center gap-2">
                <Lamp live load />
                <span className="text-brand-600 font-mono text-[10px] tracking-[0.2em] uppercase">
                  {ORDER.length} linhas sob carga
                </span>
              </span>
            </div>

            <VerticalRun live={baseNodes.some((n) => n.id === active)} />
            <Bus>
              <ul className="grid w-full max-w-[16rem] gap-3 lg:w-[16rem]">
                {baseNodes.map((n, i) => (
                  <li key={n.id} className="relative flex items-center">
                    <Tap live={active === n.id} />
                    <NodeField
                      node={n}
                      code={`B-0${i + 1}`}
                      live={active === n.id}
                      dim={isDim(n.id)}
                      onEnter={take(n.id)}
                      onRelease={release}
                    />
                  </li>
                ))}
              </ul>
            </Bus>
          </div>

          {/* What the core drives. */}
          <div>
            <Legend>Sai</Legend>
            <Bus>
              <ul className="mt-4 flex flex-col gap-3">
                {outputNodes.map((n, i) => (
                  <li key={n.id} className="relative flex items-center">
                    <Tap live={active === n.id} />
                    <Run side="right" live={active === n.id} />
                    <NodeField
                      node={n}
                      code={`S-0${i + 1}`}
                      live={active === n.id}
                      dim={isDim(n.id)}
                      onEnter={take(n.id)}
                      onRelease={release}
                    />
                  </li>
                ))}
              </ul>
            </Bus>
          </div>
        </div>
      </Container>
    </section>
  );
}
