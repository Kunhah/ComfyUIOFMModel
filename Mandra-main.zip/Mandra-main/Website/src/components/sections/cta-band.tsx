import { Container } from "@/components/ui/container";
import { Section } from "@/components/ui/section";
import { ButtonLink } from "@/components/ui/button";
import { Appear, Parallax } from "@/components/motion/scroll-motion";

export function CtaBand() {
  return (
    <Section tone="brand" spacing="none" className="overflow-hidden">
      <Parallax
        distance={-70}
        className="pointer-events-none absolute inset-x-0 -inset-y-24"
      >
        <div
          aria-hidden
          className="bg-grid size-full [mask-image:linear-gradient(to_right,black,transparent_70%)] [--grid-color:rgb(22_25_29/0.09)] [--grid-size:48px]"
        />
      </Parallax>
      <div
        aria-hidden
        className="pointer-events-none absolute -top-24 -right-24 size-[420px] rounded-full bg-[radial-gradient(circle,rgb(255_236_205/0.5),transparent_65%)]"
      />

      <Container size="wide" className="relative py-14 sm:py-16">
        <Appear className="grid items-center gap-8 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.8fr)_auto]">
          <h2 className="text-fg text-[28px] leading-[1.15] font-bold sm:text-[34px]">
            Sua empresa pode aparecer quando o cliente estiver procurando.
          </h2>

          <p className="text-fg-muted text-sm leading-relaxed">
            Com uma base digital bem construída, as campanhas de Google Ads
            direcionam os cliques para um caminho claro de contato.
          </p>

          <ButtonLink
            href="#contato"
            size="lg"
            variant="inverse"
            withArrow
            className="justify-self-start lg:justify-self-end"
          >
            Quero anunciar com estratégia
          </ButtonLink>
        </Appear>
      </Container>
    </Section>
  );
}
