"use client";

import { useCallback, useSyncExternalStore } from "react";
import useEmblaCarousel from "embla-carousel-react";
import { ArrowLeft, ArrowRight, Star } from "lucide-react";
import { testimonials } from "@/content/testimonials";
import { Container } from "@/components/ui/container";
import { Section } from "@/components/ui/section";
import { Eyebrow } from "@/components/ui/section-heading";
import { Card } from "@/components/ui/card";
import { Appear } from "@/components/motion/scroll-motion";
import { cn } from "@/lib/utils";

function Stars({ count }: { count: number }) {
  return (
    <div
      role="img"
      className="flex gap-0.5"
      aria-label={`${count} de 5 estrelas`}
    >
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          aria-hidden
          className={cn(
            "size-3.5",
            i < count ? "fill-brand-500 text-brand-500" : "text-line-strong",
          )}
        />
      ))}
    </div>
  );
}

export function Testimonials() {
  const [emblaRef, embla] = useEmblaCarousel({
    align: "start",
    loop: false,
    containScroll: "trimSnaps",
  });
  // Embla is an imperative external store; reading it through
  // useSyncExternalStore keeps render in sync without effect-driven setState.
  // Every snapshot returns a primitive so the reference stays stable.
  const subscribe = useCallback(
    (onChange: () => void) => {
      if (!embla) return () => {};
      embla.on("select", onChange).on("reInit", onChange);
      return () => {
        embla.off("select", onChange).off("reInit", onChange);
      };
    },
    [embla],
  );

  const selected = useSyncExternalStore(
    subscribe,
    () => embla?.selectedScrollSnap() ?? 0,
    () => 0,
  );
  const snapCount = useSyncExternalStore(
    subscribe,
    () => embla?.scrollSnapList().length ?? 0,
    () => 0,
  );
  const canPrev = useSyncExternalStore(
    subscribe,
    () => embla?.canScrollPrev() ?? false,
    () => false,
  );
  const canNext = useSyncExternalStore(
    subscribe,
    () => embla?.canScrollNext() ?? false,
    () => false,
  );

  return (
    <Section id="depoimentos" tone="light" spacing="lg">
      <Container size="wide">
        <div className="grid gap-10 lg:grid-cols-[minmax(0,300px)_minmax(0,1fr)] lg:gap-12">
          <Appear>
            <Eyebrow>Quem confia na Mandra</Eyebrow>
            <h2 className="mt-3 text-3xl leading-tight font-bold sm:text-[36px]">
              O que nossos clientes dizem
            </h2>

            <div className="mt-8 flex items-center gap-2">
              <button
                type="button"
                onClick={() => embla?.scrollPrev()}
                disabled={!canPrev}
                aria-label="Depoimento anterior"
                className="border-line text-fg-muted hover:border-brand-400 hover:text-brand-600 disabled:hover:border-line disabled:hover:text-fg-muted flex size-10 items-center justify-center rounded-full border transition-colors disabled:opacity-40"
              >
                <ArrowLeft className="size-4" />
              </button>
              <button
                type="button"
                onClick={() => embla?.scrollNext()}
                disabled={!canNext}
                aria-label="Próximo depoimento"
                className="border-line text-fg-muted hover:border-brand-400 hover:text-brand-600 disabled:hover:border-line disabled:hover:text-fg-muted flex size-10 items-center justify-center rounded-full border transition-colors disabled:opacity-40"
              >
                <ArrowRight className="size-4" />
              </button>
            </div>
          </Appear>

          {/* min-w-0: without it this grid item takes min-width:auto and sizes
              to the Embla track instead of the column, overflowing the page. */}
          <Appear className="min-w-0">
            <div className="overflow-hidden" ref={emblaRef}>
              <ul className="flex gap-5">
                {testimonials.map((t) => (
                  <li
                    key={t.id}
                    className="min-w-0 flex-[0_0_100%] sm:flex-[0_0_50%] xl:flex-[0_0_calc(50%-10px)]"
                  >
                    <Card className="h-full p-6">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-center gap-3">
                          <span
                            aria-hidden
                            className="bg-brand-100 text-brand-700 flex size-10 shrink-0 items-center justify-center rounded-full text-[11px] font-semibold"
                          >
                            {t.initials}
                          </span>
                          <div>
                            <p className="text-fg text-sm font-semibold">
                              {t.name}
                            </p>
                            <p className="text-fg-muted text-xs">{t.role}</p>
                          </div>
                        </div>
                        <Stars count={t.rating} />
                      </div>
                      <blockquote className="text-fg-muted mt-5 text-[13px] leading-relaxed">
                        {t.quote}
                      </blockquote>
                    </Card>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mt-6 flex justify-center gap-1.5 lg:justify-start">
              {Array.from({ length: snapCount }).map((_, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => embla?.scrollTo(i)}
                  aria-label={`Ir para o depoimento ${i + 1}`}
                  aria-current={i === selected}
                  // Visual dot stays small; the button supplies a 24px target.
                  className="group flex size-6 items-center justify-center"
                >
                  <span
                    className={cn(
                      "block h-1.5 rounded-full transition-all duration-300",
                      i === selected
                        ? "bg-brand-500 w-6"
                        : "bg-line-strong group-hover:bg-brand-400 w-1.5",
                    )}
                  />
                </button>
              ))}
            </div>
          </Appear>
        </div>
      </Container>
    </Section>
  );
}
