"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Download,
  Globe,
  Share2,
  Mail,
  Loader2,
  MessageCircle,
  Send,
  Phone,
  Search,
  Trash2,
} from "lucide-react";
import type { Niche } from "@/lib/prospector/niches";
import { outreachMessage, whatsappUrl } from "@/lib/prospector/score";
import type { OutreachContext } from "@/lib/prospector/templates";
import type { ScoredLead, SearchResponse } from "@/lib/prospector/types";
import type { SearchScope } from "@/lib/prospector/types";
import { BRAZIL_REGIONS, BRAZIL_STATES } from "@/lib/prospector/brazil";
import { cn } from "@/lib/utils";
import { ContactedMark } from "@/components/prospector/contacted-mark";

// `businesses`/`noSite` are absent when the option is reconstructed from a deep
// link, where the URL only carries the city, the state and the country.
type CityOption = {
  name: string;
  uf: string;
  country: string;
  businesses?: number;
  noSite?: number;
};

/** One country the local extract can actually answer for. */
export type CountryOption = {
  code: string;
  label: string;
  /** The part of the world it is filed under, for the picker's groups. */
  region: string;
  cities: number;
  noSite: number;
};

/** A search expressed in the URL, parsed server-side in page.tsx. */
export type InitialSearch = {
  niche: string;
  scope?: SearchScope;
  city: string;
  uf: string;
  region?: string;
  country: string;
  onlyWithoutWebsite: boolean;
  minConfidence: number;
  save: boolean;
};

export function Prospector({
  niches,
  countries,
  defaultCountry,
  initialSearch,
  initialResult,
  initialError,
  canExport,
  outreach,
}: {
  niches: Niche[];
  /** Countries present in the extract, grouped by part of the world in the picker. */
  countries: CountryOption[];
  /** The one with the most reach — what a first-time search starts on. */
  defaultCountry: string;
  initialSearch: InitialSearch | null;
  /** Results for a URL-driven search, already run on the server. */
  initialResult: SearchResponse | null;
  initialError: string | null;
  /** Whether this account holds the "export" permission. The route re-checks. */
  canExport: boolean;
  /**
   * This operator's openers and their name, as the server read them. Every
   * wa.me link on this board is written from them — see `outreachMessage()`; a
   * board that fell back to the built-in copy would send a different message
   * from the one the same lead gets in the CRM two clicks away.
   */
  outreach: OutreachContext;
}) {
  // Seeded from the prop, so the server and client render identically and no
  // effect has to write state to catch up with the URL.
  const [niche, setNiche] = useState(
    initialSearch?.niche ?? niches[0]?.slug ?? "",
  );
  const [country, setCountry] = useState(
    initialSearch?.country ?? defaultCountry,
  );
  const [scope, setScope] = useState<SearchScope>(
    initialSearch?.scope ?? "city",
  );
  const [stateUf, setStateUf] = useState(initialSearch?.uf || "SP");
  const [region, setRegion] = useState(initialSearch?.region || "sudeste");
  const [cityQuery, setCityQuery] = useState(
    initialSearch ? cityLabel(initialSearch.city, initialSearch.uf) : "",
  );
  const [city, setCity] = useState<CityOption | null>(
    initialSearch?.city
      ? {
          name: initialSearch.city,
          uf: initialSearch.uf,
          country: initialSearch.country,
        }
      : null,
  );
  const [options, setOptions] = useState<CityOption[]>([]);
  const [showOptions, setShowOptions] = useState(false);

  // Marketing niches are prospected the other way round — see `scorePartner` in
  // score.ts. The server forces the no-website filter off for them; the checkbox
  // has to say so, or it reads as a control that silently does nothing.
  const partnership =
    niches.find((n) => n.slug === niche)?.intent === "parceiro";
  const [onlyWithoutWebsite, setOnlyWithoutWebsite] = useState(
    initialSearch?.onlyWithoutWebsite ?? true,
  );
  const [minConfidence, setMinConfidence] = useState(
    initialSearch?.minConfidence ?? 0.5,
  );
  // OSM is an additive second directory. It is on by default; a best-effort
  // failure never suppresses the local Overture results.
  const [includeOpenStreetMap, setIncludeOpenStreetMap] = useState(true);
  // Writing to the history is the default — it is what makes "novo" mean
  // anything. Turning it off is for sizing a market rather than working it.
  const [save, setSave] = useState(initialSearch?.save ?? true);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(initialError);
  const [result, setResult] = useState<SearchResponse | null>(initialResult);
  const [filter, setFilter] = useState("");

  // Debounced city autocomplete. The index lives on the server (345KB), so this
  // is a fetch rather than a local filter.
  //
  // Nothing is cleared here on a too-short query: setState in an effect body
  // triggers a cascading render. Whether stale options are shown is derived at
  // render time instead (`visibleOptions` below).
  useEffect(() => {
    if (cityQuery.trim().length < 2) return;
    const controller = new AbortController();
    const timer = setTimeout(() => {
      fetch(
        `/api/prospector/cities?q=${encodeURIComponent(cityQuery)}&country=${encodeURIComponent(country)}`,
        { signal: controller.signal },
      )
        .then((r) => r.json())
        .then((d) => setOptions(d.cities ?? []))
        .catch(() => {
          /* aborted or offline — leave the previous options in place */
        });
    }, 150);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [cityQuery, country]);

  /** Takes explicit args so a URL-driven search doesn't have to wait for state. */
  const runSearch = useCallback(
    async (args: {
      niche: string;
      scope: SearchScope;
      city?: string;
      uf?: string;
      region?: string;
      country: string;
      onlyWithoutWebsite: boolean;
      minConfidence: number;
      includeOpenStreetMap: boolean;
      save: boolean;
    }) => {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch("/api/prospector/search", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ ...args, limit: 1000 }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error ?? `Erro ${res.status}`);
        setResult(data as SearchResponse);
        setFilter("");

        // Put the search in the address bar so it can be shared or bookmarked.
        // replaceState, not pushState: a search isn't a navigation, and stacking
        // history entries would make Back feel broken.
        const qs = new URLSearchParams({
          niche: args.niche,
          country: args.country,
          scope: args.scope,
          conf: String(args.minConfidence),
        });
        if (args.city) qs.set("city", args.city);
        if (args.uf) qs.set("uf", args.uf);
        if (args.region) qs.set("region", args.region);
        if (!args.onlyWithoutWebsite) qs.set("all", "1");
        // Carried in the link too, so a shared "just looking" search doesn't
        // start writing to the history the moment somebody else opens it.
        if (!args.save) qs.set("save", "0");
        window.history.replaceState(null, "", `?${qs}`);
      } catch (err) {
        setError(err instanceof Error ? err.message : String(err));
        setResult(null);
      } finally {
        setLoading(false);
      }
    },
    [],
  );

  const search = useCallback(() => {
    if (scope === "city" && !city) {
      setError("Escolha uma cidade da lista.");
      return;
    }
    return runSearch({
      niche,
      scope,
      city: scope === "city" ? city?.name : undefined,
      uf: scope === "city" ? city?.uf : scope === "state" ? stateUf : undefined,
      region: scope === "region" ? region : undefined,
      country,
      onlyWithoutWebsite,
      minConfidence,
      includeOpenStreetMap: scope === "city" && includeOpenStreetMap,
      save,
    });
  }, [
    city,
    country,
    scope,
    stateUf,
    region,
    niche,
    onlyWithoutWebsite,
    minConfidence,
    includeOpenStreetMap,
    save,
    runSearch,
  ]);

  /**
   * Drops leads from the local history without leaving the board.
   *
   * Removed from the table as well as from the database: leaving a row that no
   * longer exists on screen invites a second click that reports "não
   * encontrado", and the count beside the export button would then lie.
   */
  const [deleting, setDeleting] = useState<string | null>(null);
  const deleteLead = useCallback(async (lead: ScoredLead) => {
    setDeleting(lead.id);
    try {
      const res = await fetch("/api/prospector/history/delete", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ ids: [lead.id] }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? `Erro ${res.status}`);
      setResult((current) =>
        current
          ? {
              ...current,
              leads: current.leads.filter((l) => l.id !== lead.id),
              stats: { ...current.stats, returned: current.stats.returned - 1 },
            }
          : current,
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setDeleting(null);
    }
  }, []);

  // Derived, not stored: a query shorter than the fetch threshold shows nothing,
  // without needing to clear `options` from inside the effect.
  const visibleOptions = cityQuery.trim().length >= 2 ? options : [];

  const visible = useMemo(() => {
    const leads = result?.leads ?? [];
    const q = filter.trim().toLowerCase();
    if (!q) return leads;
    return leads.filter(
      (l) =>
        l.name.toLowerCase().includes(q) ||
        (l.address ?? "").toLowerCase().includes(q) ||
        (l.category ?? "").toLowerCase().includes(q),
    );
  }, [result, filter]);

  const exportCsv = useCallback(async () => {
    if (visible.length === 0) return;
    const nicheLabel = niches.find((n) => n.slug === niche)?.label ?? niche;
    const res = await fetch("/api/prospector/export", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        leads: visible,
        filename: `${nicheLabel}-${scopeLabel(scope, city, stateUf, region, country)}`,
      }),
    });
    if (!res.ok) return;
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "leads.csv";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }, [visible, niche, niches, city, scope, stateUf, region, country]);

  return (
    <>
      <form
        className="border-line bg-surface rounded-xl border p-4"
        onSubmit={(e) => {
          e.preventDefault();
          void search();
        }}
      >
        <div className="grid gap-4 md:grid-cols-[minmax(0,1fr)_minmax(0,13rem)_minmax(0,12rem)_minmax(0,1fr)_auto]">
          <Field label="Nicho">
            <select
              value={niche}
              onChange={(e) => setNiche(e.target.value)}
              className="border-line bg-surface-2 focus:border-brand w-full rounded-md border px-3 py-2 text-sm outline-none"
            >
              {/* Grouped: 33 flat options is a scroll hunt, and the families
                  (Beleza, Alimentação, Saúde…) are how you actually think about
                  which campaign to run next. */}
              {groupNiches(niches).map((g) => (
                <optgroup key={g.group} label={g.group}>
                  {g.niches.map((n) => (
                    <option key={n.slug} value={n.slug}>
                      {n.label}
                    </option>
                  ))}
                </optgroup>
              ))}
            </select>
          </Field>

          <Field label="País">
            <select
              value={country}
              onChange={(e) => {
                setCountry(e.target.value);
                if (
                  e.target.value !== "BR" &&
                  (scope === "state" || scope === "region")
                ) {
                  setScope("city");
                }
                // The chosen city belongs to the country it was picked in.
                // Keeping it would search Lisbon's bounding box inside Brazil.
                setCity(null);
                setCityQuery("");
              }}
              className="border-line bg-surface-2 focus:border-brand w-full rounded-md border px-3 py-2 text-sm outline-none"
            >
              {/* Grouped by part of the world, and only countries the extract
                  actually holds — offering one that was never synced offers a
                  search that returns nothing. */}
              {groupCountries(countries).map((g) => (
                <optgroup key={g.region} label={g.region}>
                  {g.countries.map((c) => (
                    <option key={c.code} value={c.code}>
                      {c.label}
                    </option>
                  ))}
                </optgroup>
              ))}
            </select>
          </Field>

          <Field label="Abrangência">
            <select
              value={scope}
              onChange={(e) => setScope(e.target.value as SearchScope)}
              className="border-line bg-surface-2 focus:border-brand w-full rounded-md border px-3 py-2 text-sm outline-none"
            >
              <option value="city">Cidade</option>
              {country === "BR" && <option value="state">Estado</option>}
              {country === "BR" && (
                <option value="region">Região do Brasil</option>
              )}
              <option value="country">
                {country === "BR" ? "Brasil inteiro" : "País inteiro"}
              </option>
            </select>
          </Field>

          <Field
            label={
              scope === "city"
                ? "Cidade"
                : scope === "state"
                  ? "Estado"
                  : scope === "region"
                    ? "Região"
                    : "Área"
            }
          >
            {scope === "city" ? (
              <CityInput
                query={cityQuery}
                onQueryChange={(v) => {
                  setCityQuery(v);
                  setCity(null);
                  setShowOptions(true);
                }}
                options={visibleOptions}
                show={showOptions}
                onPick={(c) => {
                  setCity(c);
                  setCityQuery(cityLabel(c.name, c.uf));
                  setShowOptions(false);
                }}
                onBlur={() => setShowOptions(false)}
                selected={city}
              />
            ) : scope === "state" ? (
              <select
                value={stateUf}
                onChange={(e) => setStateUf(e.target.value)}
                className="border-line bg-surface-2 focus:border-brand w-full rounded-md border px-3 py-2 text-sm outline-none"
              >
                {BRAZIL_STATES.map(([code, label]) => (
                  <option key={code} value={code}>
                    {label} ({code})
                  </option>
                ))}
              </select>
            ) : scope === "region" ? (
              <select
                value={region}
                onChange={(e) => setRegion(e.target.value)}
                className="border-line bg-surface-2 focus:border-brand w-full rounded-md border px-3 py-2 text-sm outline-none"
              >
                {BRAZIL_REGIONS.map((item) => (
                  <option key={item.slug} value={item.slug}>
                    {item.label}
                  </option>
                ))}
              </select>
            ) : (
              <div className="border-line bg-surface-2 text-fg-muted rounded-md border px-3 py-2 text-sm">
                {countries.find((item) => item.code === country)?.label ??
                  country}
              </div>
            )}
          </Field>

          <Field>
            <button
              type="submit"
              disabled={loading || (scope === "city" && !city)}
              className={cn(
                "inline-flex h-[38px] items-center gap-2 rounded-md px-4 text-sm font-medium transition",
                "bg-brand text-brand-fg hover:brightness-110",
                "disabled:cursor-not-allowed disabled:opacity-40",
              )}
            >
              {loading ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Search className="size-4" />
              )}
              {loading ? "Buscando…" : "Buscar"}
            </button>
          </Field>
        </div>

        <div className="border-line mt-4 flex flex-wrap items-center gap-x-6 gap-y-3 border-t pt-4 text-sm">
          <label
            className={
              partnership
                ? "inline-flex items-center gap-2"
                : "inline-flex cursor-pointer items-center gap-2"
            }
          >
            <input
              type="checkbox"
              checked={onlyWithoutWebsite && !partnership}
              onChange={(e) => setOnlyWithoutWebsite(e.target.checked)}
              disabled={partnership}
              className="accent-brand size-4"
            />
            <span className={partnership ? "text-fg-muted" : undefined}>
              Só quem não tem site
              {partnership && " (parceria: mostra todos)"}
            </span>
          </label>

          <label className="inline-flex cursor-pointer items-center gap-2">
            <input
              type="checkbox"
              checked={includeOpenStreetMap && scope === "city"}
              onChange={(e) => setIncludeOpenStreetMap(e.target.checked)}
              disabled={scope !== "city"}
              className="accent-brand size-4"
            />
            <span className={scope !== "city" ? "text-fg-muted" : undefined}>
              Incluir OpenStreetMap {scope !== "city" && "(somente cidade)"}
            </span>
          </label>

          {/* Off means the run leaves nothing behind — for sizing a market or
              trying niches, where a hundred junk leads in the CRM is the cost. */}
          <label className="inline-flex cursor-pointer items-center gap-2">
            <input
              type="checkbox"
              checked={save}
              onChange={(e) => setSave(e.target.checked)}
              className="accent-brand size-4"
            />
            <span>
              Salvar no histórico
              {!save && (
                <span className="text-warm ml-1.5 text-xs">
                  (nada será gravado)
                </span>
              )}
            </span>
          </label>

          <label className="inline-flex items-center gap-3">
            <span className="text-fg-muted">
              Confiança mínima{" "}
              <span className="tnum text-fg">{minConfidence.toFixed(2)}</span>
            </span>
            <input
              type="range"
              min={0}
              max={0.95}
              step={0.05}
              value={minConfidence}
              onChange={(e) => setMinConfidence(Number(e.target.value))}
              className="accent-brand w-40"
            />
          </label>
        </div>
      </form>

      {error && (
        <p className="mt-4 rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300">
          {error}
        </p>
      )}

      {result?.warnings.map((w) => (
        <p
          key={w}
          className="border-warm/30 bg-warm/10 text-warm mt-4 rounded-lg border px-4 py-3 text-sm"
        >
          {w}
        </p>
      ))}

      {result && (
        <>
          <div className="mt-6 flex flex-wrap items-end justify-between gap-4">
            <div className="flex flex-wrap gap-6">
              <Stat label="encontrados" value={result.stats.total} />
              {/* Excludes register rows, which have no website field at all —
                  see `withoutWebsite` in search.ts. Saying "no mapa" keeps that
                  from reading as a count over everything on screen. */}
              <Stat
                label={
                  (result.stats.fromCnpj ?? 0) > 0
                    ? "sem site (no mapa)"
                    : "sem site"
                }
                value={result.stats.withoutWebsite}
              />
              <Stat label="com telefone" value={result.stats.withPhone} />
              <Stat label="com WhatsApp" value={result.stats.withWhatsapp} />
              {(result.stats.fromOpenStreetMap ?? 0) > 0 && (
                <Stat
                  label="novos no OSM"
                  value={result.stats.fromOpenStreetMap ?? 0}
                />
              )}
              {(result.stats.fromGeoapify ?? 0) > 0 && (
                <Stat
                  label="novos no Geoapify"
                  value={result.stats.fromGeoapify ?? 0}
                />
              )}
              {/* Usually the larger half of a partner search rather than a
                  supplement, so it is worth its own figure: it is the answer to
                  "how many of these did the map never know about". */}
              {(result.stats.fromCnpj ?? 0) > 0 && (
                <Stat
                  label="no registro (CNPJ)"
                  value={result.stats.fromCnpj ?? 0}
                />
              )}
              <Stat label="na tela" value={result.stats.returned} />
              {result.persisted && (
                <Stat label="novos" value={result.persisted.inserted} />
              )}
              {!result.saved && <Stat label="histórico" value="desligado" />}
              <Stat
                label="tempo"
                value={`${(result.stats.elapsedMs / 1000).toFixed(2)}s`}
              />
            </div>

            <div className="flex items-center gap-3">
              <input
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                placeholder="Filtrar nome, endereço…"
                className="border-line bg-surface-2 focus:border-brand h-[34px] w-56 rounded-md border px-3 text-sm outline-none"
              />
              {canExport && (
                <button
                  onClick={() => void exportCsv()}
                  disabled={visible.length === 0}
                  className="border-line bg-surface-2 hover:border-brand inline-flex h-[34px] items-center gap-2 rounded-md border px-3 text-sm disabled:opacity-40"
                >
                  <Download className="size-4" />
                  CSV ({visible.length})
                </button>
              )}
            </div>
          </div>

          <LeadTable
            leads={visible}
            onDelete={(lead) => void deleteLead(lead)}
            deleting={deleting}
            outreach={outreach}
          />
        </>
      )}

      {!result && !loading && (
        <p className="text-fg-muted mt-10 text-center text-sm">
          Escolha um nicho e uma área para começar.
        </p>
      )}
    </>
  );
}

/** `label` omitted renders an invisible spacer, to keep the submit button aligned. */
function Field({
  label,
  children,
}: {
  label?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span
        aria-hidden={label ? undefined : true}
        className="text-fg-muted mb-1.5 block text-xs font-medium tracking-wide uppercase"
      >
        {label ?? " "}
      </span>
      {children}
    </label>
  );
}

/**
 * Groups the niche list for `<optgroup>`. Mirrors nichesByGroup() in the registry,
 * but works off the prop — this is a client component and receives the niches as
 * plain serialised data rather than importing the module.
 */
function groupNiches(niches: Niche[]): { group: string; niches: Niche[] }[] {
  const groups: { group: string; niches: Niche[] }[] = [];
  for (const niche of niches) {
    const last = groups[groups.length - 1];
    if (last && last.group === niche.group) last.niches.push(niche);
    else groups.push({ group: niche.group, niches: [niche] });
  }
  return groups;
}

/**
 * Groups the country list for `<optgroup>`, preserving the order the server
 * sent — which is the registry's own WORLD_REGIONS order, so the picker reads
 * as a map rather than as whatever order the extract was built in.
 */
function groupCountries(
  countries: CountryOption[],
): { region: string; countries: CountryOption[] }[] {
  const groups: { region: string; countries: CountryOption[] }[] = [];
  for (const country of countries) {
    const last = groups[groups.length - 1];
    if (last && last.region === country.region) last.countries.push(country);
    else groups.push({ region: country.region, countries: [country] });
  }
  return groups;
}

/** "Belo Horizonte — MG", or just the name where there is no state code. */
function cityLabel(name: string, uf: string): string {
  return uf ? `${name} — ${uf}` : name;
}

function scopeLabel(
  scope: SearchScope,
  city: CityOption | null,
  uf: string,
  region: string,
  country: string,
): string {
  if (scope === "city")
    return cityLabel(city?.name ?? "cidade", city?.uf ?? "");
  if (scope === "state") return uf;
  if (scope === "region") {
    return BRAZIL_REGIONS.find((item) => item.slug === region)?.label ?? region;
  }
  return country === "BR" ? "Brasil" : country;
}

function CityInput({
  query,
  onQueryChange,
  options,
  show,
  onPick,
  onBlur,
  selected,
}: {
  query: string;
  onQueryChange: (v: string) => void;
  options: CityOption[];
  show: boolean;
  onPick: (c: CityOption) => void;
  onBlur: () => void;
  selected: CityOption | null;
}) {
  return (
    <div className="relative">
      <input
        value={query}
        onChange={(e) => onQueryChange(e.target.value)}
        // A click on an option must register before the list unmounts, so the
        // blur has to lose the race deliberately.
        onBlur={() => setTimeout(onBlur, 120)}
        placeholder="Belo Horizonte"
        autoComplete="off"
        className={cn(
          "bg-surface-2 w-full rounded-md border px-3 py-2 text-sm outline-none",
          selected
            ? "border-line focus:border-brand"
            : "border-warm/40 focus:border-brand",
        )}
      />
      {show && options.length > 0 && (
        <ul className="border-line bg-surface absolute z-20 mt-1 max-h-64 w-full overflow-auto rounded-md border shadow-xl">
          {options.map((c) => (
            <li key={`${c.country}-${c.name}-${c.uf}`}>
              <button
                type="button"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => onPick(c)}
                className="hover:bg-surface-2 flex w-full items-baseline justify-between gap-3 px-3 py-2 text-left text-sm"
              >
                <span className="truncate">
                  {c.name}
                  {c.uf && (
                    <span className="text-fg-muted ml-1.5 text-xs">{c.uf}</span>
                  )}
                </span>
                {/* The size of the pool, so you can tell a capital from a hamlet
                    of the same name before committing to a search. */}
                {c.noSite !== undefined && (
                  <span className="text-fg-muted tnum shrink-0 text-xs">
                    {c.noSite.toLocaleString("pt-BR")} sem site
                  </span>
                )}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number | string }) {
  return (
    <div>
      <div className="tnum text-xl font-semibold">
        {typeof value === "number" ? value.toLocaleString("pt-BR") : value}
      </div>
      <div className="text-fg-muted text-xs tracking-wide uppercase">
        {label}
      </div>
    </div>
  );
}

function LeadTable({
  leads,
  onDelete,
  deleting,
  outreach,
}: {
  leads: ScoredLead[];
  /** Removes the lead from the local history — see deleteLead() above. */
  onDelete: (lead: ScoredLead) => void;
  /** Id currently being deleted, so its button can't be clicked twice. */
  deleting: string | null;
  /** The opener in force, threaded down to the WhatsApp and mailto links. */
  outreach: OutreachContext;
}) {
  if (leads.length === 0) {
    return (
      <p className="border-line bg-surface text-fg-muted mt-8 rounded-lg border px-4 py-8 text-center text-sm">
        Nenhum negócio encontrado com esses filtros.
      </p>
    );
  }

  return (
    <div className="border-line mt-4 overflow-x-auto rounded-xl border">
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="bg-surface-2 text-fg-muted text-left text-xs tracking-wide uppercase">
            <th className="w-16 px-3 py-2.5 font-medium">Score</th>
            <th className="px-3 py-2.5 font-medium">Negócio</th>
            <th className="px-3 py-2.5 font-medium">Endereço</th>
            <th className="px-3 py-2.5 font-medium">Sinais</th>
            <th className="w-44 px-3 py-2.5 font-medium">Contato</th>
            <th className="w-10 px-3 py-2.5 font-medium"></th>
          </tr>
        </thead>
        <tbody>
          {leads.map((l) => (
            <tr key={l.id} className="border-line hover:bg-surface/60 border-t">
              <td className="px-3 py-2.5 align-top">
                <ScoreBadge score={l.score} />
              </td>
              <td className="px-3 py-2.5 align-top">
                <div className="flex items-baseline gap-1.5">
                  <span className="font-medium">{l.name}</span>
                  {/* Only ever marks the first time a business is seen, so on a
                      repeat search this is exactly the list that appeared since. */}
                  {l.isNew && (
                    <span className="border-brand/40 text-brand shrink-0 rounded border px-1 py-px text-[10px] leading-none uppercase">
                      novo
                    </span>
                  )}
                </div>
                <div className="text-fg-muted text-xs">
                  {l.category}
                  {l.source === "openstreetmap" ? " · OpenStreetMap" : ""}
                  {l.source === "geoapify" ? " · Geoapify" : ""}
                </div>
              </td>
              <td className="text-fg-muted px-3 py-2.5 align-top">
                <div>{l.address ?? "—"}</div>
                <div className="text-xs">
                  {l.city}
                  {l.uf ? `, ${l.uf}` : ""}
                  {l.country ? ` · ${l.country}` : ""}
                </div>
              </td>
              <td className="px-3 py-2.5 align-top">
                <div className="flex flex-wrap gap-1">
                  {l.reasons.map((r) => (
                    <span
                      key={r}
                      className="border-line bg-surface-2 text-fg-muted rounded border px-1.5 py-0.5 text-xs"
                    >
                      {r}
                    </span>
                  ))}
                </div>
              </td>
              <td className="px-3 py-2.5 align-top">
                <Contact lead={l} outreach={outreach} />
              </td>
              <td className="px-3 py-2.5 align-top">
                <DeleteButton
                  lead={l}
                  onDelete={onDelete}
                  pending={deleting === l.id}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/**
 * Drops one business from the local history.
 *
 * Confirmed in the browser rather than with an in-page dialog: this is a
 * single-row, immediately-visible action, and a modal for it would be more
 * ceremony than the act deserves. The bulk equivalent, which can empty the
 * pipeline, lives on the history page and asks properly.
 */
function DeleteButton({
  lead,
  onDelete,
  pending,
}: {
  lead: ScoredLead;
  onDelete: (lead: ScoredLead) => void;
  pending: boolean;
}) {
  return (
    <button
      type="button"
      disabled={pending}
      title="Remover do banco de dados"
      aria-label={`Remover ${lead.name} do banco de dados`}
      onClick={() => {
        if (window.confirm(`Remover ${lead.name} do banco de dados?`)) {
          onDelete(lead);
        }
      }}
      className="text-fg-muted rounded-md p-1.5 transition hover:bg-red-500/10 hover:text-red-400 disabled:opacity-40"
    >
      {pending ? (
        <Loader2 className="size-4 animate-spin" />
      ) : (
        <Trash2 className="size-4" />
      )}
    </button>
  );
}

function ScoreBadge({ score }: { score: number }) {
  const tone =
    score >= 80
      ? "border-hot/40 bg-hot/15 text-hot"
      : score >= 60
        ? "border-warm/40 bg-warm/15 text-warm"
        : "border-line bg-surface-2 text-cool";
  return (
    <span
      className={cn(
        "tnum inline-block rounded-md border px-2 py-1 text-sm font-semibold",
        tone,
      )}
    >
      {score}
    </span>
  );
}

function Contact({
  lead,
  outreach,
}: {
  lead: ScoredLead;
  outreach: OutreachContext;
}) {
  const wa = whatsappUrl(
    lead.phone,
    outreachMessage(lead, undefined, outreach),
    lead.country,
  );

  // The tab navigation to wa.me can cancel ordinary fetches, hence keepalive.
  // The server update is idempotent, so a second click doesn't reset its due date.
  const recordOutreach = (channel: string) => {
    void fetch("/api/prospector/history/outreach", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id: lead.id, channel }),
      keepalive: true,
    });
  };

  return (
    <div className="flex flex-col items-start gap-1.5">
      {/* Above the buttons, not beside them: it has to be read before the click,
          and this column is a vertical stack scanned top-down. */}
      <ContactedMark lead={lead} />
      {wa ? (
        <>
          <a
            href={wa}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => recordOutreach("whatsapp")}
            className="inline-flex items-center gap-1.5 rounded-md bg-emerald-600/90 px-2 py-1 text-xs font-medium text-white hover:bg-emerald-600"
          >
            <MessageCircle className="size-3.5" />
            WhatsApp
          </a>
          {lead.phone && (
            <a
              href={`tel:${lead.phone}`}
              onClick={() => recordOutreach("phone")}
              className="text-fg-muted hover:text-fg inline-flex items-center gap-1.5 text-xs"
            >
              <Phone className="size-3.5" />
              {lead.phone}
            </a>
          )}
        </>
      ) : lead.phone ? (
        <a
          href={`tel:${lead.phone}`}
          onClick={() => recordOutreach("phone")}
          className="text-fg-muted hover:text-fg inline-flex items-center gap-1.5 text-xs"
        >
          <Phone className="size-3.5" />
          {lead.phone}
        </a>
      ) : (
        <span className="text-fg-muted text-xs">sem telefone</span>
      )}

      {(lead.socialLinks?.length
        ? lead.socialLinks
        : lead.social
          ? [{ platform: "rede social", url: lead.social }]
          : []
      ).map((social) => (
        <a
          key={social.url}
          href={social.url}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() =>
            recordOutreach(
              social.platform.toLowerCase() === "telegram"
                ? "telegram"
                : [
                      "instagram",
                      "facebook",
                      "linkedin",
                      "tiktok",
                      "x",
                      "threads",
                      "bluesky",
                      "pinterest",
                      "snapchat",
                      "discord",
                      "messenger",
                    ].includes(social.platform.toLowerCase())
                  ? social.platform.toLowerCase()
                  : "social",
            )
          }
          className="text-fg-muted hover:text-fg inline-flex items-center gap-1.5 text-xs"
        >
          {social.platform.toLowerCase() === "telegram" ? (
            <Send className="size-3.5" />
          ) : (
            <Share2 className="size-3.5" />
          )}
          {social.platform}
        </a>
      ))}

      {lead.email && (
        <a
          href={`mailto:${lead.email}?subject=${encodeURIComponent(`Ideia para ${lead.name}`)}&body=${encodeURIComponent(outreachMessage(lead, undefined, outreach))}`}
          onClick={() => recordOutreach("email")}
          className="text-fg-muted hover:text-fg inline-flex items-center gap-1.5 text-xs"
        >
          <Mail className="size-3.5" />
          {lead.email}
        </a>
      )}

      {lead.website && (
        <a
          href={lead.website}
          target="_blank"
          rel="noopener noreferrer"
          className="text-fg-muted hover:text-fg inline-flex items-center gap-1.5 text-xs"
        >
          <Globe className="size-3.5" />
          site
        </a>
      )}
    </div>
  );
}
