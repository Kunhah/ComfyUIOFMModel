"use client";

import { MessageCircle, Phone } from "lucide-react";
import { ContactedMark } from "@/components/prospector/contacted-mark";
import type { FunnelStage } from "@/lib/prospector/types";

/** Contact choices used by saved search results, with one audit path for both. */
export function ContactActions({
  id,
  phone,
  whatsappUrl,
  contactedAt,
  attempts,
  owner,
  funnelStage,
}: {
  id: string;
  phone: string | null;
  whatsappUrl: string | null;
  /** The history behind the buttons — see `ContactedMark`. */
  contactedAt?: string | null;
  attempts?: number;
  owner?: { name: string } | null;
  funnelStage?: FunnelStage | null;
}) {
  const record = (channel: "whatsapp" | "phone") => {
    void fetch("/api/prospector/history/outreach", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id, channel }),
      keepalive: true,
    });
  };

  if (!phone && !whatsappUrl) {
    return <span className="text-fg-muted text-xs">sem telefone</span>;
  }

  return (
    <>
      <ContactedMark lead={{ contactedAt, attempts, owner, funnelStage }} />
      {whatsappUrl && (
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => record("whatsapp")}
          className="inline-flex items-center gap-1.5 rounded-md bg-[#25D366] px-2.5 py-1.5 text-xs font-medium text-black"
        >
          <MessageCircle className="size-3.5" />
          WhatsApp
        </a>
      )}
      {phone && (
        <a
          href={`tel:${phone}`}
          onClick={() => record("phone")}
          className="text-fg-muted hover:text-fg inline-flex items-center gap-1.5 text-xs"
        >
          <Phone className="size-3.5" />
          {phone}
        </a>
      )}
    </>
  );
}
