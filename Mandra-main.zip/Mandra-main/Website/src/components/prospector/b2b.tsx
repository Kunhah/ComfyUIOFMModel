"use client";

import { useCallback, useMemo, useRef, useState } from "react";
import {
  Building2,
  Copy,
  Download,
  Globe,
  Loader2,
  Mail,
  Phone,
  Search,
  Square,
} from "lucide-react";
import { BrandIcon, brandPaths } from "@/components/ui/brand-icon";
import { countryLabel, type Country } from "@/lib/b2b/countries";
import { outreachSubject } from "@/lib/b2b/score";
import type { DiscoveryTarget } from "@/lib/b2b/sectors";
import type {
  Candidate,
  DiscoverResponse,
  EnrichEvent,
  Prospect,
} from "@/lib/b2b/types";
import { cn } from "@/lib/utils";

/**
 * The B2B board.
 *
 * Two steps, deliberately separate. Discovery is cheap and reversible, so you
 * run it, look at how many companies came back and from where, and adjust.
 * Crawling is the expensive half — hundreds of outbound requests over several
 * minutes — so it never starts on its own. Fusing them into one button was the
 * first version and it was wrong: every mistyped filter cost a five-minute crawl.
 */

type Mode = "overture" | "lista";

const PRESETS: { label: string; codes: string[] }[] = [
  { label: "DACH", codes: ["DE", "AT", "CH"] },
  { label: "Benelux", codes: ["NL", "BE", "LU"] },
  { label: "Sul da Europa", codes: ["IT", "ES", "PT", "FR"] },
  { label: "Nórdicos", codes: ["SE", "DK", "NO", "FI"] },
];

export function B2b({
  targets,
  countries,
  europe,
  storedContactable,
  canExport,
  uncovered = [],
  coverageUnknown = false,
}: {
  targets: DiscoveryTarget[];
  /** Only what the picker renders — the bounding boxes are a server concern. */
  countries: Pick<Country, "code" | "label">[];
  /** Default selection — the industrial core of Europe. */
  europe: string[];
  storedContactable: number;
  /** Whether this account holds the "export" permission. The route re-checks. */
  canExport: boolean;
  /**
   * Slugs the local extract holds no category for. They are still selectable —
   * the search runs, it just cannot return anything — so the picker says so
   * rather than letting an empty board read as an empty market.
   */
  uncovered?: string[];
  /** The extract predates the manifest's category list, so coverage is unknown. */
  coverageUnknown?: boolean;
}) {
  const [mode, setMode] = useState<Mode>("overture");
  const [sector, setSector] = useState(targets[0]?.slug ?? "");
  const outOfExtract = useMemo(() => new Set(uncovered), [uncovered]);
  const [selected, setSelected] = useState<string[]>(["DE", "AT", "CH"]);
  const [city, setCity] = useState("");
  const [limit, setLimit] = useState(200);
  const [seeds, setSeeds] = useState("");

  const [concurrency, setConcurrency] = useState(8);
  const [maxPages, setMaxPages] = useState(8);
  const [skipKnown, setSkipKnown] = useState(true);
  const [respectRobots, setRespectRobots] = useState(true);

  const [candidates, setCandidates] = useState<Candidate[] | null>(null);
  const [discovery, setDiscovery] = useState<DiscoverResponse["stats"] | null>(
    null,
  );
  const [prospects, setProspects] = useState<Prospect[]>([]);
  const [progress, setProgress] = useState<{
    done: number;
    total: number;
  } | null>(null);
  const [summary, setSummary] = useState<Extract<
    EnrichEvent,
    { type: "done" }
  > | null>(null);

  const [discovering, setDiscovering] = useState(false);
  const [crawling, setCrawling] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [warnings, setWarnings] = useState<string[]>([]);
  const [filter, setFilter] = useState("");
  const [onlyWithEmail, setOnlyWithEmail] = useState(true);

  // Kept in a ref rather than state: aborting must not wait for a render, and
  // nothing about it is displayed.
  const abort = useRef<AbortController | null>(null);

  const toggleCountry = (code: string) =>
    setSelected((current) =>
      current.includes(code)
        ? current.filter((c) => c !== code)
        : [...current, code],
    );

  const discover = useCallback(async () => {
    setDiscovering(true);
    setError(null);
    setWarnings([]);
    try {
      const response = await fetch("/api/prospector/b2b/discover", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(
          mode === "lista"
            ? { seeds }
            : { sector, countries: selected, city, limit },
        ),
      });
      const data = await response.json();
      if (!response.ok)
        throw new Error(data.error ?? `Erro ${response.status}`);
      const result = data as DiscoverResponse;
      setCandidates(result.candidates);
      setDiscovery(result.stats);
      setWarnings(result.warnings);
      // A new discovery invalidates the board: those rows belong to the previous
      // list and mixing them would misreport what the run found.
      setProspects([]);
      setSummary(null);
      setProgress(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      setCandidates(null);
      setDiscovery(null);
    } finally {
      setDiscovering(false);
    }
  }, [mode, seeds, sector, selected, city, limit]);

  const crawl = useCallback(async () => {
    if (!candidates || candidates.length === 0) return;
    const controller = new AbortController();
    abort.current = controller;

    setCrawling(true);
    setError(null);
    setProspects([]);
    setSummary(null);
    setProgress({ done: 0, total: candidates.length });

    try {
      const response = await fetch("/api/prospector/b2b/enrich", {
        method: "POST",
        headers: { "content-type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({
          candidates,
          concurrency,
          maxPages,
          skipKnown,
          respectRobots,
        }),
      });
      if (!response.ok || !response.body) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.error ?? `Erro ${response.status}`);
      }

      // NDJSON: one event per line, so a company lands on the board the moment
      // its crawl finishes rather than when the whole run does.
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let newline: number;
        while ((newline = buffer.indexOf("\n")) >= 0) {
          const line = buffer.slice(0, newline).trim();
          buffer = buffer.slice(newline + 1);
          if (!line) continue;
          let event: EnrichEvent;
          try {
            event = JSON.parse(line) as EnrichEvent;
          } catch {
            continue;
          }
          handleEvent(event, {
            setProspects,
            setProgress,
            setSummary,
            setWarnings,
            setError,
          });
        }
      }
    } catch (err) {
      if (!controller.signal.aborted) {
        setError(err instanceof Error ? err.message : String(err));
      }
    } finally {
      setCrawling(false);
      abort.current = null;
    }
  }, [candidates, concurrency, maxPages, skipKnown, respectRobots]);

  const stop = useCallback(() => abort.current?.abort(), []);

  const selectedTarget = useMemo(
    () => targets.find((t) => t.slug === sector) ?? null,
    [targets, sector],
  );

  const visible = useMemo(() => {
    const query = filter.trim().toLowerCase();
    return prospects
      .filter((p) => !onlyWithEmail || p.emails.length > 0)
      .filter(
        (p) =>
          !query ||
          p.name.toLowerCase().includes(query) ||
          p.domain.includes(query) ||
          p.emails.some((e) => e.address.includes(query)),
      )
      .sort((a, b) => b.score - a.score || b.emails.length - a.emails.length);
  }, [prospects, filter, onlyWithEmail]);

  const exportCsv = useCallback(
    async (scope: "board" | "historico") => {
      const response = await fetch("/api/prospector/b2b/export", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(
          scope === "board"
            ? { scope, prospects: visible, filename: `b2b-${sector}` }
            : { scope, filename: "b2b-historico" },
        ),
      });
      if (!response.ok) return;
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download =
        scope === "board" ? "b2b-leads.csv" : "b2b-historico.csv";
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(url);
    },
    [visible, sector],
  );

  const withEmail = prospects.filter((p) => p.emails.length > 0).length;

  return (
    <>
      {uncovered.length > 0 && (
        <p className="border-warm/30 bg-warm/10 text-warm mb-4 rounded-lg border px-4 py-3 text-sm">
          <strong className="font-semibold">
            {uncovered.length} perfis fora do extrato local.
          </strong>{" "}
          Foram adicionados ao registro depois que{" "}
          <code className="bg-surface-2 rounded px-1 py-0.5 text-xs">
            b2b-companies.parquet
          </code>{" "}
          foi gerado, então a busca por eles volta vazia — o que parece um
          mercado vazio e não é. Rode{" "}
          <code className="bg-surface-2 rounded px-1 py-0.5 text-xs">
            npm run sync:b2b
          </code>{" "}
          de novo para incluí-los.
        </p>
      )}
      {coverageUnknown && (
        <p className="border-line bg-surface-2 text-fg-muted mb-4 rounded-lg border px-4 py-3 text-sm">
          O extrato local foi gerado por uma versão que não registrava a lista
          de categorias, então não dá para dizer quais perfis ele cobre. Um{" "}
          <code className="bg-surface rounded px-1 py-0.5 text-xs">
            npm run sync:b2b
          </code>{" "}
          resolve — e passa a marcar os que faltam.
        </p>
      )}
      <form
        className="border-line bg-surface rounded-xl border p-4"
        onSubmit={(event) => {
          event.preventDefault();
          void discover();
        }}
      >
        <div className="mb-4 flex gap-1">
          <Tab active={mode === "overture"} onClick={() => setMode("overture")}>
            Buscar por setor
          </Tab>
          <Tab active={mode === "lista"} onClick={() => setMode("lista")}>
            Colar lista
          </Tab>
        </div>

        {mode === "overture" ? (
          <>
            <div className="grid gap-4 md:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)_auto_auto]">
              <Field label="Perfil de busca">
                <select
                  value={sector}
                  onChange={(e) => setSector(e.target.value)}
                  className="border-line bg-surface-2 focus:border-brand w-full rounded-md border px-3 py-2 text-sm outline-none"
                >
                  {groupTargets(targets).map((group) => (
                    <optgroup key={group.group} label={group.group}>
                      {group.sectors.map((s) => (
                        <option key={s.slug} value={s.slug}>
                          {ticketMark(s.ticket)} {s.label}
                          {outOfExtract.has(s.slug) ? " — fora do extrato" : ""}
                        </option>
                      ))}
                    </optgroup>
                  ))}
                </select>
                {/* The registry is 85 profiles deep and most of them are
                    industries the person searching has never sold to. The note
                    is what there is to sell, so the choice is a pitch rather
                    than a noun; the ticket is why one outranks another. */}
                <SectorHint
                  target={selectedTarget}
                  uncovered={
                    selectedTarget
                      ? outOfExtract.has(selectedTarget.slug)
                      : false
                  }
                />
              </Field>

              <Field label="Cidade (opcional)">
                <input
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="Stuttgart"
                  className="border-line bg-surface-2 focus:border-brand w-full rounded-md border px-3 py-2 text-sm outline-none"
                />
              </Field>

              <Field label="Máx. empresas">
                <input
                  type="number"
                  min={1}
                  max={2000}
                  value={limit}
                  onChange={(e) => setLimit(Number(e.target.value))}
                  className="border-line bg-surface-2 focus:border-brand tnum w-28 rounded-md border px-3 py-2 text-sm outline-none"
                />
              </Field>

              <Field>
                <SubmitButton loading={discovering} />
              </Field>
            </div>

            <div className="border-line mt-4 border-t pt-4">
              <div className="mb-2 flex flex-wrap items-center gap-2">
                <span className="text-fg-muted text-xs font-medium tracking-wide uppercase">
                  Países ({selected.length})
                </span>
                {PRESETS.map((preset) => (
                  <Chip
                    key={preset.label}
                    onClick={() => setSelected(preset.codes)}
                  >
                    {preset.label}
                  </Chip>
                ))}
                <Chip onClick={() => setSelected(europe)}>Europa</Chip>
                <Chip onClick={() => setSelected([])}>Limpar</Chip>
              </div>
              <div className="grid max-h-40 grid-cols-2 gap-x-4 gap-y-1 overflow-auto sm:grid-cols-4 lg:grid-cols-6">
                {countries.map((country) => (
                  <label
                    key={country.code}
                    className="flex cursor-pointer items-center gap-2 text-sm"
                  >
                    <input
                      type="checkbox"
                      checked={selected.includes(country.code)}
                      onChange={() => toggleCountry(country.code)}
                      className="accent-brand size-3.5"
                    />
                    <span className="truncate">{country.label}</span>
                  </label>
                ))}
              </div>
            </div>
          </>
        ) : (
          <div className="grid gap-4 md:grid-cols-[minmax(0,1fr)_auto]">
            <Field label="Um domínio por linha (nome opcional antes da vírgula)">
              <textarea
                value={seeds}
                onChange={(e) => setSeeds(e.target.value)}
                rows={6}
                placeholder={
                  "Müller Präzisionstechnik GmbH, mueller-praezision.de\nhttps://www.kern-microtechnik.com\nbrunner-maschinenbau.at"
                }
                className="border-line bg-surface-2 focus:border-brand w-full rounded-md border px-3 py-2 font-mono text-xs outline-none"
              />
            </Field>
            <Field>
              <SubmitButton loading={discovering} />
            </Field>
          </div>
        )}

        <div className="border-line mt-4 flex flex-wrap items-center gap-x-6 gap-y-3 border-t pt-4 text-sm">
          <label className="inline-flex items-center gap-2">
            <span className="text-fg-muted">
              Sites em paralelo{" "}
              <span className="tnum text-fg">{concurrency}</span>
            </span>
            <input
              type="range"
              min={1}
              max={16}
              value={concurrency}
              onChange={(e) => setConcurrency(Number(e.target.value))}
              className="accent-brand w-28"
            />
          </label>
          <label className="inline-flex items-center gap-2">
            <span className="text-fg-muted">
              Páginas por site <span className="tnum text-fg">{maxPages}</span>
            </span>
            <input
              type="range"
              min={1}
              max={20}
              value={maxPages}
              onChange={(e) => setMaxPages(Number(e.target.value))}
              className="accent-brand w-28"
            />
          </label>
          <label className="inline-flex cursor-pointer items-center gap-2">
            <input
              type="checkbox"
              checked={skipKnown}
              onChange={(e) => setSkipKnown(e.target.checked)}
              className="accent-brand size-4"
            />
            <span>Pular quem já está no histórico</span>
          </label>
          <label className="inline-flex cursor-pointer items-center gap-2">
            <input
              type="checkbox"
              checked={respectRobots}
              onChange={(e) => setRespectRobots(e.target.checked)}
              className="accent-brand size-4"
            />
            <span>Respeitar robots.txt</span>
          </label>
        </div>
      </form>

      {error && (
        <p className="mt-4 rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300">
          {error}
        </p>
      )}

      {warnings.map((warning) => (
        <p
          key={warning}
          className="border-warm/30 bg-warm/10 text-warm mt-4 rounded-lg border px-4 py-3 text-sm"
        >
          {warning}
        </p>
      ))}

      {candidates && (
        <div className="border-line bg-surface mt-6 flex flex-wrap items-center justify-between gap-4 rounded-xl border p-4">
          <div className="flex flex-wrap gap-6">
            <Stat label="empresas encontradas" value={candidates.length} />
            {discovery && discovery.matched > 0 && (
              <Stat label="registros no overture" value={discovery.matched} />
            )}
            {discovery && (
              <Stat
                label="busca"
                value={`${(discovery.elapsedMs / 1000).toFixed(1)}s`}
              />
            )}
          </div>
          <div className="flex items-center gap-3">
            {crawling ? (
              <button
                type="button"
                onClick={stop}
                className="border-line bg-surface-2 hover:border-warm inline-flex h-[38px] items-center gap-2 rounded-md border px-4 text-sm"
              >
                <Square className="size-3.5" />
                Parar
              </button>
            ) : null}
            <button
              type="button"
              onClick={() => void crawl()}
              disabled={crawling || candidates.length === 0}
              className={cn(
                "inline-flex h-[38px] items-center gap-2 rounded-md px-4 text-sm font-medium transition",
                "bg-brand text-brand-fg hover:brightness-110",
                "disabled:cursor-not-allowed disabled:opacity-40",
              )}
            >
              {crawling ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Mail className="size-4" />
              )}
              {crawling ? "Rastreando…" : `Rastrear ${candidates.length} sites`}
            </button>
          </div>
        </div>
      )}

      {progress && (
        <div className="mt-4">
          <div className="text-fg-muted mb-1.5 flex justify-between text-xs">
            <span>
              {progress.done} de {progress.total} sites · {withEmail} com e-mail
            </span>
            {summary && (
              <span>
                concluído em {(summary.elapsedMs / 1000).toFixed(0)}s ·{" "}
                {summary.unreachable} inacessíveis
                {summary.persisted
                  ? ` · ${summary.persisted.inserted} novos`
                  : ""}
              </span>
            )}
          </div>
          <div className="bg-surface-2 h-1.5 overflow-hidden rounded-full">
            <div
              className="bg-brand h-full transition-[width] duration-300"
              style={{
                width: `${progress.total === 0 ? 0 : (progress.done / progress.total) * 100}%`,
              }}
            />
          </div>
        </div>
      )}

      {prospects.length > 0 && (
        <>
          <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
            <label className="inline-flex cursor-pointer items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={onlyWithEmail}
                onChange={(e) => setOnlyWithEmail(e.target.checked)}
                className="accent-brand size-4"
              />
              <span>Só com e-mail</span>
            </label>
            <div className="flex items-center gap-3">
              <input
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                placeholder="Filtrar empresa, domínio, e-mail…"
                className="border-line bg-surface-2 focus:border-brand h-[34px] w-64 rounded-md border px-3 text-sm outline-none"
              />
              {canExport && (
                <button
                  type="button"
                  onClick={() => void exportCsv("board")}
                  disabled={visible.length === 0}
                  className="border-line bg-surface-2 hover:border-brand inline-flex h-[34px] items-center gap-2 rounded-md border px-3 text-sm disabled:opacity-40"
                >
                  <Download className="size-4" />
                  CSV ({visible.length})
                </button>
              )}
              {canExport && storedContactable > 0 && (
                <button
                  type="button"
                  onClick={() => void exportCsv("historico")}
                  className="border-line bg-surface-2 hover:border-brand inline-flex h-[34px] items-center gap-2 rounded-md border px-3 text-sm"
                >
                  <Download className="size-4" />
                  Histórico ({storedContactable})
                </button>
              )}
            </div>
          </div>

          <ProspectTable prospects={visible} />
        </>
      )}

      {!candidates && !discovering && (
        <p className="text-fg-muted mt-10 text-center text-sm">
          Escolha um setor e os países — ou cole uma lista de domínios — para
          começar.
        </p>
      )}
    </>
  );
}

function handleEvent(
  event: EnrichEvent,
  set: {
    setProspects: React.Dispatch<React.SetStateAction<Prospect[]>>;
    setProgress: (p: { done: number; total: number }) => void;
    setSummary: (s: Extract<EnrichEvent, { type: "done" }>) => void;
    setWarnings: React.Dispatch<React.SetStateAction<string[]>>;
    setError: (e: string) => void;
  },
): void {
  switch (event.type) {
    case "start":
      set.setProgress({ done: 0, total: event.total });
      break;
    case "prospect":
      set.setProspects((current) => [...current, event.prospect]);
      set.setProgress({ done: event.done, total: event.total });
      break;
    case "done":
      set.setSummary(event);
      set.setProgress({ done: event.total, total: event.total });
      if (event.warnings.length > 0) {
        set.setWarnings((current) => [
          ...new Set([...current, ...event.warnings]),
        ]);
      }
      break;
    case "error":
      set.setError(event.error);
      break;
  }
}

/**
 * The ticket band as five glyphs.
 *
 * A `<select>` cannot be styled per option, and the picker is the one place the
 * value prior has to be visible — the whole point of the expansion is that the
 * list now mixes a hospital group and a print shop. Filled circles read at a
 * glance and survive the OS rendering its own dropdown.
 */
function ticketMark(ticket: 1 | 2 | 3 | 4 | 5): string {
  return "●".repeat(ticket) + "○".repeat(5 - ticket);
}

function SectorHint({
  target,
  uncovered,
}: {
  target: DiscoveryTarget | null;
  uncovered: boolean;
}) {
  if (!target) return null;
  return (
    <p className="text-fg-muted mt-1.5 text-xs">
      <span className="text-fg-subtle tnum">{ticketMark(target.ticket)}</span>{" "}
      ticket {target.ticket}/5
      {target.note ? <> · {target.note}</> : null}
      {uncovered && (
        <>
          {" · "}
          <span className="text-warm">
            fora do extrato local — rode npm run sync:b2b
          </span>
        </>
      )}
    </p>
  );
}

function groupTargets(
  targets: DiscoveryTarget[],
): { group: string; sectors: DiscoveryTarget[] }[] {
  const groups: { group: string; sectors: DiscoveryTarget[] }[] = [];
  for (const sector of targets) {
    const last = groups[groups.length - 1];
    if (last && last.group === sector.group) last.sectors.push(sector);
    else groups.push({ group: sector.group, sectors: [sector] });
  }
  return groups;
}

function Tab({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "rounded-md px-3 py-1.5 text-sm transition",
        active
          ? "bg-surface-2 text-fg border-line border"
          : "text-fg-muted hover:text-fg border border-transparent",
      )}
    >
      {children}
    </button>
  );
}

function Chip({
  onClick,
  children,
}: {
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="border-line bg-surface-2 text-fg-muted hover:border-brand hover:text-fg rounded border px-2 py-0.5 text-xs"
    >
      {children}
    </button>
  );
}

function SubmitButton({ loading }: { loading: boolean }) {
  return (
    <button
      type="submit"
      disabled={loading}
      className={cn(
        "inline-flex h-[38px] items-center gap-2 rounded-md px-4 text-sm font-medium transition",
        "bg-brand text-brand-fg hover:brightness-110",
        "disabled:cursor-not-allowed disabled:opacity-40",
      )}
    >
      {loading ? (
        <Loader2 className="size-4 animate-spin" />
      ) : (
        <Search className="size-4" />
      )}
      {loading ? "Buscando…" : "Descobrir"}
    </button>
  );
}

function Field({
  label,
  children,
}: {
  label?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span
        aria-hidden={label ? undefined : true}
        className="text-fg-muted mb-1.5 block text-xs font-medium tracking-wide uppercase"
      >
        {label ?? " "}
      </span>
      {children}
    </label>
  );
}

function Stat({ label, value }: { label: string; value: number | string }) {
  return (
    <div>
      <div className="tnum text-xl font-semibold">
        {typeof value === "number" ? value.toLocaleString("pt-BR") : value}
      </div>
      <div className="text-fg-muted text-xs tracking-wide uppercase">
        {label}
      </div>
    </div>
  );
}

function ProspectTable({ prospects }: { prospects: Prospect[] }) {
  if (prospects.length === 0) {
    return (
      <p className="border-line bg-surface text-fg-muted mt-4 rounded-lg border px-4 py-8 text-center text-sm">
        Nenhuma empresa com esses filtros.
      </p>
    );
  }

  return (
    <div className="border-line mt-4 overflow-x-auto rounded-xl border">
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="bg-surface-2 text-fg-muted text-left text-xs tracking-wide uppercase">
            <th className="w-16 px-3 py-2.5 font-medium">Score</th>
            <th className="px-3 py-2.5 font-medium">Empresa</th>
            <th className="px-3 py-2.5 font-medium">Contatos</th>
            <th className="px-3 py-2.5 font-medium">Sinais</th>
            <th className="w-40 px-3 py-2.5 font-medium">Links</th>
          </tr>
        </thead>
        <tbody>
          {prospects.map((prospect) => (
            <tr
              key={prospect.domain}
              className="border-line hover:bg-surface/60 border-t align-top"
            >
              <td className="px-3 py-2.5">
                <ScoreBadge score={prospect.score} />
              </td>
              <td className="px-3 py-2.5">
                <div className="flex items-baseline gap-1.5">
                  <span className="font-medium">{prospect.name}</span>
                  {prospect.isNew && (
                    <span className="border-brand/40 text-brand shrink-0 rounded border px-1 py-px text-[10px] leading-none uppercase">
                      novo
                    </span>
                  )}
                </div>
                <div className="text-fg-muted text-xs">
                  {prospect.domain}
                  {" · "}
                  {countryLabel(prospect.country)}
                  {prospect.city ? `, ${prospect.city}` : ""}
                </div>
                {(prospect.vat || prospect.employees) && (
                  <div className="text-fg-subtle mt-0.5 text-xs">
                    {[
                      prospect.vat,
                      prospect.employees && `${prospect.employees} func.`,
                    ]
                      .filter(Boolean)
                      .join(" · ")}
                  </div>
                )}
              </td>
              <td className="px-3 py-2.5">
                <Contacts prospect={prospect} />
              </td>
              <td className="px-3 py-2.5">
                <div className="flex flex-wrap gap-1">
                  {prospect.reasons.map((reason) => (
                    <span
                      key={reason}
                      className="border-line bg-surface-2 text-fg-muted rounded border px-1.5 py-0.5 text-xs"
                    >
                      {reason}
                    </span>
                  ))}
                  {prospect.technologies.slice(0, 3).map((tech) => (
                    <span
                      key={tech}
                      className="border-line text-fg-subtle rounded border px-1.5 py-0.5 text-xs"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </td>
              <td className="px-3 py-2.5">
                <div className="flex flex-col gap-1.5">
                  <a
                    href={prospect.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-fg-muted hover:text-fg inline-flex items-center gap-1.5 text-xs"
                  >
                    <Globe className="size-3.5" />
                    site
                  </a>
                  {prospect.socials.linkedin && (
                    <a
                      href={prospect.socials.linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-fg-muted hover:text-fg inline-flex items-center gap-1.5 text-xs"
                    >
                      <BrandIcon
                        path={brandPaths.linkedin}
                        className="size-3.5"
                      />
                      LinkedIn
                    </a>
                  )}
                  {prospect.phones[0] && (
                    <a
                      href={`tel:${prospect.phones[0]}`}
                      className="text-fg-muted hover:text-fg inline-flex items-center gap-1.5 text-xs"
                    >
                      <Phone className="size-3.5" />
                      {prospect.phones[0]}
                    </a>
                  )}
                  {prospect.pages > 0 && (
                    <span className="text-fg-subtle inline-flex items-center gap-1.5 text-xs">
                      <Building2 className="size-3.5" />
                      {prospect.pages} pág.
                    </span>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Contacts({ prospect }: { prospect: Prospect }) {
  if (prospect.emails.length === 0) {
    return (
      <span className="text-fg-subtle text-xs">
        {prospect.status === "inacessivel"
          ? `inacessível — ${prospect.error ?? "sem resposta"}`
          : prospect.status === "bloqueado"
            ? "robots.txt bloqueia"
            : "nenhum e-mail no site"}
      </span>
    );
  }

  const [best, ...rest] = prospect.emails;
  const subject = outreachSubject(prospect, prospect.languages[0] ?? "en");

  return (
    <div className="flex flex-col gap-1">
      <div className="flex items-center gap-1.5">
        <a
          href={`mailto:${best.address}?subject=${encodeURIComponent(subject)}`}
          className="text-brand text-sm hover:underline"
        >
          {best.address}
        </a>
        <CopyButton value={best.address} />
        <span className="border-line text-fg-subtle rounded border px-1 py-px text-[10px] uppercase">
          {best.category}
        </span>
      </div>
      {rest.length > 0 && (
        <details className="text-fg-muted text-xs">
          <summary className="cursor-pointer select-none">
            +{rest.length} e-mail{rest.length === 1 ? "" : "s"}
          </summary>
          <ul className="mt-1 space-y-0.5">
            {rest.map((email) => (
              <li key={email.address} className="flex items-center gap-1.5">
                <a href={`mailto:${email.address}`} className="hover:text-fg">
                  {email.address}
                </a>
                <span className="text-fg-subtle">
                  {email.category} · {email.source}
                </span>
              </li>
            ))}
          </ul>
        </details>
      )}
    </div>
  );
}

function CopyButton({ value }: { value: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      title="Copiar"
      onClick={() => {
        // `navigator.clipboard` is absent on insecure origins, so this is a
        // TypeError and not a rejected promise. The value is on screen and
        // selectable, so a failed copy just does nothing.
        void (async () => {
          try {
            await navigator.clipboard.writeText(value);
            setCopied(true);
            setTimeout(() => setCopied(false), 1200);
          } catch {}
        })();
      }}
      className={cn(
        "text-fg-subtle hover:text-fg transition",
        copied && "text-brand",
      )}
    >
      <Copy className="size-3" />
    </button>
  );
}

function ScoreBadge({ score }: { score: number }) {
  const tone =
    score >= 75
      ? "border-hot/40 bg-hot/15 text-hot"
      : score >= 55
        ? "border-warm/40 bg-warm/15 text-warm"
        : "border-line bg-surface-2 text-cool";
  return (
    <span
      className={cn(
        "tnum inline-block rounded-md border px-2 py-1 text-sm font-semibold",
        tone,
      )}
    >
      {score}
    </span>
  );
}
