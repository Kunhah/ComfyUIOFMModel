"use client";

import { useState, useTransition } from "react";

/** Date-only follow-up editor with optimistic persistence. */
export function FollowUpPicker({
  id,
  value,
}: {
  id: string;
  value: string | null;
}) {
  const [date, setDate] = useState(value ?? "");
  const [failed, setFailed] = useState(false);
  const [pending, startTransition] = useTransition();

  function change(next: string) {
    const previous = date;
    setDate(next);
    setFailed(false);
    startTransition(async () => {
      try {
        const res = await fetch("/api/prospector/history/follow-up", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ id, date: next || null }),
        });
        if (!res.ok) throw new Error(String(res.status));
      } catch {
        setDate(previous);
        setFailed(true);
      }
    });
  }

  return (
    <span className="inline-flex items-center gap-1">
      <input
        type="date"
        value={date}
        disabled={pending}
        onChange={(event) => change(event.target.value)}
        aria-label="Próximo follow-up"
        className="border-line bg-surface-2 focus:border-brand h-7 rounded-md border px-1.5 text-xs outline-none"
      />
      {failed && (
        <span className="text-warm text-xs" title="Não foi possível salvar">
          !
        </span>
      )}
    </span>
  );
}
