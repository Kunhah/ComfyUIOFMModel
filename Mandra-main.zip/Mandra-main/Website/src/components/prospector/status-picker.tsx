"use client";

import { useState, useTransition } from "react";
import { LEAD_STATUSES, type LeadStatus } from "@/lib/prospector/types";

/**
 * The one interactive control on the history page.
 *
 * Optimistic: the select shows the new value immediately and only rolls back if
 * the write fails. Marking twenty leads as contacted shouldn't mean twenty
 * round-trip waits, and a failed PATCH on a local SQLite file is close to
 * impossible anyway — but silently showing the wrong pipeline state would be
 * worse than a brief flicker, so the rollback is there.
 */

const LABEL: Record<LeadStatus, string> = {
  novo: "novo",
  contatado: "contatado",
  respondeu: "respondeu",
  cliente: "cliente",
  descartado: "descartado",
};

const TONE: Record<LeadStatus, string> = {
  novo: "border-line text-fg-muted",
  contatado: "border-brand/50 text-brand",
  respondeu: "border-warm/50 text-warm",
  cliente: "border-[#25D366]/60 text-[#25D366]",
  descartado: "border-line text-fg-muted opacity-60",
};

export function StatusPicker({
  id,
  status,
}: {
  id: string;
  status: LeadStatus;
}) {
  const [value, setValue] = useState<LeadStatus>(status);
  const [failed, setFailed] = useState(false);
  const [pending, startTransition] = useTransition();

  function change(next: LeadStatus) {
    const previous = value;
    setValue(next);
    setFailed(false);

    startTransition(async () => {
      try {
        const res = await fetch("/api/prospector/history/status", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ id, status: next }),
        });
        if (!res.ok) throw new Error(String(res.status));
      } catch {
        setValue(previous);
        setFailed(true);
      }
    });
  }

  return (
    <span className="inline-flex items-center gap-1.5">
      <select
        value={value}
        disabled={pending}
        onChange={(e) => change(e.target.value as LeadStatus)}
        className={`bg-surface-2 focus:border-brand rounded-md border px-2 py-1 text-xs outline-none ${TONE[value]}`}
      >
        {LEAD_STATUSES.map((s) => (
          <option key={s} value={s}>
            {LABEL[s]}
          </option>
        ))}
      </select>
      {failed && (
        <span className="text-warm text-xs" title="Não foi possível salvar">
          !
        </span>
      )}
    </span>
  );
}
