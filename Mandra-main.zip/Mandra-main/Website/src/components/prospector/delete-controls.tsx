"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Loader2, Trash2 } from "lucide-react";

/**
 * Removing leads from the local history — the two destructive controls on the
 * history page, and the only ones in the tool.
 *
 * They ask for very different amounts of certainty on purpose. Dropping one row
 * is a click and a browser confirm: it is visible, it is one business, and the
 * next search that covers it will find it again. Dropping everything the current
 * filters match can empty the pipeline in one request, so it names the number,
 * says which filters produced it, and is refused outright by the server for
 * anyone who is not the administrator.
 *
 * Both refresh the route rather than patching state. The page is a server
 * component whose counters, facets and per-niche breakdown all derive from the
 * same rows, and re-rendering it is the only way those stay true.
 */

export function DeleteLeadButton({
  id,
  name,
}: {
  id: string;
  /** Shown in the confirmation, so nobody deletes the wrong row from muscle memory. */
  name: string;
}) {
  const router = useRouter();
  const [failed, setFailed] = useState(false);
  const [pending, startTransition] = useTransition();

  function remove() {
    if (!window.confirm(`Remover ${name} do banco de dados?`)) return;
    setFailed(false);
    startTransition(async () => {
      try {
        const res = await fetch("/api/prospector/history/delete", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ ids: [id] }),
        });
        if (!res.ok) throw new Error(String(res.status));
        router.refresh();
      } catch {
        setFailed(true);
      }
    });
  }

  return (
    <button
      type="button"
      onClick={remove}
      disabled={pending}
      title={failed ? "Não foi possível remover" : "Remover do banco de dados"}
      aria-label={`Remover ${name} do banco de dados`}
      className={`rounded-md p-1.5 transition hover:bg-red-500/10 hover:text-red-400 disabled:opacity-40 ${
        failed ? "text-warm" : "text-fg-muted"
      }`}
    >
      {pending ? (
        <Loader2 className="size-4 animate-spin" />
      ) : (
        <Trash2 className="size-4" />
      )}
    </button>
  );
}

export function DeleteMatchingButton({
  query,
  count,
  filtered,
}: {
  /** The page's own query string, so the delete matches exactly what is shown. */
  query: string;
  count: number;
  /** Whether anything narrows the view. Unfiltered means the whole history. */
  filtered: boolean;
}) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  if (count === 0) return null;

  function remove() {
    const what = filtered
      ? `os ${count.toLocaleString("pt-BR")} leads deste filtro`
      : `TODOS os ${count.toLocaleString("pt-BR")} leads do histórico`;
    if (!window.confirm(`Apagar ${what}? Isso não pode ser desfeito.`)) return;
    // An unfiltered delete is the whole database. Typing the word is the second
    // ask — a dialog you dismiss by reflex is not a confirmation.
    if (!filtered) {
      const typed = window.prompt(
        "Isso apaga o histórico inteiro. Digite APAGAR TUDO para confirmar.",
      );
      if (typed?.trim().toUpperCase() !== "APAGAR TUDO") return;
    }

    setError(null);
    startTransition(async () => {
      try {
        const res = await fetch("/api/prospector/history/delete", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            filters: Object.fromEntries(
              new URLSearchParams(query.replace(/^\?/, "")),
            ),
            confirm: true,
            everything: !filtered,
          }),
        });
        const data = (await res.json()) as { error?: string };
        if (!res.ok) throw new Error(data.error ?? `Erro ${res.status}`);
        router.refresh();
      } catch (err) {
        setError(err instanceof Error ? err.message : String(err));
      }
    });
  }

  return (
    <span className="inline-flex items-center gap-2">
      <button
        type="button"
        onClick={remove}
        disabled={pending}
        className="inline-flex items-center gap-2 rounded-md border border-red-500/40 px-3 py-2 text-sm text-red-400 transition hover:bg-red-500/10 disabled:opacity-40"
      >
        {pending ? (
          <Loader2 className="size-4 animate-spin" />
        ) : (
          <Trash2 className="size-4" />
        )}
        Apagar {count.toLocaleString("pt-BR")}
        {filtered ? " do filtro" : " (tudo)"}
      </button>
      {error && <span className="text-warm text-xs">{error}</span>}
    </span>
  );
}
