"use client";

import { useState } from "react";
import Link from "next/link";
import { Building2, MapPin } from "lucide-react";
import {
  Prospector,
  type CountryOption,
  type InitialSearch,
} from "@/components/prospector/prospector";
import { B2b } from "@/components/prospector/b2b";
import type { Niche } from "@/lib/prospector/niches";
import type { OutreachContext } from "@/lib/prospector/templates";
import type { SearchResponse } from "@/lib/prospector/types";
import type { DiscoveryTarget } from "@/lib/b2b/sectors";
import { cn } from "@/lib/utils";

/**
 * The two prospectors on one screen.
 *
 * They used to be two routes, and moving between them was a server navigation:
 * the page unmounted, its counters were read again, and — the part that actually
 * cost something — a B2B crawl in progress was killed by leaving the tab it was
 * streaming into. A crawl is minutes long and streams NDJSON into React state,
 * so "I'll just check a city while this runs" threw the run away.
 *
 * So the switch is state and nothing else: no route change, no reload, and both
 * panels stay mounted — the inactive one is only hidden. That is the whole
 * reason `hidden` is a class here rather than a conditional render. A `{tool ===
 * "b2b" && <B2b/>}` reads better and unmounts the running crawl, which is the
 * bug this replaced.
 *
 * Four routes render this and differ only in `initialTool` and `chrome`, so
 * every URL still works as a deep link while nothing inside the tool navigates:
 * `/prospector` and `/prospector/b2b` standalone, `/admin/prospector` and
 * `/admin/prospector/b2b` inside the CRM shell.
 *
 * `chrome` is why the CRM mount is not a second copy of this file. The two
 * differ in exactly three things — the page's own padding, the header's
 * typography, and where "histórico" points — and every other line is shared. A
 * forked CRM version is how `/admin/prospector` and `/prospector` would start
 * disagreeing about what the tool says, which is the same rule the CSV column
 * lists and `parseFilters()` already live under. Before this, the CRM's B2B
 * entry left the shell entirely for the dark standalone tool: same tool, a
 * completely different-looking page, reached by a full navigation.
 */

export type LocalPanelProps = {
  niches: Niche[];
  countries: CountryOption[];
  defaultCountry: string;
  initialSearch: InitialSearch | null;
  initialResult: SearchResponse | null;
  initialError: string | null;
  canExport: boolean;
  /**
   * The opener this operator has in force, plus their name, read from SQLite
   * by the page. Passed down rather than looked up because the search board is
   * a client component and `templates-store.ts` opens a database.
   */
  outreach: OutreachContext;
  release: string;
  localExtract: boolean;
  cnpjRegister: boolean;
  history: number;
  reach: {
    countries: number;
    cities: number;
    businesses: number;
    noSite: number;
  };
};

export type B2bPanelProps = {
  targets: DiscoveryTarget[];
  countries: { code: string; label: string }[];
  europe: string[];
  storedContactable: number;
  canExport: boolean;
  uncovered: string[];
  coverageUnknown: boolean;
  release: string;
  localExtract: boolean;
  universalExtract: boolean;
  companies: number;
  contactable: number;
};

export type Tool = "local" | "b2b";

/**
 * Which shell the workspace is sitting in. `tool` is the standalone dark
 * `[data-prospector]` page; `crm` is inside the `[data-admin-shell]` sidebar
 * layout, which owns its own background and gutters.
 */
export type Chrome = "tool" | "crm";

const fmt = (n: number): string => n.toLocaleString("pt-BR");

export function ProspectorWorkspace({
  initialTool,
  local,
  b2b,
  chrome = "tool",
}: {
  initialTool: Tool;
  local: LocalPanelProps;
  /** Absent when the account was not granted the crawler; the tab is then gone. */
  b2b: B2bPanelProps | null;
  chrome?: Chrome;
}) {
  // Falls back to the local tool rather than rendering an empty screen: an
  // operator without the `b2b` grant can still reach /prospector/b2b by typing
  // it, and the page above has already redirected the ones who cannot.
  const [tool, setTool] = useState<Tool>(b2b ? initialTool : "local");
  const active = b2b ? tool : "local";
  const crm = chrome === "crm";

  return (
    <main
      className={cn(
        "mx-auto max-w-[1400px] px-5 py-8",
        // The CRM shell is a flex row with a sidebar, so the content column has
        // to claim the rest of it and gets the shell's wider gutter at md.
        crm && "w-full flex-1 md:px-8",
      )}
    >
      {b2b && (
        <div className="mb-6 flex gap-1">
          <ToolTab
            active={active === "local"}
            onClick={() => setTool("local")}
            icon={<MapPin className="size-4" />}
          >
            Negócios locais
          </ToolTab>
          <ToolTab
            active={active === "b2b"}
            onClick={() => setTool("b2b")}
            icon={<Building2 className="size-4" />}
          >
            Empresas B2B
          </ToolTab>
        </div>
      )}

      {active === "local" ? (
        <LocalHeader panel={local} chrome={chrome} />
      ) : (
        b2b && <B2bHeader panel={b2b} chrome={chrome} />
      )}

      {/* Hidden, never unmounted — see the note at the top of this file. */}
      <div className={cn(active !== "local" && "hidden")}>
        {!local.localExtract && (
          <div className="border-warm/30 bg-warm/10 mb-6 rounded-lg border px-4 py-3 text-sm">
            <strong className="text-warm font-semibold">
              Extrato local ausente.
            </strong>{" "}
            Reinicie o container para semear o banco de buscas. Em
            desenvolvimento, rode{" "}
            <code className="bg-surface-2 rounded px-1.5 py-0.5 text-xs">
              npm run sync
            </code>{" "}
            para gerar o extrato local.
          </div>
        )}
        {crm && local.localExtract && !local.cnpjRegister && (
          <div className="border-line bg-surface-2 mb-6 rounded-lg border px-4 py-3 text-sm">
            <strong className="font-semibold">Registro CNPJ ausente.</strong> As
            buscas do grupo{" "}
            <span className="text-fg">Marketing e parcerias</span> vão retornar
            só as agências que estão no mapa — o gestor de tráfego autônomo não
            aparece. Rode{" "}
            <code className="bg-surface rounded px-1.5 py-0.5 text-xs">
              npm run sync:cnpj
            </code>{" "}
            para incluí-lo.
          </div>
        )}
        <Prospector
          niches={local.niches}
          countries={local.countries}
          defaultCountry={local.defaultCountry}
          initialSearch={local.initialSearch}
          initialResult={local.initialResult}
          initialError={local.initialError}
          canExport={local.canExport}
          outreach={local.outreach}
        />
      </div>

      {b2b && (
        <div className={cn(active !== "b2b" && "hidden")}>
          {!b2b.localExtract && (
            <div className="border-warm/30 bg-warm/10 mb-6 rounded-lg border px-4 py-3 text-sm">
              <strong className="text-warm font-semibold">
                Extrato B2B ausente.
              </strong>{" "}
              A descoberta por setor vai consultar o S3 do Overture e pode levar
              vários minutos por busca. Rode{" "}
              <code className="bg-surface-2 rounded px-1.5 py-0.5 text-xs">
                npm run sync:b2b
              </code>{" "}
              uma vez para deixá-la instantânea. Colar uma lista de domínios
              funciona sem nada disso.
            </div>
          )}

          {b2b.localExtract && !b2b.universalExtract && (
            <div className="border-line bg-surface-2 text-fg-muted mb-6 rounded-lg border px-4 py-3 text-sm">
              <strong className="text-fg font-semibold">
                Radar amplo disponível sob demanda.
              </strong>{" "}
              O extrato atual cobre os perfis setoriais. Para descobrir empresas
              com qualquer categoria do Overture, gere uma vez o extrato
              universal:{" "}
              <code className="bg-surface rounded px-1.5 py-0.5 text-xs">
                npm run sync:b2b -- --universal --countries DE,AT,CH
              </code>
              .
            </div>
          )}

          <B2b
            targets={b2b.targets}
            countries={b2b.countries}
            europe={b2b.europe}
            storedContactable={b2b.storedContactable}
            canExport={b2b.canExport}
            uncovered={b2b.uncovered}
            coverageUnknown={b2b.coverageUnknown}
          />
        </div>
      )}
    </main>
  );
}

function LocalHeader({
  panel,
  chrome,
}: {
  panel: LocalPanelProps;
  chrome: Chrome;
}) {
  const crm = chrome === "crm";
  return (
    <header className="mb-8">
      <div className="flex flex-wrap items-baseline justify-between gap-3">
        <Title
          chrome={chrome}
          eyebrow="PROSPECÇÃO"
          crmTitle="Buscar leads"
          toolTitle={
            <>
              Mandra <span className="text-brand">Prospector</span>
            </>
          }
        />
        <p className="text-fg-muted text-sm">
          Overture Maps <span className="text-fg">{panel.release}</span>
          {" · "}
          {panel.localExtract ? (
            <span className="text-fg">extrato local</span>
          ) : (
            <span className="text-warm">extrato local indisponível</span>
          )}
          {" · "}
          {/* The CRM has its own, richer history screen and the standalone
              tool has the tool one. Sending an operator inside the shell out to
              /prospector/historico drops them out of the sidebar — the exact
              thing this workspace exists to stop. */}
          {panel.history > 0 ? (
            <Link
              href={crm ? "/admin/historico" : "/prospector/historico"}
              className="text-brand hover:underline"
            >
              histórico{crm ? "" : " local"}: {fmt(panel.history)}
            </Link>
          ) : (
            <span className="text-fg-muted">
              histórico{crm ? "" : " local"} vazio
            </span>
          )}
          {" · "}
          {panel.cnpjRegister ? (
            <span className="text-fg">registro CNPJ</span>
          ) : (
            <span className="text-warm">registro CNPJ ausente</span>
          )}
          {" · "}
          {/* The WhatsApp buttons in the table below are written from it, and
              this is the only screen where an operator is looking at the
              message often enough to notice it needs changing. Same
              inside/outside-the-shell rule as the history link above. */}
          <Link
            href={crm ? "/admin/mensagens" : "/prospector/mensagens"}
            className="text-brand hover:underline"
          >
            sua mensagem
          </Link>
        </p>
      </div>
      <p className="text-fg-muted mt-2 max-w-3xl text-sm">
        Encontra negócios por nicho e área — cidade, estado, região ou país — e
        ordena por quem mais precisa de um site. Dados do Overture Maps (livres
        para uso e exportação).
      </p>
      {/* Said here because the group is the only thing in the picker that is
          not a prospect list, and a "Gestores de tráfego" search that ranks
          agencies with a site at the top otherwise reads as a broken sort. */}
      <p className="text-fg-muted mt-1 max-w-3xl text-sm">
        O grupo <span className="text-fg">Marketing e parcerias</span> busca ao
        contrário: gestores de tráfego, agências e criação para fechar parceria
        de indicação — ordenados por quem já tem site e presença própria, não
        por quem precisa de um.
      </p>
      {/* States its own reach, so "nada encontrado" reads as a fact about the
          city rather than a doubt about whether the tool is working. */}
      {panel.localExtract && (
        <p className="text-fg-muted mt-1 text-sm">
          <span className="text-fg tnum">{fmt(panel.reach.countries)}</span>{" "}
          {panel.reach.countries === 1 ? "país" : "países"} ·{" "}
          <span className="text-fg tnum">{fmt(panel.reach.cities)}</span>{" "}
          cidades ·{" "}
          <span className="text-fg tnum">{fmt(panel.reach.businesses)}</span>{" "}
          negócios ·{" "}
          <span className="text-fg tnum">{fmt(panel.reach.noSite)}</span> sem
          site
        </p>
      )}
      {/* The extract is what decides reach, and it is built per country. Say
          so where the reach is stated, or "nada encontrado" in Lisbon reads as
          a bug rather than as a sync that was never run. */}
      {panel.localExtract && panel.countries.length === 1 && (
        <p className="text-fg-muted mt-1 text-xs">
          Só {panel.countries[0].label} está no extrato local. Para prospectar
          em outro país, rode{" "}
          <code className="bg-surface-2 rounded px-1.5 py-0.5">
            npm run sync -- --countries PT,ES
          </code>{" "}
          e depois{" "}
          <code className="bg-surface-2 rounded px-1.5 py-0.5">
            npm run cities
          </code>
          .
        </p>
      )}
    </header>
  );
}

function B2bHeader({
  panel,
  chrome,
}: {
  panel: B2bPanelProps;
  chrome: Chrome;
}) {
  return (
    <header className="mb-8">
      <div className="flex flex-wrap items-baseline justify-between gap-3">
        <Title
          chrome={chrome}
          eyebrow="PROSPECÇÃO"
          crmTitle="Empresas B2B"
          toolTitle={
            <>
              Mandra <span className="text-brand">Prospector B2B</span>
            </>
          }
        />
        <p className="text-fg-muted text-sm">
          Overture Maps <span className="text-fg">{panel.release}</span>
          {" · "}
          {panel.localExtract ? (
            <span className="text-fg">extrato local</span>
          ) : (
            <span className="text-warm">consulta remota (lenta)</span>
          )}
          {" · "}
          <span className="text-fg tnum">{fmt(panel.targets.length)}</span>{" "}
          perfis de busca
        </p>
      </div>
      <p className="text-fg-muted mt-2 max-w-3xl text-sm">
        Encontra as empresas que compram software como investimento, não como
        panfleto — indústria, engenharia, saúde privada, seguros, logística,
        provedores, ensino — por setor e país, rastreia o site de cada uma e
        extrai os e-mails de contato, ordenados por quem realmente responde:
        diretoria e comercial antes de{" "}
        <code className="bg-surface-2 rounded px-1 py-0.5 text-xs">info@</code>.
      </p>
      {/* The whole premise of the registry, said where the choice is made: the
          value is in the sectors nobody else is mailing, and a picker of 85
          profiles otherwise reads as a list to scroll past. */}
      <p className="text-fg-muted mt-1 max-w-3xl text-sm">
        Os perfis estão marcados de{" "}
        <span className="text-fg-subtle">●○○○○</span> a{" "}
        <span className="text-fg-subtle">●●●●●</span> por ticket, e as{" "}
        <span className="text-fg">Campanhas de alto valor</span> no topo da
        lista cruzam vários setores de uma vez —{" "}
        <span className="text-fg">Ticket máximo</span> varre só a faixa 5.
      </p>
      {panel.companies > 0 && (
        <p className="text-fg-muted mt-1 text-sm">
          <span className="text-fg tnum">{fmt(panel.companies)}</span> empresas
          rastreadas ·{" "}
          <span className="text-fg tnum">{fmt(panel.contactable)}</span> com
          e-mail
        </p>
      )}
    </header>
  );
}

/**
 * The page title in whichever voice the shell speaks.
 *
 * The standalone tool names the product ("Mandra Prospector"), because it is the
 * whole page and nothing around it says what it is. The CRM already has a
 * sidebar with our name on it, so its screens are titled by the job — an
 * eyebrow and a plain verb phrase, matching /admin/funil and /admin/ligacoes.
 * Rendering the product name there is what made the B2B screen read as a
 * different application.
 */
function Title({
  chrome,
  eyebrow,
  crmTitle,
  toolTitle,
}: {
  chrome: Chrome;
  eyebrow: string;
  crmTitle: string;
  toolTitle: React.ReactNode;
}) {
  if (chrome === "crm") {
    return (
      <div>
        <p className="text-brand text-xs font-semibold tracking-[0.16em]">
          {eyebrow}
        </p>
        <h1 className="mt-1.5 text-3xl font-semibold tracking-tight md:text-[34px]">
          {crmTitle}
        </h1>
      </div>
    );
  }
  return <h1 className="text-2xl font-semibold tracking-tight">{toolTitle}</h1>;
}

function ToolTab({
  active,
  onClick,
  icon,
  children,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "inline-flex items-center gap-2 rounded-md px-3 py-2 text-sm transition",
        active
          ? "border-line bg-surface text-fg border font-medium"
          : "text-fg-muted hover:text-fg border border-transparent",
      )}
    >
      {icon}
      {children}
    </button>
  );
}
