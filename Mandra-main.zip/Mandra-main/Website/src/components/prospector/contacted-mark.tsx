import { Ban, History, Trophy } from "lucide-react";
import { isClosedStage, type FunnelStage } from "@/lib/prospector/types";

/**
 * What the buttons beside this need you to know before you press them.
 *
 * Two warnings, one slot, in that order of severity:
 *
 *  1. **Closed or lost.** The conversation is over — they bought, or they said
 *     no. `dailyCandidates` has never drawn one and `createCallList` no longer
 *     builds one in, so nothing hands an operator a closed lead any more; this
 *     is what covers the paths that stay open on purpose, where the number is
 *     sitting right there next to a `tel:` link.
 *  2. **Already contacted.** Somebody here has reached out. A repeat first
 *     contact is the one mistake a prospect always notices, and until this
 *     existed nothing on the search screen said it had happened — `novo` marks a
 *     business we had never *seen*, which is a different question.
 *
 * The closed mark supersedes the contacted one rather than stacking with it: a
 * lead cannot reach a closed stage without having been contacted, so showing
 * both would spend two lines of a dense table on one fact and bury the sharper
 * half of it.
 *
 * Both are warnings, never blocks. Phoning a customer is often exactly right,
 * and so is a follow-up to a lead who once said no — the buttons stay live and
 * the mark only makes sure the decision is made knowingly. `ownership.ts` is
 * what actually refuses a contact, and it renders separately.
 *
 * The dates are sliced rather than parsed, like every other date on these
 * screens: `new Date(iso)` reads the timestamp as UTC and would render a call
 * made on Tuesday evening in Brasília as Wednesday.
 */

/** The shape both warnings read. Every caller has some of it; none has all of it. */
export type ContactMarkLead = {
  contactedAt?: string | null;
  attempts?: number;
  owner?: { name: string } | null;
  funnelStage?: FunnelStage | null;
};

/** A YYYY-MM-DD or an ISO timestamp as a short date. Never `new Date(iso)`. */
function shortDate(value: string): string {
  const [y, m, d] = value.slice(0, 10).split("-");
  return y && m && d ? `${d}/${m}` : value;
}

/** The full sentence, used as the tooltip and read out to a screen reader. */
export function contactedTitle(lead: ContactMarkLead): string {
  if (isClosedStage(lead.funnelStage)) {
    const won = lead.funnelStage === "fechado";
    return won
      ? "Já é cliente — este negócio foi fechado. Não prospecte de novo; fale com o responsável antes de qualquer contato."
      : "Lead perdido — este negócio já disse não. Não ligue de novo sem um motivo novo.";
  }

  const parts = [`Já contatado em ${shortDate(lead.contactedAt ?? "")}`];
  if (lead.attempts && lead.attempts > 0) {
    parts.push(
      `${lead.attempts} ${lead.attempts === 1 ? "ligação registrada" : "ligações registradas"}`,
    );
  }
  if (lead.owner) parts.push(`atendido por ${lead.owner.name}`);
  return `${parts.join(" · ")}. Confirme antes de entrar em contato de novo.`;
}

export function ContactedMark({
  lead,
  variant = "chip",
}: {
  lead: ContactMarkLead;
  /** `icon` for the CRM's icon-only actions column, where a chip does not fit. */
  variant?: "chip" | "icon";
}) {
  const closed = isClosedStage(lead.funnelStage);
  if (!closed && !lead.contactedAt) return null;

  const won = lead.funnelStage === "fechado";
  const title = contactedTitle(lead);
  const Icon = closed ? (won ? Trophy : Ban) : History;

  // Won is its own colour: an existing customer is good news that happens to
  // mean "do not cold-call", and painting it the red of a rejection would read
  // as a problem with the account every time somebody scanned the table.
  const tone = closed
    ? won
      ? "border-emerald-300 bg-emerald-50 text-emerald-800"
      : "border-red-300 bg-red-50 text-red-800"
    : "border-amber-300 bg-amber-50 text-amber-800";

  const label = closed
    ? won
      ? "já é cliente · não prospectar"
      : "perdido · não ligar"
    : `já contatado ${shortDate(lead.contactedAt ?? "")}${
        lead.attempts && lead.attempts > 0 ? ` · ${lead.attempts}×` : ""
      }`;

  if (variant === "icon") {
    return (
      <span
        title={title}
        className={`inline-flex items-center rounded-md border p-1 ${tone}`}
      >
        <Icon className="size-3.5" />
        <span className="sr-only">{title}</span>
      </span>
    );
  }

  return (
    <span
      title={title}
      className={`inline-flex items-center gap-1 rounded border px-1.5 py-0.5 text-[11px] leading-tight font-medium ${tone}`}
    >
      <Icon className="size-3 shrink-0" />
      {label}
      <span className="sr-only">. {title}</span>
    </span>
  );
}
