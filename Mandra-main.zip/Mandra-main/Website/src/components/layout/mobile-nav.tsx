"use client";

import { useEffect, useRef } from "react";
import Link from "next/link";
import { X } from "lucide-react";
import { navLinks } from "@/content/nav";
import { ButtonLink } from "@/components/ui/button";
import { Logo } from "@/components/ui/logo";

type MobileNavProps = {
  open: boolean;
  onClose: () => void;
};

export function MobileNav({ open, onClose }: MobileNavProps) {
  const panelRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);

  // Lock body scroll, move focus in, and trap Tab within the panel.
  useEffect(() => {
    if (!open) return;

    const previouslyFocused = document.activeElement as HTMLElement | null;
    const { overflow } = document.body.style;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        onClose();
        return;
      }
      if (event.key !== "Tab" || !panelRef.current) return;

      const focusable = panelRef.current.querySelectorAll<HTMLElement>(
        'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])',
      );
      if (focusable.length === 0) return;

      const first = focusable[0];
      const last = focusable[focusable.length - 1];

      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = overflow;
      previouslyFocused?.focus();
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      ref={panelRef}
      role="dialog"
      aria-modal="true"
      aria-label="Menu de navegação"
      data-tone="light"
      className="bg-surface fixed inset-0 z-50 flex flex-col lg:hidden"
    >
      <div className="flex h-16 items-center justify-between px-5">
        <Logo />
        <button
          ref={closeRef}
          type="button"
          onClick={onClose}
          aria-label="Fechar menu"
          className="rounded-control text-fg-muted hover:bg-fg/5 hover:text-fg flex size-10 items-center justify-center transition-colors"
        >
          <X className="size-5" />
        </button>
      </div>

      <nav className="flex flex-1 flex-col gap-1 px-5 pt-4">
        {navLinks.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            onClick={onClose}
            className="border-line text-fg hover:text-brand-600 border-b py-4 text-xl font-medium transition-colors"
          >
            {link.label}
          </Link>
        ))}
      </nav>

      <div className="px-5 pt-6 pb-10">
        <ButtonLink
          href="#contato"
          size="lg"
          withArrow
          onClick={onClose}
          className="w-full"
        >
          Solicitar orçamento
        </ButtonLink>
      </div>
    </div>
  );
}
