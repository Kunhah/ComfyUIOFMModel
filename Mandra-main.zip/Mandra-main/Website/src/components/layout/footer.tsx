import Link from "next/link";
import { Mail, MapPin, Phone } from "lucide-react";
import { site, legalLinks } from "@/content/site";
import {
  navLinks,
  footerServiceLinks,
  footerSegmentLinks,
} from "@/content/nav";
import { Container } from "@/components/ui/container";
import { LogoMark } from "@/components/ui/logo";
import { BrandIcon, brandPaths } from "@/components/ui/brand-icon";
import { Legend } from "@/components/rede/plate";

// The phone was a placeholder and was deliberately unrendered; it is real now,
// so it leads. It is also the site's primary conversion route — the ad landing
// pages under src/app/(ads)/ exist to end in a tap on this same href — which is
// why it sits above the e-mail rather than below the address.
const contactRows = [
  { icon: Phone, text: site.contact.phone, href: site.contact.phoneHref },
  { icon: Mail, text: site.contact.email, href: site.contact.emailHref },
  { icon: MapPin, text: site.contact.address, href: null },
];

function FooterColumn({
  title,
  links,
}: {
  title: string;
  links: readonly { label: string; href: string }[];
}) {
  return (
    <div>
      <h3>
        <Legend>{title}</Legend>
      </h3>
      <ul className="mt-5 space-y-2.5">
        {links.map((link) => (
          <li key={link.label}>
            <Link
              href={link.href}
              className="text-fg-muted hover:text-brand-300 text-sm transition-colors duration-200"
            >
              {link.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function Footer() {
  return (
    <footer data-tone="night" className="border-line bg-bg text-fg border-t">
      <Container size="wide" className="py-16 sm:py-20">
        <div className="grid gap-12 sm:grid-cols-2 lg:grid-cols-[1.35fr_1fr_1.1fr_1fr_1.1fr]">
          <div>
            <Link
              href="/"
              aria-label="Mandra — página inicial"
              className="inline-flex items-center gap-2 transition-opacity hover:opacity-80"
            >
              <LogoMark className="text-brand-400" />
              <span className="text-[15px] font-semibold tracking-[-0.01em]">
                MANDRA
              </span>
            </Link>
            <p className="text-fg-muted mt-4 max-w-xs text-sm leading-relaxed">
              {site.blurb}
            </p>
            <ul className="mt-6 flex items-center gap-2">
              {site.social.map((item) => (
                <li key={item.label}>
                  <a
                    href={item.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={item.label}
                    className="plate text-fg-muted hover:text-brand-300 flex size-9 items-center justify-center rounded-[4px] transition-colors duration-200"
                  >
                    <BrandIcon path={brandPaths[item.icon]} />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <FooterColumn title="Links rápidos" links={navLinks} />
          <FooterColumn title="Serviços" links={footerServiceLinks} />
          <FooterColumn title="Por segmento" links={footerSegmentLinks} />

          <div>
            <h3>
              <Legend>Contato</Legend>
            </h3>
            <ul className="mt-5 space-y-3">
              {contactRows.map(({ icon: Icon, text, href }) => (
                <li key={text} className="flex items-start gap-2.5">
                  <Icon className="text-brand-400 mt-0.5 size-4 shrink-0" />
                  {href ? (
                    <a
                      href={href}
                      className="text-fg-muted hover:text-brand-300 text-sm transition-colors duration-200"
                    >
                      {text}
                    </a>
                  ) : (
                    <span className="text-fg-muted text-sm">{text}</span>
                  )}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-line mt-14 flex flex-col gap-4 border-t pt-6 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-fg-subtle text-xs">
            © {new Date().getFullYear()} {site.name}. Todos os direitos
            reservados.
          </p>
          <ul className="flex flex-wrap items-center gap-6">
            {legalLinks.map((link) => (
              <li key={link.href}>
                <Link
                  href={link.href}
                  className="text-fg-subtle hover:text-fg text-xs transition-colors"
                >
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </Container>
    </footer>
  );
}
