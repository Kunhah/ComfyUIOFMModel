"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Menu } from "lucide-react";
import { navLinks } from "@/content/nav";
import { Logo } from "@/components/ui/logo";
import { MobileNav } from "@/components/layout/mobile-nav";
import { Lamp } from "@/components/rede/plate";
import { cn } from "@/lib/utils";

/**
 * The service head: the chrome that hangs above the bundle.
 *
 * It stays transparent over the field so the cables run behind it, and drops
 * onto a plate once the page scrolls — the header is a piece of the same
 * hardware as everything else, so it gets the plate's milled edges rather than
 * a blurred white bar. The primary action is a terminal, square and stamped,
 * because a rounded pill button is the one atom that would give the whole
 * committed world away.
 */
export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const closeMenu = useCallback(() => setMenuOpen(false), []);

  return (
    <>
      <header
        data-tone="night"
        className={cn(
          "ease-out-soft sticky top-0 z-40 w-full transition-[background-color,border-color,box-shadow] duration-300",
          scrolled
            ? "border-line border-b bg-[rgb(6_8_11/0.82)] shadow-[0_1px_0_rgb(255_255_255/0.05),0_18px_40px_-30px_rgb(0_0_0/1)] backdrop-blur-md"
            : "border-b border-transparent bg-transparent",
        )}
      >
        <div className="mx-auto flex h-16 w-full max-w-[1360px] items-center justify-between gap-6 px-5 sm:px-8 lg:h-[72px]">
          <Logo />

          <nav
            aria-label="Navegação principal"
            className="hidden items-center gap-7 lg:flex"
          >
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-fg-muted hover:text-brand-300 text-[13px] font-medium tracking-[0.01em] transition-colors duration-200"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <Link
              href="#contato"
              className="plate text-fg hover:text-ink-950 hover:bg-brand-400 group hidden items-center gap-2.5 rounded-[4px] px-4 py-2.5 text-[13px] font-semibold transition-colors duration-200 sm:inline-flex"
            >
              <Lamp live className="group-hover:bg-ink-950 group-hover:shadow-none" />
              Solicitar orçamento
            </Link>
            <button
              type="button"
              onClick={() => setMenuOpen(true)}
              aria-label="Abrir menu"
              aria-expanded={menuOpen}
              className="text-fg hover:bg-fg/10 flex size-10 items-center justify-center rounded-[4px] transition-colors lg:hidden"
            >
              <Menu className="size-5" />
            </button>
          </div>
        </div>
      </header>

      <MobileNav open={menuOpen} onClose={closeMenu} />
    </>
  );
}
