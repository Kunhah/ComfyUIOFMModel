/**
 * Fresnel rim glow. Rendered on a slightly larger back-faced sphere with
 * additive blending, so only the limb lights up and the globe itself stays
 * unobscured.
 */

export const atmosphereVertex = /* glsl */ `
  varying vec3 vNormal;
  varying vec3 vWorldPos;

  void main() {
    vNormal = normalize(mat3(modelMatrix) * normal);
    vec4 worldPos = modelMatrix * vec4(position, 1.0);
    vWorldPos = worldPos.xyz;
    gl_Position = projectionMatrix * viewMatrix * worldPos;
  }
`;

export const atmosphereFragment = /* glsl */ `
  uniform vec3 uColor;
  uniform float uPower;
  uniform float uIntensity;

  varying vec3 vNormal;
  varying vec3 vWorldPos;

  void main() {
    vec3 viewDir = normalize(cameraPosition - vWorldPos);
    // abs() because we render back faces — the normal points away from us.
    float fresnel = pow(1.0 - abs(dot(normalize(vNormal), viewDir)), uPower);
    gl_FragColor = vec4(uColor, fresnel * uIntensity);
  }
`;
