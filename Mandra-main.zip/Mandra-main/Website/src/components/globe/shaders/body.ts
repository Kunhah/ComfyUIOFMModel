/**
 * Opaque globe body sitting just under the dot cloud. Its real job is depth:
 * by writing depth it occludes dots on the far hemisphere, which no amount of
 * alpha trickery in the dot shader can do correctly. Visually it supplies the
 * deep-blue sphere the dots sit on, with a soft terminator.
 */

export const bodyVertex = /* glsl */ `
  varying vec3 vNormal;
  varying vec3 vWorldPos;

  void main() {
    vNormal = normalize(mat3(modelMatrix) * normal);
    vec4 worldPos = modelMatrix * vec4(position, 1.0);
    vWorldPos = worldPos.xyz;
    gl_Position = projectionMatrix * viewMatrix * worldPos;
  }
`;

export const bodyFragment = /* glsl */ `
  uniform vec3 uLitColor;
  uniform vec3 uShadeColor;
  uniform vec3 uLimbColor;
  uniform vec3 uLightDir;
  uniform vec3 uFadeColor;
  uniform float uProgress;
  uniform float uOpacity;

  varying vec3 vNormal;
  varying vec3 vWorldPos;

  void main() {
    vec3 normal = normalize(vNormal);
    vec3 viewDir = normalize(cameraPosition - vWorldPos);

    // Day/night falloff from a fixed key light, deliberately soft so the
    // terminator reads as shading rather than a hard line.
    float lambert = smoothstep(-0.35, 0.85, dot(normal, normalize(uLightDir)));
    vec3 color = mix(uShadeColor, uLitColor, lambert);

    // Darken toward the limb so the sphere reads as curved, not as a flat disc.
    float facing = clamp(dot(normal, viewDir), 0.0, 1.0);
    color = mix(uLimbColor, color, pow(facing, 0.55));

    // Washes toward the hero background as the globe starts breaking up, then
    // fades out entirely — it belongs to the intact sphere only.
    color = mix(color, uFadeColor, pow(clamp(uProgress, 0.0, 1.0), 1.15));

    gl_FragColor = vec4(color, uOpacity);
  }
`;
