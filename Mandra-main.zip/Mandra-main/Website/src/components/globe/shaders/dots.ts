/**
 * Land-dot shader. Shaders live in .ts modules rather than .glsl files so no
 * Turbopack loader configuration is needed.
 *
 * The dots run a three-act scroll sequence, all in the vertex stage:
 *   1. globe    — points sit on the sphere, breathing gently
 *   2. explode  — they burst outward into a swirling cloud
 *   3. reform   — the cloud converges into the Mandra "M" monogram
 * then the whole thing disperses.
 */

export const dotsVertex = /* glsl */ `
  uniform float uTime;
  uniform float uExplode;   // 0→1 scatter off the sphere
  uniform float uReform;    // 0→1 converge into the monogram
  uniform float uCloudRadius;
  uniform float uSize;
  uniform float uPixelRatio;

  attribute float aScale;
  attribute float aSeed;
  attribute vec3 aMonogram;
  attribute vec3 aDrift;

  varying float vFacing;
  varying float vSeed;
  varying float vReform;

  void main() {
    vec3 spherePos = position; // unit sphere

    // Gentle breathing while the globe is intact.
    float breathe = sin(uTime * 0.8 + aSeed * 6.2831) * 0.004;
    spherePos *= 1.0 + breathe;

    // --- act 2: scatter into a cloud -------------------------------------
    // aDrift is an isotropic point inside the unit ball, so the cloud's outer
    // envelope is exactly uCloudRadius and its silhouette is round. Moving to a
    // bounded target rather than pushing each point outward by a free distance
    // is what keeps the cloud inside the camera frustum — overflow it and the
    // canvas crops the cloud into a hard-edged rectangle.
    //
    // The path bows outward on the way, because the cloud's mean radius (~0.92)
    // is slightly *inside* the sphere the points start on: interpolating straight
    // to it reads as the globe imploding, not bursting.
    float arc = sin(uExplode * 3.1415927) * 0.12;
    vec3 cloudPos = mix(spherePos * (1.0 + arc), aDrift * uCloudRadius, uExplode);

    // Slow swirl so the cloud drifts instead of hanging frozen. Each point
    // circles its own radius, so the motion is tangential and adds nothing to
    // the envelope — offsetting along the world axes instead (sin on x, cos on
    // y, sin on z) traces a box and works against the round silhouette.
    vec3 radial = normalize(cloudPos + vec3(1e-4));
    vec3 ref = abs(radial.y) < 0.9 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
    vec3 tanA = normalize(cross(radial, ref));
    vec3 tanB = cross(radial, tanA);
    float swirl = uTime * 0.5 + aSeed * 6.2831;
    cloudPos += (cos(swirl) * tanA + sin(swirl) * tanB) * 0.09 * uExplode;

    // --- act 3: settle into the mark -------------------------------------
    // Staggering by seed makes the mark assemble progressively rather than
    // every point landing on the same frame.
    float settle = clamp((uReform - aSeed * 0.25) / 0.75, 0.0, 1.0);
    settle = settle * settle * (3.0 - 2.0 * settle); // smoothstep
    vec3 pos = mix(cloudPos, aMonogram, settle);

    vec4 worldPos = modelMatrix * vec4(pos, 1.0);
    vec4 mvPosition = viewMatrix * worldPos;

    // How squarely this dot faces the camera: 1 at the sub-camera point,
    // 0 at the limb, negative on the far hemisphere. Loose points and the flat
    // mark always face us, so the limb term is blended out.
    vec3 worldNormal = normalize(mat3(modelMatrix) * normalize(position));
    vec3 viewDir = normalize(cameraPosition - worldPos.xyz);
    float sphereFacing = dot(worldNormal, viewDir);
    vFacing = mix(sphereFacing, 1.0, max(uExplode, settle));

    vSeed = aSeed;
    vReform = settle;

    // Perspective-correct sizing: dots shrink with distance. The cloud phase
    // grows them slightly to offset the camera easing back, so the swarm doesn't
    // dim just as it becomes the only thing on screen.
    float grow = 1.0 + uExplode * 0.3;
    gl_PointSize = uSize * aScale * grow * uPixelRatio / -mvPosition.z;
    gl_Position = projectionMatrix * mvPosition;
  }
`;

export const dotsFragment = /* glsl */ `
  uniform vec3 uColorDeep;
  uniform vec3 uColorBright;
  uniform vec3 uColorMark;
  uniform float uOpacity;
  uniform float uExplode;
  uniform float uSolid;   // 1 while the dark globe body is intact, 0 once gone
  uniform float uTime;

  varying float vFacing;
  varying float vSeed;
  varying float vReform;

  void main() {
    // Round off the square point sprite.
    float d = length(gl_PointCoord - 0.5);
    float mask = smoothstep(0.5, 0.28, d);
    if (mask < 0.01) discard;

    // Fade out across the limb so the far hemisphere doesn't show through.
    float front = smoothstep(-0.08, 0.32, vFacing);

    // Slow, desynchronised twinkle keeps the surface from looking static.
    float twinkle = 0.85 + 0.15 * sin(uTime * 1.6 + vSeed * 12.0);

    vec3 color = mix(uColorDeep, uColorBright, pow(clamp(vFacing, 0.0, 1.0), 1.5));

    // The terrain tint is pale because it is read against a dark globe. The
    // moment that globe is gone the dots sit on the cream page, so they have
    // to become a saturated brand amber to stay visible at all.
    //
    // Keyed on the body fading rather than on the scatter starting: the body
    // leads the scatter, and during that gap pale dots on a pale sphere read as
    // a blank ball.
    float loose = max(1.0 - uSolid, max(uExplode, vReform));
    color = mix(color, uColorMark, loose);

    float alpha = mask * front * uOpacity * twinkle;
    gl_FragColor = vec4(color, alpha);
  }
`;

export const markerVertex = /* glsl */ `
  uniform float uSize;
  uniform float uPixelRatio;

  attribute float aSeed;

  varying float vFacing;
  varying float vSeed;

  void main() {
    vec4 worldPos = modelMatrix * vec4(position, 1.0);
    vec4 mvPosition = viewMatrix * worldPos;

    vec3 worldNormal = normalize(mat3(modelMatrix) * normalize(position));
    vec3 viewDir = normalize(cameraPosition - worldPos.xyz);
    vFacing = dot(worldNormal, viewDir);
    vSeed = aSeed;

    gl_PointSize = uSize * uPixelRatio / -mvPosition.z;
    gl_Position = projectionMatrix * mvPosition;
  }
`;

export const markerFragment = /* glsl */ `
  uniform vec3 uColor;
  uniform float uTime;
  uniform float uOpacity;

  varying float vFacing;
  varying float vSeed;

  void main() {
    // 0 at the sprite centre, 1 at its edge.
    float d = length(gl_PointCoord - 0.5) * 2.0;

    float core = 1.0 - smoothstep(0.0, 0.26, d);

    // A ring that expands and fades on repeat — the "active node" pulse.
    float phase = fract(uTime * 0.45 + vSeed);
    float ring = smoothstep(0.09, 0.0, abs(d - phase)) * (1.0 - phase);

    float front = smoothstep(0.0, 0.3, vFacing);
    float alpha = (core + ring * 0.85) * front * uOpacity;
    if (alpha < 0.01) discard;

    gl_FragColor = vec4(uColor, alpha);
  }
`;
