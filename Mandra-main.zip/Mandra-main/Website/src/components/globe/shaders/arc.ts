/**
 * Connection arc. A dim base line carries a bright head with a fading tail
 * that travels along the tube's length (vUv.x runs 0→1 end to end).
 */

export const arcVertex = /* glsl */ `
  varying vec2 vUv;

  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

export const arcFragment = /* glsl */ `
  uniform vec3 uColor;
  uniform float uTime;
  uniform float uSpeed;
  uniform float uOffset;   // desynchronises arcs that share a speed
  uniform float uOpacity;

  varying vec2 vUv;

  void main() {
    float t = fract(vUv.x - uTime * uSpeed + uOffset);

    // Sharp leading edge, long soft tail.
    float head = smoothstep(0.0, 0.05, t) * (1.0 - smoothstep(0.05, 0.34, t));

    float alpha = (0.10 + head * 0.95) * uOpacity;
    gl_FragColor = vec4(uColor, alpha);
  }
`;
