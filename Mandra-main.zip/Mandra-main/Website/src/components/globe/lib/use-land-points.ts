"use client";

import { useEffect, useState } from "react";
import { latLonToVec3 } from "@/components/globe/lib/coords";

export type GlobePoints = {
  /** Position on the sphere. */
  positions: Float32Array;
  /** Matching position inside the Mandra "M" the cloud reassembles into. */
  monogram: Float32Array;
  /** Where this point sits in the scattered cloud, inside the unit ball. */
  drifts: Float32Array;
  scales: Float32Array;
  seeds: Float32Array;
  count: number;
};

/**
 * mulberry32's mixing step: an integer hash giving several *independent*
 * uniforms per point, seeded only by the index — so the cloud looks identical on
 * every load without needing Math.random.
 *
 * Worth the arithmetic over the usual `fract(sin(seed))` trick. Feeding one
 * sine into all three components of a direction gives each component an arcsine
 * distribution, which piles values up near ±1 — the directions then cluster
 * around the corners of a cube instead of covering the sphere.
 */
function hash(n: number) {
  let t = (n + 0x6d2b79f5) | 0;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}

/**
 * Loads both pre-computed clouds — land points on the sphere, and the monogram
 * the dots reform into — and expands them into the typed arrays the dot
 * geometry needs.
 *
 * `budget` caps the point count; the caller passes a lower number on small
 * screens. Points are taken evenly across the file rather than from its head, so
 * a reduced cloud still covers the whole globe.
 *
 * The step is fractional on purpose. An integer stride quantises hard — at
 * 48,831 points and a budget of 44,000 it rounds to a stride of 2 and throws
 * away nearly half the detail that was asked for.
 */
export function useLandPoints(budget: number): GlobePoints | null {
  const [points, setPoints] = useState<GlobePoints | null>(null);

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();

    const load = async (url: string) => {
      const res = await fetch(url, { signal: controller.signal });
      if (!res.ok) throw new Error(`${url}: ${res.status}`);
      return new Int16Array(await res.arrayBuffer());
    };

    Promise.all([
      load("/data/land-points.bin"),
      load("/data/monogram-points.bin"),
    ])
      .then(([raw, mono]) => {
        if (cancelled) return;

        const total = raw.length / 2;
        const monoCount = mono.length / 2;
        const count = Math.min(total, budget);
        const step = total / count;

        const positions = new Float32Array(count * 3);
        const monogram = new Float32Array(count * 3);
        const drifts = new Float32Array(count * 3);
        const scales = new Float32Array(count);
        const seeds = new Float32Array(count);

        for (let i = 0; i < count; i++) {
          const src = Math.floor(i * step);
          const lat = raw[src * 2] / 100;
          const lon = raw[src * 2 + 1] / 100;
          const v = latLonToVec3(lat, lon, 1);

          positions[i * 3] = v.x;
          positions[i * 3 + 1] = v.y;
          positions[i * 3 + 2] = v.z;

          const rand = hash(i * 4);
          scales[i] = 0.65 + rand * 0.75;
          seeds[i] = rand;

          // Scatter target. The direction is area-uniform on the sphere (pick z
          // uniformly, then a longitude) so the cloud has no preferred axis, and
          // the radius is cube-rooted and biased outward, giving a thick shell
          // that reads as a round, evenly dense blob from any angle.
          const z = hash(i * 4 + 1) * 2 - 1;
          const ring = Math.sqrt(Math.max(0, 1 - z * z));
          const theta = hash(i * 4 + 2) * Math.PI * 2;
          const radius = 0.34 + 0.66 * Math.cbrt(hash(i * 4 + 3));

          drifts[i * 3] = Math.cos(theta) * ring * radius;
          drifts[i * 3 + 1] = Math.sin(theta) * ring * radius;
          drifts[i * 3 + 2] = z * radius;

          // Deliberately not spatially matched to the sphere position: pairing
          // them at random means every dot travels a long way to its place in
          // the mark, which is what makes the reassembly read as a swarm.
          const m = (i * 7919) % monoCount;
          monogram[i * 3] = mono[m * 2] / 1000;
          monogram[i * 3 + 1] = mono[m * 2 + 1] / 1000;
          // A little depth so the flat mark still catches the point sizing.
          monogram[i * 3 + 2] = (rand - 0.5) * 0.06;
        }

        setPoints({ positions, monogram, drifts, scales, seeds, count });
      })
      .catch((error) => {
        if ((error as Error).name !== "AbortError") {
          console.error("Globe point data failed to load", error);
        }
      });

    return () => {
      cancelled = true;
      controller.abort();
    };
  }, [budget]);

  return points;
}
