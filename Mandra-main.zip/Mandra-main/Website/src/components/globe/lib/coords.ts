import { QuadraticBezierCurve3, Vector3 } from "three";

const DEG2RAD = Math.PI / 180;

/**
 * Equirectangular lat/lon → a point on a sphere, using the same convention as
 * three's SphereGeometry so markers, dots and arcs all agree.
 */
export function latLonToVec3(lat: number, lon: number, radius = 1): Vector3 {
  const phi = (90 - lat) * DEG2RAD;
  const theta = (lon + 180) * DEG2RAD;
  return new Vector3(
    -radius * Math.sin(phi) * Math.cos(theta),
    radius * Math.cos(phi),
    radius * Math.sin(phi) * Math.sin(theta),
  );
}

/**
 * A great-circle-ish arc between two surface points. The control point is the
 * midpoint pushed outward in proportion to the angular separation, so short
 * hops stay low and long routes bow higher. Kept deliberately shallow — a
 * steeper lift throws arcs outside the globe's silhouette and reads as noise.
 */
export function arcBetween(
  from: Vector3,
  to: Vector3,
  radius = 1,
): QuadraticBezierCurve3 {
  const angle = from.angleTo(to);
  const lift = 1 + 0.035 + angle * 0.12;
  const mid = from.clone().add(to).normalize().multiplyScalar(radius * lift);
  return new QuadraticBezierCurve3(from.clone(), mid, to.clone());
}
