"use client";

/* eslint-disable react-hooks/immutability --
 * Driving a Three.js scene means mutating uniform values on materials each
 * frame. Those materials are built once in useMemo (allocating them per render
 * would thrash the GPU), so the compiler sees mutation of a memoised value.
 * That is the intended pattern for imperative GPU objects and has no immutable
 * equivalent — recreating a ShaderMaterial per frame is exactly what we must
 * avoid. Mutation here never feeds React's render output.
 */

import { useEffect, useMemo, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import {
  AdditiveBlending,
  NormalBlending,
  BackSide,
  BufferAttribute,
  BufferGeometry,
  Color,
  Group,
  MathUtils,
  Points,
  Mesh,
  FrontSide,
  Vector3,
  ShaderMaterial,
  TubeGeometry,
} from "three";
import { getScroll } from "@/lib/scroll-store";
import { globeCities, globeRoutes } from "@/content/globe";
import { arcBetween, latLonToVec3 } from "@/components/globe/lib/coords";
import { useLandPoints } from "@/components/globe/lib/use-land-points";
import {
  dotsVertex,
  dotsFragment,
  markerVertex,
  markerFragment,
} from "@/components/globe/shaders/dots";
import {
  atmosphereVertex,
  atmosphereFragment,
} from "@/components/globe/shaders/atmosphere";
import { bodyVertex, bodyFragment } from "@/components/globe/shaders/body";
import { arcVertex, arcFragment } from "@/components/globe/shaders/arc";

/**
 * The globe is the brand in three dimensions: a charcoal body — the mascot's
 * own black — lit by amber land, arcs and markers. The dot colours are pale
 * ambers because they are read against that dark body; MARK is the saturated
 * one, since by the time the monogram assembles the body is gone and the dots
 * are sitting on the cream page (see the mix in dotsFragment).
 */
const DEEP = new Color("#c98a3f");
const BRIGHT = new Color("#ffe6bd");
const ATMO = new Color("#f3a33a");
const ARC = new Color("#ffc27a");
const MARKER = new Color("#ffdfae");
const BODY_LIT = new Color("#453b2d");
const BODY_SHADE = new Color("#17161a");
const BODY_LIMB = new Color("#0b0e12");
const MARK = new Color("#c97b10"); // assembled monogram, read on the cream page
const BODY_FADE = new Color("#fdfbf7"); // ≈ the hero background
const LIGHT_DIR = new Vector3(-0.45, 0.35, 0.82).normalize();

const MARKER_RADIUS = 1.012;
const ARC_RADIUS = 1.006;
const BODY_RADIUS = 0.992;

/**
 * ---- frustum budget ------------------------------------------------------
 *
 * Anything wider than the camera frustum is cropped by the canvas edge, and
 * because the stage is always `aspect-square` that crop is a hard-edged
 * rectangle — the single most conspicuous way this sequence can break. At fov 35
 * the visible half-extent on both axes is `h(z) = z * tan(17.5°) ≈ 0.3153 * z`,
 * so every act has to fit under its own h:
 *
 *   act 1  globe   r = 1.055 (atmosphere)  z = 3.60  h = 1.135   → 93%
 *   act 2  cloud   r ≤ 1.11 (arc peak)     z ≥ 3.85  h ≥ 1.213   → ≤ 89%
 *   act 3  mark    half-width 1.088        z = 3.90  h = 1.230   → 88%
 *
 * Keep every ratio under ~0.9. The cloud is the tight one: its envelope peaks
 * mid-flight, which is why the camera eases back on sqrt(explode) — a linear
 * pull-back is still too close when the bulge arrives. The mark's half-width is
 * a property of public/data/monogram-points.bin, so regenerating that at a
 * different scale means re-checking this table.
 */
const ATMOSPHERE_RADIUS = 1.055;
export const CAMERA_Z = 3.6;

/** Outer radius of the scattered cloud. See the frustum budget above. */
const CLOUD_RADIUS = 1.1;
/** Camera easing: back for the cloud, then in again to frame the mark. */
const EXPLODE_PULLBACK = 0.55;
const REFORM_PUSHIN = 0.25;

/**
 * Longitude facing the camera is `-90 - degrees(rotation.y)`, so -0.7 rad puts
 * Brazil and the Atlantic front and centre — where the markers and arcs are
 * densest — instead of an empty Pacific.
 */
const INITIAL_SPIN = -0.7;

/** How far the pointer swings the globe, in radians at the screen edge. */
const POINTER_YAW = 0.42;
const POINTER_PITCH = 0.3;

/** GLSL-style smoothstep, for keeping the JS phase curves in the same shape. */
function smoothstep(edge0: number, edge1: number, x: number) {
  const t = MathUtils.clamp((x - edge0) / (edge1 - edge0), 0, 1);
  return t * t * (3 - 2 * t);
}

type Props = {
  pointBudget: number;
  /** Static single frame, no rotation or scroll coupling. */
  reducedMotion: boolean;
  /** Fired once the dot cloud has actually been drawn, so the poster can fade. */
  onFirstFrame?: () => void;
};

export function GlobeScene({
  pointBudget,
  reducedMotion,
  onFirstFrame,
}: Props) {
  const land = useLandPoints(pointBudget);
  const { camera, invalidate } = useThree();

  const groupRef = useRef<Group>(null);
  const spinRef = useRef(INITIAL_SPIN);
  const progressRef = useRef(0);
  const pointerRef = useRef({ x: 0, y: 0 });
  const pointerYawRef = useRef(0);
  const bodyRef = useRef<Mesh>(null);
  const announcedRef = useRef(false);

  // ---- dot cloud -----------------------------------------------------------
  const dots = useMemo(() => {
    if (!land) return null;

    const geometry = new BufferGeometry();
    geometry.setAttribute("position", new BufferAttribute(land.positions, 3));
    geometry.setAttribute("aScale", new BufferAttribute(land.scales, 1));
    geometry.setAttribute("aSeed", new BufferAttribute(land.seeds, 1));
    geometry.setAttribute("aMonogram", new BufferAttribute(land.monogram, 3));
    geometry.setAttribute("aDrift", new BufferAttribute(land.drifts, 3));

    const material = new ShaderMaterial({
      vertexShader: dotsVertex,
      fragmentShader: dotsFragment,
      transparent: true,
      depthWrite: false,
      // Normal, not additive: additive can only brighten what's behind it, so
      // the moment these dots leave the dark globe for the white page they
      // would disappear entirely.
      blending: NormalBlending,
      uniforms: {
        uTime: { value: 0 },
        uExplode: { value: 0 },
        uReform: { value: 0 },
        uCloudRadius: { value: CLOUD_RADIUS },
        uSolid: { value: 1 },
        uSize: { value: 3.5 },
        uPixelRatio: { value: 1 },
        uOpacity: { value: 1 },
        uColorDeep: { value: DEEP },
        uColorBright: { value: BRIGHT },
        uColorMark: { value: MARK },
      },
    });

    return new Points(geometry, material);
  }, [land]);

  // ---- city markers --------------------------------------------------------
  const markers = useMemo(() => {
    const positions = new Float32Array(globeCities.length * 3);
    const seeds = new Float32Array(globeCities.length);

    globeCities.forEach((city, i) => {
      const v = latLonToVec3(city.lat, city.lon, MARKER_RADIUS);
      positions[i * 3] = v.x;
      positions[i * 3 + 1] = v.y;
      positions[i * 3 + 2] = v.z;
      seeds[i] = i / globeCities.length;
    });

    const geometry = new BufferGeometry();
    geometry.setAttribute("position", new BufferAttribute(positions, 3));
    geometry.setAttribute("aSeed", new BufferAttribute(seeds, 1));

    const material = new ShaderMaterial({
      vertexShader: markerVertex,
      fragmentShader: markerFragment,
      transparent: true,
      depthWrite: false,
      blending: AdditiveBlending,
      uniforms: {
        uTime: { value: 0 },
        uSize: { value: 26 },
        uPixelRatio: { value: 1 },
        uOpacity: { value: 1 },
        uColor: { value: MARKER },
      },
    });

    return new Points(geometry, material);
  }, []);

  // ---- connection arcs -----------------------------------------------------
  const arcs = useMemo(() => {
    return globeRoutes.map(([a, b], i) => {
      const from = latLonToVec3(
        globeCities[a].lat,
        globeCities[a].lon,
        ARC_RADIUS,
      );
      const to = latLonToVec3(
        globeCities[b].lat,
        globeCities[b].lon,
        ARC_RADIUS,
      );
      const curve = arcBetween(from, to, ARC_RADIUS);

      const geometry = new TubeGeometry(curve, 64, 0.0035, 6, false);
      const material = new ShaderMaterial({
        vertexShader: arcVertex,
        fragmentShader: arcFragment,
        transparent: true,
        depthWrite: false,
        blending: AdditiveBlending,
        uniforms: {
          uTime: { value: 0 },
          uSpeed: { value: 0.22 + (i % 4) * 0.05 },
          uOffset: { value: (i * 0.37) % 1 },
          uOpacity: { value: 1 },
          uColor: { value: ARC },
        },
      });

      return { geometry, material };
    });
  }, []);

  // ---- opaque body ---------------------------------------------------------
  // Writes depth, so dots on the far hemisphere are genuinely occluded rather
  // than merely faded by the dot shader's facing term.
  const bodyMaterial = useMemo(
    () =>
      new ShaderMaterial({
        vertexShader: bodyVertex,
        fragmentShader: bodyFragment,
        side: FrontSide,
        transparent: true,
        depthWrite: true,
        uniforms: {
          uLitColor: { value: BODY_LIT },
          uShadeColor: { value: BODY_SHADE },
          uLimbColor: { value: BODY_LIMB },
          uLightDir: { value: LIGHT_DIR },
          uFadeColor: { value: BODY_FADE },
          uProgress: { value: 0 },
          uOpacity: { value: 1 },
        },
      }),
    [],
  );

  // ---- atmosphere ----------------------------------------------------------
  const atmosphereMaterial = useMemo(
    () =>
      new ShaderMaterial({
        vertexShader: atmosphereVertex,
        fragmentShader: atmosphereFragment,
        transparent: true,
        depthWrite: false,
        side: BackSide,
        blending: AdditiveBlending,
        // Tighter and fainter than the old blue rim. The canvas composites over
        // the cream page rather than over black, so an additive glow does not
        // brighten anything — it lays amber on top, and a wide, strong one
        // reads as a painted ring around the globe rather than as air.
        uniforms: {
          uColor: { value: ATMO },
          uPower: { value: 5.2 },
          uIntensity: { value: 0.4 },
        },
      }),
    [],
  );

  // Dispose every GPU resource this component allocated. R3F only auto-disposes
  // objects it created from JSX, not ones built imperatively in useMemo.
  useEffect(() => {
    return () => {
      dots?.geometry.dispose();
      (dots?.material as ShaderMaterial | undefined)?.dispose();
      markers.geometry.dispose();
      (markers.material as ShaderMaterial).dispose();
      arcs.forEach(({ geometry, material }) => {
        geometry.dispose();
        material.dispose();
      });
      atmosphereMaterial.dispose();
      bodyMaterial.dispose();
    };
  }, [dots, markers, arcs, atmosphereMaterial, bodyMaterial]);

  // Under reduced motion the canvas is frameloop="demand": ask for exactly one
  // redraw once the dot cloud is ready. Invalidating from inside useFrame would
  // schedule the next frame from within the current one — an endless loop, and
  // precisely the continuous animation this mode exists to avoid.
  useEffect(() => {
    if (reducedMotion && dots) invalidate();
  }, [reducedMotion, dots, invalidate]);

  // Pointer parallax tracked on the window: R3F pointer events don't fire
  // reliably over Points clouds or a back-faced sphere.
  useEffect(() => {
    if (reducedMotion) return;
    const onMove = (event: PointerEvent) => {
      pointerRef.current = {
        x: (event.clientX / window.innerWidth) * 2 - 1,
        y: (event.clientY / window.innerHeight) * 2 - 1,
      };
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => window.removeEventListener("pointermove", onMove);
  }, [reducedMotion]);

  useFrame((state, delta) => {
    const group = groupRef.current;
    if (!group) return;

    const dpr = state.gl.getPixelRatio();
    const time = state.clock.elapsedTime;

    // One damped read of the scroll store per frame — no React re-render.
    const target = reducedMotion ? 0 : getScroll().heroProgress;
    progressRef.current = MathUtils.damp(
      progressRef.current,
      target,
      3.6,
      Math.min(delta, 0.1),
    );
    const progress = progressRef.current;

    // Three acts across the pinned hero. Ranges overlap slightly so the cloud is
    // already scattering before it starts being pulled into the mark. The mark
    // is complete by 0.72 and holds until 0.9 — the payoff needs to sit still
    // for a moment, so trim scroll distance from the transitions, not from this.
    const explode = smoothstep(0.12, 0.44, progress);
    const reform = smoothstep(0.38, 0.74, progress);
    const disperse = smoothstep(0.9, 1.0, progress);
    // The globe's own surfaces belong to act 1 only. Its fade leads the scatter
    // so the solid body is already going before any dot moves through it.
    const globeFade = 1 - smoothstep(0.06, 0.3, progress);

    if (!reducedMotion) {
      // Idle drift, slowing to a stop as the mark assembles — a rotating "A"
      // would be unreadable.
      spinRef.current += delta * 0.045 * (1 + explode * 3.0) * (1 - reform);

      // Mouse parallax. Deliberately pronounced: the globe should feel like it
      // is being steered, so the pointer adds real yaw and pitch on top of the
      // idle spin, plus a little translation for depth. Damping is fast enough
      // to feel responsive but still absorbs jitter.
      const { x, y } = pointerRef.current;
      const step = Math.min(delta, 0.1);

      pointerYawRef.current = MathUtils.damp(
        pointerYawRef.current,
        x * POINTER_YAW,
        6,
        step,
      );
      // Everything unwinds toward zero as the mark forms, so it settles
      // square to the camera.
      const upright = 1 - reform;
      group.rotation.y = (spinRef.current + pointerYawRef.current) * upright;

      group.rotation.x = MathUtils.damp(
        group.rotation.x,
        (-0.18 + y * POINTER_PITCH) * upright,
        6,
        step,
      );
      group.position.x = MathUtils.damp(
        group.position.x,
        x * 0.13 * upright,
        6,
        step,
      );
      group.position.y = MathUtils.damp(
        group.position.y,
        -y * 0.07 * upright,
        6,
        step,
      );

      // Back off to frame the scattered cloud, then in again for the mark.
      camera.position.z = MathUtils.damp(
        camera.position.z,
        CAMERA_Z +
          Math.sqrt(explode) * EXPLODE_PULLBACK -
          reform * REFORM_PUSHIN,
        3.6,
        Math.min(delta, 0.1),
      );
      camera.updateProjectionMatrix();
    } else {
      group.rotation.y = INITIAL_SPIN;
      group.rotation.x = -0.18;
    }

    if (dots) {
      const u = (dots.material as ShaderMaterial).uniforms;
      u.uTime.value = time;
      u.uExplode.value = explode;
      u.uReform.value = reform;
      u.uSolid.value = globeFade;
      u.uPixelRatio.value = dpr;
      u.uOpacity.value = 1 - disperse;
    }

    // The solid body, its glow, the arcs and the city markers all belong to the
    // intact globe — they clear out as soon as it starts breaking apart.
    bodyMaterial.uniforms.uProgress.value = 1 - globeFade;
    bodyMaterial.uniforms.uOpacity.value = globeFade;
    // A transparent mesh still writes depth, and this one is a sphere of radius
    // 0.992 sitting right where the scattering dots pass through — so it would
    // silently swallow a good half of the cloud. Depth-occlusion is only wanted
    // while the body is solid enough to actually hide the far hemisphere.
    bodyMaterial.depthWrite = globeFade > 0.85;
    if (bodyRef.current) bodyRef.current.visible = globeFade > 0.02;

    const markerUniforms = (markers.material as ShaderMaterial).uniforms;
    markerUniforms.uTime.value = time;
    markerUniforms.uPixelRatio.value = dpr;
    markerUniforms.uOpacity.value = globeFade;

    arcs.forEach(({ material }) => {
      material.uniforms.uTime.value = time;
      material.uniforms.uOpacity.value = globeFade;
    });

    atmosphereMaterial.uniforms.uIntensity.value = 0.4 * globeFade;

    // Only hand over from the poster once there is a real globe to show.
    if (dots && !announcedRef.current) {
      announcedRef.current = true;
      onFirstFrame?.();
    }
  });

  return (
    <group ref={groupRef} rotation={[-0.18, INITIAL_SPIN, 0]}>
      <mesh ref={bodyRef} material={bodyMaterial} renderOrder={-1}>
        <sphereGeometry args={[BODY_RADIUS, 64, 64]} />
      </mesh>

      {dots && <primitive object={dots} />}
      <primitive object={markers} />

      {arcs.map(({ geometry, material }, i) => (
        <mesh key={i} geometry={geometry} material={material} />
      ))}

      <mesh material={atmosphereMaterial}>
        <sphereGeometry args={[ATMOSPHERE_RADIUS, 48, 48]} />
      </mesh>
    </group>
  );
}
