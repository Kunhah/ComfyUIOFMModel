"use client";

import { useEffect, useRef, useState } from "react";
import { Canvas } from "@react-three/fiber";
import { GlobeScene, CAMERA_Z } from "@/components/globe/globe-scene";
import { useMediaQuery } from "@/hooks/use-media-query";

function supportsWebGL() {
  try {
    const canvas = document.createElement("canvas");
    return Boolean(
      canvas.getContext("webgl2") ??
        canvas.getContext("webgl") ??
        canvas.getContext("experimental-webgl"),
    );
  } catch {
    return false;
  }
}

/**
 * Owns the WebGL surface. Renders nothing — leaving the static poster visible —
 * when WebGL is unavailable, and parks `frameloop` at "never" whenever the hero
 * is off screen, so the globe costs zero GPU time further down the page.
 *
 * This module is only ever imported with `ssr: false`, so probing the browser
 * during render (rather than from an effect) is safe.
 */
export function GlobeCanvas({ onReady }: { onReady?: () => void }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [webgl] = useState(supportsWebGL);
  const [inView, setInView] = useState(true);

  const reducedMotion = useMediaQuery("(prefers-reduced-motion: reduce)");
  const isSmall = useMediaQuery("(max-width: 768px)");
  // The land cloud holds ~48k points; desktop uses most of them, small
  // screens take an even stride through the same file.
  const pointBudget = isSmall ? 12_000 : 44_000;

  useEffect(() => {
    const node = containerRef.current;
    if (!node || !webgl) return;

    const observer = new IntersectionObserver(
      ([entry]) => setInView(entry.isIntersecting),
      { rootMargin: "120px" },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, [webgl]);

  return (
    <div ref={containerRef} className="absolute inset-0">
      {webgl && (
        <Canvas
          // Reduced motion renders on demand; otherwise pause when out of view.
          frameloop={reducedMotion ? "demand" : inView ? "always" : "never"}
          dpr={[1, 2]}
          gl={{
            antialias: false,
            alpha: true,
            powerPreference: "high-performance",
          }}
          camera={{ fov: 35, position: [0, 0, CAMERA_Z], near: 0.1, far: 100 }}
          style={{ pointerEvents: "none" }}
        >
          <GlobeScene
            pointBudget={pointBudget}
            reducedMotion={reducedMotion}
            onFirstFrame={onReady}
          />
        </Canvas>
      )}
    </div>
  );
}
