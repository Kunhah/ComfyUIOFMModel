"use client";

import dynamic from "next/dynamic";
import { useEffect, useState } from "react";
import { GlobePoster } from "@/components/globe/globe-poster";

// ssr:false must be declared inside a Client Component in Next 16. The poster
// renders immediately underneath, so the hero never waits on Three.js.
const GlobeCanvas = dynamic(
  () => import("@/components/globe/globe-canvas").then((m) => m.GlobeCanvas),
  { ssr: false },
);

/**
 * Seam between the hero layout and the globe. The static poster paints first
 * and cross-fades out once WebGL has a frame on screen — so there's no flash of
 * empty space, and no two spheres stacked on top of each other. If WebGL is
 * unavailable the canvas never reports ready and the poster simply stays.
 */
export function GlobeStage() {
  const [webglReady, setWebglReady] = useState(false);
  const [mountCanvas, setMountCanvas] = useState(false);

  // Hold the canvas back until after `load`, then until the main thread is idle.
  // Parsing Three.js costs ~2s of CPU on a throttled device; letting that run
  // before first paint pushes LCP out by the same amount, because the hero's
  // headline can't paint while the main thread is busy. Idle alone isn't enough
  // — the browser reports idle gaps well before LCP settles. The poster is
  // already on screen throughout, so nothing looks unfinished while we wait.
  useEffect(() => {
    let idleHandle: number | undefined;
    let timerHandle: number | undefined;

    const schedule = () => {
      if (typeof window.requestIdleCallback === "function") {
        idleHandle = window.requestIdleCallback(() => setMountCanvas(true), {
          timeout: 2000,
        });
      } else {
        timerHandle = window.setTimeout(() => setMountCanvas(true), 300);
      }
    };

    if (document.readyState === "complete") {
      schedule();
    } else {
      window.addEventListener("load", schedule, { once: true });
    }

    return () => {
      window.removeEventListener("load", schedule);
      if (idleHandle !== undefined) window.cancelIdleCallback?.(idleHandle);
      if (timerHandle !== undefined) window.clearTimeout(timerHandle);
    };
  }, []);

  return (
    <div className="absolute inset-0">
      <GlobePoster
        className={`transition-opacity duration-700 ease-out-soft ${
          webglReady ? "opacity-0" : "opacity-100"
        }`}
      />
      {mountCanvas && <GlobeCanvas onReady={() => setWebglReady(true)} />}
    </div>
  );
}
