import { cn } from "@/lib/utils";

/**
 * Static stand-in for the WebGL globe. Rendered on the server as the hero's
 * first paint, and kept as the permanent fallback for no-WebGL and
 * prefers-reduced-motion users once the canvas lands in Phase 5.
 */
export function GlobePoster({ className }: { className?: string }) {
  return (
    <div className={cn("absolute inset-0", className)} aria-hidden>
      {/* Outer atmosphere bloom. */}
      <div className="absolute inset-[4%] rounded-full bg-[radial-gradient(circle,rgb(243_163_58/0.45),rgb(217_132_19/0.16)_52%,transparent_70%)] blur-2xl" />

      {/* Sphere body. */}
      <div className="absolute inset-[12%] overflow-hidden rounded-full bg-[radial-gradient(circle_at_34%_28%,#453b30,#2a2620_42%,#17161a_66%,#0b0e12_86%)] shadow-[inset_0_-24px_60px_rgb(6_8_10/0.8),0_0_90px_-8px_rgb(243_163_58/0.55)]">
        {/* Dot matrix, faded toward the limb so it reads as curvature. */}
        <div className="absolute inset-0 bg-[radial-gradient(circle,rgb(255_212_150/0.9)_1.1px,transparent_1.1px)] [mask-image:radial-gradient(circle_at_38%_32%,black_22%,rgb(0_0_0/0.5)_56%,transparent_78%)] bg-[length:9px_9px]" />
        {/* Specular highlight. */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_22%,rgb(255_240_220/0.28),transparent_45%)]" />
      </div>

      {/* Rim light along the limb. */}
      <div className="ring-brand-400/45 absolute inset-[12%] rounded-full ring-1 ring-inset" />
    </div>
  );
}
