import Link from "next/link";
import { cn } from "@/lib/utils";

/** The Mandra brand mark. The source artwork lives at public/mandra.svg. */
export function LogoMark({ className }: { className?: string }) {
  return (
    <img
      src="/mandra.svg"
      alt=""
      aria-hidden
      className={cn("size-7 object-contain", className)}
    />
  );
}

export function Logo({
  className,
  href = "/",
}: {
  className?: string;
  href?: string;
}) {
  return (
    <Link
      href={href}
      aria-label="Mandra — página inicial"
      className={cn(
        "group text-fg inline-flex items-center gap-2 transition-opacity hover:opacity-80",
        className,
      )}
    >
      <LogoMark />
      <span className="text-[15px] font-semibold tracking-[-0.01em]">
        MANDRA
      </span>
    </Link>
  );
}
