import {
  siBehance,
  siInstagram,
  siYoutube,
  siGithub,
  siWhatsapp,
} from "simple-icons";
import { cn } from "@/lib/utils";

/** Renders a 24×24 single-path brand mark in `currentColor`. */
export function BrandIcon({
  path,
  title,
  className,
}: {
  path: string;
  title?: string;
  className?: string;
}) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      role={title ? "img" : undefined}
      aria-label={title}
      aria-hidden={title ? undefined : true}
      className={cn("size-4", className)}
    >
      <path d={path} />
    </svg>
  );
}

// LinkedIn was dropped from simple-icons over trademark policy — supplied here.
const linkedinPath =
  "M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.225 0z";

export const brandPaths: Record<string, string> = {
  linkedin: linkedinPath,
  behance: siBehance.path,
  instagram: siInstagram.path,
  youtube: siYoutube.path,
  github: siGithub.path,
  whatsapp: siWhatsapp.path,
};
