import { cn } from "@/lib/utils";

/** The uppercase amber kicker above every section title. */
export function Eyebrow({
  className,
  ...props
}: React.ComponentPropsWithoutRef<"p">) {
  return (
    <p
      className={cn(
        "text-brand-600 text-[11px] font-semibold tracking-[0.14em] uppercase",
        "[[data-tone=dark]_&]:text-brand-400 [[data-tone=brand]_&]:text-ink-950",
        className,
      )}
      {...props}
    />
  );
}

type SectionHeadingProps = {
  eyebrow?: string;
  title: React.ReactNode;
  description?: React.ReactNode;
  /** Right-hand slot for the "Ver todos os serviços →" link. */
  action?: React.ReactNode;
  align?: "left" | "center";
  className?: string;
  as?: "h2" | "h3";
};

export function SectionHeading({
  eyebrow,
  title,
  description,
  action,
  align = "left",
  className,
  as: Tag = "h2",
}: SectionHeadingProps) {
  return (
    <div
      className={cn(
        "flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between",
        align === "center" && "sm:flex-col sm:items-center",
        className,
      )}
    >
      <div className={cn("max-w-2xl", align === "center" && "text-center")}>
        {eyebrow && <Eyebrow className="mb-3">{eyebrow}</Eyebrow>}
        <Tag className="text-3xl leading-[1.15] font-bold sm:text-[40px]">
          {title}
        </Tag>
        {description && (
          <p className="text-fg-muted mt-4 text-[15px] leading-relaxed">
            {description}
          </p>
        )}
      </div>
      {action && <div className="shrink-0 pb-1">{action}</div>}
    </div>
  );
}
