import { cn } from "@/lib/utils";

/** Tech pill ("Next.js", "Stripe", ...) shown on the case-study cards. */
export function Badge({
  className,
  ...props
}: React.ComponentPropsWithoutRef<"span">) {
  return (
    <span
      className={cn(
        "border-line bg-fg/[0.03] text-fg-muted inline-flex items-center rounded-md border px-2 py-0.5 text-[11px] font-medium",
        "[[data-tone=dark]_&]:bg-white/5",
        className,
      )}
      {...props}
    />
  );
}

/** Small uppercase category label above a card title. */
export function CategoryLabel({
  className,
  ...props
}: React.ComponentPropsWithoutRef<"span">) {
  return (
    <span
      className={cn(
        "text-brand-600 text-[10px] font-semibold tracking-[0.12em] uppercase",
        "[[data-tone=dark]_&]:text-brand-400 [[data-tone=brand]_&]:text-ink-950/75",
        className,
      )}
      {...props}
    />
  );
}
