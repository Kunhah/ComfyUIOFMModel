import { cn } from "@/lib/utils";

type CardProps = React.ComponentPropsWithoutRef<"div"> & {
  /** Adds the lift-on-hover treatment used by the services and case cards. */
  interactive?: boolean;
};

export function Card({ className, interactive, ...props }: CardProps) {
  return (
    <div
      className={cn(
        "rounded-card border-line bg-surface-raised border",
        interactive &&
          "ease-out-soft hover:border-brand-300 hover:shadow-raised transition-[transform,border-color,box-shadow] duration-300 hover:-translate-y-1",
        className,
      )}
      {...props}
    />
  );
}

/** Square icon tile that heads each services / stats card. */
export function IconTile({
  className,
  ...props
}: React.ComponentPropsWithoutRef<"div">) {
  return (
    <div
      className={cn(
        "bg-brand-50 text-brand-600 flex size-10 shrink-0 items-center justify-center rounded-[10px]",
        "[[data-tone=dark]_&]:bg-brand-400/12 [[data-tone=dark]_&]:text-brand-400",
        className,
      )}
      {...props}
    />
  );
}
