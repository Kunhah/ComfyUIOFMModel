import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "secondary" | "ghost" | "inverse";
type Size = "sm" | "md" | "lg";

const base =
  "group inline-flex items-center justify-center gap-2 rounded-control font-medium whitespace-nowrap " +
  "transition-[transform,background-color,border-color,box-shadow,color] duration-200 ease-out-soft " +
  "disabled:pointer-events-none disabled:opacity-50 active:translate-y-px";

const variants: Record<Variant, string> = {
  // Amber field, charcoal label — the mascot's own pairing, and the one that
  // survives both the cream bands and the charcoal ones without a per-tone
  // override. Amber under white text is 2.3:1; it was never available here.
  primary:
    "bg-brand-400 text-ink-950 shadow-glow hover:bg-brand-300 hover:shadow-[0_10px_28px_-6px_rgb(243_163_58/0.6)]",
  secondary:
    "border border-line-strong bg-surface-raised text-fg hover:border-brand-400 hover:text-brand-600",
  ghost: "text-fg-muted hover:bg-fg/5 hover:text-fg",
  // For use on the amber band, where an amber button would disappear.
  inverse: "bg-ink-950 text-white hover:bg-ink-800",
};

const sizes: Record<Size, string> = {
  sm: "h-9 px-4 text-sm",
  md: "h-11 px-5 text-[15px]",
  lg: "h-12 px-6 text-base",
};

type ButtonOwnProps = {
  variant?: Variant;
  size?: Size;
  /** Appends the reference's trailing arrow, which nudges right on hover. */
  withArrow?: boolean;
  className?: string;
  children?: React.ReactNode;
};

const arrow = (
  <ArrowRight
    aria-hidden
    className="ease-out-soft size-4 shrink-0 transition-transform duration-200 group-hover:translate-x-0.5"
  />
);

export function Button({
  variant = "primary",
  size = "md",
  withArrow,
  className,
  children,
  ...props
}: ButtonOwnProps & React.ComponentPropsWithoutRef<"button">) {
  return (
    <button
      className={cn(base, variants[variant], sizes[size], className)}
      {...props}
    >
      {children}
      {withArrow && arrow}
    </button>
  );
}

export function ButtonLink({
  variant = "primary",
  size = "md",
  withArrow,
  className,
  children,
  ...props
}: ButtonOwnProps & React.ComponentPropsWithoutRef<typeof Link>) {
  return (
    <Link
      className={cn(base, variants[variant], sizes[size], className)}
      {...props}
    >
      {children}
      {withArrow && arrow}
    </Link>
  );
}

/** The understated "Saiba mais →" / "Ver projeto →" text link used on cards. */
export function ArrowLink({
  className,
  children,
  ...props
}: React.ComponentPropsWithoutRef<typeof Link>) {
  return (
    <Link
      className={cn(
        "group text-brand-600 hover:text-brand-700 inline-flex items-center gap-1.5 text-sm font-medium transition-colors",
        "[[data-tone=brand]_&]:text-ink-950 [[data-tone=brand]_&]:hover:text-ink-950/70",
        "[[data-tone=dark]_&]:text-brand-400 [[data-tone=dark]_&]:hover:text-brand-300",
        className,
      )}
      {...props}
    >
      {children}
      <ArrowRight
        aria-hidden
        className="ease-out-soft size-3.5 transition-transform duration-200 group-hover:translate-x-1"
      />
    </Link>
  );
}
