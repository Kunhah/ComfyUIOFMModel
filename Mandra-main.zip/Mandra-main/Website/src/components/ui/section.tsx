import { cn } from "@/lib/utils";

export type Tone = "light" | "muted" | "dark" | "night" | "brand";

type SectionProps = React.ComponentPropsWithoutRef<"section"> & {
  /**
   * Sets `data-tone`, which remaps the semantic colour vars (--fg, --surface,
   * --line, ...) for everything inside. Children never need `dark:` variants.
   */
  tone?: Tone;
  /** Vertical rhythm. `none` when the section manages its own padding. */
  spacing?: "none" | "sm" | "md" | "lg";
};

const spacings = {
  none: "",
  sm: "py-16 sm:py-20",
  md: "py-24 sm:py-32",
  lg: "py-32 sm:py-40 lg:py-48",
} as const;

export function Section({
  className,
  tone = "light",
  spacing = "md",
  ...props
}: SectionProps) {
  return (
    <section
      data-tone={tone}
      className={cn(
        "relative bg-surface text-fg",
        spacings[spacing],
        className,
      )}
      {...props}
    />
  );
}
