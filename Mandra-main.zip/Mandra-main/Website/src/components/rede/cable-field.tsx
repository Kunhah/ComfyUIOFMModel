"use client";

import dynamic from "next/dynamic";
import { useEffect, useState } from "react";
import { FieldPoster } from "@/components/rede/field-poster";

// ssr:false must be declared inside a Client Component in Next 16.
const CableCanvas = dynamic(
  () => import("@/components/rede/cable-canvas").then((m) => m.CableCanvas),
  { ssr: false },
);

/**
 * Seam between the hero layout and the bundle.
 *
 * The poster paints first and cross-fades out once WebGL has a frame, so the
 * headline never waits on Three.js and there is never a flash of empty night.
 * The canvas is held back until after `load` and then until the main thread is
 * idle: parsing Three costs about two seconds of CPU on a throttled phone, and
 * running that before first paint pushes LCP out by the same amount. If WebGL
 * is unavailable the canvas never reports ready and the poster simply stays.
 */
export function CableField({ className }: { className?: string }) {
  const [ready, setReady] = useState(false);
  const [mount, setMount] = useState(false);

  useEffect(() => {
    let idle: number | undefined;
    let timer: number | undefined;

    const schedule = () => {
      if (typeof window.requestIdleCallback === "function") {
        idle = window.requestIdleCallback(() => setMount(true), {
          timeout: 2000,
        });
      } else {
        timer = window.setTimeout(() => setMount(true), 300);
      }
    };

    if (document.readyState === "complete") schedule();
    else window.addEventListener("load", schedule, { once: true });

    return () => {
      window.removeEventListener("load", schedule);
      if (idle !== undefined) window.cancelIdleCallback?.(idle);
      if (timer !== undefined) window.clearTimeout(timer);
    };
  }, []);

  return (
    <div className={className}>
      <FieldPoster
        className={`ease-out-soft absolute inset-0 size-full transition-opacity duration-700 ${
          ready ? "opacity-0" : "opacity-100"
        }`}
      />
      {mount && <CableCanvas onReady={() => setReady(true)} />}
    </div>
  );
}
