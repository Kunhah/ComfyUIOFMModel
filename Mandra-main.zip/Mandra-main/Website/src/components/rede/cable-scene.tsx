"use client";

import { useMemo, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { cableVertex, cableFragment } from "@/components/rede/shaders/cable";
import {
  currentVertex,
  currentFragment,
} from "@/components/rede/shaders/current";
import { useMonogram } from "@/components/rede/lib/use-monogram";
import { heroProgress } from "@/components/rede/lib/hero-progress";

/** How many conductors the bundle holds. Fixed: it sizes the uniform array. */
export const CABLE_COUNT = 34;
export const CAMERA_Z = 7.4;
export const CAMERA_Z_SMALL = 9.4;

/** The five lines Mandra actually terminates, in the order the page names them. */
const SERVICE_LANES = 5;

type Cable = {
  /** Where the span comes in from, off the right of the frame. */
  from: THREE.Vector3;
  /** Where it lands: the terminal, which every cable shares to within a hair. */
  to: THREE.Vector3;
  sag: number;
  radius: number;
  /** Which of the five service lines this conductor belongs to, or -1. */
  lane: number;
  seed: number;
  /** 0 = cold grey-black sheath, 1 = warmer brown-black. */
  tint: number;
  /** A few spans are through-runs that never land here. */
  passing: boolean;
};

/**
 * The bundle's geometry.
 *
 * Cables enter from the right at spread-out heights and converge on a single
 * termination point at the lower left, so the field has a direction: every
 * conductor in the frame points at the button. The spread at the entry end and
 * the shared point at the landing end is the entire composition — sag is what
 * keeps them from reading as a fan of straight lines.
 */
function buildCables(
  count: number,
  halfW: number,
  halfH: number,
  anchor: { x: number; y: number },
): Cable[] {
  // A rough deterministic hash, so the field is identical between server and
  // client and between reloads. Math.random here would make the poster and the
  // canvas disagree on where the cables are.
  const rand = (n: number) => {
    const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
    return x - Math.floor(x);
  };

  // Everything is expressed against the visible half-extents rather than in
  // absolute units. A fixed spread put almost the whole bundle outside a phone
  // frame — the cables only appeared as a stub in one corner — because a narrow
  // viewport sees barely a quarter of the world a desktop one does.
  const spread = halfW * 1.55;

  // The termination is the DOM terminal block's own position, handed in as
  // normalized viewport coordinates. The bundle used to converge on a point in
  // empty night while the button sat somewhere else entirely, which broke the
  // one promise the first viewport is built on: the cables have to land IN the
  // primary action, not near it.
  const terminal = new THREE.Vector3(anchor.x * halfW, anchor.y * halfH, 0.7);
  const aspect = halfW / halfH;

  return Array.from({ length: count }, (_, i) => {
    const t = count === 1 ? 0.5 : i / (count - 1);
    const r1 = rand(i + 1);
    const r2 = rand(i + 41);
    const r3 = rand(i + 97);

    // The first cables in the list are the five service lines: they sit
    // foremost and thickest, because they are the ones the page can name.
    const isLane = i < SERVICE_LANES;
    const lane = isLane ? i : -1;

    // Entry heights fan across the upper two thirds of the frame; the service
    // lines are placed on an even pitch so they read as a deliberate set, and
    // the rest fill in around them.
    const vFan = Math.max(1, 1.55 / Math.max(aspect, 0.4));
    const y = isLane
      ? (2.55 - i * 0.62) * vFan
      : (-1.9 + t * 5.4 + (r1 - 0.5) * 0.55) * vFan;

    const z = isLane ? 0.55 + r2 * 0.3 : -0.7 - r2 * 3.4;

    // A handful of spans are through-runs: they cross the frame on their own
    // line and exit the far side without joining the bundle, so the picture
    // reads as a street with cable on it rather than a single tidy fan.
    const passing = !isLane && r3 > 0.82;

    return {
      passing,
      tint: r2,
      from: new THREE.Vector3(spread * (0.92 + r3 * 0.22), y, z),
      to: passing
        ? new THREE.Vector3(
            -spread * (0.95 + r1 * 0.3),
            y * 0.35 - 1.1 - r2 * 1.4,
            z,
          )
        : terminal
            .clone()
            .add(
              new THREE.Vector3(
                (r1 - 0.5) * 0.12,
                (r2 - 0.5) * 0.14,
                (r3 - 0.5) * 0.3,
              ),
            ),
      // Sag scales with how far the cable travels and with a little variance,
      // which is what separates the spans in the middle of the frame where
      // they would otherwise overlap into one mass.
      sag: 0.55 + r1 * 1.35 + (isLane ? 0.25 : 0),
      radius: isLane ? 0.115 : 0.03 + r2 * 0.03,
      lane,
      seed: r3,
    };
  });
}

/** Catenary, approximated by the parabola every suspended span is drawn as. */
function pointAt(cable: Cable, t: number, out: THREE.Vector3) {
  out.lerpVectors(cable.from, cable.to, t);
  out.y -= cable.sag * 4 * t * (1 - t);
  return out;
}

/**
 * Builds every cable into ONE geometry with a per-vertex cable index, so the
 * whole bundle is a single draw call. Tubes are generated by hand rather than
 * with TubeGeometry because the custom attributes have to be written in the
 * same pass, and because a shared parallel-transport frame would twist the
 * near-vertical landing runs.
 */
function buildGeometry(cables: Cable[], segments: number, radial: number) {
  const vertsPerCable = (segments + 1) * (radial + 1);
  const total = vertsPerCable * cables.length;

  const positions = new Float32Array(total * 3);
  const normals = new Float32Array(total * 3);
  const uvs = new Float32Array(total * 2);
  const aCable = new Float32Array(total);
  const aSeed = new Float32Array(total);
  const aTint = new Float32Array(total);
  const indices: number[] = [];

  const p = new THREE.Vector3();
  const pNext = new THREE.Vector3();
  const tangent = new THREE.Vector3();
  const normal = new THREE.Vector3();
  const binormal = new THREE.Vector3();
  // Cables hang in a vertical plane, so a fixed world up is a stable frame for
  // all of them — no Frenet twist, and the specular stripe stays on top.
  const up = new THREE.Vector3(0, 1, 0);

  let v = 0;
  cables.forEach((cable, ci) => {
    const base = ci * vertsPerCable;

    for (let s = 0; s <= segments; s++) {
      const t = s / segments;
      pointAt(cable, t, p);
      pointAt(cable, Math.min(1, t + 1e-3), pNext);
      tangent.subVectors(pNext, p).normalize();

      normal.crossVectors(tangent, up).normalize();
      if (normal.lengthSq() < 1e-6) normal.set(1, 0, 0);
      binormal.crossVectors(normal, tangent).normalize();

      for (let r = 0; r <= radial; r++) {
        const a = (r / radial) * Math.PI * 2;
        const cos = Math.cos(a);
        const sin = Math.sin(a);

        const nx = cos * normal.x + sin * binormal.x;
        const ny = cos * normal.y + sin * binormal.y;
        const nz = cos * normal.z + sin * binormal.z;

        positions[v * 3] = p.x + nx * cable.radius;
        positions[v * 3 + 1] = p.y + ny * cable.radius;
        positions[v * 3 + 2] = p.z + nz * cable.radius;
        normals[v * 3] = nx;
        normals[v * 3 + 1] = ny;
        normals[v * 3 + 2] = nz;
        uvs[v * 2] = t;
        uvs[v * 2 + 1] = r / radial;
        aCable[v] = ci;
        aSeed[v] = cable.seed;
        aTint[v] = cable.tint;
        v++;
      }
    }

    for (let s = 0; s < segments; s++) {
      for (let r = 0; r < radial; r++) {
        const a = base + s * (radial + 1) + r;
        const b = a + radial + 1;
        indices.push(a, b, a + 1, b, b + 1, a + 1);
      }
    }
  });

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute("normal", new THREE.BufferAttribute(normals, 3));
  geometry.setAttribute("uv", new THREE.BufferAttribute(uvs, 2));
  geometry.setAttribute("aCable", new THREE.BufferAttribute(aCable, 1));
  geometry.setAttribute("aSeed", new THREE.BufferAttribute(aSeed, 1));
  geometry.setAttribute("aTint", new THREE.BufferAttribute(aTint, 1));
  geometry.setIndex(indices);
  geometry.computeBoundingSphere();
  return geometry;
}

/**
 * Seeds one point per index onto a cable, spread along the conductors in
 * proportion to how much load each carries: the five named lines get most of
 * the current, the anonymous spans behind them a thinner share. This is where
 * the swarm is standing when the discharge begins, so it has to look like
 * current sitting on cable, not like a cloud that happens to be nearby.
 */
function seedOnCables(cables: Cable[], count: number) {
  const positions = new Float32Array(count * 3);
  const p = new THREE.Vector3();

  for (let i = 0; i < count; i++) {
    // Deterministic, like everything else in this scene.
    const a = Math.abs(Math.sin(i * 12.9898) * 43758.5453) % 1;
    const b = Math.abs(Math.sin(i * 78.233) * 24634.6345) % 1;

    // Bias toward the named lines: they are the ones under load.
    const laneBias = b < 0.62;
    const pool = laneBias
      ? Math.min(SERVICE_LANES, cables.length)
      : cables.length;
    const ci = laneBias
      ? Math.floor(a * pool) % pool
      : Math.floor(a * pool) % pool;

    const cable = cables[ci];
    // Denser toward the termination, matching where the shader puts the load.
    const t = Math.pow(b, 0.7);
    pointAt(cable, t, p);

    positions[i * 3] = p.x;
    positions[i * 3 + 1] = p.y;
    positions[i * 3 + 2] = p.z;
  }

  return positions;
}

export function CableScene({
  reducedMotion,
  quality,
  anchor,
  cameraZ,
  onFirstFrame,
}: {
  reducedMotion: boolean;
  quality: "high" | "low";
  /** Camera distance, so the haze range can be expressed relative to it. */
  cameraZ: number;
  /** Where the terminal block sits, in normalized viewport coords (-1..1). */
  anchor: { x: number; y: number };
  onFirstFrame?: () => void;
}) {
  const { viewport } = useThree();
  const materialRef = useRef<THREE.ShaderMaterial>(null);
  const currentMaterialRef = useRef<THREE.ShaderMaterial>(null);
  const groupRef = useRef<THREE.Group>(null);
  const reported = useRef(false);
  const pointer = useRef({ x: 0, y: 0 });

  const segments = quality === "high" ? 96 : 44;
  const radial = quality === "high" ? 8 : 5;
  const count = quality === "high" ? CABLE_COUNT : 16;
  const pointBudget = quality === "high" ? 24_000 : 7_000;

  const markHeight = quality === "high" ? 2.5 : 2.0;
  const mark = useMonogram(pointBudget, markHeight);

  const halfW = viewport.width / 2;
  const halfH = viewport.height / 2;

  const { geometry, cables } = useMemo(() => {
    const cables = buildCables(count, halfW, halfH, anchor);
    return { geometry: buildGeometry(cables, segments, radial), cables };
  }, [count, halfW, halfH, anchor, segments, radial]);

  // The discharge geometry only exists once the mark has loaded; until then
  // the hero is the bundle alone, which is a complete first viewport on its
  // own rather than a page waiting for an asset.
  const pointGeometry = useMemo(() => {
    if (!mark) return null;
    const g = new THREE.BufferGeometry();
    g.setAttribute(
      "position",
      new THREE.BufferAttribute(seedOnCables(cables, mark.count), 3),
    );
    g.setAttribute("aDrift", new THREE.BufferAttribute(mark.drifts, 3));
    g.setAttribute("aMonogram", new THREE.BufferAttribute(mark.monogram, 3));
    g.setAttribute("aScale", new THREE.BufferAttribute(mark.scales, 1));
    g.setAttribute("aSeed", new THREE.BufferAttribute(mark.seeds, 1));
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 12);
    return g;
  }, [mark, cables]);

  const markHalfWidth = useMemo(() => {
    if (!mark) return 1;
    let max = 0;
    for (let i = 0; i < mark.count; i++) {
      const x = Math.abs(mark.monogram[i * 3]);
      if (x > max) max = x;
    }
    return max || 1;
  }, [mark]);

  const currentUniforms = useMemo(
    () => ({
      uExplode: { value: 0 },
      uReform: { value: 0 },
      uTime: { value: 0 },
      uOpacity: { value: 0 },
      uSize: { value: 2.6 },
      uPixelRatio: { value: 1 },
      uMarkHalfWidth: { value: 1 },
      uHot: { value: new THREE.Color("#fff1d6") },
      uWarm: { value: new THREE.Color("#ffb354") }, // brand-300
      uDeep: { value: new THREE.Color("#d98413") }, // brand-500
    }),
    [],
  );

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uSway: { value: 0 },
      uFogNear: { value: 0 },
      uFogFar: { value: 0 },
      uSpeed: { value: 0.19 },
      uDischarge: { value: 0 },
      // Sized to CABLE_COUNT rather than to `count`: the array length is
      // compiled into the shader, so it must not change with quality.
      uEnergy: { value: new Array(CABLE_COUNT).fill(0) as number[] },
      uSteel: { value: new THREE.Color("#8595a8") },
      uSteelDark: { value: new THREE.Color("#111820") },
      uLive: { value: new THREE.Color("#f3a33a") },
      uFilament: { value: new THREE.Color("#ffd9a0") },
      uNight: { value: new THREE.Color("#06080b") },
    }),
    [],
  );

  // The switching sequence. On arrival the five service lines energize one
  // after another — the bundle coming up to load — and from then on they hold,
  // with the anonymous spans behind them cycling slowly so the field never
  // freezes into a still.
  const clock = useRef(0);

  useFrame((state, delta) => {
    const mat = materialRef.current;
    if (!mat) return;

    clock.current += Math.min(delta, 0.05);
    const t = clock.current;

    // The pin's scroll progress drives the whole sequence, so scrubbing back
    // up runs the discharge in reverse.
    const p = reducedMotion ? 0 : heroProgress.value;
    const explode = THREE.MathUtils.smoothstep(p, 0.26, 0.62);
    const reform = THREE.MathUtils.smoothstep(p, 0.54, 0.94);
    const discharge = Math.max(explode, reform);

    const cur = currentMaterialRef.current;
    if (cur) {
      cur.uniforms.uExplode.value = explode;
      cur.uniforms.uReform.value = reform;
      cur.uniforms.uTime.value = t;
      cur.uniforms.uPixelRatio.value = Math.min(state.viewport.dpr ?? 1, 2);
      cur.uniforms.uMarkHalfWidth.value = markHalfWidth;
      // The swarm is invisible while it is still riding the conductors.
      cur.uniforms.uOpacity.value = THREE.MathUtils.smoothstep(p, 0.16, 0.32);
    }

    mat.uniforms.uFogNear.value = -(cameraZ - 4);
    mat.uniforms.uFogFar.value = -(cameraZ + 12);
    mat.uniforms.uTime.value = reducedMotion ? 2.4 : t;
    mat.uniforms.uSway.value = reducedMotion ? 0 : t * 0.45;

    // The cables give up their load as the current leaves them.
    mat.uniforms.uDischarge.value = discharge;

    const energy = mat.uniforms.uEnergy.value as number[];
    for (let i = 0; i < cables.length; i++) {
      const cable = cables[i];
      let target: number;

      if (cable.lane >= 0) {
        // Staggered switch-on, then held: these are the named lines.
        target = reducedMotion ? 1 : t > 0.55 + cable.lane * 0.28 ? 1 : 0;
      } else {
        // Background spans breathe in and out of load on their own long cycle.
        const cycle = Math.sin(t * 0.22 + cable.seed * 12.9);
        target = reducedMotion ? 0 : cycle > 0.72 ? 1 : 0;
      }

      // Latch rather than fade: a contactor closes, it does not dissolve. The
      // asymmetry — fast to make, slow to break — is what a real one sounds
      // like, and it keeps the field from flickering.
      const rate = target > energy[i] ? 9 : 1.6;
      energy[i] += (target - energy[i]) * Math.min(1, delta * rate);
    }

    // A hand's width of parallax, damped. Enough to say the bundle has depth,
    // not enough to become a toy.
    if (groupRef.current && !reducedMotion) {
      const g = groupRef.current;
      g.rotation.y += (pointer.current.x * 0.045 - g.rotation.y) * 0.04;
      g.rotation.x += (pointer.current.y * 0.03 - g.rotation.x) * 0.04;
    }

    pointer.current.x = state.pointer.x;
    pointer.current.y = state.pointer.y;

    if (!reported.current) {
      reported.current = true;
      onFirstFrame?.();
    }
  });

  return (
    <group ref={groupRef}>
      <mesh geometry={geometry} frustumCulled={false}>
        <shaderMaterial
          ref={materialRef}
          vertexShader={cableVertex.replace(
            /CABLE_COUNT/g,
            String(CABLE_COUNT),
          )}
          fragmentShader={cableFragment}
          uniforms={uniforms}
        />
      </mesh>

      {pointGeometry && (
        <points geometry={pointGeometry} frustumCulled={false}>
          <shaderMaterial
            ref={currentMaterialRef}
            vertexShader={currentVertex}
            fragmentShader={currentFragment}
            uniforms={currentUniforms}
            transparent
            depthWrite={false}
          />
        </points>
      )}
    </group>
  );
}
