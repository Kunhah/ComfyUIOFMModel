"use client";

import { useEffect, useRef, useState } from "react";
import { Canvas } from "@react-three/fiber";
import {
  CableScene,
  CAMERA_Z,
  CAMERA_Z_SMALL,
} from "@/components/rede/cable-scene";
import { useMediaQuery } from "@/hooks/use-media-query";

function supportsWebGL() {
  try {
    const canvas = document.createElement("canvas");
    return Boolean(
      canvas.getContext("webgl2") ??
      canvas.getContext("webgl") ??
      canvas.getContext("experimental-webgl"),
    );
  } catch {
    return false;
  }
}

/**
 * Owns the WebGL surface for the bundle. Renders nothing — leaving the poster
 * as the final state — when WebGL is unavailable, and parks `frameloop` at
 * "never" once the hero leaves the screen, so the field costs no GPU time
 * while the visitor reads the rest of the page.
 *
 * Only ever imported with `ssr: false`, so probing the browser during render
 * rather than from an effect is safe.
 */
/**
 * Where the bundle converges, in normalized viewport coordinates (-1..1),
 * on the line the terminal block occupies at each breakpoint.
 *
 * Deliberately just PAST the edge: the strands converge as they pass behind
 * the block and leave the frame still running, so the bundle reads as
 * continuing off-screen rather than tapering to a point in open air.
 */
const ANCHOR = {
  desktop: { x: -1.22, y: -0.2 },
  small: { x: -1.05, y: -0.58 },
};

export function CableCanvas({ onReady }: { onReady?: () => void }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [webgl] = useState(supportsWebGL);
  const [inView, setInView] = useState(true);

  const reducedMotion = useMediaQuery("(prefers-reduced-motion: reduce)");
  const isSmall = useMediaQuery("(max-width: 768px)");

  useEffect(() => {
    const node = containerRef.current;
    if (!node || !webgl) return;
    const observer = new IntersectionObserver(
      ([entry]) => setInView(entry.isIntersecting),
      { rootMargin: "120px" },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, [webgl]);

  return (
    <div ref={containerRef} className="absolute inset-0">
      {webgl && (
        <Canvas
          frameloop={reducedMotion ? "demand" : inView ? "always" : "never"}
          // The sheath is a smooth gradient across a thin silhouette, so MSAA
          // earns its cost here in a way it did not on the globe's points.
          dpr={[1, 1.75]}
          gl={{
            antialias: true,
            alpha: false,
            powerPreference: "high-performance",
          }}
          camera={{
            fov: 42,
            // A phone frame sees so little of the world that the nearest cables
            // filled it edge to edge and read as out-of-focus bars. Standing
            // further back puts whole spans in frame, so they read as cable.
            position: [0, 0, isSmall ? CAMERA_Z_SMALL : CAMERA_Z],
            near: 0.1,
            far: 80,
          }}
          style={{ pointerEvents: "none" }}
        >
          <color attach="background" args={["#06080b"]} />
          <CableScene
            reducedMotion={reducedMotion}
            quality={isSmall ? "low" : "high"}
            anchor={isSmall ? ANCHOR.small : ANCHOR.desktop}
            cameraZ={isSmall ? CAMERA_Z_SMALL : CAMERA_Z}
            onFirstFrame={onReady}
          />
        </Canvas>
      )}
    </div>
  );
}
