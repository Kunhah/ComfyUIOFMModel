/**
 * The discharge: the current leaving the cables and becoming the mark.
 *
 * Three acts, all in the vertex stage, driven by the hero pin's scroll
 * progress rather than by a timer — scrubbing back up runs the whole sequence
 * in reverse, which a played-once animation cannot do.
 *
 *   1. carried  — the points sit on the conductors, invisible, riding the load
 *   2. discharge — they detach and scatter into a shell around the bundle
 *   3. reform   — they converge into the Mandra mark
 *
 * Each point's timing is offset by its own seed so the bundle does not
 * discharge in one flat pop and the mark does not snap into place; the swarm
 * arrives over a beat, the way a real one does.
 */

export const currentVertex = /* glsl */ `
  uniform float uExplode;
  uniform float uReform;
  uniform float uTime;
  uniform float uSize;
  uniform float uPixelRatio;

  attribute vec3 aDrift;
  attribute vec3 aMonogram;
  attribute float aScale;
  attribute float aSeed;

  varying float vReform;
  varying float vMonoX;
  varying float vHeat;

  // Smoothstep with a per-point offset, so the swarm staggers instead of
  // moving as one rigid body.
  float staggered(float p, float seed, float spread) {
    float t = clamp((p - seed * spread) / max(1.0 - spread, 0.001), 0.0, 1.0);
    return t * t * (3.0 - 2.0 * t);
  }

  void main() {
    float e = staggered(uExplode, aSeed, 0.28);
    float r = staggered(uReform, aSeed, 0.22);

    // While scattered the shell turns slowly, so the held moment between the
    // two acts is alive rather than frozen.
    vec3 drift = aDrift;
    float ang = uTime * 0.22 + aSeed * 6.2831853;
    drift.x += sin(ang) * 0.16;
    drift.y += cos(ang * 0.83) * 0.16;

    vec3 pos = mix(position, drift, e);
    pos = mix(pos, aMonogram, r);

    vReform = r;
    vMonoX = aMonogram.x;
    // Hottest mid-flight, cooling as it lands — the arc, not the terminal.
    vHeat = e * (1.0 - r);

    vec4 mv = modelViewMatrix * vec4(pos, 1.0);
    gl_Position = projectionMatrix * mv;

    float size = uSize * aScale * (0.5 + 0.5 * max(e, r));
    gl_PointSize = size * uPixelRatio * (12.0 / max(-mv.z, 0.001));
  }
`;

export const currentFragment = /* glsl */ `
  precision highp float;

  uniform float uOpacity;
  uniform vec3 uHot;
  uniform vec3 uWarm;
  uniform vec3 uDeep;
  uniform float uMarkHalfWidth;

  varying float vReform;
  varying float vMonoX;
  varying float vHeat;

  void main() {
    // Round point with a soft edge. Discarding outside the disc is cheaper
    // than blending a square down to nothing.
    vec2 c = gl_PointCoord - 0.5;
    float d = dot(c, c);
    if (d > 0.25) discard;
    float alpha = smoothstep(0.25, 0.015, d);

    // The formed mark carries the artwork's own left-to-right amber ramp, so
    // the swarm settles into the logo's gradient rather than a flat fill.
    float g = clamp(vMonoX / max(uMarkHalfWidth, 0.001) * 0.5 + 0.5, 0.0, 1.0);
    vec3 mark = mix(uWarm, uDeep, g);

    vec3 color = mix(mark, uHot, vHeat * 0.85);

    gl_FragColor = vec4(color, alpha * uOpacity);

    // THREE.Color parses a hex as sRGB and converts it to the LINEAR working
    // space, but a raw ShaderMaterial writes gl_FragColor straight out with no
    // encoding step — so authored brand values were being displayed as if the
    // linear numbers were already sRGB. #ffb354 landed as #ff7217: darker, and
    // rotated from hue 33 to hue 24, which is why the reassembled mark read
    // vermilion against an amber wordmark in the same frame. This chunk is the
    // encoding step the built-in materials get for free.
    #include <colorspace_fragment>
  }
`;
