/**
 * The conductor shader.
 *
 * Shaders live in .ts modules rather than .glsl files so no Turbopack loader
 * configuration is needed — the same call the globe makes.
 *
 * One material draws every cable in the field. Each vertex carries the index of
 * the cable it belongs to, and the per-cable state (how energized it is, and
 * when it was switched) is read from a small uniform array. Dynamic indexing of
 * a uniform array is legal in the vertex stage under GLSL ES 1.0, which is what
 * lets 26 independently-switched cables share a single draw call.
 *
 * Two things are deliberately NOT here:
 *
 * - There is no ambient amber. A cable is either de-energized steel or it is
 *   carrying current, and current is a travelling filament with a head and a
 *   tail, not a glow. A cable that glows without a pulse moving along it is
 *   decoration, and decoration is what this direction refuses.
 * - There is no bloom pass. The "glow" is the sheath's own specular highlight
 *   widening as the filament passes under it, which is what a lit cable
 *   actually looks like and costs one extra one pow.
 */

export const cableVertex = /* glsl */ `
  uniform float uEnergy[CABLE_COUNT];   // 0 = dead steel, 1 = carrying load
  uniform float uSway;
  uniform float uFogNear;
  uniform float uFogFar;

  attribute float aCable;
  attribute float aSeed;
  attribute float aTint;

  varying float vArc;      // 0 at the far end, 1 where the cable is terminated
  varying float vEnergy;
  varying float vSeed;
  varying float vFog;
  varying float vTint;
  varying vec3 vNormalV;

  void main() {
    // TubeGeometry's uv.x already runs the length of the tube, so the arc
    // parameter the current travels along comes for free.
    vArc = uv.x;
    vSeed = aSeed;
    vTint = aTint;
    vEnergy = uEnergy[int(aCable)];

    vec3 pos = position;

    // Wind. A suspended cable moves as a whole span, anchored at both ends, so
    // the displacement is a half-sine over the arc rather than a per-vertex
    // wobble — the give is greatest at mid-span and exactly zero at the poles.
    float span = sin(vArc * 3.14159265);
    float phase = uSway + aSeed * 6.2831853;
    pos.y += sin(phase) * 0.055 * span;
    pos.z += cos(phase * 0.77) * 0.045 * span;

    vec4 mv = modelViewMatrix * vec4(pos, 1.0);
    vNormalV = normalize(normalMatrix * normal);

    // Distance haze, so the cables behind the bundle read as further away
    // rather than as thinner copies of the ones in front. The range is handed
    // in relative to the camera: a fixed view-space range meant that standing
    // further back for a phone frame pushed the entire bundle into fog.
    vFog = smoothstep(uFogNear, uFogFar, mv.z);

    gl_Position = projectionMatrix * mv;
  }
`;

export const cableFragment = /* glsl */ `
  precision highp float;

  uniform float uTime;
  uniform vec3 uSteel;
  uniform vec3 uSteelDark;
  uniform vec3 uLive;
  uniform vec3 uFilament;
  uniform vec3 uNight;
  uniform float uSpeed;
  uniform float uDischarge;

  varying float vArc;
  varying float vEnergy;
  varying float vSeed;
  varying float vFog;
  varying float vTint;
  varying vec3 vNormalV;

  void main() {
    // --- the sheath -------------------------------------------------------
    // Polyethylene is nearly black and reads almost entirely by its highlight,
    // so the lambert term is deliberately weak and the specular term does the
    // describing. Key light sits up and to the left, matching the page.
    vec3 N = normalize(vNormalV);
    vec3 L = normalize(vec3(-0.45, 0.86, 0.25));
    float lambert = max(dot(N, L), 0.0);

    vec3 sheath = mix(uSteelDark, uSteel, lambert * lambert);

    // Not every conductor in a bundle is the same plastic. A per-cable tint
    // swings the sheath between a cold grey-black and a warmer brown-black,
    // which is what stops twenty-six identical tubes reading as one extruded
    // pattern.
    sheath *= mix(vec3(0.86, 0.92, 1.05), vec3(1.12, 0.98, 0.86), vTint);

    // Two speculars, not one. The tight stripe along the upper quarter is what
    // makes it read as round; the broad low sheen underneath is the rest of the
    // sky falling on a glossy surface, and without it the cable looks like a
    // matte bar with a line painted on it.
    float spec = pow(lambert, 26.0);
    float sheen = pow(lambert, 3.5);
    sheath += vec3(0.30, 0.34, 0.40) * sheen * 0.22;
    sheath += vec3(0.78, 0.84, 0.94) * spec * 0.85;

    // Extrusion grain: a faint ripple along the length, so the sheath has a
    // surface instead of being a perfect gradient.
    float grain = sin(vArc * 420.0 + vSeed * 30.0) * 0.5 + 0.5;
    sheath *= 0.97 + grain * 0.06;

    // --- the current ------------------------------------------------------
    // A comet travelling toward the termination: a tight head with a tail
    // stretched out behind it. fract() on the arc makes it loop; the seed
    // offsets each cable so the bundle never pulses in lockstep.
    float p = fract(vArc - uTime * uSpeed + vSeed * 0.37);
    float head = exp(-p * p * 900.0);
    float tail = exp(-p * 26.0) * 0.55;
    float travelling = clamp(head + tail, 0.0, 1.0);

    // Load builds toward the box: a cable carries more the closer it gets to
    // where it lands, which is what aims the whole field at the terminal.
    float toward = 0.25 + 0.75 * smoothstep(0.15, 1.0, vArc);

    vec3 color = sheath;
    float load = vEnergy * (1.0 - uDischarge);
    color += uLive * load * travelling * toward * (0.35 + lambert * 0.9);
    color += uFilament * load * head * toward * 0.9;

    // The highlight widens under the filament — the cable's own gloss picking
    // up the light it is carrying, rather than a bloom pass over the top.
    color += vec3(1.0) * load * head * spec * 0.6;

    // As the current leaves for the mark, the conductors fall back to unlit
    // steel and sink into the night — the bundle is still there, it is simply
    // no longer carrying anything.
    color = mix(color, uNight, vFog);
    color = mix(color, uNight, uDischarge * 0.88);

    gl_FragColor = vec4(color, 1.0);
  }
`;
