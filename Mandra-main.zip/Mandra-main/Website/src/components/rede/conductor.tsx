"use client";

import { cn } from "@/lib/utils";

/**
 * The head that travels a conductor under load.
 *
 * A tight bright tip with a long warm tail — the DOM counterpart of the hero
 * shader's filament, so a line lighting up under the cursor behaves like the
 * cables above it rather than like a colour change.
 *
 * Sized as a fraction of its rail and clipped by it, which is what lets one
 * keyframe drive rails of any length: the travel in `current-run` is expressed
 * relative to the head, not to the track.
 */
const HEAD =
  "bg-[linear-gradient(90deg,transparent,rgb(243_163_58/0.28)_62%,rgb(255_216_160)_96%,transparent)]";
const HEAD_DOWN =
  "bg-[linear-gradient(180deg,transparent,rgb(243_163_58/0.28)_62%,rgb(255_216_160)_96%,transparent)]";

/**
 * A conductor running through the page's own layout, with or without load.
 *
 * De-energized it is the sheath gradient and nothing else. Motion is confined
 * to the overlay, so the resting state is the visible default and reduced
 * motion simply stops the head without hiding the conductor.
 *
 * `delay` exists so a group of conductors can be staggered from the caller —
 * five lines all pulsing on the same frame read as one flashing block rather
 * than as five lines each carrying their own load.
 */
export function Conductor({
  live,
  axis = "x",
  duration = "2.4s",
  delay = "0s",
  className,
}: {
  live?: boolean;
  /** Direction of travel. `y` is a drop; the head's specular turns with it. */
  axis?: "x" | "y";
  duration?: string;
  delay?: string;
  className?: string;
}) {
  const vertical = axis === "y";

  return (
    <span
      aria-hidden
      className={cn(
        "conductor relative block overflow-hidden rounded-full",
        vertical ? "h-full w-[3px]" : "h-[3px] w-full",
        className,
      )}
    >
      <span
        className={cn(
          "absolute transition-opacity duration-300",
          vertical
            ? `inset-x-0 top-0 h-[45%] ${HEAD_DOWN}`
            : `inset-y-0 left-0 w-[45%] ${HEAD}`,
          live
            ? `opacity-100 ${vertical ? "current-drop" : "current-run"}`
            : "opacity-0",
        )}
        style={{
          ["--current-duration" as string]: duration,
          ["--current-delay" as string]: delay,
        }}
      />
    </span>
  );
}
