"use client";

import { useEffect, useState } from "react";

export type MarkCloud = {
  /** Position inside the Mandra mark. */
  monogram: Float32Array;
  /** Where the point sits while scattered, before it finds its place. */
  drifts: Float32Array;
  scales: Float32Array;
  seeds: Float32Array;
  count: number;
};

/**
 * mulberry32's mixing step: an integer hash giving several *independent*
 * uniforms per point, seeded only by the index — so the cloud is identical on
 * every load without Math.random.
 *
 * Worth the arithmetic over the usual fract(sin(seed)) trick: feeding one sine
 * into all three components of a direction gives each an arcsine distribution,
 * which piles values up near ±1 and clusters the scatter at the corners of a
 * cube instead of filling a ball.
 */
function hash(n: number) {
  let t = (n + 0x6d2b79f5) | 0;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}

/**
 * Loads the pre-computed Mandra mark and expands it into the attributes the
 * discharge needs.
 *
 * The file is Int16 x/y pairs at 1/1000 scale, written by
 * `npm run globe:monogram` from public/mandra.svg. Its extent is measured here
 * rather than assumed, so re-exporting the artwork at a different size cannot
 * silently change how large the mark forms on screen.
 *
 * `budget` caps the count; small screens pass fewer. Points are taken on an
 * even fractional stride across the whole file rather than from its head, so a
 * reduced cloud still covers the entire mark instead of half of it.
 */
export function useMonogram(budget: number, height: number): MarkCloud | null {
  const [cloud, setCloud] = useState<MarkCloud | null>(null);

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();

    fetch("/data/monogram-points.bin", { signal: controller.signal })
      .then((res) => {
        if (!res.ok) throw new Error(`monogram-points.bin: ${res.status}`);
        return res.arrayBuffer();
      })
      .then((buffer) => {
        if (cancelled) return;
        const raw = new Int16Array(buffer);
        const total = raw.length / 2;
        if (total === 0) throw new Error("monogram-points.bin is empty");

        // Measure the artwork rather than trusting the generator's scale.
        let minX = Infinity;
        let maxX = -Infinity;
        let minY = Infinity;
        let maxY = -Infinity;
        for (let i = 0; i < total; i++) {
          const x = raw[i * 2];
          const y = raw[i * 2 + 1];
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
          if (y < minY) minY = y;
          if (y > maxY) maxY = y;
        }
        const cx = (minX + maxX) / 2;
        const cy = (minY + maxY) / 2;
        const scale = height / Math.max(1, maxY - minY);

        const count = Math.min(total, budget);
        const step = total / count;

        const monogram = new Float32Array(count * 3);
        const drifts = new Float32Array(count * 3);
        const scales = new Float32Array(count);
        const seeds = new Float32Array(count);

        for (let i = 0; i < count; i++) {
          const src = Math.floor(i * step);
          const rand = hash(i * 4);

          monogram[i * 3] = (raw[src * 2] - cx) * scale;
          monogram[i * 3 + 1] = (raw[src * 2 + 1] - cy) * scale;
          // Sits in front of where the cables hang, so the formed mark is
          // never half-occluded by a strand that has not finished dimming.
          monogram[i * 3 + 2] = 1.25 + (rand - 0.5) * 0.12;

          scales[i] = 0.62 + rand * 0.8;
          seeds[i] = rand;

          // Area-uniform direction, radius cube-rooted and biased outward, so
          // the scatter reads as an even shell from any angle rather than as a
          // dense core with stragglers.
          const z = hash(i * 4 + 1) * 2 - 1;
          const ring = Math.sqrt(Math.max(0, 1 - z * z));
          const theta = hash(i * 4 + 2) * Math.PI * 2;
          const radius = 1.6 + 2.1 * Math.cbrt(hash(i * 4 + 3));

          drifts[i * 3] = Math.cos(theta) * ring * radius;
          drifts[i * 3 + 1] = Math.sin(theta) * ring * radius * 0.72;
          drifts[i * 3 + 2] = z * radius * 0.5 + 0.4;
        }

        setCloud({ monogram, drifts, scales, seeds, count });
      })
      .catch((error) => {
        if ((error as Error).name !== "AbortError") {
          console.error("Mandra mark point data failed to load", error);
        }
      });

    return () => {
      cancelled = true;
      controller.abort();
    };
  }, [budget, height]);

  return cloud;
}
