/**
 * The hero pin's scroll progress, as a plain mutable box.
 *
 * React context does not cross into the react-three-fiber reconciler, so the
 * scene cannot read the pin's MotionValue through a provider. Routing it
 * through a module-level box instead of state is also what keeps the sequence
 * cheap: the DOM tree writes on every scroll frame and the scene reads inside
 * useFrame, and neither side ever re-renders because of it.
 */
export const heroProgress = { value: 0 };
