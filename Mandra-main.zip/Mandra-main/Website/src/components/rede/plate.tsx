import { cn } from "@/lib/utils";

/**
 * The terminal plate — A Rede's one repeating unit.
 *
 * Every named thing on the page wears the same silkscreened aluminium plate
 * with the same three fields: the stamped code, what the terminal is, and what
 * it carries. The plate is what makes the system legible before any of the
 * content is read, and it is why the page needs no card grid: a plate is an
 * identification, not a container, so plates can sit on a conductor, in a
 *list, or across a band without any of them becoming a box of a box.
 */

/**
 * The bolt heads that hold a plate to its box. Four of them are what separates
 * a stamped plate from a rounded rectangle with a border, and they are the
 * cheapest honest material on the page.
 */
export function Bolts() {
  return (
    <span aria-hidden>
      {[
        "top-1.5 left-1.5",
        "top-1.5 right-1.5",
        "bottom-1.5 left-1.5",
        "bottom-1.5 right-1.5",
      ].map((pos) => (
        <span
          key={pos}
          className={`absolute ${pos} size-[3px] rounded-full bg-[var(--bolt-face)] shadow-[0_1px_0_var(--bolt-edge)]`}
        />
      ))}
    </span>
  );
}

export function PlateCode({
  children,
  live,
  className,
}: {
  children: React.ReactNode;
  live?: boolean;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "plate-id font-mono text-[11px] leading-none tracking-[0.18em] transition-colors duration-300",
        live ? "text-[var(--ink-accent)]" : "text-[var(--ink-id-dead)]",
        className,
      )}
    >
      {children}
    </span>
  );
}

/**
 * The latching indicator lamp. Two states and nothing between them: a
 * contactor is closed or it is open. The lit lamp gets a real offset shadow
 * and a lens highlight rather than a zero-offset halo, so it reads as a bulb
 * behind glass instead of a coloured dot.
 *
 * `load` adds the third thing a real panel lamp tells you, which is that the
 * terminal is not merely closed but working. It is deliberately a very shallow
 * breath on the glow alone: a lamp that throbs reads as an alarm, and every
 * lamp that wears this is reporting normal service. Stagger a bank of them
 * with `delay` — a row of lamps pulsing on one frame is a flashing block, not
 * six independent terminals.
 */
export function Lamp({
  live,
  load,
  duration = "3.6s",
  delay = "0s",
  className,
}: {
  live?: boolean;
  /** Breathe the glow, for a terminal that is carrying rather than just closed. */
  load?: boolean;
  duration?: string;
  delay?: string;
  className?: string;
}) {
  return (
    <span
      aria-hidden
      className={cn(
        "relative block size-2.5 shrink-0 rounded-full transition-all duration-200",
        live
          ? "bg-brand-400 shadow-[0_0_0_1px_rgb(243_163_58/0.35),0_1px_10px_1px_rgb(243_163_58/0.55)]"
          : "bg-dead-600 shadow-[inset_0_1px_1px_rgb(0_0_0/0.6)]",
        className,
      )}
    >
      <span
        className={cn(
          "absolute top-[2px] left-[2px] size-1 rounded-full transition-opacity",
          live ? "bg-white/70 opacity-100" : "opacity-0",
        )}
      />
      {/* The breath rides a second, purely additive glow rather than animating
          the lamp's own shadow — the lamp keeps its resting presence even at
          the bottom of the cycle, and nothing here can dim the lens. */}
      {live && load ? (
        <span
          style={{
            ["--current-duration" as string]: duration,
            ["--current-delay" as string]: delay,
          }}
          className="lamp-load absolute -inset-px rounded-full shadow-[0_0_10px_2px_rgb(243_163_58/0.55)]"
        />
      ) : null}
    </span>
  );
}

/** The stamped legend strip bolted under an instrument, holding one label. */
export function Legend({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "plate inline-flex items-center rounded-[3px] px-2.5 py-1 font-mono text-[10px] leading-none tracking-[0.2em] text-[var(--ink-id-dead)] uppercase",
        className,
      )}
    >
      {children}
    </span>
  );
}
