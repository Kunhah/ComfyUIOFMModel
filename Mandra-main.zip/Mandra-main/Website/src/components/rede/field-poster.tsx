/**
 * The still the field paints over.
 *
 * It is drawn from the same idea as the shader — spans fanning in from the
 * right and landing together at the lower left — so the canvas fading in on
 * top is a change of material, not a change of composition. It is also the
 * final state on a machine with no WebGL, which is why it is a real drawing
 * with a lit conductor in it rather than a grey placeholder.
 */
export function FieldPoster({ className }: { className?: string }) {
  const spans = Array.from({ length: 18 }, (_, i) => {
    const seed = Math.abs(Math.sin(i * 12.9898) * 43758.5453) % 1;
    const lane = i < 5;
    const y = lane ? 150 + i * 62 : 60 + seed * 560;
    const sag = lane ? 130 + i * 14 : 70 + seed * 190;
    return {
      d: `M 1480 ${y.toFixed(1)} Q 700 ${(y + sag * 2).toFixed(1)} 150 640`,
      lane,
      width: lane ? 3.2 : 1.1 + seed * 1.1,
      opacity: lane ? 1 : 0.3 + seed * 0.35,
    };
  });

  return (
    <svg
      aria-hidden
      viewBox="0 0 1440 760"
      preserveAspectRatio="xMidYMid slice"
      className={className}
    >
      <defs>
        <linearGradient id="rede-sheath" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#5f6c7c" />
          <stop offset="35%" stopColor="#333d4a" />
          <stop offset="100%" stopColor="#05070a" />
        </linearGradient>
      </defs>
      <rect width="1440" height="760" fill="#06080b" />
      {spans.map((s, i) => (
        <path
          key={i}
          d={s.d}
          fill="none"
          stroke="url(#rede-sheath)"
          strokeWidth={s.width}
          strokeLinecap="round"
          opacity={s.opacity}
        />
      ))}
      {/* One line under load, so the still already states the rule the whole
          page runs on: amber means current, and nothing else. */}
      <path
        d={spans[2].d}
        fill="none"
        stroke="#f3a33a"
        strokeWidth="3.4"
        strokeLinecap="round"
        strokeDasharray="26 340"
        opacity="0.95"
      />
    </svg>
  );
}
