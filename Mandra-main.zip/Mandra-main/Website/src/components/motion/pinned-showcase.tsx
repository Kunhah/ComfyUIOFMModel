"use client";

import {
  createContext,
  useContext,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  motion,
  useScroll,
  useTransform,
  useMotionValue,
  useMotionValueEvent,
  useSpring,
  type MotionValue,
} from "motion/react";
import { cn } from "@/lib/utils";

/**
 * A section that pins to the screen and steps through its items as you scroll,
 * each one transitioning into the next rather than simply appearing.
 *
 * The outer element is several viewports tall; the inner panel is sticky, so it
 * holds still while the page scrolls past. That scroll distance is divided
 * between the items.
 *
 * Three things here are load-bearing:
 *
 *  1. `overflow` other than visible on ANY ancestor silently kills sticky, so it
 *     lives on the sticky panel itself, never on the outer section.
 *
 *  2. Motion accelerates simple scroll→style maps onto a native ViewTimeline,
 *     which measures the element's own viewport crossing — meaningless for a
 *     pinned panel, and it desynchronises accelerated properties (opacity) from
 *     JS-driven ones (transform). `useDetachedProgress` keeps them together.
 *
 *  3. Un-pinning — for reduced motion, and below lg where a two-column showcase
 *     cannot fit a viewport — happens through CSS variants rather than by
 *     rendering a different tree. Branching structure on a client-only media
 *     query is a hydration mismatch, since the server cannot know the answer,
 *     and React throws away and re-renders the whole subtree when it finds one.
 */

type ShowcaseContext = {
  progress: MotionValue<number>;
  count: number;
  active: number;
};

const Showcase = createContext<ShowcaseContext | null>(null);

function useDetachedProgress(source: MotionValue<number>) {
  const detached = useMotionValue(source.get());
  useMotionValueEvent(source, "change", (v) => detached.set(v));
  return detached;
}

/**
 * Wheel scrolling arrives in coarse, uneven jumps. Springing the progress value
 * once here smooths every panel's crossfade and the index fill together, rather
 * than each mapping the raw steps independently.
 */
const PROGRESS_SPRING = {
  stiffness: 150,
  damping: 32,
  mass: 0.34,
  restDelta: 0.0005,
} as const;

export function PinnedShowcase({
  count,
  children,
  className,
  /** Viewports of scroll allotted to each item, on top of one for the panel. */
  screensPerItem = 0.65,
}: {
  count: number;
  children: ReactNode;
  className?: string;
  screensPerItem?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end end"],
  });
  const progress = useSpring(
    useDetachedProgress(scrollYProgress),
    PROGRESS_SPRING,
  );

  useMotionValueEvent(progress, "change", (v) => {
    // Panel i is centred at v * count === i, so the one on screen is simply the
    // nearest — round, not floor. The crossfade is symmetric about the halfway
    // point, so the label flips exactly as the two panels trade places.
    const next = Math.min(count - 1, Math.max(0, Math.round(v * count)));
    setActive((current) => (current === next ? current : next));
  });

  return (
    <Showcase.Provider value={{ progress, count, active }}>
      <div
        ref={ref}
        className={cn(
          "relative motion-reduce:!h-auto max-lg:!h-auto",
          className,
        )}
        style={{ height: `${(count * screensPerItem + 1) * 100}vh` }}
      >
        <div
          className={cn(
            "sticky top-0 flex h-screen items-center overflow-hidden",
            // Below lg there isn't a viewport's worth of room for a two-column
            // showcase, so it un-pins and the panels simply stack.
            "max-lg:relative max-lg:h-auto max-lg:py-20",
            "motion-reduce:relative motion-reduce:h-auto motion-reduce:py-24",
          )}
        >
          {children}
        </div>
      </div>
    </Showcase.Provider>
  );
}

function useShowcase() {
  const ctx = useContext(Showcase);
  if (!ctx)
    throw new Error("Showcase components must be inside PinnedShowcase");
  return ctx;
}

/** Which item is currently front-and-centre. */
export function useActiveItem() {
  return useShowcase().active;
}

/**
 * One panel in the stack. Panels are layered on top of each other and cross-fade
 * as scroll carries the sequence forward: the outgoing one lifts away and
 * shrinks slightly while the incoming one rises into its place.
 *
 * Under reduced motion they drop out of the stack into normal flow, so each is
 * simply readable one after another.
 */
export function ShowcasePanel({
  index,
  children,
  className,
}: {
  index: number;
  children: ReactNode;
  className?: string;
}) {
  const { progress, count } = useShowcase();

  // Distance from this panel's moment: 0 when centred, ±1 when a full step away.
  const distance = useTransform(progress, (v) => v * count - index);
  // Narrow, symmetric crossfade. A wider window leaves two panels legible on
  // top of each other through the whole handover, which reads as a mistake
  // rather than a transition.
  const opacity = useTransform(
    distance,
    [-0.55, -0.3, 0.3, 0.55],
    [0, 1, 1, 0],
  );
  const y = useTransform(distance, [-1, 0, 1], [70, 0, -70]);
  const scale = useTransform(distance, [-1, 0, 1], [0.94, 1, 0.94]);

  return (
    <motion.div
      className={cn(
        "absolute inset-0",
        "max-lg:!static max-lg:mb-10 max-lg:!transform-none max-lg:!opacity-100",
        "motion-reduce:!static motion-reduce:mb-16 motion-reduce:!transform-none motion-reduce:!opacity-100",
        className,
      )}
      style={{ opacity, y, scale }}
    >
      {children}
    </motion.div>
  );
}

/**
 * A row in the index beside the panels, marking how far through the sequence
 * the reader is. The active row's rule fills as its panel holds the stage.
 */
export function ShowcaseIndexItem({
  index,
  label,
  onSelect,
}: {
  index: number;
  label: string;
  onSelect?: () => void;
}) {
  const { progress, count, active } = useShowcase();
  const isActive = active === index;

  const fill = useTransform(progress, (v) =>
    Math.min(1, Math.max(0, v * count - index)),
  );

  return (
    <li>
      <button
        type="button"
        onClick={onSelect}
        aria-current={isActive}
        className={cn(
          "group flex w-full items-center gap-3 py-2.5 text-left transition-colors",
          isActive ? "text-fg" : "text-fg-subtle hover:text-fg-muted",
        )}
      >
        <span className="bg-line-strong relative h-px w-8 shrink-0 overflow-hidden">
          <motion.span
            className="bg-brand-400 absolute inset-y-0 left-0 block w-full origin-left motion-reduce:!transform-none"
            style={{ scaleX: fill }}
          />
        </span>
        <span
          className={cn(
            "text-[15px] font-medium transition-all",
            isActive && "translate-x-0.5 font-semibold",
          )}
        >
          {label}
        </span>
      </button>
    </li>
  );
}
