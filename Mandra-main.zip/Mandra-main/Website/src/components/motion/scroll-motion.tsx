"use client";

import {
  createContext,
  useContext,
  useRef,
  type CSSProperties,
  type ReactNode,
  type RefObject,
} from "react";
import {
  motion,
  useScroll,
  useTransform,
  useSpring,
  useMotionValue,
  type MotionValue,
} from "motion/react";
import { useMediaQuery } from "@/hooks/use-media-query";
import { cn } from "@/lib/utils";

/**
 * Scroll-driven motion primitives.
 *
 * Everything here is *continuously linked* to scroll position — elements keep
 * moving the whole time they cross the viewport, and scrubbing back up runs
 * them in reverse. That's the difference from a one-shot "fade in when visible"
 * animation, which plays once on a timer and then sits still.
 *
 * All of it collapses to a plain <div> under prefers-reduced-motion.
 */

/**
 * Applied to every animated element so reduced-motion users get the resting
 * state. Done in CSS rather than by rendering a different tree: branching
 * structure or inline styles on a client-only media query is a hydration
 * mismatch, and React discards and re-renders the whole subtree when it hits
 * one.
 */
const REST = "motion-reduce:!transform-none motion-reduce:!opacity-100";

/** Progress 0→1 while `ref` travels from entering to leaving the viewport. */
export function useCrossViewportProgress(ref: RefObject<HTMLElement | null>) {
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  return scrollYProgress;
}

/** Progress 0→1 as `ref` rises from the lower viewport into comfortable view. */
export function useEnterProgress(ref: RefObject<HTMLElement | null>) {
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start 0.92", "start 0.38"],
  });
  return scrollYProgress;
}

/**
 * Ref helper for the polymorphic components below. Declaring a single
 * RefObject<HTMLDivElement> breaks when `as="li"`, because motion's ref type
 * becomes an intersection of both elements; a callback ref assigns from either.
 */
function useElementRef() {
  const ref = useRef<HTMLElement | null>(null);
  const setRef = (node: HTMLElement | null) => {
    ref.current = node;
  };
  return [ref, setRef] as const;
}

/** Softens a raw scroll value so fast flicks don't snap. */
function useSmooth(value: MotionValue<number>) {
  return useSpring(value, { stiffness: 220, damping: 40, mass: 0.35 });
}

type ParallaxProps = {
  children: ReactNode;
  className?: string;
  /**
   * Pixels of travel across the full viewport pass. Positive drifts upward
   * (moves against the scroll, reading as "further away"); negative drifts
   * downward, reading as "closer".
   */
  distance?: number;
  as?: "div" | "li";
};

/**
 * Continuous vertical drift across the element's whole viewport traversal.
 * Give neighbouring elements different `distance` values to build depth — that
 * difference in rate is what the eye reads as parallax.
 */
export function Parallax({
  children,
  className,
  distance = 60,
  as = "div",
}: ParallaxProps) {
  const [ref, setRef] = useElementRef();
  const progress = useCrossViewportProgress(ref);
  const y = useSmooth(useTransform(progress, [0, 1], [distance, -distance]));

  const Component = motion[as];

  return (
    <Component
      ref={setRef}
      className={cn(REST, className)}
      style={{ y }}
    >
      {children}
    </Component>
  );
}

/**
 * Parallax bound to raw page scroll rather than to the element's viewport
 * traversal — correct for the hero, whose children start on screen and so have
 * no "entering" phase to key off.
 *
 * Mapped directly with no spring: this tracks the wheel exactly, which is the
 * point. Adding smoothing here would reintroduce the floaty, detached feel of a
 * scroll-hijacking library.
 */
export function HeroParallax({
  children,
  className,
  speed = 0.2,
  fadeOverPx,
}: {
  children: ReactNode;
  className?: string;
  /** Fraction of scroll distance to lag behind by. Higher = moves more. */
  speed?: number;
  /** Optional: fade to 0 across this many pixels of scroll. */
  fadeOverPx?: number;
}) {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, (v) => v * speed);
  const opacity = useTransform(
    scrollY,
    [0, fadeOverPx ?? 1],
    [1, fadeOverPx ? 0 : 1],
  );

  return (
    <motion.div className={cn(REST, className)} style={{ y, opacity }}>
      {children}
    </motion.div>
  );
}

type ScrollInProps = {
  children: ReactNode;
  className?: string;
  /** Starting offset in px; the element slides to 0 as it enters. */
  y?: number;
  /** Starting horizontal offset — use ±x for elements that belong to a side. */
  x?: number;
  /** Starting scale, animating to 1. */
  scale?: number;
  fade?: boolean;
  as?: "div" | "li";
};

/**
 * Scroll-linked entrance: the element is dragged into place *by* the scroll
 * rather than playing a fixed-duration animation once it becomes visible. Scrub
 * up and it slides back out.
 */
export function ScrollIn({
  children,
  className,
  y = 70,
  x = 0,
  scale = 1,
  fade = true,
  as = "div",
}: ScrollInProps) {
  const [ref, setRef] = useElementRef();
  const progress = useEnterProgress(ref);

  // Horizontal entrances belong to side-by-side layouts. Below lg those columns
  // stack, so the slide is meaningless — and a positive x on a full-width card
  // pushes past the right edge and adds horizontal page overflow.
  const sideBySide = useMediaQuery("(min-width: 1024px)");
  const fromX = sideBySide ? x : 0;

  const ty = useSmooth(useTransform(progress, [0, 1], [y, 0]));
  const tx = useSmooth(useTransform(progress, [0, 1], [fromX, 0]));
  const s = useSmooth(useTransform(progress, [0, 1], [scale, 1]));
  const opacity = useTransform(progress, [0, 0.65], [fade ? 0 : 1, 1]);

  const Component = motion[as];

  return (
    <Component
      ref={setRef}
      className={cn(REST, className)}
      style={{ y: ty, x: tx, scale: s, opacity }}
    >
      {children}
    </Component>
  );
}

/**
 * Staggered variant of ScrollIn for grid children: `index` shifts each item's
 * start so a row assembles progressively instead of arriving as one slab.
 */
export function ScrollInStagger({
  children,
  className,
  index,
  y = 80,
  as = "div",
}: {
  children: ReactNode;
  className?: string;
  index: number;
  y?: number;
  as?: "div" | "li";
}) {
  const [ref, setRef] = useElementRef();
  const progress = useEnterProgress(ref);

  // Later cards start further down and settle later in the same scroll window.
  const offset = y + index * 26;
  const start = Math.min(0.12 * index, 0.4);

  const ty = useSmooth(useTransform(progress, [start, 1], [offset, 0]));
  const opacity = useTransform(progress, [start, start + 0.5], [0, 1]);

  const Component = motion[as];

  return (
    <Component
      ref={setRef}
      className={cn(REST, className)}
      style={{ y: ty, opacity }}
    >
      {children}
    </Component>
  );
}

/* ------------------------------------------------------------------------- *
 * Ecosystem diagram
 * ------------------------------------------------------------------------- */

/**
 * Shared so all ten nodes key off one scroll subscription instead of each
 * mounting its own.
 */
const DiagramProgress = createContext<MotionValue<number> | null>(null);

/**
 * The Mandra Core diagram assembles as you scroll: the whole board scales up
 * while each node slides in from the edge it belongs to, so the ecosystem
 * visibly converges on the core rather than appearing all at once.
 */
export function EcosystemDiagram({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start 0.95", "center 0.55"],
  });
  const scale = useSmooth(useTransform(scrollYProgress, [0, 1], [0.88, 1]));

  return (
    <DiagramProgress.Provider value={scrollYProgress}>
      <motion.div
        ref={ref}
        className={cn(REST, className)}
        style={{ scale }}
      >
        {children}
      </motion.div>
    </DiagramProgress.Provider>
  );
}

const nodeOrigin = {
  left: { x: -90, y: 0 },
  right: { x: 90, y: 0 },
  top: { x: 0, y: -60 },
  bottom: { x: 0, y: 60 },
} as const;

/** One node of the diagram, sliding toward the core from its own side. */
export function DiagramNode({
  children,
  from,
  style,
  className,
}: {
  children: ReactNode;
  from: keyof typeof nodeOrigin;
  style?: CSSProperties;
  className?: string;
}) {
  const fallback = useMotionValue(1);
  const progress = useContext(DiagramProgress) ?? fallback;
  const origin = nodeOrigin[from];

  const x = useSmooth(useTransform(progress, [0, 1], [origin.x, 0]));
  const y = useSmooth(useTransform(progress, [0, 1], [origin.y, 0]));
  const opacity = useTransform(progress, [0, 0.7], [0, 1]);

  return (
    <motion.div
      className={cn(REST, className)}
      style={{ ...style, x, y, opacity }}
    >
      {children}
    </motion.div>
  );
}

/**
 * The process timeline's connecting rule, drawing itself from the origin as the
 * section scrolls. Scales along the axis it occupies: vertical below `md`,
 * horizontal from `md` up — which is why the two orientations are separate
 * elements rather than one transformed both ways.
 */
export function ProcessTrack() {
  const ref = useRef<HTMLSpanElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start 0.9", "start 0.35"],
  });
  const grow = useSmooth(useTransform(scrollYProgress, [0, 1], [0, 1]));

  // The measured element must have a layout box. A `display: contents` wrapper
  // reports a zero rect, which makes useScroll read as already-complete — hence
  // this absolutely positioned wrapper that inherits the list's box instead.
  return (
    <span
      ref={ref}
      aria-hidden
      className="pointer-events-none absolute inset-0"
    >
      <motion.span
        className={cn(
          "absolute bottom-3 left-[19px] top-3 w-px origin-top bg-line md:hidden",
          "motion-reduce:!transform-none",
        )}
        style={{ scaleY: grow }}
      />
      <motion.span
        className={cn(
          "absolute left-0 right-0 top-[19px] hidden h-px origin-left bg-line md:block",
          "motion-reduce:!transform-none",
        )}
        style={{ scaleX: grow }}
      />
    </span>
  );
}

/* ------------------------------------------------------------------------- *
 * Plain reveal
 * ------------------------------------------------------------------------- */

/**
 * One-shot fade-and-rise the first time an element scrolls into view, and then
 * it stays put. This is the default for ordinary sections — the elaborate
 * scroll-linked treatments are reserved for the pinned showcases and the hero,
 * where the movement is the point.
 *
 * `once: true` matters: without it, content re-animates every time you scroll
 * back up, which reads as a glitch rather than an effect.
 */
export function Appear({
  children,
  className,
  y = 26,
  delay = 0,
  as = "div",
}: {
  children: ReactNode;
  className?: string;
  y?: number;
  delay?: number;
  as?: "div" | "li";
}) {
  const Component = motion[as];
  return (
    <Component
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </Component>
  );
}
