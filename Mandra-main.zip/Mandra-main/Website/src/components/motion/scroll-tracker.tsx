"use client";

import { useEffect } from "react";
import { setScroll } from "@/lib/scroll-store";

/**
 * Publishes native scroll position into the vanilla scroll store that the globe
 * reads inside useFrame.
 *
 * Deliberately no smooth-scroll library: hijacking the wheel to add inertia
 * makes the page feel detached from the input device. Scroll stays native and
 * exact; the *animation* is what's driven by scroll position, not the scrolling
 * itself.
 *
 * Reads are coalesced into one rAF tick so a burst of scroll events can't cause
 * more than one layout read per frame.
 */
export function ScrollTracker() {
  useEffect(() => {
    let frame = 0;
    let heroHeight = window.innerHeight;

    const measure = () => {
      const hero = document.getElementById("hero");
      // The hero pins: its inner panel is sticky and stays put while the outer
      // section scrolls past. Progress therefore runs across the overhang
      // (height - viewport), which is exactly the distance the pin lasts.
      heroHeight = Math.max(
        1,
        (hero?.offsetHeight ?? window.innerHeight) - window.innerHeight,
      );
    };

    const publish = () => {
      frame = 0;
      const y = window.scrollY;
      setScroll({
        scrollY: y,
        heroProgress: Math.min(1, Math.max(0, y / heroHeight)),
      });
    };

    const onScroll = () => {
      if (frame) return;
      frame = requestAnimationFrame(publish);
    };

    const onResize = () => {
      measure();
      onScroll();
    };

    measure();
    publish();

    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onResize);
    return () => {
      if (frame) cancelAnimationFrame(frame);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onResize);
    };
  }, []);

  return null;
}
