"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  type ReactNode,
} from "react";
import {
  motion,
  useScroll,
  useTransform,
  useMotionValue,
  useMotionValueEvent,
  useSpring,
  type MotionValue,
} from "motion/react";
import { heroProgress } from "@/components/rede/lib/hero-progress";
import { cn } from "@/lib/utils";

/**
 * Mirrors a scroll MotionValue into a plain one.
 *
 * Motion accelerates simple scroll→style maps by handing them to a native
 * WAAPI animation on a ViewTimeline. A ViewTimeline measures how far the
 * element itself has crossed the viewport — which for a sticky, pinned panel is
 * nothing like how far its section has scrolled. The result is that an
 * accelerated property (opacity) desynchronises from a JS-driven one
 * (transform) even though both read the same source.
 *
 * Routing through a manually-updated value keeps every property on the same
 * JS-driven progress.
 */
function useDetachedProgress(source: MotionValue<number>) {
  const detached = useMotionValue(source.get());
  useMotionValueEvent(source, "change", (v) => detached.set(v));
  return detached;
}

/**
 * Wheel scrolling arrives in coarse, uneven jumps, so anything mapped straight
 * off scroll position inherits that steppiness. A spring on the progress value
 * itself smooths every downstream property at once.
 *
 * Tuned stiff enough to still feel attached to the input — a softer spring
 * reintroduces the floaty, lagging feel of a scroll-hijacking library.
 */
const PROGRESS_SPRING = {
  stiffness: 160,
  damping: 34,
  mass: 0.32,
  restDelta: 0.0005,
} as const;

/**
 * The hero pins: an outer section several viewports tall with a sticky inner
 * panel, so the panel holds still while the page scrolls past it. That scroll
 * distance is what gives the globe's three-act sequence — spin, explode,
 * reassemble into the Mandra mark — room to actually read.
 *
 * `HERO_SCREENS` is the total height in viewports; one of those is the panel
 * itself, so the pin lasts (HERO_SCREENS - 1) screens of scrolling.
 *
 * The sequence it now drives is the discharge: the bundle gives up its load,
 * the current detaches as a swarm, and the swarm reassembles into the Mandra
 * mark. Same three-act shape the globe used, different subject.
 *
 * Note the overflow-hidden sits on the sticky panel, never on the outer
 * section: an `overflow` other than visible on an ancestor silently kills
 * position: sticky.
 *
 * Reduced motion un-pins through the `motion-reduce:` CSS variant rather than
 * by rendering a different tree. Branching structure on a client-only media
 * query is a hydration mismatch — the server cannot know the answer — and React
 * discards and re-renders the whole subtree when it finds one.
 */
const HERO_SCREENS = 3;

const HeroProgress = createContext<MotionValue<number> | null>(null);

/**
 * Mirrors the pin's progress into the module-level box the WebGL scene reads.
 *
 * React context does not cross into the react-three-fiber reconciler, so the
 * scene cannot subscribe to the MotionValue directly. Writing to a plain box on
 * each change keeps both sides on the same number without either re-rendering.
 */
function ProgressBridge({ source }: { source: MotionValue<number> }) {
  useMotionValueEvent(source, "change", (v) => {
    heroProgress.value = v;
  });
  return null;
}

export function HeroPin({
  children,
  className,
  tone = "night",
}: {
  children: ReactNode;
  className?: string;
  tone?: "light" | "night";
}) {
  const ref = useRef<HTMLElement>(null);

  // Matches the scroll-store's heroProgress, which the globe reads inside
  // useFrame — both run 0→1 across the section's scrollable overhang.
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end end"],
  });

  return (
    <HeroProgress.Provider value={scrollYProgress}>
      <ProgressBridge source={scrollYProgress} />
      <section
        id="hero"
        ref={ref}
        data-tone={tone}
        // The first step of the home page's funnel. The band is measured by
        // carrying the attribute, never by importing the tracker — see the
        // rule in AGENTS.md.
        data-section="hero"
        className={cn(
          "bg-surface text-fg relative motion-reduce:!h-auto",
          className,
        )}
        style={{ height: `${HERO_SCREENS * 100}vh` }}
      >
        <div className="sticky top-0 flex h-screen items-center overflow-hidden motion-reduce:relative motion-reduce:h-auto motion-reduce:py-20">
          {children}
        </div>
      </section>
    </HeroProgress.Provider>
  );
}

/**
 * Hero content that leaves as the globe sequence takes over. `exitBy` is the
 * hero progress at which this element has fully gone, so staggering it across
 * siblings peels the layout away instead of dropping it all at once.
 */
export function HeroPhase({
  children,
  className,
  exitBy = 0.35,
  /** Vertical travel on the way out (negative drifts upward). */
  lift = -60,
  /** Horizontal travel on the way out. */
  slide = 0,
}: {
  children: ReactNode;
  className?: string;
  exitBy?: number;
  lift?: number;
  slide?: number;
}) {
  const fallback = useMotionValue(0);
  const source = useContext(HeroProgress) ?? fallback;
  const progress = useSpring(useDetachedProgress(source), PROGRESS_SPRING);

  const start = Math.max(0, exitBy - 0.26);
  const y = useTransform(progress, [start, exitBy], [0, lift]);
  const x = useTransform(progress, [start, exitBy], [0, slide]);
  const opacity = useTransform(progress, [start, exitBy], [1, 0]);

  return (
    <motion.div
      className={cn(
        "motion-reduce:!opacity-100 motion-reduce:!transform-none",
        className,
      )}
      style={{ y, x, opacity }}
    >
      {children}
    </motion.div>
  );
}

/**
 * Holds the globe stage and slides it to the centre of the screen as the
 * sequence takes over.
 *
 * At rest the globe sits in the hero's right-hand column, balanced against the
 * copy. Once the copy has left, that layout no longer applies — an off-centre
 * mark leaves the whole left half of the screen empty. So the stage drifts to
 * true screen centre over the same stretch the copy is exiting.
 *
 * The shift is measured rather than hard-coded, because the stage's resting
 * position depends on the grid, the container width and whether the metric rail
 * is showing. The measured element is never itself transformed — only its child
 * is — so its box stays truthful to read.
 */
export function GlobeFrame({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  const boxRef = useRef<HTMLDivElement>(null);
  const fallback = useMotionValue(0);
  const source = useContext(HeroProgress) ?? fallback;
  const progress = useSpring(useDetachedProgress(source), PROGRESS_SPRING);

  const shift = useMotionValue(0);
  const x = useMotionValue(0);

  // Centred well before the mark assembles at 0.72 — a mark that is still
  // sliding as it resolves reads as drift rather than as a landing.
  const apply = useCallback(() => {
    const t = Math.min(1, Math.max(0, (progress.get() - 0.1) / 0.34));
    x.set(t * shift.get());
  }, [progress, shift, x]);

  useMotionValueEvent(progress, "change", apply);

  useEffect(() => {
    const measure = () => {
      const el = boxRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      shift.set(window.innerWidth / 2 - (rect.left + rect.width / 2));
      apply();
    };

    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, [apply, shift]);

  return (
    <div ref={boxRef} className={className}>
      <motion.div
        className="absolute inset-0 motion-reduce:!transform-none"
        style={{ x }}
      >
        {children}
      </motion.div>
    </div>
  );
}
