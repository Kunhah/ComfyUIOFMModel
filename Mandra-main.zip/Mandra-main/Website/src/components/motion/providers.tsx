"use client";

import { MotionConfig } from "motion/react";
import type { ReactNode } from "react";
import { ScrollTracker } from "@/components/motion/scroll-tracker";

/**
 * `reducedMotion="user"` makes every Motion animation on the page honour the
 * OS setting automatically, so individual components don't each need a guard.
 */
export function Providers({ children }: { children: ReactNode }) {
  return (
    <MotionConfig reducedMotion="user">
      <ScrollTracker />
      {children}
    </MotionConfig>
  );
}
