"use client";

import { useEffect } from "react";
import {
  MAX_EVENTS,
  type ClientEvent,
  type Device,
  type Payload,
  type ViewContext,
} from "@/lib/analytics/events";
import { AD_PARAMS } from "@/lib/analytics/tagging";

/**
 * The site's own measurement, on every page that is in the registry.
 *
 * It lived under `components/ads/` and was called `AdsTracker` while the
 * ad landing pages were the only thing measured. They are not: the home
 * page — the one surface every organic visitor and every person who types the
 * name lands on — now reports its bands through the same component, and a name
 * saying "ads" would have been a standing invitation to leave it off the next
 * page that is not one.
 *
 * It answers the question a click counter cannot: *where on the page people
 * stop*. Sections report themselves as they come into view, taps report where
 * on the page they happened, and the FAQ reports which question someone had to
 * open — which together turn "conversion fell" into "nobody gets past the
 * deliverables on a phone" or "a third of readers open the price question".
 *
 * Three properties it is built to keep, in order of importance:
 *
 *   1. **It never delays a tap.** Every listener is passive or delegated, the
 *      queue flushes on a timer and on page hide, and a `tel:` link is never
 *      held open waiting for a beacon. Analytics that costs a call is a net
 *      loss on a page whose only job is calls.
 *   2. **It stores nothing personal.** The session id is a random string in
 *      `sessionStorage`, so it dies with the tab and identifies nobody across
 *      tabs, visits or sites. No cookie is set and the server records no IP.
 *   3. **It fails silently.** Analytics must not be able to break a page the
 *      business is buying traffic for, so every call is wrapped and a failed
 *      flush is dropped rather than retried forever.
 *
 * The CTA listener is delegated from the document rather than wired into the
 * buttons: the same actions are used on the marketing site's Terminal band,
 * and an action that has to be told about analytics is one that gets shipped
 * without it. Anything carrying `data-ads-action` is measured, wherever it is.
 */

/**
 * Same-origin, always. The whole app — landing pages, collector and dashboard
 * — is one container on the VPS with `data/` on its volume, so the beacon
 * never has to cross an origin.
 */
const ENDPOINT = "/api/v1/analytics";
/** Long enough that a reader produces a handful of requests, not a stream. */
const FLUSH_MS = 8_000;

function device(): Device {
  const width = window.innerWidth;
  if (width < 640) return "celular";
  if (width < 1024) return "tablet";
  return "desktop";
}

/**
 * The visit's context, read once.
 *
 * `utm_term` is the one that matters most: Google writes the matched keyword
 * there when the campaign is tagged, and it is what turns "the page converts
 * at 8%" into "this keyword converts at zero and has spent R$300".
 */
function viewContext(): ViewContext {
  const params = new URLSearchParams(window.location.search);

  /** First spelling that is actually present wins — see AD_PARAMS for why. */
  const read = (field: string): string | undefined => {
    for (const key of AD_PARAMS[field] ?? []) {
      const value = params.get(key)?.trim();
      // Google leaves the literal placeholder in place when a parameter has no
      // value for that click (a display placement has no keyword). Storing
      // "{keyword}" as a keyword would be worse than storing nothing.
      if (value && !value.startsWith("{")) return value.slice(0, 120);
    }
    return undefined;
  };

  return {
    device: device(),
    viewport: window.innerWidth,
    // Only the host: the rest of somebody else's URL is not ours to keep.
    referrer: document.referrer ? safeHost(document.referrer) : undefined,
    source: read("source"),
    medium: read("medium"),
    campaign: read("campaign"),
    adgroup: read("adgroup"),
    term: read("term"),
    matchtype: read("matchtype"),
    network: read("network"),
    content: read("content"),
    gclid: read("gclid"),
  };
}

function safeHost(url: string): string | undefined {
  try {
    const host = new URL(url).hostname;
    return host === window.location.hostname ? undefined : host;
  } catch {
    return undefined;
  }
}

/**
 * A 32-character random id, without assuming a secure context.
 *
 * `crypto.randomUUID` is `[SecureContext]`: it exists over HTTPS and on
 * localhost and is simply *absent* over plain HTTP. Calling it unguarded threw
 * during the tracker's effect on a VPS reached by `http://host:port` — before a
 * TLS certificate is attached to a domain — and took the whole page down with
 * it, which is exactly the failure mode this component promises not to have.
 *
 * `getRandomValues` is not gated and covers that case. The last fallback is
 * `Math.random`, which is not cryptographic and does not need to be: this id
 * only has to be unlikely to collide with another visitor's.
 */
function randomId(): string {
  const c: Crypto | undefined = globalThis.crypto;
  if (typeof c?.randomUUID === "function") {
    return c.randomUUID().replace(/-/g, "");
  }
  const bytes = new Uint8Array(16);
  if (typeof c?.getRandomValues === "function") {
    c.getRandomValues(bytes);
  } else {
    for (let i = 0; i < bytes.length; i += 1) {
      bytes[i] = Math.floor(Math.random() * 256);
    }
  }
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

function sessionId(page: string): string {
  const key = `mandra.an.${page}`;
  const fresh = randomId();
  try {
    const existing = sessionStorage.getItem(key);
    if (existing) return existing;
    sessionStorage.setItem(key, fresh);
  } catch {
    // Private mode, or site data blocked. The visit is still worth counting;
    // it simply cannot be stitched across a reload.
  }
  return fresh;
}

export function PageTracker({ page }: { page: string }) {
  useEffect(() => {
    const session = sessionId(page);
    const start = performance.now();
    const since = () => Math.round(performance.now() - start);

    let queue: ClientEvent[] = [];
    let context: ViewContext | undefined = viewContext();
    let maxDepth = 0;
    let visibleMs = 0;
    let visibleSince = document.visibilityState === "visible" ? Date.now() : 0;

    const push = (event: ClientEvent) => {
      // A page that somehow produces hundreds of events drops the excess
      // rather than growing the queue without bound.
      if (queue.length < MAX_EVENTS) queue.push(event);
    };

    /**
     * Emit the per-section visible time accumulated so far.
     *
     * Assigned below, once the observer that fills the tallies exists. It is a
     * holder rather than a plain function because `flush` is defined before
     * that observer and calling it in between would otherwise be a hoisting
     * accident waiting to happen.
     */
    let pushDwell = () => {};

    const flush = (final = false) => {
      const engaged =
        visibleMs + (visibleSince ? Date.now() - visibleSince : 0);
      if (maxDepth > 0) push({ type: "depth", value: maxDepth, t: since() });
      if (engaged > 0) push({ type: "engage", value: engaged, t: since() });
      pushDwell();
      // Where the reader was standing when they left, which is a different
      // question from how far they got: a session that reaches the closing
      // band, scrolls back to the price and leaves there is a complete funnel
      // by every other measure and an abandonment at the price in fact.
      if (final && current) push({ type: "exit", name: current, t: since() });
      if (queue.length === 0) return;

      const payload: Payload = {
        v: 1,
        session,
        page,
        context,
        events: queue,
      };
      queue = [];
      // Context rides along only on the first flush; the server keeps what it
      // already stored, so repeating it would be bytes for nothing.
      context = undefined;

      const body = JSON.stringify(payload);
      try {
        if (final && navigator.sendBeacon) {
          navigator.sendBeacon(
            ENDPOINT,
            new Blob([body], { type: "application/json" }),
          );
          return;
        }
        void fetch(ENDPOINT, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body,
          keepalive: true,
        }).catch(() => {});
      } catch {
        // Nothing to do and nobody to tell.
      }
    };

    push({ type: "view", t: 0 });

    /* -- sections ---------------------------------------------------------
       Reported once each, so a reader who scrolls back up is one person at
       that step rather than three. 35% of the band has to be on screen: a
       one-pixel sliver passing by is not "they read it". */
    const seen = new Set<string>();
    /** Sections on screen right now, and since when. Dwell is built from this. */
    const openSince = new Map<string, number>();
    /** Accumulated visible milliseconds per section. */
    const dwellMs = new Map<string, number>();
    /** The band the reader is standing in, which is where they exit from. */
    let current: string | undefined;

    const closeDwell = (name: string, now: number) => {
      const from = openSince.get(name);
      if (from === undefined) return;
      openSince.delete(name);
      dwellMs.set(name, (dwellMs.get(name) ?? 0) + (now - from));
    };

    const observer = new IntersectionObserver(
      (entries) => {
        const now = Date.now();
        for (const entry of entries) {
          const name = (entry.target as HTMLElement).dataset.section;
          if (!name) continue;

          if (entry.isIntersecting) {
            // Reached, once per session. A reader who scrolls back up is one
            // person at that step rather than three.
            if (!seen.has(name)) {
              seen.add(name);
              push({ type: "section", name, t: since() });
            }
            // Dwell, every time. This one deliberately does accumulate on a
            // second visit: the question it answers is how long the band held
            // someone in total, and someone who scrolled back to re-read the
            // price spent that time on the price.
            if (!openSince.has(name)) openSince.set(name, now);
            current = name;
          } else {
            closeDwell(name, now);
            if (current === name) current = undefined;
          }
        }
      },
      { threshold: 0.35 },
    );
    document
      .querySelectorAll<HTMLElement>("[data-section]")
      .forEach((node) => observer.observe(node));

    pushDwell = () => {
      const now = Date.now();
      // Bands still on screen are closed and immediately reopened, so the time
      // already spent in them is reported now instead of only when the reader
      // finally scrolls away — which, for the last band someone reads, is
      // never.
      for (const name of Array.from(openSince.keys())) {
        closeDwell(name, now);
        openSince.set(name, now);
      }
      for (const [name, ms] of dwellMs) {
        if (ms > 0) push({ type: "dwell", name, value: ms, t: since() });
      }
    };

    /* -- scroll depth ------------------------------------------------------ */
    let ticking = false;
    let firstScrollSent = false;
    const onScroll = () => {
      // How fast the hero is left behind. A first screen that is read takes a
      // couple of seconds; one that is skipped is scrolled past in a few
      // hundred milliseconds, and no other measure here can tell the two
      // apart — both end up as "saw the hero".
      if (!firstScrollSent && window.scrollY > 0) {
        firstScrollSent = true;
        push({ type: "firstscroll", value: since(), t: since() });
      }
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        ticking = false;
        const scrollable =
          document.documentElement.scrollHeight - window.innerHeight;
        if (scrollable <= 0) {
          maxDepth = 100;
          return;
        }
        const depth = Math.round((window.scrollY / scrollable) * 100);
        if (depth > maxDepth) maxDepth = Math.min(depth, 100);
      });
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();

    /* -- the actions -------------------------------------------------------
       Delegated and in the capture phase, so the event is recorded before a
       `tel:` href hands the tab to the dialer and the bubble phase may never
       run. */
    const onClick = (event: MouseEvent) => {
      const target = (event.target as HTMLElement | null)?.closest?.(
        "[data-ads-action]",
      ) as HTMLElement | null;
      if (!target) return;
      push({
        type: "cta",
        name: target.dataset.adsAction,
        placement: target.dataset.placement,
        t: since(),
      });
      // The dialer can take the tab away immediately, so this one does not
      // wait for the timer.
      flush(true);
    };
    document.addEventListener("click", onClick, { capture: true });

    /* -- clicks that do nothing -------------------------------------------
       The signal that says what to *fix* rather than what to rewrite: someone
       wanted to go further, tried, and the page answered with nothing. A
       heading styled like a button, a card that looks tappable, a phone number
       set as text. Every one of those is a reader lost in the one moment they
       were willing to act, and no funnel can show it.

       Anything genuinely interactive is excluded, and so is a click that was
       part of selecting text — dragging across a paragraph is reading, not
       frustration. */
    const INTERACTIVE =
      "a, button, input, select, textarea, label, summary, details, video, audio, [role='button'], [role='link'], [role='tab'], [contenteditable], [data-ads-action], [tabindex]:not([tabindex='-1'])";

    /**
     * A short, stable description of what was clicked.
     *
     * Page copy, which is ours — but clamped hard all the same, because this
     * string is the one field on the whole surface that is built from the DOM
     * rather than from a list we wrote. An author can override it outright
     * with `data-dead-label` where the text would be unhelpful.
     */
    const describe = (node: HTMLElement): string => {
      const explicit = node.dataset.deadLabel;
      if (explicit) return explicit.slice(0, 60);
      const section =
        node.closest<HTMLElement>("[data-section]")?.dataset.section;
      const text = (node.textContent ?? "").replace(/\s+/g, " ").trim();
      const what = text ? text.slice(0, 40) : node.tagName.toLowerCase();
      return section ? `${section}: ${what}` : what;
    };

    /** A burst is clicks landing in the same spot in quick succession. */
    const RAGE_RADIUS = 30;
    const RAGE_WINDOW = 1_200;
    const RAGE_AT = 3;
    let burst = { x: 0, y: 0, at: 0, count: 0, label: "" };

    const onDeadClick = (event: MouseEvent) => {
      const node = event.target as HTMLElement | null;
      if (!node || typeof node.closest !== "function") return;
      if (node.closest(INTERACTIVE)) return;
      // Selecting text is reading, not frustration.
      if ((window.getSelection()?.toString().length ?? 0) > 0) return;

      const label = describe(node);
      push({ type: "dead", name: label, t: since() });

      const now = Date.now();
      const near =
        Math.abs(event.clientX - burst.x) < RAGE_RADIUS &&
        Math.abs(event.clientY - burst.y) < RAGE_RADIUS &&
        now - burst.at < RAGE_WINDOW;

      burst = near
        ? { ...burst, at: now, count: burst.count + 1 }
        : { x: event.clientX, y: event.clientY, at: now, count: 1, label };

      // Reported once, when the burst becomes one, rather than on every
      // further click — otherwise one stuck reader fills the queue.
      if (burst.count === RAGE_AT) {
        push({
          type: "rage",
          name: burst.label,
          value: burst.count,
          t: since(),
        });
      }
    };
    document.addEventListener("click", onDeadClick, { capture: true });

    /* -- the questions ----------------------------------------------------- */
    const onToggle = (event: Event) => {
      const target = event.target as HTMLDetailsElement | null;
      if (!target?.open || !target.dataset.faq) return;
      push({ type: "faq", name: target.dataset.faq, t: since() });
    };
    document.addEventListener("toggle", onToggle, { capture: true });

    /* -- visible time and the final flush ---------------------------------- */
    const onVisibility = () => {
      if (document.visibilityState === "hidden") {
        if (visibleSince) visibleMs += Date.now() - visibleSince;
        visibleSince = 0;
        flush(true);
      } else {
        visibleSince = Date.now();
      }
    };
    document.addEventListener("visibilitychange", onVisibility);
    // Safari on iOS does not reliably fire visibilitychange on navigation away.
    window.addEventListener("pagehide", () => flush(true));

    const timer = window.setInterval(() => flush(), FLUSH_MS);

    return () => {
      window.clearInterval(timer);
      observer.disconnect();
      window.removeEventListener("scroll", onScroll);
      document.removeEventListener("click", onClick, { capture: true });
      document.removeEventListener("click", onDeadClick, { capture: true });
      document.removeEventListener("toggle", onToggle, { capture: true });
      document.removeEventListener("visibilitychange", onVisibility);
      flush(true);
    };
  }, [page]);

  return null;
}
