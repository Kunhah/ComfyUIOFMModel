import Script from "next/script";
import { GOOGLE_ADS_ID } from "@/lib/ads/gtag";

/**
 * The Google tag, loaded only once an Ads account exists.
 *
 * Rendering nothing when `NEXT_PUBLIC_GOOGLE_ADS_ID` is unset is deliberate:
 * the landing pages ship before the account does, and an empty gtag on every
 * page would be a third-party request on the exact pages whose load time the
 * campaign's quality score is measured on.
 *
 * It is scoped to the ads tree rather than the root layout, so the marketing
 * site and the internal tools stay free of it.
 */
export function GoogleTag() {
  if (!GOOGLE_ADS_ID) return null;

  return (
    <>
      <Script
        src={`https://www.googletagmanager.com/gtag/js?id=${GOOGLE_ADS_ID}`}
        strategy="afterInteractive"
      />
      <Script id="google-ads-gtag" strategy="afterInteractive">
        {`window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', '${GOOGLE_ADS_ID}');`}
      </Script>
    </>
  );
}
