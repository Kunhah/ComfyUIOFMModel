"use client";

import { Phone } from "lucide-react";
import { site, whatsappHref } from "@/content/site";
import { Bolts } from "@/components/rede/plate";
import { BrandIcon, brandPaths } from "@/components/ui/brand-icon";
import { reportConversion } from "@/lib/ads/gtag";
import type { Placement } from "@/lib/analytics/events";
import { cn } from "@/lib/utils";

/**
 * The actions an ad landing page exists for.
 *
 * Every one of them is a single tap on a real `tel:` or `wa.me` href — never a
 * form, never a modal, never a "fale conosco" that scrolls somewhere. A click
 * bought at R$4 is spent the moment the visitor has to look for the phone
 * number, so the number is written out on the button itself: the label *is*
 * the number, which also means a desktop visitor can read and dial it without
 * clicking anything at all.
 *
 * They are client components only because the conversion beacon has to fire on
 * the tap — see `lib/ads/gtag.ts` for why a `tel:` link is invisible to Google
 * without it.
 */

/**
 * The primary action: the same bolted terminal block the site's hero and
 * Terminal band are made of, with the phone number as its label.
 *
 * `tone` is which band it is standing on. On night it is the live amber field
 * with charcoal type; on the amber band it inverts to charcoal with white
 * type, because amber on amber is not a button.
 */
export function CallAction({
  tone = "night",
  placement = "primeira-tela",
  className,
}: {
  tone?: "night" | "brand";
  /** Where on the page this instance sits. Read by the tracker, not by CSS. */
  placement?: Placement;
  className?: string;
}) {
  const onBrand = tone === "brand";

  return (
    <div
      className={cn("relative inline-flex max-w-full items-stretch", className)}
    >
      {/* The landing lug — the point the cable field converges on. */}
      <span
        aria-hidden
        className="bg-ink-950 relative hidden w-7 shrink-0 self-stretch rounded-l-[3px] sm:block"
      >
        {/* Amber on charcoal in both registers: the lug is the same charcoal
            whichever band it stands on, so hatching it in charcoal would make
            it disappear. This is the one place amber does not mean "live". */}
        <span className="hazard absolute inset-y-2 left-1/2 w-2 -translate-x-1/2 [--hazard-color:rgb(243_163_58/0.75)]" />
      </span>
      <a
        href={site.contact.phoneHref}
        onClick={() => reportConversion("call")}
        data-ads-action="call"
        data-placement={placement}
        className={cn(
          "group relative inline-flex min-w-0 items-center gap-3 rounded-[3px] px-6 py-4 font-semibold transition-colors duration-200 sm:rounded-l-none sm:px-7",
          onBrand
            ? "bg-ink-950 focus-visible:outline-ink-950 text-white hover:bg-[#232a31]"
            : "bg-brand-400 text-ink-950 hover:bg-brand-300",
        )}
      >
        <Bolts />
        <Phone aria-hidden className="size-[18px] shrink-0" />
        <span className="flex min-w-0 flex-col text-left leading-tight">
          <span className="text-[17px] tracking-[-0.01em] tabular-nums sm:text-[19px]">
            {site.contact.phone}
          </span>
          <span
            className={cn(
              "text-[11px] font-medium tracking-[0.14em] uppercase",
              onBrand ? "text-white/65" : "text-ink-950/65",
            )}
          >
            Ligar agora
          </span>
        </span>
      </a>
    </div>
  );
}

/**
 * The secondary action. A plate button, so it reads as the same hardware
 * family as the primary without competing with it for the amber.
 */
export function WhatsappAction({
  message,
  tone = "night",
  placement = "primeira-tela",
  className,
}: {
  message: string;
  tone?: "night" | "brand";
  placement?: Placement;
  className?: string;
}) {
  return (
    <a
      href={whatsappHref(message)}
      target="_blank"
      rel="noopener noreferrer"
      onClick={() => reportConversion("whatsapp")}
      data-ads-action="whatsapp"
      data-placement={placement}
      className={cn(
        "plate group relative inline-flex items-center gap-2.5 rounded-[4px] px-5 py-4 text-[15px] font-semibold transition-colors duration-200",
        tone === "brand"
          ? "text-white hover:bg-[#232a31]"
          : "text-fg hover:text-brand-300",
        className,
      )}
    >
      <BrandIcon path={brandPaths.whatsapp} className="size-[18px] shrink-0" />
      Chamar no WhatsApp
    </a>
  );
}

/**
 * The compact action in the page header, present at every scroll position on
 * a desktop viewport. On a phone the sticky bar below does this job better,
 * which is why this one hides there rather than being duplicated.
 */
export function HeaderCallAction() {
  return (
    <a
      href={site.contact.phoneHref}
      onClick={() => reportConversion("call")}
      data-ads-action="call"
      data-placement="cabecalho"
      className="bg-brand-400 text-ink-950 hover:bg-brand-300 relative hidden items-center gap-2 rounded-[3px] px-4 py-2.5 text-[14px] font-semibold tabular-nums transition-colors duration-200 sm:inline-flex"
    >
      <Bolts />
      <Phone aria-hidden className="size-4 shrink-0" />
      {site.contact.phone}
    </a>
  );
}

/**
 * The sticky bar at the bottom of a phone screen.
 *
 * This is the single highest-leverage element on these pages: it makes the
 * distance between any point of the page and a ringing phone exactly one tap,
 * at every scroll depth, which is the whole brief. It is hidden from `lg` up,
 * where the header action is always on screen anyway, and the layout reserves
 * the space it occupies so it never covers the last line of the footer.
 */
export function CallBar({ message }: { message: string }) {
  return (
    <div
      data-tone="night"
      className="fixed inset-x-0 bottom-0 z-50 border-t border-[rgb(148_163_184/0.18)] bg-[rgb(6_8_11/0.94)] backdrop-blur-md lg:hidden"
      style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)" }}
    >
      <div className="flex items-stretch gap-2 p-2">
        <a
          href={site.contact.phoneHref}
          onClick={() => reportConversion("call")}
          data-ads-action="call"
          data-placement="barra-fixa"
          className="bg-brand-400 text-ink-950 active:bg-brand-300 relative flex flex-[1.6] items-center justify-center gap-2 rounded-[3px] px-3 py-3 text-[15px] font-semibold tabular-nums"
        >
          <Bolts />
          <Phone aria-hidden className="size-[18px] shrink-0" />
          Ligar {site.contact.phone}
        </a>
        <a
          href={whatsappHref(message)}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => reportConversion("whatsapp")}
          data-ads-action="whatsapp"
          data-placement="barra-fixa"
          aria-label="Chamar no WhatsApp"
          className="plate text-fg flex flex-1 items-center justify-center gap-2 rounded-[4px] px-3 py-3 text-[14px] font-semibold"
        >
          <BrandIcon
            path={brandPaths.whatsapp}
            className="size-[18px] shrink-0"
          />
          WhatsApp
        </a>
      </div>
    </div>
  );
}
