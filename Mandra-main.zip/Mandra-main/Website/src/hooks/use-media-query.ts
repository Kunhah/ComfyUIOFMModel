"use client";

import { useCallback, useSyncExternalStore } from "react";

/**
 * Reads a media query as an external store rather than mirroring it into state
 * from an effect, so there's no cascading render on mount and SSR gets a
 * defined answer.
 */
export function useMediaQuery(query: string): boolean {
  const subscribe = useCallback(
    (onChange: () => void) => {
      const mql = window.matchMedia(query);
      mql.addEventListener("change", onChange);
      return () => mql.removeEventListener("change", onChange);
    },
    [query],
  );

  return useSyncExternalStore(
    subscribe,
    () => window.matchMedia(query).matches,
    () => false,
  );
}
