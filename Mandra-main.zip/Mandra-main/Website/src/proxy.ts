import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { SESSION_COOKIE, verifySession } from "@/lib/auth/session";

/**
 * The first gate, and only the first.
 *
 * This verifies the session cookie's signature and expiry — a hash, no database
 * — and turns anonymous traffic away before it reaches a page. It deliberately
 * does not ask whether the account still exists or is still active, because
 * answering that means reading SQLite on every request, and Next's own guidance
 * is that a proxy is an optimistic check rather than the authorization boundary.
 *
 * That question is answered by `requireUser()` / `requireAdmin()` in
 * `lib/auth/server.ts`, which every protected page and route calls. A revoked
 * operator still holds a validly signed cookie; this lets them past, and the
 * page behind it does not.
 *
 * Covers the prospector as well as the CRM: they share one database, and a lead
 * tool that anyone can run is a lead tool anyone can empty into a CSV.
 */

/** Reachable without a session — the login form and the route that issues one. */
const PUBLIC = [
  "/admin/login",
  "/operador/login",
  "/app/login",
  "/api/admin/session",
];

/**
 * The redirect has to carry an absolute URL, and it has to be built from
 * `request.nextUrl` rather than written by hand.
 *
 * Absolute because Next parses the Location of a proxy response itself: a
 * relative one throws `ERR_INVALID_URL` inside the proxy runtime and every
 * protected page answers 500 while the API routes, which return JSON instead of
 * a redirect, keep working — which is exactly as confusing to debug as it
 * sounds.
 *
 * Which raises the obvious worry behind a reverse proxy — an absolute URL built
 * from an internal origin would send clients to an address they can't reach. It
 * doesn't happen: Next strips the origin again on its way out when it matches
 * the request's own, so what reaches the browser is `location: /admin/login?…`
 * and the client keeps whatever host and scheme it arrived on. Cloning
 * `nextUrl` rather than writing a string is what keeps that true.
 */
function loginRedirect(request: NextRequest, next: string): NextResponse {
  const url = request.nextUrl.clone();
  // Each tree bounces to its own login. Sending a client to /admin/login would
  // show them our copy and then refuse the sign-in — the route checks the
  // submitted portal against the account's role.
  const path = request.nextUrl.pathname;
  url.pathname = path.startsWith("/app")
    ? "/app/login"
    : path.startsWith("/operador") || path.startsWith("/prospector")
      ? "/operador/login"
      : "/admin/login";
  url.search = "";
  url.searchParams.set("next", next);
  return NextResponse.redirect(url);
}

export async function proxy(request: NextRequest) {
  const { pathname, search } = request.nextUrl;

  if (PUBLIC.some((path) => pathname === path)) return NextResponse.next();

  const claims = await verifySession(
    request.cookies.get(SESSION_COOKIE)?.value,
  );
  if (claims) return NextResponse.next();

  // An API caller gets an answer it can parse. Redirecting a fetch to an HTML
  // login form produces a 200 full of markup, which reads as a bizarre success.
  if (pathname.startsWith("/api/")) {
    return NextResponse.json({ error: "Não autenticado." }, { status: 401 });
  }

  return loginRedirect(request, `${pathname}${search}`);
}

export const config = {
  matcher: [
    "/admin/:path*",
    "/app/:path*",
    "/operador/:path*",
    "/prospector/:path*",
    "/api/admin/:path*",
    "/api/prospector/:path*",
  ],
};
