---
name: Mandra — A Rede
description: The same rede in two registers — drawn on paper by day, energized at night; amber only where current flows.
colors:
  night-950: "#06080b"
  night-900: "#0a0d11"
  night-800: "#10141a"
  night-700: "#171d25"
  night-600: "#212934"
  dead-600: "#333d4a"
  dead-500: "#46515f"
  dead-400: "#5f6c7c"
  dead-300: "#8290a1"
  brand-300: "#ffb354"
  brand-400: "#f3a33a"
  brand-500: "#d98413"
  brand-600: "#a85f09"
  filament: "#ffd9a0"
  ink-950: "#0b0e12"
  ink-900: "#101419"
  ink-800: "#171c21"
  ink-700: "#232a31"
  paper: "#fdfbf7"
  paper-muted: "#f5f2ec"
  paper-sunken: "#ede8dd"
  night-fg: "#f4f1ea"
  night-fg-muted: "#9aa6b4"
  night-fg-subtle: "#6e7b8b"
  night-line: "rgb(148 163 184 / 0.14)"
  night-line-strong: "rgb(148 163 184 / 0.28)"
  paper-fg: "#1d2228"
  paper-fg-muted: "#5b6570"
  paper-fg-subtle: "#8a939e"
  paper-line: "#ece5d8"
  paper-line-strong: "#dcd3c2"
  brand-band-fg: "#16191d"
  ink-accent-paper: "#a85f09"
  ink-accent-night: "#f3a33a"
  ink-id-dead-paper: "#6f6553"
  ink-id-dead-night: "#8290a1"
  recess-face-paper: "#efeade"
  recess-face-night: "#05070a"
  conductor-ink: "#6f6553"
  conductor-steel: "#333d4a"
typography:
  display:
    fontFamily: "Archivo, Inter, ui-sans-serif, sans-serif"
    fontSize: "clamp(2.05rem, 7.6vw, 4.4rem)"
    fontWeight: 800
    lineHeight: 0.96
    letterSpacing: "-0.035em"
  headline:
    fontFamily: "Archivo, Inter, ui-sans-serif, sans-serif"
    fontSize: "clamp(1.9rem, 4vw, 3.1rem)"
    fontWeight: 800
    lineHeight: 1.02
    letterSpacing: "-0.03em"
  title:
    fontFamily: "Archivo, Inter, ui-sans-serif, sans-serif"
    fontSize: "clamp(1.5rem, 3vw, 2.3rem)"
    fontWeight: 700
    lineHeight: 1.05
    letterSpacing: "-0.025em"
  subtitle:
    fontFamily: "Archivo, Inter, ui-sans-serif, sans-serif"
    fontSize: "1.125rem"
    fontWeight: 700
    lineHeight: 1.15
    letterSpacing: "-0.02em"
  body:
    fontFamily: "Inter, ui-sans-serif, system-ui, sans-serif"
    fontSize: "15px"
    fontWeight: 400
    lineHeight: 1.625
    letterSpacing: "normal"
  label:
    fontFamily: "Geist Mono, ui-monospace, monospace"
    fontSize: "11px"
    fontWeight: 400
    lineHeight: 1
    letterSpacing: "0.18em"
  legend:
    fontFamily: "Geist Mono, ui-monospace, monospace"
    fontSize: "10px"
    fontWeight: 400
    lineHeight: 1
    letterSpacing: "0.2em"
rounded:
  hardware: "3px"
  plate: "4px"
  core: "5px"
  control: "12px"
  card: "16px"
  panel: "20px"
spacing:
  hairline: "3px"
  xs: "6px"
  sm: "12px"
  md: "20px"
  lg: "32px"
  band: "80px"
  band-lg: "112px"
components:
  button-primary:
    backgroundColor: "{colors.brand-400}"
    textColor: "{colors.ink-950}"
    rounded: "{rounded.hardware}"
    padding: "16px 24px"
    typography: "{typography.body}"
  button-primary-hover:
    backgroundColor: "{colors.brand-300}"
    textColor: "{colors.ink-950}"
  button-plate:
    backgroundColor: "{colors.night-800}"
    textColor: "{colors.night-fg}"
    rounded: "{rounded.plate}"
    padding: "10px 16px"
  button-plate-hover:
    backgroundColor: "{colors.brand-400}"
    textColor: "{colors.ink-950}"
  button-on-brand:
    backgroundColor: "{colors.ink-950}"
    textColor: "#ffffff"
    rounded: "{rounded.hardware}"
    padding: "16px 28px"
  plate-code:
    textColor: "{colors.ink-id-dead-night}"
    typography: "{typography.label}"
  plate-code-live:
    textColor: "{colors.ink-accent-night}"
    typography: "{typography.label}"
  plate-code-paper:
    textColor: "{colors.ink-id-dead-paper}"
    typography: "{typography.label}"
  plate-code-paper-live:
    textColor: "{colors.ink-accent-paper}"
    typography: "{typography.label}"
  legend:
    textColor: "{colors.ink-id-dead-night}"
    rounded: "{rounded.hardware}"
    padding: "4px 10px"
    typography: "{typography.legend}"
  lamp:
    backgroundColor: "{colors.dead-600}"
    size: "10px"
    rounded: "9999px"
  lamp-live:
    backgroundColor: "{colors.brand-400}"
    size: "10px"
    rounded: "9999px"
---

# Design System: Mandra — A Rede

## Overview

**Creative North Star: "The Schematic and the Junction Box"**

A Rede is Brazilian aerial cabling, and the shipped build renders it in **two
registers of the same world**: the schematic is drawn on paper, the network runs
at night. On paper a plate is a hairline ruled box on stock, a conductor is a
ruled ink line and a recess is a sunken well in the sheet. At night the same
objects are the things themselves — milled aluminium, a glossy sheathed cable, a
cavity inside a box. Amber crosses both registers unchanged, because current
does not care what it is drawn on. This is one system, not two: the `plate`,
`recess` and `conductor` utilities are written once against tone-aware CSS
variables (`--plate-face`, `--plate-edge-top`, `--plate-edge-bottom`,
`--plate-shadow`, `--recess-face`, `--recess-shadow`, `--conductor-1..4`,
`--bolt-face`, `--bolt-edge`, `--ink-accent`, `--ink-id-dead`) that every tone
block re-points.

The page is a tonal arc rather than a stack of bands: night (hero) → night
(Emaranhado) → paper (Linhas) → muted (Diagrama) → paper (Rota) → night
(Ferramental) → night (Carga) → brand/amber (Terminal). Dark is the rede
energized, light is the rede drawn, amber is the rede at full load. The first
viewport is a pinned three-act discharge: the bundle under load, the amber
current detaching from the conductors as a ~24k-point swarm while the tubes fall
to unlit steel, and the swarm reassembling into the Mandra mark.

Density is high on identification and low on ornament. Type is Archivo signage
weights over Geist Mono ID fields; body copy is Inter and stays out of the way.
Motion is latched, never ambient: a contactor closes fast and releases slow, and
lit/unlit is a binary that carries the navigation. There is no bloom pass and no
ambient glow anywhere in the build — what reads as glow is the sheath's own
specular highlight widening under the travelling filament. The build refuses the
five-parallel-feature-cards grid outright, in Linhas most of all, because five
equal boxes side by side *are* the tangle the product exists to terminate.

The public marketing surface is this world in full. The internal tools
(`/prospector`, `/admin`, `/app`) stay in their own tone blocks and keep the warm
charcoal-and-cream `ink`/`paper` world; they share the token architecture — the
same `@theme inline` semantic names, remapped per tone — and not this world's
night palette.

**Key Characteristics:**
- Two registers, one system: paper drawing and night hardware, same objects.
- Amber only where current flows; night ground `#06080b`–`#171d25`.
- Materials as tone-aware variables: plate, recess, conductor, bolts, hazard.
- The three-field terminal plate is the one repeating unit, in both registers.
- Square hardware corners (3–5px), never a pill.
- Latched binary states; no cross-fades, no bloom, no ambient glow.

## Colors

A two-material palette — de-energized blue-cast steel (night) or ruled ink
(paper) — with one accent that means exactly one thing.

### Primary
- **Live Amber** (`brand-400`): the conductor at load. It fills the hero's
  primary action, lights every lamp, marks the one energized line in Linhas, and
  owns the entire closing Terminal band. Never applied because a surface needed
  interest.
- **Filament Amber** (`brand-300`): the current at its hottest — hover on the
  primary action, live plate codes on night, hovered links on night, and the
  warm stop of the discharge shader.
- **Deep Amber** (`brand-600`): the first amber step clearing 4.5:1 on light
  ground. It is `--ink-accent` on every paper and muted band, and the only amber
  permitted to carry small text there.

### Secondary
- **Blue-cast Steel** (`dead-600`…`dead-300`): the de-energized conductor at
  night. It must read as metal, not as grey text, which is why it carries a blue
  cast rather than sitting on the neutral ink ramp. `dead-300` is the unlit plate
  code; `dead-600` is the unlit lamp, the dashed fault border and the scrollbar.
- **Drawn Ink** (`conductor-ink` `#6f6553` over `#b9ae99`): the same conductor on
  paper — a ruled line with a drawn core, not a coloured bar.

### Neutral
- **Night** (`night-950`–`night-600`): the ground. `night-950` is the hero and the
  WebGL clear colour; `night-900` is the section surface; `night-800` is the
  plate face; `night-700` the raised step.
- **Night Foreground** (`night-fg`, `-muted`, `-subtle`): secondary text is tinted
  from the ground's own hue rather than greyed — a neutral grey here reads as a
  rendering fault, not a choice.
- **Paper** (`paper`, `paper-muted`, `paper-sunken`) with **Paper Foreground**
  (`paper-fg`, `-muted`, `-subtle`) and **Paper Line** (`paper-line`,
  `-strong`): the drawing register's stock, ink and rules.
- **Ink** (`ink-950`–`ink-700`): the mascot's warm charcoal. The type colour on
  the amber band, the button field there, and the internal tools' ground.

### Named Rules
**The Current Rule.** Amber means one thing: current is flowing. It marks a
state, never a surface. The single exception is the closing Terminal band, where
it owns the whole field — and that reads as the network under load precisely
because it was never spent decoratively above it.

**The Two-Registers Rule.** Light is not a different design system. A paper band
uses the same `plate` / `recess` / `conductor` utilities as a night band; only
the material variables change. If a light section needs a new device to look
finished, the device is wrong, not the register.

**The Charcoal-on-Amber Rule.** Type on the amber band is charcoal (`#16191d`),
never white. White on `#f3a33a` is 2.3:1.

**The Contrast Ladder Rule.** `brand-300`/`brand-400` are the display values on
dark ground; `brand-600` is the only amber permitted to carry small text on a
light one. Check an amber against the band it lands on, not against the ramp.

**The No-Opacity-Dimming Rule.** Never dim text with a wrapper opacity.
Multiplying already-muted tokens took 11px ID type to ~2.4:1. State is carried by
colour tokens checked at their **final rendered value**, plus the lamp and the
conductor.

**The Every-Tone Rule.** A new semantic colour lives in `@theme inline` — never
plain `@theme` — and must be given a value in *every* tone block (`light`,
`muted`, `dark`, `night`, `brand`, `[data-prospector]`, `[data-admin]`,
`[data-admin] [data-admin-shell]`), or it resolves to nothing on the bands that
lack it.

**The Colorspace Rule.** `THREE.Color` parses a hex as sRGB and converts it into
the linear working space, but a raw `ShaderMaterial` writes `gl_FragColor` with
no encoding step — so an authored brand value renders wrong (`#ffb354` landed as
~`#ff7217`, hue 33 → 24). Every raw ShaderMaterial that outputs an authored brand
colour must end with `#include <colorspace_fragment>`. The mark now measures hue
33 at all three sample points. **Documented exception:**
`src/components/rede/shaders/cable.ts` still outputs un-encoded — its colours
were tuned by eye against that pipeline and the night register was ruled
untouchable in two review rounds, so correcting the encoding would silently
repaint the whole bundle. That is a recorded exception, not an oversight; changing
it means re-tuning the bundle's colours in the same commit.

**Known gap, unresolved:** the reassembled mark (hue 33) and the header wordmark
(hue 43, sampled `#FDBA0C`) sit ~10° apart. That is the logo artwork's own
gradient, not the shader, and it is recorded here rather than presented as fixed.

## Typography

**Display Font:** Archivo (500–800), falling back to Inter
**Body Font:** Inter, falling back to system sans
**Label/Mono Font:** Geist Mono, falling back to `ui-monospace`

**Character:** A highway-gothic grotesque over a monospaced ID field. Archivo
comes from the same signage tradition as the silkscreened plate bolted to a
utility box; Geist Mono is used only for identification and measurement — codes,
legends, load readings — and never for prose.

### Hierarchy
- **Display** (800, `clamp(2.05rem, 7.6vw, 4.4rem)`, 0.96, `-0.035em`): the hero
  headline, set in the negative space the cables leave rather than in a panel.
  The Terminal band's headline is the same role at `clamp(2rem, 4.6vw, 3.6rem)`.
- **Headline** (800, `clamp(1.9rem, 4vw, 3.1rem)`, 1.02, `-0.03em`): every
  band's opening statement, in both registers.
- **Title** (700, `clamp(1.5rem, 3vw, 2.3rem)`, 1.05, `-0.025em`): the line name
  in Linhas, which is also its button.
- **Subtitle** (700, 1.125rem, `-0.02em`): the per-row heading in Rota and Carga.
- **Body** (400, 15px, ~1.625): all prose, held to a 52–62ch measure.
- **Label** (400, 11px, `0.18em`): the stamped plate code, tabular figures on.
- **Legend** (400, 10px, `0.2em`, uppercase): the stamped legend strip and the
  band's own identification strip — a physical object, never a kicker.

### Named Rules
**The No-Kicker Rule.** No eyebrow or kicker above a heading, at any breakpoint.
A stacked identifier above a heading is a kicker even when the desktop layout is
fine, so the mobile arrangement is not an exemption. Identifiers live in a left
field column (Linhas, Rota, Carga) or inline on the heading's own baseline, and
the convention is the same in every section.

**The Mono-Is-Identification Rule.** Geist Mono appears only where something is
identified or measured — a code, a legend, a load. Mono as body copy is off-world.

**The Tabular Rule.** Every code, legend and measurement under `[data-rede]` is
`tabular-nums` with `zero` on: the ID column is the alignment the world is built
on.

**The Signage Tracking Rule.** Display sizes take `-0.02em` to `-0.035em`;
mono labels take `+0.14em` to `+0.24em`. The two faces move in opposite
directions on purpose.

## Layout

The content rail is a centred `max-w-[1360px]` (`wide`), with `max-w-[1200px]`
and `max-w-3xl` available for denser and narrower reading. Gutters are 20px
rising to 32px at `sm`.

Bands are the unit of page structure, each carrying its own `data-tone` and the
same vertical rhythm: 80px rising to 112px (`py-20 sm:py-28`). The hero is the
exception — `HeroPin` is a section three viewports tall with a sticky
`h-screen` panel inside it, so the pin lasts two screens of scrolling and the
discharge has room to read. The header is pulled over the hero with a negative
top margin so the cables run behind the chrome. `overflow-hidden` sits on the
sticky panel, never on the outer section, or `position: sticky` dies silently.

Rows, not grids, are the default arrangement. Linhas and Carga are full-width
runs stacked vertically with a conductor or a hairline between them; Rota is a
single vertical bus with seven taps; Ferramental is one bolted panel whose cell
field is a 2/3/4-column recess. Diagrama is the only true two-axis figure, and
below `lg` its horizontal runs are replaced by a vertical bus with taps, because
the horizontal answer cannot survive the reflow.

Breakpoints are Tailwind's defaults (`sm` 640, `lg` 1024, `xl` 1280) plus a
768px media query in JS for the WebGL field's small-viewport branch.

### Named Rules
**The Wired-At-Every-Breakpoint Rule.** A diagram must actually be wired, at
every breakpoint. Every node reaches the core by a real conductor ending in a
numbered lug, so the count of lugs equals the count of nodes and a reader can
follow any one line from its box to where it lands. A section asserting "dez
linhas, dez terminais" over boxes joined by nothing is the defect this page's own
thesis forbids; a layout that only wires up at `lg` is the same defect on a
phone.

## Elevation & Depth

Depth is material, not ambient. At night a plate is stamped from one piece, so
the light on its edge is what reads as thickness: two inset hairlines (white at
7% along the top, black at 50% along the bottom) plus a tight contact shadow and
one wide, very soft occlusion. A recess inverts that light — dark at the top
where the lip casts into the cavity, a thin lift along the bottom. Bolt heads at
the four corners are what separate a plate from a rounded rectangle with a
border.

**On paper there is no fill and no shadow at all.** `--plate-face` and both edge
variables are `transparent`; the whole plate is a single hairline ruled box
(`inset 0 0 0 1px rgb(29 34 40 / 0.2)`). A white filled card with a drop shadow
is stock UI material and was a review finding — the paper register earns its
depth from ink weight and from the recess, which stays real there
(`#efeade` with an inset well).

The one real offset shadow in the world is the lit lamp: a 1px ring and a 10px
downward bloom, so it reads as a bulb behind glass rather than a coloured dot.
The `--shadow-soft` / `--shadow-raised` / `--shadow-glow` tokens remain in the
palette layer for the internal tools and are not part of this world.

### Shadow Vocabulary
- **Plate, night** (`inset 0 1px 0 rgb(255 255 255 / 0.07), inset 0 -1px 0 rgb(0 0 0 / 0.5), 0 1px 2px rgb(0 0 0 / 0.4), 0 12px 28px -18px rgb(0 0 0 / 0.9)`): every plate, legend, header chrome and social tile on a night band.
- **Plate, paper** (`inset 0 0 0 1px rgb(29 34 40 / 0.2)`): the same plate, drawn. No fill, no drop shadow.
- **Recess, night** (`inset 0 2px 6px rgb(0 0 0 / 0.75), inset 0 -1px 0 rgb(255 255 255 / 0.05)`): the cavity a list of terminals sits in.
- **Recess, paper** (`inset 0 2px 5px rgb(29 34 40 / 0.13), inset 0 -1px 0 rgb(255 255 255 / 0.7)`): a sunken well in the sheet.
- **Lamp, lit** (`0 0 0 1px rgb(243 163 58 / 0.35), 0 1px 10px 1px rgb(243 163 58 / 0.55)`): the latched indicator, and nothing else.
- **Lamp, unlit** (`inset 0 1px 1px rgb(0 0 0 / 0.6)`): a dead bulb, seated.
- **Header, scrolled** (`0 1px 0 rgb(255 255 255 / 0.05), 0 18px 40px -30px rgb(0 0 0 / 1)`): the chrome dropping onto its plate.

### Named Rules
**The One-Repeating-Unit Rule.** The plate is the one repeating unit and it must
be honoured in **both** registers. Honouring it only at night is what made the
tonal arc read as two design systems.

**The No-Bloom Rule.** No bloom pass and no ambient glow, in WebGL or in CSS.
What reads as glow is the sheath's own specular highlight widening under the
travelling filament.

**The Edge-Not-Border Rule.** Thickness comes from inset light on an edge (night)
or from a single hairline rule (paper). A plate never takes a 1px outline plus a
fill plus a shadow to look raised.

## Shapes

Corners are hardware-small: 3px on anything stamped or bolted, 4px on a plate or
a tile, 5px on the diagram's core, and full-round only on a bolt head, a lamp, or
the cap of a conductor run. The larger `control`/`card`/`panel` radii (12/16/20px)
belong to the internal tools and do not appear on the marketing surface. A pill
button is the single atom that would give the whole world away.

The recurring silhouettes are four: the conductor run (a 3–6px bar carrying the
four-stop sheath/ink gradient, with rounded caps), the bolted rectangular plate,
the recessed cell field, and the diagonal hazard hatch (`-45deg`, 3px stripe on a
9px pitch; amber at 55% alpha on night, charcoal at 50% on the amber band).
Hatching is the only place amber appears without meaning "live", which is why it
is held at low alpha and never sits under body text.

## Components

### Buttons
- **Shape:** stamped-square (3px), or plate-square (4px) when the button is
  itself a piece of hardware.
- **Primary:** live amber field, charcoal (`ink-950`) label, 16px/24px padding,
  15px semibold, seated inside a bolted plate with a hazard landing lug on its
  left edge — the point the cable field converges on. The hero's action and the
  Terminal's action are the same object; on the amber band it inverts to a
  charcoal field with white type and an amber hazard lug.
- **Hover / Focus:** amber steps up to filament (`brand-300`) over 200ms and the
  arrow translates 2px. Focus is a 2px `brand-400` outline at 2px offset
  globally, overridden to `brand-300` on amber and to `--ink-accent` on paper.
- **Plate (secondary):** the plate material as the button — night face, night
  foreground, a live lamp leading; on hover it inverts to an amber field with
  charcoal type and the lamp goes dark.

### Plate Code / Legend
- **Style:** `PlateCode` is 11px mono at `0.18em`, coloured by `--ink-id-dead`
  unlit and `--ink-accent` live, transitioning over 300ms — which is what makes
  it correct on paper (`#6f6553` / `#a85f09`) and at night (`#8290a1` / `#f3a33a`)
  with no variant. `Legend` is the same family at 10px/`0.2em` uppercase, wearing
  the plate material with 10px/4px padding.
- **State:** the live/unlit pair is the only variation. There is no size ramp.

### Cards / Containers
- **Corner Style:** 4px (3px for an inner recess, 5px for the diagram core).
- **Background:** the `plate` utility, whatever the register decides that is; a
  list of terminals sits in a `recess`.
- **Shadow Strategy:** the Plate and Recess entries above; no drop shadow on paper.
- **Border:** none. Rows inside a night recess are divided by white at 5–6%; on
  paper by `var(--line)`.
- **Internal Padding:** 20px, rising to 28–32px on wide plates.

### Navigation
- **Header:** transparent over the cable field, dropping onto a blurred night
  plate (`rgb(6 8 11 / 0.82)`, `backdrop-blur-md`) past 40px of scroll. Links are
  13px medium in `night-fg-muted`, going filament amber on hover. The primary
  action is a plate button carrying a live lamp.
- **Footer:** night ground, hairline top rule, `Legend` strips as column
  headings, plate tiles for the social marks.
- **Bus strip:** under the hero, five named conductors as a divided row — lamp,
  live plate code, line name — so the WebGL field is legible as information
  rather than as atmosphere. It exits first as the discharge takes the stage.

### The Conductor
A 3–6px bar carrying a four-stop gradient supplied by `--conductor-1..4`: at
night a polyethylene sheath with one white 18% specular highlight at 22%; on
paper a ruled line with a drawn core. Energized, a tight amber head with a long
tail travels its length at 2.4–2.6s, linear, infinite, confined to an absolutely
positioned overlay — so the resting state is the visible default and
reduced-motion stops the head without hiding the conductor. SVG connectors carry
`pathLength="100"` so one set of dash values fits any real path length.

### The Discharge (hero)
A full-bleed WebGL bundle of 34 catenary conductors on `night-950`, pinned across
three viewports and driven entirely by scroll progress in three acts: the bundle
under load; the amber current detaching from the conductors as a ~24k-point swarm
while the tubes fall to unlit steel (`uDischarge` mixes the sheath back to night);
and the swarm reassembling into the Mandra mark, centred well before it resolves
so it lands rather than drifts. Steel `#8595a8` over `#111820`, live `#f3a33a`,
filament `#ffd9a0`; the swarm's stops are `#fff1d6` / `#ffb354` / `#d98413`. Its
lifecycle is part of the design: a poster SVG paints first, the canvas is held
until after `load` and then until `requestIdleCallback`, cross-fades in over
700ms once it has a frame, parks `frameloop` at `never` off-screen and at
`demand` under reduced motion, and renders nothing at all without WebGL — the
poster is then the final state. Shaders live in `.ts` modules, not `.glsl`, so no
bundler loader config is needed; watch for backticks inside GLSL comments, which
terminate the template literal.

### Named Rules
**The Progress-Box Rule.** React context does not cross into the
react-three-fiber reconciler, so scroll progress is bridged through a
module-level mutable box (`heroProgress`) written by a `useMotionValueEvent` in
the DOM tree and read inside `useFrame`. Neither side re-renders. Any future
scene that needs a DOM-side value takes the same route — a provider or a
`useState` here is a re-render on every scroll frame.

**The Latch Rule.** State is latched, not cross-faded. A contactor closes fast
and releases slow (shader attack 9, release 1.6). Lit/unlit is a binary, and that
binary is the navigation signal.

**The Keyboard-Reachable-State Rule.** Any state a pointer can reach, a keyboard
must reach. The Linhas binary is driven by real `<button>`s with `onFocus` and
`aria-pressed`, never by hover alone.

**The Plate-Is-Not-A-Card Rule.** A plate identifies; it does not contain. Rota's
step rows and Diagrama's node fields keep the conductor and its taps dominant and
never gain a fill or a shadow, or the run becomes the card grid the thesis
refuses.

**The Marks-Keep-Their-Colours Rule.** Third-party brand marks in Ferramental
render in their own hex at 55% opacity, coming to full strength on hover. It is
the one place a colour other than amber is allowed on this page: a logo is
evidence, and repainting it amber would misrepresent it.

## Do's and Don'ts

### Do:
- **Do** spend amber only on state: `brand-400` for a live conductor or lamp,
  `brand-300` for the filament and hover, `brand-600` (`--ink-accent`) for amber
  that must carry text on a light band.
- **Do** put charcoal on amber (`#16191d`), never white.
- **Do** build every surface from the `plate` / `recess` / `conductor` utilities
  and let the tone block choose the material; add four bolt heads to anything
  meant to be bolted on.
- **Do** give every new semantic colour a value in every tone block, declared in
  `@theme inline`.
- **Do** end every raw ShaderMaterial that outputs an authored brand colour with
  `#include <colorspace_fragment>`, and measure the result rather than trusting
  the hex.
- **Do** bridge DOM-side scroll values into the r3f scene through a module-level
  box, not through context or state.
- **Do** wire every node in a diagram to its terminal, at every breakpoint —
  swapping horizontal runs for a vertical bus with taps below `lg` is the
  supported answer.
- **Do** give every hover-reachable state a focus path on a real `<button>`.
- **Do** hold prose to a 52–62ch measure and keep display type in Archivo with
  negative tracking, identification type in Geist Mono with wide positive
  tracking and tabular figures.
- **Do** keep the WebGL field deferred behind `load` + idle, with a poster that is
  a valid final state.

### Don't:
- **Don't** use a wrapper opacity to dim text. Change the colour token and check
  its final rendered contrast.
- **Don't** give a paper plate a white fill or a drop shadow. On paper it is a
  hairline ruled box; a filled, shadowed card is stock UI material.
- **Don't** add a bloom pass, an ambient glow, a coloured halo or a zero-offset
  aura. The lamp's seated bulb shadow is the only lit shadow in the world.
- **Don't** add an eyebrow or kicker above a heading — including at mobile, where
  a stacked identifier above a heading is still a kicker. Use the left field
  column, the heading's own baseline, or a bolted `Legend` strip.
- **Don't** arrange page structure as a row of same-size icon cards, and don't
  give a plate a fill or a shadow that turns it into one.
- **Don't** use gradient text, hero metric templates, glyph or emoji icons, hard
  offset shadows outside the lamp, coloured side-borders, or a system display
  face.
- **Don't** round a control past 5px on the marketing surface, and never make a
  pill.
- **Don't** cross-fade a state that should latch, or leave a hover-only
  interaction without a focus path.
- **Don't** put amber under body text, including as hazard hatching.
- **Don't** import the internal tools' `ink`/`paper` ramps or their
  `--shadow-soft` / `--shadow-raised` / `--shadow-glow` tokens onto a night band.
- **Don't** "fix" the un-encoded output in `shaders/cable.ts` in isolation; it is
  a documented exception and correcting it repaints the whole bundle.
