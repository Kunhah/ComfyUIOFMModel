# Atlas Contábil — os produtos, para um escritório de contabilidade

The plan for selling what we already build — the WhatsApp assistant, the client
portal, sales insight, the dashboards — to an escritório de contabilidade, and
what has to change for it to fit.

This is a design document. The only part that exists is marked **built**: the
WhatsApp preset in `whatsapp-bot/presets/contabilidade.config.ts`. Everything
else is a commitment to a shape, written on top of `plataforma.md` (tenancy,
channels, the job runner) and `ai-infra.md` (the skill spine). Where this
document and those disagree, those win and this one is out of date.

## Why this vertical is not "a clinic with other nouns"

Every client we have sold to so far has the same shape: our products sit at the
**front door**. A lead arrives, we make sure somebody answers, an appointment
happens. The pitch is conversion.

An accounting office's front door matters, but its money is behind it:

- **Revenue is a carteira, not a stream of sales.** 50 to 400 client companies,
  each paying honorários every month. One lost client costs years of honorários,
  and nobody notices it leaving until the distrato.
- **The bottleneck is the monthly chase.** Every empresa owes documents every
  month — notas, extratos, folha de ponto — and they arrive late, as WhatsApp
  photos, to whichever employee's phone the client happens to have. Guias go
  back out the same way. The team's week is spent asking "já mandou?".
- **Deadlines are external and fixed.** A late DAS is a fine on the client and
  a lost client for the office. The office carries the risk of the client's
  lateness.

Both conversations — the carteira and the prospect — land on **the same
number**. That is why the bot preset routes by "is this person a client?"
before its second sentence, and why the portal in this document is mostly about
the carteira. The Mandra sector note already said it: "carteira de clientes com
entrega mensal: portal do cliente vende só" (`src/lib/b2b/sectors.ts`).

## What we do not build

Say it out loud so nobody builds it by accident:

- **A contábil ERP.** Escrituração, SPED, folha, apuração and transmission are
  Domínio, Alterdata, Questor, Contmatic, Omie — decades of legislation in code.
  We never compute a tax, never generate a guia, never transmit an obligation.
  We **read what they export** (the guia PDFs, the obligations report) and
  deliver it. Competing with Domínio is a different company.
- **Tax advice from a model.** Not in the bot, not in a skill, not in a
  dashboard sentence. Regime, dedução, "compensa virar MEI?" is professional
  advice with a CRC number behind it; wrong, it is a fine the office pays for.
  Every such question becomes a meeting or a handoff.
- **Holding credentials.** No gov.br, e-CAC, prefeitura or bank password, no
  certificado digital, ever — not stored, not asked for, not accepted when
  offered. Procurações eletrônicas are between the office and the Receita.
- **A third tenancy level.** The office's clients do not get accounts. See
  "The portal" below; `plataforma.md`'s "two levels, not three" holds.

## The data: a carteira under the account

The office is an `account` (plataforma phase 0, built). Its client companies are
rows under it, not tenants:

```
empresas          account_id, cnpj, razao_social, regime ∈ mei|simples|presumido|real,
                  responsavel_id, honorario_mensal, status ∈ ativa|suspensa|encerrada
empresa_contatos  empresa_id, lead_id, papel ∈ socio|financeiro|rh
                  -- one phone may be contact for several empresas: the sócio with three CNPJs
obrigacoes        account_id, regime, tipo, dia_vencimento, dia_limite_documentos
                  -- the office's own calendar, per regime. Data, not code.
pendencias        empresa_id, competencia (AAAA-MM), tipo, estado ∈ aguardando|recebido|conferido|dispensado,
                  recebido_em, canal ∈ whatsapp|portal|email|balcao
guias             empresa_id, competencia, tipo, valor_centavos, vencimento, arquivo,
                  entregue_em, visualizada_em, paga_em
```

Rules worth keeping:

- **Deadlines are rows, never constants.** Legislation moves — FGTS left the 7th
  for the 20th when FGTS Digital arrived in 2024 — and an office sets its own
  document cut-off (the preset's FAQ says "até o dia 5"). A hard-coded calendar
  is wrong on the day the law changes, and nobody is paid to notice.
- **A contact hangs off `leads`**, same reason as the inbox: `leads` is already
  the person record. A prospect who signs becomes an `empresa_contatos` row;
  the lead and its history stay.
- **`guias.valor_centavos` comes from the parsed PDF, never from a model.** It is
  what the office issued. A value no row can back is not rendered.
- **Scoping is the same `account_id` in the query** as every other table
  (`plataforma.md`, "Scoping is enforced in the query"). A skill or a screen that
  reads `empresas` without it is a data leak between accounting offices.

## Produto 1 — Assistente de WhatsApp · **built** (the preset)

`whatsapp-bot/presets/contabilidade.config.ts`, run with
`BOT_CONFIG=presets/contabilidade.config.ts`. It works today as a standalone
container on the office's number; it does not wait for the inbox.

**What it does.** Knows whether it is talking to the carteira or to a prospect
(`consultar_cadastro`). For clients: says what the office is still waiting for
this month, receives files and records them against the pendência after
confirming empresa and competência, sends a guia's second copy, and sets a
monthly reminder when asked. For prospects: qualifies (need, city, revenue band,
employees — one question at a time), records the lead and books a meeting with
the accountant. Anything that is advice, anything about a notificação, malha
fina or blocked CNPJ, goes to a person.

**The backend contract** — what the carteira backend below implements:

| Tool | Request | Returns |
| --- | --- | --- |
| `consultar_cadastro` | `GET /clientes/eu` | is this person a client; their empresas (id, name, regime, responsável) |
| `consultar_pendencias` | `GET /clientes/eu/pendencias?empresa&competencia` | awaiting / received for that month |
| `registrar_envio` | `POST /clientes/eu/envios` | marks a pendência `recebido`, canal whatsapp |
| `segunda_via_guia` | `GET /clientes/eu/guias?empresa&tipo&competencia` | vencimento, valor, link or linha digitável |
| `registrar_interessado` | `POST /interessados` | creates the lead, `origem: whatsapp` |
| `consultar_horarios` / `marcar_conversa` | `/agenda/...` | plataforma module 2 |

**`eu` is the phone header, and this is the one engine change the vertical
needed.** No tool takes a phone number from the model. Every call carries
`x-conversa-telefone`, set by `runTool()` from the conversation row, and the
backend resolves `eu` from it. Before this, the template's own example had the
model fill `telefone` — which for a clinic is an annoyance and for an accounting
office is "me passa o DAS da empresa do número 31 9…" working. The backend must
also check that `empresa` belongs to that phone; the header identifies, the
backend authorises.

**Two tensions, left visible:**

- **"Nunca peça documento" is non-negotiable** in `prompt.ts`, and receiving
  documents is this bot's job. The preset squares it by making the pendência the
  office's statement rather than the bot's request — it reports what
  `consultar_pendencias` listed and says it can be sent here, and asks for
  nothing beyond it. That holds for a model reading carefully. If real
  conversations show the bot refusing to mention pendências, narrow the
  template rule to "documento de identificação" rather than loosening it in the
  preset, which cannot.
- **The file does not reach the backend.** The bot reads a file to text, stores
  the transcript and throws the bytes away (by design — see the bot's
  AGENTS.md). The original stays in the office's WhatsApp, where the team picks
  it up today. For the portal to hold the document, the template needs **media
  passthrough**: `understand.ts` posts the bytes to a configured endpoint before
  transcribing, and `registrar_envio` references what came back. A template
  change, not a preset change, and C1 in the roadmap.

**Proactive reminders are not the bot's cron.** `lembrete_recorrente` reminds
one person who asked, capped at 12. "Documentos de setembro: faltam o extrato e
as notas" sent to the whole carteira on the 1st is a campaign (plataforma
module 3), with suppression, caps and — on the Cloud API — a template approved
by Meta.

## Produto 2 — O portal da carteira

Two screens, two audiences, no new tenancy level.

**For the office, at `/app/carteira`** (behind the `cliente` login that exists):

- **The board: empresas × this competência.** Each cell is the pendência state.
  Sort by "most late". This is the screen the office opens on the 3rd of every
  month, and it replaces a spreadsheet and a lot of "já mandou?".
- **Guias in bulk.** Drop the month's guia PDFs exported by the ERP. Each is read
  locally with `pdftotext` (same reasoning as the bot: local first, it does not
  leave the machine), matched to an empresa by CNPJ, vencimento and valor pulled
  from the text, and anything that does not match is shown as unmatched rather
  than guessed. Deliver to all matched in one action: WhatsApp and the link below.
- **Delivered, and seen.** `entregue_em` and `visualizada_em` per guia. When a
  client says "nunca recebi o DAS" after a fine, this row is the office's
  evidence. Offices will buy the portal for this column alone.

**For the office's clients: a link, not a login.** Each empresa gets a signed,
expiring magic link (`/c/[token]`, scoped to one empresa, revocable) that shows
this month's checklist, an upload box and the guias to download. No password to
forget, and no password for the bot to be asked about. It keeps the empresa a
row under the account rather than a tenant, which is what keeps plataforma at
two levels. The price is that a forwarded link is a forwarded link: short
expiry, re-issued by the bot on request, and a view log.

Uploads through the link land as `pendencias.estado = recebido`, `canal =
portal` — the same state the bot's `registrar_envio` writes, so the board does
not care which channel a document came through.

## Produto 3 — Insight de vendas, for the office's own pipeline

`insight.lead` today helps *us* call a business. The same spine helps the office
answer *its* prospects — people wanting to open a company, go MEI, switch
accountant, or file IRPF.

- **`contabil.lead`** — per interessado: fit against the office's own
  `tabela de honorários` (rows the office enters; the model never proposes a
  price), the three questions the accountant should ask, and what not to say
  before a contract exists. Same `facts.ts` discipline: `observado` must cite.
- **Public CNPJ data as facts.** For a prospect with a CNPJ ("trocar de
  contador"), the Receita's public registry — situação cadastral, CNAE, porte,
  data de abertura, optante do Simples — via a public CNPJ API. "Aberta há 4
  meses, optante do Simples, CNAE de clínica" is an observation with a source,
  and it is exactly the thirty seconds of lookup nobody does before calling back.
- **IRPF season is a campaign, not a skill.** March to May, last year's IRPF
  clients get a reactivation sequence. `posvenda.reativacao` ranks them; the
  sending is plataforma module 3.

**For us, selling to accountants:** `contabilidade` currently maps to the
generic `recorrente` segment in `src/lib/ai/segments.ts`. If the pitch to
offices starts to diverge — it should: the pain is the monthly chase, not lead
follow-up — that is one `OVERRIDES` entry and a new segment, not a rewrite.

## Produto 4 — BI: a carteira em números

`ai-infra.md` module 6, specialised. The charts are counts, not AI:

| Métrica | De onde |
| --- | --- |
| Honorários/mês, clientes ativos, entradas e saídas | `empresas` |
| % da carteira com documentos completos, por dia do mês | `pendencias` |
| Atraso médio de envio, por empresa | `pendencias.recebido_em` vs `obrigacoes.dia_limite_documentos` |
| Guias entregues vs visualizadas | `guias` |
| Esforço por empresa | conversations and messages per empresa (plataforma module 1) |

**Rentabilidade por empresa is the headline.** Honorário ÷ esforço — messages,
late months, handoffs — ranks the clients who cost more than they pay. Every
office suspects which ones; none has the list. `contabil.rentabilidade` is
`financas.preco` specialised: it names reajuste candidates, and every number
carries its formula and inputs (the ai-infra rule: no currency value the
renderer cannot trace to a row).

`painel.narrativa`, weekly and cached: "12 empresas ainda não mandaram o extrato
de agosto; 3 delas atrasaram nos últimos três meses." Every claim links to the
cell it came from.

## Produto 5 — Retenção da carteira

`posvenda.risco` specialised, because churn is what this business dies of:
a client asking for "todos os meus documentos", a declaração de rendimentos out
of season, the word distrato, honorários paid late, a sócio going quiet.
**Flagged to a person, never acted on** — the ai-infra rule, and here a wrong
flag that triggers a discount is honorários given away for nothing.

## Produto 6 — Estratégia: close the loop with Mandra

The part only we can sell. From `empresas` we know which CNAEs and regimes are
the office's most profitable clients; the prospector knows every business of
that kind in the office's city. "Your best clients are clinics on Lucro
Presumido; here are the 140 clinics within 5 km" is `estrategia.plano` feeding
a call list — the office gets new clients from the same tool we use to find it.

## Roadmap

Engineering weeks at one developer. Note what does *not* depend on plataforma
phase 1 (the inbox): the carteira can ship before it.

| Fase | Escopo | Depende de | Semanas |
| --- | --- | --- | --- |
| **C0 — Preset** ✅ built | Bot preset, `x-conversa-telefone`, preset boot test | — | feito |
| **C1 — O arquivo** | Media passthrough in the template; `registrar_envio` references the stored file | — | 1 |
| **C2 — Carteira** | `empresas`, contatos, `obrigacoes`, `pendencias`; the `/clientes/eu` endpoints; the board; magic link | plataforma 0 (built) | 3–4 |
| **C3 — Guias** | Bulk PDF upload, CNPJ match, delivery, `visualizada_em` | C2 | 2 |
| **C4 — Painel** | Métricas da carteira, rentabilidade, narrativa semanal | C2, ai-infra D | 2–3 |
| **C5 — Insight** | `contabil.lead`, CNPJ facts, tabela de honorários | ai-infra B (built) | 1–2 |
| **C6 — Retenção e estratégia** | `risco`, IRPF campaign, the Mandra loop | plataforma 1 and 3 | 2–3 |

C0 to C3 is a product one office can use on its own number in about six weeks,
and C3 is the one they will pay for.

## Perguntas em aberto

- **Which ERP does the first office use?** It decides how guias and the
  obligations calendar get in: an export folder, an API, or a person dropping
  PDFs. Do not integrate until the first office names it.
- **LGPD, twice removed.** These are documents of the office's clients — a third
  party to us. Scanned PDFs and photos go to a vision model (the preset keeps it
  to 3 pages). That has to be in the contract with the office, and the office's
  own contract with its clients has to allow it. Get the paragraph written
  before the first pairing, not after.
- **Price per empresa or flat?** Per empresa in the carteira tracks our cost
  (messages, storage) and the office's value; flat is easier to sell. Decide
  after one office has used C2 for a month.
- **Should a client see its own pendências in the portal**, or only hear about
  them on WhatsApp? Some offices will not want a list that makes their own
  delays visible too.
- **Magic link lifetime.** Short is safer and more annoying. Start at 7 days,
  re-issued by the bot, and look at the view log.
