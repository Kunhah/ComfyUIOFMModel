# Analytics

`/admin/analytics` — seis telas sobre o que o tráfego faz, medido pelas
próprias páginas. A pergunta que esta seção existe para responder não é
"quantos cliques", é **o que mudar em seguida**.

## Por que não só o Google Analytics

O Google Ads e o GA respondem bem "quantos" e muito mal "por que menos". Para
saber que dois terços de quem leu a lista de entregáveis nunca chega à faixa
final é preciso definir eventos e um funil personalizados — e, no momento em
que você está definindo tudo isso, os dados podem muito bem ficar num arquivo
nosso, em SQL, sem amostragem, sem banner de consentimento e sem depender de
uma conta que alguém pode perder o acesso.

A tag do Google continua ali, para a única coisa que só ela faz: alimentar o
lance. As duas camadas medem coisas diferentes e não competem.

## O que é medido

**O site inteiro, não só os anúncios.** Até esta versão, as landing
pages eram medidas e a home — a página em que cai todo visitante orgânico e
todo mundo que digita o nome — não produzia dado nenhum. "Onde perdemos a
pessoa" era respondível para a metade paga do negócio e não respondível para a
outra.

O que pode se medir está em `src/lib/analytics/pages.ts`, e o coletor recusa
qualquer página fora dessa lista. Cada página tem um **template**, e cada
template tem o seu próprio funil:

| Template | Páginas             | Funil                                    |
| -------- | ------------------- | ---------------------------------------- |
| `site`   | Home                | as oito faixas de `(marketing)/page.tsx` |
| `ads`    | as landing pages    | as seis faixas de `(ads)/[slug]`         |
| `legal`  | Privacidade, Termos | nenhum, de propósito                     |

As páginas legais são medidas e não têm funil: não há o que converter nelas, e
um gráfico sugerindo o contrário não significaria nada. O que a contagem serve
é ao resto do site — um salto de leituras ali é um sinal sobre as páginas que
linkam para lá.

## O que é coletado, e o que não é

Coletado: a seção que entrou na tela e por quanto tempo, o toque em ligar ou
WhatsApp e em que posição, a abertura de uma pergunta, a profundidade de
rolagem, o tempo até a primeira rolagem, **cliques em coisas que não fazem
nada**, a faixa em que a pessoa estava ao sair, o dispositivo, a largura da
tela, o **host** de origem e os parâmetros de campanha da URL.

**Não** coletado: endereço IP, cookie, identificador que atravesse sites ou
visitas, e a URL de origem completa — só o host. O identificador de sessão é
uma string aleatória em `sessionStorage`: ele morre com a aba.

Isso não é só cortesia. IP é dado pessoal sob a LGPD; uma página que não coleta
nenhum não tem consentimento a pedir, e é por isso que não há banner.

## As seis telas

**Visão geral** — entrega a pergunta em vez de esperar que você a traga. Diz,
em frases, a maior perda do funil, o que as pessoas clicam que não funciona e
onde estavam quando desistiram. Os contadores ficam _abaixo_ das conclusões de
propósito: um número no topo de uma tela é lido como o assunto, e a contagem de
sessões nunca é o assunto — é o tamanho da amostra de tudo que vem depois.

**Páginas** — o funil por faixa, e ao lado dele quanto tempo cada faixa
segurou alguém. O funil conta uma faixa como vista quando um terço dela cruza a
tela, o que é certo para "chegaram lá" e não diz nada sobre "leram". Uma faixa
que todos alcançam e ninguém lê aparece no funil como um degrau sem perda — ou
seja, como um acerto.

**Comportamento** — atrito, não progresso. É a tela dos **cliques mortos**, a
única cujas linhas viram uma mudança sem nenhuma interpretação: cada uma é
alguém que quis avançar, tentou, e não recebeu nada de volta. Um título com
cara de botão. Um cartão que parece tocável. Um telefone escrito como texto
numa página cujo trabalho inteiro é telefone.

**Aquisição** — de onde vem e em que horário. Leia depois das outras: mexer em
lance numa página que perde dois terços dos leitores na mesma faixa só compra a
mesma perda por outro preço.

**Comercial** — o que acontece _depois_ do toque no telefone. As outras telas
param no clique porque é a última coisa que um navegador vê, e o negócio
inteiro acontece depois dele. Uma landing page convertendo a 9% em ligações que
ninguém atende é pior que uma convertendo a 4% em ligações que fecham.

**WhatsApp** — se o agente está funcionando, não se está rodando. Um agente que
responde tudo em quatro segundos e nunca produz um agendamento é um beco sem
saída muito responsivo.

## Regras de leitura embutidas nas telas

- Toda taxa aparece ao lado da contagem que a gerou, e abaixo de trinta sessões
  a tela avisa que a porcentagem descreve um punhado de pessoas.
- Os tempos são **medianas**, nunca médias — uma aba esquecida aberta no almoço
  move a média em minutos e a mediana em nada.
- **O funil exige um escopo de uma forma só.** Um funil somando a home e uma
  landing page mostraria degraus que não existem em página nenhuma, então a
  tela se recusa a desenhá-lo até que você escolha uma página ou um tipo — e
  diz isso, em vez de mostrar um gráfico vazio que parece falta de dado.
- **"Sem resposta" fica ao lado do tempo de resposta.** Uma mediana de resposta
  é calculada só sobre o que foi respondido, então uma conversa abandonada não
  entra nela: a falha é invisível exatamente na estatística que deveria pegá-la.

## Onde as peças ficam

| Peça                                 | Arquivo                                 |
| ------------------------------------ | --------------------------------------- |
| Contrato de eventos e os funis       | `src/lib/analytics/events.ts`           |
| Registro de páginas mensuráveis      | `src/lib/analytics/pages.ts`            |
| Esquema, escrita e consultas         | `src/lib/analytics/db.ts`               |
| Leitura dos filtros da URL           | `src/lib/analytics/scope.ts`            |
| Funil comercial (lê `prospector.db`) | `src/lib/analytics/commercial.ts`       |
| Números do agente (lê `wa_*`)        | `src/lib/analytics/whatsapp.ts`         |
| Coletor público                      | `src/app/api/v1/analytics/route.ts`     |
| Medidor no navegador                 | `src/components/analytics/tracker.tsx`  |
| Peças de tela compartilhadas         | `src/components/admin/analytics/`       |
| As seis telas                        | `src/app/admin/(crm)/analytics/`        |
| Banco                                | `data/analytics.db` (ou `ANALYTICS_DB`) |

O banco é um arquivo SQLite **separado** de `prospector.db` e de `b2b.db`, pelo
mesmo motivo que aqueles dois são separados entre si: esquemas sem relação e
ciclos de vida sem relação. Este aqui é descartável — apagar o arquivo perde
histórico e nada mais.

As telas Comercial e WhatsApp leem `prospector.db`, não este arquivo. Os dois
bancos **não são cruzados**, e isso é deliberado: a sessão de página é anônima
por construção e um lead é uma empresa com nome e telefone. Cruzar os dois
seria justamente a coisa que esta camada inteira foi feita para não fazer. O
que eles compartilham é o período, para que as duas metades descrevam as mesmas
semanas.

## O disco

O site, o coletor e o painel são **o mesmo contêiner**, com `data/` num volume.
O beacon é sempre da mesma origem e a rota não responde CORS.

Se o processo que renderiza o painel não conseguir escrever o banco,
`/admin/analytics` mostra um aviso com o caminho tentado em vez de uma tela
zerada. Zero por estar quebrado é idêntico a zero por não haver tráfego, que é
a pior classe de bug deste repositório.

## Marcação das campanhas

A coluna "por palavra-chave" depende de a campanha escrever o termo na URL. A
string exata está em `src/lib/analytics/tagging.ts` e a própria tela de
Aquisição a mostra, pronta para copiar, quando detecta sessões pagas sem termo.

Sem isso a tabela mostra "(sem termo)" para todo mundo. A sessão ainda conta
como paga, porque o `gclid` o Google acrescenta sozinho.

## Como medir algo novo

Um elemento passa a ser medido só por carregar um atributo — nada precisa
importar o medidor:

- `data-section="<nome>"` numa `<section>` adiciona um degrau ao funil. O nome
  precisa estar no funil do template daquela página, em `events.ts`, na ordem
  em que aparece. Essa lista _é_ o funil.
- `data-ads-action="call"` ou `"whatsapp"` num link o torna uma conversão, e
  `data-placement="<posição>"` diz onde ele está.
- `data-faq="<pergunta>"` num `<details>` registra a abertura.
- `data-dead-label="<rótulo>"` troca o texto com que um clique morto aparece na
  tabela, para quando o texto do elemento não ajudaria.

Uma **página** nova passa a ser medida entrando em `pages.ts` e montando
`<PageTracker page="<slug>" />`. O coletor recusa qualquer outra coisa, e os
slugs do site vivem no mesmo espaço de nomes dos slugs de anúncio — há um teste
que falha se os dois colidirem, porque um grupo de anúncios chamado `home`
tomaria silenciosamente a linha, o funil e o histórico da home.

## O que ele nunca deve fazer

- **Atrasar um toque.** O `tel:` nunca espera um beacon. Analytics que custa
  uma ligação é prejuízo numa página cujo único trabalho é ligação.
- **Derrubar a página.** Toda chamada é envolvida e uma falha de envio é
  descartada, não repetida.
- **Guardar dado pessoal.** Se algum campo novo puder identificar alguém, ele
  não entra. O rótulo de um clique morto é construído a partir do DOM — é o
  único campo desta superfície que não vem de uma lista que escrevemos — e por
  isso é cortado em sessenta caracteres.
