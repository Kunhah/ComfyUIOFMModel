# Ligando o site de um cliente ao CRM

Cada cliente tem o site em um repositório próprio, hospedado onde fizer sentido
— Netlify, Vercel, uma VPS, um WordPress. Nada aqui pressupõe framework, pacote
ou etapa de build: a integração inteira são **uma tag, duas variáveis de
ambiente e uma chamada HTTP**.

O kit pronto de cada cliente, já com a chave dele, está em
`/admin/contas/<slug>`. Este documento é a referência por trás dele.

## O atalho: o `CLAUDE.md` pronto

Em `/admin/contas/<slug>` há um `CLAUDE.md` gerado para aquela conta, já com a
chave, o endpoint e os domínios liberados. Salve na **raiz** do repositório do
site, com esse nome exato — é o arquivo que o Claude Code lê em toda sessão, e é
o que faz quem constrói o site já começar sabendo que este CRM existe. Sem ele a
coisa razoável a fazer é inventar um formulário que não chega a lugar nenhum.

O resto deste documento é a referência por trás dele.

## A ordem importa

1. **Crie a conta** em `/admin/contas`. É o cliente, não o site.
2. **Crie o site** em `/admin/sites` e escolha a conta no campo **Conta**.
   Pulando esse campo o site fica como nosso, e os contatos do formulário dele
   entram no _nosso_ pipeline. O portal do cliente segue vazio e nada relata
   isso — é a falha silenciosa mais cara desta integração.
3. **Crie o acesso** em `/admin/contas` → _Novo acesso_. Sem isso a conta existe
   e o cliente nunca a viu.
4. **Cole o kit** no repositório do site.

## O caminho curto: a tag

```html
<script src="https://SEU-CRM/atlas-crm.js" data-key="atlas_..." defer></script>
```

E qualquer formulário marcado com `data-atlas-crm`:

```html
<form data-atlas-crm>
  <input name="nome" required placeholder="Seu nome" />
  <input name="email" type="email" placeholder="Seu e-mail" />
  <input name="telefone" placeholder="WhatsApp" />
  <textarea name="mensagem"></textarea>
  <button type="submit">Enviar</button>
</form>
```

O script cuida do envio, do estado de carregando, da mensagem de erro e do
honeypot. Os nomes dos campos valem em português ou inglês (`nome`/`name`,
`telefone`/`phone`) porque renomear um input em um site no ar é exatamente a
edição que quebra a analytics de alguém. Qualquer campo que ele não reconheça
vai junto, sob o rótulo visível, e vira uma linha na nota do lead.

## O caminho longo: HTTP direto

Mesmo endpoint, para quando o envio sai do servidor — um route handler do Next,
uma Server Action, um back-end em qualquer linguagem.

```
POST https://SEU-CRM/api/v1/leads
content-type: application/json
```

```jsonc
{
  "key": "atlas_...", // obrigatório: identifica o site
  "name": "Maria Silva", // obrigatório
  "email": "maria@ex.com", // e-mail OU telefone é obrigatório
  "phone": "+55 31 98888-7777",
  "message": "Gostaria de um orçamento.",
  "company": "Padaria da Maria",
  "city": "Belo Horizonte",
  "uf": "MG",
  "pageUrl": "https://cliente.com.br/contato",
  "fields": { "Como nos conheceu": "Instagram" },
}
```

| Resposta | Significado                                                                                        |
| -------- | -------------------------------------------------------------------------------------------------- |
| `201`    | Lead novo.                                                                                         |
| `200`    | Já conhecíamos essa pessoa; os dados de contato foram atualizados e a mensagem anexada.            |
| `202`    | Honeypot preenchido. Respondido como sucesso de propósito: um bot que ouve "falhou" tenta de novo. |
| `400`    | Falta nome, ou falta e-mail e telefone. O corpo traz `{ error }` legível.                          |
| `401`    | Chave desconhecida.                                                                                |
| `403`    | Site desativado, ou origem fora da lista de domínios.                                              |
| `429`    | Limite de envios. Respeite o `Retry-After`.                                                        |

## O que protege o endpoint

A chave **não é segredo** — ela viaja no HTML de um site público, e tratá-la
como senha só impediria mostrar ao cliente a própria chave. Quem limita o
endpoint é:

- **A lista de domínios.** O navegador manda a origem exata da página, então uma
  origem errada é recusada. Uma requisição _sem_ origem passa: é o que permite
  integração pelo servidor, e recusá-la não impediria nada — `curl` manda a
  origem que quiser.
- **O limite por IP e por site**, que é o que de fato limita o estrago.
- **O honeypot**, que pega os bots que preenchem tudo o que encontram.

**Liste o apex e o `www` separadamente.** Um site que responde nos dois com só
um liberado tem um formulário que funciona para metade dos visitantes, e nada
em lugar nenhum relata isso.

## Trocar a chave

`/admin/sites` → _Trocar chave_. O formulário do cliente para de funcionar até o
trecho no site dele ser atualizado, então isso é uma edição combinada com quem
mantém o repositório — não uma manutenção de rotina.

## O que o cliente recebe

`/app`, com login próprio: os contatos dele, o estágio de cada um, notas e data
de retorno. Só os leads da conta dele — a separação é imposta na consulta, não
na tela, e tem teste próprio em `src/lib/prospector/scope.test.ts`.
