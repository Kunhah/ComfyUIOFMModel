# Mandra Prospector

Internal prospecting tool for Mandra. Pick a niche, a country and an area, get
back local businesses ranked by how badly they need what we sell — starting with
the ones that have no website at all but do have a WhatsApp number.

It started Brazil-only and still ships that way: the committed city index covers
Brazil, and prospecting anywhere else means one extra sync
(`npm run sync -- --countries PT,ES`). The country registry in
`src/lib/countries.ts` carries the ~65 countries the pipelines know how to read —
bounding box, dial code, mobile numbering rule, opener language — and the picker
offers whichever of them your extract actually holds.

Not customer-facing. It's a route on the marketing site — `/prospector` — but it
is `noindex`, `Disallow`ed in robots.txt, and its whole data layer is local
files, so in practice it runs on your machine.

Its sibling, **[Prospector B2B](prospector-b2b.md)**, works the other way round:
companies that _do_ have a website — industry, engineering, health, finance,
wholesale, logistics, anywhere in Europe — crawled for the e-mail address of
somebody who can sign. Same tone block, same SQLite-and-CSV plumbing, different
sale. It is the second tab on this same screen, so moving between the two is a
click and not a page load; `/prospector/b2b` opens it directly.

## Getting started

The tool lives inside the `Website/` app: pages under `src/app/prospector/`,
API under `src/app/api/prospector/`, engine under `src/lib/prospector/`. Run it
from the repo root:

```bash
npm run prospector     # http://localhost:3000/prospector
```

That's the whole thing, first run included. `npm run prospector` is a launcher
(`scripts/prospector/start.mjs`): it checks what's actually missing, runs only
that, and then starts the dev server. On a fresh clone it installs dependencies,
downloads the extract and builds the city index; on every run after, it finds
nothing to do and boots straight away.

It starts the _site's_ dev server — there is one app now, not two. Use
`npm run dev` when you're working on the marketing pages and want to skip the
checks.

It is checking for specific failures rather than just whether files exist:

| Situation                                    | What it does                                                                                            |
| -------------------------------------------- | ------------------------------------------------------------------------------------------------------- |
| dependencies not installed                   | `npm install`                                                                                           |
| extract missing                              | `npm run sync`                                                                                          |
| extract truncated or empty                   | `npm run sync` — a killed download leaves a file that opens and then fails mid-query                    |
| city index missing or corrupt                | `npm run cities`                                                                                        |
| city index older than the extract            | `npm run cities` — syncing without rebuilding leaves the picker describing data that is no longer there |
| extract from a different Overture release    | warns, so the header can't claim one release while querying another                                     |
| port already in use                          | says it's already running and stops, instead of failing on `EADDRINUSE`                                 |
| leftover `.partial` from an interrupted sync | deletes it                                                                                              |

```bash
npm run prospector:check    # report what's missing, change nothing (exit 1 if any)
npm run dev                 # skip all checks, plain next dev

# from Website/
node scripts/prospector/start.mjs --port 3999
node scripts/prospector/start.mjs --force-sync
```

Or step through it by hand:

```bash
npm install
npm run prospector:sync      # one-time, ~2 min — see below
npm run prospector:cities    # rebuilds the city index from it
npm run dev                  # http://localhost:3000/prospector
```

| Script (from the repo root)  | What it does                                                                                                          |
| ---------------------------- | --------------------------------------------------------------------------------------------------------------------- |
| `npm run prospector`         | **Check what's missing, fix it, then start.** The one you want.                                                       |
| `npm run prospector:check`   | Report what's missing and exit                                                                                        |
| `npm run prospector:sync`    | **Download the business extract.** Brazil by default; `-- --countries PT,ES` for more. Run once per Overture release. |
| `npm run prospector:cities`  | Rebuild the searchable city index. **Run after every sync.**                                                          |
| `npm run prospector:harvest` | **Fill the CRM in bulk**, sweeping city × niche. What stocks a 100-a-day calling queue.                               |
| `npm run dev`                | Dev server, no checks (Turbopack)                                                                                     |
| `npm run build` / `start`    | Production build / serve it                                                                                           |

Inside `Website/` the same things are `npm run up`, `check`, `sync`, `cities`,
`harvest`.

`sync` then `cities`, in that order — the city index and its counts are derived
from the extract, so running the sync alone leaves the picker describing the old
data.

Both commands resolve `data/` from the working directory, so run them from
`Website/` or through the root scripts above — from anywhere else they'll build
a second extract where nothing will look for it.

## Why the data source is Overture and not Google

The obvious source is the Google Places API, and it is the wrong one here.

Google's Maps Platform terms only let you store `place_id` indefinitely and
coordinates for 30 days. **Business names, phone numbers and ratings must be
fetched live and cannot be warehoused.** A prospecting tool is a warehouse of
names and phone numbers by definition, so the entire product would sit outside
the licence — including the CSV export.

[Overture Maps](https://overturemaps.org) is open data under CDLA Permissive 2.0.
Free, no API key, no quota, and explicitly storable and redistributable. It is
also _better_ for this job than the free alternative — measured on hair and
beauty businesses in Belo Horizonte:

| Source                   | Businesses found |
| ------------------------ | ---------------- |
| OpenStreetMap (Overpass) | 68               |
| Overture Maps            | 4,612            |

OSM simply does not have Brazilian SMBs. Overture merges Meta and Microsoft
place data and does.

The board includes **OpenStreetMap** by default. This is an additive, live
search of the selected niche's OSM tags, not a replacement for Overture: it
occasionally finds a locally mapped business absent from Overture, then removes
likely duplicates by name plus phone, address, or nearby coordinate. It is on by
default and fails open — if the shared public Overpass service is busy, the
complete Overture result still returns. Rows and CSVs retain their `fonte`
(`overture` or `openstreetmap`) so the supplement is always auditable.

For a third, independent POI index, set `GEOAPIFY_API_KEY` in `.env`. Geoapify
is queried by the selected niche and city bounding box, then its records are
deduplicated against the open sources and used to fill missing phone, website,
email, and social fields on a matched business. It is optional: with no key the
two open sources remain the complete search, and a Geoapify failure never hides
their results. Geoapify's Places API requires an API key and at least one
category, which is why the integration has a maintained per-niche category map.

What comes back per business: name, category, street address, city, state,
phone, website, social profile, sometimes email, coordinates, and a 0–1
confidence score. Roughly 88% have a phone number.

## The local extract (`npm run sync`)

**This is the one setup step, and skipping it makes the tool unusable rather than
just slow.**

The Overture places dataset is a single unpartitioned set of Parquet files
covering the planet. Nothing about it is organised geographically, so a query
can only be pruned via Parquet row-group statistics — which still means fetching
metadata for the whole world. Measured, querying S3 per search:

| Mode                          | Time per search             |
| ----------------------------- | --------------------------- |
| Remote (S3, no extract)       | 90s – 230s, highly variable |
| Local (`data/places.parquet`) | **0.2s – 0.6s**             |

So `npm run sync` pulls the countries you ask for, once, filtered to the
categories in `src/lib/prospector/niches.ts`, and writes `data/places.parquet`
(the file used to be `data/br-leads.parquet`, back when Brazil was the only
option; an existing one is still read when it is all there is):

```
1,768,794 businesses · 1,098,965 with no website · 122 MB
```

then `npm run cities` turns that into the searchable index,
`src/data/prospector/cities.json`:

```
6,215 cities · 1,765,436 of 1,768,794 businesses reachable (99.8%)
```

### Prospecting outside Brazil

```bash
npm run sync                                  # Brazil — or PROSPECTOR_COUNTRIES from .env
npm run sync -- --countries PT,ES,MX          # those three instead
npm run sync -- --region "Europa Ocidental"   # a whole part of the world
npm run sync -- --add --countries DE          # keep what you have, add Germany
npm run sync -- --all-countries               # everything in the registry
npm run sync -- --list                        # the codes and regions on offer
npm run cities                                # always, afterwards
```

Each country is another slice of the planet-wide scan, so a run costs roughly
5–20 minutes per country and the file grows accordingly. `--add` reads
`data/extract.json` to know what the current extract covers and widens it;
without it a sync _replaces_ the extract, which is what you want when narrowing
back down.

For a persistent international setup, set `PROSPECTOR_COUNTRIES=BR,PT,ES,MX,US`
in the deployment environment. Subsequent plain syncs keep that market; command
line `--countries` still overrides it for one-off extracts.

The picker then offers only the countries in the index, grouped by part of the
world. Two things follow the country rather than being global:

- **The state code.** Brazil has 27 codes we trust and validate; elsewhere the
  region is whatever Overture carries, normalised into an opaque grouping key, and
  for some countries it is empty on every record. A city with no region is matched
  on country, locality and bounding box alone — which is why `uf` is optional in
  a search URL now.
- **The phone.** `mobile` in the country registry says what a mobile number looks
  like there, and that decides both the WhatsApp button and the "com WhatsApp"
  count. Countries whose plan cannot separate mobiles from landlines (the US and
  Canada) carry `null` and get no button — a wa.me link to a landline opens a dead
  chat, and guessing is worse than saying nothing. The opener itself is written in
  Portuguese, Spanish or English per the registry's `speaks` field.

The parquet is gitignored — it is derived data, and 122MB does not belong in git.
The app falls back to querying S3 directly when it is missing, so a fresh clone
works, but the UI shows a warning telling you to run the sync.

**Re-run both** when Overture publishes a new release (roughly monthly, bump
`OVERTURE_RELEASE`) or **whenever you add a niche** — new categories are not in
the existing extract and would silently return zero results, which looks like
"no businesses here" rather than "not synced".

The sync filters on `addresses[1].country IN (…)`, which is not the same thing as
the bounding box. The box is the union of the selected countries' boxes, so it
covers everything in between and beyond: the Brazil box alone also covers
Paraguay, Uruguay, Bolivia and parts of Argentina, Chile, Peru and Colombia, and
without the country test the extract carried **284k foreign businesses** while the
city picker offered Asunción, Santiago, Córdoba and Santa Cruz de la Sierra.

## Filling the CRM in bulk (`npm run harvest`)

A search puts its leads in the CRM by running, which is the right shape for
working a market you have chosen and the wrong one for stocking a queue. Cold
calling at a hundred dials a day eats the base far faster than a person can
click through city-and-niche combinations: two niches across three cities is
737 leads, about a week, and the extract behind it holds 1,14 million Brazilian
businesses with no website.

`npm run harvest` is that same search run for every combination, unattended:

```bash
npm run harvest                                    # top 25 cities, every niche
npm run harvest -- --uf SC,PR,RS                   # only the south
npm run harvest -- --cities 100                    # the hundred biggest markets
npm run harvest -- --niches odontologia,padarias   # two niches, nationwide
npm run harvest -- --dry-run                       # the plan, and nothing else
```

| Flag           | Meaning                                                             |
| -------------- | ------------------------------------------------------------------- |
| `--cities N`   | How many cities to sweep, biggest first (default 25)                |
| `--uf SC,PR`   | Restrict to these state codes                                       |
| `--country BR` | Which country's cities, from the index (default `BR`)               |
| `--niches a,b` | Only these niches (default: all of them)                            |
| `--limit N`    | Rows per search (default 5000, the engine's ceiling)                |
| `--conf N`     | Confidence floor, 0–1 (default 0.5)                                 |
| `--min-pool N` | Skip cities with fewer than N website-less businesses (default 200) |
| `--all`        | Include businesses that already have a website                      |
| `--osm`        | Also query OpenStreetMap (off in bulk — see below)                  |
| `--fresh`      | Ignore saved progress and sweep everything again                    |
| `--dry-run`    | Print the plan and exit                                             |

**It calls `performSearch`, it does not reimplement the query.** Same scoring,
same dedupe, same niche-from-category rule, same writes — which is the only way
the bulk path and the interactive one cannot drift. The script's own decisions
are just which combinations to run and in what order.

Cities are ranked by their **website-less** count, not their total. That is the
pool the pitch is for, and the two orders disagree enough to matter.

**OpenStreetMap is off by default here and only here.** Overpass is a shared
public service; the interactive search hits it once, and a sweep would hit it
once per combination — thousands of times. Overture alone is already the
complete local answer, and the supplement is also the slowest part of every
search.

The sweep is resumable. `data/harvest.json` is rewritten after each combination,
so a crash, a Ctrl-C or a closed lid costs one search rather than the run — which
matters when a national sweep is tens of thousands of them. A second Ctrl-C
exits immediately; the first lets the search in flight finish and saves.

Re-running a combination is harmless: persistence is keyed on the Overture id,
so an already-known business is updated rather than duplicated, and the run
reports it as not new.

It finishes by printing the phone pool — how many leads have a number worth
dialling, how many are available today, and what that is in days at a hundred
calls a day. That last number is the one to plan on, not the lead total: leads
with no phone, shared switchboards and dead numbers are all in the base and none
of them are a call.

## Searches are URLs

A search is fully expressed in the query string, and the server renders the
results before sending the page — so a link arrives with its table already
populated, and works with JS disabled:

```
/?niche=barbearias-saloes&city=Belo%20Horizonte&uf=MG
/?niche=pet&city=Manaus&uf=AM&conf=0.7
/?niche=restaurantes&city=S%C3%A3o%20Paulo&uf=SP&all=1
/?niche=barbearias-saloes&country=PT&city=Lisboa&save=0
/?niche=energia-solar&scope=state&uf=SP&all=1
/?niche=energia-solar&scope=region&region=sudeste&all=1
/?niche=energia-solar&scope=country&country=BR&all=1
```

| Param         | Meaning                                                                |
| ------------- | ---------------------------------------------------------------------- |
| `niche`       | slug from `src/lib/prospector/niches.ts`                               |
| `country`     | ISO-3166 alpha-2, must be in the index. Defaults to `BR`               |
| `scope`       | `city` (default), `state`, `region`, or `country`                      |
| `city` / `uf` | must match the city index; `uf` disambiguates repeated names, optional |
| `region`      | Brazilian macro-region slug, such as `sudeste` or `nordeste`           |
| `conf`        | confidence floor, 0–1 (default 0.5)                                    |
| `all=1`       | include businesses that already have a website                         |
| `save=0`      | run the search without writing anything to the history                 |

Handy for sending someone a specific list, and it's the quickest way to confirm
the data layer is alive without touching the form.

State and macro-region scopes are available for Brazil; every indexed country
can be searched as a whole. Broad searches use the local Overture extract only:
the live OpenStreetMap and Geoapify supplements are city-bounded services and
would return an incomplete slice if asked to cover a state or country.

## How a search works

```
niche          ──▶ src/lib/prospector/niches.ts   ──▶ Overture category list
country + city ──▶ src/data/prospector/cities.json ──▶ bbox + region + country
                    │
                    ▼
         data/places.parquet  (DuckDB, one scan)
                    │
                    ▼
         src/lib/prospector/score.ts       ──▶ 0-100 score + pt-BR reasons
                    │
                    ▼
              board  ·  CSV  ·  wa.me link
```

Three things in that pipeline are load-bearing and easy to break:

**The city bounding box is not an optimisation, it is correctness.** Brazil
reuses city names heavily — "Bom Jesus" exists in a dozen states — and the planet
reuses them harder still: Santiago is a city in Chile, in Spain and in Rio Grande
do Sul. The query filters on country _and_ bbox _and_ normalised locality name
_and_ state code where there is one. Drop any of them and you merge unrelated
municipalities. The bbox also can't be used alone: it is a rectangle, so a Belo
Horizonte box catches Ibirité too.

**The city index is built from the extract, not from Overture's boundaries.** The
boundaries say what a municipality is _called_; the business records say what
their addresses actually _say_. Where those disagree, a boundary-derived index
makes the city unsearchable — and they disagree more than you'd expect. Brasília
was the worst case: Overture models the Federal District as 35 administrative
regions (Plano Piloto, Ceilândia, Taguatinga…) with no locality named "Brasília"
at all, while the businesses there give exactly that. **7,283 businesses, 2,390 of
them with no website, returned nothing.** Deriving the index from the places side
makes that class of bug structurally impossible: a name is in the index because
businesses use it. Boundaries are still read, but only for typeset display names.

**The category strings in `niches.ts` are copied from the live vocabulary**, kept
in `src/data/prospector/overture-categories.csv` (every category with ≥20 businesses in São
Paulo). An invented category name matches nothing and fails silently. Add
categories from that file, then re-run `npm run sync`.

**Stats are computed in SQL over every match, not over the returned page.** The
page is capped by `limit`, so counting the returned rows would report the limit
back as if it were the size of the pool ("2,875 without a website" would read as
"1,000"). The reachability counts are additionally scoped to the rows actually
shown, otherwise a filtered search reports more contactable leads than leads.

## Matching a city the way people type it

`normalise()` in `src/lib/prospector/cities.ts` folds away case, accents **and punctuation**,
and `overture.ts` repeats the same folding in SQL. The two have to agree exactly —
if they drift, a city resolves in the picker and then returns zero rows.

Punctuation is not cosmetic here. Overture's boundary names are typeset
("São João del-Rei", "Itapecuru-Mirim") while the records write them plainly
("Sao Joao del Rei"), and an accent-only normaliser stranded real municipalities.
On top of that:

- A trailing state code is split off the query, so `belo horizonte mg` works.
- The same split happens at sync time on the data side, because plenty of records
  put the state inside the city field — `"Belo Horizonte, MG"`, `"São Paulo SP"`.
  Left alone each becomes a near-duplicate city holding a handful of businesses.
  It is only applied when the record's own state agrees, so a row claiming
  `"Curitiba - Pr"` in Pará is left exactly as it is rather than quietly rewritten.
- **A missing state is not a reason to drop a lead.** 15,182 records give a city
  and no region. Once bbox and locality match, the state code has nothing left to
  disambiguate, so the query accepts `uf IS NULL`. The index only folds those rows
  into names that occur in exactly one state, which is what stops them being
  credited to the wrong "Santa Luzia".
- The picker ranks by business count, not bounding-box area. Area was a bad proxy:
  sprawling Amazonian municipalities have enormous boxes and almost no businesses,
  so they outranked the capitals people were actually typing.

Alternate spellings live in a hand-written `ALIASES` list in
`scripts/prospector/build-city-index.mjs`. That started as fuzzy matching — pair each unused
boundary name with its nearest unreachable locality above a Jaro-Winkler cutoff —
and it had to be thrown away: 13 of the 19 pairs it produced joined genuinely
different municipalities ("Capão Bonito do Sul" to "Capão Bonito", "Alagoinha do
Piauí" to "Alagoinha"). A wrong alias is worse than a missing one, because the
search succeeds and returns another town's businesses. Add pairs only when you
have confirmed they are one municipality.

## Niches

43 niches over 84 Overture categories, grouped into 10 families so the dropdown stays
navigable. **A category belongs to exactly one niche**, and `niches.ts` throws at
import if that is ever violated.

That rule is not theoretical. `nail_salon` was in both "barbearias-saloes" and
"estetica" — 17.624 businesses under two niches at once. Worse, a lead's stored
niche was whichever search had touched it last, so of the 133 nail salons already
saved, 61 sat under one and 72 under the other, purely by search order. Every
per-niche count was fiction.

Two changes fix it for good:

- **A lead's niche is derived from its own Overture category**, never from the
  search that found it. Same lead, same niche, whatever you searched for.
- **Overlap is caught at import.** The reverse map is also what the sync script
  reads, so the extract and the niche list cannot disagree.

The niches were also split much finer than the original 12. "Restaurantes" bundled
16 categories and matched 32.895 businesses in São Paulo — against the 1.000-row cap
you could never see past the first 3%. Pizzarias, padarias, bares, cafeterias and
hamburguerias are separate now, which is also how the pitch differs.

Verified against the extract when the vocabulary was 33 niches: they summed to
**1.768.794**, exactly the row count, with nothing double-counted and nothing
unmapped. The import-time overlap check is what keeps that property true as
niches are added; the figure itself is only as current as the last re-count.

**Regrouping categories needs no re-sync** as long as they're already in the extract
— every saved lead's niche is rebuilt from its category on next start (`reniche()` in
`db.ts`, keyed on a fingerprint of the vocabulary). Adding a category that isn't in
the extract does need `npm run sync`.

Old slugs stop resolving, so a bookmarked deep link using one returns "Nicho
desconhecido." instead of quietly searching something else.

### Marketing e parcerias — the one family that isn't a prospect list

Eight of the nine families are businesses to sell a site to. The ninth is people
to sell _with_: gestores de tráfego, marketing and advertising agencies, and
design/creation shops. A niche declares this with `intent: "parceiro"`
(everything else is `cliente`, which is what every niche was before this
existed).

| Niche                               | Overture categories                                                                                 |
| ----------------------------------- | --------------------------------------------------------------------------------------------------- |
| Gestores de tráfego                 | `internet_marketing_service`, `marketing_consultant`, `business_advertising`                        |
| Agências de marketing e publicidade | `marketing_agency`, `advertising_agency`, `media_agency`, `social_media_agency`, `public_relations` |
| Design e criação                    | `graphic_designer`, `product_design`                                                                |

The trade is symmetric and that is the whole pitch: a gestor de tráfego running
campaigns for a shop with no site is burning their client's budget on a link with
nowhere to land, and we sell exactly that landing page — while every business we
close a site for eventually asks who runs their ads. The opener says so in the
first line (`partnershipMessage` in `score.ts`, pt/es/en like the client one) and
offers a referral split in both directions rather than a free demo.

Three things change automatically once a niche is `parceiro`:

- **The "só quem não tem site" filter is forced off**, not defaulted off. An old
  link carrying `?all=`, or plain habit, must not be able to turn a partner
  search into an empty one — and the businesses it would keep are precisely the
  dormant one-person outfits.
- **Qualification runs the other way round** (`scorePartner`, below).
- **Every existing screen follows without being changed.** The intent is derived
  from the business's own Overture category — `intentForCategory()`, the same
  direction `nicheForCategory()` already runs in — so the WhatsApp button in the
  CRM, the CSV export and the history page each offer a marketing agency a
  partnership opener without knowing anything about parcerias. An unmapped
  category is a `cliente`, which is what an unclassified business always was.

`web_designer` is deliberately not in any niche: that is a competitor, not a
partner, and including it would fill a parcerias search with agencies selling the
one thing Mandra sells.

### The Receita Federal register (`npm run sync:cnpj`)

The map half of a partner search finds agencies. It cannot find the trade's
largest population, and no amount of category tuning will: **a gestor de tráfego
works from a laptop and has no storefront to survey**, so Overture has never
heard of them. The Receita has heard of every one that formalised, because
formalising is what being in that register means.

`npm run sync:cnpj` builds `data/cnpj.parquet` from the Receita's open CNPJ
data — a second extract beside `places.parquet`, never merged with it, queried
by `src/lib/prospector/cnpj.ts`. `performSearch` runs it only for `parceiro`
niches, at every scope, and merges the result through the same
`mergeSupplementary` used for OpenStreetMap.

Measured on one of the ten Estabelecimentos parts (2026-08), active
establishments under the precise CNAEs:

|                          |                                      |
| ------------------------ | ------------------------------------ |
| Estabelecimentos no alvo | 5.997 por parte (~60.000 no país)    |
| Com telefone             | **99%**                              |
| Com e-mail               | **90,6%**                            |
| Com nome fantasia        | 29,1% — a razão social cobre o resto |

Contrast the map route, where a POI's contact fields are whatever a surveyor saw
on a door.

**CNAEs come in two tiers, and the second one is the important design decision.**
A precise CNAE identifies the trade and is taken whole. A broad one contains the
trade without identifying it, and is only accepted when the business's own name
also reads as marketing (`MARKETING_NAME` in `niches.ts`, applied to razão social
and nome fantasia together — 71% of these rows have no fantasia, so judging on it
alone would discard most of the pool unread).

That split is measured, not cautious. Sampling `7319-0/02` ("promoção de vendas")
returns OLIVEIRA VIDRACARIA E ENERGIA SOLAR, OFICINA MECANICA R.N., EMPORIO
INDUSTRIAL E ELETRICO — and it is **70% of everything a plain CNAE filter
returns**. Taken whole it would have buried the real base under three times its
own volume in glaziers and mechanics. Sampling `7319-0/99` ("outras atividades de
publicidade"), by contrast, returns 2J MIDIA DIGITAL, NOVA BELEM PUBLICIDADE,
TAGHY AGENCIA DIGITAL — the trade itself, taken whole.

**What the register is bad at, stated rather than hidden.** Its `correio
eletrônico` is very often the accountant who opened the company — `cgbcontabil02@`,
`edsoncontador_lbc@`, `societario@jotacecontabil…` are typical. The sync reports
an approximate count of these in `data/cnpj.json` (`accountantEmail`) instead of
dropping the rows: it is still a route in, and an operator should read the limit
up front rather than infer it from the fortieth reply. Two smaller cleanups run
on the way in — the field sometimes carries its own label (`e-mail: anuncios@…`),
and filler phones with one repeated digit (`5555-5555`) would otherwise inflate
the coverage figure this source was chosen for.

**The register's telephone is not a WhatsApp number, and this is not marginal.**
Measured on the 2026-08 extract: 6.350 of 6.357 phones are ten national digits —
the pre-2016 format, captured when the company was registered and never updated.
A Brazilian mobile is eleven digits starting with 9, so `isWhatsappCapable`
rejects effectively all of them, and it is right to. About a third (2.152) were
probably mobiles before the nine-digit migration, and prepending the 9 would
recover them — it is deliberately **not** done. That is a guess about a specific
number, and a wrong one opens a stranger's chat with a partnership pitch, which
is precisely the failure `normalisePhone`'s own comment exists to prevent.

So **e-mail is the channel for register rows** (90% coverage against 0% WhatsApp),
which suits a partnership approach better than a cold message anyway. The search
says so in a warning rather than leaving it to be discovered.

**`confidence` on a CNPJ row is the establishment's age**, not a provider score —
the Receita publishes none. It has to carry something real: every row here scores
the same 75 under `scorePartner`, and `scoreAndSort` breaks ties on confidence
before name, so a constant would leave a partner list ordered alphabetically.
Years trading is the one durability signal the register has, and it is a fair
reading of "is this record real and current".

Three things about the source that are not obvious:

- **A register row's blank `website` means "never asked", not "hasn't got one".**
  The Receita has no such column. `scorePartner` reads `source === "cnpj"` and
  scores "registro ativo" instead of "sem site próprio", and the search's
  `withoutWebsite` stat excludes these rows — counting them would report every
  partner search as almost entirely site-less, which is a fact about the
  Receita's schema and not about the trade.
- **The files are cp1252 and contain bytes that are valid in no encoding at all**
  (`0x8F` inside an e-mail field), which makes DuckDB's own `encoding='latin-1'`
  refuse the whole file. The sync pipes them through `iconv -c`.
- **The download is a Nextcloud WebDAV share behind an opaque token**, which the
  Receita changed in Jan/2026 and will change again. It is a constant in the
  script and overridable with `CNPJ_SHARE_TOKEN`; a failed listing says so
  instead of reporting an empty month list.

`npm run sync:cnpj -- --parts 1` runs the whole pipeline against ~2GB instead of
~7GB. Use it to check a change end to end; the metadata records `partial: true`
so the result cannot be mistaken for a real extract later.

It limits **Estabelecimentos only** — Empresas is always read in full. The two
tables' ten parts are partitioned independently, so part 1 of one does not hold
the same companies as part 1 of the other; pairing them drops 98% of the sample
on the razão social join (measured: 24.213 establishments in, 409 rows out).

Sócios — the register of the natural persons behind each company — is
deliberately not downloaded. We have no use for it, and pulling a table of names
and CPF fragments we will never read is not a neutral act.

**These categories are not in an extract built before them, so this needs
`npm run sync` and then `npm run cities`** — the usual rule for adding a
category, and here the searches return nothing at all until it is run.

OpenStreetMap and Geoapify are not consulted for these niches (no entry in their
tag/category maps, which both read as "no supplementary rows"). Their vocabularies
don't line up with Overture's here, and a row whose category maps to nothing would
be scored as a client and sorted to the bottom for having a website.

## Scoring

Deterministic rules in `src/lib/prospector/score.ts`, not an LLM: it is instant, free, and
you can read a row and see exactly why it scored what it did. Every score comes
with pt-BR reason chips in the UI.

| Signal                        | Points    | Why                                                                                            |
| ----------------------------- | --------- | ---------------------------------------------------------------------------------------------- |
| No website                    | +45       | The thing we actually sell. Dominates by design.                                               |
| Social profile but no website | +15       | Strongest warm signal there is — they already want to be findable, they just never got a site. |
| Has a phone                   | +15       | Can start a conversation today.                                                                |
| …and it's a mobile            | +10       | WhatsApp resolves; a landline `wa.me` link is dead.                                            |
| Confidence ≥ 0.8              | +10       | Record is real and current.                                                                    |
| Has a street address          | +5        |                                                                                                |
| _Already has a website_       | _+5 only_ | Still a possible redesign lead, so not zero, but it sorts below everything sellable.           |

Ties break on confidence, not name. Scores bunch at the ceiling — any no-site
business with a mobile and a clean record hits 100 — and breaking ties
alphabetically buried the best records under every shop starting with "A".

### Scoring a partner

A `parceiro` niche reads the same 0–100 scale in mirror image, because "sem site"
is the top signal for a client and close to a disqualification for a partner. An
agency with no website, no Instagram and a landline is dormant or one person
moonlighting; either way it is not somebody to hand a client to.

| Signal               | Points | Why                                                                                                |
| -------------------- | ------ | -------------------------------------------------------------------------------------------------- |
| Has a website        | +25    | Visibly operating. For a client this is worth +5.                                                  |
| Social profile       | +20    | An agency that doesn't run its own social is advertising the fact.                                 |
| Has a phone          | +15    |                                                                                                    |
| …and it's a mobile   | +10    |                                                                                                    |
| Has an e-mail        | +15    | Weighted above the client's +10: a partnership opens by proposal far more often than by cold call. |
| Confidence ≥ 0.8     | +10    |                                                                                                    |
| Has a street address | +5     |                                                                                                    |

The reason chips are worded for the row they appear on — "site próprio" and "sem
site próprio" rather than reusing the client wording, since "já tem site" is a
shrug on a client and the point on a partner.

`performSearch` passes the intent explicitly rather than letting each row's
category decide, so a supplementary row that arrived under another directory's
vocabulary is still scored as what it was searched for.

WhatsApp capability is derived, not assumed, and it is derived _per country_.
Brazilian mobiles are `+55` + 2-digit DDD + 9 digits starting with `9`; landlines
are 8 digits starting 2–5. Portugal's mobiles start `91/92/93/96`, Germany's
`15/16/17`, and the US and Canada do not distinguish at all — those carry no rule
and get no button rather than a guess. The pattern lives in `mobile` on the
country registry and is run twice: in JS for the button, and interpolated into
the SQL for the "com WhatsApp" total, which is counted over every match rather
than over the returned page. `src/lib/prospector/score.test.ts` is what keeps the
two halves from drifting.

## Looking at what you've gathered (`/prospector/historico`)

`/prospector` only ever shows the search you just ran. `/prospector/historico` is everything the tool
has ever found, read back out of SQLite — the search page writes, this page reads.

| What      | How                                                                                |
| --------- | ---------------------------------------------------------------------------------- |
| Filter    | free text (name or address), niche, country, city, situação, no-site, has-WhatsApp |
| Per niche | breakdown: leads, sem site, WhatsApp and how many you've worked, per niche         |
| Sort      | score, most recently found, first found, name                                      |
| Export    | **every matching row**, not just the page you're looking at                        |
| Pipeline  | per-row dropdown: novo → contatado → respondeu → cliente → descartado              |
| Delete    | per row, or everything the current filters match (administrator only)              |

Filters live entirely in the query string, so a view is a shareable URL and works
with JavaScript off — the whole filter bar is a plain GET form. Only the situação
dropdown and the delete buttons need JS, and the dropdown updates optimistically
rather than making you wait a round trip per lead.

### Not saving, and un-saving

Two controls decide what the history holds, and they are deliberately asymmetric.

**"Salvar no histórico"** on the search form (or `save=0` in the URL) runs a
search that writes _nothing_: no leads, no partial rows, no "novo" marks — the
board says `histórico: desligado` and the audit still records that the search
happened. It is for sizing a market or trying six niches without putting a
hundred businesses you will never call into the shared pipeline.

**Deleting** is the other direction. A trash button on each row of the board and
of the history removes that one business; the history's toolbar removes
everything the current filters match, which is administrator-only because it can
empty the pipeline in one request, and an _unfiltered_ delete has to be confirmed
twice. Nothing is tombstoned: a deleted business is found again by the next
search that covers it and comes back marked "novo", which is honest — the history
no longer knows it. The audit row in `prospector_activity` outlives the lead.

```
/prospector/historico?nosite=1&wa=1          # the sellable, reachable pool
/prospector/historico?niche=pet&city=Manaus  # one niche in one city
/prospector/historico?status=contatado       # who you've already messaged
/prospector/historico?q=estudio              # accent-insensitive: finds "Estúdio"
```

Free text matches a folded copy of name + address written on save (`search_norm`),
because SQLite has no `strip_accents` — so "estudio" finds "Estúdio" and
"sao joao" finds "São João".

The CSV here carries six extra columns the board's export can't know: `status`,
`contatado_em`, `proximo_follow_up`, `primeiro_visto`, `ultimo_visto` and `nicho_busca`. Both exports share one writer
in `src/lib/prospector/csv.ts`, so the common columns can't drift apart.

Score and reason chips are recomputed from `score.ts` on read rather than taken
from the stored value, so a row is shown under today's scoring rules. The stored
score is what SQL sorts and filters on, since that's what's indexed.

## Lead history (SQLite)

The search itself needs no database — Overture plus the local extract is the whole
engine. The history adds the one thing a search can't tell you: **whether you have
seen a business before.** Without it, running the same city twice looks identical
both times and there's no way to spot what appeared since. Rows the database
hasn't seen before get a `novo` badge, and the header counts what you've built up.

There is nothing to set up. `data/prospector.db` is created on the first search.

```bash
sqlite3 data/prospector.db 'SELECT name, phone, score FROM leads ORDER BY score DESC LIMIT 20'
rm data/prospector.db      # reset — searches keep working, everything looks new again
```

Deleting it while the dev server is running won't take effect: the process keeps a
handle on the unlinked file and carries on writing to it, so the row counts stay
stubbornly high. **Stop the server, delete, restart.**

`node:sqlite` ships with Node, so there is no dependency, no native build step and
nothing to keep out of the bundler. Its API is synchronous, which for a single-user
tool on localhost is a feature: a search writes ~1,000 rows in one transaction in
single-digit milliseconds, with no connection pool, no network hop and no service
to be down. WAL mode is on, so an unclean shutdown can't corrupt the file.

The schema is created on open rather than through migration tooling — this is a
local single-user database that can be deleted and rebuilt by re-running a search,
so versioned migrations would be ceremony with nothing to protect.

New _columns_ are still picked up on an existing file, because they have to be:
`CREATE TABLE IF NOT EXISTS` does nothing to a table that already exists, so adding
`search_norm` to the schema left older files without it — and since the column is in
the INSERT list, **every search failed** with "no such column" rather than degrading.
`addMissingColumns()` adds what's missing on open and backfills it. Renames, type
changes and constraint changes are out of scope; for those, delete the file.

`first_seen_at` is never overwritten; that is the point of keeping history.
Everything else refreshes on re-upsert, so a business that has since published a
website updates rather than lingering at whatever it looked like the first time.

Opening WhatsApp records the outreach, moves a new lead to `contatado`, and adds a
follow-up due in three days. The history page lets you adjust or clear that date,
and its “follow-ups de hoje” view is the daily work queue. `notes` remains
reserved for richer per-lead context.

It also decides who the lead belongs to. **The first operator to contact a
business — a logged call or an opened WhatsApp thread — becomes its owner, and
nobody else on the team may contact it afterwards.** The history and the CRM show
"atendido por" on every owned lead and turn the contact buttons into a label for
everyone else; the call queue steps over them, and the routes refuse the write
with a 409. While somebody is on the dialer the lead is also _reserved_ for them
for twenty minutes, renewed while the screen is open, so two people who open the
same queue position don't both dial it — the reservation expires on its own, so a
closed laptop never locks a lead. Administrators are exempt from all of it and can
hand a lead back to the team with "liberar" in the expanded CRM row. The rules,
and why the two halves are separate, are in `src/lib/prospector/ownership.ts`.

The file is gitignored, along with its `-wal`/`-shm` companions. It is local state
rather than source, and who you have already pulled and contacted has no business
in a shared repo.

## Known state

- **No preview-site generator.** That is ViziHub's actual conversion weapon and
  the obvious next step.
- **Pipeline is intentionally lightweight.** It records first outreach and a single
  next follow-up date, but has no reminders or per-lead history of changes.
- **33 niches** in `src/lib/prospector/niches.ts` across 8 families, mapping 55 Overture
  categories.
- **Confidence floor defaults to 0.5.** Below that the records get noticeably
  stale and duplicated. The slider goes to 0 if you want to see them.
- **Result limit is 1,000 per search** from the UI. São Paulo restaurants match
  32,895, so wide searches are truncated — the UI says so explicitly rather than
  quietly capping.
- **3,358 businesses (0.2%) remain unreachable**: they give no state and their city
  name occurs in more than one, so there is no honest way to attribute them.
- **720 municipalities have a boundary but no businesses** in our 55 categories
  and are left out of the picker. An entry that always autocompletes to zero
  results is a trap; adding a niche can bring them back.
- **`data/places.parquet` is a point-in-time snapshot.** A business that built
  a website last week still shows as "sem site" until the next sync.
- **The shipped city index covers Brazil only.** The registry knows ~65
  countries, but a country is searchable only once its businesses are in the
  extract — `npm run sync -- --countries …` then `npm run cities`.
- **The state code outside Brazil is whatever Overture carries**, normalised into
  an opaque key. It disambiguates same-named cities within a country when it is
  there and is simply absent when it is not; no country other than Brazil gets a
  validated list.
- **The US and Canada get no WhatsApp buttons.** Their numbering plan does not
  separate mobiles from landlines, so there is nothing to derive it from.
- No auth on the app itself. It binds to localhost; don't expose it.

## Environment

| Variable           | Required | Purpose                                                                                             |
| ------------------ | -------- | --------------------------------------------------------------------------------------------------- |
| `OVERTURE_RELEASE` | no       | Pin a different Overture release. Defaults to `2026-07-22.0`. Must match what `npm run sync` built. |
| `PROSPECTOR_DB`    | no       | Move the history file. Defaults to `data/prospector.db`, created on first search.                   |

Nothing here is required — the tool works with an empty environment.

## Attribution

Place data © [Overture Maps Foundation](https://overturemaps.org), licensed
CDLA Permissive 2.0. Keep the attribution if any of this output becomes
customer-facing.
