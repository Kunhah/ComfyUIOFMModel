# Atlas Jurídico — os produtos, para um escritório de advocacia

The plan for selling what we already build — the WhatsApp assistant, the client
portal, sales insight, the dashboards — to an escritório de advocacia, and what
has to change for it to fit.

This is a design document, the sibling of `contabilidade.md`, and it leans on
it: where the two verticals share a shape (the `eu` phone header, the magic link,
media passthrough) this document points there rather than repeating it. The only
part that exists is marked **built**: `whatsapp-bot/presets/advocacia.config.ts`.
`plataforma.md` and `ai-infra.md` win wherever this disagrees with them.

**This is not legal review.** Every rule below about the OAB, secrecy or LGPD is
an engineering constraint written by people who are not lawyers. The first firm
we sell to reviews the bot's text and this document's product claims before the
first pairing — and a law firm is, conveniently, the one client that can.

## Why this vertical is not "accounting with processos"

The two look alike from outside — professional services, a carteira, monthly
honorários or not — and differ in the three places that decide the product:

- **The volume is one question.** "Como está meu processo?" is most of the
  WhatsApp traffic of a litigation firm, and it interrupts a lawyer each time:
  open the system, read a movimentação written for judges, translate it. A
  process runs for years and the client asks every few weeks.
- **What the client may be told is a professional act.** An accountant's bot can
  say "falta o extrato". A lawyer's bot cannot say what "concluso para
  sentença" means *for this case*: legal advice is reserved to lawyers
  (Lei 8.906/94), and a wrong one is the firm's liability. The unit of client
  communication is therefore **text a lawyer approved**, not data.
- **The firm may not go looking for clients the way everyone else does.** The
  OAB's advertising rules (Provimento 205/2021 and the Código de Ética) allow
  informative marketing and forbid active captação and mercantilização. That
  cuts the half of our catalogue built on outbound, and it changes our own
  pitch to firms: not "more clients", but *answer the ones who already came,
  faster and with nothing said wrong*.

## What we do not build

- **Legal practice software.** Case management, deadline control, petition
  drafting and publication capture are Projuris, Astrea, ADVBOX, Legal One,
  CPJ — and publication capture services on top of them. We read what they
  expose; we do not control a prazo. A deadline system that is wrong once costs a
  client their case, and that is not a risk we can price.
- **Legal advice from a model.** Not in the bot, not in a skill. The one AI
  output that reaches a client — the andamento explanation below — is a *draft a
  lawyer approves*, never sent on its own.
- **Outbound captação.** No campaigns to prospects, no "reactivation" of people
  who are not clients, and the prospector loop from `contabilidade.md` Produto 6
  is **not offered to firms**, with the one exception noted there.
- **Anything that holds tribunal, gov.br or INSS credentials.** Same rule as the
  accounting office, for the same reason.

## The data: processos under the account

```
processos         account_id, numero_cnj, area, fase, responsavel_id,
                  segredo_de_justica, status ∈ ativo|suspenso|encerrado
processo_clientes processo_id, lead_id, papel ∈ cliente|representante
partes            account_id, nome_norm, documento_norm, processo_id, polo ∈ cliente|contraria
movimentacoes     processo_id, data, texto_tribunal, origem ∈ sistema|manual
andamentos        processo_id, movimentacao_id, texto_cliente, rascunho_ia,
                  aprovado_por, aprovado_em, visualizado_em
compromissos      processo_id, tipo ∈ audiencia|pericia|reuniao, inicio (UTC), local,
                  presenca_do_cliente ∈ obrigatoria|opcional|nao
pendencias        processo_id, descricao, estado ∈ aguardando|recebido|dispensado, canal
```

Rules worth keeping:

- **`andamentos` is separate from `movimentacoes`, and only `andamentos` with
  `aprovado_em` is ever shown to a client.** The tribunal's text is data; the
  client's text is a professional communication. The bot's `andamento_processo`
  reads only approved rows; a process with nothing approved answers "o advogado
  ainda não atualizou" — true, and a nudge to the firm.
- **`partes` exists for the conflict check**, and it is a table, not a prompt. A
  new interessado's `parte_contraria` is normalised and matched against every
  `partes` row with `polo = cliente` in the account. A match is shown to a
  lawyer before the consulta is confirmed. The model never decides a conflict.
- **`segredo_de_justica` narrows everything.** Family cases often are. Such a
  process is answered only to its own client's number, never appears on a
  shared link, and its movimentações never go to a model — the draft step skips
  it.
- **Scoping is `account_id` in the query**, as everywhere (`plataforma.md`).

## Produto 1 — Assistente de WhatsApp · **built** (the preset)

`whatsapp-bot/presets/advocacia.config.ts`, run with
`BOT_CONFIG=presets/advocacia.config.ts`. Standalone container on the firm's
number; does not wait for the inbox.

**What it does.** Knows whether it is talking to a client (`consultar_cadastro`).
For clients: the andamento as the firm approved it, the next audiência with
whether they must attend, what the firm is waiting for, and documents recorded
against a process after confirming which. For others: a minimal triage — area,
one sentence, the other party's name "para o escritório verificar se pode
atender" — then the lead and a consulta. Urgency (prisão, audiência or prazo in
two days, citação received, medida protetiva) skips triage and goes to a person;
danger now means "ligue 190" first.

**Backend contract:**

| Tool | Request | Returns |
| --- | --- | --- |
| `consultar_cadastro` | `GET /clientes/eu` | is this a client; their processos (id, area, responsável) |
| `andamento_processo` | `GET /clientes/eu/processos/andamento?processo` | latest **approved** `andamentos.texto_cliente`, with date |
| `consultar_compromissos` | `GET /clientes/eu/compromissos?processo` | upcoming, with `presenca_do_cliente` |
| `consultar_pendencias` | `GET /clientes/eu/pendencias?processo` | what the firm awaits |
| `registrar_envio` | `POST /clientes/eu/envios` | marks a pendência received, canal whatsapp |
| `registrar_interessado` | `POST /interessados` | the lead, and triggers the conflict check |
| `consultar_horarios` / `marcar_consulta` | `/agenda/...` | per area — each lawyer takes theirs |

`eu` is the `x-conversa-telefone` header, set by the engine from the
conversation row (see `contabilidade.md`, Produto 1). For a law firm it carries
more weight: "o fulano é cliente de vocês?" must fail even when the model is
talked into trying, and it does, because no tool accepts a phone or a name.

**Decisions in the preset that differ from the accounting one:**

- **`hours.outside` is `responder`, not `avisar`.** The message at 23h on a
  Saturday is the one about an arrest. With `avisar` it would wait for Monday
  behind a polite notice; with `responder` the urgency rule runs and the
  handoff webhook fires. A firm with a plantão number can switch to `avisar` and
  put the number in the notice.
- **Video is off.** Here a video is usually evidence, and the bot would read
  only its speech — then say something about a proof it never saw.
- **The triage asks for the other party and nothing else.** Not the full story:
  unsolicited detail over WhatsApp is sensitive data the firm now holds without a
  mandate, and it is what the consulta is for.
- **No emoji in process conversations, calmer pacing.** People write to lawyers
  on bad days.

**The same two tensions as accounting, unchanged:** "nunca peça documento" is
squared the same way (the pendência is the firm's statement, not the bot's
request), and files do not reach the backend until media passthrough ships —
the same template change serves both verticals.

## Produto 2 — Andamento em linguagem de gente

The product a firm will pay for, because it removes the interruption instead of
automating it.

1. A movimentação arrives (from the firm's software export, or entered).
2. `juridico.andamento` drafts `rascunho_ia`: what happened, in plain Portuguese,
   **without** any claim about chances, deadlines the client must meet, or what
   comes next. `validate()` refuses a draft that contains a number of days, a
   currency value, or words from a blocklist ("ganhar", "perder", "certamente").
3. The responsible lawyer sees a queue of drafts next to the tribunal text and
   approves, edits or rejects. One click for "Juntada de petição" repeated
   forty times; real attention for "sentença".
4. Approved text becomes what the bot answers and what the client link shows.
   `visualizado_em` records that the client saw it.

Segredo de justiça processes skip step 2 — the lawyer writes by hand. The skill
runs on the expensive chain (`ai-infra.md`: low volume, read carefully) and its
eval fixtures are real movimentações with the blocked words planted in them.

**For the client: the magic link**, as in `contabilidade.md` — one per client,
signed, expiring, listing their processos (minus segredo de justiça on a shared
device warning), approved andamentos, compromissos and an upload box. No login,
no third tenancy level.

## Produto 3 — Insight de vendas, inside the rules

What survives the OAB constraint is everything about **the people who already
wrote**:

- **`juridico.triagem`** — per interessado: area, urgency, whether it fits the
  firm's areas, what the lawyer should ask in the consulta, and the conflict
  check result (from the `partes` match, cited as a fact; the model reports it,
  never computes it). Same `facts.ts` discipline.
- **Public process data as facts.** When a prospect already has a process
  number ("quero trocar de advogado"), the CNJ's public DataJud API gives class,
  court and movement dates — observations with a source. Never for segredo de
  justiça, which DataJud does not expose anyway.
- **Response time is the metric.** The firm that answers a dismissed worker the
  same afternoon gets the case. That is the pitch, and it is an honest one.

**For us, selling to firms:** `advocacia` maps to the generic `recorrente`
segment. The pitch differs enough — no promises of volume, which a firm hears as
an ethics problem — that it is the first candidate for a dedicated segment in
`src/lib/ai/segments.ts`, with "prometer mais clientes" in its `evitar` list.

## Produto 4 — BI: o escritório em números

Counts, not AI, plus the weekly `painel.narrativa`:

| Métrica | De onde |
| --- | --- |
| Processos ativos por área e fase | `processos` |
| Andamentos pendentes de aprovação, e há quanto tempo | `andamentos` |
| "Como está meu processo?" por semana, antes e depois do link | conversations |
| Interessados por área → consulta → contrato | leads, agenda |
| Tempo até a primeira resposta, por área | conversations |
| Honorários contratados e parcelas em atraso | entered by the firm |

**What the dashboard never shows: a probability.** No "valor esperado de êxito",
no win rate by judge. Those are numbers the firm cannot defend and the client
may one day see. Contracted values and phases only, every figure traceable to a
row (the `ai-infra.md` rule).

## Produto 5 — Pós-venda

- **Audiência reminders** with "presença obrigatória" — the client who misses
  their own hearing is the costliest failure in a labour case. Jobs off
  `compromissos`, 48h and 24h before, over the client's channel.
- **`posvenda.risco`** — a client asking for "cópia de tudo", mentioning another
  lawyer, going quiet after a bad decision. Flagged to the responsible lawyer,
  never acted on.
- **Review requests and reactivation are open questions**, not features — see
  below.

## Produto 6 — Estratégia, and why it is small here

The accounting doc's best idea — point the prospector at more businesses like
the most profitable clients — is active captação, and we do not offer it to
firms. The exception is `juridico-empresarial` (B2B firms: trabalhista
patronal, tributário), where informative content aimed at companies is common
practice; even there, the firm's own compliance decides, and we supply nothing
that writes to a company that did not ask.

What remains is internal: which areas and case types pay for the effort they
cost, from the dashboard, quarterly.

## Roadmap

| Fase | Escopo | Depende de | Semanas |
| --- | --- | --- | --- |
| **J0 — Preset** ✅ built | Bot preset, triage, urgency handoff | `x-conversa-telefone` (built) | feito |
| **J1 — O arquivo** | Media passthrough — the same change as contabilidade C1 | — | shared |
| **J2 — Processos** | `processos`, clientes, `partes`, compromissos, pendências; `/clientes/eu` endpoints; conflict check | plataforma 0 (built) | 3 |
| **J3 — Andamento** | Import of movimentações, `juridico.andamento` drafts, approval queue, magic link | J2, ai-infra A (built) | 3 |
| **J4 — Triagem** | `juridico.triagem`, DataJud facts, response-time metric | ai-infra B (built) | 1–2 |
| **J5 — Painel e pós-venda** | Métricas, narrativa, audiência reminders, risco | J2, ai-infra D, plataforma 1 | 2–3 |

J0 to J3 is the product: about six weeks, and J3 is what the firm pays for.

## Perguntas em aberto

- **Does the firm's seccional have a position on chatbots?** The bot always says
  it is a virtual assistant (template rule) and only responds. The firm confirms
  that is enough before pairing.
- **Which software does the first firm use**, and does it export movimentações?
  Decides whether J3 imports or the firm types.
- **LGPD and sigilo, together.** Documents and triage text are sensitive data
  (health, family, violence) and privileged. They pass through a speech and a
  vision model (the preset caps it at 3 pages). The DPA with the firm, and the
  firm's own engagement letter, must say so. Consider whisper local
  (`whatsapp-bot/src/audio/stt.ts` is one function for that reason) for firms
  that will not accept audio leaving the server.
- **Review requests.** Asking a client for a Google review after a case may read
  as marketing the OAB frowns on. Firm's call; off by default.
- **Reactivation of past clients** (the labour client whose company is now
  hiring again) is probably captação. Off unless the firm's compliance says
  otherwise.
- **Who approves andamentos when the responsible lawyer is away?** Without a
  rule, the queue stalls and the bot answers "ainda não atualizou" for two weeks.
