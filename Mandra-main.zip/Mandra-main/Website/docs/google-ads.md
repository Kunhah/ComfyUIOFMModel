# Google Ads — as páginas, a estrutura e o que medir

As seis landing pages construídas para a Rede de Pesquisa, a que grupo de
anúncios cada uma pertence, e o que precisa estar configurado antes de o
primeiro real ser gasto.

O código vive em `src/app/(ads)/` (template e chrome) e `src/content/ads.ts`
(todo o conteúdo). Um sétimo grupo de anúncios é uma entrada nova naquele
arquivo — não uma rota nova.

## Por que páginas separadas

São dezoito páginas, uma por grupo de anúncios. Não se sobe as dezoito no
primeiro mês — sobe-se duas ou três, aprende-se, e as outras já estão prontas
quando o orçamento permitir.

Uma página inicial que diz "sites, sistemas, IA, automação e tráfego" responde
mal a **qualquer** busca específica. O Google cobra por isso duas vezes: o
Índice de qualidade sobe o custo por clique quando a página não repete a busca,
e a página converte menos porque o visitante precisa procurar a parte que
interessa a ele.

Cada página aqui tem um H1 que contém a busca, uma seção de problemas escrita
para aquele ofício, uma lista de entregáveis daquele ofício e um FAQ com as
perguntas que aquele comprador realmente faz. Isso é também o que impede que as
seis sejam conteúdo duplicado para o robô do Google.

## O mapa

| Grupo de anúncios                          | Página                            | Palavra-chave âncora                        |
| ------------------------------------------ | --------------------------------- | ------------------------------------------- |
| Sites — alta intenção                      | `/criacao-de-sites`               | `criação de sites profissionais`            |
| Sites — Florianópolis (local)              | `/criacao-de-sites-florianopolis` | `criação de sites Florianópolis`            |
| Sites — energia solar                      | `/sites-energia-solar`            | `site para empresa de energia solar`        |
| Sites — oficina mecânica                   | `/sites-oficina-mecanica`         | `site para oficina mecânica`                |
| Sites — ar condicionado e climatização     | `/sites-ar-condicionado`          | `site para empresa de ar condicionado`      |
| Automação — atendimento no WhatsApp        | `/automacao-whatsapp`             | `automação de atendimento WhatsApp`         |
| Sites — odontologia                        | `/sites-clinica-odontologica`     | `site para clínica odontológica`            |
| Sites — clínicas médicas                   | `/sites-clinica-medica`           | `site para clínica médica`                  |
| Sites — advocacia                          | `/sites-advocacia`                | `site para escritório de advocacia`         |
| Sites — contabilidade                      | `/sites-contabilidade`            | `site para escritório de contabilidade`     |
| Sites — imobiliárias                       | `/sites-imobiliaria`              | `site para imobiliária`                     |
| Sites — arquitetura e design de interiores | `/sites-arquitetura`              | `site para escritório de arquitetura`       |
| Sites — construtoras e reformas            | `/sites-construtora`              | `site para construtora`                     |
| Sites — móveis planejados e marcenaria     | `/sites-moveis-planejados`        | `site para móveis planejados`               |
| Sites — segurança eletrônica e CFTV        | `/sites-seguranca-eletronica`     | `site para empresa de segurança eletrônica` |
| Sites — estética e bem-estar               | `/sites-clinica-estetica`         | `site para clínica de estética`             |
| Sites — veterinária e pet                  | `/sites-clinica-veterinaria`      | `site para clínica veterinária`             |
| Parcerias — agências e gestores de tráfego | `/parceria-agencias`              | `desenvolvimento de sites white label`      |

A lista completa de termos de cada grupo está no campo `keywords` da entrada
correspondente em `src/content/ads.ts`, que é a mesma lista publicada na
metatag da página. Mantenha as duas iguais: é o vínculo mais barato entre o
anúncio e a página.

**CRM não tem página e isso é deliberado.** Quem busca "CRM" quase sempre
procura um produto de prateleira, um comparativo ou um tutorial, e o leilão é
disputado por empresas de software com orçamento de categoria. CRM se vende na
conversa que começa pelo site, não no leilão.

## O caminho até a ligação

O único número que importa nessas páginas é quantos toques separam o visitante
de um telefone tocando. É **um**, de qualquer ponto da página:

- o cabeçalho tem o número (desktop, sempre visível);
- a primeira tela tem o bloco de ligar e o de WhatsApp;
- o meio da página repete os dois, logo depois da lista de entregáveis;
- a barra fixa no rodapé do celular acompanha a rolagem inteira;
- a faixa final traz o número em corpo de display, legível de longe — o que é
  zero toque para quem vai discar no aparelho ao lado.

Não há formulário em nenhuma delas. Um formulário custa de três a oito campos e
entrega um contato mais frio do que uma ligação; se um dia fizer sentido, ele
entra **abaixo** do telefone, nunca no lugar dele.

## Antes de subir a campanha

### 1. Medição de conversão (obrigatório)

Sem isso o Google otimiza para cliques, e clique não paga conta. Crie duas
ações de conversão na conta do Ads — uma para a ligação, uma para o WhatsApp —
e configure três variáveis de ambiente:

```
NEXT_PUBLIC_GOOGLE_ADS_ID=AW-XXXXXXXXXX
NEXT_PUBLIC_GOOGLE_ADS_CALL_LABEL=<rótulo da conversão "Ligar">
NEXT_PUBLIC_GOOGLE_ADS_WHATSAPP_LABEL=<rótulo da conversão "WhatsApp">
```

Enquanto elas estiverem vazias, a tag do Google não é carregada — de propósito:
uma requisição de terceiro em branco encarece justamente a métrica de
carregamento pela qual a campanha é avaliada. `src/lib/ads/gtag.ts` é onde isso
mora; `data-ads-action="call"` e `data-ads-action="whatsapp"` marcam os
elementos, caso um dia entre um Tag Manager.

Além disso, ative **extensão de chamada** e **conversões de chamada do
anúncio** direto no Ads: parte das ligações acontece sem o clique chegar ao
site, e essas só aparecem por lá.

### 2. Marcação de URL (é o que dá nome ao gasto)

O Google manda a pessoa para a sua página, mas não conta qual palavra ela
pesquisou — só acrescenta o `gclid`, que diz apenas "foi pago". Sem marcar, o
máximo que se sabe é "a página converte 8%", sem nunca saber quais palavras
carregam esses 8% e quais só gastam.

Cole **uma vez**, na conta, em **Configurações da conta → Acompanhamento →
Sufixo do URL final**:

```
utm_source=google&utm_medium=cpc&utm_campaign={campaignid}&utm_adgroup={adgroupid}&utm_term={keyword}&utm_matchtype={matchtype}&utm_network={network}&utm_content={creative}
```

Todas as campanhas herdam, inclusive as futuras. O painel em
`/admin/analytics` avisa sozinho se houver clique pago chegando sem
palavra-chave, e mostra essa mesma linha para copiar — a explicação completa
está em [analytics.md](analytics.md).

### 3. Configuração da campanha

- Somente Rede de Pesquisa. Display desligado, parceiros de pesquisa
  desligados, sem Performance Max.
- Correspondência exata e de frase. Ampla só depois de existir histórico de
  conversão.
- Localização: **presença**, não interesse. "Pessoas interessadas em
  Florianópolis" inclui o Brasil inteiro pesquisando sobre a cidade.
- Horário: concentre onde alguém atende o telefone. Uma ligação perdida é um
  clique pago duas vezes.
- Lance: CPC máximo manual no começo. Lance automático sem conversão registrada
  é o Google otimizando às cegas com o seu dinheiro.

### 4. Palavras negativas, desde o primeiro dia

```
grátis, gratuito, curso, tutorial, como fazer, passo a passo, emprego, vaga,
salário, estágio, faculdade, significado, o que é, download, template, modelo,
tema, código fonte, github, wordpress grátis, wix, login, entrar, suporte,
reclamação, reclame aqui, é bom, vale a pena, residencial, automação
industrial, automação residencial, freelancer, freela, remuneração
```

Para o grupo de energia solar acrescente `curso`, `orçamento de placa`,
`preço de placa solar`, `financiamento solar` — são buscas de consumidor final,
não de integrador. Para oficina, acrescente `perto de mim`, `manual`, `tabela
fipe`, `peça` — quem busca isso quer um mecânico, não um site.

## Onde olhar depois que estiver rodando

O Google Ads responde "quantos cliques e quanto custaram". Ele não responde
"por que metade das pessoas some antes do meio da página", e é essa a pergunta
que muda a conversão.

Por isso as páginas medem a si mesmas. `/admin/analytics` mostra, por página e
por período: até onde as pessoas leem (o funil por seção, com a maior perda
apontada), qual botão é realmente usado, onde a rolagem para, conversão por
dispositivo, por campanha e por palavra-chave, e quais perguntas do FAQ as
pessoas abrem — que é a objeção que o texto acima ainda não respondeu.

Os detalhes estão em [analytics.md](analytics.md). O resumo operacional: leia o
funil primeiro, o corte por dispositivo depois, e só então mexa nos lances.

## A conta, feita direito

As duas fórmulas, e é só o que existe:

```
custo por lead    = CPC ÷ taxa de conversão da página
custo por cliente = custo por lead ÷ taxa de fechamento
```

Um cenário central plausível para o grupo de sites, com página específica e
palavras exatas: CPC R$4, conversão 10%, fechamento 20% → **R$200 por
cliente**. Um cenário ruim — página genérica, correspondência ampla, sem
negativas — é CPC R$12, conversão 4%, fechamento 10% → **R$3.000 por cliente**.
É a mesma verba; o que muda é tudo o que está neste documento.

Nenhum desses CPCs veio do Planejador de Palavras-chave com a conta e a
localização definidas — são estimativas de planejamento. Os números reais só
existem depois de rodar, e o primeiro mês é o que os produz.

Regras de corte, para não descobrir isso no fim do mês:

- palavra que gastou R$100–150 sem um lead qualificado: pausar;
- 30 cliques numa página sem nenhum contato: o problema é a página ou a
  intenção da palavra, não o lance;
- muitos contatos pedindo curso, emprego ou algo grátis: faltam negativas;
- lead que não vira reunião: a página está atraindo o comprador errado;
- reunião que não vira venda: o problema é comercial, não é o Ads.

## O que ainda depende de uma decisão sua

- **Faixa de preço.** `investimento` está `null` em toda entrada de
  `src/content/ads.ts` e a página não menciona preço enquanto estiver assim.
  Preencher (ex.: `"a partir de R$ 2.500"`) faz aparecer uma tarja de
  investimento e costuma subir bastante a qualidade do lead, ao custo de
  volume. É decisão comercial.
- **E-mail, endereço e redes sociais** em `src/content/site.ts` continuam sendo
  os dados herdados de placeholder. O telefone é real e é o que as páginas
  usam; o resto aparece no rodapé e deveria ser corrigido antes de comprar
  tráfego.
- **Domínio.** `site.url` é `https://mandra.com.br`. O canonical, o sitemap e
  os dados estruturados saem dali — se o domínio comprado for outro, é esse
  campo que muda.
