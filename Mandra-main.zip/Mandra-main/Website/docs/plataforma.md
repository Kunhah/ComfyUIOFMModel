# Atlas Plataforma — CRM, atendimento e agenda

The plan for turning the CRM we already have into the product we hand to the
businesses we sell websites to: one WhatsApp inbox, one calendar, one outreach
tool, one login per client.

This is a design document, not a description of something that exists. The only
parts shipping today are the ones marked **built**. Everything else is a
commitment to a shape, so that the first module doesn't have to be undone to fit
the second.

**Phase 0 is built**: client accounts, the `cliente` role, the scope that bounds
every lead query, and the client portal at `/app`. That is already a product — a
client we sell a website to gets a login, and the contacts their form receives
land in their own pipeline. Everything after it is still design.

## What we are copying, and what we are not

GoHighLevel is the reference because our customers have heard of it and because
it bundles the right things. It is not the target: most of it is surface we
would carry forever and sell never.

**We copy**: the conversations inbox, calendars and booking, campaigns and
sequences, and the per-client login that makes those three usable by someone who
is not us.

**We do not copy**, and should say so out loud so nobody builds it by accident:

- **The funnel / website builder.** Building the site _is what we sell_. A
  drag-and-drop builder in the product competes with our own invoice, and it is
  the single largest engineering surface in GHL.
- **The phone system and dialler.** We already have a manual call queue
  (`call_lists`, `lead_calls`) that costs nothing and works. Buying numbers and
  carrying voice is a different company.
- **Payments, invoices, memberships, courses, the ad manager.** Adjacent
  products wearing the same login. Revisit only when a paying client asks twice.
- **Reputation / review requests.** Cheap to add _later_ on top of campaigns —
  it is one more sequence with a Google review link — so it costs nothing to
  defer, and nothing to skip if nobody wants it.

The advantage we have over GHL is upstream of all of it: GHL gives a client an
empty CRM and tells them to fill it. Ours arrives with the prospector's leads
already in it, and with the website that feeds it already ours.

## Tenancy: two levels, not three

We are not reselling to other agencies. The model is therefore **Atlas, and the
client accounts under it** — no reseller tier, no white-label-of-a-white-label,
no agency-level billing. Two levels is a materially smaller build than three:
there is one place that grants access instead of a delegation chain, and one
branding layer instead of a cascade.

The anchor already exists. `intake_sites` was written for it:

> One row per site rather than per customer, because a customer with a landing
> page and a main site wants to know which one produced the lead — and because
> the row is what a tenant will hang off when the CRM stops being single-tenant.

That is the right instinct and the wrong grain. A client with two sites is one
inbox, one calendar and one set of numbers. So:

```
accounts (contas)          -- one per client business. The tenant.
  └── intake_sites         -- one or more. gains account_id.
  └── channel_accounts     -- their WhatsApp numbers, their e-mail sender.
  └── calendars
  └── campaigns
  └── users (role='cliente') -- scoped to exactly one account.
leads                      -- gains account_id, NULL = Atlas's own prospecting.
```

**`account_id` on `leads` is nullable, and NULL means Atlas.** Everything the
prospector has ever found is ours; backfilling it into a fake "Atlas" account
would make our own pipeline a tenant of itself and force every existing query to
learn about accounts on day one. NULL is the honest value and the cheap
migration — it goes in through `addMissingColumns()` like every other column
(see the additive-only rule in AGENTS.md).

Every _new_ table carries `account_id TEXT NOT NULL`. The asymmetry is
deliberate: the old tables predate tenancy and are allowed to say so; nothing
built from here on is.

### Scoping is enforced in the query, not in the page

The existing rule — _the proxy is an optimistic check, never the boundary_ —
extends directly. Add to `src/lib/auth/server.ts`:

```ts
requireAccount(accountId): Promise<Session>  // 404s, not 403s, on a foreign id
scopeOf(session): string | null              // null = Atlas, sees everything
```

and make every reader for a new table take the account as its **first argument,
not as a filter someone remembers to add**. A `listConversations(accountId, …)`
that cannot be called without one is the control; a `WHERE account_id = ?` that
a future route forgets is a cross-tenant leak, and it will be silent — the
client just sees somebody else's messages and assumes they are theirs.

A foreign id answers 404, never 403: 403 confirms the account exists.

### The client role

`users.role` today is `'operador' | 'admin'` with a CHECK constraint. Add
`'cliente'`, plus `users.account_id` (NULL for us, required for them). The
existing permission model carries over unchanged — `PERMISSIONS` is stored on
the row and re-read every request, exactly so a grant can be taken back, and
that property is worth more, not less, when the account holder is a customer.

`DEFAULT_PERMISSIONS` for a `cliente` is inbox and agenda. Not export: a CSV of
the lead base is the same object it is for an operator.

Note the CHECK constraint on `role` cannot be widened in place — the DDL is
`CREATE TABLE IF NOT EXISTS` and constraints do not reach an existing file.
Widening it means a table rebuild (`ALTER TABLE … RENAME`, create, copy, drop)
written once in `users.ts`, guarded by a check of `sqlite_master`. This is the
first thing in the project that the additive-only rule cannot cover, and it is
worth doing properly rather than by encoding the client role as a permission on
an operator row.

## The database stays SQLite. Here is when it stops.

`node:sqlite` on one file, one container. Not because it is obviously enough,
but because the alternative — Postgres, a connection pool, a migration tool, a
second container — buys nothing at ten to fifty client accounts and costs the
whole first module.

What has to change to make it survive an inbox:

- **A busy timeout.** `getDb()` already sets `journal_mode = WAL`,
  `synchronous = NORMAL` and `foreign_keys = ON`; it does not set
  `busy_timeout`, so a contended write throws `SQLITE_BUSY` immediately instead
  of waiting. One line, and it is the difference between a webhook that retries
  and a webhook that drops a message.
- **One writing process.** The job worker runs _in-process_ (below), not as a
  second container against the same file. Two processes on one SQLite file over
  a Docker volume is how you get `SQLITE_BUSY` under exactly the load that
  matters.
- **Same file as `prospector.db`.** Conversations reference leads by foreign
  key; a separate file would mean no FK, no join, and reconciling two stores by
  hand. The rule that split `b2b.db` off was _unrelated schemas_ — this schema is
  not unrelated, it hangs off `leads`.

**The tripwires.** Move to Postgres when any one of these is true, and not
before: more than one app container; sustained inbound above a few messages per
second; a client account that needs its data physically separated; or the first
time we want a read replica for reporting. Write this down now so the migration
is a decision rather than a panic.

## Channels: one interface, two providers

Both, behind `src/lib/channels/`. The point of the interface is not portability
for its own sake — it is that the two providers have genuinely different rules
and the difference must live in one place instead of in every caller.

```ts
type Outbound =
  | { kind: "text"; body: string }
  | { kind: "template"; template: string; vars: string[] }
  | { kind: "media"; url: string; caption?: string };

interface ChannelProvider {
  readonly id: "cloud" | "evolution";
  /** Cloud: false outside the 24h customer service window. Evolution: always true. */
  canSendFreeform(conv: ConversationState): boolean;
  send(
    cfg: ChannelAccount,
    to: string,
    msg: Outbound,
  ): Promise<{ providerId: string }>;
  /** Verifies the signature and normalises the payload. Throws on a bad signature. */
  parseWebhook(
    raw: string,
    headers: Headers,
    cfg: ChannelAccount,
  ): InboundEvent[];
}
```

`canSendFreeform` is the reason this is an interface and not a switch on a
string. Meta's 24-hour window means "a template, or nothing" outside it;
Evolution has no such concept. A caller that does not ask is a caller that
silently fails to send at 3pm the next day, which is precisely when a follow-up
matters.

### Meta WhatsApp Cloud API — for clients

The client's own number, on their own Business Manager, verified in their name.
This is the only defensible answer for a number their customers already have:
approved templates, per-conversation pricing, and a suspension that comes with a
process rather than a morning.

Costs: business verification per client (real onboarding work — budget an hour
of ours per client and a document chase), template approval latency, and
per-conversation fees passed through.

### Evolution API (Baileys) — for our own prospecting only

QR-pairs an ordinary WhatsApp number. No templates, no fees, no window, works
for cold outreach today. It also violates Meta's terms, and the number gets
banned — not _may_, eventually does, and the more it is used for exactly what we
want it for, the sooner.

**The policy, and it belongs in code review, not in someone's head:** Evolution
is allowed for Atlas's own outbound prospecting, on a number we can afford to
lose, never as the transport for a client's business number. `channel_accounts`
carries `provider` and the UI for a client account must not offer `evolution`.
Handing a client a channel that can vanish with their entire message history is
selling them a liability with our name on it.

The self-hosted Evolution instance is a second container in `docker-compose.yml`
reached over the internal network. It is optional: with it absent, the provider
registry omits `evolution` and everything else works.

### Inbound

One route per provider, `/api/webhooks/whatsapp/[provider]`, outside the proxy
matcher for the same reason `/api/v1/leads` is — it answers without a session,
and the gate should not grow an exception. It is protected by signature, not by
obscurity: Meta signs with `X-Hub-Signature-256` (HMAC-SHA256 over the **raw**
body — read the body as text once, verify, then parse; re-serialising loses the
byte-exact input), Evolution by a shared secret header we set.

Every inbound event is idempotent on `messages.provider_message_id UNIQUE`.
Providers retry, and a duplicated inbound message is a duplicated notification,
a duplicated campaign stop and a duplicated auto-reply.

The route does the minimum — verify, insert, return 200 — and queues everything
else. A webhook that does work is a webhook that times out and gets replayed.

## The job runner

One table, one in-process worker. No Redis, no BullMQ.

```sql
CREATE TABLE IF NOT EXISTS jobs (
  id            INTEGER PRIMARY KEY,
  account_id    TEXT,
  kind          TEXT NOT NULL,          -- send_message | campaign_step | reminder | …
  payload       TEXT NOT NULL,          -- JSON
  run_after     TEXT NOT NULL,
  attempts      INTEGER NOT NULL DEFAULT 0,
  -- Leased, not locked: a worker that dies mid-job releases it by expiry.
  claimed_until TEXT,
  last_error    TEXT,
  state         TEXT NOT NULL DEFAULT 'pendente'
                CHECK (state IN ('pendente','executando','concluido','falhou'))
);
```

The worker is started from `instrumentation.ts`, next to `warmProspector()`, and
is bound by the same rule: **it must never let the hook reject.** Next treats a
failed instrumentation hook as a failure to start, and that once took the
marketing site down with it.

Every handler must be idempotent — the lease expires on a hard kill and the job
runs twice. For sends that means the provider call is preceded by a row in
`messages` with a client-generated id, and a retry that finds the row already
`enviado` does nothing.

Retries: exponential, capped at ~6 attempts, then `falhou` with `last_error`
kept. A failed send must be visible in the conversation as a failed send. GHL's
worst behaviour is swallowing these, and a message the operator believes was
delivered is worse than an error.

## Module 1 — Conversas (the inbox)

The module clients live in. Everything else is optional next to it.

```sql
-- One per (lead, channel). A lead reached on WhatsApp and by e-mail has two.
CREATE TABLE IF NOT EXISTS conversations (
  id              TEXT PRIMARY KEY,
  account_id      TEXT NOT NULL,
  lead_id         TEXT NOT NULL REFERENCES leads (id) ON DELETE CASCADE,
  channel         TEXT NOT NULL CHECK (channel IN ('whatsapp','email')),
  channel_account_id TEXT NOT NULL,
  -- Denormalised so the list sorts without touching messages.
  last_message_at TEXT,
  last_direction  TEXT,
  unread          INTEGER NOT NULL DEFAULT 0,
  -- When the 24h freeform window closes. NULL = never opened.
  window_until    TEXT,
  assigned_to     TEXT,
  state           TEXT NOT NULL DEFAULT 'aberta'
                  CHECK (state IN ('aberta','arquivada'))
);

CREATE TABLE IF NOT EXISTS messages (
  id                  TEXT PRIMARY KEY,
  conversation_id     TEXT NOT NULL REFERENCES conversations (id) ON DELETE CASCADE,
  direction           TEXT NOT NULL CHECK (direction IN ('entrada','saida')),
  body                TEXT,
  media_url           TEXT,
  media_kind          TEXT,
  -- Unique and nullable: ours has none until the provider accepts it.
  provider_message_id TEXT UNIQUE,
  status              TEXT NOT NULL DEFAULT 'pendente'
                      CHECK (status IN ('pendente','enviado','entregue','lido','falhou')),
  error               TEXT,
  author_id           TEXT,        -- NULL for inbound and for automation
  author_name         TEXT,        -- captured, like prospector_activity does
  occurred_at         TEXT NOT NULL
);
```

Design notes worth keeping:

- **The conversation hangs off `leads`, not off a new `contacts` table.** `leads`
  is already the contact record: it carries the phone, the funnel stage, the
  notes and the history. A second person-table would immediately need
  reconciling with it. An inbound message from an unknown number _creates_ a lead
  with `source = 'whatsapp'`, the same way the intake form creates one with
  `source = 'formulario'`.
- **`window_until` is stored, not computed.** It is a function of the last
  _inbound_ message and the provider's rules, and computing it in the renderer is
  the timezone bug the CRM already learned once — the "today" counters had to be
  folded in SQL for exactly this reason.
- **`author_name` is captured on the row.** Same reason `prospector_activity`
  captures it: accounts get deleted, and a transcript that loses who said what is
  a transcript nobody can use in a dispute.
- **Live updates by SSE, not WebSockets.** One direction, no extra transport, and
  it survives the reverse proxy. Poll as the fallback; the inbox is a handful of
  users, not a chat product.

Screens: a two-pane inbox at `/admin/conversas` and at `/app/conversas` for the
client, a thread view with the composer disabled (with the reason shown) when
`canSendFreeform` is false, templates, quick replies, assignment, and the lead's
funnel controls in a side panel — the point of one product is that answering a
message and moving the deal are not two apps.

## Module 2 — Agenda (calendars and booking)

Self-contained, demoable in days, and the thing a dentist actually asks for.

```
calendars            account_id, name, slug, timezone, slot_minutes,
                     buffer_before, buffer_after, min_notice_hours, max_days_ahead
availability_rules   calendar_id, weekday, start_time, end_time     -- local wall time
calendar_blocks      calendar_id, start_at, end_at, reason          -- UTC. holidays, blocks
appointments         account_id, calendar_id, lead_id, start_at, end_at (UTC),
                     status ∈ agendado|confirmado|concluido|cancelado|falta,
                     source ∈ publico|manual|campanha, notes
```

Two rules the module lives or dies by:

- **Availability is local wall time; appointments are UTC.** A rule that says
  "Tuesdays 09:00–18:00" must survive a DST change, and an appointment must not
  move when one happens. Store the calendar's IANA timezone, resolve slots at
  query time. Do not store offsets.
- **Double-booking is prevented in the write, not in the slot list.** The slot
  list is a snapshot the visitor read thirty seconds ago. The insert re-checks
  overlap inside the same transaction and returns "that slot just went" — which
  is a real thing that happens on a page shared in a WhatsApp broadcast.

Public booking page at `/agenda/[slug]`, outside the login like `/api/v1/leads`,
rate-limited by the existing `lib/crm/rate-limit.ts`. Reminders are jobs:
24h and 1h before, over the client's WhatsApp channel, cancelled when the
appointment is.

Confirmation and reminder both create or update a lead, so an appointment booked
by a stranger lands in the CRM with the rest.

## Module 3 — Campanhas (sequences and bulk outreach)

Closest to what the prospector already feeds, and the most dangerous thing in
the document. A bug here does not lose data; it sends four thousand messages.

```
campaigns          account_id, name, channel, channel_account_id,
                   state ∈ rascunho|ativa|pausada|encerrada,
                   quiet_from, quiet_to, per_hour_cap
campaign_steps     campaign_id, position, delay_hours, template, kind
enrollments        campaign_id, lead_id, step, next_run_at,
                   state ∈ ativa|concluida|parada|erro, stopped_reason
suppressions       account_id, phone_norm, email_norm, reason, created_at
```

The rules, each of which exists because its absence is a specific disaster:

- **Suppression is checked at send time, never at enrolment.** Somebody opts out
  on Tuesday; a sequence enrolled on Monday must not still reach them on Friday.
- **A reply stops the sequence.** Inbound on the conversation sets every active
  enrolment for that lead to `parada`. Nothing is more damaging to a client's
  number than a drip that keeps drip-ing at someone mid-conversation.
- **Quiet hours and a per-hour cap, per channel account.** Both because it is
  decent and because volume spikes are what get numbers flagged.
- **The cap is enforced by the worker's claim rate**, not by a sleep inside a
  handler. A handler that sleeps holds a lease and a database connection.
- **Every outbound carries an opt-out line** and an inbound matching
  `sair|parar|descadastrar` writes a suppression automatically. LGPD is the floor
  here, not the ceiling — our legitimate-interest basis for cold B2B contact
  survives a regulator only if honouring a refusal is instant and demonstrable.
  Keep the audit row.

Campaigns are built over the existing history filters: the audience is a saved
`parseFilters()` query, materialised into enrolments at launch (the same
reasoning as `call_lists.source_query` — a list must not silently pick up leads
found later).

## Roadmap

Sequenced so each phase is usable alone. Estimates are engineering weeks at one
developer, and they assume the Meta business verification for the first client
runs in parallel with phase 2 rather than after it.

| Phase                        | Scope                                                                                                                                                                                                                                                                                                                                  | Weeks |
| ---------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----- |
| **0 — Foundations** ✅ built | `accounts`, `account_id` on `leads` and `intake_sites`, the `cliente` role + `users` table rebuild, `LeadScope` + `scopeFor()`, scoped mutation routes, the `/app` portal, `/admin/contas`. Left over from this phase: `busy_timeout`, the `jobs` table and the worker — none of which the portal needs, having no background work yet | done  |
| **1 — Conversas**            | `channel_accounts`, the provider interface, Evolution for us first (fastest to a working inbox), webhooks, conversations + messages, the two-pane inbox, SSE                                                                                                                                                                           | 4–5   |
| **1b — Cloud API**           | Meta provider, template registry, 24h window handling, first client onboarded on their own number                                                                                                                                                                                                                                      | 2     |
| **2 — Agenda**               | calendars, availability, public booking page, reminders as jobs, appointments on the lead panel                                                                                                                                                                                                                                        | 3     |
| **3 — Campanhas**            | campaigns, steps, enrolments, suppressions, stop-on-reply, caps and quiet hours, launch from a history filter                                                                                                                                                                                                                          | 3–4   |
| **4 — Polish**               | per-account branding, client-facing dashboard, notification e-mails, reputation as one more sequence                                                                                                                                                                                                                                   | 2     |

Roughly four months to all three modules from here. Phase 1 alone is a product we
can put in front of a client, which is the point of ordering it that way —
though phase 0 turned out to be one too, because the intake form and the CRM
were already there and only ever needed an owner.

**What a client gets today**: a login at `/app`, every contact their website
form produces, the funnel and follow-up dates the CRM already had, notes, tags
and a WhatsApp link per contact. What they do not get yet: an inbox, an agenda,
or anything that sends on its own.

## Open questions

- **Which number does a client start on?** Their existing WhatsApp Business
  number is the one their customers know, and moving it to the Cloud API means
  it stops working in the app on their phone. That is the single hardest
  conversation in onboarding and it is a sales problem, not a technical one.
  Decide the script before phase 1b, not during it.
- **Does a client see leads the prospector found?** They are ours, found for our
  own selling. Default: no — `account_id IS NULL` is invisible to a `cliente`
  session. Worth confirming, because "we already know 400 businesses like yours"
  is also a sales asset.
- **Retention.** Message transcripts grow without bound and contain other
  people's personal data. Pick a retention window per account before the first
  one is a year old.
