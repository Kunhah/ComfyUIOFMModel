# Conectar o WhatsApp de um cliente

O assistente atende no **número do cliente**, não no nosso. Cada conta tem a sua
própria instância no bridge, e as conversas de um cliente nunca aparecem no CRM
de outro — nem quando a mesma pessoa escreve para os dois.

Tudo acontece em `/admin/contas/<slug>`, na seção **WhatsApp do cliente**.

## Antes de começar

O servidor precisa ter o bridge de pé e três variáveis definidas:

| Variável                   | Para quê                              |
| -------------------------- | ------------------------------------- |
| `EVOLUTION_API_URL`        | Onde o bridge responde (rede interna) |
| `EVOLUTION_API_KEY`        | Autentica **nós** perante o bridge    |
| `EVOLUTION_WEBHOOK_SECRET` | Autentica **o bridge** perante nós    |

Sem a terceira o pareamento é **recusado**, e isso é intencional: o webhook
rejeita tudo quando ela está vazia, então parear assim entregaria um número
conectado cujas mensagens nunca seriam aceitas.

`EVOLUTION_INSTANCE` continua sendo **a nossa** — o número com que o time
prospecta. Ela não é uma conta.

## Parear, com o celular do cliente na mão

1. Abra `/admin/contas/<slug>` e clique em **Conectar número**.
2. No celular do cliente: **WhatsApp → Configurações → Aparelhos conectados →
   Conectar um aparelho**, e aponte para o QR.
3. A tela vira **Conectado** sozinha e mostra o número pareado.

O QR expira em ~40 segundos. A tela gera outro sozinha enquanto estiver aberta —
não é preciso recarregar nem clicar de novo.

Clicar em **Conectar número** duas vezes não cria duas instâncias: ela é nomeada
a partir do slug da conta, então repetir o passo continua de onde parou.

## O texto do assistente

Logo abaixo há um campo com **o que o assistente deve saber**: o que a empresa
faz, nas palavras dela. Horário, serviços, convênios, o que for.

**Sem esse texto o assistente não responde nada nessa conta.** As mensagens
chegam e ficam no CRM para uma pessoa atender, e isso é deliberado: o texto
padrão é o _nosso_ — descreve a Atlas e oferece os nossos serviços —, e responder
o paciente de um dentista falando de desenvolvimento web, no número do dentista,
é pior do que não responder.

As regras que não mudam (nunca inventar preço, nunca pedir senha, nunca dizer que
é humano) valem em toda conta e não dependem desse texto.

## O que o cliente vê

As conversas entram no CRM da conta dele. Quem atende pelo WhatsApp Web no
celular pareado continua atendendo normalmente — o assistente e a pessoa não se
atropelam, porque **responder como humano desliga o assistente naquela conversa**
até alguém religá-lo.

## Desconectar

O botão **Desconectar** faz logout e remove a instância. O número para de
responder na hora.

**As conversas continuam no CRM.** Elas são o registro do que foi dito a pessoas
reais e sobrevivem ao fim da conexão — o cliente pode ser reconectado depois e o
histórico continua lá.

## Quando alguma coisa não chega

Se o número aparece como **Conectado** e nenhuma mensagem entra, é quase sempre o
webhook apontando para um endereço antigo — o CRM mudou de host e a instância
continua chamando o anterior. Clicar em **Conectar número** de novo reescreve o
webhook com o endereço atual; não é preciso reparear.

Mensagens que chegam por uma instância que não pertence a nenhuma conta são
**descartadas**, nunca atribuídas à nossa. O log registra
`inbound.unrouted` com o nome da instância — é o que procurar quando um cliente
diz que escreveu e nada apareceu.
