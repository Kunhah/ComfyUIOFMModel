# Análise de reuniões

`/admin/reunioes` e `/operador/reunioes` — sobe a gravação de uma reunião
comercial, ela é transcrita **neste servidor** e avaliada contra o SPIN do
`roteiro-ligacao.md`: nota por etapa, momentos citados com timestamp, objeções e
uma hipótese do que derrubou a venda.

O ponto da ferramenta não é dar uma nota. É responder "por que essa não fechou"
com uma frase que o vendedor possa ir ouvir na gravação.

## O caminho de uma reunião

```
upload  →  ffmpeg  →  whisper.cpp  →  Claude  →  relatório
(streaming    (16kHz     (transcrição     (rubrica     (SQLite)
 pro disco)    mono)      com tempos)      SPIN)
```

Só o último passo sai da máquina. O áudio e a transcrição não vão para lugar
nenhum — o que é enviado ao modelo é o texto com marcações de tempo.

| Estado          | O que está acontecendo                               |
| --------------- | ---------------------------------------------------- |
| `fila`          | Na lista, ainda não começou                          |
| `transcrevendo` | whisper rodando. Alguns minutos para 40 min de áudio |
| `analisando`    | O modelo lendo a transcrição                         |
| `pronto`        | Relatório disponível                                 |
| `erro`          | Falhou; a mensagem está na página                    |

Os dois passos lentos rodam fora da requisição. Fechar a aba não interrompe
nada, e `instrumentation.ts` retoma na inicialização o que estava no meio quando
o processo parou.

## Instalação

```bash
npm run review:setup
```

Verifica ffmpeg e `whisper-cli`, diz como instalar o que faltar no seu sistema,
e baixa o modelo (~1,6 GB) para `data/whisper/`. É idempotente — rodar de novo
numa máquina configurada não baixa nada.

Faltando qualquer um dos três, a página diz **qual** dos três, em vez de
"não configurado".

### A chave da análise

```
ANTHROPIC_API_KEY=sk-ant-...
```

Sem ela a análise cai no chain do WhatsApp (Groq, OpenRouter): responde, e
responde genérico. `analysis_model` na linha registra quem respondeu, para uma
análise fraca poder ser explicada em vez de virar desconfiança na ferramenta.

## Decisões que valem saber

**A transcrição é local, e é uma escolha.** O arquivo é a voz de um cliente
discutindo os números dele, enviado por um vendedor que não negociou contrato de
tratamento de dados com ninguém. Mandar isso para um serviço de transcrição é
uma decisão que se toma em voz alta, não uma que se herda do que era mais fácil
de integrar. Também é grátis por reunião, o que importa numa ferramenta feita
para rodar em toda reunião e não só nas interessantes.

**O áudio é apagado depois de transcrito.** `REVIEW_KEEP_AUDIO=1` desliga isso.
O que todo recurso posterior precisa é da transcrição — reanalisar com uma
rubrica melhor lê o texto, não o áudio — então guardar o arquivo compra
re-transcrição e mais nada, ao custo de uma pasta de conversas de clientes sem
política de retenção.

**Não há separação de interlocutores.** A diarização do whisper.cpp precisa de
gravação estéreo com as partes em canais separados, o que uma gravação de celular
ou um export do Meet não é. O modelo deduz quem fala pelo contexto — acerta quase
sempre, e "quase" está escrito na página em vez de escondido.

**O desfecho é informado por você, nunca deduzido.** "Ache o que deu errado" e
"ache o que deu certo" são leituras diferentes da mesma transcrição, e adivinhar
qual fazer a partir das palavras é justamente o palpite que o modelo erra mais.

**A rubrica é o roteiro, não conselho genérico de vendas.** `rubric.ts` é o
`roteiro-ligacao.md` convertido em critérios, com âncoras de nota por etapa —
por isso o relatório diz "você pulou a implicação" em vez de "explore melhor as
dores do cliente". **Quando o roteiro muda, esse arquivo muda junto**; se os dois
divergirem, a ferramenta passa a treinar a equipe num método que ninguém combinou.

**Implicação e necessidade pesam mais que as outras seis etapas somadas.** São as
duas que correlacionam com fechamento e as duas que um vendedor experiente pula
por serem desconfortáveis. Uma reunião com abertura impecável e implicação zero é
uma reunião ruim, e a nota geral tem que dizer isso.

**A gravação de um operador é dele.** A rota responde 404 — não 403 — para uma
reunião de outra pessoa, porque um 403 confirma que ela existe. O admin vê todas.

## Variáveis de ambiente

Todas opcionais menos a chave; os padrões estão em `.env.example`.

| Variável            | Para quê                                              |
| ------------------- | ----------------------------------------------------- |
| `ANTHROPIC_API_KEY` | Quem faz a análise. Sem ela, cai no chain do WhatsApp |
| `ANTHROPIC_MODEL`   | Padrão `claude-opus-5`                                |
| `WHISPER_BIN`       | Se o binário não está no PATH como `whisper-cli`      |
| `WHISPER_MODEL`     | Padrão `data/whisper/ggml-large-v3-turbo.bin`         |
| `WHISPER_LANGUAGE`  | Padrão `pt`, declarado em vez de detectado            |
| `FFMPEG_BIN`        | Se ffmpeg não está no PATH                            |
| `REVIEW_AUDIO_DIR`  | Padrão `data/reunioes`                                |
| `REVIEW_KEEP_AUDIO` | `1` mantém o áudio depois da transcrição              |

## Antes de gravar

Gravar uma conversa da qual você participa é legal no Brasil. O cliente que
descobre depois é um cliente perdido, então avise: _"posso gravar para eu revisar
depois?"_ — uma frase, no começo da chamada. A página repete isso onde não dá
para não ver.
