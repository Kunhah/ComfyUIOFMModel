# Atlas IA — a infraestrutura, e os produtos em cima dela

The plan for the layer that every AI product we sell stands on, and for the
products themselves: insight de vendas, atendimento, pós-venda, finanças,
estratégia e os painéis que resumem tudo isso.

This is a design document, not a description of something that exists. The parts
marked **built** ship today — as of this writing that is the whole of Fase A,
`src/lib/ai/`, which the rest of the document is written on top of. Everything else is a commitment to a shape, so the
fifth product does not have to reinvent what the first one guessed at.

It sits under `docs/plataforma.md` and does not replace it: that document owns
tenancy, channels, the job runner and the three CRM modules. This one owns what
happens between "we have the data" and "the client reads a sentence that changes
what they do on Monday".

## The spine already exists. It is in the wrong place. — **built**

_(Built. `src/lib/ai/` now holds it; the section below is kept as the argument
for why, because that argument is what stops it being scattered again.)_

Three AI features ship today and all three were written independently:

| Onde                    | O que faz                                     | O que inventou de novo                        |
| ----------------------- | --------------------------------------------- | --------------------------------------------- |
| `lib/whatsapp/llm.ts`   | Provider chain: Groq → OpenRouter → Anthropic | O router, o timeout, o `LlmError`             |
| `lib/whatsapp/agent.ts` | Atendimento: prompt + envelope JSON + ações   | O contrato de envelope, o contexto do lead    |
| `lib/review/analyse.ts` | Lê a transcrição e diz o que derrubou a venda | Um segundo prompt de sistema, um `validate()` |

They already converged on the same four moves without anyone deciding they
should: **a system prompt built from real rows, a user prompt built from the
subject, a JSON envelope, and a `validate()` that refuses to trust the model.**
`analyse.ts` even imports `extractJson` from the WhatsApp agent, with a comment
saying why two implementations would be two sets of edge cases. That comment is
the whole argument for this document, generalised.

What is missing is everything that only hurts at four products and up: nobody
knows what a run cost, nobody can tell whether a prompt got worse last Tuesday,
and nothing stops a skill reading another account's rows because the query
forgot a `WHERE`.

## The thesis: one spine, many skills

**A skill is the unit.** Not an agent, not a service, not a page. A skill is:

```ts
type Skill<Input, Output> = {
  id: string; // "insight.lead", "financas.fluxo"
  /** What it is for, in one line. Shown in the run log and in /admin/ia. */
  purpose: string;
  /** Rows in, prompt out. The only place that touches the database. */
  context(input: Input, scope: Scope): Promise<Context>;
  system(ctx: Context): string;
  user(ctx: Context): string;
  /** Refuses the model's answer rather than passing it on. Never throws away silently. */
  validate(raw: unknown): Output;
  budget: Budget; // modelo, maxTokens, temperature, teto de custo
};
```

Everything else in `src/lib/ai/` exists to run one of those and record that it
ran. A new product is a new skill plus a page that shows its output; it is not a
new provider, a new prompt loader, a new JSON extractor, a new retry, a new cost
counter, and a new way of being wrong.

**The rule that keeps it honest: no route calls a provider directly.** If a
feature needs a model, it declares a skill. The moment a `fetch` to an inference
endpoint appears in `src/app/api/`, the run log has a hole in it and the cost
report is a guess.

### What we deliberately do not build

- **A vector database.** Our data is thousands of rows in SQLite with names,
  cities and niches on them — that is a `WHERE`, not an embedding. Semantic
  search over transcripts is the first honest use, and it can be FTS5 first.
  Revisit when a skill's context genuinely cannot be selected by a query.
- **A prompt-management SaaS.** Prompts are TypeScript in the repo, reviewed in
  the diff, deployed with the code. A prompt edited in a web UI is an
  unreviewable production change to the thing that talks to customers.
- **An agent framework.** The WhatsApp agent's envelope — a JSON object with a
  message and a bounded list of typed actions — already works, is testable
  without a network, and never lets a model call a function we did not enumerate.
  Multi-step tool loops come only where a single pass provably cannot do the job.
- **Fine-tuning.** Every failure we have seen so far is a context failure. Fix
  the rows we put in the prompt before touching weights.

## `src/lib/ai/` — the modules

```
src/lib/ai/
  providers.ts   -- moved from lib/whatsapp/llm.ts, unchanged in behaviour
  run.ts         -- runSkill(): the only path from a skill to a provider
  registry.ts    -- id → descrição. What /admin/ia lists.
  envelope.ts    -- extractJson + the validate helpers both consumers grew
  scope.ts       -- what a skill may read, and for whom
  brief.ts       -- the per-account context every skill shares
  cost.ts        -- tokens → BRL, per provider, per account
  evals/         -- fixtures + assertions per skill
```

### `runSkill()` is the whole contract

```ts
runSkill(skill, input, scope): Promise<{ output; runId; provider; cost }>
```

It builds the context, renders the prompts, picks the provider chain from the
budget, calls it, extracts the JSON, validates it, writes one row to `ai_runs`,
and returns. A failure writes the row too — a skill that fails silently is
indistinguishable from a skill nobody used.

**`runCompletion()` is the second entry point, and the narrow one.** Two features
predate the skill shape and should not be forced into it: the WhatsApp agent
never throws on a bad answer (`parseAgentReply()` degrades everything to
something sendable, because the alternative on a live thread is a customer left
on read — the exact opposite of the refusal `runSkill()` performs) and it takes a
second corrective round-trip, so a turn is one _or two_ completions; and the
meeting review's `validate()` fills defaults rather than rejecting, because a
thin review is still worth reading. What neither gets to opt out of is the
accounting. Both go through `runCompletion()`, which does the completion, the
costing and the row, and leaves the parsing to the caller.

```sql
CREATE TABLE IF NOT EXISTS ai_runs (
  id           INTEGER PRIMARY KEY,
  account_id   TEXT,                    -- NULL = Atlas (mesma convenção de leads)
  skill        TEXT NOT NULL,
  subject      TEXT,                    -- "lead:8123", "conta:acme/2026-09"
  provider     TEXT,                    -- quem respondeu, não quem foi tentado
  model        TEXT,
  tokens_in    INTEGER,
  tokens_out   INTEGER,
  cost_brl     REAL,
  latency_ms   INTEGER,
  state        TEXT NOT NULL            -- ok | invalido | erro | recusado
                 CHECK (state IN ('ok','invalido','erro','recusado')),
  error        TEXT,
  created_at   TEXT NOT NULL
);
```

`provider` records **who answered**, not who was asked, for the reason
`analysis_model` already exists on `meeting_reviews`: a thin report should be
explainable rather than doubted. `state = 'invalido'` is its own value and not an
error — a model that answers with well-formed nonsense is a prompt problem, and
collapsing it into `erro` hides the only signal that says so.

It lives in `data/prospector.db` with everything else. The reason is the one
already written at the top of `lib/whatsapp/db.ts`: a run is _about_ a lead or an
account, and a second file means no join and no foreign key. Additive only, added
through `addMissingColumns()` like every other column.

### The brief: context is the product

The model is a commodity and the prompt is a week of work. What actually
separates our answer from the client typing the same question into ChatGPT is
that ours arrives with their rows already in it.

`brief.ts` assembles, once per account and cached for the request:

- the account, its sites, its niche and its city;
- what it sells and at what ticket — today free text in `accounts.notes` and the
  WhatsApp brief, and that is not good enough for finance or strategy (see the
  open questions);
- the funnel as it stands: counts by stage, average time in stage, conversion;
- the last N conversations and their outcomes;
- what the meeting reviews found — objections, recurring stages that fail.

Every skill gets it. A skill that needs more asks in its own `context()`, and a
skill that needs less still gets it, because a finance answer that ignores the
funnel is the generic answer we are trying not to sell.

**The brief is the migration path, not the prompt.** When a client's data grows
past what fits in a context window, `brief.ts` is the one file that learns to
summarise. No skill changes.

### Scoping, again, in the query

The rule from `docs/plataforma.md` extends unchanged and matters more here,
because a leak through an AI feature is a leak _narrated in fluent Portuguese_.

`context()` takes `scope` as its **first argument, not as a filter someone
remembers to add**. A skill cannot construct a scope; it receives one from the
route, which got it from `requireAccount()`. And two hard rules on top:

- **A skill never receives raw SQL, a table name, or a query it composed.** It
  receives rows a typed reader returned. The model decides what to say, never
  what to read.
- **`account_id IS NULL` rows — everything the prospector found — are invisible
  to any skill running under a client scope.** That is our pipeline, and the
  answer to "does a client see leads the prospector found?" is no until somebody
  decides otherwise on purpose.

### Guardrails, and where they live

Not in the prompt. A prompt is a request; a guardrail is a `validate()` that
returns nothing when the answer is out of bounds.

- **Números que a IA não inventa.** Nenhuma skill emite um valor de contrato,
  preço, prazo, desconto ou projeção de receita que não venha de uma linha. The
  WhatsApp agent already forbids this in prose; here it is structural — the
  numeric fields of an envelope are ids of rows, and the renderer looks up the
  value.
- **Toda afirmação carrega a origem.** An insight cites the lead, the message or
  the metric it came from. An insight nobody can check is a sentence that costs
  us trust the first time it is wrong.
- **Nada envia sozinho.** A skill produces text and a _proposed_ action. Sending
  is a job, jobs come from the runner in `plataforma.md`, and enqueueing one
  requires either a human approving or an explicit per-account opt-in with caps
  and quiet hours. The bar the WhatsApp agent already meets — never schedule
  without the person agreeing — is the floor, not the ceiling.
- **Custo é um teto, não um relatório.** A monthly ceiling per account, checked
  in `runSkill()` **before** the call — every mechanism that only _notices_ an
  overrun notices it after it has been paid. Over the ceiling the run is recorded
  as `recusado` and the page says so. Configured per deployment as
  `AI_QUOTA_BRL`, unset by default: a ceiling that silently stops a client's
  inbox from answering is worse than the bill it prevents. A per-account override
  is a column on `accounts` and is the next change here, not this one.

### Evals: how we notice a prompt got worse

Cheap, in-repo, no service. `src/lib/ai/evals/<skill>/` holds fixtures — real
rows, anonymised, with the answer we consider correct — and `npm run eval`
runs each skill over them, asserting the _checkable_ parts: the envelope parses,
the schema validates, cited ids exist, no invented number, required fields
present, and (where it applies) a score inside a band.

It does not assert prose. Grading tone by model is a second model to maintain and
a second thing to be wrong. What we do instead is keep every run in `ai_runs` and
let operators mark an output as bad from the page it appears on — one column,
`useful INTEGER`, and the bad ones become next month's fixtures.

Run it in CI on every change to a prompt. A prompt edit with no eval run is the
only kind of change here that can degrade production without failing a test.

**Built, and narrower than this section promised.** `npm run eval` replays
recorded answers through each skill's `validate()`, with no provider call and no
database — free, deterministic, CI-able. It checks the envelope parses, that
`validate()` accepts what it should and refuses what it should not, that every
citation points at a fact we supplied, and that no number appears in the prose
that we did not supply. All three skills have fixtures — ten in total, covering
the failures each guardrail exists for: a citation nobody supplied, a fabricated
statistic, a lead dropped from a ranking, a duplicated one, an invented id, and
an envelope that parsed and said nothing.

The ranking fixtures pin the property that matters most about `insight.fila`:
every lead handed in comes back out. A skill that quietly lost one would be
deciding on its own that a business never gets called, invisibly — nobody counts
what is missing from a list.

## Os módulos

Ordered so each one is sellable alone, and so each reuses the rows the previous
one already had to assemble.

### Módulo 1 — Insight de vendas (pré-venda) · **built**

The one that pays for the rest, because it works on data we already own and it
sells _our_ pipeline before it sells anyone else's.

The prospector finds a business; the B2B crawler reads its site; `score.ts`
already answers "can I start a conversation, and is there anything worth selling
at the end of it?" with a number and pt-BR reasons. What is missing is the
sentence between that number and the call.

**Skills:**

- `insight.lead` — per lead: the angle (what is visibly broken and what it costs
  them), ICP fit with a reason, and an opener that references something real
  about _that_ business. Grounded in `leads`, a linha `companies` do B2B, the site
  extract, and `roteiro-ligacao.md` as the script it must stay inside.
- `insight.fila` — over a search result or a call list: which 20 of these 400 to
  call today and why, as a ranking with reasons. The queue an operator opens in
  the morning.
- `insight.objecao` — reads the meeting reviews across accounts in the same
  niche and tells the operator which objection this call will meet before it does.

**Why it was first:** every input existed, the output lands on a page that
exists, and the person who evaluates it is us — a bad insight is caught on the
call, not by a client.

**What shipped, and what did not.** `insight.lead` and `insight.objecao` are on
the dialer at `/admin/ligacoes/[id]`, generated on a click and cached per lead
and per niche. `insight.fila` ranks a list **at creation and
nowhere else**, behind an opt-in checkbox on the list builder.

That is the answer to the product question this raised. `createCallList` writes
positions in the order it is handed, so choosing the order there shapes a queue
without touching one; re-ranking a live list would move work an operator is
partway through, and they would come back from lunch to a different lead at
position twelve with no way to know why. The ranking also fails open — an
outage, a ceiling, or a bad answer leaves the list in the operator's own order
rather than refusing to build it, because a queue in the wrong order is a worse
day and no queue is no day.

Three grounding pieces came out of building it, and all three are reusable:

- **`facts.ts`** — the numbered fact list a skill hands the model, and the
  citation whitelist `validate()` filters against. The "no invented facts" rule
  is only a rule if an uncited claim can be dropped mechanically.
- **`segments.ts`** — which of six _sales_ segments a niche belongs to, and what
  changes in the pitch because of it. There are 43 niches; writing 43 templates
  by hand is how you get 43 templates, six of which are current. What actually
  changes the pitch is how a customer arrives and what one lost customer costs,
  and on that axis the 43 collapse to six: `agenda`, `consulta`, `orcamento`,
  `balcao`, `recorrente`, `parceria`. This is `roteiro-ligacao.md` §11, which
  until now reached no prompt at all — which is why an insight for a dentist read
  like an insight for a bakery with the noun swapped.

  It maps from the `group` each niche already carries, so a niche added to
  `niches.ts` is segmented the moment it is added rather than falling to the
  default until somebody notices; `OVERRIDES` names the few groups that split
  (a pet shop's bath-and-groom is an appointment book, the vet next door is a
  consultation), and `intent: "parceiro"` wins over everything, because pitching
  an agency as a customer ends the conversation in a sentence. The niche itself
  still reaches the model as a fact, so it can be specific about the trade; the
  segment tells it what kind of conversation this is.

  `insight.objecao` is keyed on the segment rather than the niche, which is also
  the cost design: a barbershop and a nail studio meet the same objections and
  share one cached answer instead of paying the expensive chain twice.

- **`skills/roteiro.ts`** — the call script reduced to the constraints a prompt
  can be held to. Not a copy of `roteiro-ligacao.md`: that file is outside the
  Next app and would not survive the standalone build, and a prompt needs rules
  rather than four pages of worked dialogue to paraphrase. The markdown wins
  whenever the two disagree.

**What it must not do:** invent a fact about the business. If the crawl found no
CRM, that is an observation; "eles perdem 30% dos leads" is a fabrication with a
number on it. The envelope separates `observado` (with source ids) from
`hipotese` (explicitly hedged in the copy), and the page renders them differently.

### Módulo 2 — Atendimento (**parcialmente built**)

Ships today for our own number. What this document adds is not features but
membership: the agent becomes a skill, its provider call goes through
`runSkill()`, and its runs land in `ai_runs`. Then, for the first time, we can
answer how much a conversation costs and which model actually answered it.

After that, and only after: per-account tone and knowledge from the brief instead
of one free-text field, a bounded FAQ per account, and handoff quality as an
eval fixture.

### Módulo 3 — Pós-venda e retenção

Runs on the conversations and appointments the platform produces.

- `posvenda.noshow` — a missed appointment, the recovery message, and when.
- `posvenda.reativacao` — who went quiet, ranked by how likely and how valuable,
  with the reason and a message that references the real last exchange.
- `posvenda.avaliacao` — the review request, timed off a _good_ interaction
  rather than a calendar. `plataforma.md` defers reputation as "one more
  sequence"; this is what makes that sequence not feel like spam.
- `posvenda.risco` — churn signals from tone and cadence, flagged to a human.
  Never acted on automatically: a wrong churn call that triggers a discount is
  worse than not noticing.

Depends on phases 1 and 2 of `plataforma.md`. Nothing here is buildable before
there is an inbox.

### Módulo 4 — Finanças

The module with the largest gap between perceived value and data on hand, and
therefore the one most likely to ship as a beautiful lie. Two stages, and the
first is not AI at all:

1. **Get the numbers.** Ticket, cost, close rate, ad spend. Manual entry per
   account first — a monthly form, five fields. Bank and ad-platform integrations
   only after a client fills that form twice, which is also the cheapest possible
   test of whether they care.
2. **Then the skills.** `financas.fluxo` (projeção com as premissas visíveis e
   editáveis), `financas.unitario` (CAC, LTV, payback, por canal), and
   `financas.preco` (where the ticket is out of line with the effort, from the
   funnel and the conversations).

**Every number carries its formula and its inputs.** A projection whose
assumptions are invisible is a number the client will act on and we cannot
defend. No skill in this module emits a currency value the renderer cannot trace
to a row.

### Módulo 5 — Estratégia

The quarterly, not the daily. `estrategia.diagnostico` — where the funnel loses
money, from the reviews, the conversations and the counts, with an ordered list
of what to change. `estrategia.concorrencia` — what the B2B crawler sees at the
competitors we can name. `estrategia.plano` — a 90-day plan whose every item is
a metric already in the dashboard, so the next quarter's diagnosis can grade it.

Highest value per output and lowest volume — a handful of runs a quarter — which
is exactly the shape that justifies the most expensive model and a long budget.

### Módulo 6 — Painéis e a narrativa

The surface the other five are read through, and the one the client opens.

The charts are not AI: counts, funnel, response time, appointments, revenue as
entered. On top of them one skill, `painel.narrativa` — _what changed, why, and
the three things to do this week_ — with every claim linking to the chart it came
from. The AI does not compute the numbers; it reads them and orders them.

One rule stops this being a gimmick: **the narrative is generated on a schedule,
not on page load.** A weekly job, one run per account, cached and shown with its
date. Regenerating on every visit costs money to say the same thing, and a page
whose text changes when you refresh reads as unserious.

## Custo

At the volumes we are talking about — a few hundred insights a day, a few
thousand messages a month — the bill is small if and only if the routing is
deliberate. It is the budget on the skill:

- **Atendimento e insight em lote**: the fast, cheap chain (Groq → OpenRouter).
  Volume is high, each output is short, latency is felt by a person waiting.
- **Análise, finanças, estratégia, narrativa**: Claude. Volume is low, the output
  is read carefully, and a cheap model here produces exactly the generic answer
  the client can get for free elsewhere. `analysisProviders()` already encodes
  this preference; it becomes a field on the budget instead of a function.

Per-account quota, checked before the call, reported on `/admin/ia` next to what
each skill actually spent. Cost per account per month is the number that decides
what we can price this at, and today we cannot compute it.

## Roadmap

Engineering weeks at one developer, assuming `plataforma.md` phases run first
where a module needs them.

| Fase                        | Escopo                                                                                                                                                                                                                  | Semanas |
| --------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------- |
| **A — A espinha** ✅ built  | `src/lib/ai/` extraído do WhatsApp, `runSkill()`, `runCompletion()`, `ai_runs`, `registry`, `cost.ts`, `/admin/ia`, teto por conta. Atendimento (turno e correção) e análise de reunião migrados e agora contabilizados | feito   |
| **B — Insight de vendas**   | `insight.lead`, `insight.fila`, `insight.objecao`, na tela do lead, na fila e no prospector. Fixtures e `npm run eval`                                                                                                  | 2–3     |
| **C — Brief e evals**       | `brief.ts` de verdade, evals em CI, marcação `useful` nas telas, primeiro relatório de custo por conta                                                                                                                  | 1–2     |
| **D — Painéis + narrativa** | Métricas por conta, `painel.narrativa` como job semanal, no `/app`                                                                                                                                                      | 2–3     |
| **E — Pós-venda**           | Depende de plataforma fase 1–2. `noshow`, `reativacao`, `avaliacao`, `risco`                                                                                                                                            | 2–3     |
| **F — Finanças**            | Entrada manual, depois `fluxo`, `unitario`, `preco`                                                                                                                                                                     | 3       |
| **G — Estratégia**          | `diagnostico`, `concorrencia`, `plano`                                                                                                                                                                                  | 2       |

Fase A era infraestrutura pura e não produziu nada vendável — é a única do documento
que não é, e é por isso que ela vem antes de qualquer coisa e dura duas semanas e
não seis. B é um produto sozinho, em cima de dados que já temos, avaliado por
nós.

## Perguntas em aberto

- **Onde o cliente descreve o próprio negócio?** Finanças e estratégia precisam
  de ticket, custo e capacidade, e hoje isso é texto livre em `accounts.notes`.
  Um formulário de onboarding é a resposta óbvia e é também a primeira coisa que
  um cliente não preenche. Decidir antes da fase D, não durante a F.
- **Retenção de contexto.** `ai_runs` guarda prompt e resposta? Guardar torna
  eval e depuração possíveis; guardar significa transcrições de clientes de
  clientes em texto claro, sem janela de retenção. Proposta: guardar os ids do
  contexto e o output, nunca o prompt renderizado — e uma janela curta atrás de
  uma flag para depurar.
- **A IA aparece como IA?** No atendimento a regra já existe e é nunca mentir. Em
  um insight ou num painel, dizer "gerado por IA" é honesto e também convida o
  cliente a descontar o que leu. A postura que sustenta as duas: a origem de cada
  afirmação está sempre visível, e aí a pergunta importa menos.
- **Quem responde quando erra.** Uma projeção errada num painel é uma decisão do
  cliente tomada em cima dela. Antes da fase F, escrever o que o contrato diz
  sobre isso.
