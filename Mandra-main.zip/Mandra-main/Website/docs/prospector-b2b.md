# Mandra Prospector B2B

`/prospector/b2b` — the second half of the lead tool. Where
[the prospector](prospector.md) finds Brazilian businesses **without** a website
and gives you a phone number, this one finds companies **with** a website in
Europe (or anywhere else) and gives you the e-mail address of somebody who can
sign a contract.

It is not a separate screen any more. Four routes render the same workspace and
differ only in which tab opens first and which shell they sit in — `/prospector`
and `/prospector/b2b` standalone, `/admin/prospector` and `/admin/prospector/b2b`
inside the CRM sidebar — so switching between the two tools changes no URL and
reloads nothing, and a crawl streaming into one panel survives you going to look
at a city in the other. Every URL still works as a deep link; it just stops being
a navigation once you are inside. The CRM's sidebar entry now stays in the CRM:
it used to jump to the dark standalone tool, which was the same crawler wearing a
different page.

It exists for a different sale. A salon with no site buys a site. A machine shop
in Baden-Württemberg with a 2011 WordPress and no CRM buys automation, a portal,
an integration — one deal worth dozens of the other kind. Those companies are
also, deliberately, the _less obvious_ ones: nobody is cold-mailing a metal
fabricator in Westphalia.

## The two halves of a run

```
descobrir                          rastrear
─────────                          ────────
Overture (setor × países)     →    crawler (robots, orçamento por site)
  ou lista colada                    ↓
                                   extrator de e-mails
                                     ↓
                                   extrator de empresa (VAT, telefone, stack)
                                     ↓
                                   score → histórico (SQLite) → CSV
```

They are two buttons on purpose. Discovery is a database query — cheap, instant
with a local extract, and worth iterating on. Crawling is hundreds of outbound
requests over several minutes. Fusing them meant every mistyped filter cost a
five-minute crawl.

## Getting started

Nothing to install; the tool ships with the site.

```bash
# from Website/
npm run dev            # or npm run up, which also checks the prospector's data
open http://localhost:3000/prospector/b2b
```

**Colar lista** works immediately — paste one domain per line and press
_Descobrir_:

```
Müller Präzisionstechnik GmbH, mueller-praezision.de
https://www.kern-microtechnik.com
brunner-maschinenbau.at
```

**Buscar por setor** queries Overture. Without a local extract it goes to S3 and
takes minutes per search; one download fixes that permanently:

```bash
npm run sync:b2b                              # Europe, ~5–25 min
npm run sync:b2b -- --countries DE,AT,CH      # just DACH, much faster
npm run sync:b2b -- --all-countries           # everything in the registry
```

From the repo root the same thing is `npm run prospector:b2b`.

## Discovery

### Sectors

`src/lib/b2b/sectors.ts`, 85 sectors over 206 Overture categories, in fifteen
groups. The industrial core is still there — metalurgia, usinagem, máquinas
industriais, plásticos, química, automação, engenharia, laboratórios, logística,
atacado, agro — and around it sits everything else whose commercial operation is
complex enough that software is a capital purchase:

- **Saúde e ciências da vida** — hospitais, redes de clínicas e diagnóstico,
  longa permanência, dispositivos médicos, saúde ocupacional, institutos de P&D.
- **Serviços financeiros** — seguradoras e corretoras, bancos e cooperativas de
  crédito, gestão de ativos, crédito e cobrança.
- **Imobiliário e ativos** — imobiliário corporativo e industrial, incorporação,
  administração predial, leilões.
- **Logística e frota** — armazenagem e última milha, veículos pesados, locação
  de equipamentos, aviação e náutica.
- **Serviços profissionais e corporativos** — jurídico empresarial, contabilidade
  e auditoria, consultoria, recrutamento, contact center, facilities.
- **Educação, hospitalidade, mídia e provedores** — ensino superior, escolas
  privadas, hotelaria, veículos de imprensa, ISPs regionais.

The selection criterion for all of it is one sentence: high contract value *and*
low competitive pressure in the inbox. A lift-maintenance firm in Graz and an
industrial packaging converter in Westphalia get no agency mail at all, which is
why the reply rate there is what it is. Categories that are valuable but already
saturated (marketing agencies, web designers) stay on the prospector side as
partnership targets and are deliberately not here.

Two rules, both inherited from the prospector's niche registry and both enforced
in code:

- **Category strings are never invented.** They come from
  `src/data/prospector/overture-categories.csv`. An unknown category matches
  nothing and fails silently, which reads as "no companies in this sector".
  `sync-b2b.mjs` cross-checks the whole list against that file before spending
  twenty minutes on a download.
- **A category belongs to exactly one sector.** The module throws at import
  otherwise, because an overlapping category splits a sector's companies between
  two slugs and makes every per-sector count fiction.

- **The extract has to know the list.** `sync-b2b.mjs` records the exact
  categories it pulled in `data/extract-b2b.json`, so a sector added after the
  file was built is *marked* in the picker as "fora do extrato" instead of
  quietly returning zero companies — which is indistinguishable from a market
  with none. `sectors.test.ts` runs the vocabulary and uniqueness checks before
  the commit, rather than after you have started a twenty-minute download.

Each sector also carries a `ticket` of 1–5 — a prior on deal size, shown in the
picker as ●●●●○ — plus a one-line `note` saying what there is to sell there
("Base instalada + contrato de manutenção: agenda, chamado, laudo"). The ticket
only breaks ties in the score; the note is so the person searching is choosing a
pitch rather than a noun, which matters once the list is 85 profiles deep.

### Campanhas de alto valor

The first entries in **Perfil de busca** are deliberate multi-sector campaigns,
not new Overture categories. They solve a practical discovery problem: a maker
of standard parts can be tagged as `metal_supplier`, `industrial_equipment` or
`b2b_electronic_equipment`, so searching only one sector leaves the best,
least-obvious companies behind.

- **Componentes industriais e peças normalizadas** — technical distributors,
  fastening/standard-parts makers and industrial component suppliers; use this
  first for companies in the vein of Hoffmann, Ganter, Halder, item and Elesa.
- **Fábrica conectada e engenharia de produção** — machine shops, automation
  integrators and industrial-equipment makers.
- **Processos regulados** — chemical, laboratory, pharma, biotech and medical
  supply businesses, where integrations and traceability carry real value.
- **Infraestrutura industrial**, **Infraestrutura crítica** and **Cadeia B2B** —
  operationally complex companies in utilities, ISPs, technical distribution and
  freight.
- **Saúde privada**, **Financeiro**, **Ativos imobiliários**, **Serviços
  profissionais**, **Frota e mobilidade** and **Educação e hospitalidade** — the
  same idea applied outside industry: a regulated or recurring process that runs
  today on e-mail and a spreadsheet.
- **Fábricas e plantas industriais** — the whole manufacturing base in one
  sweep: indústria geral, metalurgia, usinagem, máquinas, plásticos, química,
  eletrônica, embalagens, autopeças, bens de consumo, vidro e cerâmica.
- **Ticket máximo** and **Alto valor** are derived rather than listed: they sweep
  every sector at ticket 5, and at 4 and above, respectively. Retuning a sector's
  ticket moves it in and out of them, which is the point — a hand-copied list
  stops meaning what its label says within a month.

Campaigns only widen discovery. Each returned company retains its specific
sector, so scoring, exports and the history remain comparable to individual
sector searches.

**Radar amplo — empresas B2B escondidas** is the exception: it has no category
filter, so it can surface a specialised manufacturer or technical distributor
that Overture labelled unexpectedly. It needs a deliberately larger local
extract and never falls back to a planet-wide remote query:

```bash
npm run sync:b2b -- --universal --countries DE,AT,CH
```

Start with one country cluster and a 200-company batch. The crawler still
deduplicates domains and applies its usual per-site ceilings; only businesses
whose own pages expose a usable contact are carried into the working list.

### Countries

`src/lib/b2b/countries.ts` holds 40 countries with the four things the pipeline
needs: a bounding box, a dial code, ccTLDs and a VAT prefix.

The bounding box is the load-bearing one. Overture places is a single
unpartitioned set of Parquet files, so the only thing that stops a query scanning
the planet is a bbox predicate that row-group statistics can prune on. The boxes
are rectangles and every one of them spills across a border — `addresses[1].country`
is what makes the result correct.

The rest is used _after_ the crawl, to decide what a phone number, a domain or a
tax id found on a page means.

### The extract (`npm run sync:b2b`)

Writes `data/b2b-companies.parquet` plus `data/extract-b2b.json` (which records
the release and the countries, so a bumped `OVERTURE_RELEASE` can be spotted).

It is a _different file_ from the prospector's `places.parquet`, not an
extension of it: multi-country, filtered to B2B categories, and it keeps only
records that **have** a website — the crawler's entry point, without which a row
cannot be prospected here at all.

Both are gitignored, both live in `data/`, and every command must be run from
`Website/` because that path is resolved from `process.cwd()`.

## The crawler

`src/lib/b2b/crawl/`. Per site: a homepage, then the two to seven pages most
likely to carry contact details, then stop.

- **Links are ranked, not filtered.** `impressum` outranks everything, because in
  Germany, Austria and Switzerland that page is legally required to carry the
  company's full name, address, phone, e-mail, VAT id and the name of whoever
  runs it. There is no denser page in European B2B. Then contact, team, about,
  vertrieb, locations. Anchor text counts as much as the path, since plenty of
  sites route everything through `/index.php?id=42` and label it "Kontakt".
- **Standard paths are a fallback, not the plan.** `/kontakt`, `/impressum` and
  friends are only probed when link discovery found nothing contact-shaped —
  blind-probing eleven paths on every site would triple the request count to find
  pages a competent site simply links.
- **Depth 2, and only from a strong page.** That is how `/impressum` gets found
  when it is linked only from `/kontakt`, without opening the door to walking the
  catalogue.
- **Ceilings everywhere**: 8 pages, 35s per site, 12s per request, 2 MB per
  response, non-HTML bodies dropped, binaries never requested. A run of 200 sites
  always contains a handful that accept the connection and never send a byte;
  without a ceiling those decide how long the run takes.
- **Entry variants.** `http://` on a host that now only answers HTTPS, or the
  apex on a host that only serves `www`, are both one cheap retry away from a
  company that would otherwise be reported unreachable.
- **robots.txt is honoured** (toggleable in the UI). Not because it is legally
  required, but because we are about to introduce ourselves by e-mail and being
  the crawler that ignored their stated wishes is a checkable bad opening. It
  also happens to skip `/search`, `/cart` and the other infinite spaces.
- **Politeness**: concurrency is across _companies_ (8 at a time by default),
  never within one, plus a 250 ms floor between requests to the same host and an
  honoured `Crawl-delay` up to 2s.

### No headless browser

Deliberate. Playwright would add ~300 MB to an image that already ships a Next
server and DuckDB, and contact/impressum/about pages are almost universally
server-rendered even on sites whose homepage is a SPA. A site that renders its
address only in JavaScript is reported as reached with nothing found — one row
lost, rather than a browser in the deployment.

## E-mail extraction

`src/lib/b2b/extract/emails.ts`. The naive version of this module is one line —
`html.match(EMAIL_REGEX)` — and on European industrial sites it finds roughly
nothing, because those sites have spent twenty years hiding from spambots.

Every path exists because it was the only one that worked on some real category
of site:

| Fonte         | O que é                                                                                                                                        |
| ------------- | ---------------------------------------------------------------------------------------------------------------------------------------------- |
| `mailto`      | O caso honesto, e o de maior confiança                                                                                                         |
| `cloudflare`  | Ofuscação do plano grátis (XOR em hex), ligada por padrão — sem decodificar, uma página de contato atrás da Cloudflare mostra **zero** e-mails |
| `jsonld`      | schema.org `Organization`/`ContactPoint` — escrito para máquinas, sempre correto                                                               |
| `meta`        | `<meta name="contact">` em templates antigos                                                                                                   |
| `desofuscado` | `(at)`, `[dot]`, `&#64;`, endereços espaçados                                                                                                  |
| `script`      | `email: "…"` embutido em config de formulário                                                                                                  |
| `comentario`  | Deixado em comentários HTML, o tempo todo                                                                                                      |
| `texto`       | Texto visível, incluindo `url(mailto:…)` em CSS                                                                                                |

Then everything goes through the same validation — image sprites (`logo@2x.png`),
32-hex cache-busting locals, placeholder domains, `noreply@` and friends are all
dropped — and gets scored:

```
score = 20 (encontrado)
      + papel do local part      (ceo/geschäftsführung 45 · vertrieb/sales 40 · info 20 · jobs 8)
      | ou 38 se parecer pessoa  (nome.sobrenome@)
      + fonte                    (mailto 20 · jsonld 18 · desofuscado 14 · script 4)
      + página                   (impressum/kontakt 25 · team/about 18 · home 8)
      + domínio                  (próprio +15 · free-mail +5 · terceiros −20)
```

A named human outranks every shared mailbox except the director's, because a
reply from a person is the entire objective. `info@` is what every scraper finds
and is scored accordingly.

## Company extraction

`src/lib/b2b/extract/company.ts`: name (legal name preferred — that is what a
formal European B2B mail is addressed to), address, postcode, city, country,
phones, LinkedIn/Xing/Facebook/Instagram/YouTube, **VAT id**, **commercial
register** (HRB, KvK, SIRET, REA, Company No., CNPJ), head-count, languages and
a technology fingerprint.

Two things are worth knowing:

- **Every field prefers the machine-readable source** (JSON-LD, then meta tags)
  and falls back to page text, and is left `null` rather than guessed. A wrong
  address on a lead row is worse than an empty one — you find out it was wrong in
  the reply.
- **The street anchors the address.** A four-digit number followed by a
  capitalised word is _also_ the shape of "© 1997-2026 SPI", "2026 MiniDebConf
  Campinas" and "12025 Waterfront Drive". So the street is matched first and an
  ambiguous four-digit postcode is only believed within 160 characters of it;
  formats that carry letters or a hyphen (`1234 AB`, `12-345`, `1234-567`) and
  five-digit codes stand on their own.

The technology fingerprint is not trivia — it is the pitch. WordPress + jQuery +
no analytics + no CRM is a company whose commercial operation runs on an inbox
and a spreadsheet.

## Scoring

`src/lib/b2b/score.ts`, 0–100, four axes:

| Eixo             | O que mede                                                                                                                                   |
| ---------------- | -------------------------------------------------------------------------------------------------------------------------------------------- |
| **contato**      | Chega-se a um humano que pode dizer sim? Pessoa nomeada > diretoria > comercial > `info@` > nada. Domina o score — sem endereço não há lead. |
| **evidência**    | VAT, registro comercial, número de funcionários, LinkedIn. Prova de que a empresa existe, opera e tem porte.                                 |
| **oportunidade** | Sem rastreamento/CRM (+10), stack legado sem nada moderno (+8), sem HTTPS (+4), site multilíngue (+5 — quem exporta compra de fora).         |
| **ticket**       | O prior do setor na escala 1–5, centrado em 3, ±10. Só desempata — mas a faixa é larga porque o registro vai de gráfica a rede hospitalar.    |

The reasons behind the number are pt-BR phrases that go straight onto the row, so
the score never has to be taken on faith.

## Streaming

`POST /api/prospector/b2b/enrich` answers **NDJSON**, one event per line:
`start`, then a `prospect` per company as its crawl ends, then `done`.

Not JSON: a single document can only be parsed once complete, and a request that
answers only after ten minutes is indistinguishable from one that has hung. This
way a company lands on the board the moment it is finished and you can start
writing to the first good lead while the rest is still running. _Parar_ aborts
the fetch, which reaches the crawler through the request signal.

## History (SQLite)

`data/b2b.db`, via `node:sqlite` — a Node builtin, so no dependency and nothing
for `serverExternalPackages`. Two tables: `companies` (keyed by **domain**, since
that is the only identity an Overture record and a pasted line share) and
`emails` (one row per address, never deleted — an address that vanished in a
redesign still worked once).

It is a separate file from `data/prospector.db` on purpose: the two share no
columns, no id space and no lifecycle, and the prospector's database re-derives
every row's niche when it opens.

The history is what makes repeat runs cheap. **"Pular quem já está no histórico"**
skips domains that already produced an address; a company that was unreachable
last week is retried, since that costs one request and may now answer.

Schema changes must be additive and go through `addMissingColumns()` — people are
told they can keep this file.

## Export

`src/lib/b2b/csv.ts` owns the columns for **both** export paths (the board, whose
rows are posted back from the browser so the file matches exactly what is on
screen, and the history, read from SQLite and not capped by the run). Adding a
column in a route handler is how the prospector's two exports drifted apart.

First columns are the ones needed to actually send the mail: empresa, email,
email_tipo, site, país, cidade, score. UTF-8 BOM so Excel in a pt-BR locale
doesn't mangle every German name; formula-injection guarded; the phone loses its
`+` because Excel evaluates it as a formula and the apostrophe fix stays visible
everywhere else.

## Known limits

- **Overture's coverage of small industrial firms varies by country.** Where it
  is thin, the pasted-list mode is the answer — trade-fair exhibitor lists,
  association directories, a competitor's customer page.
- **JavaScript-only contact pages are missed** (see "no headless browser").
- **US-style addresses ("City, ST 90094") aren't parsed** — the postcode patterns
  are European, city-after-code. Discovery supplies the city anyway.
- **No e-mail verification.** Addresses are scraped, not SMTP-probed; the score
  reflects how the address was published, not whether the mailbox accepts mail.
- **No sending.** The tool opens `mailto:` with a subject in the site's language.
  Sequencing, tracking and unsubscribe handling are not here and shouldn't be
  bolted on without reading GDPR Art. 6(1)(f) first — B2B cold contact in the EU
  is legitimate-interest territory, and the rules differ by country.

## Environment

| Variable           | Default                        | Use                                                  |
| ------------------ | ------------------------------ | ---------------------------------------------------- |
| `OVERTURE_RELEASE` | `2026-07-22.0`                 | Pin the dataset release (shared with the prospector) |
| `B2B_DB`           | `data/b2b.db`                  | Move the history file                                |
| `B2B_USER_AGENT`   | `MandraProspectorBot/1.0 (+…)` | What the crawler calls itself in logs                |

## Attribution

Company data from [Overture Maps](https://overturemaps.org), CDLA Permissive 2.0
— free to use, store and export, which the Google Maps Platform terms are not.
Everything else on a company's page is that company's own publication.
