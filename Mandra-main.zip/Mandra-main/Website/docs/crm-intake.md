# Ligando o site de um cliente ao CRM

O que um cliente compra aqui é simples de descrever: o formulário de contato do
site dele cai direto num CRM, na mesma tela onde os leads do prospector já são
trabalhados. Nada de e-mail que se perde na caixa de entrada.

A instalação é um trecho de código. Não há SDK, não há build, não há conta para o
cliente criar.

## 1. Criar o site no CRM

`/admin/sites`, apenas administrador. Três campos:

| Campo                    | O que é                                               |
| ------------------------ | ----------------------------------------------------- |
| **Nome**                 | Como você reconhece o cliente na lista                |
| **País**                 | Decide se o telefone informado vira botão de WhatsApp |
| **Domínios autorizados** | Os endereços exatos de onde o formulário pode enviar  |

Um registro por **site**, não por cliente. Quem tem uma landing page e um site
principal quer saber qual das duas converteu.

### O domínio é comparado por igualdade exata

O navegador manda o endereço exato em que está. Se o site do cliente atende em
`https://cliente.com.br` **e** em `https://www.cliente.com.br`, liste os dois — do
contrário o formulário funciona para metade dos visitantes e nada em lugar nenhum
avisa que isso está acontecendo.

Domínio sem `https://` é aceito e completado. Caminho (`/contato`), usuário e
senha são recusados: não é isso que o navegador envia.

## 2. Colar o trecho no site do cliente

O botão **Instalar** mostra o trecho pronto, já com a chave:

```html
<form data-atlas-crm>
  <input name="nome" required placeholder="Seu nome" />
  <input name="email" type="email" placeholder="Seu e-mail" />
  <input name="telefone" placeholder="WhatsApp" />
  <textarea name="mensagem" placeholder="Como podemos ajudar?"></textarea>
  <button type="submit">Enviar</button>
</form>

<script src="https://SEU-CRM/atlas-crm.js" data-key="atlas_..."></script>
```

O script não mexe no CSS da página. O formulário continua sendo o do cliente, com
o visual do cliente.

### Não é preciso renomear os campos

`nome` e `name`, `telefone`, `celular`, `whatsapp` e `phone`, `mensagem` e
`message`, `empresa` e `company`, `cidade` e `city` chegam todos no mesmo lugar.
Renomear um input num site que já está no ar é justamente o tipo de edição que
quebra o analytics de alguém.

**Qualquer campo que o script não conhece vai junto**, identificado pelo label
visível, e vira uma linha na anotação do lead. Um formulário com "Orçamento
previsto" e "Como nos conheceu?" chega completo sem nenhuma configuração.

### Atributos opcionais no `<form>`

| Atributo              | Para quê                                          |
| --------------------- | ------------------------------------------------- |
| `data-atlas-success`  | Troca a mensagem de sucesso                       |
| `data-atlas-error`    | Troca a mensagem de erro                          |
| `data-atlas-redirect` | Manda para uma página de obrigado depois do envio |

E um `<p data-atlas-status></p>` em qualquer lugar do formulário recebe a
mensagem, se você quiser controlar onde ela aparece. Sem isso, o script cria um
parágrafo no fim do formulário.

### Formulário feito em React, Vue ou similar

```js
window.AtlasCRM.submit({
  nome: "Maria",
  email: "maria@exemplo.com.br",
  telefone: "31 99999-8888",
  mensagem: "Quero um orçamento",
  "Origem da indicação": "Instagram",
}); // devolve uma Promise
```

`window.AtlasCRM.scan()` reconecta formulários que foram remontados depois da
carga da página. Chamar duas vezes não duplica nada.

## 3. O lead no CRM

Chega em **Histórico completo** marcado como `formulario`, na etapa
**descoberta**, com:

- a mensagem e os campos extras já na anotação, com data e a página de origem;
- o botão de WhatsApp pronto, quando o telefone informado for um celular no plano
  de numeração do país do site;
- pontuação na mesma escala dos leads que o prospector encontrou, para que os dois
  ordenem juntos.

**Quem escreve duas vezes vira um lead só.** A identificação é pelo e-mail e, na
falta dele, pelo telefone — normalizado antes, para que "31 99999-8888" e
"+5531999998888" não virem duas pessoas. A segunda mensagem é acrescentada à
anotação; a etapa do funil, a situação, as etiquetas e o follow-up que o operador
já tiver definido **não são tocados**.

## Integração sem navegador (Zapier, n8n, backend)

```bash
curl -X POST https://SEU-CRM/api/v1/leads \
  -H "Content-Type: application/json" \
  -d '{
    "key": "atlas_...",
    "name": "Maria Souza",
    "email": "maria@exemplo.com.br",
    "phone": "31 99999-8888",
    "message": "Quero um orçamento",
    "company": "Café Central",
    "city": "Belo Horizonte",
    "uf": "MG",
    "pageUrl": "https://cliente.com.br/contato",
    "fields": { "Orçamento previsto": "R$ 2.000" }
  }'
```

`name` é obrigatório, e é preciso ter **e-mail ou telefone** — sem um dos dois o
lead não pode ser respondido nem reconhecido depois.

| Status | Quando                                             |
| ------ | -------------------------------------------------- |
| 201    | Lead novo                                          |
| 200    | Pessoa já conhecida, registro atualizado           |
| 202    | Honeypot preenchido — descartado, sem dizer ao bot |
| 400    | Campo obrigatório faltando ou JSON inválido        |
| 401    | Chave desconhecida                                 |
| 403    | Site desativado, ou origem fora da lista           |
| 429    | Limite de envios (5/min e 30/h por IP e por site)  |

## Desativar, trocar a chave, excluir

São três ações diferentes e não são intercambiáveis:

- **Desativar** para os envios e deixa o trecho instalado. É o que fazer com um
  cliente que pausou — reversível sem tocar no site dele.
- **Trocar a chave** invalida a que está na página do cliente. O formulário dele
  **para de funcionar** até o trecho ser atualizado. É para uma chave que vazou e
  está sendo abusada, e para mais nada.
- **Excluir** para a entrada de novos leads. **Os leads que o site já trouxe
  continuam no CRM** — são o funil do cliente, não a saída do formulário.

## O que protege o endpoint, e o que não protege

A chave **não é um segredo**. Ela está no código-fonte de um site público: quem
abre "ver código-fonte" tem a chave. Isso é uma propriedade de qualquer formulário
embutido, não uma falha a corrigir.

O que efetivamente limita o estrago:

- **a lista de domínios**, que impede _outro site_ de enviar pelo navegador de um
  visitante — mas não impede um `curl`, e não tem como impedir;
- **o limite de envios por IP**, que é o que de fato põe um teto;
- **o honeypot**, que pega os robôs que preenchem todo campo que encontram.

Todo valor recebido é tratado como texto que um estranho digitou: nada é
renderizado como HTML e nada é interpolado em SQL.

O limite de envios vive na memória do processo — ele zera a cada deploy e conta
separado por container. Serve para conter um retry travado, não uma enxurrada
distribuída. Se o CRM passar a rodar em mais de uma instância, é a única peça
aqui que precisa sair do processo.
