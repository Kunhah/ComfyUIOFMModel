import path from "node:path";
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // DuckDB, used by /prospector, ships a native binding (.node). Bundling it
  // breaks `require`, so it has to stay external and be loaded by Node itself.
  // Neither package is on Next's built-in opt-out list, so both must be named.
  serverExternalPackages: ["@duckdb/node-api", "@duckdb/node-bindings"],

  // Emits .next/standalone — the server plus only the node_modules it actually
  // uses — which is what the Dockerfile ships. Without it the image would have
  // to carry the full dependency tree (Three.js, Next, DuckDB) to run `next start`.
  output: "standalone",

  // Tracing defaults to this folder, but `npm install` runs at the workspace root
  // and hoists node_modules one level up. Left at the default, every dependency
  // resolves outside the trace root and the standalone build ships with none of them.
  outputFileTracingRoot: path.join(import.meta.dirname, ".."),

  // The tracer follows `path.join(process.cwd(), "data", ...)` in the prospector
  // and copies the whole folder — the 127MB Overture extract and the lead history
  // with it. Both are runtime state that belongs in a mounted volume, not a
  // 127MB-heavier build output carrying a snapshot that goes stale on the next sync.
  // The key is a route glob, while the file pattern is relative to this
  // Next.js project's root. `**` is not a route glob, so the old rule was
  // never applied to the instrumentation trace that follows process.cwd().
  outputFileTracingExcludes: { "/*": ["data/**/*"] },

  // The tracer finds `duckdb.node` because it is required by name, but not the
  // `libduckdb.so` sitting beside it — that one is dlopen'd by the binary itself,
  // which no static analysis can see. Without it the standalone server starts
  // fine and then fails every prospector request with "libduckdb.so: cannot open
  // shared object file". Both paths are listed because npm hoists to the
  // workspace root, but a non-hoisted install would put it in this folder.
  outputFileTracingIncludes: {
    "**": [
      "node_modules/@duckdb/node-bindings-*/**/*",
      "../node_modules/@duckdb/node-bindings-*/**/*",
    ],
  },
};

export default nextConfig;
