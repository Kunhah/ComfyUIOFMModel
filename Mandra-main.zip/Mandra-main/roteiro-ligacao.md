# Roteiro de ligação — Mandra

Cold call → reunião → proposta. A abertura é permissão, a reunião é SPIN.

Regra que vale para o documento inteiro: **quem fala mais perde.** Na abertura
você fala 30 segundos. Na reunião você fala menos de 30% do tempo. O roteiro
existe para você não improvisar sob pressão, não para ser lido em voz alta.

---

## 0. Antes de discar

Trinta segundos com a ficha do lead aberta no prospector. Você precisa de três
coisas na tela:

| O quê | Onde | Para quê |
| --- | --- | --- |
| **O motivo do score** | `sem site`, `só redes sociais`, `WhatsApp` | É a sua frase de abertura específica |
| **O nome do negócio, dito certo** | ficha | Errar o nome encerra a ligação |
| **Uma observação real** | Google/Instagram, 20 segundos | Prova que não é robodiscagem |

Se você não consegue completar a frase *"liguei porque reparei que ..."* com algo
verdadeiro e específico, não disque. Passe para o próximo.

**Meta da ligação:** agendar reunião. Não é vender, não é explicar, não é
mandar orçamento. Uma ligação que termina em "me manda por WhatsApp" é uma
ligação perdida, mesmo que pareça simpática.

---

## 1. Abertura (0s–10s)

> **Bom dia, é da [Empresa]?**
>
> *(espera confirmar)*
>
> **Então, vou ser sincero contigo: meu nome é Pedro Cunha, 
> e eu tenho uma proposta para a [Empresa]. Você quer desligar agora
> ou topa me dar 30 segundinhos e aí você decide?**

Isso é um *permission opener* e funciona porque devolve o controle. Três coisas
que você não pode mudar nele:

- **"Vou ser sincero"** antes de admitir que é ligação comercial. A pessoa já
  sabe que é. Você admitir primeiro compra a única coisa que importa nos
  primeiros 10 segundos: credibilidade.
- **"Você quer desligar"** dito por você. Tira a defesa dela.
- **"30 segundos"** — e você cronometra de verdade. Se estourar, perdeu.

**Pausa. Espere a resposta.** Não emende. O silêncio aqui é a parte que
funciona.

### Se disser não
> **Sem problema, obrigado pela sinceridade. Só uma coisa antes de desligar:
> se em algum momento vocês estiverem incomodados com contato que chega e não
> vira cliente, meu número fica aqui. Bom dia.**

Desligue de verdade. Um "não" respeitado hoje é uma ligação atendida daqui a
seis meses.

---

## 2. Os 30 segundos (10s–40s)

> **Ótimo. Eu ajudo empresas de [segmento] a adquirir mais clientes e, 
> principalmente, a aproveitar melhor os leads que já recebem mas sem sobrecarregar a equipe.**

> Uma coisa que eu queria entender é: quando uma empresa entra em contato pedindo orçamento
> e não fecha de primeira, vocês têm algum processo para acompanhar
> esse contato depois ou isso depende do acompanhamento manual de alguém?

> Você sabia que cerca de metade das pessoas que entram em 
> contato acabam não agendando? E, mesmo as que agendam, mais ou menos
> uma em cada cinco não comparece. Na minha 
> própria empresa, consegui aumentar bastante o número de 
> clientes só melhorando a gestão e o acompanhamento desses contatos. 
> Então deixa eu te perguntar, na [empresa] a conversão de leads tem sido um problema?

Terminou em pergunta. Sempre termine em pergunta — é o que transforma
apresentação em conversa.

Por que essa pergunta: qualquer resposta serve para você.

| Resposta | O que você faz |
| --- | --- |
| "Ninguém / só segunda" | **Achou.** Vá para o agendamento. |
| "Eu mesmo respondo, a qualquer hora" | "E você acha isso sustentável?" — a dor é o dono ser refém do celular. |
| "Tenho uma menina que responde" | "E ela consegue responder em quanto tempo, na média?" — a dor é o tempo de resposta. |
| "A gente não recebe contato por WhatsApp" | Troque o canal: telefone, Instagram, formulário. A pergunta é a mesma. |

---

## 3. Objeções na abertura

Regra: **reconheça, não discuta, devolva pergunta.** Uma tentativa por objeção.
Na segunda repetição da mesma objeção, agradeça e desligue.

**"Não tenho interesse."**
> Justo, você nem sabe do que se trata ainda. Só me diz uma coisa e eu desligo:
> hoje vocês conseguem saber quantas pessoas entraram em contato no mês passado
> e quantas viraram cliente?

**"Já temos site."**
> Ótimo, aí a gente já elimina metade do problema. Minha pergunta é a outra
> metade: o contato que chega pelo site, cai onde? Alguém acompanha se
> respondeu?

**"Já trabalhamos com uma agência."**
> Faz sentido. E eles cuidam do que acontece **depois** que o lead chega, ou
> só de trazer o lead? Porque é aí que eu atuo, e quase sempre é uma coisa
> diferente da outra.

**"Manda por e-mail/WhatsApp que eu vejo."**
> Mando sim, mas vou ser honesto: material genérico não te serve de nada. São
> 20 minutos onde eu te mostro o número de quantos contatos vocês estão
> perdendo. Se não fizer sentido em 20 minutos, você não me atende de novo.
> Terça de manhã ou quinta à tarde?

**"Quanto custa?"**
> Depende do que você precisa, e eu ainda não sei. O que eu posso te dizer é a
> faixa: começa em [R$ X] e não passa de [R$ Y] sem você aprovar antes. Faz
> sentido conversar 20 minutos pra eu te dar um número de verdade?

**"Não sou eu quem decide."**
> Entendi. E quem seria a pessoa? *(anote)* Você me passa o contato ou prefere
> que eu ligue direto? — e se ele hesitar: E você toparia participar da
> conversa? Sua visão da operação é o que falta pra proposta fazer sentido.

**"Agora não posso falar."**
> Imaginei, por isso perguntei dos 30 segundos. Qual o melhor horário: amanhã
> de manhã ou depois das 18h?

---

## 4. Agendamento (40s–70s)

Nunca pergunte *"quando você pode?"* — pergunta aberta gera "me liga semana que
vem". Ofereça **duas opções fechadas**.

> **Maravilha. Eu te mostro isso em 20 minutos, por vídeo. Terça às 10h ou
> quinta às 16h, o que fica melhor?**
>
> *(fecha o horário)*
>
> **Fechado, [dia] às [hora]. Qual o e-mail pra eu mandar o convite da agenda?**
>
> *(repete o e-mail letra por letra e confirma)*
>
> **Perfeito. Vai chegar um convite do Google Agenda em uns 5 minutos —
> confirma pra mim quando chegar? E anota meu número aí, é esse mesmo que
> apareceu no seu celular.**
>
> **Última coisa: pra reunião valer a pena, você consegue chegar sabendo
> quantos contatos vocês receberam no mês passado, mais ou menos? Nem precisa
> ser exato.**

Esse último pedido faz três coisas: cria compromisso (quem faz uma tarefa
comparece), começa o SPIN antes da reunião, e frequentemente é quando a pessoa
descobre sozinha que não sabe — que é exatamente o problema que você vende.

### Reduzir no-show
- Convite na agenda **na hora**, ainda com a pessoa na linha.
- Mensagem no WhatsApp logo após: uma linha, com o dia, hora e link.
- Confirmação na véspera: *"Confirmando nossa conversa amanhã às 10h — segue o
  link. Tudo certo?"*
- Registre a ligação e o follow-up no CRM antes de discar o próximo número.
  Uma ligação não registrada é uma ligação que não aconteceu.

---

## 5. A reunião — SPIN

**Estrutura:** 2 min de abertura · 20 min de SPIN · 5 min de solução · 3 min de
próximo passo.

A ordem não é estética. SPIN é uma sequência causal: **S** te dá o mapa da
operação, **P** encontra o problema dentro dela, **I** torna o problema caro o
bastante para valer o preço, e **N** faz o cliente pedir a solução em vez de
recebê-la. Pular uma etapa não acelera nada — transfere o trabalho dela para a
etapa de objeções, onde ela custa muito mais caro.

Um jeito de guardar a lógica inteira em uma frase: **problema pequeno não paga
solução grande.** A implicação é a etapa que muda o tamanho do problema, e é por
isso que ela é a que separa a reunião que fecha da que "vai pensar".

### Orçamento de perguntas

Não é decoração — é o que impede a reunião de virar interrogatório na etapa
errada. Numa reunião de 20 minutos de diagnóstico:

| Etapa | Nº de perguntas | Tempo | Quem fala |
| --- | --- | --- | --- |
| **S** Situação | 3 a 4, no máximo | ~3 min | Ele, em respostas curtas |
| **P** Problema | 4 a 6 | ~5 min | Ele começa a se soltar |
| **I** Implicação | 5 a 8 | ~8 min | Ele fala muito. É o objetivo |
| **N** Necessidade | 3 a 4 | ~4 min | Ele descreve a solução |

Se você fez mais perguntas de Situação do que de Implicação, a reunião foi um
cadastro, não um diagnóstico.

---

### 5.0 Abertura da reunião (2 min)

> **Obrigado pelo tempo. Deixa eu combinar o seguinte: nos primeiros 10
> minutos eu só vou te fazer perguntas sobre como funciona a operação de vocês
> hoje. Depois disso, uma de duas coisas acontece — ou eu te mostro exatamente o
> que eu faria, ou eu te digo que não é pra mim e a gente não perde mais tempo.
> Pode ser?**

Dizer que você pode desqualificar o negócio dele te separa de todo mundo que já
ligou pra ele, e compra permissão para fazer 20 perguntas sem parecer
interrogatório.

> **Antes de começar: o que te fez aceitar essa conversa?**

A resposta é a dor, dita por ele, nos primeiros 60 segundos. **Anote a frase
literal.** Ela volta três vezes: para direcionar o P, para abrir o N e para
fechar. Um fechamento que usa as palavras do cliente é o cliente concordando
consigo mesmo.

---

### 5.1 SITUAÇÃO — o mapa, e nada além dele

**Objetivo:** entender como o lead entra e como é tratado, com detalhe suficiente
para as perguntas de Problema serem específicas. Nada mais.

**Você tem que sair sabendo quatro coisas:** por onde chegam os contatos, quantos
chegam, quem responde, e onde isso fica registrado.

**A regra que economiza a reunião:** pergunta de Situação é **imposto**. Ela custa
paciência do cliente, não gera nenhuma vontade de comprar, e é a única etapa em
que quanto menos você fizer, melhor o resultado. Tudo que você conseguir
descobrir antes (Google, Instagram, o site, o próprio prospector) é uma pergunta
que você não gasta.

**As quatro perguntas, nesta ordem:**

1. **Me conta como funciona hoje: por onde chega um cliente novo pra vocês?**
   *(deixa ele listar sozinho — Instagram, indicação, Google, passagem na rua)*
2. **Desses, qual traz mais gente? E mais ou menos quantos por semana?**
3. **Quando esse contato chega, o que acontece na prática? Quem pega?**
4. **E fica registrado em algum lugar, ou é o histórico do WhatsApp mesmo?**

**Como transformar imposto em crédito.** Toda pergunta de Situação fica mais
barata se você mostrar o trabalho antes de perguntar:

> ❌ "Vocês têm site?"
> ✅ "Eu vi que vocês não têm site, só o Instagram — a captação hoje é toda por
> lá mesmo, ou o telefone ainda toca?"

A segunda versão prova que você pesquisou, e a resposta traz três informações em
vez de um sim/não.

**Sinais de que está indo bem:** as respostas ficam mais longas que a pergunta;
ele começa a explicar sem você pedir.

**Sinais de que travou:** respostas de uma palavra, ou "por que você quer saber
isso?". Destrave nomeando o motivo — *"pergunto porque quero entender onde vale a
pena mexer antes de te propor qualquer coisa"*.

**Erros:**
- Perguntar o que estava no Google. Queima credibilidade e tempo ao mesmo tempo.
- Fazer sete, oito perguntas de Situação porque são as fáceis e as confortáveis.
- Anotar em silêncio por dois minutos. Reaja ao que ele diz.

**Gatilho para avançar:** você já consegue completar a frase *"então hoje o
contato chega por X, quem responde é Y, e fica registrado em Z"*. Aí pare de
mapear.

**Transição:**
> **Entendi. E dentro desse processo, o que mais te incomoda hoje?**

---

### 5.2 PROBLEMA — encontre a dor, e não a resolva

**Objetivo:** fazer o cliente declarar, com as palavras dele, pelo menos duas
dificuldades concretas. Em SPIN isso se chama **necessidade implícita** — uma
insatisfação declarada, ainda sem intenção de compra ("demoro pra responder", "às
vezes perco contato").

**A regra que define esta etapa:** necessidade implícita **não** fecha venda.
Ela é matéria-prima. Quem ouve "eu demoro pra responder" e já emenda "então você
precisa de um sistema" acabou de queimar a etapa mais valiosa da reunião.

**As perguntas, da mais aberta para a mais específica:**

1. **Quais têm sido os gargalos que você percebe? Onde você sente que está
   perdendo gente?**
2. **Quanto tempo, na média, leva pra alguém responder um contato novo?**
   *(silêncio — deixa ele estimar em voz alta)*
3. **E fora do horário comercial? Sábado, domingo, sete da noite?**
4. **Quantas vezes vocês tentam de novo quando a pessoa pede orçamento e
   some?** *(a resposta quase sempre é "uma, no máximo duas")*
5. **Consegue me dizer, dos contatos do mês passado, quantos viraram cliente?**
   *(quase sempre: "não sei ao certo" — e esse "não sei" é um problema em si)*
6. **Já aconteceu de um cliente comentar que tinha chamado antes e ninguém
   respondeu?**

**As três dores que você está procurando** (uma basta, duas é bom, três é venda
fácil):

| Dor | Como ela aparece na fala dele |
| --- | --- |
| **Velocidade** | "às vezes demora", "depende de eu ver" |
| **Rastreabilidade** | "não sei quantos", "fica no WhatsApp mesmo" |
| **Dependência do dono** | "sou eu que respondo", "se eu não olhar, ninguém olha" |

**Como aprofundar sem resolver.** Quando ele reconhecer um problema, a sua
próxima frase é sempre uma das três:

- **"Me conta mais sobre isso."**
- **"Isso acontece com que frequência?"**
- **"Me dá um exemplo de quando isso aconteceu."**

O exemplo concreto é o mais poderoso: um caso específico com nome e data é o que
você vai usar na Implicação. "A gente perde contato" é abstrato; "teve uma
senhora semana passada que chamou no domingo e quando eu vi na segunda ela já
tinha fechado com outro" é uma história que dói.

**Sinais de que está indo bem:** ele dá exemplos sem você pedir; muda o tom;
reclama de alguém da equipe ou de si mesmo.

**Sinais de que travou:** "no geral tá tudo bem", "a gente se vira". Destrave com
uma pergunta de contraste: *"e se você comparasse com o volume que vocês tinham
antes da pandemia / com o que você gostaria?"* — ou vá pelo lado do custo de
oportunidade: *"o que você deixaria de fazer se não precisasse responder
mensagem?"*.

**Erros:**
- Apresentar solução aqui. É o erro nº 1 da profissão e ele parece produtivo.
- Aceitar a primeira dor e parar. A primeira é quase sempre a mais superficial.
- Fazer pergunta de problema com resposta sim/não ("você tem dificuldade em
  responder rápido?"). Pergunte *quanto*, *quando*, *quantas vezes*.

**Gatilho para avançar:** ele declarou pelo menos uma dor concreta **e** deu um
exemplo dela. Aí você para de procurar problema e começa a medir o que achou.

**Transição — a frase que abre a Implicação:**
> **Deixa eu entender melhor o tamanho disso.**

---

### 5.3 IMPLICAÇÃO — o coração da venda

**Objetivo:** transformar a necessidade implícita em algo **caro**. Você não está
buscando informação nova; está fazendo o cliente calcular, em voz alta, o que o
problema que ele acabou de admitir já custou.

**Por que esta é a etapa decisiva.** É a única que muda a percepção de tamanho do
problema, e é o tamanho do problema — não a qualidade da sua solução — que
determina se o preço parece caro ou barato. Um cliente que acha que perde R$ 400
por mês compara você com o sobrinho. Um cliente que acabou de calcular R$ 13 mil
por mês compara você com R$ 13 mil.

Também é a etapa mais desconfortável de conduzir, porque você está deliberadamente
deixando o cliente em um lugar ruim antes de oferecer a saída. Quem tem pressa de
aliviar esse desconforto vira consultor gratuito.

**As cinco direções de implicação.** Não faça as oito perguntas de enfiada: puxe
a corda da dor que ele declarou.

**1. Efeito cascata — o que esse problema causa em outra coisa**
> Quando um contato fica sem resposta até segunda, o que costuma acontecer com
> ele?
> Você diria que ele fica esperando vocês, ou que já chamou outros três?

**2. Frequência — de um caso para um padrão**
> Isso acontece quantas vezes por semana, no seu chute?
> Então em um mês são uns [n]. É por aí?

**3. Dinheiro — o número que muda a conversa**
> Quanto vale um cliente novo pra vocês, na média?
> E se ele volta, no ano?
> Então a gente tá falando de mais ou menos [n × ticket] por mês.

**4. Tempo e custo humano**
> Quantas horas por semana você gasta respondendo mensagem que poderia ser
> respondida sozinha?
> Isso te tira de quê? O que você faria com essas horas?
> E quando você tira férias, o que acontece com o WhatsApp?

**5. Segunda ordem — o custo que ele ainda não pensou**
> Isso já te fez perder alguma indicação? Porque cliente indicado que não é
> respondido queima duas pontas: ele e quem indicou.
> Se vocês dobrassem o movimento amanhã, a operação de atendimento aguentaria ou
> quebraria?
> Como isso afeta a moral da equipe, quando eles sabem que tem contato
> acumulando?

**A conta na frente dele.** Em algum ponto, pare de perguntar e some. Escreva na
tela compartilhada, ou fale devagar o suficiente para ele anotar:

```
Contatos por mês                          40
Sem resposta em 1 hora            60%  →  24
Desses, os que não voltam         70%  →  17
Ticket médio                          R$ 800
──────────────────────────────────────────────
Perda mensal                       R$ 13.600
Perda anual                        R$ 163.200
```

E então a frase mais importante da reunião inteira:

> **Esses números são teus, não meus. Eu só tô somando o que você me falou.**

**Use os números dele mesmo quando forem chutes.** Se ele disser "acho que uns 30
por mês", use 30. Um número conservador que ele mesmo deu é infinitamente mais
persuasivo que um número correto que você trouxe. E se ele contestar depois, ele
está contestando a si mesmo.

**Sinais de que está funcionando** — aprenda a reconhecer, porque são o momento
de parar de cavar:
- Ele fica em silêncio depois de um número.
- "Nossa, eu nunca tinha parado pra fazer essa conta."
- Ele começa a te ajudar a piorar o quadro: *"e olha que nem contei os que..."*
- Ele muda de postura: senta pra frente, pega papel.

**Sinais de que travou:** ele minimiza ("mas isso é normal do ramo", "todo mundo
tem isso"). Destrave com comparação: *"e você acha que o seu concorrente que
responde em cinco minutos também acha normal?"* — ou com o inverso: *"se isso é
normal, o que separa quem cresce de quem não cresce nesse ramo?"*.

**Erros:**
- Fazer a conta você e apresentar pronta. Ele precisa fazer, não assistir.
- Parar na primeira implicação. Uma dor tem três ou quatro consequências.
- Exagerar o número. Um cálculo inflado que ele não reconhece destrói tudo que
  você construiu — sempre arredonde **para baixo**.
- Aliviar o desconforto cedo demais ("mas isso é fácil de resolver"). Deixe
  doer o tempo necessário.
- Ficar na implicação depois que ele já entendeu. Aí vira maldade e ele fecha.

**Gatilho para avançar:** existe um número na mesa que ele reconhece como dele,
e ele demonstrou desconforto com esse número. Não avance antes disso; não
insista depois.

**Transição:**
> **Deixa eu te perguntar outra coisa então.**

---

### 5.4 NECESSIDADE DE SOLUÇÃO — faça ele vender pra ele mesmo

**Objetivo:** converter o desconforto em uma **necessidade explícita** — um desejo
declarado de resolver ("eu preciso responder mais rápido", "eu queria conseguir
acompanhar isso"). É a diferença entre "isso me incomoda" e "eu quero resolver
isso", e é o que a proposta responde.

**Por que existe uma etapa inteira só pra isso.** Aqui você vira a conversa: em
vez de você listar benefícios, o cliente lista. Isso faz três coisas que nenhum
argumento seu faz:

1. **Reduz objeção.** Ninguém discute com a própria conclusão.
2. **Prepara o campeão interno.** Quando ele for repetir isso ao sócio, vai
   repetir as palavras dele — não as suas, que ele não lembra.
3. **Te entrega a proposta escrita.** O que ele descrever aqui é o escopo, na
   ordem de prioridade dele.

**A forma da pergunta.** Sempre condicional e sempre terminando em benefício.
"Se... o que mudaria / que diferença faria / quanto valeria?"

1. **Se todo contato que chegasse fosse respondido em menos de um minuto, a
   qualquer hora, o que mudaria pra vocês?**
2. **Que diferença faria você abrir uma tela de manhã e ver exatamente quem
   chamou ontem, por qual canal, e quem ainda não foi respondido?**
3. **Se o sistema cutucasse sozinho quem pediu orçamento e sumiu, quanto disso
   daria pra recuperar, no teu chute?**
4. **Se isso funcionasse do jeito que você tá descrevendo, o que você faria com
   as horas que sobrariam?**

**As duas perguntas de compromisso**, que devem vir no fim desta etapa e nunca
antes:

5. **Vale a pena resolver isso agora, ou é coisa pra daqui seis meses?**
6. **Se eu te mostrasse como fazer isso sem aumentar o trabalho de ninguém aí,
   faria sentido a gente seguir?**

**O truque que multiplica esta etapa:** depois de cada resposta, pergunte
**"por quê?"** ou **"o que mais?"**. A primeira resposta é funcional ("eu
responderia mais rápido"); a segunda é a que vende ("eu conseguiria sair no fim
de semana sem ficar com o celular na mão").

**Anote com as palavras exatas dele.** Se ele disser "eu queria parar de ser
refém do celular", a sua proposta abre com *"para você parar de ser refém do
celular"*. Não com "solução de automação de atendimento".

**Sinais de que está funcionando:**
- Ele fala no futuro afirmativo: *"aí eu conseguiria..."*, *"a gente ia poder..."*
- Ele começa a perguntar **como** funciona, antes de você apresentar.
- Ele menciona alguém: *"a Cláudia ia amar isso"*. Isso é o campeão interno
  nascendo.
- Ele pergunta preço aqui. Não é objeção; é interesse. Segure: *"já te falo, só
  quero entender mais uma coisa antes"*.

**Sinais de que travou:** respostas curtas e genéricas ("ia ser bom, né"). Isso
quase sempre significa que a **Implicação foi fraca** — o problema ainda não é
grande o bastante para valer o esforço de imaginar a solução. Volte uma etapa,
não insista nesta.

**Erros:**
- Responder a própria pergunta. *"Se todo contato fosse respondido rápido, você
  ia converter muito mais, né?"* — isso é você falando, e não conta.
- Passar direto para a apresentação quando ele responde bem. É justamente aí que
  cabe mais uma pergunta.
- Fazer as perguntas de compromisso (5 e 6) cedo demais, antes de ele ter
  descrito o valor. Aí viram fechamento forçado.

**Gatilho para avançar:** ele descreveu, no futuro afirmativo, pelo menos um
benefício concreto — e disse que vale a pena resolver agora. Só então apresente.

---

### 5.5 Diagnóstico rápido: em que etapa a reunião travou

Quando uma reunião não anda, a causa quase nunca está na etapa em que você
percebeu o problema:

| O que você ouviu no fim | Etapa que falhou | O que fazer da próxima |
| --- | --- | --- |
| "Tá caro" | **Implicação** | O problema não ficou grande o bastante. Faça a conta com ele |
| "Vou pensar" | **Necessidade** | Ele nunca declarou querer resolver. Faltaram as perguntas condicionais |
| "Manda por e-mail" | **Problema** | Nenhuma dor real foi declarada. Você mapeou, não diagnosticou |
| "Não é prioridade agora" | **Implicação** | Faltou a dimensão tempo: o que custa esperar seis meses |
| "Preciso falar com meu sócio" | **Necessidade** | Ele não tem as palavras dele para repetir. Ofereça entrar na conversa |
| "Já temos alguém que faz" | **Problema** | Você não achou a lacuna entre o que o outro faz e o que dói |


## 6. Só agora: a solução (5 min)

Apresente **apenas o que responde ao que ele disse.** Se ele não falou de
agenda, não fale de agenda.

> **Deixa eu te mostrar o que eu faria, e é bem menos do que você tá esperando.**

**Camada 1 — a base (entrega em ~2 semanas)**
Site que aparece no Google + formulário que cai direto no nosso CRM, na mesma
tela onde a gente trabalha lead todo dia. Sem e-mail que se perde. Você abre e
vê quem chamou, quando, por onde, e o que já foi respondido.

**Camada 2 — o que resolve o gargalo dele**
Notificação instantânea de contato novo, follow-up automático em três toques
pra quem pediu orçamento e sumiu, e histórico de cada tentativa registrado.

**Camada 3 — quando fizer sentido**
Atendimento automático de primeira resposta e agendamento. Não vendo isso na
primeira conversa e não prometo prazo.

**Uma regra de honestidade que te protege:** prometa a Camada 1 com data. A
Camada 2, com data realista. A Camada 3, como direção, nunca como entrega
contratada. Cliente que recebe menos do que foi vendido não reclama — ele só
não indica você pra ninguém, e indicação é o seu canal mais barato.

---

## 7. Objeções na reunião

**"Tá caro."**
> Caro comparado com o quê? Porque a gente acabou de calcular [R$ 13.600] por
> mês indo embora. Se você me disser que o número tá errado, aí a conversa é
> outra e eu quero saber.

**"Vou pensar."**
> Claro. Só me ajuda: pensar sobre o quê especificamente? Preço, prazo, ou você
> não ficou convencido de que resolve? *(cada um leva a uma conversa diferente
> — "vou pensar" sozinho não leva a nenhuma)*

**"Preciso falar com meu sócio."**
> Perfeito, e é o certo. Vamos fazer assim: eu entro 15 minutos com vocês dois
> pra ele poder perguntar direto, em vez de você ter que defender minha
> proposta. Quinta às 10h serve pros dois?

**"Meu sobrinho faz site."**
> Provavelmente faz, e talvez mais barato. Mas site não era o problema — o
> problema é o contato que chega e ninguém responde. Ele vai manter isso
> rodando, com você sabendo todo mês quantos contatos entraram e quantos
> fecharam?

**"Já tentei isso antes e não funcionou."**
> O que exatamente você tentou, e onde travou? *(escute inteiro — é ouro; a
> resposta te diz exatamente o que não repetir)*

**"Manda a proposta por e-mail."**
> Mando hoje. E já deixo marcado 15 minutos pra terça pra gente passar por ela
> juntos — proposta lida sozinha vira dúvida que nunca é perguntada.

---

## 8. Fechamento e próximo passo

Nunca termine sem data marcada. "Te aviso" não é próximo passo.

> **Pelo que você me contou — [repete a frase dele: "a gente perde muito no
> sábado"] — faz sentido a gente começar pelo [Camada 1 + 2]. Eu te mando a
> proposta até amanhã de manhã, com escopo, prazo e valor.**
>
> **E já deixo marcado 15 minutos pra [dia] pra gente passar por ela juntos.
> Se estiver tudo certo, a gente começa na semana seguinte. Combinado?**

Se ele fechar na hora, feche na hora. Não diga "vou preparar tudo e te mando".

---

## 9. Depois da ligação (5 minutos, inegociável)

1. Registrar o desfecho e o próximo passo no CRM, com a data do follow-up.
2. Convite da agenda enviado.
3. WhatsApp de confirmação com o link.
4. Anotar, com as palavras dele, a dor principal e o número que vocês
   calcularam juntos. Isso vira a primeira linha da proposta.

---

## 10. Erros que matam a ligação

- Apresentar solução antes do I e do N. É o erro nº 1 e ele parece produtivo.
- Falar mais de 30% do tempo na reunião.
- Perguntar situação que dá pra descobrir no Google.
- Aceitar "me manda por WhatsApp" sem oferecer duas datas.
- Prometer atendimento automático com IA como se estivesse pronto.
- Argumentar com uma objeção duas vezes.
- Sair sem data marcada.
- Não registrar o lead. Ligação não registrada não existe.

---

## 11. Variações por segmento

**Salão / barbearia / estética**
Dor: agendamento por WhatsApp durante o atendimento; a profissional está com a
mão na cliente e o celular apita.
> Quando você tá atendendo e chega mensagem, você responde na hora ou depois?
> E quantas somem nesse meio tempo?

**Clínica (odonto, fisio, estética)**
Dor: primeira consulta perdida por falta de retorno; paciente que pediu
orçamento e não voltou.
> Dos orçamentos que vocês passaram no mês passado, quantos vocês retomaram
> depois? E quanto vale um paciente que fecha o tratamento inteiro?

**Comércio / serviço local (obra, reforma, assistência)**
Dor: orçamento pedido por três empresas, ganha quem responde primeiro.
> Quando alguém pede orçamento, você é o primeiro, o segundo ou o terceiro a
> responder? Sabe quem responde antes de você?

**Indústria / B2B (prospector B2B)**
Ciclo mais longo, o gargalo não é velocidade — é rastreabilidade e follow-up.
> Quando chega um pedido de cotação pelo site, ele cai onde? E se o vendedor
> que pegou sai de férias, quem sabe que aquilo existe?
